import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))

from core.perception.perception_types import Position3D, SourceSensor
from core.fusion.fusion_types import FusedObject, FusedWorldState, FusionMode
from core.prediction.phase4c_pipeline import Phase4CPipeline
from core.prediction.prediction_types import TrackLifecycleState


def _obj(track_id, t, x, y, vx=3.0, vy=0.0, heading=0.0, cls="car"):
    return FusedObject(
        fused_object_id=f"f_{track_id}", object_class=cls, class_confidence=0.9,
        position_3d=Position3D(x, y, 0.0), velocity=(vx, vy, 0.0),
        dimensions=None, heading=heading, distance=10.0, bbox_2d=None,
        source_sensors=frozenset({SourceSensor.CAMERA, SourceSensor.LIDAR}),
        position_confidence=0.85, existence_probability=0.85, quality=0.8,
        track_id=track_id, timestamp=t,
    )


def _world(objects, t, mode=FusionMode.PARTIAL_FUSION):
    return FusedWorldState(timestamp=t, frame_id=1, fusion_mode=mode, objects=objects)


def test_reappearing_track_reuses_same_track_id_no_duplicate():
    pipe = Phase4CPipeline()
    t = 1.0
    for _ in range(3):
        o = _obj("recover_1", t, t * 2.0, 0.0)
        pipe.process(_world([o], t))
        t += 0.2

    # Miss two cycles (goes TEMPORARILY_LOST / coasts).
    for _ in range(2):
        t += 0.2
        pipe.process(_world([], t))

    # Measurement returns with the same track_id.
    t += 0.2
    o = _obj("recover_1", t, t * 2.0, 0.0)
    out = pipe.process(_world([o], t))

    matches = [p for p in out.objects if p.track_id == "recover_1"]
    assert len(matches) == 1, "reassociation must not create a duplicate track"
    assert matches[0].coasted is False


def test_reappearing_track_lifecycle_returns_to_active():
    pipe = Phase4CPipeline()
    t = 1.0
    for _ in range(3):
        o = _obj("recover_2", t, t * 2.0, 0.0)
        pipe.process(_world([o], t))
        t += 0.2

    for _ in range(2):
        t += 0.2
        pipe.process(_world([], t))
    assert pipe._engine.lifecycle.get_state("recover_2") in (
        TrackLifecycleState.TEMPORARILY_LOST, TrackLifecycleState.STALE, TrackLifecycleState.ACTIVE,
    )

    t += 0.2
    o = _obj("recover_2", t, t * 2.0, 0.0)
    pipe.process(_world([o], t))
    assert pipe._engine.lifecycle.get_state("recover_2") == TrackLifecycleState.ACTIVE


def test_track_history_is_preserved_across_a_brief_loss():
    pipe = Phase4CPipeline()
    t = 1.0
    for _ in range(3):
        o = _obj("recover_3", t, t * 2.0, 0.0)
        pipe.process(_world([o], t))
        t += 0.2
    history_before = len(pipe._engine.history.get_history("recover_3"))

    t += 0.2
    pipe.process(_world([], t))  # one missed cycle, no new measurement

    t += 0.2
    o = _obj("recover_3", t, t * 2.0, 0.0)
    pipe.process(_world([o], t))
    history_after = len(pipe._engine.history.get_history("recover_3"))

    # History grew (the recovered measurement was appended), it wasn't reset.
    assert history_after > history_before
