import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))

from core.perception.perception_types import Position3D, SourceSensor
from core.fusion.fusion_types import FusedObject, FusedWorldState, FusionMode
from core.prediction.prediction_engine import PredictionEngine, PredictionEngineConfig


def _fused_object(track_id="track_1", t=1.0, x=0.0, y=0.0, vx=3.0, vy=0.0):
    return FusedObject(
        fused_object_id=f"fused_{track_id}", object_class="car", class_confidence=0.9,
        position_3d=Position3D(x, y, 0.0), velocity=(vx, vy, 0.0),
        dimensions=None, heading=0.0, distance=10.0, bbox_2d=None,
        source_sensors=frozenset({SourceSensor.CAMERA}),
        position_confidence=0.9, existence_probability=0.9,
        track_id=track_id, timestamp=t,
    )


def _world(obj, t):
    return FusedWorldState(timestamp=t, frame_id=1, fusion_mode=FusionMode.SINGLE_SENSOR, objects=[obj])


def test_uncertainty_present_for_every_horizon():
    engine = PredictionEngine()
    out = engine.process(_world(_fused_object(t=1.0), 1.0))
    obj = out.objects[0]
    assert len(obj.trajectory) == len(engine.config.horizons_s)
    for point in obj.trajectory:
        assert point.covariance is not None


def test_uncertainty_grows_with_horizon():
    engine = PredictionEngine()
    out = engine.process(_world(_fused_object(t=1.0), 1.0))
    obj = out.objects[0]
    sigma_x_by_horizon = [pt.covariance[0][0] for pt in obj.trajectory]
    # Strictly increasing sigma_x^2 as horizon grows (spec section 13).
    assert all(a < b for a, b in zip(sigma_x_by_horizon, sigma_x_by_horizon[1:]))


def test_uncertainty_not_identical_across_horizons():
    engine = PredictionEngine()
    out = engine.process(_world(_fused_object(t=1.0), 1.0))
    obj = out.objects[0]
    sigmas = {pt.covariance[0][0] for pt in obj.trajectory}
    assert len(sigmas) == len(obj.trajectory)


def test_short_horizon_has_lower_uncertainty_than_long_horizon():
    engine = PredictionEngine()
    out = engine.process(_world(_fused_object(t=1.0), 1.0))
    obj = out.objects[0]
    shortest = min(obj.trajectory, key=lambda p: p.horizon_s)
    longest = max(obj.trajectory, key=lambda p: p.horizon_s)
    assert shortest.covariance[0][0] < longest.covariance[0][0]


def test_predicted_object_exposes_sigma_fields():
    engine = PredictionEngine()
    out = engine.process(_world(_fused_object(t=1.0), 1.0))
    obj = out.objects[0]
    for key in ("sigma_x", "sigma_y", "sigma_vx", "sigma_vy"):
        assert key in obj.uncertainty
        assert obj.uncertainty[key] >= 0.0
