import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))

from core.perception.perception_types import Position3D, SourceSensor
from core.fusion.fusion_types import FusedObject, FusedWorldState, FusionMode
from core.prediction.phase4c_pipeline import Phase4CPipeline
from core.prediction.sensor_quality import (
    SensorQuality, classify_sensor_quality, uncertainty_multiplier, confidence_multiplier,
)
from core.prediction.uncertainty_engine import UncertaintyFactors, compute_uncertainty


def _obj(track_id, t, x, y, vx=3.0, vy=0.0, heading=0.0, quality=0.9,
         sensors=frozenset({SourceSensor.CAMERA, SourceSensor.LIDAR, SourceSensor.RADAR}),
         position_confidence=0.9):
    return FusedObject(
        fused_object_id=f"f_{track_id}", object_class="car", class_confidence=0.9,
        position_3d=Position3D(x, y, 0.0), velocity=(vx, vy, 0.0),
        dimensions=None, heading=heading, distance=10.0, bbox_2d=None,
        source_sensors=sensors, position_confidence=position_confidence,
        existence_probability=0.9, quality=quality, track_id=track_id, timestamp=t,
    )


def _world(objects, t, mode=FusionMode.FULL_FUSION):
    return FusedWorldState(timestamp=t, frame_id=1, fusion_mode=mode, objects=objects)


def test_classify_full_fusion():
    q = classify_sensor_quality(fusion_mode="FULL_FUSION", sensor_count=3, quality=0.9, position_confidence=0.9)
    assert q == SensorQuality.FULL_FUSION


def test_classify_partial_fusion():
    q = classify_sensor_quality(fusion_mode="PARTIAL_FUSION", sensor_count=2, quality=0.7, position_confidence=0.7)
    assert q == SensorQuality.PARTIAL_FUSION


def test_classify_single_sensor():
    q = classify_sensor_quality(fusion_mode="SINGLE_SENSOR", sensor_count=1, quality=0.6, position_confidence=0.6)
    assert q == SensorQuality.SINGLE_SENSOR


def test_classify_low_confidence_regardless_of_sensor_count():
    q = classify_sensor_quality(fusion_mode="FULL_FUSION", sensor_count=3, quality=0.1, position_confidence=0.1)
    assert q == SensorQuality.LOW_CONFIDENCE


def test_no_valid_sensor_is_low_confidence():
    q = classify_sensor_quality(fusion_mode="NO_VALID_SENSOR", sensor_count=0, quality=0.0, position_confidence=0.0)
    assert q == SensorQuality.LOW_CONFIDENCE


def test_uncertainty_and_confidence_multipliers_monotonic_with_degradation():
    tiers = [SensorQuality.FULL_FUSION, SensorQuality.PARTIAL_FUSION, SensorQuality.SINGLE_SENSOR, SensorQuality.LOW_CONFIDENCE]
    unc = [uncertainty_multiplier(t) for t in tiers]
    conf = [confidence_multiplier(t) for t in tiers]
    assert unc == sorted(unc)               # uncertainty strictly non-decreasing as quality worsens
    assert conf == sorted(conf, reverse=True)  # confidence strictly non-increasing


def test_degraded_sensor_quality_increases_predicted_sigma():
    common = dict(horizon_s=1.0, base_sigma=0.5, object_type="car")
    full = compute_uncertainty(UncertaintyFactors(sensor_quality=SensorQuality.FULL_FUSION, **common))
    low = compute_uncertainty(UncertaintyFactors(sensor_quality=SensorQuality.LOW_CONFIDENCE, **common))
    assert low.sigma_x > full.sigma_x
    assert low.confidence < full.confidence


def test_pipeline_reduces_confidence_when_single_sensor():
    pipe_full = Phase4CPipeline()
    pipe_single = Phase4CPipeline()

    full_obj = _obj("c1", 1.0, 0.0, 0.0, quality=0.95, position_confidence=0.95,
                     sensors=frozenset({SourceSensor.CAMERA, SourceSensor.LIDAR, SourceSensor.RADAR}))
    single_obj = _obj("c2", 1.0, 0.0, 0.0, quality=0.5, position_confidence=0.5,
                       sensors=frozenset({SourceSensor.CAMERA}))

    out_full = pipe_full.process(_world([full_obj], 1.0, mode=FusionMode.FULL_FUSION))
    out_single = pipe_single.process(_world([single_obj], 1.0, mode=FusionMode.SINGLE_SENSOR))

    p_full = out_full.objects[0]
    p_single = out_single.objects[0]
    assert p_full.sensor_quality == SensorQuality.FULL_FUSION
    assert p_single.sensor_quality in (SensorQuality.SINGLE_SENSOR, SensorQuality.LOW_CONFIDENCE)
    assert p_single.predicted.prediction_confidence < p_full.predicted.prediction_confidence
