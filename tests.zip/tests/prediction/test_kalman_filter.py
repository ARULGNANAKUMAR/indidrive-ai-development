import math
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))

from core.prediction.kalman_filter import KalmanFilterCV


def test_kf_uninitialized_returns_none_state():
    kf = KalmanFilterCV()
    assert kf.get_state() is None
    assert kf.get_covariance() is None


def test_kf_initialize_sets_state():
    kf = KalmanFilterCV()
    kf.initialize(1.0, 2.0, vx=0.5, vy=-0.5)
    state = kf.get_state()
    assert state == (1.0, 2.0, 0.5, -0.5)


def test_kf_predict_moves_position_by_velocity():
    kf = KalmanFilterCV()
    kf.initialize(0.0, 0.0, vx=1.0, vy=0.0)
    kf.predict(2.0)
    x, y, vx, vy = kf.get_state()
    assert math.isclose(x, 2.0, rel_tol=1e-6)
    assert math.isclose(vx, 1.0, rel_tol=1e-6)


def test_kf_predict_grows_covariance():
    kf = KalmanFilterCV()
    kf.initialize(0.0, 0.0, vx=1.0, vy=0.0)
    cov_before = kf.get_covariance()
    kf.predict(1.0)
    cov_after = kf.get_covariance()
    assert cov_after[0][0] > cov_before[0][0]


def test_kf_update_pulls_state_toward_measurement():
    kf = KalmanFilterCV(measurement_noise=0.01)
    kf.initialize(0.0, 0.0, vx=0.0, vy=0.0)
    kf.predict(1.0)
    kf.update(10.0, 10.0)
    x, y, _, _ = kf.get_state()
    assert x > 5.0
    assert y > 5.0


def test_kf_reset_clears_state():
    kf = KalmanFilterCV()
    kf.initialize(1.0, 1.0)
    kf.reset()
    assert kf.get_state() is None
    assert kf.is_initialized is False


def test_kf_missing_measurement_is_tolerated():
    kf = KalmanFilterCV()
    kf.initialize(0.0, 0.0, vx=1.0, vy=0.0)
    kf.predict(1.0)
    # No update() call this cycle -- filter should still hold a valid state.
    state = kf.get_state()
    assert state is not None
    assert all(math.isfinite(v) for v in state)


def test_kf_irregular_timestamps_handled():
    kf = KalmanFilterCV()
    kf.initialize(0.0, 0.0, vx=1.0, vy=0.0)
    kf.predict(0.01)
    kf.update(0.01, 0.0)
    kf.predict(3.7)
    kf.update(3.7, 0.0)
    state = kf.get_state()
    assert all(math.isfinite(v) for v in state)


def test_kf_invalid_dt_is_safe():
    kf = KalmanFilterCV()
    kf.initialize(0.0, 0.0, vx=1.0, vy=0.0)
    kf.predict(math.nan)
    kf.predict(-5.0)
    state = kf.get_state()
    assert all(math.isfinite(v) for v in state)


def test_kf_nan_measurement_is_skipped_not_applied():
    kf = KalmanFilterCV()
    kf.initialize(0.0, 0.0, vx=1.0, vy=0.0)
    kf.predict(1.0)
    state_before = kf.get_state()
    kf.update(math.nan, math.inf)
    state_after = kf.get_state()
    assert state_before == state_after


def test_kf_std_devs_are_nonnegative():
    kf = KalmanFilterCV()
    kf.initialize(0.0, 0.0)
    kf.predict(1.0)
    sigmas = kf.get_std_devs()
    assert all(s >= 0.0 for s in sigmas)
