import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))

from core.perception.perception_types import Position3D, SourceSensor
from core.fusion.fusion_types import FusedObject, FusedWorldState, FusionMode
from core.prediction.prediction_engine import PredictionEngine


def _obj(track_id, t, x, y, vx=2.0, vy=1.0, heading=0.2):
    return FusedObject(
        fused_object_id=f"fused_{track_id}", object_class="car", class_confidence=0.9,
        position_3d=Position3D(x, y, 0.0), velocity=(vx, vy, 0.0),
        dimensions=None, heading=heading, distance=10.0, bbox_2d=None,
        source_sensors=frozenset({SourceSensor.CAMERA}),
        position_confidence=0.9, existence_probability=0.9, track_id=track_id, timestamp=t,
    )


def _sequence():
    return [
        FusedWorldState(timestamp=1.0, frame_id=1, fusion_mode=FusionMode.SINGLE_SENSOR,
                         objects=[_obj("101", 1.0, 0.0, 0.0)]),
        FusedWorldState(timestamp=1.1, frame_id=2, fusion_mode=FusionMode.SINGLE_SENSOR,
                         objects=[_obj("101", 1.1, 0.2, 0.1)]),
        FusedWorldState(timestamp=1.2, frame_id=3, fusion_mode=FusionMode.SINGLE_SENSOR,
                         objects=[_obj("101", 1.2, 0.4, 0.2)]),
    ]


def _run_sequence():
    engine = PredictionEngine()
    outputs = []
    for ws in _sequence():
        outputs.append(engine.process(ws))
    return outputs


def test_same_input_sequence_produces_same_selected_models():
    run1 = _run_sequence()
    run2 = _run_sequence()
    models1 = [o.objects[0].selected_model for o in run1]
    models2 = [o.objects[0].selected_model for o in run2]
    assert models1 == models2


def test_same_input_sequence_produces_same_trajectory():
    run1 = _run_sequence()
    run2 = _run_sequence()
    traj1 = [[(round(p.x, 9), round(p.y, 9)) for p in o.objects[0].trajectory] for o in run1]
    traj2 = [[(round(p.x, 9), round(p.y, 9)) for p in o.objects[0].trajectory] for o in run2]
    assert traj1 == traj2


def test_same_input_sequence_produces_same_uncertainty():
    run1 = _run_sequence()
    run2 = _run_sequence()
    unc1 = [o.objects[0].uncertainty for o in run1]
    unc2 = [o.objects[0].uncertainty for o in run2]
    assert unc1 == unc2


def test_single_frame_processed_twice_by_fresh_engines_is_identical():
    ws = FusedWorldState(timestamp=1.0, frame_id=1, fusion_mode=FusionMode.SINGLE_SENSOR,
                          objects=[_obj("101", 1.0, 5.0, 5.0)])
    out_a = PredictionEngine().process(ws)
    out_b = PredictionEngine().process(ws)
    da, db = out_a.to_dict(), out_b.to_dict()
    # Latency metrics are real wall-clock measurements (spec section 21/17
    # requires them measured, not fabricated) so they legitimately vary
    # between runs; determinism applies to the prediction content itself.
    da.pop("metrics"), db.pop("metrics")
    assert da == db
