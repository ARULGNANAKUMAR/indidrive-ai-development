import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))

from core.perception.perception_types import Position3D, SourceSensor
from core.fusion.fusion_types import FusedObject, FusedWorldState, FusionMode
from core.prediction.prediction_engine import PredictionEngine
from core.prediction.hypothesis_engine import HypothesisEngine
from core.prediction.hypothesis_types import BehaviourType


def _obj(track_id, t, x, y, vx=1.0, vy=0.0, heading=0.0, object_class="car"):
    return FusedObject(
        fused_object_id=f"fused_{track_id}", object_class=object_class, class_confidence=0.9,
        position_3d=Position3D(x, y, 0.0), velocity=(vx, vy, 0.0),
        dimensions=None, heading=heading, distance=10.0, bbox_2d=None,
        source_sensors=frozenset({SourceSensor.CAMERA}),
        position_confidence=0.9, existence_probability=0.9, track_id=track_id, timestamp=t,
    )


def _world(objects, t):
    return FusedWorldState(timestamp=t, frame_id=1, fusion_mode=FusionMode.SINGLE_SENSOR, objects=objects)


def test_multiple_objects_get_independent_hypothesis_sets():
    engine = PredictionEngine()
    hyp_engine = HypothesisEngine()
    objs = [
        _obj("car1", 1.0, 0.0, 0.0, vx=5.0),
        _obj("car2", 1.0, 50.0, 0.0, vx=-5.0),
        _obj("ped1", 1.0, 20.0, 5.0, vx=1.0, object_class="pedestrian"),
    ]
    out = engine.process(_world(objs, 1.0))
    result = hyp_engine.process(out, history=engine._history)
    assert set(result.tracks.keys()) == {"car1", "car2", "ped1"}


def test_multi_object_zero_velocity_objects_are_stable():
    engine = PredictionEngine()
    hyp_engine = HypothesisEngine()
    objs = [_obj("still1", 1.0, 0.0, 0.0, vx=0.0, vy=0.0), _obj("still2", 1.0, 5.0, 5.0, vx=0.0, vy=0.0)]
    out = engine.process(_world(objs, 1.0))
    result = hyp_engine.process(out, history=engine._history)
    assert all(result.tracks[tid].is_stable for tid in ("still1", "still2"))


def test_multi_object_empty_world_yields_no_tracks():
    engine = PredictionEngine()
    hyp_engine = HypothesisEngine()
    out = engine.process(_world([], 1.0))
    result = hyp_engine.process(out, history=engine._history)
    assert result.tracks == {}


def test_multi_object_hypotheses_do_not_cross_contaminate_track_ids():
    engine = PredictionEngine()
    hyp_engine = HypothesisEngine()
    objs = [_obj("left_car", 1.0, 0.0, 0.0, vx=8.0, heading=0.0)]
    # Give it a nonzero heading change across two cycles to induce turning.
    engine.process(_world(objs, 1.0))
    out = engine.process(_world(
        [_obj("left_car", 2.0, 4.0, 1.0, vx=8.0, vy=1.0, heading=0.3)], 2.0
    ))
    result = hyp_engine.process(out, history=engine._history)
    hs = result.tracks["left_car"]
    assert all(h.track_id == "left_car" for h in hs.hypotheses)
