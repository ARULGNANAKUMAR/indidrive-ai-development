import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))

from core.prediction.prediction_types import MotionState, ModelType
from core.prediction.hypothesis_types import BehaviourType
from core.prediction.hypothesis_generator import HypothesisGenerator

HORIZONS = (0.5, 1.0, 2.0)


def _steady_state():
    return MotionState(
        x=0.0, y=0.0, z=0.0, vx=6.0, vy=0.0, vz=0.0, ax=0.0, ay=0.0, az=0.0,
        yaw=0.0, yaw_rate=0.0, speed=6.0, heading=0.0, timestamp=1.0,
    )


def test_stable_car_takes_fast_path_single_hypothesis():
    gen = HypothesisGenerator()
    hs = gen.generate(
        track_id="stable1", object_type="car", current_state=_steady_state(),
        selected_model=ModelType.CV, horizons_s=HORIZONS,
    )
    assert hs.is_stable is True
    assert len(hs.hypotheses) == 1


def test_fast_path_hypothesis_is_straight_with_full_probability():
    gen = HypothesisGenerator()
    hs = gen.generate(
        track_id="stable2", object_type="car", current_state=_steady_state(),
        selected_model=ModelType.CV, horizons_s=HORIZONS,
    )
    hyp = hs.hypotheses[0]
    assert hyp.behaviour == BehaviourType.STRAIGHT
    assert hyp.probability == 1.0


def test_fast_path_trajectory_matches_configured_horizons():
    gen = HypothesisGenerator()
    hs = gen.generate(
        track_id="stable3", object_type="car", current_state=_steady_state(),
        selected_model=ModelType.CV, horizons_s=HORIZONS,
    )
    assert tuple(p.horizon_s for p in hs.hypotheses[0].trajectory) == HORIZONS


def test_slightly_below_threshold_yaw_rate_still_stable():
    gen = HypothesisGenerator()
    state = MotionState(
        x=0.0, y=0.0, z=0.0, vx=6.0, vy=0.0, vz=0.0, ax=0.0, ay=0.0, az=0.0,
        yaw=0.0, yaw_rate=0.01, speed=6.0, heading=0.0, timestamp=1.0,
    )
    hs = gen.generate(
        track_id="stable4", object_type="car", current_state=state,
        selected_model=ModelType.CV, horizons_s=HORIZONS,
    )
    assert hs.is_stable is True
