import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))

from core.perception.perception_types import Position3D, SourceSensor
from core.fusion.fusion_types import FusedObject, FusedWorldState, FusionMode
from core.prediction.phase4c_pipeline import Phase4CPipeline
from core.prediction.object_behaviour import get_profile, clamp_yaw_rate_for_class
from core.prediction.uncertainty_engine import UncertaintyFactors, compute_uncertainty


def _obj(track_id, t, x, y, vx=5.0, vy=0.0, heading=0.0, cls="bus"):
    return FusedObject(
        fused_object_id=f"f_{track_id}", object_class=cls, class_confidence=0.9,
        position_3d=Position3D(x, y, 0.0), velocity=(vx, vy, 0.0),
        dimensions=None, heading=heading, distance=15.0, bbox_2d=None,
        source_sensors=frozenset({SourceSensor.CAMERA, SourceSensor.LIDAR, SourceSensor.RADAR}),
        position_confidence=0.9, existence_probability=0.9, quality=0.9,
        track_id=track_id, timestamp=t,
    )


def _world(objects, t, mode=FusionMode.FULL_FUSION):
    return FusedWorldState(timestamp=t, frame_id=1, fusion_mode=mode, objects=objects)


def test_bus_and_truck_are_less_agile_than_car():
    car = get_profile("car")
    bus = get_profile("bus")
    truck = get_profile("truck")
    assert bus.agility < car.agility
    assert truck.agility < car.agility
    assert bus.max_yaw_rate < car.max_yaw_rate
    assert truck.max_yaw_rate < car.max_yaw_rate


def test_bus_lateral_uncertainty_lower_than_car_reflecting_movement_continuity():
    car = get_profile("car")
    bus = get_profile("bus")
    assert bus.lateral_uncertainty_factor < car.lateral_uncertainty_factor


def test_bus_yaw_rate_clamped_to_smooth_turning():
    noisy_measurement = 2.5  # rad/s -- not physically plausible for a bus
    clamped = clamp_yaw_rate_for_class("bus", noisy_measurement)
    assert clamped < noisy_measurement
    assert clamped == get_profile("bus").max_yaw_rate


def test_tractor_supports_low_speed_irregular_movement():
    tractor = get_profile("tractor")
    car = get_profile("car")
    # Irregular movement -> more lateral/longitudinal uncertainty than a car...
    assert tractor.lateral_uncertainty_factor > car.lateral_uncertainty_factor
    assert tractor.longitudinal_uncertainty_factor > car.longitudinal_uncertainty_factor
    # ...but not as agile turning as a two-wheeler.
    moto = get_profile("motorcycle")
    assert tractor.agility < moto.agility


def test_bus_sigma_lower_than_motorcycle_sigma_same_conditions():
    common = dict(horizon_s=2.0, base_sigma=1.0, sensor_quality=None, track_age_cycles=5)
    bus_result = compute_uncertainty(UncertaintyFactors(object_type="bus", **common))
    moto_result = compute_uncertainty(UncertaintyFactors(object_type="motorcycle", **common))
    assert bus_result.sigma_x < moto_result.sigma_x


def test_bus_trajectory_holds_continuity_across_cycles():
    pipe = Phase4CPipeline()
    t = 1.0
    last = None
    for i in range(4):
        o = _obj("bus_1", t, i * 5.0, 0.0, vx=5.0, vy=0.0, heading=0.0, cls="bus")
        out = pipe.process(_world([o], t))
        last = out
        t += 0.5
    p = next(o for o in last.objects if o.track_id == "bus_1")
    assert p.behaviour_class.value == "BUS"
    assert p.predicted.lifecycle_state.value in ("NEW", "ACTIVE")
