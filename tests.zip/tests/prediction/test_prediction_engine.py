import math
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))

from core.perception.perception_types import Position3D, SourceSensor, HealthState
from core.fusion.fusion_types import FusedObject, FusedWorldState, FusionMode
from core.prediction.prediction_engine import PredictionEngine
from core.prediction.prediction_types import ModelType, TrackLifecycleState


def _obj(track_id, t, x, y, vx=1.0, vy=0.0, heading=0.0):
    return FusedObject(
        fused_object_id=f"fused_{track_id}", object_class="car", class_confidence=0.9,
        position_3d=Position3D(x, y, 0.0), velocity=(vx, vy, 0.0),
        dimensions=None, heading=heading, distance=10.0, bbox_2d=None,
        source_sensors=frozenset({SourceSensor.CAMERA}),
        position_confidence=0.9, existence_probability=0.9, track_id=track_id, timestamp=t,
    )


def _world(objects, t):
    return FusedWorldState(timestamp=t, frame_id=1, fusion_mode=FusionMode.SINGLE_SENSOR, objects=objects)


def test_engine_produces_prediction_for_stationary_vehicle():
    engine = PredictionEngine()
    obj = _obj("101", 1.0, 5.0, 5.0, vx=0.0, vy=0.0)
    out = engine.process(_world([obj], 1.0))
    p = out.objects[0]
    assert p.selected_model == ModelType.CV
    assert all(math.isclose(pt.x, 5.0, abs_tol=1e-6) for pt in p.trajectory)


def test_engine_produces_prediction_for_moving_vehicle():
    engine = PredictionEngine()
    obj = _obj("101", 1.0, 0.0, 0.0, vx=4.0, vy=0.0)
    out = engine.process(_world([obj], 1.0))
    p = out.objects[0]
    assert p.trajectory[-1].x > p.trajectory[0].x


def test_engine_handles_multiple_tracks_independently():
    engine = PredictionEngine()
    a = _obj("A", 1.0, 0.0, 0.0, vx=1.0)
    b = _obj("B", 1.0, 100.0, 100.0, vx=-1.0)
    out = engine.process(_world([a, b], 1.0))
    ids = {p.track_id for p in out.objects}
    assert ids == {"A", "B"}


def test_engine_creates_new_track_on_first_sighting():
    engine = PredictionEngine()
    obj = _obj("new_track", 1.0, 0.0, 0.0)
    out = engine.process(_world([obj], 1.0))
    assert out.objects[0].lifecycle_state == TrackLifecycleState.NEW


def test_engine_track_loses_and_recovers_across_cycles():
    engine = PredictionEngine()
    # Cycle 1 & 2: track seen -> becomes ACTIVE.
    engine.process(_world([_obj("101", 1.0, 0.0, 0.0)], 1.0))
    engine.process(_world([_obj("101", 2.0, 1.0, 0.0)], 2.0))
    # Cycle 3: track missing entirely this frame (temporary loss).
    engine.process(_world([], 3.0))
    # Cycle 4: track reappears.
    out = engine.process(_world([_obj("101", 4.0, 3.0, 0.0)], 4.0))
    assert out.objects[0].track_id == "101"
    assert out.objects[0].lifecycle_state == TrackLifecycleState.ACTIVE


def test_engine_track_expires_after_prolonged_absence():
    engine = PredictionEngine()
    engine.process(_world([_obj("101", 1.0, 0.0, 0.0)], 1.0))
    # Enough consecutive empty cycles to exceed default delete_after_misses.
    for i in range(2, 15):
        engine.process(_world([], float(i)))
    assert "101" not in engine._lifecycle.active_track_ids()
    assert "101" not in engine._filters


def test_engine_metrics_are_measured_not_fabricated():
    engine = PredictionEngine()
    obj = _obj("101", 1.0, 0.0, 0.0)
    out = engine.process(_world([obj], 1.0))
    assert out.metrics.prediction_latency_ms >= 0.0
    assert out.metrics.prediction_latency_ms < 1000.0  # sanity bound, not a fabricated constant


def test_engine_healthy_when_all_objects_valid():
    engine = PredictionEngine()
    obj = _obj("101", 1.0, 0.0, 0.0)
    out = engine.process(_world([obj], 1.0))
    assert out.prediction_health == HealthState.HEALTHY
