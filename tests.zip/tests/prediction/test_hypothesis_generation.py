import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))

from core.prediction.prediction_types import MotionState, ModelType
from core.prediction.hypothesis_types import BehaviourType
from core.prediction.hypothesis_generator import HypothesisGenerator

HORIZONS = (0.5, 1.0, 2.0)


def _state(vx=5.0, vy=0.0, ax=0.0, ay=0.0, yaw_rate=0.0, heading=0.0, speed=None):
    return MotionState(
        x=0.0, y=0.0, z=0.0, vx=vx, vy=vy, vz=0.0, ax=ax, ay=ay, az=0.0,
        yaw=heading, yaw_rate=yaw_rate, speed=speed if speed is not None else vx,
        heading=heading, timestamp=1.0,
    )


def test_generate_stable_object_yields_single_straight_hypothesis():
    gen = HypothesisGenerator()
    hs = gen.generate(
        track_id="t1", object_type="car", current_state=_state(),
        selected_model=ModelType.CV, horizons_s=HORIZONS,
    )
    assert hs.is_stable is True
    assert len(hs.hypotheses) == 1
    assert hs.hypotheses[0].behaviour == BehaviourType.STRAIGHT
    assert hs.hypotheses[0].probability == 1.0


def test_generate_turning_car_yields_left_hypothesis():
    gen = HypothesisGenerator()
    hs = gen.generate(
        track_id="t2", object_type="car", current_state=_state(vx=8.0, yaw_rate=0.6),
        selected_model=ModelType.CTRV, horizons_s=HORIZONS,
    )
    assert hs.is_stable is False
    behaviours = {h.behaviour for h in hs.hypotheses}
    assert BehaviourType.LEFT in behaviours


def test_generate_accelerating_car_yields_acceleration_hypothesis():
    gen = HypothesisGenerator()
    hs = gen.generate(
        track_id="t3", object_type="car", current_state=_state(vx=8.0, ax=3.0),
        selected_model=ModelType.CA, horizons_s=HORIZONS,
    )
    behaviours = {h.behaviour for h in hs.hypotheses}
    assert BehaviourType.ACCELERATION in behaviours


def test_generate_braking_car_yields_braking_hypothesis():
    gen = HypothesisGenerator()
    hs = gen.generate(
        track_id="t4", object_type="car", current_state=_state(vx=8.0, ax=-4.0),
        selected_model=ModelType.CA, horizons_s=HORIZONS,
    )
    behaviours = {h.behaviour for h in hs.hypotheses}
    assert BehaviourType.BRAKING in behaviours


def test_generate_lateral_motorcycle_yields_turn_hypothesis_from_lateral_velocity():
    gen = HypothesisGenerator()
    # High lateral (body-frame) velocity but yaw_rate near zero -- e.g. a
    # motorcycle drifting sideways within its own lane.
    hs = gen.generate(
        track_id="m1", object_type="motorcycle",
        current_state=_state(vx=6.0, vy=1.0, yaw_rate=0.0), selected_model=ModelType.CV,
        horizons_s=HORIZONS,
    )
    behaviours = {h.behaviour for h in hs.hypotheses}
    assert BehaviourType.LEFT in behaviours


def test_generate_hypotheses_use_configured_horizons():
    gen = HypothesisGenerator()
    hs = gen.generate(
        track_id="t5", object_type="car", current_state=_state(vx=8.0, yaw_rate=0.6),
        selected_model=ModelType.CTRV, horizons_s=HORIZONS,
    )
    for hyp in hs.hypotheses:
        assert tuple(p.horizon_s for p in hyp.trajectory) == HORIZONS


def test_generate_zero_velocity_object_is_stable():
    gen = HypothesisGenerator()
    hs = gen.generate(
        track_id="t6", object_type="car", current_state=_state(vx=0.0, vy=0.0, speed=0.0),
        selected_model=ModelType.CV, horizons_s=HORIZONS,
    )
    assert hs.is_stable is True
    assert hs.hypotheses[0].behaviour == BehaviourType.STRAIGHT


def test_generate_invalid_state_returns_no_hypotheses():
    gen = HypothesisGenerator()
    bad_state = _state(vx=float("nan"))
    hs = gen.generate(
        track_id="t7", object_type="car", current_state=bad_state,
        selected_model=ModelType.CV, horizons_s=HORIZONS,
    )
    assert hs.hypotheses == []


def test_generate_stable_object_does_not_generate_extra_hypotheses():
    gen = HypothesisGenerator()
    hs = gen.generate(
        track_id="t8", object_type="car", current_state=_state(vx=10.0),
        selected_model=ModelType.CV, horizons_s=HORIZONS,
    )
    assert len(hs.hypotheses) == 1
