import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))

from core.perception.perception_types import Position3D, SourceSensor
from core.fusion.fusion_types import FusedObject, FusedWorldState, FusionMode
from core.prediction.phase4c_pipeline import Phase4CPipeline
from core.prediction.object_behaviour import get_profile
from core.prediction.uncertainty_engine import UncertaintyFactors, compute_uncertainty
from core.prediction.path_selector import PredictionPath


def _obj(track_id, t, x, y, vx=0.0, vy=0.0, heading=0.0, cls="pedestrian"):
    return FusedObject(
        fused_object_id=f"f_{track_id}", object_class=cls, class_confidence=0.9,
        position_3d=Position3D(x, y, 0.0), velocity=(vx, vy, 0.0),
        dimensions=None, heading=heading, distance=8.0, bbox_2d=None,
        source_sensors=frozenset({SourceSensor.CAMERA}),
        position_confidence=0.8, existence_probability=0.8, quality=0.75,
        track_id=track_id, timestamp=t,
    )


def _world(objects, t, mode=FusionMode.SINGLE_SENSOR):
    return FusedWorldState(timestamp=t, frame_id=1, fusion_mode=mode, objects=objects)


def test_pedestrian_profile_has_highest_direction_uncertainty_among_common_classes():
    ped = get_profile("pedestrian")
    car = get_profile("car")
    moto = get_profile("motorcycle")
    assert ped.direction_uncertainty_factor > car.direction_uncertainty_factor
    assert ped.direction_uncertainty_factor >= moto.direction_uncertainty_factor
    assert ped.sudden_entry_prone is True


def test_pedestrian_sigma_grows_more_than_car_for_same_conditions():
    common = dict(horizon_s=1.5, base_sigma=0.5, sensor_quality=None, track_age_cycles=4)
    ped = compute_uncertainty(UncertaintyFactors(object_type="pedestrian", **common))
    car = compute_uncertainty(UncertaintyFactors(object_type="car", **common))
    assert ped.sigma_x > car.sigma_x


def test_pedestrian_lateral_crossing_scenario_is_valid():
    """A pedestrian walking laterally across the road (crossing) --
    prediction must still produce a usable trajectory even with no
    lane markings assumed."""
    pipe = Phase4CPipeline()
    o = _obj("ped_1", 1.0, 2.0, 0.0, vx=0.0, vy=1.2, heading=1.5708)
    out = pipe.process(_world([o], 1.0))
    p = out.objects[0]
    assert p.behaviour_class.value == "PEDESTRIAN"
    assert p.predicted.trajectory
    assert p.predicted.trajectory[-1].y > p.predicted.trajectory[0].y


def test_pedestrian_sudden_road_entry_routes_to_deep_path():
    """Pedestrian suddenly stepping into the road from stationary --
    a sharp velocity/heading change across cycles."""
    pipe = Phase4CPipeline()
    t = 1.0
    for _ in range(3):
        o = _obj("ped_2", t, 5.0, -2.0, vx=0.0, vy=0.0, heading=0.0)
        out = pipe.process(_world([o], t))
        t += 0.2

    # Sudden entry into the road: rapid lateral velocity onset.
    o = _obj("ped_2", t, 5.0, -1.5, vx=0.2, vy=1.8, heading=1.4)
    out = pipe.process(_world([o], t))
    result = next(p for p in out.objects if p.track_id == "ped_2")
    assert result.prediction_path == PredictionPath.DEEP
