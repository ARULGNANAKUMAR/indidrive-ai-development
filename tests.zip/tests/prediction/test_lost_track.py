import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))

from core.perception.perception_types import Position3D, SourceSensor
from core.fusion.fusion_types import FusedObject, FusedWorldState, FusionMode
from core.prediction.phase4c_pipeline import Phase4CPipeline
from core.prediction.prediction_types import TrackLifecycleState


def _obj(track_id, t, x, y, vx=3.0, vy=0.0, heading=0.0, cls="car"):
    return FusedObject(
        fused_object_id=f"f_{track_id}", object_class=cls, class_confidence=0.9,
        position_3d=Position3D(x, y, 0.0), velocity=(vx, vy, 0.0),
        dimensions=None, heading=heading, distance=10.0, bbox_2d=None,
        source_sensors=frozenset({SourceSensor.CAMERA, SourceSensor.LIDAR}),
        position_confidence=0.85, existence_probability=0.85, quality=0.8,
        track_id=track_id, timestamp=t,
    )


def _world(objects, t, mode=FusionMode.PARTIAL_FUSION):
    return FusedWorldState(timestamp=t, frame_id=1, fusion_mode=mode, objects=objects)


def _establish_active_track(pipe, track_id, t0=1.0, dt=0.2, hits=3):
    t = t0
    for _ in range(hits):
        o = _obj(track_id, t, t * 2.0, 0.0)
        pipe.process(_world([o], t))
        t += dt
    return t


def test_lost_track_continues_short_term_prediction():
    pipe = Phase4CPipeline()
    t = _establish_active_track(pipe, "car_lost_1")

    # One measurement is missed -> the empty cycle should not immediately
    # drop the track; it should still appear (coasted or still active).
    t += 0.2
    out = pipe.process(_world([], t))
    matches = [o for o in out.objects if o.track_id == "car_lost_1"]
    assert matches, "track should still be predicted despite a missed measurement"


def test_lost_track_uncertainty_grows_with_time_since_last_measurement():
    pipe = Phase4CPipeline()
    t = _establish_active_track(pipe, "car_lost_2")

    sigmas = []
    for _ in range(4):
        t += 0.3
        out = pipe.process(_world([], t))
        match = next((o for o in out.objects if o.track_id == "car_lost_2"), None)
        if match is not None:
            sigmas.append(match.predicted.uncertainty.get("sigma_x", 0.0))

    assert len(sigmas) >= 2
    # Uncertainty should grow (or at worst hold) the longer the track goes
    # without a real measurement -- never shrink while coasting.
    assert all(sigmas[i] <= sigmas[i + 1] for i in range(len(sigmas) - 1))


def test_lost_track_eventually_marked_stale_or_deleted():
    pipe = Phase4CPipeline()
    _establish_active_track(pipe, "car_lost_3")

    t = 100.0
    states = []
    for _ in range(12):
        out = pipe.process(_world([], t))
        state = pipe._engine.lifecycle.get_state("car_lost_3")
        states.append(state)
        t += 0.2

    assert TrackLifecycleState.STALE in states or TrackLifecycleState.DELETED in states


def test_coasted_object_is_flagged_as_coasted():
    pipe = Phase4CPipeline()
    t = _establish_active_track(pipe, "car_lost_4")
    t += 0.3
    out = pipe.process(_world([], t))
    match = next((o for o in out.objects if o.track_id == "car_lost_4"), None)
    assert match is not None
    assert match.coasted is True
