import math
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))

from core.prediction.track_history import TrackHistoryManager


def _add(mgr, track_id, t, x, y, vx=1.0, vy=0.0, heading=0.0):
    return mgr.add_measurement(
        track_id, timestamp=t, x=x, y=y, z=0.0, vx=vx, vy=vy, vz=0.0,
        heading=heading, confidence=0.9,
    )


def test_history_starts_empty():
    mgr = TrackHistoryManager()
    assert mgr.get_history("101") == []
    assert mgr.has_track("101") is False


def test_history_records_measurements_in_order():
    mgr = TrackHistoryManager()
    for i in range(5):
        _add(mgr, "101", float(i), float(i), 0.0)
    hist = mgr.get_history("101")
    assert len(hist) == 5
    assert [e.x for e in hist] == [0.0, 1.0, 2.0, 3.0, 4.0]


def test_history_is_bounded_and_never_grows_unbounded():
    mgr = TrackHistoryManager(max_history=5)
    for i in range(50):
        _add(mgr, "101", float(i), float(i), 0.0)
    assert len(mgr.get_history("101")) == 5


def test_history_derives_acceleration_from_velocity_delta():
    mgr = TrackHistoryManager()
    _add(mgr, "101", 0.0, 0.0, 0.0, vx=1.0)
    entry = _add(mgr, "101", 1.0, 1.0, 0.0, vx=3.0)
    assert math.isclose(entry.ax, 2.0)


def test_history_first_entry_has_zero_derived_acceleration():
    mgr = TrackHistoryManager()
    entry = _add(mgr, "101", 0.0, 0.0, 0.0, vx=5.0)
    assert entry.ax == 0.0
    assert entry.yaw_rate == 0.0


def test_history_derives_yaw_rate_from_heading_delta():
    mgr = TrackHistoryManager()
    _add(mgr, "101", 0.0, 0.0, 0.0, heading=0.0)
    entry = _add(mgr, "101", 1.0, 1.0, 0.0, heading=0.5)
    assert math.isclose(entry.yaw_rate, 0.5)


def test_history_multiple_tracks_are_independent():
    mgr = TrackHistoryManager()
    _add(mgr, "101", 0.0, 0.0, 0.0)
    _add(mgr, "202", 0.0, 100.0, 100.0)
    assert mgr.get_latest("101").x == 0.0
    assert mgr.get_latest("202").x == 100.0


def test_history_remove_track_releases_memory():
    mgr = TrackHistoryManager()
    _add(mgr, "101", 0.0, 0.0, 0.0)
    mgr.remove_track("101")
    assert mgr.has_track("101") is False
    assert mgr.get_history("101") == []


def test_history_reset_clears_all_tracks():
    mgr = TrackHistoryManager()
    _add(mgr, "101", 0.0, 0.0, 0.0)
    _add(mgr, "202", 0.0, 0.0, 0.0)
    mgr.reset()
    assert mgr.active_track_ids() == []
