import math
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))

from core.prediction.prediction_types import (
    MotionState, PredictedState, PredictedObject, PredictionMetrics,
    PredictedWorldState, ModelType, TrackLifecycleState, NOT_AVAILABLE,
)
from core.perception.perception_types import HealthState


def _state(**overrides):
    base = dict(x=1.0, y=2.0, z=0.0, vx=1.0, vy=0.0, vz=0.0,
                ax=0.0, ay=0.0, az=0.0, yaw=0.0, yaw_rate=0.0,
                speed=1.0, heading=0.0, timestamp=10.0)
    base.update(overrides)
    return MotionState(**base)


def test_motion_state_has_all_required_fields():
    s = _state()
    d = s.to_dict()
    for field in ("x", "y", "z", "vx", "vy", "vz", "ax", "ay", "az",
                  "yaw", "yaw_rate", "speed", "heading", "timestamp"):
        assert field in d


def test_motion_state_is_valid_for_finite_values():
    assert _state().is_valid() is True


def test_motion_state_is_invalid_for_nan():
    assert _state(x=math.nan).is_valid() is False


def test_motion_state_is_invalid_for_inf():
    assert _state(vy=math.inf).is_valid() is False


def test_predicted_state_to_dict_reports_not_available_for_missing_covariance():
    ps = PredictedState(timestamp=1.0, x=0, y=0, z=0, vx=0, vy=0, vz=0, yaw=0, speed=0, horizon_s=0.5)
    d = ps.to_dict()
    assert d["covariance"] == NOT_AVAILABLE
    assert d["horizon_s"] == 0.5


def test_predicted_object_to_dict_shape():
    obj = PredictedObject(
        track_id="track_1", object_type="car", current_state=_state(),
        trajectory=[PredictedState(timestamp=1.0, x=0, y=0, z=0, vx=0, vy=0, vz=0, yaw=0, speed=0)],
        prediction_confidence=0.8, uncertainty={"sigma_x": 0.1}, selected_model=ModelType.CV,
        lifecycle_state=TrackLifecycleState.ACTIVE,
    )
    d = obj.to_dict()
    assert d["track_id"] == "track_1"
    assert d["selected_model"] == "CV"
    assert d["lifecycle_state"] == "ACTIVE"
    assert len(d["trajectory"]) == 1


def test_predicted_object_uncertainty_reports_not_available_when_empty():
    obj = PredictedObject(track_id="t", object_type="car", current_state=_state())
    assert obj.to_dict()["uncertainty"] == NOT_AVAILABLE


def test_prediction_metrics_to_dict_rounds_values():
    m = PredictionMetrics(prediction_latency_ms=1.23456)
    assert m.to_dict()["prediction_latency_ms"] == 1.235


def test_predicted_world_state_defaults_to_not_configured():
    ws = PredictedWorldState(timestamp=1.0, frame_id=1)
    assert ws.prediction_health == HealthState.NOT_CONFIGURED
    d = ws.to_dict()
    assert d["objects"] == []
    assert d["prediction_health"] == "NOT_CONFIGURED"


def test_model_type_enum_values():
    assert ModelType.CV.value == "CV"
    assert ModelType.CA.value == "CA"
    assert ModelType.CTRV.value == "CTRV"


def test_track_lifecycle_state_enum_values():
    assert TrackLifecycleState.NEW.value == "NEW"
    assert TrackLifecycleState.ACTIVE.value == "ACTIVE"
    assert TrackLifecycleState.TEMPORARILY_LOST.value == "TEMPORARILY_LOST"
    assert TrackLifecycleState.STALE.value == "STALE"
    assert TrackLifecycleState.DELETED.value == "DELETED"
