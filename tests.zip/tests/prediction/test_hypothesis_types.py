import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))

from core.prediction.hypothesis_types import BehaviourType, TrajectoryHypothesis, TrackHypothesisSet
from core.prediction.prediction_types import ModelType, PredictedState


def _pred_state(h):
    return PredictedState(timestamp=1.0 + h, x=h, y=0.0, z=0.0, vx=1.0, vy=0.0, vz=0.0, yaw=0.0, speed=1.0, horizon_s=h)


def test_behaviour_type_has_five_members():
    assert {b.value for b in BehaviourType} == {"STRAIGHT", "LEFT", "RIGHT", "BRAKING", "ACCELERATION"}


def test_trajectory_hypothesis_holds_required_fields():
    hyp = TrajectoryHypothesis(
        track_id="t1", model=ModelType.CV, behaviour=BehaviourType.STRAIGHT,
        probability=1.0, confidence=0.9, trajectory=[_pred_state(0.5)],
        uncertainty={"sigma_x": 0.1},
    )
    d = hyp.to_dict()
    assert d["track_id"] == "t1"
    assert d["model"] == "CV"
    assert d["behaviour"] == "STRAIGHT"
    assert d["probability"] == 1.0
    assert d["trajectory"][0]["horizon_s"] == 0.5


def test_track_hypothesis_set_best_returns_highest_probability():
    a = TrajectoryHypothesis(track_id="t1", model=ModelType.CV, behaviour=BehaviourType.STRAIGHT, probability=0.3)
    b = TrajectoryHypothesis(track_id="t1", model=ModelType.CTRV, behaviour=BehaviourType.LEFT, probability=0.7)
    hs = TrackHypothesisSet(track_id="t1", object_type="car", is_stable=False, hypotheses=[a, b])
    assert hs.best() is b


def test_track_hypothesis_set_best_none_when_empty():
    hs = TrackHypothesisSet(track_id="t1", object_type="car", is_stable=True, hypotheses=[])
    assert hs.best() is None


def test_track_hypothesis_set_to_dict_roundtrips_fields():
    hyp = TrajectoryHypothesis(track_id="t2", model=ModelType.CA, behaviour=BehaviourType.BRAKING, probability=1.0)
    hs = TrackHypothesisSet(track_id="t2", object_type="truck", is_stable=False, hypotheses=[hyp])
    d = hs.to_dict()
    assert d["track_id"] == "t2"
    assert d["is_stable"] is False
    assert len(d["hypotheses"]) == 1
