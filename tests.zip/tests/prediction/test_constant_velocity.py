import math
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))

from core.prediction.prediction_types import MotionState
from core.prediction.motion_models import constant_velocity


def _state(**overrides):
    base = dict(x=0.0, y=0.0, z=0.0, vx=2.0, vy=1.0, vz=0.0,
                ax=0.0, ay=0.0, az=0.0, yaw=0.3, yaw_rate=0.0,
                speed=math.hypot(2.0, 1.0), heading=0.3, timestamp=5.0)
    base.update(overrides)
    return MotionState(**base)


def test_cv_moving_object_moves_linearly():
    s = _state()
    future = constant_velocity(s, 2.0)
    assert math.isclose(future.x, 4.0)
    assert math.isclose(future.y, 2.0)
    assert math.isclose(future.timestamp, 7.0)


def test_cv_stationary_object_does_not_move():
    s = _state(vx=0.0, vy=0.0, speed=0.0)
    future = constant_velocity(s, 3.0)
    assert future.x == s.x
    assert future.y == s.y


def test_cv_velocity_unchanged():
    s = _state()
    future = constant_velocity(s, 1.0)
    assert future.vx == s.vx
    assert future.vy == s.vy


def test_cv_zero_dt_is_identity_position():
    s = _state()
    future = constant_velocity(s, 0.0)
    assert future.x == s.x
    assert future.y == s.y


def test_cv_negative_dt_is_treated_as_zero():
    s = _state()
    future = constant_velocity(s, -5.0)
    assert future.x == s.x
    assert future.y == s.y


def test_cv_speed_matches_velocity_magnitude():
    s = _state(vx=3.0, vy=4.0)
    future = constant_velocity(s, 1.0)
    assert math.isclose(future.speed, 5.0)
