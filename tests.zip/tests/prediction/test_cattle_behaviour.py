import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))

from core.perception.perception_types import Position3D, SourceSensor
from core.fusion.fusion_types import FusedObject, FusedWorldState, FusionMode
from core.prediction.phase4c_pipeline import Phase4CPipeline
from core.prediction.object_behaviour import get_profile, ObjectBehaviourClass
from core.prediction.uncertainty_engine import UncertaintyFactors, compute_uncertainty
from core.prediction.path_selector import PredictionPath


def _obj(track_id, t, x, y, vx=0.3, vy=0.0, heading=0.0, cls="cow"):
    return FusedObject(
        fused_object_id=f"f_{track_id}", object_class=cls, class_confidence=0.8,
        position_3d=Position3D(x, y, 0.0), velocity=(vx, vy, 0.0),
        dimensions=None, heading=heading, distance=12.0, bbox_2d=None,
        source_sensors=frozenset({SourceSensor.CAMERA}),
        position_confidence=0.7, existence_probability=0.7, quality=0.65,
        track_id=track_id, timestamp=t,
    )


def _world(objects, t, mode=FusionMode.SINGLE_SENSOR):
    return FusedWorldState(timestamp=t, frame_id=1, fusion_mode=mode, objects=objects)


def test_cattle_has_broadest_uncertainty_of_all_classes():
    cattle = get_profile("cattle")
    all_others = [
        get_profile(c) for c in
        ["car", "motorcycle", "scooter", "auto_rickshaw", "bus", "truck", "tractor", "cycle", "pedestrian"]
    ]
    assert all(cattle.lateral_uncertainty_factor >= o.lateral_uncertainty_factor for o in all_others)
    assert all(cattle.direction_uncertainty_factor >= o.direction_uncertainty_factor for o in all_others)
    assert all(cattle.unpredictability >= o.unpredictability for o in all_others)


def test_cattle_aliases_all_resolve_to_same_profile():
    assert get_profile("cow") == get_profile("bull") == get_profile("buffalo") == get_profile("cattle")
    assert get_profile("cow").behaviour_class == ObjectBehaviourClass.CATTLE


def test_cattle_sigma_is_not_a_fixed_fake_value_it_scales_with_horizon():
    near = compute_uncertainty(UncertaintyFactors(object_type="cattle", horizon_s=0.25, base_sigma=0.5))
    far = compute_uncertainty(UncertaintyFactors(object_type="cattle", horizon_s=5.0, base_sigma=0.5))
    assert far.sigma_x > near.sigma_x
    assert far.sigma_x != near.sigma_x  # never identical/hardcoded


def test_cattle_crossing_road_always_routes_to_deep_path():
    pipe = Phase4CPipeline()
    o = _obj("cattle_1", 1.0, 4.0, 0.0, vx=0.4, vy=0.1, heading=0.2)
    out = pipe.process(_world([o], 1.0))
    p = out.objects[0]
    assert p.behaviour_class == ObjectBehaviourClass.CATTLE
    assert p.prediction_path == PredictionPath.DEEP
