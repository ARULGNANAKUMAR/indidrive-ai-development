import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))

from core.perception.perception_types import Position3D, SourceSensor
from core.fusion.fusion_types import FusedObject, FusedWorldState, FusionMode
from core.prediction.phase4c_pipeline import Phase4CPipeline
from core.prediction.path_selector import PathDecisionInputs, PredictionPath, select_path
from core.prediction.sensor_quality import SensorQuality


def test_stable_full_fusion_object_selects_fast_path():
    decision = select_path(PathDecisionInputs(
        is_stable=True, sensor_quality=SensorQuality.FULL_FUSION,
        lost_this_cycle=False, sudden_acceleration=False, sudden_braking=False,
        unpredictable_class=False,
    ))
    assert decision == PredictionPath.FAST


def test_unstable_object_always_selects_deep_path():
    decision = select_path(PathDecisionInputs(is_stable=False, sensor_quality=SensorQuality.FULL_FUSION))
    assert decision == PredictionPath.DEEP


def test_degraded_sensor_forces_deep_path_even_if_stable():
    decision = select_path(PathDecisionInputs(is_stable=True, sensor_quality=SensorQuality.LOW_CONFIDENCE))
    assert decision == PredictionPath.DEEP
    decision2 = select_path(PathDecisionInputs(is_stable=True, sensor_quality=SensorQuality.SINGLE_SENSOR))
    assert decision2 == PredictionPath.DEEP


def test_lost_track_forces_deep_path():
    decision = select_path(PathDecisionInputs(is_stable=True, sensor_quality=SensorQuality.FULL_FUSION, lost_this_cycle=True))
    assert decision == PredictionPath.DEEP


def test_sudden_acceleration_or_braking_forces_deep_path():
    accel = select_path(PathDecisionInputs(is_stable=True, sensor_quality=SensorQuality.FULL_FUSION, sudden_acceleration=True))
    brake = select_path(PathDecisionInputs(is_stable=True, sensor_quality=SensorQuality.FULL_FUSION, sudden_braking=True))
    assert accel == PredictionPath.DEEP
    assert brake == PredictionPath.DEEP


def test_unpredictable_class_forces_deep_path():
    decision = select_path(PathDecisionInputs(is_stable=True, sensor_quality=SensorQuality.FULL_FUSION, unpredictable_class=True))
    assert decision == PredictionPath.DEEP


def _obj(track_id, t, x, y, vx=3.0, vy=0.0, heading=0.0, cls="car", sensors=None, quality=0.9, pc=0.9):
    return FusedObject(
        fused_object_id=f"f_{track_id}", object_class=cls, class_confidence=0.9,
        position_3d=Position3D(x, y, 0.0), velocity=(vx, vy, 0.0),
        dimensions=None, heading=heading, distance=10.0, bbox_2d=None,
        source_sensors=sensors or frozenset({SourceSensor.CAMERA, SourceSensor.LIDAR, SourceSensor.RADAR}),
        position_confidence=pc, existence_probability=0.9, quality=quality,
        track_id=track_id, timestamp=t,
    )


def _world(objects, t, mode=FusionMode.FULL_FUSION):
    return FusedWorldState(timestamp=t, frame_id=1, fusion_mode=mode, objects=objects)


def test_pipeline_routes_stable_car_full_fusion_to_fast_path():
    pipe = Phase4CPipeline()
    t = 1.0
    out = None
    for i in range(3):
        o = _obj("car_stable", t, i * 1.0, 0.0, vx=5.0, vy=0.0)
        out = pipe.process(_world([o], t))
        t += 0.2
    p = next(x for x in out.objects if x.track_id == "car_stable")
    assert p.prediction_path == PredictionPath.FAST


def test_pipeline_routes_unstable_motorcycle_to_deep_path():
    pipe = Phase4CPipeline()
    t = 1.0
    out = None
    for i in range(3):
        o = _obj("moto_deep", t, i * 1.0, 0.0, vx=8.0, vy=0.0, cls="motorcycle")
        out = pipe.process(_world([o], t))
        t += 0.1
    # sharp swerve
    o = _obj("moto_deep", t, t, 0.5, vx=5.0, vy=5.0, cls="motorcycle")
    out = pipe.process(_world([o], t))
    p = next(x for x in out.objects if x.track_id == "moto_deep")
    assert p.prediction_path == PredictionPath.DEEP
