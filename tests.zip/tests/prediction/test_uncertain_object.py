import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))

from core.prediction.prediction_types import MotionState, ModelType
from core.prediction.hypothesis_types import BehaviourType
from core.prediction.hypothesis_generator import HypothesisGenerator

HORIZONS = (0.5, 1.0, 2.0)


def _state(vx=8.0, vy=0.0, ax=0.0, ay=0.0, yaw_rate=0.0, heading=0.0):
    return MotionState(
        x=0.0, y=0.0, z=0.0, vx=vx, vy=vy, vz=0.0, ax=ax, ay=ay, az=0.0,
        yaw=heading, yaw_rate=yaw_rate, speed=vx, heading=heading, timestamp=1.0,
    )


def test_unstable_object_yields_more_than_one_hypothesis():
    gen = HypothesisGenerator()
    hs = gen.generate(
        track_id="u1", object_type="car", current_state=_state(yaw_rate=0.5, ax=2.5),
        selected_model=ModelType.CTRV, horizons_s=HORIZONS,
    )
    assert hs.is_stable is False
    assert len(hs.hypotheses) > 1


def test_uncertain_object_hypotheses_carry_uncertainty():
    gen = HypothesisGenerator()
    hs = gen.generate(
        track_id="u2", object_type="car", current_state=_state(yaw_rate=0.6),
        selected_model=ModelType.CTRV, horizons_s=HORIZONS,
    )
    for hyp in hs.hypotheses:
        assert "sigma_x" in hyp.uncertainty
        assert hyp.uncertainty["sigma_x"] >= 0.0


def test_uncertain_object_highest_probability_matches_dominant_signal():
    gen = HypothesisGenerator()
    hs = gen.generate(
        track_id="u3", object_type="car", current_state=_state(yaw_rate=0.9),
        selected_model=ModelType.CTRV, horizons_s=HORIZONS,
    )
    best = hs.best()
    assert best.behaviour == BehaviourType.LEFT


def test_uncertain_object_hypothesis_count_capped():
    gen = HypothesisGenerator()
    hs = gen.generate(
        track_id="u4", object_type="pedestrian",
        current_state=_state(yaw_rate=0.5, ax=2.0, vy=1.0), selected_model=ModelType.CTRV,
        horizons_s=HORIZONS,
    )
    assert len(hs.hypotheses) <= gen.config.max_hypotheses
