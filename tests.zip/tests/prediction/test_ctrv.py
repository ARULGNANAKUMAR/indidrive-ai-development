import math
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))

from core.prediction.prediction_types import MotionState
from core.prediction.motion_models import constant_turn_rate_and_velocity, constant_velocity


def _state(**overrides):
    base = dict(x=0.0, y=0.0, z=0.0, vx=2.0, vy=0.0, vz=0.0,
                ax=0.0, ay=0.0, az=0.0, yaw=0.0, yaw_rate=0.5,
                speed=2.0, heading=0.0, timestamp=0.0)
    base.update(overrides)
    return MotionState(**base)


def test_ctrv_turning_object_changes_heading():
    s = _state(yaw_rate=0.5)
    future = constant_turn_rate_and_velocity(s, 1.0)
    assert not math.isclose(future.yaw, s.yaw)
    assert math.isclose(future.yaw, s.yaw + 0.5 * 1.0)


def test_ctrv_preserves_speed_magnitude():
    s = _state(yaw_rate=0.3)
    future = constant_turn_rate_and_velocity(s, 2.0)
    assert math.isclose(math.hypot(future.vx, future.vy), s.speed, rel_tol=1e-6)


def test_ctrv_zero_yaw_rate_matches_straight_line():
    s = _state(yaw_rate=0.0)
    ctrv_future = constant_turn_rate_and_velocity(s, 1.5)
    # For zero yaw rate CTRV must not divide by zero and must approximate
    # straight-line motion (same direction as heading).
    assert math.isfinite(ctrv_future.x)
    assert math.isfinite(ctrv_future.y)
    expected_x = s.x + s.speed * math.cos(s.yaw) * 1.5
    assert math.isclose(ctrv_future.x, expected_x, rel_tol=1e-6)


def test_ctrv_near_zero_yaw_rate_does_not_explode():
    s = _state(yaw_rate=1e-8)
    future = constant_turn_rate_and_velocity(s, 3.0)
    assert math.isfinite(future.x)
    assert math.isfinite(future.y)


def test_ctrv_zero_velocity_stays_in_place():
    s = _state(vx=0.0, vy=0.0, speed=0.0, yaw_rate=0.2)
    future = constant_turn_rate_and_velocity(s, 1.0)
    assert math.isclose(future.x, s.x, abs_tol=1e-9)
    assert math.isclose(future.y, s.y, abs_tol=1e-9)


def test_ctrv_negative_dt_is_treated_as_zero():
    s = _state()
    future = constant_turn_rate_and_velocity(s, -1.0)
    assert math.isclose(future.x, s.x)
    assert math.isclose(future.y, s.y)
