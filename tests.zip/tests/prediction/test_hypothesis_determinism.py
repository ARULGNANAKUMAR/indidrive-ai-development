import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))

from core.prediction.prediction_types import MotionState, ModelType
from core.prediction.hypothesis_generator import HypothesisGenerator

HORIZONS = (0.5, 1.0, 2.0)


def _state(vx=8.0, vy=0.5, ax=1.0, ay=0.0, yaw_rate=0.4, heading=0.1):
    return MotionState(
        x=1.0, y=2.0, z=0.0, vx=vx, vy=vy, vz=0.0, ax=ax, ay=ay, az=0.0,
        yaw=heading, yaw_rate=yaw_rate, speed=vx, heading=heading, timestamp=1.0,
    )


def test_repeated_generation_is_identical():
    gen = HypothesisGenerator()
    results = []
    for _ in range(10):
        hs = gen.generate(
            track_id="det1", object_type="car", current_state=_state(),
            selected_model=ModelType.CTRV, horizons_s=HORIZONS,
        )
        results.append(tuple((h.behaviour, round(h.probability, 9)) for h in hs.hypotheses))
    assert len(set(results)) == 1


def test_repeated_generation_across_separate_generator_instances():
    outputs = []
    for _ in range(5):
        gen = HypothesisGenerator()
        hs = gen.generate(
            track_id="det2", object_type="pedestrian", current_state=_state(yaw_rate=-0.6),
            selected_model=ModelType.CTRV, horizons_s=HORIZONS,
        )
        outputs.append(tuple((h.behaviour, round(h.probability, 9)) for h in hs.hypotheses))
    assert len(set(outputs)) == 1


def test_deterministic_trajectory_values():
    gen = HypothesisGenerator()
    hs1 = gen.generate(track_id="det3", object_type="car", current_state=_state(),
                        selected_model=ModelType.CTRV, horizons_s=HORIZONS)
    hs2 = gen.generate(track_id="det3", object_type="car", current_state=_state(),
                        selected_model=ModelType.CTRV, horizons_s=HORIZONS)
    for h1, h2 in zip(hs1.hypotheses, hs2.hypotheses):
        for p1, p2 in zip(h1.trajectory, h2.trajectory):
            assert p1.x == p2.x
            assert p1.y == p2.y
