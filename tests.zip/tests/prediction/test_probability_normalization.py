import math
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))

from core.prediction.prediction_types import MotionState, ModelType
from core.prediction.hypothesis_generator import HypothesisGenerator

HORIZONS = (0.5, 1.0)


def _state(vx=8.0, vy=0.0, ax=0.0, ay=0.0, yaw_rate=0.0, heading=0.0):
    return MotionState(
        x=0.0, y=0.0, z=0.0, vx=vx, vy=vy, vz=0.0, ax=ax, ay=ay, az=0.0,
        yaw=heading, yaw_rate=yaw_rate, speed=vx, heading=heading, timestamp=1.0,
    )


def test_probabilities_sum_to_one_for_unstable_object():
    gen = HypothesisGenerator()
    hs = gen.generate(
        track_id="t1", object_type="car", current_state=_state(yaw_rate=0.4, ax=2.0),
        selected_model=ModelType.CTRV, horizons_s=HORIZONS,
    )
    total = sum(h.probability for h in hs.hypotheses)
    assert math.isclose(total, 1.0, abs_tol=1e-6)


def test_single_hypothesis_probability_is_one():
    gen = HypothesisGenerator()
    hs = gen.generate(
        track_id="t2", object_type="car", current_state=_state(),
        selected_model=ModelType.CV, horizons_s=HORIZONS,
    )
    assert len(hs.hypotheses) == 1
    assert math.isclose(hs.hypotheses[0].probability, 1.0, abs_tol=1e-9)


def test_all_probabilities_non_negative():
    gen = HypothesisGenerator()
    hs = gen.generate(
        track_id="t3", object_type="car", current_state=_state(yaw_rate=-0.5, ax=-3.0),
        selected_model=ModelType.CTRV, horizons_s=HORIZONS,
    )
    assert all(h.probability >= 0.0 for h in hs.hypotheses)


def test_no_single_hypothesis_probability_exceeds_one():
    gen = HypothesisGenerator()
    hs = gen.generate(
        track_id="t4", object_type="pedestrian", current_state=_state(yaw_rate=0.7),
        selected_model=ModelType.CTRV, horizons_s=HORIZONS,
    )
    assert all(h.probability <= 1.0 for h in hs.hypotheses)
