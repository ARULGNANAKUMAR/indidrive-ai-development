import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))

from core.prediction.model_selector import ModelSelector, ModelSelectorConfig
from core.prediction.prediction_types import ModelType


def test_selector_picks_cv_for_stable_slow_object():
    sel = ModelSelector()
    model = sel.select(speed=5.0, yaw_rate=0.0, ax=0.0, ay=0.0)
    assert model == ModelType.CV


def test_selector_picks_cv_for_stationary_object():
    sel = ModelSelector()
    model = sel.select(speed=0.0, yaw_rate=0.9, ax=5.0, ay=5.0)
    assert model == ModelType.CV


def test_selector_picks_ca_for_accelerating_object():
    sel = ModelSelector()
    model = sel.select(speed=10.0, yaw_rate=0.0, ax=3.0, ay=0.0)
    assert model == ModelType.CA


def test_selector_picks_ctrv_for_turning_object():
    sel = ModelSelector()
    model = sel.select(speed=10.0, yaw_rate=0.8, ax=0.0, ay=0.0)
    assert model == ModelType.CTRV


def test_selector_turning_takes_priority_over_accelerating():
    sel = ModelSelector()
    model = sel.select(speed=10.0, yaw_rate=0.8, ax=3.0, ay=0.0)
    assert model == ModelType.CTRV


def test_selector_is_deterministic_across_repeated_calls():
    sel = ModelSelector()
    results = {sel.select(speed=8.0, yaw_rate=0.2, ax=1.0, ay=0.0) for _ in range(20)}
    assert len(results) == 1


def test_selector_handles_nan_inputs_safely():
    sel = ModelSelector()
    model = sel.select(speed=float("nan"), yaw_rate=float("nan"), ax=float("inf"), ay=0.0)
    assert model in (ModelType.CV, ModelType.CA, ModelType.CTRV)


def test_selector_respects_custom_thresholds():
    cfg = ModelSelectorConfig(yaw_rate_threshold=1.0, accel_threshold=10.0, stationary_speed=0.0)
    sel = ModelSelector(cfg)
    # Would be CTRV/CA under defaults, but not under these wider thresholds.
    model = sel.select(speed=5.0, yaw_rate=0.5, ax=2.0, ay=0.0)
    assert model == ModelType.CV
