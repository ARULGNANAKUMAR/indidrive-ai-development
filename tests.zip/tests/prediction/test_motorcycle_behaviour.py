import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))

from core.perception.perception_types import Position3D, SourceSensor
from core.fusion.fusion_types import FusedObject, FusedWorldState, FusionMode
from core.prediction.phase4c_pipeline import Phase4CPipeline
from core.prediction.object_behaviour import get_profile
from core.prediction.uncertainty_engine import UncertaintyFactors, compute_uncertainty
from core.prediction.path_selector import PredictionPath


def _obj(track_id, t, x, y, vx=1.0, vy=0.0, heading=0.0, cls="motorcycle", yaw_rate_hint=None):
    return FusedObject(
        fused_object_id=f"f_{track_id}", object_class=cls, class_confidence=0.9,
        position_3d=Position3D(x, y, 0.0), velocity=(vx, vy, 0.0),
        dimensions=None, heading=heading, distance=10.0, bbox_2d=None,
        source_sensors=frozenset({SourceSensor.CAMERA, SourceSensor.LIDAR}),
        position_confidence=0.85, existence_probability=0.85, quality=0.8,
        track_id=track_id, timestamp=t,
    )


def _world(objects, t, mode=FusionMode.PARTIAL_FUSION):
    return FusedWorldState(timestamp=t, frame_id=1, fusion_mode=mode, objects=objects)


def test_motorcycle_has_higher_lateral_uncertainty_than_car():
    moto = get_profile("motorcycle")
    car = get_profile("car")
    assert moto.lateral_uncertainty_factor > car.lateral_uncertainty_factor
    assert moto.agility > car.agility


def test_motorcycle_sigma_exceeds_car_sigma_same_conditions():
    common = dict(horizon_s=2.0, base_sigma=1.0, sensor_quality=None, track_age_cycles=5)
    moto_result = compute_uncertainty(UncertaintyFactors(object_type="motorcycle", **common))
    car_result = compute_uncertainty(UncertaintyFactors(object_type="car", **common))
    assert moto_result.sigma_x > car_result.sigma_x
    assert moto_result.sigma_y > car_result.sigma_y


def test_motorcycle_cut_in_routes_to_deep_path():
    """A motorcycle filtering between vehicles and cutting across a
    lane shows up as strong lateral velocity + yaw_rate change across
    consecutive cycles -- Phase 4B should mark it unstable, and Phase
    4C should route it to the deep path."""
    pipe = Phase4CPipeline()
    t = 1.0
    # A few stable cycles first (establishes a track).
    for i in range(3):
        o = _obj("moto_1", t, i * 1.0, 0.0, vx=8.0, vy=0.0, heading=0.0)
        out = pipe.process(_world([o], t))
        t += 0.1

    # Sudden lateral cut-in: strong lateral velocity component appears.
    o = _obj("moto_1", t, 3.0, 0.3, vx=6.0, vy=4.0, heading=0.0)
    out = pipe.process(_world([o], t))
    result = next(p for p in out.objects if p.track_id == "moto_1")
    assert result.behaviour_class.value == "MOTORCYCLE"
    assert result.prediction_path == PredictionPath.DEEP


def test_motorcycle_filtering_does_not_require_lane_information():
    """spec section 2/7: prediction must not assume perfect lanes --
    a motorcycle weaving between two other vehicles at a lateral
    offset that wouldn't fit a car's lane should still produce a
    valid trajectory."""
    pipe = Phase4CPipeline()
    o = _obj("moto_lane_split", 1.0, 0.0, 1.2, vx=6.0, vy=0.5, heading=0.05)
    out = pipe.process(_world([o], 1.0))
    assert len(out.objects) == 1
    assert out.objects[0].predicted.trajectory
