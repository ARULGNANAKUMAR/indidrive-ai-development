import math
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))

from core.perception.perception_types import Position3D, SourceSensor
from core.fusion.fusion_types import FusedObject, FusedWorldState, FusionMode
from core.prediction.prediction_engine import PredictionEngine
from core.perception.perception_types import HealthState


def _obj(track_id="t1", t=1.0, pos=(1.0, 1.0, 0.0), velocity=(1.0, 0.0, 0.0), heading=0.0):
    return FusedObject(
        fused_object_id=f"fused_{track_id}", object_class="car", class_confidence=0.9,
        position_3d=Position3D(*pos) if pos is not None else None,
        velocity=velocity, dimensions=None, heading=heading, distance=1.0, bbox_2d=None,
        source_sensors=frozenset({SourceSensor.CAMERA}),
        position_confidence=0.9, existence_probability=0.9, track_id=track_id, timestamp=t,
    )


def _world(objects, t=1.0):
    return FusedWorldState(timestamp=t, frame_id=1, fusion_mode=FusionMode.SINGLE_SENSOR, objects=objects)


def test_nan_position_is_skipped_not_crashing():
    engine = PredictionEngine()
    bad = _obj(pos=(math.nan, 0.0, 0.0))
    out = engine.process(_world([bad]))
    assert out.objects == []
    assert any("skipped" in w for w in out.warnings)


def test_inf_velocity_is_skipped_not_crashing():
    engine = PredictionEngine()
    bad = _obj(velocity=(math.inf, 0.0, 0.0))
    out = engine.process(_world([bad]))
    assert out.objects == []


def test_invalid_timestamp_is_skipped():
    engine = PredictionEngine()
    bad = _obj(t=-1.0)
    out = engine.process(_world([bad], t=-1.0))
    assert out.objects == []


def test_missing_position_is_skipped():
    engine = PredictionEngine()
    bad = _obj(pos=None)
    out = engine.process(_world([bad]))
    assert out.objects == []


def test_missing_velocity_falls_back_safely_instead_of_crashing():
    engine = PredictionEngine()
    obj = _obj(velocity=None)
    out = engine.process(_world([obj]))
    assert len(out.objects) == 1
    assert out.objects[0].current_state.is_valid()


def test_one_invalid_object_does_not_block_valid_ones():
    engine = PredictionEngine()
    good = _obj(track_id="good", pos=(5.0, 5.0, 0.0))
    bad = _obj(track_id="bad", pos=(math.nan, math.nan, 0.0))
    out = engine.process(_world([good, bad]))
    assert len(out.objects) == 1
    assert out.objects[0].track_id == "good"
    assert out.prediction_health == HealthState.DEGRADED


def test_all_invalid_objects_reports_failed_health():
    engine = PredictionEngine()
    bad = _obj(pos=(math.nan, 0.0, 0.0))
    out = engine.process(_world([bad]))
    assert out.prediction_health == HealthState.FAILED


def test_empty_world_state_reports_not_available_health():
    engine = PredictionEngine()
    out = engine.process(_world([]))
    assert out.prediction_health == HealthState.NOT_AVAILABLE
    assert out.objects == []
