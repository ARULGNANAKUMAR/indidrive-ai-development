import math
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))

from core.prediction.hypothesis_scoring import (
    HypothesisConfig, project_longitudinal_lateral, body_frame_lateral_velocity,
    stability_score, is_stable, candidate_behaviours, score_behaviour,
    normalize_scores, historical_yaw_rate_bias, object_class_lateral_factor,
)
from core.prediction.hypothesis_types import BehaviourType


def test_project_longitudinal_lateral_zero_heading():
    a_long, a_lat = project_longitudinal_lateral(0.0, 2.0, 1.0)
    assert math.isclose(a_long, 2.0, abs_tol=1e-9)
    assert math.isclose(a_lat, 1.0, abs_tol=1e-9)


def test_project_longitudinal_lateral_handles_nan():
    a_long, a_lat = project_longitudinal_lateral(float("nan"), 1.0, 1.0)
    assert (a_long, a_lat) == (0.0, 0.0)


def test_body_frame_lateral_velocity_pure_forward_motion_is_zero():
    v_lat = body_frame_lateral_velocity(0.0, 5.0, 0.0)
    assert math.isclose(v_lat, 0.0, abs_tol=1e-9)


def test_stability_score_is_lower_for_high_yaw_rate():
    stable = stability_score(0.0, 0.0, 0.0)
    unstable = stability_score(0.5, 0.0, 0.0)
    assert stable > unstable


def test_is_stable_true_for_steady_state():
    assert is_stable(0.0, 0.0, 0.0, 0.0) is True


def test_is_stable_false_for_turning_state():
    assert is_stable(0.5, 0.0, 0.0, 0.0) is False


def test_candidate_behaviours_always_includes_straight():
    cands = candidate_behaviours(0.0, 0.0, 0.0, 0.0, 0.0, 0.0)
    assert BehaviourType.STRAIGHT in cands


def test_candidate_behaviours_detects_left_turn():
    cands = candidate_behaviours(0.5, 0.0, 0.0, 0.0, 0.0, 0.0)
    assert BehaviourType.LEFT in cands
    assert BehaviourType.RIGHT not in cands


def test_candidate_behaviours_detects_right_turn():
    cands = candidate_behaviours(-0.5, 0.0, 0.0, 0.0, 0.0, 0.0)
    assert BehaviourType.RIGHT in cands
    assert BehaviourType.LEFT not in cands


def test_candidate_behaviours_detects_braking():
    cands = candidate_behaviours(0.0, -3.0, 0.0, 0.0, 5.0, 0.0)
    assert BehaviourType.BRAKING in cands


def test_candidate_behaviours_detects_acceleration():
    cands = candidate_behaviours(0.0, 3.0, 0.0, 0.0, 5.0, 0.0)
    assert BehaviourType.ACCELERATION in cands


def test_score_behaviour_left_positive_for_left_turn():
    score = score_behaviour(
        BehaviourType.LEFT, yaw_rate=0.5, ax=0.0, ay=0.0, heading=0.0,
        vx=5.0, vy=0.0, object_type="car", history_yaw_rates=[],
    )
    assert score > 0.0


def test_score_behaviour_right_zero_when_turning_left():
    score = score_behaviour(
        BehaviourType.RIGHT, yaw_rate=0.5, ax=0.0, ay=0.0, heading=0.0,
        vx=5.0, vy=0.0, object_type="car", history_yaw_rates=[],
    )
    assert score == 0.0


def test_score_behaviour_history_agreement_boosts_score():
    kwargs = dict(yaw_rate=0.5, ax=0.0, ay=0.0, heading=0.0, vx=5.0, vy=0.0, object_type="car")
    agree = score_behaviour(BehaviourType.LEFT, history_yaw_rates=[0.4, 0.3], **kwargs)
    disagree = score_behaviour(BehaviourType.LEFT, history_yaw_rates=[-0.4, -0.3], **kwargs)
    assert agree > disagree


def test_object_class_lateral_factor_higher_for_pedestrian():
    assert object_class_lateral_factor("pedestrian") > object_class_lateral_factor("car")


def test_historical_yaw_rate_bias_ignores_non_finite():
    bias = historical_yaw_rate_bias([0.2, float("nan"), 0.4])
    assert math.isclose(bias, 0.3, abs_tol=1e-9)


def test_normalize_scores_sums_to_one():
    probs = normalize_scores({BehaviourType.STRAIGHT: 2.0, BehaviourType.LEFT: 1.0})
    assert math.isclose(sum(probs.values()), 1.0, abs_tol=1e-9)


def test_normalize_scores_falls_back_to_uniform_when_all_zero():
    probs = normalize_scores({BehaviourType.STRAIGHT: 0.0, BehaviourType.LEFT: 0.0})
    assert math.isclose(probs[BehaviourType.STRAIGHT], 0.5, abs_tol=1e-9)
    assert math.isclose(probs[BehaviourType.LEFT], 0.5, abs_tol=1e-9)


def test_normalize_scores_empty_input_returns_empty():
    assert normalize_scores({}) == {}
