import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))

from core.prediction.object_behaviour import (
    ObjectBehaviourClass, classify_object, get_profile, clamp_yaw_rate_for_class,
)


def test_classifies_known_indian_road_classes():
    assert classify_object("car") == ObjectBehaviourClass.CAR
    assert classify_object("Motorcycle") == ObjectBehaviourClass.MOTORCYCLE
    assert classify_object("scooter") == ObjectBehaviourClass.SCOOTER
    assert classify_object("auto-rickshaw") == ObjectBehaviourClass.AUTO_RICKSHAW
    assert classify_object("AUTO") == ObjectBehaviourClass.AUTO_RICKSHAW
    assert classify_object("bus") == ObjectBehaviourClass.BUS
    assert classify_object("truck") == ObjectBehaviourClass.TRUCK
    assert classify_object("tractor") == ObjectBehaviourClass.TRACTOR
    assert classify_object("bicycle") == ObjectBehaviourClass.CYCLE
    assert classify_object("pedestrian") == ObjectBehaviourClass.PEDESTRIAN
    assert classify_object("cow") == ObjectBehaviourClass.CATTLE
    assert classify_object("buffalo") == ObjectBehaviourClass.CATTLE


def test_unknown_class_never_defaults_to_car():
    assert classify_object("unidentified_debris") == ObjectBehaviourClass.UNKNOWN
    assert classify_object("") == ObjectBehaviourClass.UNKNOWN
    assert classify_object(None) == ObjectBehaviourClass.UNKNOWN
    unknown_profile = get_profile("unidentified_debris")
    car_profile = get_profile("car")
    # Unknown is never assumed to be as predictable as a known car.
    assert unknown_profile.lateral_uncertainty_factor > car_profile.lateral_uncertainty_factor


def test_every_profile_is_deterministic_and_repeatable():
    a = get_profile("motorcycle")
    b = get_profile("motorcycle")
    assert a == b


def test_car_is_the_baseline_for_every_factor():
    car = get_profile("car")
    assert car.lateral_uncertainty_factor == 1.0
    assert car.direction_uncertainty_factor == 1.0
    assert car.agility == 1.0
    assert car.longitudinal_uncertainty_factor == 1.0


def test_clamp_yaw_rate_respects_class_ceiling():
    # A bus cannot plausibly be measured turning at 3.0 rad/s.
    clamped = clamp_yaw_rate_for_class("bus", 3.0)
    profile = get_profile("bus")
    assert clamped == profile.max_yaw_rate

    clamped_neg = clamp_yaw_rate_for_class("bus", -3.0)
    assert clamped_neg == -profile.max_yaw_rate

    # Within range values pass through unchanged.
    assert clamp_yaw_rate_for_class("car", 0.1) == 0.1


def test_clamp_yaw_rate_handles_non_finite_input():
    assert clamp_yaw_rate_for_class("car", float("nan")) == 0.0
    assert clamp_yaw_rate_for_class("car", None) == 0.0
