import math
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))

from core.prediction.prediction_types import MotionState
from core.prediction.motion_models import constant_acceleration


def _state(**overrides):
    base = dict(x=0.0, y=0.0, z=0.0, vx=1.0, vy=0.0, vz=0.0,
                ax=2.0, ay=0.0, az=0.0, yaw=0.0, yaw_rate=0.0,
                speed=1.0, heading=0.0, timestamp=0.0)
    base.update(overrides)
    return MotionState(**base)


def test_ca_matches_kinematic_formula():
    s = _state()
    t = 2.0
    future = constant_acceleration(s, t)
    expected_x = s.x + s.vx * t + 0.5 * s.ax * t * t
    assert math.isclose(future.x, expected_x)


def test_ca_velocity_updates_with_acceleration():
    s = _state()
    future = constant_acceleration(s, 1.0)
    assert math.isclose(future.vx, s.vx + s.ax * 1.0)


def test_ca_accelerating_vehicle_moves_further_than_cv_would():
    from core.prediction.motion_models import constant_velocity
    s = _state()
    cv_future = constant_velocity(s, 2.0)
    ca_future = constant_acceleration(s, 2.0)
    assert ca_future.x > cv_future.x


def test_ca_missing_acceleration_falls_back_safely():
    s = _state(ax=math.nan, ay=math.nan)
    future = constant_acceleration(s, 1.0)
    assert math.isfinite(future.x)
    assert math.isfinite(future.vx)
    assert future.ax == 0.0
    assert future.ay == 0.0


def test_ca_inf_acceleration_falls_back_safely():
    s = _state(ax=math.inf)
    future = constant_acceleration(s, 1.0)
    assert math.isfinite(future.x)
    assert future.ax == 0.0


def test_ca_zero_dt_returns_same_position():
    s = _state()
    future = constant_acceleration(s, 0.0)
    assert future.x == s.x
    assert future.vx == s.vx
