import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))

from core.prediction.uncertainty_engine import UncertaintyFactors, compute_uncertainty
from core.prediction.sensor_quality import SensorQuality


def _sigma_at(h, **kwargs):
    result = compute_uncertainty(UncertaintyFactors(horizon_s=h, base_sigma=0.5, object_type="car", **kwargs))
    return result.sigma_x


def test_uncertainty_grows_strictly_with_horizon():
    s_025 = _sigma_at(0.25)
    s_1 = _sigma_at(1.0)
    s_3 = _sigma_at(3.0)
    s_5 = _sigma_at(5.0)
    assert s_025 < s_1 < s_3 < s_5


def test_uncertainty_is_not_hardcoded_identical_across_horizons():
    values = [_sigma_at(h) for h in (0.25, 0.5, 1.0, 1.5, 2.0, 3.0, 5.0)]
    assert len(set(values)) == len(values)  # every horizon gets a distinct sigma


def test_confidence_decreases_as_horizon_grows():
    near = compute_uncertainty(UncertaintyFactors(horizon_s=0.25, base_sigma=0.5, object_type="car"))
    far = compute_uncertainty(UncertaintyFactors(horizon_s=5.0, base_sigma=0.5, object_type="car"))
    assert far.confidence < near.confidence


def test_uncertainty_never_negative_or_non_finite():
    for h in (0.0, 0.25, 5.0, 100.0):
        result = compute_uncertainty(UncertaintyFactors(horizon_s=h, base_sigma=0.5, object_type="car"))
        assert result.sigma_x >= 0.0
        assert result.sigma_y >= 0.0
        assert 0.0 <= result.confidence <= 1.0


def test_uncertainty_handles_missing_base_sigma_without_fabricating_zero():
    result = compute_uncertainty(UncertaintyFactors(horizon_s=1.0, base_sigma=None, object_type="car"))
    assert result.sigma_x > 0.0  # falls back to a deterministic floor, not a fake precise value


def test_track_age_increases_uncertainty_for_new_tracks():
    new_track = compute_uncertainty(UncertaintyFactors(horizon_s=1.0, base_sigma=0.5, object_type="car", track_age_cycles=1))
    mature_track = compute_uncertainty(UncertaintyFactors(horizon_s=1.0, base_sigma=0.5, object_type="car", track_age_cycles=20))
    assert new_track.sigma_x > mature_track.sigma_x


def test_instability_in_history_increases_uncertainty():
    stable = compute_uncertainty(UncertaintyFactors(
        horizon_s=1.0, base_sigma=0.5, object_type="car",
        velocity_std=0.0, acceleration_std=0.0, heading_std=0.0,
    ))
    unstable = compute_uncertainty(UncertaintyFactors(
        horizon_s=1.0, base_sigma=0.5, object_type="car",
        velocity_std=2.0, acceleration_std=1.5, heading_std=0.5,
    ))
    assert unstable.sigma_x > stable.sigma_x
