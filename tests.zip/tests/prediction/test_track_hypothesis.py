import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))

from core.perception.perception_types import Position3D, SourceSensor
from core.fusion.fusion_types import FusedObject, FusedWorldState, FusionMode
from core.prediction.prediction_engine import PredictionEngine
from core.prediction.hypothesis_engine import HypothesisEngine


def _obj(track_id, t, x, y, vx=1.0, vy=0.0, heading=0.0):
    return FusedObject(
        fused_object_id=f"fused_{track_id}", object_class="car", class_confidence=0.9,
        position_3d=Position3D(x, y, 0.0), velocity=(vx, vy, 0.0),
        dimensions=None, heading=heading, distance=10.0, bbox_2d=None,
        source_sensors=frozenset({SourceSensor.CAMERA}),
        position_confidence=0.9, existence_probability=0.9, track_id=track_id, timestamp=t,
    )


def _world(objects, t):
    return FusedWorldState(timestamp=t, frame_id=1, fusion_mode=FusionMode.SINGLE_SENSOR, objects=objects)


def test_every_hypothesis_keeps_its_track_id():
    engine = PredictionEngine()
    hyp_engine = HypothesisEngine()
    out = engine.process(_world([_obj("101", 1.0, 0.0, 0.0, vx=5.0)], 1.0))
    result = hyp_engine.process(out, history=engine._history)
    hs = result.tracks["101"]
    assert hs.track_id == "101"
    assert all(h.track_id == "101" for h in hs.hypotheses)


def test_hypothesis_engine_does_not_mint_new_track_ids():
    engine = PredictionEngine()
    hyp_engine = HypothesisEngine()
    out = engine.process(_world([_obj("A", 1.0, 0.0, 0.0), _obj("B", 1.0, 10.0, 0.0)], 1.0))
    result = hyp_engine.process(out, history=engine._history)
    assert set(result.tracks.keys()) == {"A", "B"}


def test_track_id_persists_across_cycles():
    engine = PredictionEngine()
    hyp_engine = HypothesisEngine()
    engine.process(_world([_obj("101", 1.0, 0.0, 0.0)], 1.0))
    out2 = engine.process(_world([_obj("101", 2.0, 1.0, 0.0)], 2.0))
    result = hyp_engine.process(out2, history=engine._history)
    assert "101" in result.tracks
    assert result.tracks["101"].track_id == "101"
