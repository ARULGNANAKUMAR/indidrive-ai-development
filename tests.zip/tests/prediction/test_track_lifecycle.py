import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))

from core.prediction.track_lifecycle import TrackLifecycleManager, TrackLifecycleConfig
from core.prediction.prediction_types import TrackLifecycleState


def test_new_track_starts_as_new():
    mgr = TrackLifecycleManager()
    state = mgr.observe("101", seen=True)
    assert state == TrackLifecycleState.NEW


def test_track_confirms_to_active_after_enough_hits():
    cfg = TrackLifecycleConfig(confirm_hits=2)
    mgr = TrackLifecycleManager(cfg)
    mgr.observe("101", seen=True)
    state = mgr.observe("101", seen=True)
    assert state == TrackLifecycleState.ACTIVE


def test_single_missed_measurement_is_tolerated():
    cfg = TrackLifecycleConfig(confirm_hits=1, lost_after_misses=2)
    mgr = TrackLifecycleManager(cfg)
    mgr.observe("101", seen=True)
    state = mgr.observe("101", seen=False)
    assert state == TrackLifecycleState.ACTIVE


def test_confidence_decreases_when_measurements_disappear():
    cfg = TrackLifecycleConfig(confirm_hits=1)
    mgr = TrackLifecycleManager(cfg)
    mgr.observe("101", seen=True)
    conf_before = mgr.get_confidence("101")
    mgr.observe("101", seen=False)
    conf_after = mgr.get_confidence("101")
    assert conf_after < conf_before


def test_track_becomes_temporarily_lost_after_enough_misses():
    cfg = TrackLifecycleConfig(confirm_hits=1, lost_after_misses=2)
    mgr = TrackLifecycleManager(cfg)
    mgr.observe("101", seen=True)
    mgr.observe("101", seen=False)
    state = mgr.observe("101", seen=False)
    assert state == TrackLifecycleState.TEMPORARILY_LOST


def test_track_recovers_to_active_after_reappearing():
    cfg = TrackLifecycleConfig(confirm_hits=1, lost_after_misses=1)
    mgr = TrackLifecycleManager(cfg)
    mgr.observe("101", seen=True)
    mgr.observe("101", seen=False)
    state = mgr.observe("101", seen=True)
    assert state == TrackLifecycleState.ACTIVE


def test_track_expires_to_stale_then_deleted():
    cfg = TrackLifecycleConfig(confirm_hits=1, lost_after_misses=1, stale_after_misses=2, delete_after_misses=3)
    mgr = TrackLifecycleManager(cfg)
    mgr.observe("101", seen=True)
    mgr.observe("101", seen=False)   # TEMPORARILY_LOST
    state = mgr.observe("101", seen=False)  # STALE
    assert state == TrackLifecycleState.STALE
    state = mgr.observe("101", seen=False)  # DELETED
    assert state == TrackLifecycleState.DELETED


def test_purge_deleted_releases_memory():
    cfg = TrackLifecycleConfig(confirm_hits=1, delete_after_misses=1)
    mgr = TrackLifecycleManager(cfg)
    mgr.observe("101", seen=True)
    mgr.observe("101", seen=False)
    deleted = mgr.purge_deleted()
    assert "101" in deleted
    assert "101" not in mgr.active_track_ids()


def test_unknown_track_reports_deleted_state():
    mgr = TrackLifecycleManager()
    assert mgr.get_state("does-not-exist") == TrackLifecycleState.DELETED
