"""UNIT TEST — SensorHealthMonitor state transitions."""
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))

from core.carla_integration.sensor_health import (
    SensorHealthMonitor, ONLINE, OFFLINE, DEGRADED, NOT_CONFIGURED,
)


def test_registered_configured_sensor_starts_offline():
    mon = SensorHealthMonitor()
    mon.register("cam", configured=True)
    assert mon.report()["cam"]["status"] == OFFLINE


def test_not_configured_sensor_stays_not_configured():
    mon = SensorHealthMonitor()
    mon.mark_not_configured("radar_front")
    report = mon.report()
    assert report["radar_front"]["status"] == NOT_CONFIGURED
    # frames should never flip a NOT_CONFIGURED sensor status implicitly here;
    # only explicit record_frame() calls would, and nothing calls it for radar.


def test_record_frame_marks_online():
    mon = SensorHealthMonitor(degraded_latency_ms=200.0)
    mon.register("cam", configured=True)
    mon.record_frame("cam", frame_id=1, callback_latency_ms=5.0)
    report = mon.report()
    assert report["cam"]["status"] == ONLINE
    assert report["cam"]["last_frame_id"] == 1


def test_high_latency_marks_degraded():
    mon = SensorHealthMonitor(degraded_latency_ms=50.0)
    mon.register("cam", configured=True)
    mon.record_frame("cam", frame_id=1, callback_latency_ms=500.0)
    assert mon.report()["cam"]["status"] == DEGRADED


def test_staleness_marks_offline():
    mon = SensorHealthMonitor(stale_after_s=0.05)
    mon.register("cam", configured=True)
    mon.record_frame("cam", frame_id=1, callback_latency_ms=1.0)
    assert mon.report()["cam"]["status"] == ONLINE
    time.sleep(0.1)
    assert mon.report()["cam"]["status"] == OFFLINE


def test_dropped_and_error_counts_accumulate():
    mon = SensorHealthMonitor()
    mon.register("cam", configured=True)
    mon.record_dropped("cam", 3)
    mon.record_error("cam", "decode failure")
    report = mon.report()
    assert report["cam"]["dropped_frames"] == 3
    assert report["cam"]["error_count"] == 1
    assert report["cam"]["last_error"] == "decode failure"


def test_status_text_format():
    mon = SensorHealthMonitor()
    mon.register("cam", configured=True)
    mon.mark_not_configured("radar_front")
    text = mon.status_text()
    assert "INDIDRIVE SENSOR STATUS" in text
    assert "radar_front" in text
    assert NOT_CONFIGURED in text
