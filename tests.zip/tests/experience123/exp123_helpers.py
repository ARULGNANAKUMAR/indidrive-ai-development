"""
IndiDrive AI — Phase 12.3 | Test Helpers
=========================================
Shared builders for Phase 12.3 outcome evaluation tests.
"""
from __future__ import annotations
import sys, os, time

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "experience122"))

from exp122_helpers import (
    make_record_config,
    make_situation,
    make_action,
    make_outcome,
    make_full_record,
)

from core.experience.record.record_types import (
    RECORD_SCHEMA_VERSION,
    NOT_AVAILABLE,
    ActionRecord,
    ActionType,
    ActionSource,
    AppliedAction,
    ExperienceRecord,
    ExperienceRecordConfig,
    OutcomeObservationState,
    OutcomeRecord,
    RecordCompleteness,
    RequestedAction,
    SituationRecord,
)
from core.experience.record.record_engine import _make_record_id

from core.experience.evaluation.evaluation_types import (
    EVALUATION_SCHEMA_VERSION,
    EvaluationConfidence,
    EvaluationStatus,
    EvidenceKey,
    OutcomeClass,
    OutcomeEvaluation,
    OutcomeEvaluatorConfig,
)
from core.experience.evaluation.outcome_evaluator import OutcomeEvaluator
from core.experience.evaluation.evaluation_validator import EvaluationValidator
from core.experience.evaluation.evaluation_store import EvaluationStore


# ---------------------------------------------------------------------------
# Evaluator / config builders
# ---------------------------------------------------------------------------

def make_evaluator(allow_early: bool = False) -> OutcomeEvaluator:
    cfg = OutcomeEvaluatorConfig(allow_early_evaluation=allow_early)
    return OutcomeEvaluator(cfg)


def make_eval_config(**kwargs) -> OutcomeEvaluatorConfig:
    cfg = OutcomeEvaluatorConfig()
    for k, v in kwargs.items():
        setattr(cfg, k, v)
    return cfg


# ---------------------------------------------------------------------------
# Outcome builders — extend Phase 12.2 make_outcome with evaluation signals
# ---------------------------------------------------------------------------

def make_safe_outcome(
    session_id: str = "sess-001",
    record_id: str = None,
    seq: int = 0,
    action_timestamp: float = None,
    hazard_after: str = "NONE",
    cleared_events=("HAZARD_DETECTED",),
    emergency_cleared: bool = False,
    control_state: str = "ACTIVE",
    planning_status: str = "ACTIVE",
    path_state: str = "VALID",
    ego_speed: float = 5.0,
) -> OutcomeRecord:
    rid = record_id or f"{session_id}-R{seq:06d}"
    ts = action_timestamp or time.time()
    out = make_outcome(
        session_id=session_id,
        record_id=rid,
        seq=seq,
        action_timestamp=ts,
        obs_state=OutcomeObservationState.OBSERVED,
        hazard_after=hazard_after,
        emergency_cleared=emergency_cleared,
        collision_detected=False,
    )
    out.control_state_after = control_state
    out.planning_status_after = planning_status
    out.path_state_after = path_state
    out.safety_state_after = "SAFE"
    out.cleared_event_types = tuple(cleared_events)
    out.unresolved_event_types = ()
    out.ego_speed_after_ms = ego_speed
    return out


def make_collision_outcome(
    session_id: str = "sess-001",
    record_id: str = None,
    seq: int = 0,
) -> OutcomeRecord:
    rid = record_id or f"{session_id}-R{seq:06d}"
    ts = time.time()
    out = make_outcome(session_id=session_id, record_id=rid, seq=seq,
                       action_timestamp=ts, obs_state=OutcomeObservationState.OBSERVED)
    out.collision_detected = True
    out.safety_state_after = "UNSAFE"
    return out


def make_no_outcome_record(
    session_id: str = "sess-001",
    seq: int = 0,
) -> ExperienceRecord:
    """ExperienceRecord with action but no outcome."""
    rid = _make_record_id(session_id, seq)
    ts = time.time()
    sit = make_situation(session_id, rid, seq, ts)
    act = make_action(session_id, rid, seq, ts)
    return ExperienceRecord(
        record_id=rid,
        session_id=session_id,
        sequence_id=seq,
        schema_version=RECORD_SCHEMA_VERSION,
        created_timestamp=ts,
        last_updated_timestamp=ts,
        situation=sit,
        action=act,
        outcome=None,
        completeness=RecordCompleteness.ACTION_ATTACHED,
        source_observation_id=f"{session_id}-O{seq:06d}",
    )


def make_pending_record(
    session_id: str = "sess-001",
    seq: int = 0,
) -> ExperienceRecord:
    """ExperienceRecord with outcome window open."""
    rid = _make_record_id(session_id, seq)
    ts = time.time()
    sit = make_situation(session_id, rid, seq, ts)
    act = make_action(session_id, rid, seq, ts)
    out = make_outcome(session_id=session_id, record_id=rid, seq=seq,
                       action_timestamp=ts,
                       obs_state=OutcomeObservationState.PARTIAL)
    return ExperienceRecord(
        record_id=rid,
        session_id=session_id,
        sequence_id=seq,
        schema_version=RECORD_SCHEMA_VERSION,
        created_timestamp=ts,
        last_updated_timestamp=ts,
        situation=sit,
        action=act,
        outcome=out,
        completeness=RecordCompleteness.OUTCOME_OBSERVING,
        source_observation_id=f"{session_id}-O{seq:06d}",
    )


def make_invalid_record() -> ExperienceRecord:
    """ExperienceRecord with deliberately invalid structure."""
    return ExperienceRecord(
        record_id=NOT_AVAILABLE,
        session_id=NOT_AVAILABLE,
        sequence_id=-1,
        schema_version="BAD_VERSION",
        created_timestamp=-1.0,
        completeness=RecordCompleteness.INVALID,
    )


def make_emergency_record(
    session_id: str = "sess-001",
    seq: int = 0,
    emergency_cleared: bool = True,
) -> ExperienceRecord:
    """Emergency triggered; may or may not be cleared."""
    rid = _make_record_id(session_id, seq)
    ts = time.time()
    sit = make_situation(session_id, rid, seq, ts, hazard_level="CRITICAL")
    sit.emergency_state = "ACTIVE"
    sit.safety_state = "EMERGENCY"
    act = make_action(session_id, rid, seq, ts,
                      action_type=ActionType.EMERGENCY_RESPONSE_STATE)
    out = make_outcome(session_id=session_id, record_id=rid, seq=seq,
                       action_timestamp=ts,
                       obs_state=OutcomeObservationState.OBSERVED,
                       emergency_cleared=emergency_cleared,
                       collision_detected=False)
    out.safety_state_after = "SAFE" if emergency_cleared else "EMERGENCY"
    out.emergency_active_after = not emergency_cleared
    out.ego_speed_after_ms = 0.0
    completeness = RecordCompleteness.COMPLETE
    return ExperienceRecord(
        record_id=rid,
        session_id=session_id,
        sequence_id=seq,
        schema_version=RECORD_SCHEMA_VERSION,
        created_timestamp=ts,
        last_updated_timestamp=ts,
        situation=sit,
        action=act,
        outcome=out,
        completeness=completeness,
        source_observation_id=f"{session_id}-O{seq:06d}",
    )


def make_cattle_crossing_record(
    session_id: str = "sess-001",
    seq: int = 0,
    cattle_cleared: bool = True,
) -> ExperienceRecord:
    """Cattle crossing scenario."""
    rid = _make_record_id(session_id, seq)
    ts = time.time()
    sit = make_situation(session_id, rid, seq, ts,
                         hazard_level="HIGH", cattle=True)
    sit.road_type = "VILLAGE_ROAD"
    act = make_action(session_id, rid, seq, ts, action_type=ActionType.STOP)
    out = make_outcome(session_id=session_id, record_id=rid, seq=seq,
                       action_timestamp=ts,
                       obs_state=OutcomeObservationState.OBSERVED,
                       hazard_after="NONE" if cattle_cleared else "HIGH",
                       collision_detected=False)
    out.safety_state_after = "SAFE"
    out.ego_speed_after_ms = 0.0
    if cattle_cleared:
        out.cleared_event_types = ("CATTLE_EVENT",)
        out.unresolved_event_types = ()
    else:
        out.cleared_event_types = ()
        out.unresolved_event_types = ("CATTLE_EVENT",)
    completeness = RecordCompleteness.COMPLETE
    return ExperienceRecord(
        record_id=rid,
        session_id=session_id,
        sequence_id=seq,
        schema_version=RECORD_SCHEMA_VERSION,
        created_timestamp=ts,
        last_updated_timestamp=ts,
        situation=sit,
        action=act,
        outcome=out,
        completeness=completeness,
        source_observation_id=f"{session_id}-O{seq:06d}",
    )


def make_degraded_record(
    session_id: str = "sess-001",
    seq: int = 0,
) -> ExperienceRecord:
    """Record captured under degraded system conditions."""
    rid = _make_record_id(session_id, seq)
    ts = time.time()
    sit = make_situation(session_id, rid, seq, ts)
    sit.is_degraded = True
    sit.failsafe_state = "ACTIVE"
    act = make_action(session_id, rid, seq, ts,
                      action_type=ActionType.DEGRADED_OPERATION)
    out = make_outcome(session_id=session_id, record_id=rid, seq=seq,
                       action_timestamp=ts,
                       obs_state=OutcomeObservationState.DEGRADED,
                       collision_detected=False)
    out.is_degraded = True
    out.safety_state_after = "SAFE"
    return ExperienceRecord(
        record_id=rid,
        session_id=session_id,
        sequence_id=seq,
        schema_version=RECORD_SCHEMA_VERSION,
        created_timestamp=ts,
        last_updated_timestamp=ts,
        situation=sit,
        action=act,
        outcome=out,
        completeness=RecordCompleteness.COMPLETE,
        source_observation_id=f"{session_id}-O{seq:06d}",
    )
