"""
Phase 12.3 Negative Scope Tests.

Explicitly prove that Phase 12.3 does NOT:
  - change steering / throttle / braking
  - modify MPC / tracking / planning
  - modify safety supervisor decisions
  - generate paths or trajectories
  - retrieve historical experiences (→ 12.4)
  - calculate similarity
  - update memory knowledge (→ 12.5)
  - train a model or update weights
  - perform reinforcement learning
  - generate RL reward
  - perform adaptive learning
  - call an LLM or cloud API
  - require internet access
"""
import sys, os, inspect
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))

from exp123_helpers import make_evaluator, make_full_record, make_cattle_crossing_record

import core.experience.evaluation.outcome_evaluator as _evaluator_mod
import core.experience.evaluation.evaluation_rules as _rules_mod
import core.experience.evaluation.evaluation_types as _types_mod
import core.experience.evaluation.evaluation_validator as _validator_mod
import core.experience.evaluation.evaluation_store as _store_mod


# ---------------------------------------------------------------------------
# No vehicle control modification
# ---------------------------------------------------------------------------

class TestNoVehicleControl:
    def test_evaluate_does_not_modify_steering(self):
        ev = make_evaluator()
        rec = make_full_record()
        # Record the action before evaluation
        steer_before = None
        if rec.action and rec.action.applied:
            steer_before = rec.action.applied.commanded_steering_rad
        ev.evaluate(rec)
        steer_after = None
        if rec.action and rec.action.applied:
            steer_after = rec.action.applied.commanded_steering_rad
        assert steer_before == steer_after

    def test_evaluate_does_not_modify_throttle_acceleration(self):
        ev = make_evaluator()
        rec = make_full_record()
        accel_before = None
        if rec.action and rec.action.applied:
            accel_before = rec.action.applied.commanded_acceleration_ms2
        ev.evaluate(rec)
        accel_after = None
        if rec.action and rec.action.applied:
            accel_after = rec.action.applied.commanded_acceleration_ms2
        assert accel_before == accel_after

    def test_evaluate_does_not_modify_situation(self):
        ev = make_evaluator()
        rec = make_full_record()
        sit_type_before = rec.situation.situation_type if rec.situation else None
        ev.evaluate(rec)
        sit_type_after = rec.situation.situation_type if rec.situation else None
        assert sit_type_before == sit_type_after

    def test_evaluate_does_not_modify_outcome_record(self):
        ev = make_evaluator()
        rec = make_full_record()
        collision_before = rec.outcome.collision_detected if rec.outcome else None
        ev.evaluate(rec)
        collision_after = rec.outcome.collision_detected if rec.outcome else None
        assert collision_before == collision_after


# ---------------------------------------------------------------------------
# No planning / MPC / tracking modification
# ---------------------------------------------------------------------------

class TestNoPlanningModification:
    def test_no_path_generation_in_evaluator(self):
        src = inspect.getsource(_evaluator_mod)
        # These are forbidden method calls / attributes in the evaluator
        forbidden = [
            "generate_path",
            "new_trajectory",
            "plan_path",
            "update_mpc",
            "set_steering",
            "set_throttle",
            "set_braking",
        ]
        for f in forbidden:
            assert f not in src, (
                f"OutcomeEvaluator source contains forbidden call: {f!r}"
            )

    def test_no_planning_calls_in_rules(self):
        src = inspect.getsource(_rules_mod)
        forbidden = [
            "generate_path",
            "new_trajectory",
            "replan()",
            "update_mpc",
        ]
        for f in forbidden:
            assert f not in src, (
                f"evaluation_rules source contains forbidden call: {f!r}"
            )


# ---------------------------------------------------------------------------
# No experience retrieval (→ Phase 12.4)
# ---------------------------------------------------------------------------

class TestNoExperienceRetrieval:
    def test_no_similarity_search(self):
        src = inspect.getsource(_evaluator_mod)
        forbidden = [
            "nearest_neighbor",
            "similarity_search",
            "retrieve_experience",
            "embedding",
            "vector_db",
            "cosine_similarity",
            "k_nearest",
        ]
        for f in forbidden:
            assert f not in src, f"Forbidden retrieval method found: {f!r}"

    def test_no_retrieval_in_rules(self):
        src = inspect.getsource(_rules_mod)
        for term in ("similarity", "retrieve", "nearest", "embedding"):
            assert term not in src, f"Retrieval term in rules: {term!r}"


# ---------------------------------------------------------------------------
# No knowledge update (→ Phase 12.5)
# ---------------------------------------------------------------------------

class TestNoKnowledgeUpdate:
    def test_no_model_update_in_evaluator(self):
        src = inspect.getsource(_evaluator_mod)
        forbidden = [
            "update_policy",
            "update_prototype",
            "train(",
            "fit(",
            "backward(",
            "gradient",
            "optimizer",
            "backprop",
            "weight_update",
        ]
        for f in forbidden:
            assert f not in src, f"Forbidden learning method: {f!r}"

    def test_no_reward_in_evaluator(self):
        src = inspect.getsource(_evaluator_mod)
        for term in ("reward", "q_value", "advantage", "policy_gradient"):
            assert term not in src, f"Forbidden RL term: {term!r}"


# ---------------------------------------------------------------------------
# No LLM / cloud / internet
# ---------------------------------------------------------------------------

class TestNoExternalCalls:
    def test_no_llm_calls(self):
        for mod in (_evaluator_mod, _rules_mod, _types_mod, _store_mod):
            src = inspect.getsource(mod)
            for term in ("openai", "anthropic", "llm", "gpt", "claude_api"):
                assert term not in src.lower(), (
                    f"LLM call found in {mod.__name__}: {term!r}"
                )

    def test_no_http_requests(self):
        for mod in (_evaluator_mod, _rules_mod, _types_mod, _store_mod):
            src = inspect.getsource(mod)
            for term in ("requests.get", "urllib.request", "http.client",
                         "aiohttp", "httpx"):
                assert term not in src, (
                    f"HTTP call found in {mod.__name__}: {term!r}"
                )

    def test_no_network_imports(self):
        for mod in (_evaluator_mod, _rules_mod, _types_mod, _store_mod):
            src = inspect.getsource(mod)
            for term in ("import socket", "import urllib", "import requests"):
                assert term not in src, (
                    f"Network import in {mod.__name__}: {term!r}"
                )


# ---------------------------------------------------------------------------
# No RL reward
# ---------------------------------------------------------------------------

class TestNoRLReward:
    def test_outcome_class_is_not_reward(self):
        """OutcomeClass is a classification, not an RL reward."""
        from core.experience.evaluation.evaluation_types import OutcomeClass
        ev = make_evaluator()
        rec = make_cattle_crossing_record(cattle_cleared=True)
        result = ev.evaluate(rec)
        # Classification exists
        assert result.outcome_class == OutcomeClass.SUCCESS
        # No reward field
        assert not hasattr(result, "reward")
        assert not hasattr(result, "q_value")
        assert not hasattr(result, "advantage")

    def test_types_have_no_reward_fields(self):
        from core.experience.evaluation.evaluation_types import (
            OutcomeEvaluation, OutcomeEvaluationSnapshot,
        )
        ev_fields = {f.name for f in OutcomeEvaluation.__dataclass_fields__.values()}
        assert "reward" not in ev_fields
        assert "q_value" not in ev_fields
        snap_fields = {f.name for f in OutcomeEvaluationSnapshot.__dataclass_fields__.values()}
        assert "reward" not in snap_fields


# ---------------------------------------------------------------------------
# Evaluation is analysis-only
# ---------------------------------------------------------------------------

class TestEvaluationIsAnalysisOnly:
    def test_evaluate_produces_new_object_not_modified_record(self):
        """Evaluation produces a new OutcomeEvaluation; record is unchanged."""
        ev = make_evaluator()
        rec = make_full_record()
        original_record_id = rec.record_id
        original_completeness = rec.completeness
        evaluation = ev.evaluate(rec)
        # Record unchanged
        assert rec.record_id == original_record_id
        assert rec.completeness == original_completeness
        # Evaluation is separate object
        assert evaluation is not rec

    def test_evaluation_does_not_set_record_fields(self):
        """Evaluation must not add attributes to the ExperienceRecord."""
        ev = make_evaluator()
        rec = make_full_record()
        fields_before = set(vars(rec).keys())
        ev.evaluate(rec)
        fields_after = set(vars(rec).keys())
        # No new fields added to the record
        assert fields_after == fields_before
