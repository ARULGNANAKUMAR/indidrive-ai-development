"""
Tests for determinism, evaluation window, reason codes,
evidence traceability, validator, and evaluation store.
"""
import sys, os, time, copy
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))

from exp123_helpers import (
    make_evaluator, make_full_record, make_no_outcome_record,
    make_cattle_crossing_record, make_pending_record, make_invalid_record,
    make_situation, make_action, make_outcome,
)
from core.experience.evaluation.evaluation_types import (
    EvaluationStatus, OutcomeClass, EvidenceKey,
)
from core.experience.evaluation.evaluation_validator import EvaluationValidator
from core.experience.evaluation.evaluation_store import EvaluationStore
from core.experience.record.record_engine import _make_record_id
from core.experience.record.record_types import (
    RECORD_SCHEMA_VERSION, ExperienceRecord, OutcomeObservationState,
    RecordCompleteness,
)


# ---------------------------------------------------------------------------
# Determinism
# ---------------------------------------------------------------------------

class TestDeterministicEvaluation:
    def test_same_record_same_class(self):
        ev = make_evaluator()
        rec = make_cattle_crossing_record(cattle_cleared=True)
        r1 = ev.evaluate(rec)
        r2 = ev.evaluate(rec)
        assert r1.outcome_class == r2.outcome_class

    def test_same_record_same_evidence(self):
        ev = make_evaluator()
        rec = make_full_record()
        r1 = ev.evaluate(rec)
        r2 = ev.evaluate(rec)
        assert set(r1.evidence) == set(r2.evidence)

    def test_same_record_same_reason_codes(self):
        ev = make_evaluator()
        rec = make_cattle_crossing_record()
        r1 = ev.evaluate(rec)
        r2 = ev.evaluate(rec)
        assert set(r1.reason_codes) == set(r2.reason_codes)

    def test_same_record_same_confidence(self):
        ev = make_evaluator()
        rec = make_cattle_crossing_record(cattle_cleared=True)
        r1 = ev.evaluate(rec)
        r2 = ev.evaluate(rec)
        assert r1.confidence == r2.confidence

    def test_different_records_may_differ(self):
        ev = make_evaluator()
        r_success = make_cattle_crossing_record(cattle_cleared=True)
        r_unsafe = make_no_outcome_record()
        res1 = ev.evaluate(r_success)
        res2 = ev.evaluate(r_unsafe)
        # They should differ in outcome class
        assert res1.outcome_class != res2.outcome_class


# ---------------------------------------------------------------------------
# Evaluation window
# ---------------------------------------------------------------------------

class TestEvaluationWindow:
    def test_window_open_gives_pending(self):
        ev = make_evaluator(allow_early=False)
        rec = make_pending_record()
        result = ev.evaluate(rec)
        assert result.outcome_class == OutcomeClass.PENDING

    def test_early_eval_bypasses_pending(self):
        ev = make_evaluator(allow_early=True)
        rec = make_pending_record()
        result = ev.evaluate(rec)
        assert result.outcome_class != OutcomeClass.PENDING

    def test_complete_record_not_pending(self):
        ev = make_evaluator(allow_early=False)
        rec = make_cattle_crossing_record(cattle_cleared=True)
        result = ev.evaluate(rec)
        assert result.outcome_class != OutcomeClass.PENDING


# ---------------------------------------------------------------------------
# Evidence traceability
# ---------------------------------------------------------------------------

class TestEvidenceTraceability:
    def test_every_evaluation_has_traceability(self):
        ev = make_evaluator()
        scenarios = [
            make_full_record(),
            make_no_outcome_record(),
            make_cattle_crossing_record(cattle_cleared=True),
            make_cattle_crossing_record(cattle_cleared=False),
            make_pending_record(),
            make_invalid_record(),
        ]
        for rec in scenarios:
            result = ev.evaluate(rec)
            # Must have evidence OR be PENDING
            if result.evaluation_status == EvaluationStatus.COMPLETE:
                assert len(result.evidence) > 0, (
                    f"No evidence for {result.outcome_class}"
                )

    def test_reason_codes_always_in_evidence(self):
        ev = make_evaluator()
        scenarios = [
            make_full_record(),
            make_cattle_crossing_record(cattle_cleared=True),
            make_no_outcome_record(),
        ]
        for rec in scenarios:
            result = ev.evaluate(rec)
            ev_set = set(result.evidence)
            for rc in result.reason_codes:
                assert rc in ev_set

    def test_id_traceable_from_evaluation(self):
        ev = make_evaluator()
        rec = make_full_record(session_id="trace-sess", seq=3)
        result = ev.evaluate(rec)
        assert result.experience_id == rec.record_id
        assert result.session_id == rec.session_id


# ---------------------------------------------------------------------------
# Reason codes
# ---------------------------------------------------------------------------

class TestReasonCodes:
    def test_no_outcome_has_outcome_missing_code(self):
        ev = make_evaluator()
        result = ev.evaluate(make_no_outcome_record())
        assert EvidenceKey.OUTCOME_MISSING.value in result.reason_codes

    def test_cattle_cleared_has_hazard_resolved_or_cattle_cleared(self):
        ev = make_evaluator()
        result = ev.evaluate(make_cattle_crossing_record(cattle_cleared=True))
        assert result.outcome_class == OutcomeClass.SUCCESS
        ev_set = set(result.evidence)
        assert (EvidenceKey.HAZARD_RESOLVED.value in ev_set
                or EvidenceKey.CATTLE_EVENT_CLEARED.value in ev_set)


# ---------------------------------------------------------------------------
# Evaluation validator
# ---------------------------------------------------------------------------

class TestEvaluationValidator:
    def setup_method(self):
        self.validator = EvaluationValidator()
        self.evaluator = make_evaluator()

    def test_valid_evaluation_passes(self):
        rec = make_cattle_crossing_record(cattle_cleared=True)
        ev = self.evaluator.evaluate(rec)
        ok, reason = self.validator.validate_evaluation(ev)
        assert ok, reason

    def test_none_evaluation_fails(self):
        ok, reason = self.validator.validate_evaluation(None)
        assert not ok

    def test_wrong_schema_fails(self):
        rec = make_full_record()
        ev = self.evaluator.evaluate(rec)
        ev.schema_version = "99.9"
        ok, reason = self.validator.validate_evaluation(ev)
        assert not ok

    def test_bad_uncertainty_fails(self):
        rec = make_full_record()
        ev = self.evaluator.evaluate(rec)
        ev.uncertainty = 1.5
        ok, reason = self.validator.validate_evaluation(ev)
        assert not ok

    def test_reason_code_not_in_evidence_fails(self):
        rec = make_full_record()
        ev = self.evaluator.evaluate(rec)
        ev.reason_codes = ev.reason_codes + ("FAKE_CODE_NOT_IN_EVIDENCE",)
        ok, reason = self.validator.validate_evaluation(ev)
        assert not ok

    def test_snapshot_validation(self):
        rec = make_full_record()
        snap = self.evaluator.evaluate_to_snapshot(rec)
        ok, reason = self.validator.validate_snapshot(snap)
        assert ok, reason


# ---------------------------------------------------------------------------
# Evaluation store
# ---------------------------------------------------------------------------

class TestEvaluationStore:
    def setup_method(self):
        self.store = EvaluationStore(max_evaluations=10, recent_window=5)
        self.store.start_session("sess-store")
        self.evaluator = make_evaluator()

    def test_add_and_retrieve(self):
        rec = make_full_record(session_id="sess-store", seq=0)
        ev = self.evaluator.evaluate(rec)
        self.store.add_evaluation(ev)
        retrieved = self.store.get_evaluation(rec.record_id)
        assert retrieved is not None
        assert retrieved.outcome_class == ev.outcome_class

    def test_get_snapshot(self):
        rec = make_full_record(session_id="sess-store", seq=1)
        ev = self.evaluator.evaluate(rec)
        self.store.add_evaluation(ev)
        snap = self.store.get_evaluation_snapshot(rec.record_id)
        assert snap is not None
        assert snap.evaluation_id == ev.evaluation_id

    def test_store_snapshot(self):
        rec = make_cattle_crossing_record(session_id="sess-store", seq=2)
        ev = self.evaluator.evaluate(rec)
        self.store.add_evaluation(ev)
        ss = self.store.get_store_snapshot()
        assert ss.total_evaluations >= 1
        assert not ss.store_failed

    def test_get_unevaluated_ids(self):
        all_ids = ("sess-store-R000010", "sess-store-R000011")
        unevaluated = self.store.get_unevaluated_ids(all_ids)
        assert "sess-store-R000010" in unevaluated

    def test_overflow_evicts_oldest(self):
        store = EvaluationStore(max_evaluations=3)
        store.start_session("sess-ov")
        for i in range(5):
            rec = make_full_record(session_id="sess-ov", seq=i)
            ev = self.evaluator.evaluate(rec)
            store.add_evaluation(ev)
        ss = store.get_store_snapshot()
        assert ss.total_evaluations <= 3

    def test_missing_returns_none(self):
        result = self.store.get_evaluation("nonexistent-record-id")
        assert result is None

    def test_get_by_class(self):
        rec = make_cattle_crossing_record(session_id="sess-store", seq=3,
                                          cattle_cleared=True)
        ev = self.evaluator.evaluate(rec)
        self.store.add_evaluation(ev)
        successes = self.store.get_evaluated_by_class(OutcomeClass.SUCCESS)
        assert len(successes) >= 1
