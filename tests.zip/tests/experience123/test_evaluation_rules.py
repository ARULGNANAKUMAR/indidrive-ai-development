"""Tests for evaluation rule logic and evidence traceability."""
import sys, os, time
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))

from exp123_helpers import (
    make_evaluator, make_full_record, make_invalid_record,
    make_situation, make_action, make_outcome,
)
from core.experience.evaluation.evaluation_rules import (
    rule_invalid_record, rule_unsafe_outcome, rule_no_outcome,
    rule_pending, rule_failure, rule_partial_success, rule_success,
    rule_degraded, rule_inconclusive, assign_confidence,
)
from core.experience.evaluation.evaluation_types import (
    EvaluationConfidence, EvidenceKey, OutcomeEvaluatorConfig,
)
from core.experience.record.record_engine import _make_record_id
from core.experience.record.record_types import (
    RECORD_SCHEMA_VERSION, ActionType, ExperienceRecord,
    OutcomeObservationState, RecordCompleteness, AppliedAction,
)


def _make_complete_record(
    session_id="sess-r", seq=0,
    collision=False, safety="SAFE",
    hazard_after="NONE", cleared=("HAZARD_DETECTED",),
    control="ACTIVE", path="VALID", plan="ACTIVE",
    unresolved=(), obs_state=OutcomeObservationState.OBSERVED,
):
    rid = _make_record_id(session_id, seq)
    ts = time.time()
    sit = make_situation(session_id, rid, seq, ts)
    act = make_action(session_id, rid, seq, ts)
    out = make_outcome(session_id, rid, seq, ts, obs_state=obs_state)
    out.collision_detected = collision
    out.safety_state_after = safety
    out.hazard_level_after = hazard_after
    out.cleared_event_types = tuple(cleared)
    out.unresolved_event_types = tuple(unresolved)
    out.control_state_after = control
    out.path_state_after = path
    out.planning_status_after = plan
    return ExperienceRecord(
        record_id=rid, session_id=session_id, sequence_id=seq,
        schema_version=RECORD_SCHEMA_VERSION, created_timestamp=ts,
        last_updated_timestamp=ts, situation=sit, action=act, outcome=out,
        completeness=RecordCompleteness.COMPLETE,
        source_observation_id=f"{session_id}-O{seq:06d}",
    )


class TestRuleInvalidRecord:
    def test_none_is_invalid(self):
        cfg = OutcomeEvaluatorConfig.default()
        matched, ev, rc = rule_invalid_record(None, cfg)  # type: ignore
        assert matched
        assert EvidenceKey.INVALID_RECORD.value in ev

    def test_bad_schema_invalid(self):
        cfg = OutcomeEvaluatorConfig.default()
        rec = make_full_record()
        rec.schema_version = "BAD"
        matched, ev, rc = rule_invalid_record(rec, cfg)
        assert matched
        assert EvidenceKey.INVALID_SCHEMA.value in ev

    def test_valid_record_not_invalid(self):
        cfg = OutcomeEvaluatorConfig.default()
        rec = make_full_record()
        matched, _, _ = rule_invalid_record(rec, cfg)
        assert not matched


class TestRuleUnsafeOutcome:
    def test_collision_detected(self):
        cfg = OutcomeEvaluatorConfig.default()
        rec = _make_complete_record(collision=True, safety="UNSAFE")
        matched, ev, rc = rule_unsafe_outcome(rec, cfg)
        assert matched
        assert EvidenceKey.COLLISION_DETECTED.value in ev

    def test_no_collision_not_unsafe(self):
        cfg = OutcomeEvaluatorConfig.default()
        rec = _make_complete_record(collision=False, safety="SAFE")
        matched, _, _ = rule_unsafe_outcome(rec, cfg)
        assert not matched

    def test_safety_violation_is_unsafe(self):
        cfg = OutcomeEvaluatorConfig.default()
        rec = _make_complete_record(safety="VIOLATION")
        matched, ev, _ = rule_unsafe_outcome(rec, cfg)
        assert matched


class TestRuleSuccess:
    def test_success_with_hazard_cleared(self):
        cfg = OutcomeEvaluatorConfig.default()
        rec = _make_complete_record(
            collision=False, safety="SAFE",
            hazard_after="NONE", cleared=("HAZARD_DETECTED",),
            control="ACTIVE", path="VALID",
        )
        matched, ev, rc = rule_success(rec, cfg)
        assert matched
        assert EvidenceKey.HAZARD_RESOLVED.value in ev

    def test_no_success_on_collision(self):
        cfg = OutcomeEvaluatorConfig.default()
        rec = _make_complete_record(collision=True)
        matched, _, _ = rule_success(rec, cfg)
        assert not matched


class TestRuleFailure:
    def test_control_failed(self):
        cfg = OutcomeEvaluatorConfig.default()
        rec = _make_complete_record(control="FAILED")
        matched, ev, rc = rule_failure(rec, cfg)
        assert matched
        assert EvidenceKey.CONTROL_FAILED.value in ev

    def test_path_invalid(self):
        cfg = OutcomeEvaluatorConfig.default()
        rec = _make_complete_record(path="INVALID")
        matched, ev, rc = rule_failure(rec, cfg)
        assert matched
        assert EvidenceKey.PATH_INVALID_AFTER.value in ev

    def test_action_not_executed(self):
        cfg = OutcomeEvaluatorConfig.default()
        rec = _make_complete_record()
        rec.action.applied = AppliedAction(is_available=False)
        matched, ev, rc = rule_failure(rec, cfg)
        assert matched
        assert EvidenceKey.ACTION_NOT_EXECUTED.value in ev


class TestAssignConfidence:
    def test_empty_evidence_unknown(self):
        conf, unc = assign_confidence([], [], False)
        assert conf == EvaluationConfidence.UNKNOWN
        assert unc == 1.0

    def test_many_evidence_high(self):
        ev = [
            EvidenceKey.NO_COLLISION_OBSERVED.value,
            EvidenceKey.HAZARD_RESOLVED.value,
            EvidenceKey.SAFETY_MAINTAINED.value,
            EvidenceKey.VEHICLE_CONTROLLABLE.value,
        ]
        conf, unc = assign_confidence(ev, ev[:1], False)
        assert conf == EvaluationConfidence.HIGH

    def test_conflict_evidence_low(self):
        ev = [EvidenceKey.CONFLICTING_EVIDENCE.value]
        conf, unc = assign_confidence(ev, ev, False)
        assert conf == EvaluationConfidence.LOW

    def test_degraded_reduces_confidence(self):
        ev = [EvidenceKey.DEGRADED_OBSERVATION.value,
              EvidenceKey.SAFETY_MAINTAINED.value,
              EvidenceKey.NO_COLLISION_OBSERVED.value]
        conf, unc = assign_confidence(ev, ev[:1], True)
        assert conf in (EvaluationConfidence.LOW, EvaluationConfidence.MEDIUM)
