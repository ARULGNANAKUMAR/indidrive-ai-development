"""Tests for the OutcomeEvaluator core."""
import sys, os, time
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))

from exp123_helpers import (
    make_evaluator,
    make_full_record,
    make_cattle_crossing_record,
    make_emergency_record,
    make_no_outcome_record,
    make_pending_record,
    make_invalid_record,
    make_degraded_record,
    make_safe_outcome,
    make_situation,
    make_action,
    make_outcome,
)
from core.experience.evaluation.evaluation_types import (
    EvaluationStatus,
    EvidenceKey,
    OutcomeClass,
    OutcomeEvaluatorConfig,
)
from core.experience.evaluation.outcome_evaluator import OutcomeEvaluator
from core.experience.record.record_engine import _make_record_id
from core.experience.record.record_types import (
    RECORD_SCHEMA_VERSION,
    ActionType,
    ExperienceRecord,
    OutcomeObservationState,
    RecordCompleteness,
)


class TestEvaluatorConstruction:
    def test_default_config(self):
        ev = OutcomeEvaluator()
        assert ev.config is not None

    def test_explicit_config(self):
        cfg = OutcomeEvaluatorConfig.default()
        ev = OutcomeEvaluator(cfg)
        assert ev.config is cfg

    def test_wrong_config_type_raises(self):
        try:
            OutcomeEvaluator("not_a_config")  # type: ignore
            assert False
        except TypeError:
            pass


class TestEvaluatorProducesValidOutput:
    def test_returns_outcome_evaluation(self):
        ev = make_evaluator()
        rec = make_full_record()
        result = ev.evaluate(rec)
        assert result is not None
        assert result.evaluation_id.endswith("-EVAL")
        assert result.experience_id == rec.record_id

    def test_schema_version_in_output(self):
        ev = make_evaluator()
        result = ev.evaluate(make_full_record())
        assert result.schema_version == "12.3"

    def test_evaluation_timestamp_set(self):
        ev = make_evaluator()
        t0 = time.time()
        result = ev.evaluate(make_full_record())
        t1 = time.time()
        assert t0 <= result.evaluation_timestamp <= t1 + 1.0

    def test_evaluation_id_format(self):
        ev = make_evaluator()
        rec = make_full_record(session_id="s-001", seq=5)
        result = ev.evaluate(rec)
        assert result.evaluation_id == f"{rec.record_id}-EVAL"

    def test_evidence_always_present_for_complete(self):
        ev = make_evaluator()
        rec = make_full_record()
        result = ev.evaluate(rec)
        if result.evaluation_status == EvaluationStatus.COMPLETE:
            assert len(result.evidence) > 0

    def test_reason_codes_subset_of_evidence(self):
        ev = make_evaluator()
        rec = make_full_record()
        result = ev.evaluate(rec)
        ev_set = set(result.evidence)
        for rc in result.reason_codes:
            assert rc in ev_set

    def test_evaluate_to_snapshot(self):
        ev = make_evaluator()
        snap = ev.evaluate_to_snapshot(make_full_record())
        assert snap.evaluation_id is not None
        assert snap.evaluation_id.endswith("-EVAL")

    def test_none_record_returns_error_not_exception(self):
        ev = make_evaluator()
        result = ev.evaluate(None)  # type: ignore
        assert result.outcome_class == OutcomeClass.EVALUATION_ERROR
        assert result.evaluation_status == EvaluationStatus.ERROR
