"""
Tests for safety authority, failure isolation, multi-step experiences,
conflicting evidence, and Indian road scenarios.
"""
import sys, os, time
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))

from exp123_helpers import (
    make_evaluator, make_full_record, make_emergency_record,
    make_cattle_crossing_record, make_degraded_record,
    make_situation, make_action, make_outcome,
)
from core.experience.evaluation.evaluation_types import (
    OutcomeClass, EvidenceKey, EvaluationStatus,
)
from core.experience.record.record_engine import _make_record_id
from core.experience.record.record_types import (
    RECORD_SCHEMA_VERSION, ActionType, ExperienceRecord,
    OutcomeObservationState, RecordCompleteness, AppliedAction,
)


# ---------------------------------------------------------------------------
# Safety authority
# ---------------------------------------------------------------------------

class TestSafetyAuthority:
    def test_collision_overrides_positive_progress(self):
        """Even if hazard cleared, collision → UNSAFE_OUTCOME."""
        ev = make_evaluator()
        rid = _make_record_id("sess-sa", 0)
        ts = time.time()
        sit = make_situation("sess-sa", rid, 0, ts, hazard_level="HIGH")
        act = make_action("sess-sa", rid, 0, ts)
        out = make_outcome("sess-sa", rid, 0, ts,
                           obs_state=OutcomeObservationState.OBSERVED)
        out.collision_detected = True  # collision — overrides everything
        out.cleared_event_types = ("HAZARD_DETECTED",)  # positive signal
        out.safety_state_after = "UNSAFE"
        rec = ExperienceRecord(
            record_id=rid, session_id="sess-sa", sequence_id=0,
            schema_version=RECORD_SCHEMA_VERSION, created_timestamp=ts,
            last_updated_timestamp=ts, situation=sit, action=act, outcome=out,
            completeness=RecordCompleteness.COMPLETE,
            source_observation_id="sess-sa-O000000",
        )
        result = ev.evaluate(rec)
        assert result.outcome_class == OutcomeClass.UNSAFE_OUTCOME

    def test_emergency_unresolved_overrides_planner_success(self):
        """Emergency unresolved → UNSAFE, regardless of planner state."""
        ev = make_evaluator()
        rid = _make_record_id("sess-sa2", 0)
        ts = time.time()
        sit = make_situation("sess-sa2", rid, 0, ts, hazard_level="HIGH")
        sit.emergency_state = "ACTIVE"
        act = make_action("sess-sa2", rid, 0, ts,
                          action_type=ActionType.EMERGENCY_RESPONSE_STATE)
        out = make_outcome("sess-sa2", rid, 0, ts,
                           obs_state=OutcomeObservationState.OBSERVED)
        out.collision_detected = False
        out.emergency_active_after = True
        out.emergency_cleared = False      # NOT cleared
        out.planning_status_after = "ACTIVE"  # planner says OK
        out.safety_state_after = "EMERGENCY"
        rec = ExperienceRecord(
            record_id=rid, session_id="sess-sa2", sequence_id=0,
            schema_version=RECORD_SCHEMA_VERSION, created_timestamp=ts,
            last_updated_timestamp=ts, situation=sit, action=act, outcome=out,
            completeness=RecordCompleteness.COMPLETE,
            source_observation_id="sess-sa2-O000000",
        )
        result = ev.evaluate(rec)
        assert result.outcome_class == OutcomeClass.UNSAFE_OUTCOME

    def test_safety_violation_preserved(self):
        ev = make_evaluator()
        rid = _make_record_id("sess-sa3", 0)
        ts = time.time()
        sit = make_situation("sess-sa3", rid, 0, ts)
        act = make_action("sess-sa3", rid, 0, ts)
        out = make_outcome("sess-sa3", rid, 0, ts,
                           obs_state=OutcomeObservationState.OBSERVED)
        out.collision_detected = False
        out.safety_state_after = "VIOLATION"
        rec = ExperienceRecord(
            record_id=rid, session_id="sess-sa3", sequence_id=0,
            schema_version=RECORD_SCHEMA_VERSION, created_timestamp=ts,
            last_updated_timestamp=ts, situation=sit, action=act, outcome=out,
            completeness=RecordCompleteness.COMPLETE,
            source_observation_id="sess-sa3-O000000",
        )
        result = ev.evaluate(rec)
        assert result.outcome_class == OutcomeClass.UNSAFE_OUTCOME
        assert EvidenceKey.SAFETY_VIOLATION_OBSERVED.value in result.evidence


# ---------------------------------------------------------------------------
# Failure isolation
# ---------------------------------------------------------------------------

class TestEvaluationFailureIsolation:
    def test_none_record_returns_error_not_exception(self):
        ev = make_evaluator()
        result = ev.evaluate(None)  # type: ignore
        assert result is not None
        assert result.outcome_class == OutcomeClass.EVALUATION_ERROR
        # Must NOT raise

    def test_missing_fields_record_does_not_crash(self):
        ev = make_evaluator()
        # Minimal empty record
        from core.experience.record.record_types import ExperienceRecord
        rec = ExperienceRecord()
        result = ev.evaluate(rec)
        assert result is not None  # must not raise

    def test_evaluation_error_not_pipeline_error(self):
        """Evaluation errors are isolated — pipeline must continue."""
        ev = make_evaluator()
        result = ev.evaluate(None)  # type: ignore
        # Must produce an OutcomeEvaluation, not raise
        assert hasattr(result, "outcome_class")
        assert hasattr(result, "evaluation_error")

    def test_evaluation_error_has_error_text(self):
        ev = make_evaluator()
        result = ev.evaluate(None)  # type: ignore
        assert result.evaluation_error != "NOT_AVAILABLE"
        assert len(result.evaluation_error) > 0


# ---------------------------------------------------------------------------
# Multi-event / multi-step experiences
# ---------------------------------------------------------------------------

class TestMultiStepExperience:
    def test_cattle_stop_then_clear(self):
        """Cattle detected → brake → stop → cattle clears = SUCCESS."""
        ev = make_evaluator()
        rec = make_cattle_crossing_record(cattle_cleared=True)
        result = ev.evaluate(rec)
        assert result.outcome_class == OutcomeClass.SUCCESS
        assert EvidenceKey.CATTLE_EVENT_CLEARED.value in result.evidence

    def test_cattle_stop_not_cleared(self):
        """Cattle detected → brake → stop → cattle NOT cleared = PARTIAL_SUCCESS."""
        ev = make_evaluator()
        rec = make_cattle_crossing_record(cattle_cleared=False)
        result = ev.evaluate(rec)
        # Vehicle stopped safely but hazard remained → PARTIAL_SUCCESS
        assert result.outcome_class in (
            OutcomeClass.PARTIAL_SUCCESS, OutcomeClass.INCONCLUSIVE,
            OutcomeClass.DEGRADED
        )

    def test_emergency_cleared_is_partial_success(self):
        """Emergency detected → response → emergency cleared = PARTIAL_SUCCESS."""
        ev = make_evaluator()
        rec = make_emergency_record(emergency_cleared=True)
        result = ev.evaluate(rec)
        assert result.outcome_class == OutcomeClass.PARTIAL_SUCCESS

    def test_emergency_unresolved_is_unsafe(self):
        """Emergency → response → still active = UNSAFE_OUTCOME."""
        ev = make_evaluator()
        rec = make_emergency_record(emergency_cleared=False)
        result = ev.evaluate(rec)
        assert result.outcome_class == OutcomeClass.UNSAFE_OUTCOME


# ---------------------------------------------------------------------------
# Conflicting evidence
# ---------------------------------------------------------------------------

class TestConflictingEvidence:
    def test_unknown_obs_state_inconclusive(self):
        ev = make_evaluator()
        rid = _make_record_id("sess-ce", 0)
        ts = time.time()
        sit = make_situation("sess-ce", rid, 0, ts)
        act = make_action("sess-ce", rid, 0, ts)
        out = make_outcome("sess-ce", rid, 0, ts,
                           obs_state=OutcomeObservationState.UNKNOWN)
        rec = ExperienceRecord(
            record_id=rid, session_id="sess-ce", sequence_id=0,
            schema_version=RECORD_SCHEMA_VERSION, created_timestamp=ts,
            last_updated_timestamp=ts, situation=sit, action=act, outcome=out,
            completeness=RecordCompleteness.COMPLETE,
            source_observation_id="sess-ce-O000000",
        )
        result = ev.evaluate(rec)
        assert result.outcome_class == OutcomeClass.INCONCLUSIVE
        assert EvidenceKey.CONFLICTING_EVIDENCE.value in result.evidence

    def test_planner_ok_control_failed_conflict(self):
        ev = make_evaluator()
        rid = _make_record_id("sess-ce2", 0)
        ts = time.time()
        sit = make_situation("sess-ce2", rid, 0, ts)
        act = make_action("sess-ce2", rid, 0, ts)
        out = make_outcome("sess-ce2", rid, 0, ts,
                           obs_state=OutcomeObservationState.OBSERVED)
        out.collision_detected = False
        out.planning_status_after = "ACTIVE"   # planner OK
        out.control_state_after = "FAILED"     # control bad
        out.safety_state_after = "SAFE"
        out.path_state_after = "VALID"
        rec = ExperienceRecord(
            record_id=rid, session_id="sess-ce2", sequence_id=0,
            schema_version=RECORD_SCHEMA_VERSION, created_timestamp=ts,
            last_updated_timestamp=ts, situation=sit, action=act, outcome=out,
            completeness=RecordCompleteness.COMPLETE,
            source_observation_id="sess-ce2-O000000",
        )
        result = ev.evaluate(rec)
        # Control failed → FAILURE takes priority over conflict
        assert result.outcome_class in (
            OutcomeClass.FAILURE, OutcomeClass.INCONCLUSIVE
        )


# ---------------------------------------------------------------------------
# Indian road scenarios
# ---------------------------------------------------------------------------

class TestIndianRoadEvaluation:
    """
    Verifies evaluation of the 10 Indian road scenarios.
    Evidence-based evaluation — not hard-coded outcomes.
    """

    def _make_record(self, session_id, seq, hazard, action_type,
                     cleared=(), unresolved=(), collision=False,
                     safety="SAFE", plan="ACTIVE", path="VALID",
                     control="ACTIVE", ego_speed=3.0, obs_state=None):
        rid = _make_record_id(session_id, seq)
        ts = time.time()
        sit = make_situation(session_id, rid, seq, ts, hazard_level=hazard)
        act = make_action(session_id, rid, seq, ts, action_type=action_type)
        out = make_outcome(session_id, rid, seq, ts,
                           obs_state=obs_state or OutcomeObservationState.OBSERVED)
        out.collision_detected = collision
        out.safety_state_after = safety
        out.cleared_event_types = tuple(cleared)
        out.unresolved_event_types = tuple(unresolved)
        out.planning_status_after = plan
        out.path_state_after = path
        out.control_state_after = control
        out.ego_speed_after_ms = ego_speed
        out.hazard_level_after = "NONE" if cleared else hazard
        return ExperienceRecord(
            record_id=rid, session_id=session_id, sequence_id=seq,
            schema_version=RECORD_SCHEMA_VERSION, created_timestamp=ts,
            last_updated_timestamp=ts, situation=sit, action=act, outcome=out,
            completeness=RecordCompleteness.COMPLETE,
            source_observation_id=f"{session_id}-O{seq:06d}",
        )

    def test_1_unmarked_village_road_normal(self):
        ev = make_evaluator()
        rec = self._make_record("ind-1", 0, "LOW",
                                ActionType.FOLLOW_REFERENCE,
                                cleared=("UNMARKED_ROAD_EVENT",))
        result = ev.evaluate(rec)
        assert result.outcome_class == OutcomeClass.SUCCESS

    def test_2_unsignalized_intersection_cleared(self):
        ev = make_evaluator()
        rec = self._make_record("ind-2", 0, "MEDIUM",
                                ActionType.SLOW_DOWN,
                                cleared=("INTERSECTION_EVENT",))
        result = ev.evaluate(rec)
        assert result.outcome_class == OutcomeClass.SUCCESS

    def test_3_highway_merge_success(self):
        ev = make_evaluator()
        rec = self._make_record("ind-3", 0, "MEDIUM",
                                ActionType.ADAPT_PATH,
                                cleared=("HIGHWAY_MERGE_EVENT",))
        result = ev.evaluate(rec)
        assert result.outcome_class == OutcomeClass.SUCCESS

    def test_4_dense_market_partial(self):
        ev = make_evaluator()
        rec = self._make_record("ind-4", 0, "HIGH",
                                ActionType.SLOW_DOWN,
                                cleared=(),
                                unresolved=("MIXED_TRAFFIC_EVENT",))
        result = ev.evaluate(rec)
        # Dense market: unresolved events present; result is context-dependent.
        # Must be evaluated (not PENDING/INVALID/ERROR) and traceable.
        assert result.outcome_class not in (
            OutcomeClass.PENDING, OutcomeClass.INVALID, OutcomeClass.EVALUATION_ERROR
        )
        assert len(result.evidence) > 0

    def test_5_cattle_cleared(self):
        ev = make_evaluator()
        rec = make_cattle_crossing_record(cattle_cleared=True)
        result = ev.evaluate(rec)
        assert result.outcome_class == OutcomeClass.SUCCESS

    def test_5_cattle_collision(self):
        ev = make_evaluator()
        rid = _make_record_id("ind-5c", 0)
        ts = time.time()
        sit = make_situation("ind-5c", rid, 0, ts, hazard_level="HIGH", cattle=True)
        act = make_action("ind-5c", rid, 0, ts, action_type=ActionType.STOP)
        out = make_outcome("ind-5c", rid, 0, ts,
                           obs_state=OutcomeObservationState.OBSERVED)
        out.collision_detected = True
        out.safety_state_after = "UNSAFE"
        rec = ExperienceRecord(
            record_id=rid, session_id="ind-5c", sequence_id=0,
            schema_version=RECORD_SCHEMA_VERSION, created_timestamp=ts,
            last_updated_timestamp=ts, situation=sit, action=act, outcome=out,
            completeness=RecordCompleteness.COMPLETE,
            source_observation_id="ind-5c-O000000",
        )
        result = ev.evaluate(rec)
        assert result.outcome_class == OutcomeClass.UNSAFE_OUTCOME

    def test_6_mixed_traffic_vru_cleared(self):
        ev = make_evaluator()
        rec = self._make_record("ind-6", 0, "HIGH",
                                ActionType.SLOW_DOWN,
                                cleared=("VULNERABLE_USER_EVENT",))
        result = ev.evaluate(rec)
        assert result.outcome_class == OutcomeClass.SUCCESS
        assert EvidenceKey.VRU_EVENT_CLEARED.value in result.evidence

    def test_7_narrow_road_adapt(self):
        ev = make_evaluator()
        rec = self._make_record("ind-7", 0, "MEDIUM",
                                ActionType.ADAPT_PATH,
                                cleared=("NARROW_ROAD_EVENT",))
        result = ev.evaluate(rec)
        assert result.outcome_class == OutcomeClass.SUCCESS

    def test_8_pothole_road_damage_replanning(self):
        ev = make_evaluator()
        rid = _make_record_id("ind-8", 0)
        ts = time.time()
        sit = make_situation("ind-8", rid, 0, ts, hazard_level="MEDIUM")
        sit.road_hazard_present = True
        act = make_action("ind-8", rid, 0, ts, action_type=ActionType.REPLAN)
        out = make_outcome("ind-8", rid, 0, ts,
                           obs_state=OutcomeObservationState.OBSERVED)
        out.collision_detected = False
        out.safety_state_after = "SAFE"
        out.replanning_occurred = True
        out.cleared_event_types = ("ROAD_HAZARD_EVENT",)
        out.hazard_level_after = "NONE"
        rec = ExperienceRecord(
            record_id=rid, session_id="ind-8", sequence_id=0,
            schema_version=RECORD_SCHEMA_VERSION, created_timestamp=ts,
            last_updated_timestamp=ts, situation=sit, action=act, outcome=out,
            completeness=RecordCompleteness.COMPLETE,
            source_observation_id="ind-8-O000000",
        )
        result = ev.evaluate(rec)
        # Replanning occurred + hazard cleared: PARTIAL_SUCCESS or SUCCESS
        # (replanning signal fires first in priority, but evidence of cleared hazard
        #  may elevate to SUCCESS depending on rule ordering)
        assert result.outcome_class in (
            OutcomeClass.PARTIAL_SUCCESS, OutcomeClass.SUCCESS
        )
        assert len(result.evidence) > 0

    def test_9_temporary_obstacle_cleared(self):
        ev = make_evaluator()
        rec = self._make_record("ind-9", 0, "HIGH",
                                ActionType.STOP,
                                cleared=("ROAD_HAZARD_EVENT",),
                                ego_speed=0.0)
        result = ev.evaluate(rec)
        assert result.outcome_class == OutcomeClass.SUCCESS

    def test_10_wrong_side_traffic_inconclusive(self):
        ev = make_evaluator()
        rid = _make_record_id("ind-10", 0)
        ts = time.time()
        sit = make_situation("ind-10", rid, 0, ts, hazard_level="HIGH")
        act = make_action("ind-10", rid, 0, ts, action_type=ActionType.SLOW_DOWN)
        out = make_outcome("ind-10", rid, 0, ts,
                           obs_state=OutcomeObservationState.UNKNOWN)
        out.collision_detected = False
        rec = ExperienceRecord(
            record_id=rid, session_id="ind-10", sequence_id=0,
            schema_version=RECORD_SCHEMA_VERSION, created_timestamp=ts,
            last_updated_timestamp=ts, situation=sit, action=act, outcome=out,
            completeness=RecordCompleteness.COMPLETE,
            source_observation_id="ind-10-O000000",
        )
        result = ev.evaluate(rec)
        assert result.outcome_class == OutcomeClass.INCONCLUSIVE
