"""Tests for SUCCESS outcome classification."""
import sys, os, time
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))

from exp123_helpers import (
    make_evaluator, make_full_record, make_cattle_crossing_record,
    make_situation, make_action, make_outcome, make_safe_outcome,
)
from core.experience.evaluation.evaluation_types import OutcomeClass, EvidenceKey
from core.experience.record.record_engine import _make_record_id
from core.experience.record.record_types import (
    RECORD_SCHEMA_VERSION, ActionType, ExperienceRecord,
    OutcomeObservationState, RecordCompleteness,
)


def _make_success_record(session_id="sess-s", seq=0, cleared=("HAZARD_DETECTED",)):
    rid = _make_record_id(session_id, seq)
    ts = time.time()
    sit = make_situation(session_id, rid, seq, ts, hazard_level="LOW")
    act = make_action(session_id, rid, seq, ts, action_type=ActionType.FOLLOW_REFERENCE)
    out = make_safe_outcome(session_id=session_id, record_id=rid, seq=seq,
                            action_timestamp=ts, hazard_after="NONE",
                            cleared_events=cleared)
    return ExperienceRecord(
        record_id=rid, session_id=session_id, sequence_id=seq,
        schema_version=RECORD_SCHEMA_VERSION, created_timestamp=ts,
        last_updated_timestamp=ts, situation=sit, action=act, outcome=out,
        completeness=RecordCompleteness.COMPLETE,
        source_observation_id=f"{session_id}-O{seq:06d}",
    )


class TestSuccessClassification:
    def test_normal_driving_success(self):
        ev = make_evaluator()
        rec = _make_success_record()
        result = ev.evaluate(rec)
        assert result.outcome_class == OutcomeClass.SUCCESS

    def test_cattle_cleared_is_success(self):
        ev = make_evaluator()
        rec = make_cattle_crossing_record(cattle_cleared=True)
        result = ev.evaluate(rec)
        assert result.outcome_class == OutcomeClass.SUCCESS

    def test_hazard_resolved_evidence_present(self):
        ev = make_evaluator()
        rec = _make_success_record(cleared=("HAZARD_DETECTED",))
        result = ev.evaluate(rec)
        assert result.outcome_class == OutcomeClass.SUCCESS
        assert EvidenceKey.HAZARD_RESOLVED.value in result.evidence

    def test_no_collision_evidence_present(self):
        ev = make_evaluator()
        rec = _make_success_record()
        result = ev.evaluate(rec)
        assert EvidenceKey.NO_COLLISION_OBSERVED.value in result.evidence

    def test_success_requires_positive_evidence(self):
        """No collision alone is insufficient for SUCCESS."""
        ev = make_evaluator()
        rid = _make_record_id("sess-bare", 0)
        ts = time.time()
        sit = make_situation("sess-bare", rid, 0, ts)
        act = make_action("sess-bare", rid, 0, ts)
        out = make_outcome("sess-bare", rid, 0, ts,
                           obs_state=OutcomeObservationState.OBSERVED)
        out.collision_detected = False
        # No cleared_event_types, no safety state, no path state — ambiguous
        out.cleared_event_types = ()
        out.unresolved_event_types = ("SOME_EVENT",)
        out.hazard_level_after = "MEDIUM"
        out.control_state_after = "NOT_AVAILABLE"
        out.safety_state_after = "NOT_AVAILABLE"
        rec = ExperienceRecord(
            record_id=rid, session_id="sess-bare", sequence_id=0,
            schema_version=RECORD_SCHEMA_VERSION, created_timestamp=ts,
            last_updated_timestamp=ts, situation=sit, action=act, outcome=out,
            completeness=RecordCompleteness.COMPLETE,
            source_observation_id="sess-bare-O000000",
        )
        result = ev.evaluate(rec)
        # With unresolved events and no positive indicators, must not be SUCCESS
        assert result.outcome_class != OutcomeClass.SUCCESS

    def test_cattle_cleared_evidence_in_reason_codes(self):
        ev = make_evaluator()
        rec = make_cattle_crossing_record(cattle_cleared=True)
        result = ev.evaluate(rec)
        assert result.outcome_class == OutcomeClass.SUCCESS
        assert len(result.reason_codes) > 0
