"""Tests for Phase 12.3 evaluation_types module."""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))

from core.experience.evaluation.evaluation_types import (
    EVALUATION_SCHEMA_VERSION,
    NOT_AVAILABLE,
    OutcomeClass,
    EvaluationConfidence,
    EvaluationStatus,
    EvidenceKey,
    OutcomeEvaluation,
    OutcomeEvaluationSnapshot,
    OutcomeEvaluatorConfig,
)


class TestSchemaVersion:
    def test_schema_version_is_12_3(self):
        assert EVALUATION_SCHEMA_VERSION == "12.3"

    def test_sentinel(self):
        assert NOT_AVAILABLE == "NOT_AVAILABLE"


class TestOutcomeClass:
    def test_all_required_classes_present(self):
        values = {c.value for c in OutcomeClass}
        assert "SUCCESS" in values
        assert "PARTIAL_SUCCESS" in values
        assert "FAILURE" in values
        assert "UNSAFE_OUTCOME" in values
        assert "NO_OUTCOME" in values
        assert "INCONCLUSIVE" in values
        assert "DEGRADED" in values
        assert "INVALID" in values
        assert "PENDING" in values
        assert "NOT_EVALUATED" in values
        assert "EVALUATION_ERROR" in values

    def test_is_str_enum(self):
        assert OutcomeClass.SUCCESS == "SUCCESS"
        assert OutcomeClass.FAILURE == "FAILURE"


class TestEvaluationConfidence:
    def test_all_levels_present(self):
        values = {c.value for c in EvaluationConfidence}
        assert "HIGH" in values
        assert "MEDIUM" in values
        assert "LOW" in values
        assert "UNKNOWN" in values


class TestEvidenceKey:
    def test_safety_keys_present(self):
        keys = {e.value for e in EvidenceKey}
        assert "COLLISION_DETECTED" in keys
        assert "NO_COLLISION_OBSERVED" in keys
        assert "EMERGENCY_TRIGGERED" in keys
        assert "EMERGENCY_CLEARED" in keys
        assert "SAFETY_MAINTAINED" in keys

    def test_data_quality_keys_present(self):
        keys = {e.value for e in EvidenceKey}
        assert "OUTCOME_MISSING" in keys
        assert "OBSERVATION_INCOMPLETE" in keys
        assert "CONFLICTING_EVIDENCE" in keys
        assert "INVALID_RECORD" in keys

    def test_cattle_keys_present(self):
        keys = {e.value for e in EvidenceKey}
        assert "CATTLE_EVENT_CLEARED" in keys
        assert "CATTLE_EVENT_UNRESOLVED" in keys


class TestOutcomeEvaluationDefaults:
    def test_default_state(self):
        ev = OutcomeEvaluation()
        assert ev.outcome_class == OutcomeClass.NOT_EVALUATED
        assert ev.evaluation_status == EvaluationStatus.PENDING
        assert ev.confidence == EvaluationConfidence.UNKNOWN
        assert ev.uncertainty == 1.0
        assert ev.evidence == ()
        assert ev.reason_codes == ()
        assert ev.schema_version == EVALUATION_SCHEMA_VERSION

    def test_to_dict_includes_required_keys(self):
        ev = OutcomeEvaluation(
            evaluation_id="REC-001-EVAL",
            experience_id="REC-001",
            session_id="sess-001",
            evaluation_timestamp=1000.0,
        )
        d = ev.to_dict()
        assert "evaluation_id" in d
        assert "outcome_class" in d
        assert "evidence" in d
        assert "reason_codes" in d
        assert "confidence" in d
        assert "uncertainty" in d
        assert "is_degraded" in d


class TestOutcomeEvaluationSnapshot:
    def test_immutable(self):
        snap = OutcomeEvaluationSnapshot(
            evaluation_id="X-EVAL",
            experience_id="X",
            session_id="s",
            evaluation_timestamp=1.0,
        )
        try:
            snap.outcome_class = OutcomeClass.SUCCESS  # type: ignore
            assert False, "Should have raised"
        except (AttributeError, TypeError):
            pass  # frozen dataclass raises one of these

    def test_to_dict(self):
        snap = OutcomeEvaluationSnapshot(
            evaluation_id="X-EVAL",
            experience_id="X",
            session_id="s",
            evaluation_timestamp=1.0,
        )
        d = snap.to_dict()
        assert d["evaluation_id"] == "X-EVAL"
        assert d["outcome_class"] == "NOT_EVALUATED"


class TestOutcomeEvaluatorConfig:
    def test_defaults(self):
        cfg = OutcomeEvaluatorConfig.default()
        assert cfg.allow_early_evaluation is False
        assert cfg.stopped_speed_threshold_ms > 0
        assert len(cfg.safe_hazard_levels) > 0

    def test_to_dict(self):
        cfg = OutcomeEvaluatorConfig.default()
        d = cfg.to_dict()
        assert "allow_early_evaluation" in d
        assert "safe_hazard_levels" in d
