"""
Tests for PARTIAL_SUCCESS, FAILURE, UNSAFE_OUTCOME, NO_OUTCOME,
INCONCLUSIVE, INVALID, DEGRADED, PENDING classifications.
"""
import sys, os, time
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))

from exp123_helpers import (
    make_evaluator,
    make_full_record,
    make_collision_outcome,
    make_emergency_record,
    make_no_outcome_record,
    make_pending_record,
    make_invalid_record,
    make_degraded_record,
    make_situation,
    make_action,
    make_outcome,
)
from core.experience.evaluation.evaluation_types import (
    OutcomeClass, EvidenceKey, EvaluationStatus,
)
from core.experience.record.record_engine import _make_record_id
from core.experience.record.record_types import (
    RECORD_SCHEMA_VERSION, ActionType, AppliedAction, ExperienceRecord,
    OutcomeObservationState, RecordCompleteness, RequestedAction, ActionSource,
    ActionRecord,
)


# ---------------------------------------------------------------------------
# INVALID
# ---------------------------------------------------------------------------

class TestInvalidClassification:
    def test_none_record_gives_error(self):
        ev = make_evaluator()
        result = ev.evaluate(None)  # type: ignore
        assert result.outcome_class == OutcomeClass.EVALUATION_ERROR

    def test_invalid_completeness_state(self):
        ev = make_evaluator()
        rec = make_invalid_record()
        result = ev.evaluate(rec)
        assert result.outcome_class == OutcomeClass.INVALID

    def test_bad_schema_version(self):
        ev = make_evaluator()
        rec = make_full_record()
        rec.schema_version = "0.0"
        result = ev.evaluate(rec)
        assert result.outcome_class == OutcomeClass.INVALID

    def test_missing_record_id(self):
        ev = make_evaluator()
        rec = make_full_record()
        rec.record_id = "NOT_AVAILABLE"
        result = ev.evaluate(rec)
        assert result.outcome_class == OutcomeClass.INVALID

    def test_negative_timestamp(self):
        ev = make_evaluator()
        rec = make_full_record()
        rec.created_timestamp = -1.0
        result = ev.evaluate(rec)
        assert result.outcome_class == OutcomeClass.INVALID

    def test_invalid_reason_code_present(self):
        ev = make_evaluator()
        rec = make_invalid_record()
        result = ev.evaluate(rec)
        invalid_keys = {
            EvidenceKey.INVALID_RECORD.value,
            EvidenceKey.INVALID_IDS.value,
            EvidenceKey.INVALID_SCHEMA.value,
            EvidenceKey.INVALID_TIMESTAMPS.value,
        }
        assert bool(set(result.evidence) & invalid_keys)


# ---------------------------------------------------------------------------
# UNSAFE_OUTCOME
# ---------------------------------------------------------------------------

class TestUnsafeOutcomeClassification:
    def test_collision_detected(self):
        ev = make_evaluator()
        rid = _make_record_id("sess-u", 0)
        ts = time.time()
        sit = make_situation("sess-u", rid, 0, ts)
        act = make_action("sess-u", rid, 0, ts)
        out = make_collision_outcome("sess-u", rid, 0)
        rec = ExperienceRecord(
            record_id=rid, session_id="sess-u", sequence_id=0,
            schema_version=RECORD_SCHEMA_VERSION, created_timestamp=ts,
            last_updated_timestamp=ts, situation=sit, action=act, outcome=out,
            completeness=RecordCompleteness.COMPLETE,
            source_observation_id="sess-u-O000000",
        )
        result = ev.evaluate(rec)
        assert result.outcome_class == OutcomeClass.UNSAFE_OUTCOME

    def test_collision_evidence_present(self):
        ev = make_evaluator()
        rid = _make_record_id("sess-u2", 0)
        ts = time.time()
        sit = make_situation("sess-u2", rid, 0, ts)
        act = make_action("sess-u2", rid, 0, ts)
        out = make_collision_outcome("sess-u2", rid, 0)
        rec = ExperienceRecord(
            record_id=rid, session_id="sess-u2", sequence_id=0,
            schema_version=RECORD_SCHEMA_VERSION, created_timestamp=ts,
            last_updated_timestamp=ts, situation=sit, action=act, outcome=out,
            completeness=RecordCompleteness.COMPLETE,
            source_observation_id="sess-u2-O000000",
        )
        result = ev.evaluate(rec)
        assert EvidenceKey.COLLISION_DETECTED.value in result.evidence

    def test_unresolved_emergency_is_unsafe(self):
        ev = make_evaluator()
        rec = make_emergency_record(emergency_cleared=False)
        result = ev.evaluate(rec)
        assert result.outcome_class == OutcomeClass.UNSAFE_OUTCOME

    def test_safety_violation_in_after_state(self):
        ev = make_evaluator()
        rid = _make_record_id("sess-u3", 0)
        ts = time.time()
        sit = make_situation("sess-u3", rid, 0, ts)
        act = make_action("sess-u3", rid, 0, ts)
        out = make_outcome("sess-u3", rid, 0, ts,
                           obs_state=OutcomeObservationState.OBSERVED)
        out.collision_detected = False
        out.safety_state_after = "VIOLATION"
        rec = ExperienceRecord(
            record_id=rid, session_id="sess-u3", sequence_id=0,
            schema_version=RECORD_SCHEMA_VERSION, created_timestamp=ts,
            last_updated_timestamp=ts, situation=sit, action=act, outcome=out,
            completeness=RecordCompleteness.COMPLETE,
            source_observation_id="sess-u3-O000000",
        )
        result = ev.evaluate(rec)
        assert result.outcome_class == OutcomeClass.UNSAFE_OUTCOME


# ---------------------------------------------------------------------------
# NO_OUTCOME
# ---------------------------------------------------------------------------

class TestNoOutcomeClassification:
    def test_no_outcome_when_outcome_missing(self):
        ev = make_evaluator()
        rec = make_no_outcome_record()
        result = ev.evaluate(rec)
        assert result.outcome_class == OutcomeClass.NO_OUTCOME

    def test_no_outcome_evidence_present(self):
        ev = make_evaluator()
        rec = make_no_outcome_record()
        result = ev.evaluate(rec)
        assert EvidenceKey.OUTCOME_MISSING.value in result.evidence

    def test_missing_obs_state_gives_no_outcome(self):
        ev = make_evaluator()
        rid = _make_record_id("sess-n", 0)
        ts = time.time()
        sit = make_situation("sess-n", rid, 0, ts)
        act = make_action("sess-n", rid, 0, ts)
        out = make_outcome("sess-n", rid, 0, ts,
                           obs_state=OutcomeObservationState.MISSING)
        rec = ExperienceRecord(
            record_id=rid, session_id="sess-n", sequence_id=0,
            schema_version=RECORD_SCHEMA_VERSION, created_timestamp=ts,
            last_updated_timestamp=ts, situation=sit, action=act, outcome=out,
            completeness=RecordCompleteness.COMPLETE,
            source_observation_id="sess-n-O000000",
        )
        result = ev.evaluate(rec)
        assert result.outcome_class == OutcomeClass.NO_OUTCOME


# ---------------------------------------------------------------------------
# PENDING
# ---------------------------------------------------------------------------

class TestPendingClassification:
    def test_pending_when_window_open(self):
        ev = make_evaluator(allow_early=False)
        rec = make_pending_record()
        result = ev.evaluate(rec)
        assert result.outcome_class == OutcomeClass.PENDING
        assert result.evaluation_status == EvaluationStatus.PENDING

    def test_pending_evidence(self):
        ev = make_evaluator(allow_early=False)
        rec = make_pending_record()
        result = ev.evaluate(rec)
        assert EvidenceKey.OBSERVATION_WINDOW_OPEN.value in result.evidence

    def test_early_evaluation_allowed_bypasses_pending(self):
        ev = make_evaluator(allow_early=True)
        rec = make_pending_record()
        result = ev.evaluate(rec)
        # Should NOT be PENDING when early evaluation is allowed
        assert result.outcome_class != OutcomeClass.PENDING


# ---------------------------------------------------------------------------
# FAILURE
# ---------------------------------------------------------------------------

class TestFailureClassification:
    def test_action_not_executed_is_failure(self):
        ev = make_evaluator()
        rid = _make_record_id("sess-f", 0)
        ts = time.time()
        sit = make_situation("sess-f", rid, 0, ts)
        act = make_action("sess-f", rid, 0, ts)
        act.applied = AppliedAction(is_available=False)
        out = make_outcome("sess-f", rid, 0, ts,
                           obs_state=OutcomeObservationState.OBSERVED)
        out.collision_detected = False
        out.safety_state_after = "SAFE"
        out.control_state_after = "FAILED"
        rec = ExperienceRecord(
            record_id=rid, session_id="sess-f", sequence_id=0,
            schema_version=RECORD_SCHEMA_VERSION, created_timestamp=ts,
            last_updated_timestamp=ts, situation=sit, action=act, outcome=out,
            completeness=RecordCompleteness.COMPLETE,
            source_observation_id="sess-f-O000000",
        )
        result = ev.evaluate(rec)
        assert result.outcome_class == OutcomeClass.FAILURE

    def test_control_failed_in_after_state(self):
        ev = make_evaluator()
        rid = _make_record_id("sess-f2", 0)
        ts = time.time()
        sit = make_situation("sess-f2", rid, 0, ts)
        act = make_action("sess-f2", rid, 0, ts)
        out = make_outcome("sess-f2", rid, 0, ts,
                           obs_state=OutcomeObservationState.OBSERVED)
        out.collision_detected = False
        out.safety_state_after = "SAFE"
        out.control_state_after = "FAILED"
        rec = ExperienceRecord(
            record_id=rid, session_id="sess-f2", sequence_id=0,
            schema_version=RECORD_SCHEMA_VERSION, created_timestamp=ts,
            last_updated_timestamp=ts, situation=sit, action=act, outcome=out,
            completeness=RecordCompleteness.COMPLETE,
            source_observation_id="sess-f2-O000000",
        )
        result = ev.evaluate(rec)
        assert result.outcome_class == OutcomeClass.FAILURE
        assert EvidenceKey.CONTROL_FAILED.value in result.evidence

    def test_path_invalid_is_failure(self):
        ev = make_evaluator()
        rid = _make_record_id("sess-f3", 0)
        ts = time.time()
        sit = make_situation("sess-f3", rid, 0, ts)
        act = make_action("sess-f3", rid, 0, ts)
        out = make_outcome("sess-f3", rid, 0, ts,
                           obs_state=OutcomeObservationState.OBSERVED)
        out.collision_detected = False
        out.path_state_after = "INVALID"
        rec = ExperienceRecord(
            record_id=rid, session_id="sess-f3", sequence_id=0,
            schema_version=RECORD_SCHEMA_VERSION, created_timestamp=ts,
            last_updated_timestamp=ts, situation=sit, action=act, outcome=out,
            completeness=RecordCompleteness.COMPLETE,
            source_observation_id="sess-f3-O000000",
        )
        result = ev.evaluate(rec)
        assert result.outcome_class == OutcomeClass.FAILURE


# ---------------------------------------------------------------------------
# PARTIAL_SUCCESS
# ---------------------------------------------------------------------------

class TestPartialSuccessClassification:
    def test_emergency_cleared_is_partial_success(self):
        ev = make_evaluator()
        rec = make_emergency_record(emergency_cleared=True)
        result = ev.evaluate(rec)
        assert result.outcome_class == OutcomeClass.PARTIAL_SUCCESS

    def test_replanning_occurred_gives_partial(self):
        ev = make_evaluator()
        rid = _make_record_id("sess-ps", 0)
        ts = time.time()
        sit = make_situation("sess-ps", rid, 0, ts, hazard_level="HIGH")
        act = make_action("sess-ps", rid, 0, ts, action_type=ActionType.REPLAN)
        out = make_outcome("sess-ps", rid, 0, ts,
                           obs_state=OutcomeObservationState.OBSERVED)
        out.collision_detected = False
        out.safety_state_after = "SAFE"
        out.replanning_occurred = True
        out.cleared_event_types = ()
        out.unresolved_event_types = ()
        out.hazard_level_after = "LOW"
        rec = ExperienceRecord(
            record_id=rid, session_id="sess-ps", sequence_id=0,
            schema_version=RECORD_SCHEMA_VERSION, created_timestamp=ts,
            last_updated_timestamp=ts, situation=sit, action=act, outcome=out,
            completeness=RecordCompleteness.COMPLETE,
            source_observation_id="sess-ps-O000000",
        )
        result = ev.evaluate(rec)
        assert result.outcome_class == OutcomeClass.PARTIAL_SUCCESS

    def test_cattle_uncleared_but_stopped_safely(self):
        ev = make_evaluator()
        rec = make_emergency_record(emergency_cleared=True)
        result = ev.evaluate(rec)
        assert result.outcome_class == OutcomeClass.PARTIAL_SUCCESS

    def test_partial_evidence_present(self):
        ev = make_evaluator()
        rec = make_emergency_record(emergency_cleared=True)
        result = ev.evaluate(rec)
        assert EvidenceKey.EMERGENCY_CLEARED.value in result.evidence


# ---------------------------------------------------------------------------
# DEGRADED
# ---------------------------------------------------------------------------

class TestDegradedClassification:
    def test_degraded_system_gives_degraded(self):
        ev = make_evaluator()
        rec = make_degraded_record()
        result = ev.evaluate(rec)
        assert result.outcome_class in (
            OutcomeClass.DEGRADED, OutcomeClass.PARTIAL_SUCCESS, OutcomeClass.INCONCLUSIVE
        )
        # Must reflect degraded state
        assert result.is_degraded

    def test_degraded_evidence_present(self):
        ev = make_evaluator()
        rec = make_degraded_record()
        result = ev.evaluate(rec)
        ev_set = set(result.evidence)
        degraded_keys = {
            EvidenceKey.DEGRADED_OBSERVATION.value,
            EvidenceKey.DEGRADED_SYSTEM_STATE.value,
            EvidenceKey.FAIL_SAFE_ACTIVE.value,
        }
        assert ev_set & degraded_keys  # at least one degraded key present


# ---------------------------------------------------------------------------
# INCONCLUSIVE
# ---------------------------------------------------------------------------

class TestInconclusiveClassification:
    def test_no_situation_is_inconclusive(self):
        ev = make_evaluator()
        rid = _make_record_id("sess-i", 0)
        ts = time.time()
        act = make_action("sess-i", rid, 0, ts)
        out = make_outcome("sess-i", rid, 0, ts,
                           obs_state=OutcomeObservationState.OBSERVED)
        rec = ExperienceRecord(
            record_id=rid, session_id="sess-i", sequence_id=0,
            schema_version=RECORD_SCHEMA_VERSION, created_timestamp=ts,
            last_updated_timestamp=ts, situation=None, action=act, outcome=out,
            completeness=RecordCompleteness.PARTIAL,
            source_observation_id="sess-i-O000000",
        )
        result = ev.evaluate(rec)
        assert result.outcome_class == OutcomeClass.INCONCLUSIVE

    def test_conflicting_evidence_code_present(self):
        ev = make_evaluator()
        rid = _make_record_id("sess-i2", 0)
        ts = time.time()
        sit = make_situation("sess-i2", rid, 0, ts)
        act = make_action("sess-i2", rid, 0, ts)
        out = make_outcome("sess-i2", rid, 0, ts,
                           obs_state=OutcomeObservationState.UNKNOWN)
        rec = ExperienceRecord(
            record_id=rid, session_id="sess-i2", sequence_id=0,
            schema_version=RECORD_SCHEMA_VERSION, created_timestamp=ts,
            last_updated_timestamp=ts, situation=sit, action=act, outcome=out,
            completeness=RecordCompleteness.COMPLETE,
            source_observation_id="sess-i2-O000000",
        )
        result = ev.evaluate(rec)
        assert result.outcome_class == OutcomeClass.INCONCLUSIVE
        assert EvidenceKey.CONFLICTING_EVIDENCE.value in result.evidence
