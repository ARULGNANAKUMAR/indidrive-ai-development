"""
IndiDrive AI — Phase 12.5 | Contradictions, Staleness & Atomicity Tests
========================================================================
Tests: contradiction handling, negative knowledge, staleness, atomicity,
       failure isolation, duplicate prevention, capacity limits.
"""
from __future__ import annotations

import time

import pytest

from core.experience.knowledge import (
    AdaptiveKnowledgeConfig,
    KnowledgeContextKey,
    KnowledgeStatus,
    KnowledgeStore,
    KnowledgeUpdateEngine,
    UpdateType,
    ValidationStatus,
)
from tests.experience125.exp125_helpers import (
    default_config, lenient_config, make_engine,
    urban_pedestrian_key, highway_key, make_experiences,
)


# ---------------------------------------------------------------------------
# Contradiction handling
# ---------------------------------------------------------------------------

class TestContradictions:
    def test_mixed_does_not_become_strong_positive(self):
        """SUCCESS+SUCCESS+FAILURE+UNSAFE must NOT produce HIGH confidence."""
        from core.experience.knowledge import KnowledgeConfidenceClass, EvidenceAggregator
        agg = EvidenceAggregator(default_config())
        records = make_experiences(["SUCCESS", "SUCCESS", "FAILURE", "UNSAFE_OUTCOME"])
        cand = agg.aggregate(urban_pedestrian_key(), records)
        assert cand.confidence_class not in (
            KnowledgeConfidenceClass.HIGH, KnowledgeConfidenceClass.VERY_HIGH
        )

    def test_contradictory_lowers_consistency(self):
        from core.experience.knowledge import EvidenceAggregator
        agg = EvidenceAggregator(lenient_config())
        pure = agg.aggregate(urban_pedestrian_key(),
                             make_experiences(["SUCCESS"] * 5))
        contra = agg.aggregate(urban_pedestrian_key(),
                               make_experiences(["SUCCESS"] * 3 + ["UNSAFE_OUTCOME"] * 2))
        assert contra.consistency < pure.consistency

    def test_contradictory_knowledge_status_not_active(self):
        """Highly contradictory evidence should not become simply ACTIVE."""
        cfg = default_config(minimum_evidence_count=3, minimum_consistency=0.0)
        engine = make_engine(cfg)
        key = urban_pedestrian_key()
        records = make_experiences(
            ["SUCCESS", "FAILURE", "UNSAFE_OUTCOME", "SUCCESS", "FAILURE"]
        )
        result = engine.process_experiences(key, records)
        if result.success:
            snap = engine.store.get(result.knowledge_id)
            if snap is not None:
                # Should be CONFLICTING or WEAK — not simply ACTIVE with high confidence
                if snap.status == KnowledgeStatus.ACTIVE:
                    assert snap.confidence < 0.70

    def test_negative_evidence_tracked_not_inverted(self):
        """FAILURE evidence must appear as failure_count, not success_count."""
        from core.experience.knowledge import EvidenceAggregator
        agg = EvidenceAggregator(lenient_config())
        records = make_experiences(["FAILURE"] * 3)
        cand = agg.aggregate(urban_pedestrian_key(), records)
        assert cand.failure_evidence_count == 3
        assert cand.success_evidence_count == 0

    def test_unsafe_outcome_tracked_separately(self):
        from core.experience.knowledge import EvidenceAggregator
        agg = EvidenceAggregator(lenient_config())
        records = make_experiences(["UNSAFE_OUTCOME", "UNSAFE_OUTCOME", "SUCCESS"])
        cand = agg.aggregate(urban_pedestrian_key(), records)
        assert cand.unsafe_evidence_count == 2

    def test_contradiction_preserves_disagreement_in_observation(self):
        from core.experience.knowledge import EvidenceAggregator
        agg = EvidenceAggregator(lenient_config())
        records = make_experiences(["SUCCESS", "FAILURE", "SUCCESS"])
        cand = agg.aggregate(urban_pedestrian_key(), records)
        # Relationship text must be descriptive
        assert "observational" in cand.observed_relationship.lower() or \
               "observed" in cand.observed_relationship.lower()


# ---------------------------------------------------------------------------
# Negative knowledge (descriptive, not prescriptive)
# ---------------------------------------------------------------------------

class TestNegativeKnowledge:
    def test_negative_knowledge_is_descriptive(self):
        """'failure frequency' knowledge must not contain prescriptive language."""
        from core.experience.knowledge import EvidenceAggregator
        agg = EvidenceAggregator(lenient_config())
        records = make_experiences(["FAILURE"] * 5)
        cand = agg.aggregate(urban_pedestrian_key(), records)
        rel = cand.observed_relationship.lower()
        # Must not say "therefore brake" or "always do X"
        for forbidden in ("therefore brake", "always perform", "must execute",
                          "automatically do", "action required"):
            assert forbidden not in rel

    def test_unsafe_observation_described_not_acted_upon(self):
        from core.experience.knowledge import EvidenceAggregator
        agg = EvidenceAggregator(lenient_config())
        records = make_experiences(["UNSAFE_OUTCOME"] * 3)
        cand = agg.aggregate(urban_pedestrian_key(), records)
        # Observed relationship is observational
        assert "NOT" not in cand.observed_relationship or \
               "prescriptive" in cand.observed_relationship.lower()


# ---------------------------------------------------------------------------
# Staleness
# ---------------------------------------------------------------------------

class TestStaleness:
    def test_no_stale_when_disabled(self):
        engine = make_engine(default_config(stale_after_seconds=0))
        key = urban_pedestrian_key()
        engine.process_experiences(key, make_experiences(["SUCCESS"] * 2))
        marked = engine.check_staleness()
        assert marked == []

    def test_stale_marks_old_active(self):
        cfg = default_config(stale_after_seconds=1, minimum_evidence_count=1,
                             minimum_confidence=0.01, minimum_consistency=0.0)
        engine = make_engine(cfg)
        key = urban_pedestrian_key()
        engine.process_experiences(key, make_experiences(["SUCCESS"] * 2))
        snap = engine.store.get(key.to_knowledge_id())
        if snap is None:
            pytest.skip("Entry not created (confidence below threshold)")

        # Backdate last_evidence_at
        entry = engine.store._entries[key.to_knowledge_id()]
        entry.last_evidence_at = time.time() - 10.0
        entry.status = KnowledgeStatus.ACTIVE

        marked = engine.check_staleness()
        assert key.to_knowledge_id() in marked

    def test_stale_status_transition(self):
        cfg = default_config(stale_after_seconds=1, minimum_evidence_count=1,
                             minimum_confidence=0.01, minimum_consistency=0.0)
        engine = make_engine(cfg)
        key = urban_pedestrian_key()
        engine.process_experiences(key, make_experiences(["SUCCESS"] * 2))
        entry = engine.store._entries.get(key.to_knowledge_id())
        if entry is None:
            pytest.skip("Entry not created")
        entry.last_evidence_at = time.time() - 10.0
        entry.status = KnowledgeStatus.ACTIVE
        engine.check_staleness()
        snap = engine.store.get(key.to_knowledge_id())
        assert snap.status == KnowledgeStatus.STALE

    def test_stale_not_deleted(self):
        cfg = default_config(stale_after_seconds=1, minimum_evidence_count=1,
                             minimum_confidence=0.01, minimum_consistency=0.0)
        engine = make_engine(cfg)
        key = urban_pedestrian_key()
        engine.process_experiences(key, make_experiences(["SUCCESS"] * 2))
        entry = engine.store._entries.get(key.to_knowledge_id())
        if entry is None:
            pytest.skip("Entry not created")
        entry.last_evidence_at = time.time() - 100.0
        entry.status = KnowledgeStatus.ACTIVE
        engine.check_staleness()
        # Must still exist — staleness never deletes
        assert engine.store.get(key.to_knowledge_id()) is not None


# ---------------------------------------------------------------------------
# Atomicity
# ---------------------------------------------------------------------------

class TestAtomicity:
    def test_failed_insert_preserves_nothing(self):
        """If insert returns False (capacity=0), no partial write."""
        cfg = default_config(minimum_evidence_count=1, minimum_confidence=0.01,
                             minimum_consistency=0.0, maximum_entries=0)
        engine = make_engine(cfg)
        key = urban_pedestrian_key()
        result = engine.process_experiences(key, make_experiences(["SUCCESS"] * 2))
        # With max_entries=0, insert may fail
        snap = engine.store.get(key.to_knowledge_id())
        if not result.success:
            assert snap is None

    def test_no_partial_version_visible(self):
        """After any update, only one current entry per knowledge_id is visible."""
        cfg = lenient_config()
        cfg.minimum_confidence = 0.01
        engine = make_engine(cfg)
        key = urban_pedestrian_key()
        # v1: LOW confidence
        low_recs = [{"experience_id": f"sL-R{i:06d}", "evaluation_id": f"sL-R{i:06d}-EVAL",
                     "session_id": "sL", "outcome_class": "SUCCESS",
                     "evaluation_confidence": "LOW",
                     "experience_timestamp": 1_700_000_000.0 + i}
                    for i in range(2)]
        engine.process_experiences(key, low_recs)
        # v2: HIGH confidence
        high_recs = [{"experience_id": f"sH-R{i:06d}", "evaluation_id": f"sH-R{i:06d}-EVAL",
                      "session_id": "sH", "outcome_class": "SUCCESS",
                      "evaluation_confidence": "HIGH",
                      "experience_timestamp": 1_700_010_000.0 + i}
                     for i in range(10)]
        engine.process_experiences(key, high_recs)
        # Only one current entry per knowledge_id
        all_entries = engine.store.list_all()
        current = [e for e in all_entries if e.knowledge_id == key.to_knowledge_id()]
        assert len(current) == 1
        # Current version is internally consistent
        snap = engine.store.get(key.to_knowledge_id())
        assert snap is not None
        assert 0.0 <= snap.confidence <= 1.0

    def test_existing_knowledge_intact_after_error(self):
        """Simulate a bad record; existing knowledge must survive."""
        engine = make_engine(lenient_config())
        key = urban_pedestrian_key()
        engine.process_experiences(key, make_experiences(["SUCCESS"] * 2))
        snap_before = engine.store.get(key.to_knowledge_id())
        # Submit garbage (won't raise, but may be deferred/rejected)
        bad_records = [{"outcome_class": None, "evaluation_confidence": None,
                        "experience_timestamp": "not_a_float"}]
        engine.process_experiences(key, bad_records)
        snap_after = engine.store.get(key.to_knowledge_id())
        # Previous knowledge must still be intact
        assert snap_before is not None
        if snap_after is not None:
            assert snap_after.version >= snap_before.version


# ---------------------------------------------------------------------------
# Failure isolation
# ---------------------------------------------------------------------------

class TestFailureIsolation:
    def test_empty_experience_list_safe(self):
        engine = make_engine(default_config())
        result = engine.process_experiences(urban_pedestrian_key(), [])
        # Empty → no valid evidence → DEFERRED; no crash
        assert result is not None

    def test_malformed_record_fields_safe(self):
        engine = make_engine(lenient_config())
        malformed = [
            {"experience_id": None, "outcome_class": "SUCCESS",
             "evaluation_confidence": "HIGH", "experience_timestamp": 0.0}
        ]
        result = engine.process_experiences(urban_pedestrian_key(), malformed)
        assert result is not None

    def test_unknown_outcome_class_safe(self):
        engine = make_engine(lenient_config())
        records = [{"experience_id": "x", "evaluation_id": "x-EVAL",
                    "session_id": "s", "outcome_class": "MADE_UP_OUTCOME",
                    "evaluation_confidence": "HIGH", "experience_timestamp": 0.0}]
        result = engine.process_experiences(urban_pedestrian_key(), records)
        assert result is not None

    def test_disabled_engine_returns_result(self):
        cfg = default_config()
        cfg.enabled = False
        engine = make_engine(cfg)
        result = engine.process_experiences(urban_pedestrian_key(),
                                            make_experiences(["SUCCESS"] * 5))
        assert not result.success
        assert "disabled" in result.reason.lower()

    def test_none_timestamp_does_not_crash(self):
        engine = make_engine(lenient_config())
        records = [{"experience_id": "x", "evaluation_id": "x-EVAL",
                    "session_id": "s", "outcome_class": "SUCCESS",
                    "evaluation_confidence": "HIGH",
                    "experience_timestamp": None}]
        # Should not crash; timestamp defaults to 0.0
        result = engine.process_experiences(urban_pedestrian_key(), records)
        assert result is not None


# ---------------------------------------------------------------------------
# Duplicate prevention
# ---------------------------------------------------------------------------

class TestDuplicatePrevention:
    def test_same_context_same_knowledge_id(self):
        engine = make_engine(lenient_config())
        key1 = urban_pedestrian_key()
        key2 = urban_pedestrian_key()
        r1 = engine.process_experiences(key1, make_experiences(["SUCCESS"] * 2))
        r2 = engine.process_experiences(key2, make_experiences(["SUCCESS"] * 2))
        assert r1.knowledge_id == r2.knowledge_id

    def test_duplicate_context_updates_not_duplicates(self):
        engine = make_engine(lenient_config())
        key = urban_pedestrian_key()
        engine.process_experiences(key, make_experiences(["SUCCESS"] * 2))
        engine.process_experiences(key, make_experiences(["SUCCESS"] * 2))
        all_entries = engine.store.list_all()
        same_id = [e for e in all_entries if e.knowledge_id == key.to_knowledge_id()]
        assert len(same_id) == 1  # only one current entry

    def test_different_context_creates_different_entry(self):
        engine = make_engine(lenient_config())
        r1 = engine.process_experiences(urban_pedestrian_key(),
                                        make_experiences(["SUCCESS"] * 2))
        r2 = engine.process_experiences(highway_key(),
                                        make_experiences(["SUCCESS"] * 2))
        assert r1.knowledge_id != r2.knowledge_id
        assert len(engine.store.list_all()) == 2


# ---------------------------------------------------------------------------
# Capacity limits
# ---------------------------------------------------------------------------

class TestCapacityLimits:
    def test_capacity_enforced(self):
        cfg = default_config(maximum_entries=2)
        cfg.minimum_evidence_count = 1
        cfg.minimum_confidence = 0.01
        cfg.minimum_consistency = 0.0
        engine = make_engine(cfg)
        keys = [
            KnowledgeContextKey(road_type=f"TYPE_{i}") for i in range(5)
        ]
        for key in keys:
            engine.process_experiences(key, make_experiences(["SUCCESS"] * 2))
        # Should not exceed maximum in the live entry map
        # (eviction happens, so total live entries ≤ maximum_entries)
        live = len(engine.store._entries)
        assert live <= cfg.maximum_entries

    def test_history_trimmed_to_limit(self):
        cfg = default_config(minimum_evidence_count=1, minimum_confidence=0.01,
                             minimum_consistency=0.0)
        cfg.maximum_history_per_entry = 2
        engine = make_engine(cfg)
        key = urban_pedestrian_key()
        for i in range(6):
            engine.process_experiences(key, make_experiences(["SUCCESS"] * (i + 2)))
        hist = engine.store.get_history(key.to_knowledge_id())
        assert len(hist) <= 2
