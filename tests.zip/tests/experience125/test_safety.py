"""
IndiDrive AI — Phase 12.5 | Safety Tests
=========================================
Explicitly verify that adaptive knowledge:
    - cannot change safety thresholds
    - cannot disable SafetyGate
    - cannot modify fail-safe behavior
    - cannot modify emergency braking
    - cannot modify vehicle limits
    - cannot bypass validation
    - cannot override current safety state
    - safety-type knowledge uses stricter thresholds
    - unsafe outcomes produce strong negative evidence
    - safety knowledge never weakens safety
"""
from __future__ import annotations

import inspect

import pytest

from core.experience.knowledge import (
    AdaptiveKnowledgeConfig,
    KnowledgeContext,
    KnowledgeStore,
    KnowledgeUpdateEngine,
    KnowledgeType,
)
from tests.experience125.exp125_helpers import (
    default_config, lenient_config, make_engine,
    urban_pedestrian_key, safety_critical_key, make_experiences,
)


# ---------------------------------------------------------------------------
# Safety module isolation
# ---------------------------------------------------------------------------

class TestSafetyModuleIsolation:
    def test_knowledge_update_engine_does_not_import_safety_gate(self):
        """KnowledgeUpdateEngine must not import safety_gate."""
        from core.experience.knowledge import knowledge_update_engine as mod
        src = inspect.getsource(mod)
        assert "safety_gate" not in src.lower()

    def test_knowledge_store_does_not_import_safety_gate(self):
        from core.experience.knowledge import knowledge_store as mod
        src = inspect.getsource(mod)
        assert "safety_gate" not in src.lower()

    def test_knowledge_types_does_not_import_planning(self):
        from core.experience.knowledge import knowledge_types as mod
        src = inspect.getsource(mod)
        assert "planner_engine" not in src.lower()

    def test_knowledge_types_does_not_import_mpc(self):
        """MPC must not appear in import statements or executable code."""
        from core.experience.knowledge import knowledge_types as mod
        # Strip docstrings before checking — comments explaining boundaries are allowed
        import ast
        tree = ast.parse(inspect.getsource(mod))
        code_only = ast.unparse(tree)
        assert "mpc_config" not in code_only.lower()
        assert "MpcConfig" not in code_only
        assert "mpc_tuning" not in code_only.lower()


# ---------------------------------------------------------------------------
# No control authority in KnowledgeContext
# ---------------------------------------------------------------------------

class TestKnowledgeContextNoControl:
    def test_context_has_no_execute_action(self):
        engine = make_engine(lenient_config())
        result = engine.process_experiences(
            urban_pedestrian_key(), make_experiences(["SUCCESS"] * 2)
        )
        ctx = engine.store.get_knowledge_context(result.knowledge_id)
        assert ctx is not None
        assert not hasattr(ctx, "execute_action")

    def test_context_has_no_set_policy(self):
        engine = make_engine(lenient_config())
        result = engine.process_experiences(
            urban_pedestrian_key(), make_experiences(["SUCCESS"] * 2)
        )
        ctx = engine.store.get_knowledge_context(result.knowledge_id)
        assert not hasattr(ctx, "set_policy")

    def test_context_has_no_modify_threshold(self):
        engine = make_engine(lenient_config())
        result = engine.process_experiences(
            urban_pedestrian_key(), make_experiences(["SUCCESS"] * 2)
        )
        ctx = engine.store.get_knowledge_context(result.knowledge_id)
        assert not hasattr(ctx, "modify_threshold")
        assert not hasattr(ctx, "modify_parameter")
        assert not hasattr(ctx, "disable_safety")

    def test_context_attributes_are_read_only_types(self):
        engine = make_engine(lenient_config())
        result = engine.process_experiences(
            urban_pedestrian_key(), make_experiences(["SUCCESS"] * 2)
        )
        ctx = engine.store.get_knowledge_context(result.knowledge_id)
        # All attributes should be primitives or enums — not callable controllers
        for attr in vars(ctx).values():
            assert not callable(attr), f"KnowledgeContext has callable attr: {attr}"


# ---------------------------------------------------------------------------
# Safety-type knowledge stricter thresholds
# ---------------------------------------------------------------------------

class TestSafetyTypeStricterThresholds:
    def test_safety_type_requires_more_evidence(self):
        cfg = default_config(
            minimum_evidence_count=3,
            minimum_confidence=0.40,
        )
        cfg.safety_minimum_evidence_count = 5
        cfg.safety_minimum_confidence = 0.60
        engine = make_engine(cfg)
        key = safety_critical_key()  # safety_state=UNSAFE → SAFETY type

        # 3 SUCCESS records — enough for CONTEXTUAL but not SAFETY
        result = engine.process_experiences(key, make_experiences(["SUCCESS"] * 3))
        # Safety type needs 5 → should be DEFERRED
        from core.experience.knowledge import ValidationStatus
        assert result.validation_status == ValidationStatus.DEFERRED

    def test_safety_type_accepted_with_enough_evidence(self):
        cfg = default_config(minimum_evidence_count=3)
        cfg.safety_minimum_evidence_count = 5
        cfg.safety_minimum_confidence = 0.40
        engine = make_engine(cfg)
        key = safety_critical_key()
        result = engine.process_experiences(key, make_experiences(["SUCCESS"] * 5))
        # May pass if confidence ≥ 0.40
        from core.experience.knowledge import ValidationStatus
        assert result.validation_status in (
            ValidationStatus.ACCEPTED, ValidationStatus.DEFERRED
        )

    def test_safety_knowledge_type_inferred(self):
        from core.experience.knowledge import EvidenceAggregator
        agg = EvidenceAggregator(lenient_config())
        key = safety_critical_key()
        cand = agg.aggregate(key, make_experiences(["SUCCESS"] * 2))
        assert cand.knowledge_type == KnowledgeType.SAFETY


# ---------------------------------------------------------------------------
# Unsafe outcome as strong negative evidence
# ---------------------------------------------------------------------------

class TestUnsafeOutcomeNegativeEvidence:
    def test_unsafe_outcome_strong_negative_weight(self):
        from core.experience.knowledge import OUTCOME_WEIGHT
        assert OUTCOME_WEIGHT["UNSAFE_OUTCOME"] <= -0.5

    def test_unsafe_outcome_is_safety_evidence(self):
        from core.experience.knowledge import EvidenceAggregator
        agg = EvidenceAggregator(lenient_config())
        records = make_experiences(["UNSAFE_OUTCOME"])
        cand = agg.aggregate(urban_pedestrian_key(), records)
        unsafe_evs = [ev for ev in cand.evidence if ev.outcome_class == "UNSAFE_OUTCOME"]
        assert len(unsafe_evs) == 1
        assert unsafe_evs[0].is_safety_evidence

    def test_unsafe_outcome_does_not_inflate_confidence(self):
        from core.experience.knowledge import EvidenceAggregator
        agg = EvidenceAggregator(lenient_config())
        records = make_experiences(["UNSAFE_OUTCOME"] * 5)
        cand = agg.aggregate(urban_pedestrian_key(), records)
        assert cand.confidence == 0.0

    def test_unsafe_outcome_counted_in_unsafe_count(self):
        from core.experience.knowledge import EvidenceAggregator
        agg = EvidenceAggregator(lenient_config())
        records = make_experiences(["SUCCESS", "UNSAFE_OUTCOME", "UNSAFE_OUTCOME"])
        cand = agg.aggregate(urban_pedestrian_key(), records)
        assert cand.unsafe_evidence_count == 2


# ---------------------------------------------------------------------------
# Safety knowledge never weakens safety
# ---------------------------------------------------------------------------

class TestSafetyNeverWeakened:
    def test_knowledge_entry_has_no_safety_threshold_field(self):
        """KnowledgeEntry must not contain fields that could adjust safety params."""
        from core.experience.knowledge import KnowledgeEntry
        entry_fields = {f.name for f in KnowledgeEntry.__dataclass_fields__.values()}
        forbidden = {
            "safety_threshold", "collision_threshold", "emergency_brake_threshold",
            "safety_margin", "failsafe_override", "bypass_safety",
        }
        assert not entry_fields.intersection(forbidden)

    def test_knowledge_update_result_has_no_control_fields(self):
        from core.experience.knowledge import KnowledgeUpdateResult
        result_fields = {f.name for f in KnowledgeUpdateResult.__dataclass_fields__.values()}
        forbidden = {
            "steering_command", "throttle_command", "brake_command",
            "mpc_param", "safety_threshold", "trajectory",
        }
        assert not result_fields.intersection(forbidden)

    def test_observed_relationship_not_prescriptive(self):
        """Observed relationship must never contain prescriptive control instructions."""
        from core.experience.knowledge import EvidenceAggregator
        agg = EvidenceAggregator(lenient_config())
        key = safety_critical_key()
        records = make_experiences(["UNSAFE_OUTCOME"] * 3)
        cand = agg.aggregate(key, records)
        rel = cand.observed_relationship.lower()
        # Must not say "therefore brake" or similar prescriptive statements
        for forbidden in (
            "therefore brake", "apply brakes", "steer left", "steer right",
            "reduce throttle", "increase throttle", "execute emergency",
            "disable safety", "bypass safetgate",
        ):
            assert forbidden not in rel, \
                f"Prescriptive content found: '{forbidden}' in '{rel}'"

    def test_store_has_no_safety_gate_write_method(self):
        """KnowledgeStore must have no method that can write to SafetyGate."""
        store = KnowledgeStore()
        store_methods = [m for m in dir(store) if not m.startswith("__")]
        for method_name in store_methods:
            assert "safety_gate" not in method_name.lower()
            assert "mpc" not in method_name.lower()
            assert "planner" not in method_name.lower()
            assert "steering" not in method_name.lower()
            assert "throttle" not in method_name.lower()
            assert "braking" not in method_name.lower()

    def test_engine_has_no_vehicle_write_method(self):
        """KnowledgeUpdateEngine must have no method that can write to vehicle."""
        engine = make_engine()
        engine_methods = [m for m in dir(engine) if not m.startswith("__")]
        for method_name in engine_methods:
            assert "steering" not in method_name.lower()
            assert "throttle" not in method_name.lower()
            assert "braking" not in method_name.lower()
            assert "trajectory" not in method_name.lower()
            assert "mpc" not in method_name.lower()


# ---------------------------------------------------------------------------
# Regression: safety-connected knowledge cannot reduce margins
# ---------------------------------------------------------------------------

class TestSafetyRegressions:
    def test_safety_knowledge_cannot_reduce_margin(self):
        """
        Regression: if a developer accidentally connects KnowledgeContext
        to a safety threshold, this test must fail to alert them.
        """
        engine = make_engine(lenient_config())
        result = engine.process_experiences(
            safety_critical_key(), make_experiences(["SUCCESS"] * 3)
        )
        ctx = engine.store.get_knowledge_context(result.knowledge_id or "K-NONE")
        if ctx is None:
            return  # deferred — test still passes
        # ctx must not have any attribute that could reduce a safety margin
        for attr_name in dir(ctx):
            if attr_name.startswith("_"):
                continue
            assert "threshold" not in attr_name.lower()
            assert "margin" not in attr_name.lower()
            assert "override" not in attr_name.lower()
            assert "bypass" not in attr_name.lower()

    def test_knowledge_update_does_not_call_safety_gate(self):
        """
        Verify that the KnowledgeUpdateEngine does not import or instantiate
        SafetyGate or safety bypass methods (docstring mentions are allowed).
        """
        import ast
        import core.experience.knowledge.knowledge_update_engine as mod
        tree = ast.parse(inspect.getsource(mod))
        code_only = ast.unparse(tree)
        for forbidden in (
            "bypass_safety", "disable_emergency",
            "set_collision_threshold", "SafetyGate(",
        ):
            assert forbidden not in code_only, \
                f"Forbidden reference found in knowledge_update_engine: {forbidden}"
        # Also verify no import of safety_gate module
        import_names = [
            node.names[0].name if isinstance(node, ast.Import) else node.module
            for node in ast.walk(tree)
            if isinstance(node, (ast.Import, ast.ImportFrom))
        ]
        for name in import_names:
            if name:
                assert "safety_gate" not in name.lower()
