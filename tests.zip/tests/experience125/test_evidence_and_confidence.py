"""
IndiDrive AI — Phase 12.5 | Evidence & Confidence Tests
========================================================
Tests: single evidence, repeated evidence, positive, negative, mixed,
       inconclusive, degraded, invalid evidence, confidence model,
       determinism, outcome integration for all OutcomeClass values.
"""
from __future__ import annotations

import pytest

from core.experience.knowledge import (
    EvidenceAggregator,
    KnowledgeConfidenceClass,
    KnowledgeStore,
    KnowledgeUpdateEngine,
    AdaptiveKnowledgeConfig,
    ValidationStatus,
)
from tests.experience125.exp125_helpers import (
    default_config, lenient_config, make_engine,
    urban_pedestrian_key, highway_key, make_experiences,
)


def make_agg(cfg=None) -> EvidenceAggregator:
    return EvidenceAggregator(cfg or lenient_config())


# ---------------------------------------------------------------------------
# Single evidence
# ---------------------------------------------------------------------------

class TestSingleEvidence:
    def test_single_success_produces_positive_confidence(self):
        agg = make_agg()
        key = urban_pedestrian_key()
        records = make_experiences(["SUCCESS"])
        cand = agg.aggregate(key, records)
        assert cand.valid_evidence_count == 1
        assert cand.confidence > 0.0

    def test_single_failure_produces_zero_confidence(self):
        agg = make_agg()
        key = urban_pedestrian_key()
        records = make_experiences(["FAILURE"])
        cand = agg.aggregate(key, records)
        # FAILURE has negative weight → raw_ratio < 0 → confidence = 0
        assert cand.confidence == 0.0

    def test_single_unsafe_produces_zero_confidence(self):
        agg = make_agg()
        key = urban_pedestrian_key()
        records = make_experiences(["UNSAFE_OUTCOME"])
        cand = agg.aggregate(key, records)
        assert cand.confidence == 0.0

    def test_single_invalid_counts_zero_evidence(self):
        agg = make_agg()
        records = make_experiences(["INVALID"])
        cand = agg.aggregate(urban_pedestrian_key(), records)
        assert cand.valid_evidence_count == 0
        assert cand.confidence == 0.0


# ---------------------------------------------------------------------------
# Repeated evidence
# ---------------------------------------------------------------------------

class TestRepeatedEvidence:
    def test_repeated_success_increases_confidence(self):
        agg = make_agg()
        key = urban_pedestrian_key()
        c1 = agg.aggregate(key, make_experiences(["SUCCESS"]))
        c3 = agg.aggregate(key, make_experiences(["SUCCESS"] * 3))
        # More evidence → higher or equal confidence
        assert c3.confidence >= c1.confidence

    def test_repeated_success_reaches_high_confidence(self):
        cfg = default_config(minimum_evidence_count=3)
        agg = make_agg(cfg)
        key = urban_pedestrian_key()
        cand = agg.aggregate(key, make_experiences(["SUCCESS"] * 10, confidence="HIGH"))
        assert cand.confidence_class in (
            KnowledgeConfidenceClass.VERY_HIGH, KnowledgeConfidenceClass.HIGH
        )

    def test_evidence_count_correct(self):
        agg = make_agg()
        records = make_experiences(["SUCCESS"] * 5)
        cand = agg.aggregate(urban_pedestrian_key(), records)
        assert cand.evidence_count == 5
        assert cand.valid_evidence_count == 5
        assert cand.success_evidence_count == 5


# ---------------------------------------------------------------------------
# Positive evidence
# ---------------------------------------------------------------------------

class TestPositiveEvidence:
    def test_success_evidence(self):
        agg = make_agg()
        cand = agg.aggregate(urban_pedestrian_key(), make_experiences(["SUCCESS"] * 3))
        assert cand.success_evidence_count == 3
        assert cand.failure_evidence_count == 0

    def test_partial_success_counts_toward_success(self):
        agg = make_agg()
        cand = agg.aggregate(urban_pedestrian_key(),
                             make_experiences(["PARTIAL_SUCCESS"] * 3))
        assert cand.success_evidence_count == 3

    def test_partial_success_lower_weight_than_success(self):
        agg = make_agg()
        c_success = agg.aggregate(urban_pedestrian_key(),
                                  make_experiences(["SUCCESS"] * 3))
        c_partial = agg.aggregate(urban_pedestrian_key(),
                                  make_experiences(["PARTIAL_SUCCESS"] * 3))
        assert c_success.weighted_score > c_partial.weighted_score


# ---------------------------------------------------------------------------
# Negative evidence
# ---------------------------------------------------------------------------

class TestNegativeEvidence:
    def test_failure_is_negative_evidence(self):
        agg = make_agg()
        records = make_experiences(["FAILURE"] * 3)
        cand = agg.aggregate(urban_pedestrian_key(), records)
        assert cand.failure_evidence_count == 3
        assert cand.weighted_score < 0

    def test_unsafe_is_strong_negative_evidence(self):
        from core.experience.knowledge import OUTCOME_WEIGHT
        assert OUTCOME_WEIGHT["UNSAFE_OUTCOME"] < OUTCOME_WEIGHT["FAILURE"]

    def test_failure_tracked_not_silently_discarded(self):
        agg = make_agg()
        records = make_experiences(["SUCCESS", "FAILURE", "SUCCESS"])
        cand = agg.aggregate(urban_pedestrian_key(), records)
        assert cand.failure_evidence_count == 1
        # Negative evidence reduces confidence, consistency
        assert cand.consistency < 1.0

    def test_negative_evidence_reduces_consistency(self):
        agg = make_agg()
        cand_pure = agg.aggregate(urban_pedestrian_key(),
                                  make_experiences(["SUCCESS"] * 4))
        cand_mixed = agg.aggregate(urban_pedestrian_key(),
                                   make_experiences(["SUCCESS"] * 3 + ["FAILURE"]))
        assert cand_mixed.consistency < cand_pure.consistency


# ---------------------------------------------------------------------------
# Mixed evidence
# ---------------------------------------------------------------------------

class TestMixedEvidence:
    def test_mixed_does_not_become_high_confidence(self):
        agg = make_agg()
        # SUCCESS, SUCCESS, FAILURE, UNSAFE → contradictory
        records = make_experiences(
            ["SUCCESS", "SUCCESS", "FAILURE", "UNSAFE_OUTCOME"]
        )
        cand = agg.aggregate(urban_pedestrian_key(), records)
        assert cand.confidence_class not in (
            KnowledgeConfidenceClass.HIGH, KnowledgeConfidenceClass.VERY_HIGH
        )

    def test_mixed_evidence_has_low_consistency(self):
        agg = make_agg()
        records = make_experiences(["SUCCESS", "FAILURE", "UNSAFE_OUTCOME", "SUCCESS"])
        cand = agg.aggregate(urban_pedestrian_key(), records)
        assert cand.consistency < 0.60  # significant contradiction

    def test_contradictory_knowledge_status_is_conflicting_or_weak(self):
        engine = make_engine(default_config(minimum_evidence_count=3,
                                            minimum_consistency=0.0))
        key = urban_pedestrian_key()
        records = make_experiences(
            ["SUCCESS", "SUCCESS", "FAILURE", "UNSAFE_OUTCOME", "SUCCESS"]
        )
        result = engine.process_experiences(key, records)
        if result.success:
            snap = engine.store.get(result.knowledge_id)
            if snap is not None:
                assert snap.status in (
                    KnowledgeStatus.CONFLICTING,
                    KnowledgeStatus.WEAK,
                    KnowledgeStatus.ACTIVE,
                )

    def test_unsafe_outcome_not_discarded(self):
        agg = make_agg()
        records = make_experiences(["SUCCESS", "UNSAFE_OUTCOME", "SUCCESS"])
        cand = agg.aggregate(urban_pedestrian_key(), records)
        unsafe_ev = [ev for ev in cand.evidence if ev.outcome_class == "UNSAFE_OUTCOME"]
        assert len(unsafe_ev) == 1
        assert unsafe_ev[0].is_safety_evidence

    # Re-import needed for status check
    def test_mixed_deferred_by_consistency(self):
        # strict consistency → deferred when contradictory
        engine = make_engine(default_config(minimum_evidence_count=2,
                                            minimum_consistency=0.90))
        key = urban_pedestrian_key()
        records = make_experiences(["SUCCESS", "FAILURE", "SUCCESS"])
        result = engine.process_experiences(key, records)
        assert result.validation_status == ValidationStatus.DEFERRED


# ---------------------------------------------------------------------------
# Inconclusive evidence
# ---------------------------------------------------------------------------

class TestInconclusiveEvidence:
    def test_inconclusive_is_not_success(self):
        agg = make_agg()
        records = make_experiences(["INCONCLUSIVE"] * 3)
        cand = agg.aggregate(urban_pedestrian_key(), records)
        assert cand.success_evidence_count == 0
        assert cand.confidence == 0.0

    def test_inconclusive_has_zero_weight(self):
        from core.experience.knowledge import OUTCOME_WEIGHT
        assert OUTCOME_WEIGHT["INCONCLUSIVE"] == 0.0

    def test_inconclusive_counted_as_valid(self):
        from core.experience.knowledge import VALID_EVIDENCE_OUTCOMES
        assert "INCONCLUSIVE" in VALID_EVIDENCE_OUTCOMES

    def test_no_outcome_has_zero_weight(self):
        from core.experience.knowledge import OUTCOME_WEIGHT
        assert OUTCOME_WEIGHT["NO_OUTCOME"] == 0.0


# ---------------------------------------------------------------------------
# Degraded evidence
# ---------------------------------------------------------------------------

class TestDegradedEvidence:
    def test_degraded_outcome_has_low_weight(self):
        from core.experience.knowledge import OUTCOME_WEIGHT
        assert 0.0 < OUTCOME_WEIGHT["DEGRADED"] < OUTCOME_WEIGHT["SUCCESS"]

    def test_degraded_accepted_when_config_allows(self):
        agg = make_agg(default_config(minimum_evidence_count=3))
        records = make_experiences(["DEGRADED"] * 3)
        cand = agg.aggregate(urban_pedestrian_key(), records)
        assert cand.valid_evidence_count == 3

    def test_degraded_excluded_when_config_disallows(self):
        cfg = default_config(minimum_evidence_count=1, minimum_consistency=0.0)
        cfg.allow_degraded_evidence = False
        engine = make_engine(cfg)
        key = urban_pedestrian_key()
        # All DEGRADED → validator rejects
        records = make_experiences(["DEGRADED"] * 2)
        result = engine.process_experiences(key, records)
        assert result.validation_status in (
            ValidationStatus.REJECTED, ValidationStatus.DEFERRED
        )


# ---------------------------------------------------------------------------
# Invalid evidence
# ---------------------------------------------------------------------------

class TestInvalidEvidence:
    def test_invalid_never_counts(self):
        agg = make_agg()
        records = make_experiences(["INVALID"] * 10)
        cand = agg.aggregate(urban_pedestrian_key(), records)
        assert cand.valid_evidence_count == 0

    def test_not_evaluated_never_counts(self):
        agg = make_agg()
        records = make_experiences(["NOT_EVALUATED"] * 5)
        cand = agg.aggregate(urban_pedestrian_key(), records)
        assert cand.valid_evidence_count == 0

    def test_evaluation_error_never_counts(self):
        from core.experience.knowledge import INVALID_EVIDENCE_OUTCOMES
        assert "EVALUATION_ERROR" in INVALID_EVIDENCE_OUTCOMES

    def test_mix_of_invalid_and_success(self):
        agg = make_agg()
        records = (
            make_experiences(["INVALID"] * 5)
            + make_experiences(["SUCCESS"] * 3)
        )
        cand = agg.aggregate(urban_pedestrian_key(), records)
        assert cand.valid_evidence_count == 3
        assert cand.success_evidence_count == 3


# ---------------------------------------------------------------------------
# All OutcomeClass values
# ---------------------------------------------------------------------------

ALL_OUTCOMES = [
    "SUCCESS", "PARTIAL_SUCCESS", "FAILURE", "UNSAFE_OUTCOME",
    "DEGRADED", "INCONCLUSIVE", "NO_OUTCOME", "INVALID",
    "PENDING", "NOT_EVALUATED", "EVALUATION_ERROR",
]

class TestAllOutcomeClasses:
    def test_outcome_does_not_crash(self):
        """All OutcomeClass values must not crash and confidence must be in [0,1]."""
        agg = make_agg()
        for outcome in ALL_OUTCOMES:
            records = make_experiences([outcome] * 3)
            cand = agg.aggregate(urban_pedestrian_key(), records)
            assert 0.0 <= cand.confidence <= 1.0, \
                f"Confidence out of range for outcome={outcome}: {cand.confidence}"

    def test_invalid_never_positive_confidence(self):
        agg = make_agg()
        for oc in ("INVALID", "NOT_EVALUATED", "EVALUATION_ERROR", "PENDING"):
            cand = agg.aggregate(urban_pedestrian_key(), make_experiences([oc] * 5))
            assert cand.confidence == 0.0, f"Expected 0 confidence for {oc}"

    def test_success_highest_weight(self):
        from core.experience.knowledge import OUTCOME_WEIGHT
        non_invalid = {k: v for k, v in OUTCOME_WEIGHT.items()
                       if k not in ("INVALID", "NOT_EVALUATED",
                                    "EVALUATION_ERROR", "PENDING")}
        max_oc = max(non_invalid, key=non_invalid.get)
        assert max_oc == "SUCCESS"

    def test_unsafe_outcome_most_negative(self):
        from core.experience.knowledge import OUTCOME_WEIGHT
        assert OUTCOME_WEIGHT["UNSAFE_OUTCOME"] < OUTCOME_WEIGHT["FAILURE"]


# ---------------------------------------------------------------------------
# Confidence model
# ---------------------------------------------------------------------------

class TestConfidenceModel:
    def test_confidence_in_range(self):
        agg = make_agg()
        for outcomes in [
            ["SUCCESS"] * 10,
            ["FAILURE"] * 10,
            ["SUCCESS"] * 5 + ["FAILURE"] * 5,
            ["INCONCLUSIVE"] * 5,
        ]:
            cand = agg.aggregate(urban_pedestrian_key(), make_experiences(outcomes))
            assert 0.0 <= cand.confidence <= 1.0

    def test_confidence_class_matches_score(self):
        from core.experience.knowledge import KnowledgeConfidenceClass
        agg = make_agg()
        cand = agg.aggregate(urban_pedestrian_key(),
                             make_experiences(["SUCCESS"] * 20, confidence="HIGH"))
        if cand.confidence >= 0.85:
            assert cand.confidence_class == KnowledgeConfidenceClass.VERY_HIGH
        elif cand.confidence >= 0.70:
            assert cand.confidence_class == KnowledgeConfidenceClass.HIGH

    def test_insufficient_evidence_unknown_confidence(self):
        agg = make_agg(default_config(minimum_evidence_count=10))
        cand = agg.aggregate(urban_pedestrian_key(), make_experiences(["SUCCESS"]))
        # evidence_sufficiency = 1/10 = 0.10 → low confidence
        assert cand.confidence < 0.5

    def test_low_eval_confidence_reduces_weight(self):
        agg = make_agg()
        c_high = agg.aggregate(urban_pedestrian_key(),
                               make_experiences(["SUCCESS"] * 3, confidence="HIGH"))
        c_low = agg.aggregate(urban_pedestrian_key(),
                              make_experiences(["SUCCESS"] * 3, confidence="LOW"))
        assert c_high.weighted_score > c_low.weighted_score

    def test_consistency_zero_when_all_negative(self):
        agg = make_agg()
        cand = agg.aggregate(urban_pedestrian_key(),
                             make_experiences(["FAILURE", "UNSAFE_OUTCOME"]))
        assert cand.consistency == 0.0


# ---------------------------------------------------------------------------
# Determinism
# ---------------------------------------------------------------------------

class TestDeterminism:
    def test_same_input_same_candidate(self):
        agg = make_agg()
        key = urban_pedestrian_key()
        records = make_experiences(["SUCCESS", "PARTIAL_SUCCESS", "FAILURE"])
        c1 = agg.aggregate(key, records, candidate_seq=0)
        c2 = agg.aggregate(key, records, candidate_seq=0)
        assert c1.knowledge_id == c2.knowledge_id
        assert c1.confidence == c2.confidence
        assert c1.consistency == c2.consistency
        assert c1.weighted_score == c2.weighted_score

    def test_engine_deterministic(self):
        cfg = lenient_config()
        engine1 = KnowledgeUpdateEngine(cfg, KnowledgeStore(cfg))
        engine2 = KnowledgeUpdateEngine(cfg, KnowledgeStore(cfg))
        key = urban_pedestrian_key()
        records = make_experiences(["SUCCESS"] * 3)
        r1 = engine1.process_experiences(key, records)
        r2 = engine2.process_experiences(key, records)
        assert r1.knowledge_id == r2.knowledge_id
        assert r1.update_type == r2.update_type

    def test_no_randomness_in_confidence(self):
        agg = make_agg()
        key = urban_pedestrian_key()
        records = make_experiences(["SUCCESS"] * 5)
        confidences = {agg.aggregate(key, records).confidence for _ in range(10)}
        assert len(confidences) == 1  # all identical


from core.experience.knowledge import KnowledgeStatus  # needed above
