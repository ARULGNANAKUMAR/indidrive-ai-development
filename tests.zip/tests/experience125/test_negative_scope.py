"""
IndiDrive AI — Phase 12.5 | Negative Scope Tests
=================================================
Explicitly verify that Phase 12.5 does NOT implement Phase 12.6 capabilities:

    - NO change to planner decisions
    - NO modification of control commands
    - NO modification of MPC parameters
    - NO modification of tracking parameters
    - NO modification of safety thresholds
    - NO automatic trajectory generation
    - NO reinforcement learning
    - NO reward signals
    - NO model retraining
    - NO automatic policy change
    - NO direct action selection from knowledge
    - NO SafetyGate modification

These are regression tests.  If a future developer accidentally connects
the knowledge layer to the control pipeline, these tests must FAIL and
alert the developer.
"""
from __future__ import annotations

import inspect
import sys

import pytest

from core.experience.knowledge import (
    KnowledgeEntry,
    KnowledgeUpdateResult,
    KnowledgeContext,
    KnowledgeUpdateEngine,
    KnowledgeStore,
)
from tests.experience125.exp125_helpers import (
    lenient_config, make_engine, urban_pedestrian_key, make_experiences,
)


# ---------------------------------------------------------------------------
# No planner modification
# ---------------------------------------------------------------------------

class TestNoPlannerModification:
    def test_result_has_no_planner_field(self):
        result_fields = set(KnowledgeUpdateResult.__dataclass_fields__)
        for f in result_fields:
            assert "planner" not in f.lower()
            assert "trajectory" not in f.lower()
            assert "waypoint" not in f.lower()
            assert "path" not in f.lower()

    def test_engine_has_no_set_planner_method(self):
        engine = make_engine()
        for method in dir(engine):
            assert "planner" not in method.lower()
            assert "set_trajectory" not in method.lower()
            assert "generate_path" not in method.lower()

    def test_knowledge_entry_has_no_trajectory_field(self):
        fields = set(KnowledgeEntry.__dataclass_fields__)
        for f in fields:
            assert "trajectory" not in f.lower()
            assert "waypoint" not in f.lower()
            assert "path" not in f.lower()

    def test_no_planner_import_in_knowledge_package(self):
        modules = [
            "core.experience.knowledge.knowledge_types",
            "core.experience.knowledge.knowledge_store",
            "core.experience.knowledge.evidence_aggregator",
            "core.experience.knowledge.knowledge_validator",
            "core.experience.knowledge.knowledge_update_engine",
        ]
        for mod_name in modules:
            if mod_name in sys.modules:
                src = inspect.getsource(sys.modules[mod_name])
                assert "planner_engine" not in src
                assert "replanning_engine" not in src
                assert "candidate_generator" not in src


# ---------------------------------------------------------------------------
# No control command modification
# ---------------------------------------------------------------------------

class TestNoControlCommandModification:
    def test_result_has_no_steering_field(self):
        for f in KnowledgeUpdateResult.__dataclass_fields__:
            assert "steering" not in f.lower()
            assert "throttle" not in f.lower()
            assert "brake" not in f.lower()
            assert "accel" not in f.lower()

    def test_context_has_no_control_fields(self):
        engine = make_engine(lenient_config())
        result = engine.process_experiences(
            urban_pedestrian_key(), make_experiences(["SUCCESS"] * 2)
        )
        ctx = engine.store.get_knowledge_context(result.knowledge_id)
        if ctx is None:
            return
        for field_name in vars(ctx):
            assert "steering" not in field_name.lower()
            assert "throttle" not in field_name.lower()
            assert "brake" not in field_name.lower()
            assert "accel" not in field_name.lower()
            assert "speed_limit" not in field_name.lower()

    def test_entry_has_no_control_fields(self):
        for f in KnowledgeEntry.__dataclass_fields__:
            assert "steering" not in f.lower()
            assert "throttle" not in f.lower()
            assert "brake_command" not in f.lower()


# ---------------------------------------------------------------------------
# No MPC modification
# ---------------------------------------------------------------------------

class TestNoMPCModification:
    def test_no_mpc_in_knowledge_types(self):
        """MPC config types must not appear in executable code (docstring mentions ok)."""
        import ast
        import core.experience.knowledge.knowledge_types as mod
        tree = ast.parse(inspect.getsource(mod))
        code_only = ast.unparse(tree)
        for token in ("MpcConfig", "mpc_config", "mpc_tuning"):
            assert token not in code_only

    def test_no_mpc_in_engine(self):
        import core.experience.knowledge.knowledge_update_engine as mod
        src = inspect.getsource(mod)
        assert "mpc_" not in src

    def test_result_has_no_mpc_field(self):
        for f in KnowledgeUpdateResult.__dataclass_fields__:
            assert "mpc" not in f.lower()


# ---------------------------------------------------------------------------
# No RL / reward / retraining
# ---------------------------------------------------------------------------

class TestNoReinforcementLearning:
    def test_no_reward_in_knowledge_types(self):
        """No RL reward code in executable knowledge types (docstrings ok)."""
        import ast
        import core.experience.knowledge.knowledge_types as mod
        tree = ast.parse(inspect.getsource(mod))
        code_only = ast.unparse(tree)
        for token in ("reward_function", "compute_reward", "rl_reward"):
            assert token not in code_only.lower()

    def test_no_reward_in_engine(self):
        import ast
        import core.experience.knowledge.knowledge_update_engine as mod
        tree = ast.parse(inspect.getsource(mod))
        code_only = ast.unparse(tree)
        for token in ("reward_function", "compute_reward", "rl_reward"):
            assert token not in code_only.lower()

    def test_no_retrain_in_engine(self):
        import ast
        import core.experience.knowledge.knowledge_update_engine as mod
        tree = ast.parse(inspect.getsource(mod))
        code_only = ast.unparse(tree)
        assert "retrain" not in code_only.lower()
        assert "model_update" not in code_only.lower()

    def test_no_policy_field_in_entry(self):
        for f in KnowledgeEntry.__dataclass_fields__:
            assert "policy" not in f.lower()
            assert "reward" not in f.lower()

    def test_update_type_has_no_rl_values(self):
        from core.experience.knowledge import UpdateType
        for ut in UpdateType:
            assert "reward" not in ut.value.lower()
            assert "policy" not in ut.value.lower()
            assert "retrain" not in ut.value.lower()


# ---------------------------------------------------------------------------
# No automatic policy change
# ---------------------------------------------------------------------------

class TestNoAutomaticPolicyChange:
    def test_no_set_policy_in_engine(self):
        engine = make_engine()
        for method in dir(engine):
            assert "set_policy" not in method.lower()
            assert "apply_policy" not in method.lower()
            assert "update_policy" not in method.lower()

    def test_store_has_no_policy_write(self):
        store = KnowledgeStore()
        for method in dir(store):
            assert "policy" not in method.lower()

    def test_knowledge_terminates_at_store(self):
        """
        Regression: verify that process_experiences returns a result
        and does NOT call into planner or vehicle systems.
        """
        engine = make_engine(lenient_config())
        result = engine.process_experiences(
            urban_pedestrian_key(), make_experiences(["SUCCESS"] * 3)
        )
        # Result is KnowledgeUpdateResult — not a planner action or vehicle command
        assert isinstance(result, KnowledgeUpdateResult)
        assert not hasattr(result, "steering_angle")
        assert not hasattr(result, "throttle_percent")
        assert not hasattr(result, "brake_pressure")
        assert not hasattr(result, "trajectory")


# ---------------------------------------------------------------------------
# No direct action selection from knowledge
# ---------------------------------------------------------------------------

class TestNoDirectActionSelection:
    def test_context_has_no_select_action(self):
        engine = make_engine(lenient_config())
        result = engine.process_experiences(
            urban_pedestrian_key(), make_experiences(["SUCCESS"] * 2)
        )
        ctx = engine.store.get_knowledge_context(result.knowledge_id)
        if ctx is None:
            return
        assert not hasattr(ctx, "select_action")
        assert not hasattr(ctx, "get_action")
        assert not hasattr(ctx, "recommend_action")
        assert not hasattr(ctx, "best_action")

    def test_observed_relationship_is_descriptive_not_imperative(self):
        from core.experience.knowledge import EvidenceAggregator
        agg = EvidenceAggregator(lenient_config())
        key = urban_pedestrian_key()
        cand = agg.aggregate(key, make_experiences(["SUCCESS"] * 3))
        rel = cand.observed_relationship.lower()
        # Should contain observational keywords
        assert any(word in rel for word in ("observed", "experience", "context")), \
            f"Observed relationship is not descriptive: {cand.observed_relationship}"


# ---------------------------------------------------------------------------
# Phase boundary marker tests
# ---------------------------------------------------------------------------

class TestPhaseBoundary:
    def test_source_phase_is_12_5_not_12_6(self):
        engine = make_engine(lenient_config())
        result = engine.process_experiences(
            urban_pedestrian_key(), make_experiences(["SUCCESS"] * 2)
        )
        if result.knowledge_id:
            raw = engine.store._entries.get(result.knowledge_id)
            if raw is not None:
                assert raw.source_phase == "12.5"
                assert raw.source_phase != "12.6"

    def test_schema_version_is_12_5(self):
        from core.experience.knowledge import KNOWLEDGE_SCHEMA_VERSION
        assert KNOWLEDGE_SCHEMA_VERSION == "12.5"

    def test_no_phase_12_6_module_imported(self):
        knowledge_modules = [k for k in sys.modules if "knowledge" in k.lower()]
        for mod_name in knowledge_modules:
            assert "phase12_6" not in mod_name.lower()
            assert "12_6" not in mod_name.lower()
