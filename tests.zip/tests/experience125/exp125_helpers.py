"""
IndiDrive AI — Phase 12.5 | Test Helpers
=========================================
Shared fixtures and factory functions for Phase 12.5 test suite.
"""
from __future__ import annotations

import time
from typing import List, Optional

from core.experience.knowledge import (
    AdaptiveKnowledgeConfig,
    KnowledgeContextKey,
    KnowledgeStore,
    KnowledgeUpdateEngine,
)

# ---------------------------------------------------------------------------
# Default minimal config
# ---------------------------------------------------------------------------

def default_config(
    minimum_evidence_count: int = 3,
    minimum_confidence: float = 0.40,
    minimum_consistency: float = 0.60,
    minimum_success_ratio: float = 0.0,
    stale_after_seconds: float = 0.0,
    maximum_entries: int = 100,
) -> AdaptiveKnowledgeConfig:
    return AdaptiveKnowledgeConfig(
        enabled=True,
        minimum_evidence_count=minimum_evidence_count,
        minimum_confidence=minimum_confidence,
        minimum_consistency=minimum_consistency,
        minimum_success_ratio=minimum_success_ratio,
        allow_partial_evidence=True,
        allow_degraded_evidence=True,
        allow_negative_evidence=True,
        safety_minimum_evidence_count=5,
        safety_minimum_confidence=0.60,
        stale_after_seconds=stale_after_seconds,
        maximum_entries=maximum_entries,
        maximum_history_per_entry=5,
        maximum_evidence_per_entry=50,
    )


def lenient_config() -> AdaptiveKnowledgeConfig:
    """Config with minimum_evidence_count=1 for single-observation tests."""
    return default_config(minimum_evidence_count=1, minimum_confidence=0.01,
                          minimum_consistency=0.0)


def make_engine(config: Optional[AdaptiveKnowledgeConfig] = None
                ) -> KnowledgeUpdateEngine:
    cfg = config or default_config()
    store = KnowledgeStore(cfg)
    return KnowledgeUpdateEngine(cfg, store)


# ---------------------------------------------------------------------------
# Context key factories
# ---------------------------------------------------------------------------

def urban_pedestrian_key() -> KnowledgeContextKey:
    return KnowledgeContextKey(
        road_type="URBAN",
        road_structure="MULTI_LANE",
        intersection_state="ACTIVE",
        hazard_level="MEDIUM",
        dominant_hazard="PEDESTRIAN",
        traffic_density="MEDIUM",
        vulnerable_road_user_present=True,
        safety_state="SAFE",
        situation_type="PEDESTRIAN_CROSSING",
    )


def highway_key() -> KnowledgeContextKey:
    return KnowledgeContextKey(
        road_type="HIGHWAY",
        road_structure="MULTI_LANE",
        intersection_state="NONE",
        hazard_level="LOW",
        dominant_hazard="NOT_AVAILABLE",
        traffic_density="LOW",
        vulnerable_road_user_present=False,
        safety_state="SAFE",
        situation_type="CRUISE",
    )


def safety_critical_key() -> KnowledgeContextKey:
    return KnowledgeContextKey(
        road_type="URBAN",
        road_structure="SINGLE_LANE",
        intersection_state="ACTIVE",
        hazard_level="CRITICAL",
        dominant_hazard="COLLISION_RISK",
        traffic_density="HIGH",
        vulnerable_road_user_present=True,
        safety_state="UNSAFE",
        situation_type="EMERGENCY_STOP",
    )


# ---------------------------------------------------------------------------
# Experience record factories
# ---------------------------------------------------------------------------

def make_experience(
    outcome_class: str = "SUCCESS",
    confidence: str = "HIGH",
    experience_id: Optional[str] = None,
    session_id: str = "test-session",
    ts: Optional[float] = None,
) -> dict:
    eid = experience_id or f"{session_id}-R{int(time.time()*1000) % 1_000_000:06d}"
    return {
        "experience_id": eid,
        "evaluation_id": f"{eid}-EVAL",
        "session_id": session_id,
        "outcome_class": outcome_class,
        "evaluation_confidence": confidence,
        "experience_timestamp": ts or time.time(),
    }


def make_experiences(outcomes: List[str], confidence: str = "HIGH",
                     session_id: str = "sess") -> List[dict]:
    """Create a list of experience records with sequential IDs."""
    result = []
    base_ts = 1_700_000_000.0
    for i, oc in enumerate(outcomes):
        result.append({
            "experience_id": f"{session_id}-R{i:06d}",
            "evaluation_id": f"{session_id}-R{i:06d}-EVAL",
            "session_id": session_id,
            "outcome_class": oc,
            "evaluation_confidence": confidence,
            "experience_timestamp": base_ts + i * 60.0,
        })
    return result
