"""
IndiDrive AI — Phase 6.1 test suite: Drivable Area & Road Boundary Understanding.
Synthetic point clouds only (no CARLA / real sensor / dataset required),
mirroring the style of tests/perception/test_lidar_perception.py.
"""
import math
import sys
from pathlib import Path

import numpy as np
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))

from core.perception.road_understanding import RoadUnderstandingPipeline, RoadUnderstandingConfig
from core.perception.road_understanding_types import RoadUnderstandingStatus, BoundaryAvailability
from core.perception.perception_types import RoadState, DrivableArea, BackendKind, NOT_AVAILABLE
from core.perception.lidar_perception import LiDARPerceptionPipeline, LiDARPerceptionResult, ProcessingMetrics


# ---------------------------------------------------------------------------
# Synthetic point-cloud helpers (vehicle frame: +X forward, +Y left, +Z up)
# ---------------------------------------------------------------------------

def _straight_road(width=6.0, length=40.0, n_ground=600, obstacles=True, seed=0):
    rng = np.random.default_rng(seed)
    x = rng.uniform(0, length, n_ground)
    y = rng.uniform(-width / 2 + 0.3, width / 2 - 0.3, n_ground)
    z = rng.normal(0, 0.02, n_ground)
    ground = np.stack([x, y, z, rng.uniform(0, 1, n_ground)], axis=1)
    if not obstacles:
        return ground.astype(np.float32)
    xs = np.repeat(np.arange(2, length, 4.0), 5)
    jitter = rng.normal(0, 0.2, xs.shape[0])
    left_obs = np.stack([xs + jitter, np.full(xs.shape[0], width / 2) + rng.normal(0, 0.05, xs.shape[0]),
                          rng.uniform(0.2, 1.0, xs.shape[0]), rng.uniform(0, 1, xs.shape[0])], axis=1)
    right_obs = np.stack([xs + jitter, np.full(xs.shape[0], -width / 2) + rng.normal(0, 0.05, xs.shape[0]),
                           rng.uniform(0.2, 1.0, xs.shape[0]), rng.uniform(0, 1, xs.shape[0])], axis=1)
    return np.vstack([ground, left_obs, right_obs]).astype(np.float32)


def _curved_road(width=6.0, length=40.0, n_ground=800, curvature=0.02, seed=1):
    rng = np.random.default_rng(seed)
    x = rng.uniform(0, length, n_ground)
    centerline = curvature * x ** 2   # gentle quadratic curve, growing offset with distance
    y = centerline + rng.uniform(-width / 2 + 0.3, width / 2 - 0.3, n_ground)
    z = rng.normal(0, 0.02, n_ground)
    ground = np.stack([x, y, z, rng.uniform(0, 1, n_ground)], axis=1)
    xs = np.repeat(np.arange(2, length, 4.0), 5)
    jitter = rng.normal(0, 0.2, xs.shape[0])
    c = curvature * xs ** 2
    left_obs = np.stack([xs + jitter, c + width / 2 + rng.normal(0, 0.05, xs.shape[0]),
                          rng.uniform(0.2, 1.0, xs.shape[0]), rng.uniform(0, 1, xs.shape[0])], axis=1)
    right_obs = np.stack([xs + jitter, c - width / 2 + rng.normal(0, 0.05, xs.shape[0]),
                           rng.uniform(0.2, 1.0, xs.shape[0]), rng.uniform(0, 1, xs.shape[0])], axis=1)
    return np.vstack([ground, left_obs, right_obs]).astype(np.float32)


def _asymmetric_road(left_w=2.0, right_w=5.0, length=40.0, n_ground=600, seed=2):
    rng = np.random.default_rng(seed)
    x = rng.uniform(0, length, n_ground)
    y = rng.uniform(-right_w + 0.3, left_w - 0.3, n_ground)
    z = rng.normal(0, 0.02, n_ground)
    ground = np.stack([x, y, z, rng.uniform(0, 1, n_ground)], axis=1)
    xs = np.repeat(np.arange(2, length, 4.0), 5)
    jitter = rng.normal(0, 0.2, xs.shape[0])
    left_obs = np.stack([xs + jitter, np.full(xs.shape[0], left_w) + rng.normal(0, 0.05, xs.shape[0]),
                          rng.uniform(0.2, 1.0, xs.shape[0]), rng.uniform(0, 1, xs.shape[0])], axis=1)
    right_obs = np.stack([xs + jitter, np.full(xs.shape[0], -right_w) + rng.normal(0, 0.05, xs.shape[0]),
                           rng.uniform(0.2, 1.0, xs.shape[0]), rng.uniform(0, 1, xs.shape[0])], axis=1)
    return np.vstack([ground, left_obs, right_obs]).astype(np.float32)


def _one_sided_road(side="left", width=6.0, length=40.0, n_ground=600, seed=3):
    """Only one boundary observed: the opposite side has no LiDAR returns
    at all (fully occluded/out of range), not just "no obstacle" — a real
    occlusion means no ground returns reach that side either."""
    rng = np.random.default_rng(seed)
    x = rng.uniform(0, length, n_ground)
    if side == "left":
        y = rng.uniform(0.0, width / 2 - 0.3, n_ground)     # no returns to the right at all
    else:
        y = rng.uniform(-width / 2 + 0.3, 0.0, n_ground)    # no returns to the left at all
    z = rng.normal(0, 0.02, n_ground)
    ground = np.stack([x, y, z, rng.uniform(0, 1, n_ground)], axis=1)
    xs = np.repeat(np.arange(2, length, 4.0), 5)
    jitter = rng.normal(0, 0.2, xs.shape[0])
    sign = 1.0 if side == "left" else -1.0
    obs = np.stack([xs + jitter, np.full(xs.shape[0], sign * width / 2) + rng.normal(0, 0.05, xs.shape[0]),
                     rng.uniform(0.2, 1.0, xs.shape[0]), rng.uniform(0, 1, xs.shape[0])], axis=1)
    return np.vstack([ground, obs]).astype(np.float32)


def _unmarked_village_road(length=30.0, n_ground=400, seed=4):
    """No obstacles at all — an unmarked road with only a loose ground
    plane; boundaries should come back UNAVAILABLE/degraded, not invented."""
    rng = np.random.default_rng(seed)
    x = rng.uniform(0, length, n_ground)
    y = rng.uniform(-2.0, 2.0, n_ground)
    z = rng.normal(0, 0.03, n_ground)
    return np.stack([x, y, z, rng.uniform(0, 1, n_ground)], axis=1).astype(np.float32)


def _lidar_result_from_points(points, timestamp=1.0):
    return LiDARPerceptionPipeline().process(points, timestamp=timestamp)


# ---------------------------------------------------------------------------
# Basic output
# ---------------------------------------------------------------------------

def test_valid_road_understanding_ok_status():
    pipe = RoadUnderstandingPipeline()
    ru = pipe.process(lidar_points=_straight_road(), timestamp=1.0, frame_id=1)
    assert ru.status == RoadUnderstandingStatus.OK
    assert ru.boundary_availability == BoundaryAvailability.BOTH
    assert ru.timestamp == 1.0
    assert ru.frame_id == 1


def test_empty_input_reports_unavailable():
    pipe = RoadUnderstandingPipeline()
    ru = pipe.process(timestamp=1.0, frame_id=1)
    assert ru.status == RoadUnderstandingStatus.UNAVAILABLE
    assert ru.boundary_availability == BoundaryAvailability.NONE
    assert ru.confidence == 0.0
    assert ru.warnings


def test_unavailable_lidar_and_camera_inputs():
    pipe = RoadUnderstandingPipeline()
    rs = RoadState(backend=BackendKind.NOT_CONFIGURED)
    ru = pipe.process(road_state=rs, lidar_result=None, timestamp=2.0)
    assert ru.status == RoadUnderstandingStatus.UNAVAILABLE
    assert ru.sensor_status["camera"] == "NOT_CONFIGURED"
    assert ru.sensor_status["lidar"] == "UNAVAILABLE"


def test_complete_boundary_information_populates_both_sides():
    pipe = RoadUnderstandingPipeline()
    ru = pipe.process(lidar_points=_straight_road(), timestamp=1.0)
    assert ru.left_boundary.available and ru.right_boundary.available
    assert len(ru.left_boundary.points) > 0 and len(ru.right_boundary.points) > 0


def test_partial_boundary_information_one_side_only():
    pipe = RoadUnderstandingPipeline()
    ru = pipe.process(lidar_points=_one_sided_road(side="left"), timestamp=1.0)
    assert ru.boundary_availability == BoundaryAvailability.LEFT_ONLY
    assert ru.status == RoadUnderstandingStatus.PARTIAL
    assert ru.left_boundary.available and not ru.right_boundary.available


# ---------------------------------------------------------------------------
# Boundary tests
# ---------------------------------------------------------------------------

def test_straight_left_right_boundaries_symmetric_and_sane():
    pipe = RoadUnderstandingPipeline()
    ru = pipe.process(lidar_points=_straight_road(width=6.0), timestamp=1.0)
    for p in ru.left_boundary.points:
        assert p.y > 0
    for p in ru.right_boundary.points:
        assert p.y < 0


def test_curved_boundaries_track_the_curve():
    pipe = RoadUnderstandingPipeline()
    ru = pipe.process(lidar_points=_curved_road(curvature=0.02), timestamp=1.0)
    assert ru.boundary_availability == BoundaryAvailability.BOTH
    left_ys = {p.x: p.y for p in ru.left_boundary.points}
    # further out (larger x), curvature pushes the corridor further left
    assert left_ys[30.0] > left_ys[0.0]


def test_asymmetric_boundaries_are_not_forced_symmetric():
    pipe = RoadUnderstandingPipeline()
    ru = pipe.process(lidar_points=_asymmetric_road(left_w=2.0, right_w=5.0), timestamp=1.0)
    left_avg = np.mean([p.y for p in ru.left_boundary.points])
    right_avg = np.mean([p.y for p in ru.right_boundary.points])
    assert left_avg < 2.5           # narrow left side
    assert abs(right_avg) > 3.0     # much wider right side
    assert abs(left_avg) != pytest.approx(abs(right_avg), rel=0.1)


def test_noisy_points_do_not_crash_and_stay_bounded():
    rng = np.random.default_rng(7)
    pts = _straight_road()
    # inject wild outliers far outside any plausible road
    outliers = np.stack([rng.uniform(0, 40, 20), rng.uniform(500, 1000, 20),
                          rng.uniform(-1, 1, 20), rng.uniform(0, 1, 20)], axis=1).astype(np.float32)
    pts_noisy = np.vstack([pts, outliers])
    pipe = RoadUnderstandingPipeline()
    ru = pipe.process(lidar_points=pts_noisy, timestamp=1.0)
    for p in ru.left_boundary.points + ru.right_boundary.points:
        assert abs(p.y) < 20.0   # outliers beyond max_lateral_search_m are ignored, not adopted


def test_partial_boundary_right_only():
    pipe = RoadUnderstandingPipeline()
    ru = pipe.process(lidar_points=_one_sided_road(side="right"), timestamp=1.0)
    assert ru.boundary_availability == BoundaryAvailability.RIGHT_ONLY
    assert not ru.left_boundary.available and ru.right_boundary.available


def test_invalid_boundary_geometry_is_rejected_not_reported():
    pipe = RoadUnderstandingPipeline()
    # Force an implausible boundary by constructing a lidar result directly
    # with obstacle points that cross the vehicle (negative width scenario).
    pts = np.array([
        [10.0, -1.0, 0.0, 0.5],   # "left" obstacle actually on the right
        [10.0, -1.0, 0.0, 0.5],
        [10.0, -1.0, 0.0, 0.5],
        [10.0, -1.0, 0.0, 0.5],
        [10.0, -1.0, 0.0, 0.5],
        [10.0, 1.0, 0.0, 0.5],
        [10.0, 1.0, 0.0, 0.5],
        [10.0, 1.0, 0.0, 0.5],
        [10.0, 1.0, 0.0, 0.5],
        [10.0, 1.0, 0.0, 0.5],
    ], dtype=np.float32)
    ru = pipe.process(lidar_points=pts, timestamp=1.0)
    # Sensible corridor here (left y=1 > right y=-1) so width should be valid;
    # this asserts the pipeline does NOT silently invent geometry elsewhere.
    sample = [s for s in ru.road_width_profile if s.distance_m == 10.0][0]
    assert sample.width_m is None or sample.width_m > 0


# ---------------------------------------------------------------------------
# Drivable area tests
# ---------------------------------------------------------------------------

def test_valid_drivable_corridor_polygon():
    pipe = RoadUnderstandingPipeline()
    ru = pipe.process(lidar_points=_straight_road(), timestamp=1.0)
    assert ru.drivable_polygon is not None
    assert len(ru.drivable_polygon) >= 4


def test_narrow_road_corridor():
    pipe = RoadUnderstandingPipeline()
    ru = pipe.process(lidar_points=_straight_road(width=1.8, length=30, n_ground=400), timestamp=1.0)
    assert ru.drivable_area_available
    widths = [s.width_m for s in ru.road_width_profile if s.width_m is not None]
    if widths:
        assert all(w < 4.0 for w in widths)


def test_wide_road_corridor():
    pipe = RoadUnderstandingPipeline()
    ru = pipe.process(lidar_points=_straight_road(width=14.0, length=40, n_ground=1200), timestamp=1.0)
    widths = [s.width_m for s in ru.road_width_profile if s.width_m is not None]
    assert widths and all(w > 8.0 for w in widths)


def test_irregular_road_still_produces_partial_or_ok():
    pipe = RoadUnderstandingPipeline()
    ru = pipe.process(lidar_points=_asymmetric_road(left_w=1.0, right_w=7.0), timestamp=1.0)
    assert ru.status in (RoadUnderstandingStatus.OK, RoadUnderstandingStatus.PARTIAL)


def test_partial_corridor_no_polygon_when_one_side_missing():
    pipe = RoadUnderstandingPipeline()
    ru = pipe.process(lidar_points=_one_sided_road(side="left"), timestamp=1.0)
    assert ru.drivable_polygon is None


def test_unavailable_corridor_when_no_sensors():
    pipe = RoadUnderstandingPipeline()
    ru = pipe.process(timestamp=1.0)
    assert not ru.drivable_area_available
    assert ru.drivable_polygon is None


# ---------------------------------------------------------------------------
# Road width
# ---------------------------------------------------------------------------

def test_valid_width_matches_expected_road_within_tolerance():
    pipe = RoadUnderstandingPipeline()
    ru = pipe.process(lidar_points=_straight_road(width=6.0, length=40, n_ground=1000), timestamp=1.0)
    widths = [s.width_m for s in ru.road_width_profile if s.width_m is not None]
    assert widths
    assert all(3.5 < w < 6.5 for w in widths)


def test_changing_width_profile_along_curve():
    pipe = RoadUnderstandingPipeline(RoadUnderstandingConfig(forward_distances_m=(5.0, 15.0, 25.0)))
    ru = pipe.process(lidar_points=_curved_road(length=35, curvature=0.0), timestamp=1.0)
    assert len(ru.road_width_profile) == 3


def test_narrow_width_reported_small():
    pipe = RoadUnderstandingPipeline()
    ru = pipe.process(lidar_points=_straight_road(width=2.0, length=30, n_ground=500), timestamp=1.0)
    widths = [s.width_m for s in ru.road_width_profile if s.width_m is not None]
    assert widths and all(w < 3.0 for w in widths)


def test_missing_boundaries_give_missing_width():
    pipe = RoadUnderstandingPipeline()
    ru = pipe.process(lidar_points=_unmarked_village_road(), timestamp=1.0)
    for s in ru.road_width_profile:
        if s.availability != BoundaryAvailability.BOTH:
            assert s.width_m is None


# ---------------------------------------------------------------------------
# Sensor degradation
# ---------------------------------------------------------------------------

def test_camera_unavailable_lidar_only():
    pipe = RoadUnderstandingPipeline()
    ru = pipe.process(lidar_points=_straight_road(), timestamp=1.0)
    assert ru.sensor_status["camera"] == "UNAVAILABLE"
    assert ru.sensor_status["lidar"] == "OK"
    assert ru.source == "lidar"


def test_lidar_unavailable_camera_only():
    pipe = RoadUnderstandingPipeline()
    rs = RoadState(road_present=True, road_confidence=0.6, backend=BackendKind.BASELINE)
    ru = pipe.process(road_state=rs, timestamp=1.0)
    assert ru.sensor_status["lidar"] == "UNAVAILABLE"
    assert ru.source == "camera"
    assert ru.boundary_availability == BoundaryAvailability.NONE  # no fabricated geometry


def test_both_sensors_unavailable():
    pipe = RoadUnderstandingPipeline()
    ru = pipe.process(timestamp=1.0)
    assert ru.status == RoadUnderstandingStatus.UNAVAILABLE
    assert ru.sensor_status == {"camera": "UNAVAILABLE", "lidar": "UNAVAILABLE"}


def test_stale_lidar_frame_excluded():
    pipe = RoadUnderstandingPipeline()
    ru = pipe.process(lidar_points=_straight_road(), timestamp=10.0, lidar_timestamp=5.0)
    assert ru.sensor_status["lidar"] == "STALE"
    assert ru.status == RoadUnderstandingStatus.UNAVAILABLE


def test_empty_lidar_input_handled_gracefully():
    pipe = RoadUnderstandingPipeline()
    ru = pipe.process(lidar_points=np.zeros((0, 4), dtype=np.float32), timestamp=1.0)
    assert ru.sensor_status["lidar"] == "EMPTY_POINT_CLOUD"
    assert ru.status == RoadUnderstandingStatus.UNAVAILABLE


def test_malformed_lidar_frame_handled_gracefully():
    pipe = RoadUnderstandingPipeline()
    bad = np.zeros((5, 5, 2))  # wrong shape entirely
    ru = pipe.process(lidar_points=bad, timestamp=1.0)
    assert ru.sensor_status["lidar"] == "INVALID_FRAME"
    assert ru.status == RoadUnderstandingStatus.UNAVAILABLE


def test_both_sensors_available_uses_fusion_source():
    pipe = RoadUnderstandingPipeline()
    rs = RoadState(road_present=True, road_confidence=0.8, backend=BackendKind.BASELINE)
    ru = pipe.process(road_state=rs, lidar_points=_straight_road(), timestamp=1.0)
    assert ru.source == "fusion"
    assert ru.sensor_status == {"camera": "OK", "lidar": "OK"}


def test_reused_lidar_result_avoids_recomputation():
    pts = _straight_road()
    lidar_result = _lidar_result_from_points(pts, timestamp=1.0)
    pipe = RoadUnderstandingPipeline()
    ru = pipe.process(lidar_result=lidar_result, timestamp=1.0)
    assert ru.status == RoadUnderstandingStatus.OK


# ---------------------------------------------------------------------------
# Coordinate validation
# ---------------------------------------------------------------------------

def test_valid_vehicle_relative_coordinates():
    pipe = RoadUnderstandingPipeline()
    ru = pipe.process(lidar_points=_straight_road(), timestamp=1.0)
    for p in ru.left_boundary.points + ru.right_boundary.points:
        assert math.isfinite(p.x) and math.isfinite(p.y)


def test_nan_points_are_filtered_not_propagated():
    pts = _straight_road()
    pts[0, 0] = np.nan
    pts[1, 1] = np.nan
    pipe = RoadUnderstandingPipeline()
    ru = pipe.process(lidar_points=pts, timestamp=1.0)
    for p in ru.left_boundary.points + ru.right_boundary.points:
        assert math.isfinite(p.x) and math.isfinite(p.y)


def test_infinite_points_are_filtered_not_propagated():
    pts = _straight_road()
    pts[2, 1] = np.inf
    pts[3, 1] = -np.inf
    pipe = RoadUnderstandingPipeline()
    ru = pipe.process(lidar_points=pts, timestamp=1.0)
    for p in ru.left_boundary.points + ru.right_boundary.points:
        assert math.isfinite(p.y)


def test_inconsistent_geometry_produces_no_negative_width():
    pipe = RoadUnderstandingPipeline()
    ru = pipe.process(lidar_points=_straight_road(), timestamp=1.0)
    for s in ru.road_width_profile:
        if s.width_m is not None:
            assert s.width_m > 0


# ---------------------------------------------------------------------------
# Confidence
# ---------------------------------------------------------------------------

def test_high_confidence_dense_points():
    pipe = RoadUnderstandingPipeline()
    ru = pipe.process(lidar_points=_straight_road(n_ground=1500), timestamp=1.0)
    assert ru.confidence > 0.5


def test_low_confidence_sparse_points():
    pipe = RoadUnderstandingPipeline()
    pts = _straight_road(width=6.0, length=40, n_ground=30, obstacles=False, seed=9)
    # add just barely enough obstacle points to register a boundary, but sparse
    rng = np.random.default_rng(9)
    sparse_obs = np.array([[10.0, 3.0, 0.3, 0.5]] * 5 + [[10.0, -3.0, 0.3, 0.5]] * 5, dtype=np.float32)
    pts = np.vstack([pts, sparse_obs])
    ru = pipe.process(lidar_points=pts, timestamp=1.0)
    assert ru.confidence <= 1.0  # sanity bound; sparse input must not report inflated confidence
    assert ru.confidence < 0.9


def test_missing_confidence_when_unavailable():
    pipe = RoadUnderstandingPipeline()
    ru = pipe.process(timestamp=1.0)
    assert ru.confidence == 0.0
    assert ru.uncertainty == 1.0


def test_invalid_confidence_never_out_of_range():
    pipe = RoadUnderstandingPipeline()
    for pts in (_straight_road(), _unmarked_village_road(), _asymmetric_road()):
        ru = pipe.process(lidar_points=pts, timestamp=1.0)
        assert 0.0 <= ru.confidence <= 1.0
        assert 0.0 <= ru.uncertainty <= 1.0


# ---------------------------------------------------------------------------
# Determinism
# ---------------------------------------------------------------------------

def test_determinism_same_input_same_output():
    pipe = RoadUnderstandingPipeline()
    pts = _curved_road()
    r1 = pipe.process(lidar_points=pts.copy(), timestamp=1.0, frame_id=1).to_dict()
    r2 = pipe.process(lidar_points=pts.copy(), timestamp=1.0, frame_id=1).to_dict()
    assert r1 == r2


def test_determinism_across_separate_pipeline_instances():
    pts = _asymmetric_road()
    r1 = RoadUnderstandingPipeline().process(lidar_points=pts.copy(), timestamp=1.0).to_dict()
    r2 = RoadUnderstandingPipeline().process(lidar_points=pts.copy(), timestamp=1.0).to_dict()
    assert r1 == r2


# ---------------------------------------------------------------------------
# Indian road cases (synthetic, lightweight — Step 26)
# ---------------------------------------------------------------------------

def test_unmarked_village_road_no_fabricated_boundaries():
    pipe = RoadUnderstandingPipeline()
    ru = pipe.process(lidar_points=_unmarked_village_road(), timestamp=1.0)
    # no obstacles at all -> boundaries should not be confidently invented
    assert ru.status in (RoadUnderstandingStatus.DEGRADED, RoadUnderstandingStatus.PARTIAL,
                          RoadUnderstandingStatus.UNAVAILABLE)


def test_narrow_indian_road():
    pipe = RoadUnderstandingPipeline()
    ru = pipe.process(lidar_points=_straight_road(width=2.5, length=25, n_ground=400), timestamp=1.0)
    assert ru.drivable_area_available


def test_asymmetric_indian_road_shoulder():
    pipe = RoadUnderstandingPipeline()
    ru = pipe.process(lidar_points=_asymmetric_road(left_w=1.5, right_w=4.5), timestamp=1.0)
    assert ru.boundary_availability != BoundaryAvailability.NONE


def test_curved_indian_road():
    pipe = RoadUnderstandingPipeline()
    ru = pipe.process(lidar_points=_curved_road(curvature=0.015), timestamp=1.0)
    assert ru.status in (RoadUnderstandingStatus.OK, RoadUnderstandingStatus.PARTIAL)


def test_partially_occluded_indian_road():
    pipe = RoadUnderstandingPipeline()
    ru = pipe.process(lidar_points=_one_sided_road(side="right"), timestamp=1.0)
    assert ru.status == RoadUnderstandingStatus.PARTIAL
    assert ru.boundary_availability == BoundaryAvailability.RIGHT_ONLY


# ---------------------------------------------------------------------------
# Config / disabled
# ---------------------------------------------------------------------------

def test_disabled_via_config_returns_unavailable():
    pipe = RoadUnderstandingPipeline(RoadUnderstandingConfig(enabled=False))
    ru = pipe.process(lidar_points=_straight_road(), timestamp=1.0)
    assert ru.status == RoadUnderstandingStatus.UNAVAILABLE
    assert ru.sensor_status["lidar"] == "DISABLED"


def test_config_from_dict_roundtrip():
    cfg = RoadUnderstandingConfig.from_dict({
        "enabled": True, "minimum_confidence": 0.4, "forward_distances_m": [0, 5, 10],
        "min_points_per_sample": 3,
    })
    assert cfg.minimum_confidence == 0.4
    assert cfg.forward_distances_m == (0, 5, 10)
    assert cfg.min_points_per_sample == 3


def test_to_dict_is_json_serializable():
    import json
    pipe = RoadUnderstandingPipeline()
    ru = pipe.process(lidar_points=_straight_road(), timestamp=1.0)
    json.dumps(ru.to_dict())  # raises if not serializable
