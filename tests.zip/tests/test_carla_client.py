"""
Tests for the parts of carla_client that can be verified WITHOUT a real
CARLA install: SensorBus thread-safety/decoding logic, and the
connection module's honest failure path when `carla` isn't importable
(which is the actual state of the sandbox this was built in — this
test exercises a real code path, not a hypothetical one).

Tests that need an actual CARLA server (vehicle spawn, live camera
frames) are NOT included here — they belong in an integration test run
on a machine with CARLA running, since faking them would just be
testing a mock, not this code.
"""
import sys
import threading
from pathlib import Path

import numpy as np
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from core.carla_integration.sensors import SensorBus, _decode_rgb_image, _decode_lidar
from core.carla_integration.connection import CarlaConnection, CarlaUnavailableError


class FakeCarlaImage:
    """Mimics carla.Image's raw_data/height/width shape (BGRA bytes)."""
    def __init__(self, height, width):
        self.height = height
        self.width = width
        # deterministic pattern so we can check the decode did the right thing
        arr = np.zeros((height, width, 4), dtype=np.uint8)
        arr[..., 0] = 10   # B
        arr[..., 1] = 20   # G
        arr[..., 2] = 30   # R
        arr[..., 3] = 255  # A
        self.raw_data = arr.tobytes()


class FakeLidarMeasurement:
    def __init__(self, n_points):
        arr = np.random.rand(n_points, 4).astype(np.float32)
        self.raw_data = arr.tobytes()
        self._n = n_points


def test_decode_rgb_image_channel_order():
    img = FakeCarlaImage(height=4, width=6)
    decoded = _decode_rgb_image(img)
    assert decoded.shape == (4, 6, 3)
    # BGRA (10,20,30) should decode to RGB (30,20,10)
    assert decoded[0, 0, 0] == 30  # R
    assert decoded[0, 0, 1] == 20  # G
    assert decoded[0, 0, 2] == 10  # B


def test_decode_lidar_shape():
    meas = FakeLidarMeasurement(n_points=100)
    decoded = _decode_lidar(meas)
    assert decoded.shape == (100, 4)


def test_sensor_bus_stores_latest_and_counts():
    bus = SensorBus()
    cb = bus._make_callback("test_sensor", decode_fn=lambda x: x * 2)
    cb(5)
    cb(7)
    assert bus.get("test_sensor") == 14
    assert bus.frame_count("test_sensor") == 2
    assert "test_sensor" in bus.all_names()


def test_sensor_bus_thread_safety_under_concurrent_writes():
    bus = SensorBus()
    cb = bus._make_callback("concurrent", decode_fn=lambda x: x)

    def hammer(val):
        for _ in range(200):
            cb(val)

    threads = [threading.Thread(target=hammer, args=(i,)) for i in range(8)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()

    # No crash, and count reflects all writes across all threads.
    assert bus.frame_count("concurrent") == 8 * 200
    assert bus.get("concurrent") in range(8)


def test_connection_fails_honestly_without_carla_installed():
    """
    This sandbox genuinely does not have `carla` installed — so this
    test exercises the real fallback path, not a simulated one.
    """
    conn = CarlaConnection(host="localhost", port=2000, timeout=1.0)
    with pytest.raises(CarlaUnavailableError) as exc_info:
        conn.connect()
    assert "carla" in str(exc_info.value).lower()
    assert "CARLA_SETUP.md" in str(exc_info.value)
