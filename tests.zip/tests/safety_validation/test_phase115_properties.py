"""
Phase 11.5 — Property-Based and Component Validation Tests
===========================================================
Spec sections 7–10 (per-phase validation) and 29 (property-style tests).

Section 7  — Phase 11.1 Safety Monitor state validation.
Section 8  — Phase 11.2 Emergency Detection validation.
Section 9  — Phase 11.3 Safety Supervisor validation.
Section 10 — Phase 11.4 Fail-Safe validation.
Section 29 — Property-style tests A–G.
Section 32 — Performance validation (measured values only).
"""
from __future__ import annotations

import time
try:
    import pytest
except ImportError:
    class _RaisesCtx:
        def __init__(self, exc_types):
            self._exc = exc_types if isinstance(exc_types, tuple) else (exc_types,)
        def __enter__(self): return self
        def __exit__(self, exc_type, exc_val, tb):
            if exc_type is None:
                raise AssertionError(f"Expected {self._exc} but no exception was raised")
            return issubclass(exc_type, self._exc)
    class _Pytest:
        @staticmethod
        def raises(exc): return _RaisesCtx(exc)
        @staticmethod
        def fail(msg): raise AssertionError(msg)
    pytest = _Pytest()

    def fixture(fn=None, **kw):
        if fn is not None: return fn
        def decorator(f): return f
        return decorator
    pytest.fixture = fixture

from core.safety_validation import (
    SafetyScenarioRunner,
    SafetyValidationEngine,
    FaultSpec,
    FaultTarget,
    FaultType,
    InvariantId,
    ScenarioCategory,
    ScenarioSpec,
    ValidationStatus,
)
from core.safety_validation.validation_types import AssertionResult
from core.safety.safety_types import SafetyState
from core.safety.emergency_types import EmergencyState
from core.safety_supervisor.supervisor_types import ControlAuthority
from core.failsafe.failsafe_types import FailSafeState

from .helpers_115 import (
    T, make_runner, make_engine,
    normal_spec, camera_fault_spec, lidar_fault_spec,
    planning_fault_spec, mpc_fault_spec, control_fault_spec,
    multi_fault_spec,
    assert_pass, assert_not_normal,
    assert_invariant_a_not_violated, assert_invariant_b_not_violated,
)


@pytest.fixture
def runner():
    return make_runner()


@pytest.fixture
def engine():
    return make_engine()


# ===========================================================================
# Section 7 — Phase 11.1 Safety Monitor State Validation
# ===========================================================================

class TestSafetyMonitorValidation:
    """
    Validate each Safety Monitor state is reachable and correctly propagates.
    """

    def test_safe_state_healthy_inputs(self, runner):
        """SAFE state: all healthy inputs produce SAFE from Safety Monitor."""
        spec = normal_spec("sm_01", cycles=3)
        result, _ = runner.run(spec)
        assert result.actual_safety_state == SafetyState.SAFE.value

    def test_caution_or_restricted_on_degraded_input(self, runner):
        """Degraded inputs should produce at minimum CAUTION or above."""
        spec = ScenarioSpec(
            scenario_id="sm_02",
            category=ScenarioCategory.DEGRADED_OPERATION.value,
            description="Degraded planning → safety state elevated from SAFE",
            faults=(
                FaultSpec(FaultTarget.PLANNING, FaultType.DEGRADED, activation_cycle=0),
            ),
            cycles=4,
            severity="MEDIUM",
        )
        result, _ = runner.run(spec)
        # Should not remain SAFE when planning is degraded
        assert result.actual_safety_state != SafetyState.SAFE.value, (
            f"Planning degraded but safety state stayed SAFE: {result.actual_safety_state}"
        )

    def test_degraded_state_on_world_model_failure(self, runner):
        """World model failure should produce DEGRADED or CRITICAL safety state."""
        spec = ScenarioSpec(
            scenario_id="sm_03",
            category=ScenarioCategory.CRITICAL_FAILURE.value,
            description="World model failure → DEGRADED or CRITICAL safety state",
            faults=(
                FaultSpec(FaultTarget.WORLD_MODEL, FaultType.UNAVAILABLE, activation_cycle=0),
            ),
            cycles=4,
            severity="HIGH",
        )
        result, _ = runner.run(spec)
        assert result.actual_safety_state not in (
            SafetyState.SAFE.value,
            SafetyState.CAUTION.value,
        ), f"WM failure should produce DEGRADED/CRITICAL/RESTRICTED, got {result.actual_safety_state}"

    def test_critical_state_on_control_failure(self, runner):
        """Control failure should propagate to CRITICAL or at least RESTRICTED safety state."""
        spec = control_fault_spec("sm_04", cycles=4)
        result, _ = runner.run(spec)
        assert result.actual_safety_state in (
            SafetyState.CRITICAL.value,
            SafetyState.HIGH_ALERT.value,
            SafetyState.RESTRICTED.value,
            SafetyState.DEGRADED.value,
            SafetyState.UNKNOWN.value,
        ), f"Control failure should elevate safety state, got {result.actual_safety_state}"

    def test_safety_state_unknown_when_monitor_unavailable(self, runner):
        """Safety Monitor unavailable → safety state UNKNOWN."""
        spec = ScenarioSpec(
            scenario_id="sm_05",
            category=ScenarioCategory.CRITICAL_FAILURE.value,
            description="Safety Monitor unavailable",
            faults=(
                FaultSpec(FaultTarget.SAFETY_MONITOR, FaultType.UNAVAILABLE, activation_cycle=0),
            ),
            cycles=4,
            severity="CRITICAL",
        )
        result, _ = runner.run(spec)
        # Safety Monitor unavailable → unknown state → must not allow NORMAL_CONTROL
        assert_not_normal(result, "safety monitor unavailable")

    def test_stale_safety_state_not_treated_as_fresh(self, runner):
        """
        Camera offline (simulating timeout/staleness at the sensor health level)
        must restrict control — stale sensor data cannot be treated as fresh.
        (At the failsafe layer, STALE camera maps to OFFLINE health state,
        which immediately triggers restriction — Invariant C satisfied.)
        """
        spec = ScenarioSpec(
            scenario_id="sm_06",
            category=ScenarioCategory.STALE_DATA.value,
            description="Camera offline/stale → safety monitor must not produce SAFE+NORMAL",
            faults=(
                FaultSpec(FaultTarget.CAMERA, FaultType.UNAVAILABLE, activation_cycle=0),
            ),
            cycles=4,
            invariants_to_check=(InvariantId.INVARIANT_C_STALE_IS_NOT_FRESH.value,),
            severity="HIGH",
        )
        result, _ = runner.run(spec)
        assert_not_normal(result, "camera offline (stale sensor data)")

    def test_invalid_input_does_not_yield_safe_state(self, runner):
        """Invalid sensor data must not produce SAFE state from Safety Monitor."""
        spec = ScenarioSpec(
            scenario_id="sm_07",
            category=ScenarioCategory.INVALID_DATA.value,
            description="Invalid camera data → safety monitor must not yield SAFE",
            faults=(
                FaultSpec(FaultTarget.CAMERA, FaultType.INVALID_DATA, activation_cycle=0),
            ),
            cycles=4,
            invariants_to_check=(InvariantId.INVARIANT_D_INVALID_IS_NOT_TRUSTED.value,),
            severity="HIGH",
        )
        result, _ = runner.run(spec)
        assert_not_normal(result, "invalid camera data (safety monitor)")


# ===========================================================================
# Section 8 — Phase 11.2 Emergency Detection Validation
# ===========================================================================

class TestEmergencyDetectionValidation:
    """
    Validate Emergency Detection state transitions and invariants.
    Does not implement another emergency detector — uses existing engine outputs.
    """

    def test_no_emergency_in_healthy_state(self, runner):
        """Healthy inputs → NO_EMERGENCY from Emergency Detector."""
        spec = normal_spec("em_01", cycles=3)
        result, _ = runner.run(spec)
        assert result.actual_emergency_state == EmergencyState.NO_EMERGENCY.value

    def test_planning_failure_changes_emergency_state(self, runner):
        """Planning failure → emergency state must not be NO_EMERGENCY."""
        spec = planning_fault_spec(FaultType.UNAVAILABLE, "em_02", cycles=4)
        result, _ = runner.run(spec)
        assert result.actual_emergency_state != EmergencyState.NO_EMERGENCY.value, (
            f"Planning failure should change emergency state from NO_EMERGENCY; "
            f"got {result.actual_emergency_state}"
        )

    def test_mpc_failure_changes_emergency_state(self, runner):
        """MPC failure → emergency state elevated from NO_EMERGENCY."""
        spec = mpc_fault_spec(FaultType.UNAVAILABLE, "em_03", cycles=4)
        result, _ = runner.run(spec)
        assert result.actual_emergency_state != EmergencyState.NO_EMERGENCY.value, (
            f"MPC failure should elevate emergency state; got {result.actual_emergency_state}"
        )

    def test_tracking_lost_changes_emergency_state(self, runner):
        """Tracking lost → emergency state elevated."""
        spec = ScenarioSpec(
            scenario_id="em_04",
            category=ScenarioCategory.CRITICAL_FAILURE.value,
            description="Tracking lost → emergency elevated",
            faults=(
                FaultSpec(FaultTarget.TRACKING, FaultType.UNAVAILABLE, activation_cycle=0),
            ),
            cycles=4,
            severity="CRITICAL",
        )
        result, _ = runner.run(spec)
        assert result.actual_emergency_state != EmergencyState.NO_EMERGENCY.value

    def test_emergency_state_deterministic(self, runner):
        """Same planning failure scenario → same emergency state (Invariant J)."""
        spec = planning_fault_spec(FaultType.UNAVAILABLE, "em_det_01", cycles=4)
        det = runner.run_determinism_check(spec, runs=5)
        assert det.passed, f"Emergency detection not deterministic: {det.mismatch}"

    def test_critical_emergency_triggers_inv_a_check(self, engine):
        """If emergency is CRITICAL_EMERGENCY + NORMAL_CONTROL, Invariant A violated."""
        result = engine.validate(
            scenario_id="em_inv_a_01",
            observed_emergency_state=EmergencyState.CRITICAL_EMERGENCY.value,
            observed_control_authority=ControlAuthority.NORMAL_CONTROL.value,
            invariants_to_check=(InvariantId.INVARIANT_A_NO_NORMAL_ON_CRITICAL_EMERGENCY.value,),
        )
        assert result.status == ValidationStatus.FAIL

    def test_emergency_cleared_after_fault_recovery(self, runner):
        """After fault clears, emergency should eventually clear too."""
        spec = ScenarioSpec(
            scenario_id="em_clear_01",
            category=ScenarioCategory.RECOVERY.value,
            description="Planning fails cycles 0-3, then clears",
            faults=(
                FaultSpec(FaultTarget.PLANNING, FaultType.UNAVAILABLE,
                          activation_cycle=0, duration_cycles=4),
            ),
            cycles=20,
            severity="HIGH",
        )
        result, traces = runner.run(spec)
        # After fault clears (cycle 4+), by cycle 15 emergency should be cleared
        late_traces = [t for t in traces if t.cycle >= 15]
        cleared = any(
            t.emergency_state == EmergencyState.NO_EMERGENCY.value
            for t in late_traces
        )
        assert cleared, (
            f"Emergency should clear after fault clears; "
            f"late traces: {[(t.cycle, t.emergency_state) for t in late_traces]}"
        )


# ===========================================================================
# Section 9 — Phase 11.3 Safety Supervisor Validation
# ===========================================================================

class TestSafetySupervisorValidation:
    """
    Validate Safety Supervisor authority decisions.
    «The Safety Supervisor never grants stronger control authority than
    the available safety evidence permits.»
    """

    def test_supervisor_normal_control_on_healthy(self, runner):
        """Healthy state → NORMAL_CONTROL from Safety Supervisor."""
        spec = normal_spec("sup_01", cycles=3)
        result, _ = runner.run(spec)
        assert result.actual_control_authority == ControlAuthority.NORMAL_CONTROL.value

    def test_supervisor_restricted_on_camera_failure(self, runner):
        spec = camera_fault_spec(FaultType.UNAVAILABLE, "sup_02", cycles=4)
        result, _ = runner.run(spec)
        assert_not_normal(result, "supervisor: camera failure")

    def test_supervisor_withheld_on_planning_failure(self, runner):
        """Planning failure → supervisor withholds or severely restricts control."""
        spec = planning_fault_spec(FaultType.UNAVAILABLE, "sup_03", cycles=4)
        result, _ = runner.run(spec)
        assert result.actual_control_authority in (
            ControlAuthority.CONTROL_WITHHELD.value,
            ControlAuthority.OVERRIDE_REQUIRED.value,
            ControlAuthority.SAFETY_CONTROL_REQUIRED.value,
            ControlAuthority.RESTRICTED_CONTROL.value,
        ), (f"Planning failure should severely restrict authority, "
            f"got {result.actual_control_authority}")

    def test_supervisor_withheld_on_mpc_failure(self, runner):
        """MPC failure → supervisor withholds or severely restricts."""
        spec = mpc_fault_spec(FaultType.UNAVAILABLE, "sup_04", cycles=4)
        result, _ = runner.run(spec)
        assert_not_normal(result, "supervisor: mpc failure")

    def test_supervisor_withheld_on_control_failure(self, runner):
        spec = control_fault_spec("sup_05", cycles=4)
        result, _ = runner.run(spec)
        assert_not_normal(result, "supervisor: control failure")

    def test_supervisor_never_grants_stronger_than_evidence(self, runner, engine):
        """
        Property: adding a critical failure never makes authority LESS restrictive.
        Run baseline, then add another failure, verify authority is not more permissive.
        """
        spec_base = normal_spec("sup_06a", cycles=3)
        result_base, _ = runner.run(spec_base)

        spec_fail = camera_fault_spec(FaultType.UNAVAILABLE, "sup_06b", cycles=3)
        result_fail, _ = runner.run(spec_fail)

        # The failed scenario must be at least as restrictive
        base_auth = result_base.actual_control_authority
        fail_auth = result_fail.actual_control_authority

        # NORMAL_CONTROL > all other authorities in terms of permissiveness
        # If baseline was NORMAL and failure is also NORMAL → violation
        if fail_auth == ControlAuthority.NORMAL_CONTROL.value:
            # Camera failure should never produce NORMAL_CONTROL
            pytest.fail(
                f"Camera failure produced same permissive authority as healthy baseline: "
                f"base={base_auth}, fail={fail_auth}"
            )

    def test_supervisor_deterministic(self, runner):
        """Supervisor decisions must be deterministic (Invariant J)."""
        spec = planning_fault_spec(FaultType.UNAVAILABLE, "sup_det_01", cycles=4)
        det = runner.run_determinism_check(spec, runs=5)
        assert det.passed, f"Supervisor not deterministic: {det.mismatch}"

    def test_supervisor_stale_emergency_state_restricts(self, runner):
        """Stale emergency state → supervisor must not grant NORMAL_CONTROL."""
        spec = ScenarioSpec(
            scenario_id="sup_07",
            category=ScenarioCategory.STALE_DATA.value,
            description="Stale MPC output → stale emergency/safety data",
            faults=(
                FaultSpec(FaultTarget.MPC, FaultType.STALE, activation_cycle=0),
            ),
            cycles=4,
            invariants_to_check=(InvariantId.INVARIANT_C_STALE_IS_NOT_FRESH.value,),
            severity="HIGH",
        )
        result, _ = runner.run(spec)
        assert_not_normal(result, "stale MPC (supervisor)")

    def test_supervisor_degraded_on_camera_degraded(self, runner):
        """Camera degraded → supervisor at most DEGRADED_CONTROL, not NORMAL."""
        spec = camera_fault_spec(FaultType.DEGRADED, "sup_08", cycles=4)
        result, _ = runner.run(spec)
        assert result.actual_control_authority != ControlAuthority.NORMAL_CONTROL.value


# ===========================================================================
# Section 10 — Phase 11.4 Fail-Safe Validation
# ===========================================================================

class TestFailSafeValidation:
    """
    Validate Fail-Safe Engine state transitions, dependency propagation,
    and capability preservation.
    """

    def test_normal_operation_failsafe_state_healthy(self, runner):
        spec = normal_spec("fs_01", cycles=3)
        result, _ = runner.run(spec)
        assert result.actual_fail_safe_state == FailSafeState.NORMAL_OPERATION.value

    def test_camera_failure_produces_sensor_degraded_state(self, runner):
        spec = camera_fault_spec(FaultType.UNAVAILABLE, "fs_02", cycles=4)
        result, _ = runner.run(spec)
        assert result.actual_fail_safe_state != FailSafeState.NORMAL_OPERATION.value

    def test_lidar_failure_produces_sensor_degraded_state(self, runner):
        spec = lidar_fault_spec(FaultType.UNAVAILABLE, "fs_03", cycles=4)
        result, _ = runner.run(spec)
        assert result.actual_fail_safe_state != FailSafeState.NORMAL_OPERATION.value

    def test_planning_failure_produces_subsystem_failure_state(self, runner):
        spec = planning_fault_spec(FaultType.UNAVAILABLE, "fs_04", cycles=4)
        result, _ = runner.run(spec)
        assert result.actual_fail_safe_state in (
            FailSafeState.SUBSYSTEM_FAILURE.value,
            FailSafeState.SUBSYSTEM_DEGRADED.value,
            FailSafeState.CONTROL_WITHHELD.value,
            FailSafeState.CONTROL_RESTRICTED.value,
            FailSafeState.FAIL_SAFE_ACTIVE.value,
            FailSafeState.DEGRADED_OPERATION.value,
        ), f"Planning failure produced {result.actual_fail_safe_state}"

    def test_mpc_failure_produces_subsystem_failure_state(self, runner):
        spec = mpc_fault_spec(FaultType.UNAVAILABLE, "fs_05", cycles=4)
        result, _ = runner.run(spec)
        assert result.actual_fail_safe_state not in (
            FailSafeState.NORMAL_OPERATION.value,
            FailSafeState.DEGRADED_OPERATION.value,
        )

    def test_multiple_sensor_failures_reflect_in_failsafe(self, runner):
        """Both camera + LiDAR failed → fail-safe state severe."""
        spec = multi_fault_spec(
            faults=(
                FaultSpec(FaultTarget.CAMERA, FaultType.UNAVAILABLE, activation_cycle=0),
                FaultSpec(FaultTarget.LIDAR, FaultType.UNAVAILABLE, activation_cycle=0),
            ),
            scenario_id="fs_06",
            cycles=4,
        )
        result, _ = runner.run(spec)
        assert result.actual_fail_safe_state not in (
            FailSafeState.NORMAL_OPERATION.value,
            FailSafeState.DEGRADED_OPERATION.value,
        )

    def test_failsafe_state_consistent_with_authority(self, engine):
        """Cross-field: CONTROL_WITHHELD fail-safe + NORMAL authority = inconsistent."""
        result = engine.validate(
            scenario_id="fs_cross_01",
            observed_fail_safe_state=FailSafeState.CONTROL_WITHHELD.value,
            observed_control_authority=ControlAuthority.NORMAL_CONTROL.value,
        )
        assert result.status == ValidationStatus.FAIL

    def test_failsafe_deterministic(self, runner):
        """Fail-safe decisions must be deterministic (Invariant J)."""
        spec = ScenarioSpec(
            scenario_id="fs_det_01",
            category=ScenarioCategory.DETERMINISM.value,
            description="Camera+LiDAR dual failure determinism",
            faults=(
                FaultSpec(FaultTarget.CAMERA, FaultType.UNAVAILABLE, activation_cycle=0),
                FaultSpec(FaultTarget.LIDAR, FaultType.UNAVAILABLE, activation_cycle=0),
            ),
            cycles=5,
            severity="CRITICAL",
        )
        det = runner.run_determinism_check(spec, runs=5)
        assert det.passed, f"Fail-safe not deterministic: {det.mismatch}"


# ===========================================================================
# Section 29 — Property-Style Tests
# ===========================================================================

class TestPropertyBased:
    """
    System-level properties that must hold across all inputs.
    """

    def test_property_a_critical_emergency_not_normal_authority(self, engine):
        """
        Property A: Critical emergency cannot result in unrestricted normal authority.
        """
        result = engine.validate(
            scenario_id="prop_a_01",
            observed_emergency_state=EmergencyState.CRITICAL_EMERGENCY.value,
            observed_control_authority=ControlAuthority.NORMAL_CONTROL.value,
            invariants_to_check=(InvariantId.INVARIANT_A_NO_NORMAL_ON_CRITICAL_EMERGENCY.value,),
        )
        assert result.status == ValidationStatus.FAIL, (
            "Property A: CRITICAL_EMERGENCY + NORMAL_CONTROL should fail"
        )

    def test_property_b_invalid_input_not_trusted_state(self, engine):
        """
        Property B: Invalid safety-critical input cannot result in trusted SAFE+NORMAL.
        """
        result = engine.validate(
            scenario_id="prop_b_01",
            observed_safety_state=SafetyState.SAFE.value,
            observed_control_authority=ControlAuthority.NORMAL_CONTROL.value,
            invariants_to_check=(InvariantId.INVARIANT_D_INVALID_IS_NOT_TRUSTED.value,),
        )
        assert result.status == ValidationStatus.FAIL, (
            "Property B: invalid input scenario + SAFE+NORMAL_CONTROL should fail Invariant D"
        )

    def test_property_c_failed_subsystem_not_healthy_in_failsafe(self, runner):
        """
        Property C: Critical failed subsystem cannot silently appear healthy.
        Planning failure must produce fail-safe state != NORMAL_OPERATION.
        """
        spec = planning_fault_spec(FaultType.UNAVAILABLE, "prop_c_01", cycles=4)
        result, _ = runner.run(spec)
        assert result.actual_fail_safe_state != FailSafeState.NORMAL_OPERATION.value, (
            "Property C: planning failure left fail-safe in NORMAL_OPERATION"
        )

    def test_property_d_recovery_requires_evidence(self, runner):
        """
        Property D: A subsystem that has failed must not produce NORMAL_CONTROL
        while the fault is still actively present.

        The architecture's recovery debounce speed is not prescribed here —
        we only validate the critical safety property: no NORMAL_CONTROL during
        the active failure window.
        """
        spec = ScenarioSpec(
            scenario_id="prop_d_01",
            category=ScenarioCategory.RECOVERY.value,
            description="Camera fails cycles 0-2 — NORMAL_CONTROL must not appear during failure",
            faults=(
                FaultSpec(FaultTarget.CAMERA, FaultType.UNAVAILABLE,
                          activation_cycle=0, duration_cycles=3),
            ),
            cycles=5,
            severity="HIGH",
        )
        result, traces = runner.run(spec)
        # While fault is active (cycles 0-2): must not be NORMAL_CONTROL
        for t in traces:
            if t.cycle < 3:
                assert t.control_authority != ControlAuthority.NORMAL_CONTROL.value, (
                    f"Property D: cycle {t.cycle} — camera UNAVAILABLE but "
                    f"authority={t.control_authority} (fault still active)"
                )

    def test_property_e_same_input_same_output(self, runner):
        """
        Property E: Same input sequence produces same output sequence.
        """
        spec = camera_fault_spec(FaultType.UNAVAILABLE, "prop_e_01", cycles=6)
        det = runner.run_determinism_check(spec, runs=5)
        assert det.passed, f"Property E violated: {det.mismatch}"

    def test_property_f_non_critical_sensor_failure_isolated(self, runner):
        """
        Property F: Non-critical sensor failure (e.g. camera degraded) does not
        automatically fail unrelated capability (radar tracking still works).
        """
        spec = ScenarioSpec(
            scenario_id="prop_f_01",
            category=ScenarioCategory.PROPERTY_BASED.value,
            description="Camera degraded only — unrelated radar tracking not affected",
            faults=(
                FaultSpec(FaultTarget.CAMERA, FaultType.DEGRADED, activation_cycle=0),
            ),
            cycles=4,
            severity="MEDIUM",
        )
        result, _ = runner.run(spec)
        # Camera degraded → fail-safe SENSOR_DEGRADED or similar, NOT CONTROL_WITHHELD
        assert result.actual_fail_safe_state != FailSafeState.CONTROL_WITHHELD.value, (
            f"Property F violated: camera-only degradation should not withhold control; "
            f"got fail_safe={result.actual_fail_safe_state}"
        )

    def test_property_g_adding_failure_never_less_restrictive_planning(self, runner):
        """
        Property G: Adding a critical safety failure cannot make the system less restrictive.
        Camera failed alone vs camera + planning failed.
        """
        spec1 = camera_fault_spec(FaultType.UNAVAILABLE, "prop_g_cam_01", cycles=4)
        result1, _ = runner.run(spec1)

        spec2 = multi_fault_spec(
            faults=(
                FaultSpec(FaultTarget.CAMERA, FaultType.UNAVAILABLE, activation_cycle=0),
                FaultSpec(FaultTarget.PLANNING, FaultType.UNAVAILABLE, activation_cycle=0),
            ),
            scenario_id="prop_g_cam_plan_01",
            cycles=4,
        )
        result2, _ = runner.run(spec2)

        # Both should be restricted; camera + planning failure should be
        # at least as restrictive as camera alone
        assert_not_normal(result1, "prop_g: camera alone")
        assert_not_normal(result2, "prop_g: camera + planning")

    def test_property_g_adding_mpc_failure_not_less_restrictive(self, runner):
        """Adding MPC failure on top of camera failure must not relax authority."""
        spec1 = camera_fault_spec(FaultType.UNAVAILABLE, "prop_g_cm_01", cycles=3)
        result1, _ = runner.run(spec1)

        spec2 = multi_fault_spec(
            faults=(
                FaultSpec(FaultTarget.CAMERA, FaultType.UNAVAILABLE, activation_cycle=0),
                FaultSpec(FaultTarget.MPC, FaultType.UNAVAILABLE, activation_cycle=0),
            ),
            scenario_id="prop_g_cm_02",
            cycles=3,
        )
        result2, _ = runner.run(spec2)

        assert_not_normal(result1, "prop_g: camera alone")
        assert_not_normal(result2, "prop_g: camera + MPC")


# ===========================================================================
# Section 32 — Performance Validation
# ===========================================================================

class TestPerformanceValidation:
    """
    Measure actual observed performance. Reports measured values only.
    Does NOT claim real-time or ISO certification.
    """

    def test_single_cycle_latency_measured(self, runner):
        """Measure and report single-cycle validation execution time."""
        spec = normal_spec("perf_01", cycles=1)
        start = time.monotonic()
        result, _ = runner.run(spec)
        elapsed_ms = (time.monotonic() - start) * 1000.0

        # Report measured value (no hard guarantee — just log and verify non-zero)
        assert result.execution_time_ms > 0, "Execution time not recorded"
        assert elapsed_ms > 0
        # Basic sanity: should complete within 5 seconds
        assert elapsed_ms < 5000, f"Single cycle took {elapsed_ms:.2f}ms — unexpectedly slow"

    def test_100_cycle_throughput(self, runner):
        """Measure 100-cycle scenario throughput."""
        spec = normal_spec("perf_02", cycles=100)
        start = time.monotonic()
        result, _ = runner.run(spec)
        elapsed_s = time.monotonic() - start

        throughput = 100 / elapsed_s if elapsed_s > 0 else 0
        # Sanity: at least 1 cycle per second; no formal bound claimed
        assert throughput >= 1.0, (
            f"Throughput {throughput:.1f} cycles/s seems too slow"
        )

    def test_500_cycle_no_memory_accumulation(self, runner):
        """
        500 healthy cycles — trace count must stay at exactly 500 (no accumulation).
        """
        spec = normal_spec("perf_03", cycles=500)
        _, traces = runner.run(spec)
        assert len(traces) == 500

    def test_execution_time_recorded_in_result(self, runner):
        """SafetyValidationResult.execution_time_ms is populated."""
        spec = normal_spec("perf_04", cycles=10)
        result, _ = runner.run(spec)
        assert result.execution_time_ms >= 0
        assert result.cycles_executed == 10

    def test_fault_scenario_not_significantly_slower(self, runner):
        """Fault scenarios should not be drastically slower than healthy scenarios."""
        spec_healthy = normal_spec("perf_05a", cycles=100)
        spec_fault   = camera_fault_spec(FaultType.UNAVAILABLE, "perf_05b", cycles=100)

        t0 = time.monotonic()
        runner.run(spec_healthy)
        t_healthy = time.monotonic() - t0

        t0 = time.monotonic()
        runner.run(spec_fault)
        t_fault = time.monotonic() - t0

        # Fault scenario should not be more than 5× slower than healthy
        if t_healthy > 0:
            ratio = t_fault / t_healthy
            assert ratio < 5.0, (
                f"Fault scenario {ratio:.1f}× slower than healthy — "
                f"unexpected performance cliff"
            )
