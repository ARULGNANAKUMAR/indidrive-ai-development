"""
Phase 11.5 — Test Helpers
==========================
Shared builders and utilities for Phase 11.5 safety validation tests.

Conventions:
  T = 1000.0 — reference timestamp throughout.
  All scenarios use deterministic, fixed timestamps (no wall clock).
  Builders return real project types — no mocks.
"""
from __future__ import annotations

from typing import List, Optional, Tuple

from core.safety_validation import (
    SafetyScenarioRunner,
    SafetyValidationEngine,
    FaultSpec,
    FaultTarget,
    FaultType,
    InvariantId,
    ScenarioCategory,
    ScenarioSpec,
    ValidationStatus,
)
from core.safety_validation.validation_types import AssertionResult

# Phase 11 engines
from core.safety import SafetyMonitor, SafetyMonitorConfig
from core.safety import EmergencyDetector, EmergencyDetectorConfig
from core.safety_supervisor import SafetySupervisor, SupervisorConfig
from core.failsafe import FailSafeEngine, FailSafeConfig

# Reference timestamp
T = 1000.0


# ---------------------------------------------------------------------------
# Engine factories
# ---------------------------------------------------------------------------

def make_runner(
    sm_config: Optional[SafetyMonitorConfig] = None,
    em_config: Optional[EmergencyDetectorConfig] = None,
    sup_config: Optional[SupervisorConfig] = None,
    fs_config: Optional[FailSafeConfig] = None,
) -> SafetyScenarioRunner:
    return SafetyScenarioRunner(
        safety_monitor_config=sm_config,
        emergency_detector_config=em_config,
        supervisor_config=sup_config,
        failsafe_config=fs_config,
    )


def make_engine() -> SafetyValidationEngine:
    return SafetyValidationEngine()


# ---------------------------------------------------------------------------
# Common scenario builders
# ---------------------------------------------------------------------------

def normal_spec(scenario_id: str = "normal", cycles: int = 3) -> ScenarioSpec:
    """Fully healthy, no-fault scenario."""
    return ScenarioSpec(
        scenario_id=scenario_id,
        category=ScenarioCategory.NORMAL_OPERATION.value,
        description="All subsystems healthy, no faults",
        cycles=cycles,
        expected_safety_state="SAFE",
        expected_emergency_state="NO_EMERGENCY",
        expected_fail_safe_state="NORMAL_OPERATION",
        expected_control_authority="NORMAL_CONTROL",
        invariants_to_check=(
            InvariantId.INVARIANT_A_NO_NORMAL_ON_CRITICAL_EMERGENCY.value,
            InvariantId.INVARIANT_B_NO_NORMAL_FROM_CRITICAL_SAFETY.value,
        ),
        severity="LOW",
    )


def camera_fault_spec(
    fault_type: FaultType = FaultType.UNAVAILABLE,
    scenario_id: str = "camera_fault",
    cycles: int = 4,
) -> ScenarioSpec:
    return ScenarioSpec(
        scenario_id=scenario_id,
        category=ScenarioCategory.DEGRADED_OPERATION.value,
        description=f"Camera fault: {fault_type.value}",
        faults=(
            FaultSpec(
                target=FaultTarget.CAMERA,
                fault_type=fault_type,
                activation_cycle=0,
                duration_cycles=0,
            ),
        ),
        cycles=cycles,
        severity="HIGH",
    )


def lidar_fault_spec(
    fault_type: FaultType = FaultType.UNAVAILABLE,
    scenario_id: str = "lidar_fault",
    cycles: int = 4,
) -> ScenarioSpec:
    return ScenarioSpec(
        scenario_id=scenario_id,
        category=ScenarioCategory.DEGRADED_OPERATION.value,
        description=f"LiDAR fault: {fault_type.value}",
        faults=(
            FaultSpec(
                target=FaultTarget.LIDAR,
                fault_type=fault_type,
                activation_cycle=0,
                duration_cycles=0,
            ),
        ),
        cycles=cycles,
        severity="HIGH",
    )


def planning_fault_spec(
    fault_type: FaultType = FaultType.UNAVAILABLE,
    scenario_id: str = "planning_fault",
    cycles: int = 4,
) -> ScenarioSpec:
    return ScenarioSpec(
        scenario_id=scenario_id,
        category=ScenarioCategory.CRITICAL_FAILURE.value,
        description=f"Planning fault: {fault_type.value}",
        faults=(
            FaultSpec(
                target=FaultTarget.PLANNING,
                fault_type=fault_type,
                activation_cycle=0,
                duration_cycles=0,
            ),
        ),
        cycles=cycles,
        invariants_to_check=(
            InvariantId.INVARIANT_G_CONTROL_FAILURE_IS_RESTRICTED.value,
        ),
        severity="CRITICAL",
    )


def mpc_fault_spec(
    fault_type: FaultType = FaultType.UNAVAILABLE,
    scenario_id: str = "mpc_fault",
    cycles: int = 4,
) -> ScenarioSpec:
    return ScenarioSpec(
        scenario_id=scenario_id,
        category=ScenarioCategory.CRITICAL_FAILURE.value,
        description=f"MPC fault: {fault_type.value}",
        faults=(
            FaultSpec(
                target=FaultTarget.MPC,
                fault_type=fault_type,
                activation_cycle=0,
                duration_cycles=0,
            ),
        ),
        cycles=cycles,
        invariants_to_check=(
            InvariantId.INVARIANT_G_CONTROL_FAILURE_IS_RESTRICTED.value,
        ),
        severity="CRITICAL",
    )


def control_fault_spec(
    scenario_id: str = "control_fault",
    cycles: int = 4,
) -> ScenarioSpec:
    return ScenarioSpec(
        scenario_id=scenario_id,
        category=ScenarioCategory.CRITICAL_FAILURE.value,
        description="Control command invalid",
        faults=(
            FaultSpec(
                target=FaultTarget.CONTROL,
                fault_type=FaultType.UNAVAILABLE,
                activation_cycle=0,
                duration_cycles=0,
            ),
        ),
        cycles=cycles,
        invariants_to_check=(
            InvariantId.INVARIANT_G_CONTROL_FAILURE_IS_RESTRICTED.value,
        ),
        severity="CRITICAL",
    )


def stale_world_model_spec(
    scenario_id: str = "stale_wm",
    cycles: int = 4,
) -> ScenarioSpec:
    return ScenarioSpec(
        scenario_id=scenario_id,
        category=ScenarioCategory.STALE_DATA.value,
        description="World model data goes stale",
        faults=(
            FaultSpec(
                target=FaultTarget.WORLD_MODEL,
                fault_type=FaultType.STALE,
                activation_cycle=0,
                duration_cycles=0,
            ),
        ),
        cycles=cycles,
        invariants_to_check=(
            InvariantId.INVARIANT_C_STALE_IS_NOT_FRESH.value,
        ),
        severity="HIGH",
    )


def multi_fault_spec(
    faults: Tuple[FaultSpec, ...],
    scenario_id: str = "multi_fault",
    cycles: int = 5,
    category: str = ScenarioCategory.MULTIPLE_FAILURE.value,
) -> ScenarioSpec:
    return ScenarioSpec(
        scenario_id=scenario_id,
        category=category,
        description=f"Multi-fault: {len(faults)} simultaneous faults",
        faults=faults,
        cycles=cycles,
        invariants_to_check=(
            InvariantId.INVARIANT_A_NO_NORMAL_ON_CRITICAL_EMERGENCY.value,
            InvariantId.INVARIANT_B_NO_NORMAL_FROM_CRITICAL_SAFETY.value,
            InvariantId.INVARIANT_G_CONTROL_FAILURE_IS_RESTRICTED.value,
            InvariantId.INVARIANT_I_MULTIPLE_FAILURES_PRESERVED.value,
        ),
        severity="CRITICAL",
    )


# ---------------------------------------------------------------------------
# Result assertion helpers
# ---------------------------------------------------------------------------

def assert_pass(result, msg: str = "") -> None:
    assert result.status == ValidationStatus.PASS, (
        f"{msg}: Expected PASS but got {result.status.value}. "
        f"Mismatches: {result.mismatch_codes}. Diag: {result.diagnostics}"
    )


def assert_not_normal(result, msg: str = "") -> None:
    """
    Assert that control authority is NOT NORMAL_CONTROL.

    LIMITED_CONTROL is the architecture's response to degraded (not failed) sensors —
    it IS a restriction (not unrestricted normal operation). Tests that want to verify
    a failure produces ANY restriction should only exclude NORMAL_CONTROL.
    """
    assert result.actual_control_authority != "NORMAL_CONTROL", (
        f"{msg}: Expected restricted authority but got "
        f"{result.actual_control_authority!r}. "
        f"Safety: {result.actual_safety_state}, FS: {result.actual_fail_safe_state}"
    )


def assert_invariant_a_not_violated(result, msg: str = "") -> None:
    """Assert Invariant A was not violated: no NORMAL_CONTROL on CRITICAL_EMERGENCY."""
    if result.actual_emergency_state == "CRITICAL_EMERGENCY":
        normal = {"NORMAL_CONTROL", "LIMITED_CONTROL"}
        assert result.actual_control_authority not in normal, (
            f"Invariant A violated {msg}: CRITICAL_EMERGENCY but authority="
            f"{result.actual_control_authority!r}"
        )


def assert_invariant_b_not_violated(result, msg: str = "") -> None:
    """Assert Invariant B: no NORMAL_CONTROL on CRITICAL safety state."""
    if result.actual_safety_state == "CRITICAL":
        normal = {"NORMAL_CONTROL", "LIMITED_CONTROL"}
        assert result.actual_control_authority not in normal, (
            f"Invariant B violated {msg}: CRITICAL safety but authority="
            f"{result.actual_control_authority!r}"
        )
