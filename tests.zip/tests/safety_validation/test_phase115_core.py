"""
Phase 11.5 — Core Safety Validation Tests
==========================================
Validates Invariants A–J and key scenario classes:
  - Normal operation (healthy baseline)
  - Degraded operation (sensor/subsystem degradation)
  - Critical failure (control failure, planning failure, MPC failure)
  - Snapshot cross-consistency
  - State transition validation
  - Boundary value testing

Conventions:
  T = 1000.0 — reference timestamp throughout.
  All inputs are deterministic — no wall clock, no random values.
  Tests exercise the EXISTING Phase 11.1–11.4 engines; no new safety logic.
"""
from __future__ import annotations

try:
    import pytest
except ImportError:
    # Project-standard shim when pytest is not installed.
    class _RaisesCtx:
        def __init__(self, exc_types):
            self._exc = exc_types if isinstance(exc_types, tuple) else (exc_types,)
        def __enter__(self): return self
        def __exit__(self, exc_type, exc_val, tb):
            if exc_type is None:
                raise AssertionError(f"Expected {self._exc} but no exception was raised")
            return issubclass(exc_type, self._exc)
    class _Pytest:
        @staticmethod
        def raises(exc): return _RaisesCtx(exc)
        @staticmethod
        def fail(msg): raise AssertionError(msg)
    pytest = _Pytest()

    def fixture(fn=None, **kw):
        if fn is not None: return fn
        def decorator(f): return f
        return decorator
    pytest.fixture = fixture

from core.safety_validation import (
    SafetyScenarioRunner,
    SafetyValidationEngine,
    FaultSpec,
    FaultTarget,
    FaultType,
    InvariantId,
    ScenarioCategory,
    ScenarioSpec,
    ValidationStatus,
)
from core.safety_validation.validation_types import AssertionResult
from core.safety.safety_types import SafetyState
from core.safety.emergency_types import EmergencyState
from core.safety_supervisor.supervisor_types import ControlAuthority
from core.failsafe.failsafe_types import FailSafeState

from .helpers_115 import (
    T, make_runner, make_engine,
    normal_spec, camera_fault_spec, lidar_fault_spec,
    planning_fault_spec, mpc_fault_spec, control_fault_spec,
    stale_world_model_spec, multi_fault_spec,
    assert_pass, assert_not_normal,
    assert_invariant_a_not_violated, assert_invariant_b_not_violated,
)

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def runner():
    return make_runner()


@pytest.fixture
def engine():
    return make_engine()


# ===========================================================================
# 1. Normal Operation Baseline
# ===========================================================================

class TestNormalOperation:
    """
    Section 11 of spec: verify healthy baseline produces no false emergencies,
    no false fail-safe, no unexpected restrictions.
    """

    def test_healthy_produces_safe_state(self, runner):
        spec = normal_spec("normal_01")
        result, traces = runner.run(spec)
        assert result.actual_safety_state == SafetyState.SAFE.value, (
            f"Expected SAFE but got {result.actual_safety_state}"
        )

    def test_healthy_produces_no_emergency(self, runner):
        spec = normal_spec("normal_02")
        result, _ = runner.run(spec)
        assert result.actual_emergency_state == EmergencyState.NO_EMERGENCY.value

    def test_healthy_produces_normal_control(self, runner):
        spec = normal_spec("normal_03")
        result, _ = runner.run(spec)
        assert result.actual_control_authority == ControlAuthority.NORMAL_CONTROL.value

    def test_healthy_produces_normal_fail_safe(self, runner):
        spec = normal_spec("normal_04")
        result, _ = runner.run(spec)
        assert result.actual_fail_safe_state == FailSafeState.NORMAL_OPERATION.value

    def test_healthy_full_scenario_passes(self, runner):
        spec = normal_spec("normal_05")
        result, _ = runner.run(spec)
        assert_pass(result, "Healthy baseline scenario must PASS")

    def test_healthy_no_false_active_failures(self, runner):
        spec = normal_spec("normal_06", cycles=5)
        _, traces = runner.run(spec)
        for t in traces:
            assert len(t.active_failures) == 0, (
                f"Cycle {t.cycle}: unexpected failures {t.active_failures}"
            )

    def test_healthy_stable_across_cycles(self, runner):
        """Safety state must be stable for all cycles in a healthy run."""
        spec = normal_spec("normal_07", cycles=10)
        _, traces = runner.run(spec)
        for t in traces:
            assert t.safety_state == SafetyState.SAFE.value, (
                f"Cycle {t.cycle}: expected SAFE, got {t.safety_state}"
            )
            assert t.control_authority == ControlAuthority.NORMAL_CONTROL.value, (
                f"Cycle {t.cycle}: expected NORMAL_CONTROL, got {t.control_authority}"
            )

    def test_invariant_a_not_violated_in_normal_op(self, runner):
        """Invariant A: no CRITICAL_EMERGENCY + NORMAL_CONTROL in healthy scenario."""
        spec = normal_spec("normal_08")
        result, _ = runner.run(spec)
        assert_invariant_a_not_violated(result, "normal_op")

    def test_invariant_b_not_violated_in_normal_op(self, runner):
        """Invariant B: no CRITICAL safety + NORMAL_CONTROL in healthy scenario."""
        spec = normal_spec("normal_09")
        result, _ = runner.run(spec)
        assert_invariant_b_not_violated(result, "normal_op")


# ===========================================================================
# 2. Degraded Operation
# ===========================================================================

class TestDegradedOperation:
    """
    Section 12 of spec: camera degraded, LiDAR degraded, sensor sync degraded,
    planner degraded, tracking degraded.
    """

    def test_camera_degraded_does_not_produce_critical_emergency(self, runner):
        spec = camera_fault_spec(FaultType.DEGRADED, "cam_degrad_01")
        result, _ = runner.run(spec)
        assert result.actual_emergency_state != EmergencyState.CRITICAL_EMERGENCY.value, (
            "Camera degradation alone must not produce CRITICAL_EMERGENCY"
        )

    def test_camera_unavailable_authority_not_normal(self, runner):
        """Camera unavailable should restrict control (not allow normal)."""
        spec = camera_fault_spec(FaultType.UNAVAILABLE, "cam_unavail_01")
        result, _ = runner.run(spec)
        # Camera unavailable → failsafe active → authority restricted/withheld
        assert_not_normal(result, "camera unavailable")

    def test_lidar_degraded_does_not_kill_unrelated_caps(self, runner):
        """Invariant F: LiDAR degraded must not fail unrelated capabilities."""
        spec = lidar_fault_spec(FaultType.DEGRADED, "lidar_degrad_01")
        result, traces = runner.run(spec)
        # The system should still be operating (not FAIL_SAFE_ACTIVE for unrelated caps)
        for t in traces:
            # No emergency from pure lidar degradation alone
            assert t.emergency_state != EmergencyState.CRITICAL_EMERGENCY.value, (
                f"Cycle {t.cycle}: LiDAR degradation alone caused CRITICAL_EMERGENCY"
            )

    def test_lidar_unavailable_restricts_control(self, runner):
        spec = lidar_fault_spec(FaultType.UNAVAILABLE, "lidar_unavail_01")
        result, _ = runner.run(spec)
        assert_not_normal(result, "lidar unavailable")

    def test_planning_degraded_restricts_control(self, runner):
        spec = planning_fault_spec(FaultType.DEGRADED, "plan_degrad_01")
        result, _ = runner.run(spec)
        assert_not_normal(result, "planning degraded")

    def test_mpc_degraded_restricts_control(self, runner):
        spec = mpc_fault_spec(FaultType.DEGRADED, "mpc_degrad_01")
        result, _ = runner.run(spec)
        assert_not_normal(result, "mpc degraded")

    def test_tracking_degraded_restricts_control(self, runner):
        spec = ScenarioSpec(
            scenario_id="track_degrad_01",
            category=ScenarioCategory.DEGRADED_OPERATION.value,
            description="Tracking degraded",
            faults=(
                FaultSpec(
                    target=FaultTarget.TRACKING,
                    fault_type=FaultType.DEGRADED,
                    activation_cycle=0,
                ),
            ),
            cycles=4,
            severity="MEDIUM",
        )
        result, _ = runner.run(spec)
        # Tracking degraded should cause some restriction
        assert result.actual_control_authority != ControlAuthority.NORMAL_CONTROL.value, (
            "Tracking degradation should restrict authority"
        )

    def test_perception_degraded_restricts_control(self, runner):
        spec = ScenarioSpec(
            scenario_id="perc_degrad_01",
            category=ScenarioCategory.DEGRADED_OPERATION.value,
            description="Perception degraded",
            faults=(
                FaultSpec(
                    target=FaultTarget.PERCEPTION,
                    fault_type=FaultType.DEGRADED,
                    activation_cycle=0,
                ),
            ),
            cycles=4,
            severity="MEDIUM",
        )
        result, _ = runner.run(spec)
        assert_not_normal(result, "perception degraded")

    def test_fusion_degraded_restricts_control(self, runner):
        spec = ScenarioSpec(
            scenario_id="fusion_degrad_01",
            category=ScenarioCategory.DEGRADED_OPERATION.value,
            description="Fusion degraded",
            faults=(
                FaultSpec(
                    target=FaultTarget.FUSION,
                    fault_type=FaultType.DEGRADED,
                    activation_cycle=0,
                ),
            ),
            cycles=4,
            severity="MEDIUM",
        )
        result, _ = runner.run(spec)
        assert_not_normal(result, "fusion degraded")


# ===========================================================================
# 3. Critical Failure Scenarios
# ===========================================================================

class TestCriticalFailure:
    """
    Section 13 of spec: critical sensor/subsystem failure never silently
    produces unrestricted normal control.
    """

    def test_planning_failure_does_not_allow_normal_control(self, runner):
        """Invariant G: planning failure must not allow normal control."""
        spec = planning_fault_spec(FaultType.UNAVAILABLE, "plan_fail_01")
        result, _ = runner.run(spec)
        assert_not_normal(result, "planning failure")

    def test_mpc_failure_does_not_allow_normal_control(self, runner):
        spec = mpc_fault_spec(FaultType.UNAVAILABLE, "mpc_fail_01")
        result, _ = runner.run(spec)
        assert_not_normal(result, "mpc failure")

    def test_control_failure_does_not_allow_normal_control(self, runner):
        spec = control_fault_spec("ctrl_fail_01")
        result, _ = runner.run(spec)
        assert_not_normal(result, "control failure")

    def test_camera_failure_does_not_allow_normal_control(self, runner):
        spec = camera_fault_spec(FaultType.UNAVAILABLE, "cam_fail_01")
        result, _ = runner.run(spec)
        assert_not_normal(result, "camera failure")

    def test_lidar_failure_does_not_allow_normal_control(self, runner):
        spec = lidar_fault_spec(FaultType.UNAVAILABLE, "lidar_fail_01")
        result, _ = runner.run(spec)
        assert_not_normal(result, "lidar failure")

    def test_tracking_failure_does_not_allow_normal_control(self, runner):
        spec = ScenarioSpec(
            scenario_id="track_fail_01",
            category=ScenarioCategory.CRITICAL_FAILURE.value,
            description="Tracking lost",
            faults=(
                FaultSpec(
                    target=FaultTarget.TRACKING,
                    fault_type=FaultType.UNAVAILABLE,
                    activation_cycle=0,
                ),
            ),
            cycles=4,
            severity="CRITICAL",
        )
        result, _ = runner.run(spec)
        assert_not_normal(result, "tracking failure")

    def test_perception_failure_restricts_control(self, runner):
        spec = ScenarioSpec(
            scenario_id="perc_fail_01",
            category=ScenarioCategory.CRITICAL_FAILURE.value,
            description="Perception failure",
            faults=(
                FaultSpec(
                    target=FaultTarget.PERCEPTION,
                    fault_type=FaultType.UNAVAILABLE,
                    activation_cycle=0,
                ),
            ),
            cycles=4,
            severity="CRITICAL",
        )
        result, _ = runner.run(spec)
        assert_not_normal(result, "perception failure")

    def test_world_model_failure_restricts_control(self, runner):
        spec = ScenarioSpec(
            scenario_id="wm_fail_01",
            category=ScenarioCategory.CRITICAL_FAILURE.value,
            description="World model failure",
            faults=(
                FaultSpec(
                    target=FaultTarget.WORLD_MODEL,
                    fault_type=FaultType.UNAVAILABLE,
                    activation_cycle=0,
                ),
            ),
            cycles=4,
            severity="CRITICAL",
        )
        result, _ = runner.run(spec)
        assert_not_normal(result, "world model failure")

    def test_camera_failure_fail_safe_state_not_normal(self, runner):
        """When camera fails, FailSafeState must not be NORMAL_OPERATION."""
        spec = camera_fault_spec(FaultType.UNAVAILABLE, "cam_fs_01")
        result, _ = runner.run(spec)
        assert result.actual_fail_safe_state != FailSafeState.NORMAL_OPERATION.value, (
            f"Camera failure should not leave fail-safe in NORMAL_OPERATION, "
            f"got {result.actual_fail_safe_state}"
        )

    def test_lidar_failure_fail_safe_state_not_normal(self, runner):
        spec = lidar_fault_spec(FaultType.UNAVAILABLE, "lidar_fs_01")
        result, _ = runner.run(spec)
        assert result.actual_fail_safe_state != FailSafeState.NORMAL_OPERATION.value


# ===========================================================================
# 4. Safety Invariant A — Critical Emergency ≠ Normal Control
# ===========================================================================

class TestInvariantA:
    """
    Invariant A: A critical emergency cannot result in unrestricted normal control.
    """

    def test_engine_inv_a_no_violation_with_safe_state(self, engine):
        """Invariant A not triggered when emergency is NO_EMERGENCY."""
        result = engine.validate(
            scenario_id="inv_a_01",
            observed_safety_state="SAFE",
            observed_emergency_state="NO_EMERGENCY",
            observed_fail_safe_state="NORMAL_OPERATION",
            observed_control_authority="NORMAL_CONTROL",
            expected_safety_state="SAFE",
            expected_control_authority="NORMAL_CONTROL",
            invariants_to_check=(InvariantId.INVARIANT_A_NO_NORMAL_ON_CRITICAL_EMERGENCY.value,),
        )
        assert_pass(result)

    def test_engine_inv_a_violation_detected(self, engine):
        """
        Engine must detect Invariant A violation:
        CRITICAL_EMERGENCY + NORMAL_CONTROL.
        """
        result = engine.validate(
            scenario_id="inv_a_02",
            observed_safety_state="CRITICAL",
            observed_emergency_state="CRITICAL_EMERGENCY",
            observed_fail_safe_state="CONTROL_WITHHELD",
            observed_control_authority="NORMAL_CONTROL",  # ← violation
            invariants_to_check=(InvariantId.INVARIANT_A_NO_NORMAL_ON_CRITICAL_EMERGENCY.value,),
        )
        assert result.status == ValidationStatus.FAIL
        assert any("inv_a" in a.assertion_id for a in result.assertion_results if not a.passed)

    def test_engine_inv_a_critical_plus_limited_control_not_normal(self, engine):
        """
        LIMITED_CONTROL is a restriction in this architecture (not unrestricted normal).
        CRITICAL_EMERGENCY + LIMITED_CONTROL does not violate Invariant A because
        the authority IS restricted (not NORMAL_CONTROL).
        The snapshot consistency check flags CRITICAL_EMERGENCY + SAFE safety state —
        which is a separate concern.
        """
        result = engine.validate(
            scenario_id="inv_a_03",
            observed_safety_state="CRITICAL",
            observed_emergency_state="CRITICAL_EMERGENCY",
            observed_control_authority="LIMITED_CONTROL",
            invariants_to_check=(InvariantId.INVARIANT_A_NO_NORMAL_ON_CRITICAL_EMERGENCY.value,),
        )
        # Invariant A: LIMITED_CONTROL is NOT NORMAL_CONTROL → invariant satisfied
        inv_a_assertions = [
            a for a in result.assertion_results
            if "inv_a" in a.assertion_id
        ]
        assert all(a.passed for a in inv_a_assertions), (
            f"Invariant A should be satisfied: CRITICAL_EMERGENCY + LIMITED_CONTROL "
            f"(LIMITED is a restriction, not unrestricted normal)"
        )

    def test_engine_inv_a_critical_plus_withheld_ok(self, engine):
        """CRITICAL_EMERGENCY + CONTROL_WITHHELD = invariant A satisfied."""
        result = engine.validate(
            scenario_id="inv_a_04",
            observed_emergency_state="CRITICAL_EMERGENCY",
            observed_control_authority="CONTROL_WITHHELD",
            invariants_to_check=(InvariantId.INVARIANT_A_NO_NORMAL_ON_CRITICAL_EMERGENCY.value,),
        )
        # Invariant A itself passes (authority is not normal)
        inv_a_assertions = [
            a for a in result.assertion_results
            if a.invariant_id == InvariantId.INVARIANT_A_NO_NORMAL_ON_CRITICAL_EMERGENCY.value
            and "inv_a" in a.assertion_id
        ]
        assert all(a.passed for a in inv_a_assertions), (
            f"Invariant A should pass for CONTROL_WITHHELD, got {inv_a_assertions}"
        )

    def test_engine_inv_a_emergency_detected_not_critical(self, engine):
        """EMERGENCY_DETECTED (not CRITICAL) does not trigger Invariant A."""
        result = engine.validate(
            scenario_id="inv_a_05",
            observed_emergency_state="EMERGENCY_DETECTED",
            observed_control_authority="NORMAL_CONTROL",
            invariants_to_check=(InvariantId.INVARIANT_A_NO_NORMAL_ON_CRITICAL_EMERGENCY.value,),
        )
        # Invariant A only triggers on CRITICAL_EMERGENCY
        inv_a_assertions = [
            a for a in result.assertion_results
            if "inv_a" in a.assertion_id
        ]
        assert all(a.passed for a in inv_a_assertions)


# ===========================================================================
# 5. Safety Invariant B — Critical Safety State ≠ Normal Control
# ===========================================================================

class TestInvariantB:

    def test_engine_inv_b_violation_detected(self, engine):
        """CRITICAL safety state + NORMAL_CONTROL = Invariant B violation."""
        result = engine.validate(
            scenario_id="inv_b_01",
            observed_safety_state="CRITICAL",
            observed_emergency_state="NO_EMERGENCY",
            observed_fail_safe_state="NORMAL_OPERATION",
            observed_control_authority="NORMAL_CONTROL",  # ← violation
            invariants_to_check=(InvariantId.INVARIANT_B_NO_NORMAL_FROM_CRITICAL_SAFETY.value,),
        )
        assert result.status == ValidationStatus.FAIL

    def test_engine_inv_b_satisfied_with_withheld(self, engine):
        """CRITICAL safety state + CONTROL_WITHHELD = Invariant B satisfied."""
        result = engine.validate(
            scenario_id="inv_b_02",
            observed_safety_state="CRITICAL",
            observed_control_authority="CONTROL_WITHHELD",
            invariants_to_check=(InvariantId.INVARIANT_B_NO_NORMAL_FROM_CRITICAL_SAFETY.value,),
        )
        inv_b = [a for a in result.assertion_results if "inv_b" in a.assertion_id]
        assert all(a.passed for a in inv_b)

    def test_engine_inv_b_safe_state_no_trigger(self, engine):
        """SAFE state does not trigger Invariant B."""
        result = engine.validate(
            scenario_id="inv_b_03",
            observed_safety_state="SAFE",
            observed_control_authority="NORMAL_CONTROL",
            invariants_to_check=(InvariantId.INVARIANT_B_NO_NORMAL_FROM_CRITICAL_SAFETY.value,),
        )
        inv_b = [a for a in result.assertion_results if "inv_b" in a.assertion_id]
        assert all(a.passed for a in inv_b)


# ===========================================================================
# 6. Safety Invariant C — Stale Data
# ===========================================================================

class TestInvariantC:

    def test_stale_wm_not_treated_as_fresh(self, runner):
        """Invariant C: stale world model must not produce SAFE+NORMAL_CONTROL."""
        spec = stale_world_model_spec("stale_01")
        result, _ = runner.run(spec)
        # Stale WM → safety monitor should report UNKNOWN/DEGRADED/CRITICAL
        # → not SAFE + NORMAL_CONTROL
        if result.actual_fail_safe_state not in (
            FailSafeState.NORMAL_OPERATION.value,
        ):
            # Good: stale data caused a restriction
            pass
        else:
            # If fail-safe is NORMAL_OPERATION, verify safety state is not SAFE
            # (stale detection may be at safety monitor layer)
            assert result.actual_safety_state != SafetyState.SAFE.value or \
                   result.actual_control_authority != ControlAuthority.NORMAL_CONTROL.value, (
                "Stale WM produced SAFE+NORMAL_CONTROL — Invariant C violated"
            )

    def test_stale_planning_restricts_control(self, runner):
        spec = ScenarioSpec(
            scenario_id="stale_plan_01",
            category=ScenarioCategory.STALE_DATA.value,
            description="Planning output goes stale",
            faults=(
                FaultSpec(
                    target=FaultTarget.PLANNING,
                    fault_type=FaultType.STALE,
                    activation_cycle=0,
                ),
            ),
            cycles=4,
            invariants_to_check=(InvariantId.INVARIANT_C_STALE_IS_NOT_FRESH.value,),
            severity="HIGH",
        )
        result, _ = runner.run(spec)
        assert_not_normal(result, "stale planning")

    def test_stale_mpc_restricts_control(self, runner):
        spec = ScenarioSpec(
            scenario_id="stale_mpc_01",
            category=ScenarioCategory.STALE_DATA.value,
            description="MPC output goes stale",
            faults=(
                FaultSpec(
                    target=FaultTarget.MPC,
                    fault_type=FaultType.STALE,
                    activation_cycle=0,
                ),
            ),
            cycles=4,
            invariants_to_check=(InvariantId.INVARIANT_C_STALE_IS_NOT_FRESH.value,),
            severity="HIGH",
        )
        result, _ = runner.run(spec)
        assert_not_normal(result, "stale MPC")

    def test_stale_tracking_restricts_control(self, runner):
        spec = ScenarioSpec(
            scenario_id="stale_track_01",
            category=ScenarioCategory.STALE_DATA.value,
            description="Tracking output goes stale",
            faults=(
                FaultSpec(
                    target=FaultTarget.TRACKING,
                    fault_type=FaultType.STALE,
                    activation_cycle=0,
                ),
            ),
            cycles=4,
            severity="HIGH",
        )
        result, _ = runner.run(spec)
        assert_not_normal(result, "stale tracking")

    def test_engine_stale_flag_prevents_safe_normal(self, engine):
        """Engine Invariant C: stale=True + SAFE + NORMAL_CONTROL = FAIL."""
        result = engine.validate(
            scenario_id="inv_c_01",
            observed_safety_state="SAFE",
            observed_control_authority="NORMAL_CONTROL",
            invariants_to_check=(InvariantId.INVARIANT_C_STALE_IS_NOT_FRESH.value,),
            stale=True,
        )
        assert result.status == ValidationStatus.FAIL

    def test_engine_stale_flag_with_restricted_authority_ok(self, engine):
        """stale=True + CONTROL_WITHHELD = Invariant C satisfied."""
        result = engine.validate(
            scenario_id="inv_c_02",
            observed_safety_state="UNKNOWN",
            observed_control_authority="CONTROL_WITHHELD",
            invariants_to_check=(InvariantId.INVARIANT_C_STALE_IS_NOT_FRESH.value,),
            stale=True,
        )
        inv_c = [a for a in result.assertion_results
                 if InvariantId.INVARIANT_C_STALE_IS_NOT_FRESH.value == a.invariant_id
                 and "inv_c" in a.assertion_id]
        assert all(a.passed for a in inv_c)


# ===========================================================================
# 7. Safety Invariant G — Control Failure ≠ Normal Authority
# ===========================================================================

class TestInvariantG:

    def test_control_withheld_fs_state_fails_inv_g(self, engine):
        """CONTROL_WITHHELD fail-safe + NORMAL_CONTROL authority = Invariant G violation."""
        result = engine.validate(
            scenario_id="inv_g_01",
            observed_fail_safe_state="CONTROL_WITHHELD",
            observed_control_authority="NORMAL_CONTROL",
            invariants_to_check=(InvariantId.INVARIANT_G_CONTROL_FAILURE_IS_RESTRICTED.value,),
        )
        assert result.status == ValidationStatus.FAIL

    def test_fail_safe_active_fs_state_fails_inv_g(self, engine):
        result = engine.validate(
            scenario_id="inv_g_02",
            observed_fail_safe_state="FAIL_SAFE_ACTIVE",
            observed_control_authority="NORMAL_CONTROL",
            invariants_to_check=(InvariantId.INVARIANT_G_CONTROL_FAILURE_IS_RESTRICTED.value,),
        )
        assert result.status == ValidationStatus.FAIL

    def test_control_withheld_plus_withheld_authority_ok(self, engine):
        result = engine.validate(
            scenario_id="inv_g_03",
            observed_fail_safe_state="CONTROL_WITHHELD",
            observed_control_authority="CONTROL_WITHHELD",
            invariants_to_check=(InvariantId.INVARIANT_G_CONTROL_FAILURE_IS_RESTRICTED.value,),
        )
        inv_g = [a for a in result.assertion_results if "inv_g" in a.assertion_id]
        assert all(a.passed for a in inv_g)

    def test_normal_fs_state_does_not_trigger_inv_g(self, engine):
        """NORMAL_OPERATION fail-safe state doesn't trigger Invariant G."""
        result = engine.validate(
            scenario_id="inv_g_04",
            observed_fail_safe_state="NORMAL_OPERATION",
            observed_control_authority="NORMAL_CONTROL",
            invariants_to_check=(InvariantId.INVARIANT_G_CONTROL_FAILURE_IS_RESTRICTED.value,),
        )
        inv_g = [a for a in result.assertion_results if "inv_g" in a.assertion_id]
        assert all(a.passed for a in inv_g)


# ===========================================================================
# 8. Snapshot Cross-Consistency
# ===========================================================================

class TestSnapshotConsistency:
    """
    Section 30 of spec: cross-field consistency validation.
    """

    def test_control_withheld_fs_plus_normal_auth_inconsistent(self, engine):
        """CONTROL_WITHHELD fail-safe state inconsistent with NORMAL_CONTROL."""
        result = engine.validate(
            scenario_id="snap_01",
            observed_fail_safe_state="CONTROL_WITHHELD",
            observed_control_authority="NORMAL_CONTROL",
        )
        assert result.status == ValidationStatus.FAIL

    def test_critical_emergency_vs_safe_state_inconsistent(self, engine):
        """CRITICAL_EMERGENCY should not coexist with SAFE safety state."""
        result = engine.validate(
            scenario_id="snap_02",
            observed_safety_state="SAFE",
            observed_emergency_state="CRITICAL_EMERGENCY",
            observed_control_authority="OVERRIDE_REQUIRED",
        )
        assert result.status == ValidationStatus.FAIL

    def test_consistent_snapshot_passes(self, engine):
        """A fully consistent snapshot passes all consistency checks."""
        result = engine.validate(
            scenario_id="snap_03",
            observed_safety_state="SAFE",
            observed_emergency_state="NO_EMERGENCY",
            observed_fail_safe_state="NORMAL_OPERATION",
            observed_control_authority="NORMAL_CONTROL",
            expected_safety_state="SAFE",
            expected_emergency_state="NO_EMERGENCY",
            expected_fail_safe_state="NORMAL_OPERATION",
            expected_control_authority="NORMAL_CONTROL",
        )
        assert_pass(result)

    def test_critical_safety_plus_override_required_consistent(self, engine):
        """CRITICAL safety + OVERRIDE_REQUIRED authority = consistent."""
        result = engine.validate(
            scenario_id="snap_04",
            observed_safety_state="CRITICAL",
            observed_emergency_state="CRITICAL_EMERGENCY",
            observed_fail_safe_state="CONTROL_WITHHELD",
            observed_control_authority="OVERRIDE_REQUIRED",
        )
        # No explicit expectations set, only invariant/consistency checks
        # CRITICAL+CRITICAL_EMERGENCY+CONTROL_WITHHELD+OVERRIDE_REQUIRED is consistent
        snap_fail = [
            a for a in result.assertion_results
            if not a.passed and "snap" in a.assertion_id
        ]
        assert len(snap_fail) == 0, (
            f"Consistent critical snapshot should not fail consistency checks: {snap_fail}"
        )


# ===========================================================================
# 9. State Transition Validation
# ===========================================================================

class TestStateTransitions:
    """
    Section 31 of spec: valid and some invalid state transitions.
    """

    def test_normal_to_degraded_transition(self, runner):
        """Fault activates mid-sequence → transitions from NORMAL to restricted."""
        spec = ScenarioSpec(
            scenario_id="trans_01",
            category=ScenarioCategory.STATE_TRANSITION.value,
            description="Camera fails at cycle 2 — normal → restricted transition",
            faults=(
                FaultSpec(
                    target=FaultTarget.CAMERA,
                    fault_type=FaultType.UNAVAILABLE,
                    activation_cycle=2,
                    duration_cycles=0,
                ),
            ),
            cycles=6,
            severity="HIGH",
        )
        result, traces = runner.run(spec)
        # Before fault: normal; after fault: restricted
        pre_fault = [t for t in traces if t.cycle < 2]
        post_fault = [t for t in traces if t.cycle >= 2]
        for t in pre_fault:
            assert t.control_authority == ControlAuthority.NORMAL_CONTROL.value, (
                f"Pre-fault cycle {t.cycle}: expected NORMAL_CONTROL, got {t.control_authority}"
            )
        for t in post_fault:
            assert t.control_authority != ControlAuthority.NORMAL_CONTROL.value, (
                f"Post-fault cycle {t.cycle}: expected restricted authority, got {t.control_authority}"
            )

    def test_fault_activation_and_clearance(self, runner):
        """Fault activates then clears — authority should recover after fault clears."""
        spec = ScenarioSpec(
            scenario_id="trans_02",
            category=ScenarioCategory.STATE_TRANSITION.value,
            description="Camera fails cycles 2–3, then clears",
            faults=(
                FaultSpec(
                    target=FaultTarget.CAMERA,
                    fault_type=FaultType.UNAVAILABLE,
                    activation_cycle=2,
                    duration_cycles=2,  # active at cycles 2, 3
                ),
            ),
            cycles=8,
            severity="HIGH",
        )
        result, traces = runner.run(spec)
        # After fault clears (cycle 4+), authority should eventually recover
        # (hysteresis may delay recovery — we check final state is not permanently stuck)
        final = traces[-1]
        # At least 4 post-fault cycles; hysteresis is typically 3 clear cycles
        # At cycle 7 (3+ cycles after fault cleared), should be recovered
        recovery_traces = [t for t in traces if t.cycle >= 6]
        recovered = any(
            t.control_authority == ControlAuthority.NORMAL_CONTROL.value
            for t in recovery_traces
        )
        assert recovered, (
            f"After fault clears, authority should recover. "
            f"Last traces: {[(t.cycle, t.control_authority) for t in recovery_traces]}"
        )


# ===========================================================================
# 10. Boundary Value Testing
# ===========================================================================

class TestBoundaryValues:
    """
    Section 20 of spec: boundary values for key configuration thresholds.
    """

    def test_zero_cycles_spec(self, runner):
        """Zero-cycle scenario should return gracefully."""
        spec = ScenarioSpec(
            scenario_id="boundary_01",
            category=ScenarioCategory.BOUNDARY_VALUE.value,
            description="Zero cycles",
            cycles=0,
            severity="LOW",
        )
        # Should not raise
        result, traces = runner.run(spec)
        assert len(traces) == 0
        assert result.cycles_executed == 0

    def test_single_cycle_spec(self, runner):
        """Single-cycle scenario produces a valid result."""
        spec = normal_spec("boundary_02", cycles=1)
        result, traces = runner.run(spec)
        assert len(traces) == 1
        assert result.cycles_executed == 1

    def test_single_cycle_with_fault(self, runner):
        """Single cycle, camera unavailable — should restrict in one cycle."""
        spec = camera_fault_spec(FaultType.UNAVAILABLE, "boundary_03", cycles=1)
        result, _ = runner.run(spec)
        assert_not_normal(result, "single-cycle camera failure")

    def test_fault_activates_exactly_at_cycle_boundary(self, runner):
        """Fault that activates at cycle N must be active at cycle N."""
        spec = ScenarioSpec(
            scenario_id="boundary_04",
            category=ScenarioCategory.BOUNDARY_VALUE.value,
            description="Fault activates at cycle 3 exactly",
            faults=(
                FaultSpec(
                    target=FaultTarget.CAMERA,
                    fault_type=FaultType.UNAVAILABLE,
                    activation_cycle=3,
                    duration_cycles=1,
                ),
            ),
            cycles=5,
            severity="HIGH",
        )
        result, traces = runner.run(spec)
        # Cycle 2 (just before): normal
        c2 = next((t for t in traces if t.cycle == 2), None)
        if c2:
            assert c2.control_authority == ControlAuthority.NORMAL_CONTROL.value

        # Cycle 3 (fault active): restricted
        c3 = next((t for t in traces if t.cycle == 3), None)
        if c3:
            assert c3.control_authority != ControlAuthority.NORMAL_CONTROL.value

    def test_fault_duration_zero_means_permanent(self, runner):
        """duration_cycles=0 means the fault lasts for the entire scenario."""
        spec = ScenarioSpec(
            scenario_id="boundary_05",
            category=ScenarioCategory.BOUNDARY_VALUE.value,
            description="Permanent camera fault (duration=0)",
            faults=(
                FaultSpec(
                    target=FaultTarget.CAMERA,
                    fault_type=FaultType.UNAVAILABLE,
                    activation_cycle=0,
                    duration_cycles=0,
                ),
            ),
            cycles=6,
            severity="HIGH",
        )
        result, traces = runner.run(spec)
        for t in traces:
            assert t.control_authority != ControlAuthority.NORMAL_CONTROL.value, (
                f"Cycle {t.cycle}: permanent fault should maintain restriction; "
                f"got {t.control_authority}"
            )


# ===========================================================================
# 11. ValidationEngine Unit Tests
# ===========================================================================

class TestValidationEngineUnit:
    """Unit tests for SafetyValidationEngine in isolation."""

    def test_empty_assertions_yields_inconclusive(self, engine):
        result = engine.validate(
            scenario_id="engine_01",
            # No expectations, no invariants
        )
        assert result.status == ValidationStatus.INCONCLUSIVE

    def test_matching_states_yields_pass(self, engine):
        result = engine.validate(
            scenario_id="engine_02",
            observed_safety_state="SAFE",
            expected_safety_state="SAFE",
            observed_emergency_state="NO_EMERGENCY",
            expected_emergency_state="NO_EMERGENCY",
            observed_control_authority="NORMAL_CONTROL",
            expected_control_authority="NORMAL_CONTROL",
            observed_fail_safe_state="NORMAL_OPERATION",
            expected_fail_safe_state="NORMAL_OPERATION",
        )
        assert_pass(result)

    def test_mismatched_safety_state_yields_fail(self, engine):
        result = engine.validate(
            scenario_id="engine_03",
            observed_safety_state="CRITICAL",
            expected_safety_state="SAFE",
        )
        assert result.status == ValidationStatus.FAIL
        assert "SAFETY_STATE_MISMATCH" in result.mismatch_codes

    def test_mismatched_authority_yields_fail(self, engine):
        result = engine.validate(
            scenario_id="engine_04",
            observed_control_authority="CONTROL_WITHHELD",
            expected_control_authority="NORMAL_CONTROL",
        )
        assert result.status == ValidationStatus.FAIL

    def test_degraded_flag_yields_degraded_status(self, engine):
        result = engine.validate(
            scenario_id="engine_05",
            observed_safety_state="DEGRADED",
            expected_safety_state="DEGRADED",
            degraded=True,
        )
        assert result.status == ValidationStatus.DEGRADED

    def test_determinism_check_identical_results(self, engine):
        from core.safety_validation import SafetyValidationResult, ValidationStatus
        r1 = engine.validate(
            scenario_id="det_01",
            observed_safety_state="SAFE",
            observed_emergency_state="NO_EMERGENCY",
            observed_control_authority="NORMAL_CONTROL",
            observed_fail_safe_state="NORMAL_OPERATION",
            expected_safety_state="SAFE",
            expected_control_authority="NORMAL_CONTROL",
        )
        r2 = engine.validate(
            scenario_id="det_01",
            observed_safety_state="SAFE",
            observed_emergency_state="NO_EMERGENCY",
            observed_control_authority="NORMAL_CONTROL",
            observed_fail_safe_state="NORMAL_OPERATION",
            expected_safety_state="SAFE",
            expected_control_authority="NORMAL_CONTROL",
        )
        det = engine.check_determinism([r1, r2])
        assert det.passed, f"Determinism check failed: {det.mismatch}"

    def test_determinism_check_detects_mismatch(self, engine):
        r1 = engine.validate(
            scenario_id="det_02",
            observed_control_authority="NORMAL_CONTROL",
        )
        r2 = engine.validate(
            scenario_id="det_02",
            observed_control_authority="CONTROL_WITHHELD",
        )
        det = engine.check_determinism([r1, r2])
        assert not det.passed

    def test_determinism_check_needs_two_runs(self, engine):
        r1 = engine.validate(scenario_id="det_03")
        det = engine.check_determinism([r1])
        assert not det.passed

    def test_validation_result_is_immutable(self, engine):
        result = engine.validate(scenario_id="engine_imm")
        with pytest.raises(Exception):
            result.status = ValidationStatus.PASS  # type: ignore  # frozen

    def test_assertion_result_fields(self, engine):
        result = engine.validate(
            scenario_id="engine_af",
            observed_safety_state="CRITICAL",
            expected_safety_state="SAFE",
        )
        a = next(a for a in result.assertion_results if not a.passed)
        assert a.assertion_id
        assert a.invariant_id
        assert a.description
        assert a.expected == "SAFE"
        assert a.actual == "CRITICAL"
        assert a.mismatch

    def test_schema_version(self, engine):
        result = engine.validate(scenario_id="sv_01")
        assert result.schema_version == "11.5"
