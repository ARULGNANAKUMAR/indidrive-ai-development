"""
Phase 11.5 — Test Runner
========================
Standalone runner for all Phase 11.5 safety validation tests.
Matches the project convention: no external pytest binary required.

Usage:
    python tests/safety_validation/run_phase115_tests.py
    python tests/safety_validation/run_phase115_tests.py --fast   (skip 1000-cycle tests)
    python tests/safety_validation/run_phase115_tests.py --verbose
"""
from __future__ import annotations

import sys
import time
import traceback
from typing import List, Tuple

# Ensure project root on path
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from core.safety_validation import SafetyScenarioRunner, SafetyValidationEngine

# Import test modules (shim already installs pytest substitute)
from tests.safety_validation import (
    test_phase115_core as _core,
    test_phase115_stress as _stress,
    test_phase115_indian_road as _indian,
    test_phase115_properties as _props,
)

# ---------------------------------------------------------------------------
# Test registry — (module, class_name)
# ---------------------------------------------------------------------------

_CORE_CLASSES = [
    (_core, "TestNormalOperation"),
    (_core, "TestDegradedOperation"),
    (_core, "TestCriticalFailure"),
    (_core, "TestInvariantA"),
    (_core, "TestInvariantB"),
    (_core, "TestInvariantC"),
    (_core, "TestInvariantG"),
    (_core, "TestSnapshotConsistency"),
    (_core, "TestStateTransitions"),
    (_core, "TestBoundaryValues"),
    (_core, "TestValidationEngineUnit"),
]

_STRESS_CLASSES = [
    (_stress, "TestMultipleFailures"),
    (_stress, "TestFailureCascade"),
    (_stress, "TestRecovery"),
    (_stress, "TestHysteresis"),
    (_stress, "TestStaleDataStress"),
    (_stress, "TestInvalidDataStress"),
    (_stress, "TestHighFrequencyStress"),
    (_stress, "TestLongRunSequence"),
    (_stress, "TestDeterminism"),
]

_INDIAN_CLASSES = [
    (_indian, "TestIndianRoadVillage"),
    (_indian, "TestIndianRoadMarket"),
    (_indian, "TestIndianRoadIntersection"),
    (_indian, "TestIndianRoadHighway"),
    (_indian, "TestSuddenCattleCrossing"),
    (_indian, "TestIndianRoadSensorCombinations"),
]

_PROPS_CLASSES = [
    (_props, "TestSafetyMonitorValidation"),
    (_props, "TestEmergencyDetectionValidation"),
    (_props, "TestSafetySupervisorValidation"),
    (_props, "TestFailSafeValidation"),
    (_props, "TestPropertyBased"),
    (_props, "TestPerformanceValidation"),
]

_ALL_CLASSES = _CORE_CLASSES + _STRESS_CLASSES + _INDIAN_CLASSES + _PROPS_CLASSES

# Tests that run many cycles — skip with --fast
_SLOW_TESTS = {
    "test_1000_healthy_cycles_no_corruption",
    "test_1000_camera_fault_cycles_no_corruption",
    "test_1000_cycles_executes_in_reasonable_time",
    "test_high_frequency_alternating_faults_no_drift",
    "test_normal_degraded_recovery_sequence",
    "test_500_cycle_no_memory_accumulation",
    "test_long_run_scenario_deterministic_x3",
}


# ---------------------------------------------------------------------------
# Runner
# ---------------------------------------------------------------------------

def _build_fixture(method, runner, engine):
    """Inject fixtures by parameter name."""
    try:
        varnames = method.__code__.co_varnames[:method.__code__.co_argcount]
    except AttributeError:
        varnames = ()
    kw = {}
    if "runner" in varnames:
        kw["runner"] = runner
    if "engine" in varnames:
        kw["engine"] = engine
    return kw


def run_all(fast: bool = False, verbose: bool = False) -> Tuple[int, int, List[str]]:
    runner = SafetyScenarioRunner()
    engine = SafetyValidationEngine()

    pass_count = 0
    fail_count = 0
    failures: List[str] = []

    suite_start = time.monotonic()

    for module, class_name in _ALL_CLASSES:
        cls = getattr(module, class_name)
        obj = cls()
        class_pass = 0
        class_fail = 0

        for name in sorted(dir(cls)):
            if not name.startswith("test_"):
                continue
            if fast and name in _SLOW_TESTS:
                if verbose:
                    print(f"    SKIP (--fast): {class_name}.{name}")
                continue

            method = getattr(obj, name)
            kw = _build_fixture(method, runner, engine)

            t0 = time.monotonic()
            try:
                method(**kw)
                elapsed_ms = (time.monotonic() - t0) * 1000
                pass_count += 1
                class_pass += 1
                if verbose:
                    print(f"    PASS ({elapsed_ms:5.1f}ms): {class_name}.{name}")
            except Exception as e:
                elapsed_ms = (time.monotonic() - t0) * 1000
                fail_count += 1
                class_fail += 1
                label = f"{class_name}.{name}"
                tb = traceback.format_exc(limit=3)
                failures.append(f"FAIL: {label}\n  {e}\n{tb}")
                print(f"    FAIL ({elapsed_ms:5.1f}ms): {label}")
                print(f"      {e}")
                if verbose:
                    print(tb)

        status = "✓" if class_fail == 0 else "✗"
        print(f"  {status} {class_name}: {class_pass} pass, {class_fail} fail")

    suite_elapsed = time.monotonic() - suite_start

    print()
    print("=" * 60)
    print(f"Phase 11.5 Safety Validation Tests")
    print(f"  PASS : {pass_count}")
    print(f"  FAIL : {fail_count}")
    print(f"  TOTAL: {pass_count + fail_count}")
    print(f"  TIME : {suite_elapsed:.2f}s")
    print("=" * 60)

    if failures:
        print("\nFailed tests:")
        for f in failures:
            print(f"\n  {f}")

    return pass_count, fail_count, failures


if __name__ == "__main__":
    fast    = "--fast"    in sys.argv
    verbose = "--verbose" in sys.argv or "-v" in sys.argv

    if fast:
        print("[--fast] Skipping high-cycle stress tests\n")

    pass_count, fail_count, _ = run_all(fast=fast, verbose=verbose)
    sys.exit(0 if fail_count == 0 else 1)
