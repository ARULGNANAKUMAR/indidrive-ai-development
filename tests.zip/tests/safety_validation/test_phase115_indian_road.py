"""
Phase 11.5 — Indian Road Safety Scenarios (Spec Section 23–24)
==============================================================
Validates safety behaviour for Indian-road-specific scenarios:
  - Village roads (unmarked, narrow, cattle, pedestrian, motorcycle)
  - Dense market (mixed traffic, pushcarts, temporary obstacles)
  - Unsignalized intersections (crossing vehicle, pedestrian, motorcycle)
  - Highway merge (cut-in, fast vehicle, high relative speed)
  - Sudden cattle/pedestrian crossing (limited reaction time)

Section 24: Sensor failure + Indian road combinations.

These tests use existing World Model / planning / emergency structures.
No new simulator is created.
"""
from __future__ import annotations

try:
    import pytest
except ImportError:
    class _RaisesCtx:
        def __init__(self, exc_types):
            self._exc = exc_types if isinstance(exc_types, tuple) else (exc_types,)
        def __enter__(self): return self
        def __exit__(self, exc_type, exc_val, tb):
            if exc_type is None:
                raise AssertionError(f"Expected {self._exc} but no exception was raised")
            return issubclass(exc_type, self._exc)
    class _Pytest:
        @staticmethod
        def raises(exc): return _RaisesCtx(exc)
        @staticmethod
        def fail(msg): raise AssertionError(msg)
    pytest = _Pytest()

    def fixture(fn=None, **kw):
        if fn is not None: return fn
        def decorator(f): return f
        return decorator
    pytest.fixture = fixture

from core.safety_validation import (
    SafetyScenarioRunner,
    FaultSpec,
    FaultTarget,
    FaultType,
    InvariantId,
    ScenarioCategory,
    ScenarioSpec,
    ValidationStatus,
)
from core.safety_supervisor.supervisor_types import ControlAuthority
from core.failsafe.failsafe_types import FailSafeState
from core.safety.safety_types import SafetyState

from .helpers_115 import (
    T, make_runner,
    assert_pass, assert_not_normal,
    assert_invariant_a_not_violated, assert_invariant_b_not_violated,
)


@pytest.fixture
def runner():
    return make_runner()


# ---------------------------------------------------------------------------
# Helper: build Indian road scenarios with optional sensor faults
# ---------------------------------------------------------------------------

def _indian_scenario(
    scenario_id: str,
    description: str,
    faults: tuple = (),
    cycles: int = 5,
    severity: str = "HIGH",
    category: str = ScenarioCategory.INDIAN_ROAD.value,
    invariants: tuple = (
        InvariantId.INVARIANT_A_NO_NORMAL_ON_CRITICAL_EMERGENCY.value,
        InvariantId.INVARIANT_B_NO_NORMAL_FROM_CRITICAL_SAFETY.value,
        InvariantId.INVARIANT_G_CONTROL_FAILURE_IS_RESTRICTED.value,
    ),
) -> ScenarioSpec:
    return ScenarioSpec(
        scenario_id=scenario_id,
        category=category,
        description=description,
        faults=faults,
        cycles=cycles,
        severity=severity,
        invariants_to_check=invariants,
    )


# ===========================================================================
# 23. Indian Road Safety Scenarios — Clean (no sensor fault)
# ===========================================================================

class TestIndianRoadVillage:
    """
    Village road: unmarked, narrow drivable region, motorcycle, pedestrian, cattle.
    Validates system does not falsely restrict in normal village conditions,
    but correctly restricts when a subsystem fails.
    """

    def test_village_road_normal_conditions(self, runner):
        """Village road, all sensors healthy — no unexpected restriction."""
        spec = _indian_scenario(
            scenario_id="ir_village_01",
            description="Village road: unmarked, healthy sensors, motorcycle ahead",
            cycles=5,
            severity="MEDIUM",
        )
        result, _ = runner.run(spec)
        assert result.actual_control_authority == ControlAuthority.NORMAL_CONTROL.value, (
            f"Village normal conditions produced {result.actual_control_authority}"
        )

    def test_village_road_planning_degraded_restricts(self, runner):
        """Village road + planning degraded → authority restricted (narrow road risk)."""
        spec = _indian_scenario(
            scenario_id="ir_village_02",
            description="Village road: planning degraded (narrow drivable region)",
            faults=(
                FaultSpec(FaultTarget.PLANNING, FaultType.DEGRADED, activation_cycle=0),
            ),
            cycles=5,
            severity="HIGH",
        )
        result, _ = runner.run(spec)
        assert_not_normal(result, "village road + planning degraded")

    def test_village_road_tracking_lost_restricts(self, runner):
        """Village road + tracking lost → serious restriction for narrow unmarked road."""
        spec = _indian_scenario(
            scenario_id="ir_village_03",
            description="Village road: tracking lost",
            faults=(
                FaultSpec(FaultTarget.TRACKING, FaultType.UNAVAILABLE, activation_cycle=0),
            ),
            cycles=5,
            severity="CRITICAL",
        )
        result, _ = runner.run(spec)
        assert_not_normal(result, "village tracking lost")

    def test_village_road_mpc_failure_restricts(self, runner):
        """Village road + MPC failure → critical restriction (narrow road)."""
        spec = _indian_scenario(
            scenario_id="ir_village_04",
            description="Village road: MPC failure",
            faults=(
                FaultSpec(FaultTarget.MPC, FaultType.UNAVAILABLE, activation_cycle=0),
            ),
            cycles=5,
            severity="CRITICAL",
        )
        result, _ = runner.run(spec)
        assert_not_normal(result, "village mpc failure")
        assert_invariant_a_not_violated(result)
        assert_invariant_b_not_violated(result)


class TestIndianRoadMarket:
    """
    Dense market scenario: pedestrian, motorcycle, auto, pushcart,
    temporary obstacle, mixed traffic.
    """

    def test_market_normal_healthy_sensors(self, runner):
        """Dense market with healthy sensors — no false restriction."""
        spec = _indian_scenario(
            scenario_id="ir_market_01",
            description="Dense market: healthy sensors, mixed pedestrian/vehicle traffic",
            cycles=5,
            severity="MEDIUM",
        )
        result, _ = runner.run(spec)
        assert result.actual_control_authority == ControlAuthority.NORMAL_CONTROL.value

    def test_market_perception_degraded_restricts(self, runner):
        """Market + perception degraded → safe restriction (dense crowd risk)."""
        spec = _indian_scenario(
            scenario_id="ir_market_02",
            description="Dense market: perception degraded",
            faults=(
                FaultSpec(FaultTarget.PERCEPTION, FaultType.DEGRADED, activation_cycle=0),
            ),
            cycles=5,
            severity="HIGH",
        )
        result, _ = runner.run(spec)
        assert_not_normal(result, "market + perception degraded")

    def test_market_camera_unavailable_restricts(self, runner):
        """Market + camera unavailable → critical restriction (primary sensor down)."""
        spec = _indian_scenario(
            scenario_id="ir_market_03",
            description="Dense market: camera unavailable",
            faults=(
                FaultSpec(FaultTarget.CAMERA, FaultType.UNAVAILABLE, activation_cycle=0),
            ),
            cycles=5,
            severity="CRITICAL",
        )
        result, _ = runner.run(spec)
        assert_not_normal(result, "market + camera unavailable")

    def test_market_planning_failure_invariant_g(self, runner):
        """Market + planning failure → Invariant G must hold."""
        spec = _indian_scenario(
            scenario_id="ir_market_04",
            description="Dense market: planning failure — Invariant G",
            faults=(
                FaultSpec(FaultTarget.PLANNING, FaultType.UNAVAILABLE, activation_cycle=0),
            ),
            cycles=5,
            severity="CRITICAL",
            invariants=(InvariantId.INVARIANT_G_CONTROL_FAILURE_IS_RESTRICTED.value,),
        )
        result, _ = runner.run(spec)
        assert_not_normal(result, "market + planning failure")


class TestIndianRoadIntersection:
    """
    Unsignalized intersection: crossing vehicle, motorcycle, pedestrian,
    trajectory conflict.
    """

    def test_intersection_healthy_no_restriction(self, runner):
        """Unsignalized intersection, healthy sensors — no false restriction."""
        spec = _indian_scenario(
            scenario_id="ir_inter_01",
            description="Unsignalized intersection: healthy sensors",
            cycles=5,
            severity="MEDIUM",
        )
        result, _ = runner.run(spec)
        assert result.actual_control_authority == ControlAuthority.NORMAL_CONTROL.value

    def test_intersection_mpc_failure_restricts(self, runner):
        """Intersection + MPC failure → must restrict (trajectory control unsafe)."""
        spec = _indian_scenario(
            scenario_id="ir_inter_02",
            description="Unsignalized intersection: MPC failure at crossing conflict",
            faults=(
                FaultSpec(FaultTarget.MPC, FaultType.UNAVAILABLE, activation_cycle=0),
            ),
            cycles=5,
            severity="CRITICAL",
        )
        result, _ = runner.run(spec)
        assert_not_normal(result, "intersection + mpc failure")

    def test_intersection_fusion_failure_restricts(self, runner):
        """Intersection + fusion failure → restricted (trajectory confidence lost)."""
        spec = _indian_scenario(
            scenario_id="ir_inter_03",
            description="Unsignalized intersection: fusion failure",
            faults=(
                FaultSpec(FaultTarget.FUSION, FaultType.UNAVAILABLE, activation_cycle=0),
            ),
            cycles=5,
            severity="CRITICAL",
        )
        result, _ = runner.run(spec)
        assert_not_normal(result, "intersection + fusion failure")

    def test_intersection_camera_degraded_restricts(self, runner):
        """Intersection + camera degraded → restricted (crossing conflict risk)."""
        spec = _indian_scenario(
            scenario_id="ir_inter_04",
            description="Unsignalized intersection: camera degraded",
            faults=(
                FaultSpec(FaultTarget.CAMERA, FaultType.DEGRADED, activation_cycle=0),
            ),
            cycles=5,
            severity="HIGH",
        )
        result, _ = runner.run(spec)
        assert_not_normal(result, "intersection + camera degraded")


class TestIndianRoadHighway:
    """
    Highway merge scenario: fast vehicle, cut-in, merge conflict, high relative speed.
    """

    def test_highway_merge_healthy_no_restriction(self, runner):
        """Highway merge, healthy sensors — no false restriction."""
        spec = _indian_scenario(
            scenario_id="ir_highway_01",
            description="Highway merge: healthy sensors, fast approaching vehicle",
            cycles=5,
            severity="MEDIUM",
        )
        result, _ = runner.run(spec)
        assert result.actual_control_authority == ControlAuthority.NORMAL_CONTROL.value

    def test_highway_lidar_degraded_restricts(self, runner):
        """Highway + LiDAR degraded → restricted (high-speed range estimation)."""
        spec = _indian_scenario(
            scenario_id="ir_highway_02",
            description="Highway merge: LiDAR degraded (range estimation for fast vehicle)",
            faults=(
                FaultSpec(FaultTarget.LIDAR, FaultType.DEGRADED, activation_cycle=0),
            ),
            cycles=5,
            severity="HIGH",
        )
        result, _ = runner.run(spec)
        assert_not_normal(result, "highway + lidar degraded")

    def test_highway_tracking_degraded_restricts(self, runner):
        """Highway + tracking degraded → restricted (can't track fast cut-in)."""
        spec = _indian_scenario(
            scenario_id="ir_highway_03",
            description="Highway merge: tracking degraded for cut-in",
            faults=(
                FaultSpec(FaultTarget.TRACKING, FaultType.DEGRADED, activation_cycle=0),
            ),
            cycles=5,
            severity="HIGH",
        )
        result, _ = runner.run(spec)
        assert_not_normal(result, "highway + tracking degraded")

    def test_highway_planning_failure_restricts(self, runner):
        """Highway + planning failure → critical restriction at merge speed."""
        spec = _indian_scenario(
            scenario_id="ir_highway_04",
            description="Highway merge: planning failure",
            faults=(
                FaultSpec(FaultTarget.PLANNING, FaultType.UNAVAILABLE, activation_cycle=0),
            ),
            cycles=5,
            severity="CRITICAL",
        )
        result, _ = runner.run(spec)
        assert_not_normal(result, "highway + planning failure")

    def test_highway_merge_multiple_subsystem_failure(self, runner):
        """Highway + LiDAR + tracking both fail → must be maximally restricted."""
        spec = _indian_scenario(
            scenario_id="ir_highway_05",
            description="Highway: LiDAR + tracking both failed during cut-in",
            faults=(
                FaultSpec(FaultTarget.LIDAR, FaultType.UNAVAILABLE, activation_cycle=0),
                FaultSpec(FaultTarget.TRACKING, FaultType.UNAVAILABLE, activation_cycle=0),
            ),
            cycles=5,
            severity="CRITICAL",
        )
        result, _ = runner.run(spec)
        assert_not_normal(result, "highway + lidar + tracking both failed")
        assert result.actual_fail_safe_state not in (
            FailSafeState.NORMAL_OPERATION.value,
            FailSafeState.DEGRADED_OPERATION.value,
        )


class TestSuddenCattleCrossing:
    """
    Sudden cattle/pedestrian crossing: sudden vulnerable-object intrusion,
    limited reaction time, degraded perception combinations.
    """

    def test_cattle_crossing_healthy_sensors(self, runner):
        """Sudden cattle crossing with healthy sensors — no false restriction."""
        spec = _indian_scenario(
            scenario_id="ir_cattle_01",
            description="Sudden cattle crossing: healthy sensors, limited reaction time",
            cycles=5,
            severity="HIGH",
        )
        result, _ = runner.run(spec)
        assert result.actual_control_authority == ControlAuthority.NORMAL_CONTROL.value

    def test_cattle_crossing_perception_degraded_restricts(self, runner):
        """Cattle crossing + perception degraded → restricted (sudden intrusion risk)."""
        spec = _indian_scenario(
            scenario_id="ir_cattle_02",
            description="Sudden cattle crossing: perception degraded",
            faults=(
                FaultSpec(FaultTarget.PERCEPTION, FaultType.DEGRADED, activation_cycle=0),
            ),
            cycles=5,
            severity="CRITICAL",
        )
        result, _ = runner.run(spec)
        assert_not_normal(result, "cattle crossing + perception degraded")

    def test_cattle_crossing_camera_unavailable_restricts(self, runner):
        """Cattle crossing + camera unavailable → must restrict (no visual detection)."""
        spec = _indian_scenario(
            scenario_id="ir_cattle_03",
            description="Sudden cattle crossing: camera unavailable",
            faults=(
                FaultSpec(FaultTarget.CAMERA, FaultType.UNAVAILABLE, activation_cycle=0),
            ),
            cycles=5,
            severity="CRITICAL",
        )
        result, _ = runner.run(spec)
        assert_not_normal(result, "cattle crossing + camera unavailable")

    def test_cattle_crossing_prediction_degraded_restricts(self, runner):
        """Cattle crossing + prediction degraded → restricted (trajectory unpredictable)."""
        spec = _indian_scenario(
            scenario_id="ir_cattle_04",
            description="Sudden cattle crossing: prediction degraded",
            faults=(
                FaultSpec(FaultTarget.PREDICTION, FaultType.DEGRADED, activation_cycle=0),
            ),
            cycles=5,
            severity="HIGH",
        )
        result, _ = runner.run(spec)
        assert_not_normal(result, "cattle crossing + prediction degraded")


# ===========================================================================
# 24. Sensor Failure + Indian Road Combinations (Spec Section 24)
# ===========================================================================

class TestIndianRoadSensorCombinations:
    """
    Realistic sensor failure + Indian road scenario combinations.
    Per spec section 24: verify resulting authority consistent with architecture.
    """

    def test_village_camera_degraded_plus_cattle_crossing(self, runner):
        """Village road: camera degraded + sudden cattle crossing."""
        spec = ScenarioSpec(
            scenario_id="ir_combo_01",
            category=ScenarioCategory.INDIAN_ROAD_SENSOR_COMBO.value,
            description="Village: camera degraded + cattle crossing",
            faults=(
                FaultSpec(FaultTarget.CAMERA, FaultType.DEGRADED, activation_cycle=0),
                FaultSpec(FaultTarget.PERCEPTION, FaultType.DEGRADED, activation_cycle=1),
            ),
            cycles=6,
            severity="CRITICAL",
            invariants_to_check=(
                InvariantId.INVARIANT_A_NO_NORMAL_ON_CRITICAL_EMERGENCY.value,
                InvariantId.INVARIANT_G_CONTROL_FAILURE_IS_RESTRICTED.value,
            ),
        )
        result, _ = runner.run(spec)
        assert_not_normal(result, "village camera degraded + cattle")
        assert_invariant_a_not_violated(result)
        assert_invariant_b_not_violated(result)

    def test_market_camera_degraded_plus_pedestrian_crossing(self, runner):
        """Dense market: camera degraded + pedestrian crossing."""
        spec = ScenarioSpec(
            scenario_id="ir_combo_02",
            category=ScenarioCategory.INDIAN_ROAD_SENSOR_COMBO.value,
            description="Market: camera degraded + pedestrian crossing",
            faults=(
                FaultSpec(FaultTarget.CAMERA, FaultType.DEGRADED, activation_cycle=0),
                FaultSpec(FaultTarget.TRACKING, FaultType.DEGRADED, activation_cycle=0),
            ),
            cycles=6,
            severity="CRITICAL",
            invariants_to_check=(
                InvariantId.INVARIANT_A_NO_NORMAL_ON_CRITICAL_EMERGENCY.value,
                InvariantId.INVARIANT_B_NO_NORMAL_FROM_CRITICAL_SAFETY.value,
            ),
        )
        result, _ = runner.run(spec)
        assert_not_normal(result, "market camera degraded + pedestrian")

    def test_intersection_sync_failure_plus_crossing_vehicle(self, runner):
        """Unsignalized intersection: sensor sync failure + crossing vehicle."""
        spec = ScenarioSpec(
            scenario_id="ir_combo_03",
            category=ScenarioCategory.INDIAN_ROAD_SENSOR_COMBO.value,
            description="Intersection: sensor sync failure + crossing vehicle",
            faults=(
                FaultSpec(FaultTarget.FUSION, FaultType.SYNC_FAILURE, activation_cycle=0),
                FaultSpec(FaultTarget.TRACKING, FaultType.DEGRADED, activation_cycle=0),
            ),
            cycles=6,
            severity="CRITICAL",
            invariants_to_check=(
                InvariantId.INVARIANT_G_CONTROL_FAILURE_IS_RESTRICTED.value,
            ),
        )
        result, _ = runner.run(spec)
        assert_not_normal(result, "intersection sync failure + crossing vehicle")

    def test_highway_lidar_degraded_plus_vehicle_cut_in(self, runner):
        """Highway: LiDAR degraded + vehicle cut-in."""
        spec = ScenarioSpec(
            scenario_id="ir_combo_04",
            category=ScenarioCategory.INDIAN_ROAD_SENSOR_COMBO.value,
            description="Highway: LiDAR degraded + cut-in vehicle",
            faults=(
                FaultSpec(FaultTarget.LIDAR, FaultType.DEGRADED, activation_cycle=0),
                FaultSpec(FaultTarget.PREDICTION, FaultType.DEGRADED, activation_cycle=0),
            ),
            cycles=6,
            severity="CRITICAL",
            invariants_to_check=(
                InvariantId.INVARIANT_A_NO_NORMAL_ON_CRITICAL_EMERGENCY.value,
                InvariantId.INVARIANT_G_CONTROL_FAILURE_IS_RESTRICTED.value,
            ),
        )
        result, _ = runner.run(spec)
        assert_not_normal(result, "highway lidar degraded + cut-in")
        assert_invariant_a_not_violated(result)

    def test_cattle_crossing_perception_degraded_plus_tracking_degraded(self, runner):
        """Cattle crossing: perception degradation + tracking degradation."""
        spec = ScenarioSpec(
            scenario_id="ir_combo_05",
            category=ScenarioCategory.INDIAN_ROAD_SENSOR_COMBO.value,
            description="Cattle crossing: perception + tracking both degraded",
            faults=(
                FaultSpec(FaultTarget.PERCEPTION, FaultType.DEGRADED, activation_cycle=0),
                FaultSpec(FaultTarget.TRACKING, FaultType.DEGRADED, activation_cycle=0),
            ),
            cycles=6,
            severity="CRITICAL",
            invariants_to_check=(
                InvariantId.INVARIANT_A_NO_NORMAL_ON_CRITICAL_EMERGENCY.value,
                InvariantId.INVARIANT_B_NO_NORMAL_FROM_CRITICAL_SAFETY.value,
            ),
        )
        result, _ = runner.run(spec)
        assert_not_normal(result, "cattle crossing perception + tracking degraded")
        assert_invariant_a_not_violated(result)

    def test_village_camera_and_planning_failure_combo(self, runner):
        """Village: camera failure + planning failure simultaneously."""
        spec = ScenarioSpec(
            scenario_id="ir_combo_06",
            category=ScenarioCategory.INDIAN_ROAD_SENSOR_COMBO.value,
            description="Village: camera failure + planning failure",
            faults=(
                FaultSpec(FaultTarget.CAMERA, FaultType.UNAVAILABLE, activation_cycle=0),
                FaultSpec(FaultTarget.PLANNING, FaultType.UNAVAILABLE, activation_cycle=0),
            ),
            cycles=6,
            severity="CRITICAL",
            invariants_to_check=(
                InvariantId.INVARIANT_G_CONTROL_FAILURE_IS_RESTRICTED.value,
                InvariantId.INVARIANT_I_MULTIPLE_FAILURES_PRESERVED.value,
            ),
        )
        result, _ = runner.run(spec)
        assert_not_normal(result, "village camera + planning both failed")
        # With both camera and planning down, must be in severe fail-safe
        assert result.actual_fail_safe_state not in (
            FailSafeState.NORMAL_OPERATION.value,
        ), f"Expected severe fail-safe, got {result.actual_fail_safe_state}"

    def test_highway_lidar_camera_dual_failure_combo(self, runner):
        """Highway: both LiDAR and camera fail during merge conflict."""
        spec = ScenarioSpec(
            scenario_id="ir_combo_07",
            category=ScenarioCategory.INDIAN_ROAD_SENSOR_COMBO.value,
            description="Highway: camera + lidar both fail during merge",
            faults=(
                FaultSpec(FaultTarget.CAMERA, FaultType.UNAVAILABLE, activation_cycle=0),
                FaultSpec(FaultTarget.LIDAR, FaultType.UNAVAILABLE, activation_cycle=0),
            ),
            cycles=6,
            severity="CRITICAL",
            invariants_to_check=(
                InvariantId.INVARIANT_A_NO_NORMAL_ON_CRITICAL_EMERGENCY.value,
                InvariantId.INVARIANT_B_NO_NORMAL_FROM_CRITICAL_SAFETY.value,
                InvariantId.INVARIANT_G_CONTROL_FAILURE_IS_RESTRICTED.value,
            ),
        )
        result, _ = runner.run(spec)
        assert_not_normal(result, "highway camera + lidar both failed")
        assert_invariant_a_not_violated(result)
        assert_invariant_b_not_violated(result)

    def test_indian_road_combo_determinism(self, runner):
        """Indian road combo scenarios must be deterministic (Invariant J)."""
        spec = ScenarioSpec(
            scenario_id="ir_combo_det_01",
            category=ScenarioCategory.INDIAN_ROAD_SENSOR_COMBO.value,
            description="Village camera degraded + cattle crossing — determinism check",
            faults=(
                FaultSpec(FaultTarget.CAMERA, FaultType.DEGRADED, activation_cycle=0),
                FaultSpec(FaultTarget.PERCEPTION, FaultType.DEGRADED, activation_cycle=1),
            ),
            cycles=6,
            severity="CRITICAL",
        )
        det = runner.run_determinism_check(spec, runs=5)
        assert det.passed, f"Indian road combo not deterministic: {det.mismatch}"

    def test_all_sensors_degraded_indian_road(self, runner):
        """All sensors degraded simultaneously on Indian road — must restrict completely."""
        spec = ScenarioSpec(
            scenario_id="ir_combo_08",
            category=ScenarioCategory.INDIAN_ROAD_SENSOR_COMBO.value,
            description="All sensors degraded: camera + lidar + radar",
            faults=(
                FaultSpec(FaultTarget.CAMERA, FaultType.DEGRADED, activation_cycle=0),
                FaultSpec(FaultTarget.LIDAR, FaultType.DEGRADED, activation_cycle=0),
                FaultSpec(FaultTarget.RADAR, FaultType.DEGRADED, activation_cycle=0),
            ),
            cycles=6,
            severity="CRITICAL",
            invariants_to_check=(
                InvariantId.INVARIANT_A_NO_NORMAL_ON_CRITICAL_EMERGENCY.value,
                InvariantId.INVARIANT_B_NO_NORMAL_FROM_CRITICAL_SAFETY.value,
            ),
        )
        result, _ = runner.run(spec)
        assert_not_normal(result, "all sensors degraded")
