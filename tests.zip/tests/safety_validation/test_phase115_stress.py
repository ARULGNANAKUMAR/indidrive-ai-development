"""
Phase 11.5 — Stress Testing
=============================
Multiple simultaneous failures, failure cascades, recovery testing,
hysteresis/oscillation, stale-data stress, invalid-data stress,
high-frequency stress, long-run state sequences, and determinism.

Conventions:
  T = 1000.0 — reference timestamp throughout.
  All scenarios are deterministic — no wall clock, no random values.
  Tests use existing Phase 11.1–11.4 engines only.
"""
from __future__ import annotations

import time
try:
    import pytest
except ImportError:
    class _RaisesCtx:
        def __init__(self, exc_types):
            self._exc = exc_types if isinstance(exc_types, tuple) else (exc_types,)
        def __enter__(self): return self
        def __exit__(self, exc_type, exc_val, tb):
            if exc_type is None:
                raise AssertionError(f"Expected {self._exc} but no exception was raised")
            return issubclass(exc_type, self._exc)
    class _Pytest:
        @staticmethod
        def raises(exc): return _RaisesCtx(exc)
        @staticmethod
        def fail(msg): raise AssertionError(msg)
    pytest = _Pytest()

    def fixture(fn=None, **kw):
        if fn is not None: return fn
        def decorator(f): return f
        return decorator
    pytest.fixture = fixture

from core.safety_validation import (
    SafetyScenarioRunner,
    SafetyValidationEngine,
    FaultSpec,
    FaultTarget,
    FaultType,
    InvariantId,
    ScenarioCategory,
    ScenarioSpec,
    ValidationStatus,
)
from core.safety_supervisor.supervisor_types import ControlAuthority
from core.failsafe.failsafe_types import FailSafeState
from core.safety.safety_types import SafetyState

from .helpers_115 import (
    T, make_runner, make_engine,
    normal_spec, camera_fault_spec, lidar_fault_spec,
    planning_fault_spec, mpc_fault_spec, control_fault_spec,
    multi_fault_spec,
    assert_pass, assert_not_normal,
    assert_invariant_a_not_violated, assert_invariant_b_not_violated,
)

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def runner():
    return make_runner()


@pytest.fixture
def engine():
    return make_engine()


# ===========================================================================
# 14. Multiple Failure Stress Testing (Spec Section 14)
# ===========================================================================

class TestMultipleFailures:
    """
    Mandatory deterministic combinations per spec section 14.
    All relevant failures must be preserved; authority must be conservative.
    """

    def test_camera_and_planning_degradation(self, runner):
        spec = multi_fault_spec(
            faults=(
                FaultSpec(FaultTarget.CAMERA, FaultType.UNAVAILABLE, activation_cycle=0),
                FaultSpec(FaultTarget.PLANNING, FaultType.DEGRADED, activation_cycle=0),
            ),
            scenario_id="multi_01",
        )
        result, _ = runner.run(spec)
        assert_not_normal(result, "camera + planning degradation")
        assert_invariant_a_not_violated(result)
        assert_invariant_b_not_violated(result)

    def test_lidar_and_tracking_degradation(self, runner):
        spec = multi_fault_spec(
            faults=(
                FaultSpec(FaultTarget.LIDAR, FaultType.UNAVAILABLE, activation_cycle=0),
                FaultSpec(FaultTarget.TRACKING, FaultType.DEGRADED, activation_cycle=0),
            ),
            scenario_id="multi_02",
        )
        result, _ = runner.run(spec)
        assert_not_normal(result, "lidar + tracking degradation")

    def test_camera_lidar_prediction_degradation(self, runner):
        """Both primary sensors down + prediction degraded."""
        spec = multi_fault_spec(
            faults=(
                FaultSpec(FaultTarget.CAMERA, FaultType.UNAVAILABLE, activation_cycle=0),
                FaultSpec(FaultTarget.LIDAR, FaultType.UNAVAILABLE, activation_cycle=0),
                FaultSpec(FaultTarget.PREDICTION, FaultType.DEGRADED, activation_cycle=0),
            ),
            scenario_id="multi_03",
        )
        result, _ = runner.run(spec)
        # Both primary sensors unavailable → must not have NORMAL_CONTROL
        assert_not_normal(result, "camera+lidar+prediction")

    def test_mpc_failure_and_planning_degradation(self, runner):
        spec = multi_fault_spec(
            faults=(
                FaultSpec(FaultTarget.MPC, FaultType.UNAVAILABLE, activation_cycle=0),
                FaultSpec(FaultTarget.PLANNING, FaultType.DEGRADED, activation_cycle=0),
            ),
            scenario_id="multi_04",
        )
        result, _ = runner.run(spec)
        assert_not_normal(result, "mpc+planning")

    def test_tracking_lost_and_camera_failure(self, runner):
        spec = multi_fault_spec(
            faults=(
                FaultSpec(FaultTarget.TRACKING, FaultType.UNAVAILABLE, activation_cycle=0),
                FaultSpec(FaultTarget.CAMERA, FaultType.UNAVAILABLE, activation_cycle=0),
            ),
            scenario_id="multi_05",
        )
        result, _ = runner.run(spec)
        assert_not_normal(result, "tracking lost + camera failure")

    def test_control_failure_and_camera_failure(self, runner):
        spec = multi_fault_spec(
            faults=(
                FaultSpec(FaultTarget.CONTROL, FaultType.UNAVAILABLE, activation_cycle=0),
                FaultSpec(FaultTarget.CAMERA, FaultType.UNAVAILABLE, activation_cycle=0),
            ),
            scenario_id="multi_06",
        )
        result, _ = runner.run(spec)
        assert_not_normal(result, "control + camera failure")

    def test_planning_and_mpc_and_control_failure(self, runner):
        """Triple critical failure: planning, MPC, control all down."""
        spec = multi_fault_spec(
            faults=(
                FaultSpec(FaultTarget.PLANNING, FaultType.UNAVAILABLE, activation_cycle=0),
                FaultSpec(FaultTarget.MPC, FaultType.UNAVAILABLE, activation_cycle=0),
                FaultSpec(FaultTarget.CONTROL, FaultType.UNAVAILABLE, activation_cycle=0),
            ),
            scenario_id="multi_07",
        )
        result, _ = runner.run(spec)
        assert_not_normal(result, "planning+mpc+control failure")

    def test_camera_lidar_planning_mpc_failure(self, runner):
        """All four critical components down simultaneously."""
        spec = multi_fault_spec(
            faults=(
                FaultSpec(FaultTarget.CAMERA, FaultType.UNAVAILABLE, activation_cycle=0),
                FaultSpec(FaultTarget.LIDAR, FaultType.UNAVAILABLE, activation_cycle=0),
                FaultSpec(FaultTarget.PLANNING, FaultType.UNAVAILABLE, activation_cycle=0),
                FaultSpec(FaultTarget.MPC, FaultType.UNAVAILABLE, activation_cycle=0),
            ),
            scenario_id="multi_08",
        )
        result, _ = runner.run(spec)
        assert_not_normal(result, "camera+lidar+planning+mpc all down")
        # Fail-safe state should be severe
        assert result.actual_fail_safe_state not in (
            FailSafeState.NORMAL_OPERATION.value,
            FailSafeState.DEGRADED_OPERATION.value,
        ), f"Expected severe fail-safe, got {result.actual_fail_safe_state}"

    def test_fusion_and_prediction_failure(self, runner):
        spec = multi_fault_spec(
            faults=(
                FaultSpec(FaultTarget.FUSION, FaultType.UNAVAILABLE, activation_cycle=0),
                FaultSpec(FaultTarget.PREDICTION, FaultType.UNAVAILABLE, activation_cycle=0),
            ),
            scenario_id="multi_09",
        )
        result, _ = runner.run(spec)
        assert_not_normal(result, "fusion + prediction failure")

    def test_multi_failure_authority_conservative_not_escalating(self, runner):
        """
        Adding more critical failures must never make the system LESS restrictive.
        (Property G from spec section 29.)
        """
        # Single failure
        spec1 = camera_fault_spec(FaultType.UNAVAILABLE, "prop_g_01", cycles=3)
        result1, _ = runner.run(spec1)

        # Same + additional failure
        spec2 = multi_fault_spec(
            faults=(
                FaultSpec(FaultTarget.CAMERA, FaultType.UNAVAILABLE, activation_cycle=0),
                FaultSpec(FaultTarget.LIDAR, FaultType.UNAVAILABLE, activation_cycle=0),
            ),
            scenario_id="prop_g_02",
            cycles=3,
        )
        result2, _ = runner.run(spec2)

        # Adding more failures cannot result in NORMAL_CONTROL if single failure didn't
        if result1.actual_control_authority != ControlAuthority.NORMAL_CONTROL.value:
            assert result2.actual_control_authority != ControlAuthority.NORMAL_CONTROL.value, (
                "Property G violated: adding more failures made authority LESS restrictive"
            )


# ===========================================================================
# 15. Failure Cascade Testing (Spec Section 15)
# ===========================================================================

class TestFailureCascade:
    """
    Realistic cascading failure scenarios.
    Camera → Perception → Fusion → World Model → Planning restriction.
    """

    def test_camera_failure_immediately_restricts(self, runner):
        """
        Camera UNAVAILABLE → immediate restriction in the same cycle.
        The failsafe detects sensor OFFLINE directly — no cascade delay needed.
        (TIMEOUT/STALE also map to OFFLINE, which restricts immediately.)
        """
        spec = ScenarioSpec(
            scenario_id="cascade_01",
            category=ScenarioCategory.FAILURE_CASCADE.value,
            description="Camera failure → immediate restriction",
            faults=(
                FaultSpec(
                    target=FaultTarget.CAMERA,
                    fault_type=FaultType.UNAVAILABLE,
                    activation_cycle=0,
                    duration_cycles=0,
                ),
            ),
            cycles=6,
            invariants_to_check=(
                InvariantId.INVARIANT_E_SENSOR_FAILURE_PROPAGATES.value,
            ),
            severity="CRITICAL",
        )
        result, traces = runner.run(spec)
        # Must restrict from cycle 0 (immediate — no delay for OFFLINE sensor)
        assert_not_normal(result, "camera failure immediate restriction")
        for t in traces:
            assert t.control_authority != ControlAuthority.NORMAL_CONTROL.value, (
                f"Cycle {t.cycle}: camera OFFLINE but authority={t.control_authority}"
            )

    def test_perception_failure_causes_world_model_restriction(self, runner):
        """Perception failure cascades into world model degradation → restriction."""
        spec = ScenarioSpec(
            scenario_id="cascade_02",
            category=ScenarioCategory.FAILURE_CASCADE.value,
            description="Perception failure → world model degradation → restriction",
            faults=(
                FaultSpec(
                    target=FaultTarget.PERCEPTION,
                    fault_type=FaultType.UNAVAILABLE,
                    activation_cycle=0,
                ),
                FaultSpec(
                    target=FaultTarget.FUSION,
                    fault_type=FaultType.DEGRADED,
                    activation_cycle=1,  # appears one cycle after perception fails
                ),
            ),
            cycles=6,
            severity="CRITICAL",
        )
        result, traces = runner.run(spec)
        assert_not_normal(result, "perception → fusion cascade")

    def test_unaffected_components_remain_healthy_during_partial_cascade(self, runner):
        """
        When only the camera fails (not lidar), the system should enter
        SENSOR_DEGRADED or similar — not CONTROL_WITHHELD for a single sensor.
        (Invariant F: failure must not kill unrelated capabilities.)
        """
        spec = ScenarioSpec(
            scenario_id="cascade_03",
            category=ScenarioCategory.FAILURE_CASCADE.value,
            description="Camera failure only — lidar unaffected",
            faults=(
                FaultSpec(
                    target=FaultTarget.CAMERA,
                    fault_type=FaultType.DEGRADED,  # degraded, not fully gone
                    activation_cycle=0,
                ),
            ),
            cycles=5,
            severity="MEDIUM",
        )
        result, traces = runner.run(spec)
        # Camera degraded but lidar healthy → should not be CONTROL_WITHHELD
        # (may be SENSOR_DEGRADED, DEGRADED_CONTROL, etc. but not withheld)
        assert result.actual_fail_safe_state != FailSafeState.CONTROL_WITHHELD.value, (
            f"Camera-only degradation should not withhold control. "
            f"Got fail_safe={result.actual_fail_safe_state}"
        )

    def test_cascade_trace_shows_progressive_restriction(self, runner):
        """
        Camera failure at cycle 0 restricts immediately.
        Adding planning degradation at cycle 3 must not make it LESS restrictive.
        Verifies Property G: adding failures never reduces restriction.
        """
        spec = ScenarioSpec(
            scenario_id="cascade_04",
            category=ScenarioCategory.FAILURE_CASCADE.value,
            description="Camera fails at cycle 0, planning degrades at cycle 3",
            faults=(
                FaultSpec(FaultTarget.CAMERA, FaultType.UNAVAILABLE, activation_cycle=0),
                FaultSpec(FaultTarget.PLANNING, FaultType.DEGRADED, activation_cycle=3),
            ),
            cycles=7,
            severity="HIGH",
        )
        result, traces = runner.run(spec)
        # All cycles must be restricted (camera OFFLINE from cycle 0)
        for t in traces:
            assert t.control_authority != ControlAuthority.NORMAL_CONTROL.value, (
                f"Cycle {t.cycle}: expected restriction, got {t.control_authority}"
            )


# ===========================================================================
# 16. Recovery Testing (Spec Section 16)
# ===========================================================================

class TestRecovery:
    """
    Recovery scenarios: failure → recovery candidate → confirmation → recovered.
    Also: failure → recovery → failure again.
    """

    def test_camera_recovery_after_timeout(self, runner):
        """Camera faults for 3 cycles then recovers — authority should return to normal."""
        spec = ScenarioSpec(
            scenario_id="recovery_01",
            category=ScenarioCategory.RECOVERY.value,
            description="Camera fails cycles 0–2, recovers at cycle 3",
            faults=(
                FaultSpec(
                    target=FaultTarget.CAMERA,
                    fault_type=FaultType.UNAVAILABLE,
                    activation_cycle=0,
                    duration_cycles=3,
                ),
            ),
            cycles=10,
            severity="HIGH",
        )
        result, traces = runner.run(spec)
        # During fault (cycles 0-2): restricted
        fault_traces = [t for t in traces if t.cycle < 3]
        for t in fault_traces:
            assert t.control_authority != ControlAuthority.NORMAL_CONTROL.value, (
                f"Cycle {t.cycle}: camera faulted but authority={t.control_authority}"
            )

        # After recovery (give hysteresis time — cycles 6+): should be normal
        post_recovery = [t for t in traces if t.cycle >= 7]
        if post_recovery:
            recovered = any(
                t.control_authority == ControlAuthority.NORMAL_CONTROL.value
                for t in post_recovery
            )
            assert recovered, (
                f"Camera recovered but authority never returned to NORMAL_CONTROL. "
                f"Post-recovery traces: {[(t.cycle, t.control_authority) for t in post_recovery]}"
            )

    def test_no_premature_recovery(self, runner):
        """
        System must not recover to NORMAL_CONTROL while the fault is still active.
        (The architecture's recovery debounce is whatever the config specifies —
        we validate the strictly safety-critical property: no NORMAL during active fault.)
        """
        spec = ScenarioSpec(
            scenario_id="recovery_02",
            category=ScenarioCategory.RECOVERY.value,
            description="Camera fails cycles 0-2 — no NORMAL_CONTROL while fault is active",
            faults=(
                FaultSpec(
                    target=FaultTarget.CAMERA,
                    fault_type=FaultType.UNAVAILABLE,
                    activation_cycle=0,
                    duration_cycles=3,
                ),
            ),
            cycles=6,
            severity="HIGH",
        )
        result, traces = runner.run(spec)
        # While fault is active (cycles 0-2), must never be NORMAL_CONTROL
        for t in traces:
            if t.cycle < 3:
                assert t.control_authority != ControlAuthority.NORMAL_CONTROL.value, (
                    f"Cycle {t.cycle}: camera UNAVAILABLE but authority={t.control_authority}"
                )

    def test_failure_after_recovery_re_restricts(self, runner):
        """Failure → recovery → failure again → re-restricted."""
        spec = ScenarioSpec(
            scenario_id="recovery_03",
            category=ScenarioCategory.RECOVERY.value,
            description="Camera: fail 0-2, recover 3-6, fail again 7+",
            faults=(
                # First failure
                FaultSpec(FaultTarget.CAMERA, FaultType.UNAVAILABLE,
                          activation_cycle=0, duration_cycles=3),
                # Second failure
                FaultSpec(FaultTarget.CAMERA, FaultType.UNAVAILABLE,
                          activation_cycle=7, duration_cycles=0),
            ),
            cycles=12,
            severity="HIGH",
        )
        result, traces = runner.run(spec)
        # During second failure window: restricted again
        second_fault = [t for t in traces if t.cycle >= 7]
        for t in second_fault:
            assert t.control_authority != ControlAuthority.NORMAL_CONTROL.value, (
                f"Second failure at cycle {t.cycle} should restrict; got {t.control_authority}"
            )

    def test_partial_recovery_with_second_fault(self, runner):
        """
        Camera starts recovering, then a second fault (lidar) appears
        before recovery completes.
        """
        spec = ScenarioSpec(
            scenario_id="recovery_04",
            category=ScenarioCategory.RECOVERY.value,
            description="Camera recovering, lidar fails mid-recovery",
            faults=(
                FaultSpec(FaultTarget.CAMERA, FaultType.UNAVAILABLE,
                          activation_cycle=0, duration_cycles=4),
                FaultSpec(FaultTarget.LIDAR, FaultType.UNAVAILABLE,
                          activation_cycle=3, duration_cycles=0),
            ),
            cycles=10,
            severity="CRITICAL",
        )
        result, traces = runner.run(spec)
        # After cycle 3: both faults active → must be restricted
        both_active = [t for t in traces if t.cycle >= 3]
        for t in both_active:
            assert t.control_authority != ControlAuthority.NORMAL_CONTROL.value


# ===========================================================================
# 17. Hysteresis Testing (Spec Section 17)
# ===========================================================================

class TestHysteresis:
    """
    Oscillating inputs must not produce unsafe oscillating safety authority.
    Uses timestamp-based simulation, not real sleep().
    """

    def test_oscillating_camera_fault_does_not_oscillate_authority(self, runner):
        """
        Camera oscillating between faulted and healthy.
        Key safety property: during active fault windows, authority must NEVER be NORMAL_CONTROL.
        The architecture may recover quickly between faults — that is acceptable behaviour;
        what is NOT acceptable is NORMAL_CONTROL while the fault is active.
        """
        spec = ScenarioSpec(
            scenario_id="hysteresis_01",
            category=ScenarioCategory.HYSTERESIS.value,
            description="Oscillating camera fault — no NORMAL_CONTROL during active fault",
            faults=(
                FaultSpec(FaultTarget.CAMERA, FaultType.UNAVAILABLE,
                          activation_cycle=1, duration_cycles=2),
                FaultSpec(FaultTarget.CAMERA, FaultType.UNAVAILABLE,
                          activation_cycle=5, duration_cycles=2),
            ),
            cycles=10,
            severity="HIGH",
        )
        result, traces = runner.run(spec)
        # Safety invariant: during active fault cycles, authority is never NORMAL_CONTROL
        fault_cycles = set(range(1, 3)) | set(range(5, 7))
        for t in traces:
            if t.cycle in fault_cycles:
                assert t.control_authority != ControlAuthority.NORMAL_CONTROL.value, (
                    f"Cycle {t.cycle}: camera UNAVAILABLE but authority={t.control_authority} "
                    f"— fault must restrict immediately"
                )

    def test_no_unsafe_oscillation_on_repeated_critical_flags(self, runner):
        """
        Critical planning failures in every other cycle must not yield
        NORMAL_CONTROL between failures.
        """
        faults = tuple(
            FaultSpec(FaultTarget.PLANNING, FaultType.UNAVAILABLE,
                      activation_cycle=i, duration_cycles=1)
            for i in range(0, 10, 2)  # cycles 0,2,4,6,8
        )
        spec = ScenarioSpec(
            scenario_id="hysteresis_02",
            category=ScenarioCategory.HYSTERESIS.value,
            description="Planning fault every other cycle",
            faults=faults,
            cycles=10,
            severity="CRITICAL",
        )
        result, traces = runner.run(spec)
        # During every fault cycle: must be restricted
        for t in traces:
            if t.cycle % 2 == 0:  # fault-active cycles
                assert t.control_authority != ControlAuthority.NORMAL_CONTROL.value, (
                    f"Cycle {t.cycle}: planning faulted but authority={t.control_authority}"
                )


# ===========================================================================
# 18. Stale Data Stress Testing (Spec Section 18)
# ===========================================================================

class TestStaleDataStress:
    """
    Tests for stale data at various levels of staleness.
    Verifies that safety-critical stale data is not treated as fresh.
    """

    def test_stale_camera_restricts(self, runner):
        """
        Stale camera data → camera treated as OFFLINE by the failsafe engine
        (stale sensor output cannot be trusted) → restriction required.
        Invariant C: stale safety-critical data must not be treated as fresh.
        """
        spec = ScenarioSpec(
            scenario_id="stale_s_01",
            category=ScenarioCategory.STALE_DATA.value,
            description="Camera stale (→ OFFLINE at failsafe layer) → restricts",
            faults=(
                FaultSpec(FaultTarget.CAMERA, FaultType.STALE, activation_cycle=0),
            ),
            cycles=4,
            severity="HIGH",
        )
        result, _ = runner.run(spec)
        assert_not_normal(result, "stale camera")

    def test_stale_lidar_restricts(self, runner):
        """
        Stale LiDAR data → OFFLINE at failsafe layer → restriction required.
        """
        spec = ScenarioSpec(
            scenario_id="stale_s_02",
            category=ScenarioCategory.STALE_DATA.value,
            description="LiDAR stale (→ OFFLINE at failsafe layer) → restricts",
            faults=(
                FaultSpec(FaultTarget.LIDAR, FaultType.STALE, activation_cycle=0),
            ),
            cycles=4,
            severity="HIGH",
        )
        result, _ = runner.run(spec)
        assert_not_normal(result, "stale lidar")

    def test_multiple_stale_inputs_stay_restricted(self, runner):
        """Multiple stale inputs should stay restricted, not somehow produce NORMAL."""
        spec = ScenarioSpec(
            scenario_id="stale_s_03",
            category=ScenarioCategory.STALE_DATA.value,
            description="Camera + MPC both stale",
            faults=(
                FaultSpec(FaultTarget.CAMERA, FaultType.STALE, activation_cycle=0),
                FaultSpec(FaultTarget.MPC, FaultType.STALE, activation_cycle=0),
            ),
            cycles=4,
            severity="CRITICAL",
        )
        result, _ = runner.run(spec)
        assert_not_normal(result, "camera+mpc both stale")

    def test_engine_stale_true_with_critical_emergency_invariant_c(self, engine):
        """stale=True flag on result + SAFE state = Invariant C violated."""
        result = engine.validate(
            scenario_id="stale_s_04",
            observed_safety_state="SAFE",
            observed_control_authority="NORMAL_CONTROL",
            invariants_to_check=(InvariantId.INVARIANT_C_STALE_IS_NOT_FRESH.value,),
            stale=True,
        )
        assert result.status == ValidationStatus.FAIL


# ===========================================================================
# 19. Invalid Data Stress Testing (Spec Section 19)
# ===========================================================================

class TestInvalidDataStress:

    def test_invalid_camera_data_restricts(self, runner):
        spec = ScenarioSpec(
            scenario_id="invalid_01",
            category=ScenarioCategory.INVALID_DATA.value,
            description="Camera provides invalid data",
            faults=(
                FaultSpec(FaultTarget.CAMERA, FaultType.INVALID_DATA, activation_cycle=0),
            ),
            cycles=4,
            severity="HIGH",
        )
        result, _ = runner.run(spec)
        assert_not_normal(result, "invalid camera data")

    def test_invalid_lidar_data_restricts(self, runner):
        spec = ScenarioSpec(
            scenario_id="invalid_02",
            category=ScenarioCategory.INVALID_DATA.value,
            description="LiDAR provides invalid data",
            faults=(
                FaultSpec(FaultTarget.LIDAR, FaultType.INVALID_DATA, activation_cycle=0),
            ),
            cycles=4,
            severity="HIGH",
        )
        result, _ = runner.run(spec)
        assert_not_normal(result, "invalid lidar data")

    def test_engine_inv_d_invalid_input_not_trusted(self, engine):
        """Invariant D: invalid input must not produce SAFE + NORMAL_CONTROL."""
        result = engine.validate(
            scenario_id="invalid_03",
            observed_safety_state="SAFE",
            observed_control_authority="NORMAL_CONTROL",
            invariants_to_check=(InvariantId.INVARIANT_D_INVALID_IS_NOT_TRUSTED.value,),
        )
        assert result.status == ValidationStatus.FAIL

    def test_engine_inv_d_invalid_plus_unknown_safe(self, engine):
        """Invalid input + UNKNOWN safety state = Invariant D satisfied."""
        result = engine.validate(
            scenario_id="invalid_04",
            observed_safety_state="UNKNOWN",
            observed_control_authority="CONTROL_WITHHELD",
            invariants_to_check=(InvariantId.INVARIANT_D_INVALID_IS_NOT_TRUSTED.value,),
        )
        inv_d = [a for a in result.assertion_results if "inv_d" in a.assertion_id]
        assert all(a.passed for a in inv_d)

    def test_corrupted_camera_data_restricts(self, runner):
        """
        Corrupted camera data → camera treated as OFFLINE (output cannot be trusted)
        → restriction required. Invariant D: invalid input must not yield trusted state.
        """
        spec = ScenarioSpec(
            scenario_id="invalid_05",
            category=ScenarioCategory.INVALID_DATA.value,
            description="Camera corrupted (→ OFFLINE at failsafe layer) → restricts",
            faults=(
                FaultSpec(FaultTarget.CAMERA, FaultType.CORRUPTED, activation_cycle=0),
            ),
            cycles=4,
            severity="HIGH",
        )
        result, _ = runner.run(spec)
        assert_not_normal(result, "corrupted camera")

    def test_invalid_timestamp_camera_restricts(self, runner):
        """
        Invalid camera timestamp → camera treated as OFFLINE → restriction required.
        """
        spec = ScenarioSpec(
            scenario_id="invalid_06",
            category=ScenarioCategory.INVALID_DATA.value,
            description="Camera invalid timestamp (→ OFFLINE at failsafe layer) → restricts",
            faults=(
                FaultSpec(FaultTarget.CAMERA, FaultType.INVALID_TIMESTAMP, activation_cycle=0),
            ),
            cycles=4,
            severity="HIGH",
        )
        result, _ = runner.run(spec)
        assert_not_normal(result, "camera invalid timestamp")


# ===========================================================================
# 21. High-Frequency Stress Testing (Spec Section 21)
# ===========================================================================

class TestHighFrequencyStress:
    """
    Run 1000+ deterministic safety cycles to verify:
    - no state corruption
    - no unexpected drift
    - bounded history
    - deterministic results
    """

    def test_1000_healthy_cycles_no_corruption(self, runner):
        """1000 healthy cycles must produce stable SAFE+NORMAL_CONTROL throughout."""
        spec = normal_spec("hf_01", cycles=1000)
        result, traces = runner.run(spec)
        assert_pass(result, "1000 healthy cycles")
        # Spot-check traces for stability
        for i in [0, 100, 250, 500, 750, 999]:
            t = traces[i]
            assert t.safety_state == "SAFE", f"Cycle {i}: safety drifted to {t.safety_state}"
            assert t.control_authority == "NORMAL_CONTROL", \
                f"Cycle {i}: authority drifted to {t.control_authority}"

    def test_1000_camera_fault_cycles_no_corruption(self, runner):
        """1000 cycles with camera faulted must maintain restriction throughout."""
        spec = ScenarioSpec(
            scenario_id="hf_02",
            category=ScenarioCategory.HIGH_FREQUENCY_STRESS.value,
            description="1000 cycles with camera faulted",
            faults=(
                FaultSpec(FaultTarget.CAMERA, FaultType.UNAVAILABLE, activation_cycle=0),
            ),
            cycles=1000,
            severity="HIGH",
        )
        result, traces = runner.run(spec)
        for i in [0, 100, 500, 999]:
            t = traces[i]
            assert t.control_authority != ControlAuthority.NORMAL_CONTROL.value, \
                f"Cycle {i}: camera faulted but authority={t.control_authority}"

    def test_1000_cycles_executes_in_reasonable_time(self, runner):
        """Performance: 1000 cycles must complete without excessive wall-clock time."""
        spec = normal_spec("hf_03", cycles=1000)
        start = time.monotonic()
        result, _ = runner.run(spec)
        elapsed_s = time.monotonic() - start
        # 1000 cycles should complete within 30 seconds on any reasonable machine
        assert elapsed_s < 30.0, (
            f"1000 healthy cycles took {elapsed_s:.1f}s — performance degradation?"
        )
        assert result.execution_time_ms > 0

    def test_trace_count_bounded_to_cycles(self, runner):
        """Trace count must equal the number of cycles executed — no unbounded growth."""
        cycles = 500
        spec = normal_spec("hf_04", cycles=cycles)
        _, traces = runner.run(spec)
        assert len(traces) == cycles, (
            f"Expected {cycles} trace entries, got {len(traces)}"
        )

    def test_high_frequency_alternating_faults_no_drift(self, runner):
        """
        Alternating camera/lidar fault every 10 cycles × 100 repetitions.
        Safety state must not drift unexpectedly.
        """
        faults = []
        for i in range(0, 100):
            target = FaultTarget.CAMERA if i % 2 == 0 else FaultTarget.LIDAR
            faults.append(FaultSpec(
                target=target,
                fault_type=FaultType.UNAVAILABLE,
                activation_cycle=i * 10,
                duration_cycles=9,
            ))

        spec = ScenarioSpec(
            scenario_id="hf_05",
            category=ScenarioCategory.HIGH_FREQUENCY_STRESS.value,
            description="Alternating camera/lidar faults every 10 cycles",
            faults=tuple(faults),
            cycles=1000,
            severity="HIGH",
        )
        result, traces = runner.run(spec)
        # All cycles in a fault window should be restricted
        # Spot check cycle 5 (camera fault window) and cycle 15 (lidar fault window)
        for chk_cycle in [5, 15, 25, 35]:
            t = next((x for x in traces if x.cycle == chk_cycle), None)
            if t:
                assert t.control_authority != ControlAuthority.NORMAL_CONTROL.value, \
                    f"Cycle {chk_cycle}: fault active but authority={t.control_authority}"


# ===========================================================================
# 22. Long-Run State Sequence (Spec Section 22)
# ===========================================================================

class TestLongRunSequence:
    """
    NORMAL → DEGRADED → NORMAL → EMERGENCY → FAIL_SAFE → RECOVERY → NORMAL
    repeated multiple times.
    """

    def test_normal_degraded_recovery_sequence(self, runner):
        """
        Runs: 20 normal → 10 camera fail → 20 recovery → 10 camera fail → 20 recovery
        Verifies no permanent lock-out after repeated recovery cycles.
        """
        faults = (
            FaultSpec(FaultTarget.CAMERA, FaultType.UNAVAILABLE,
                      activation_cycle=20, duration_cycles=10),
            FaultSpec(FaultTarget.CAMERA, FaultType.UNAVAILABLE,
                      activation_cycle=50, duration_cycles=10),
        )
        spec = ScenarioSpec(
            scenario_id="longrun_01",
            category=ScenarioCategory.LONG_RUN_SEQUENCE.value,
            description="NORMAL→FAIL→RECOVER sequence ×2",
            faults=faults,
            cycles=80,
            severity="HIGH",
        )
        result, traces = runner.run(spec)

        # Phase 1 (cycles 0-19): normal
        for t in traces[:20]:
            assert t.control_authority == ControlAuthority.NORMAL_CONTROL.value, \
                f"Pre-fault cycle {t.cycle}: expected NORMAL, got {t.control_authority}"

        # Phase 2 (cycles 20-29): faulted
        for t in traces[20:30]:
            assert t.control_authority != ControlAuthority.NORMAL_CONTROL.value, \
                f"Fault cycle {t.cycle}: should be restricted, got {t.control_authority}"

        # Phase 3 (cycles 35-49): should eventually recover
        recovery1 = traces[35:50]
        recovered = any(
            t.control_authority == ControlAuthority.NORMAL_CONTROL.value
            for t in recovery1
        )
        assert recovered, "Should recover to NORMAL_CONTROL after first fault clears"

        # Phase 5 (cycles 65+): should recover after second fault
        recovery2 = traces[65:]
        recovered2 = any(
            t.control_authority == ControlAuthority.NORMAL_CONTROL.value
            for t in recovery2
        )
        assert recovered2, "Should recover to NORMAL_CONTROL after second fault clears"

    def test_no_stale_emergency_after_clearing(self, runner):
        """
        After a fault clears and system recovers, old emergency traces must
        not persist indefinitely.
        """
        spec = ScenarioSpec(
            scenario_id="longrun_02",
            category=ScenarioCategory.LONG_RUN_SEQUENCE.value,
            description="Fault clears — old emergency must not persist",
            faults=(
                FaultSpec(FaultTarget.PLANNING, FaultType.UNAVAILABLE,
                          activation_cycle=5, duration_cycles=5),
            ),
            cycles=30,
            severity="HIGH",
        )
        result, traces = runner.run(spec)
        # After fault clears (cycle 10+), by cycle 20+ safety state should have
        # returned from CRITICAL — not be stuck
        post = [t for t in traces if t.cycle >= 20]
        all_critical = all(t.safety_state == "CRITICAL" for t in post)
        assert not all_critical, (
            "Safety state appears stuck at CRITICAL long after fault cleared"
        )


# ===========================================================================
# 28. Determinism Testing (Spec Section 28)
# ===========================================================================

class TestDeterminism:
    """
    Same scenario run multiple times must produce identical outputs.
    Invariant J: deterministic behavior.
    """

    def test_normal_scenario_deterministic_x10(self, runner):
        spec = normal_spec("det_01", cycles=5)
        det_result = runner.run_determinism_check(spec, runs=10)
        assert det_result.passed, (
            f"Normal scenario not deterministic: {det_result.mismatch}"
        )

    def test_camera_fault_scenario_deterministic_x10(self, runner):
        spec = camera_fault_spec(FaultType.UNAVAILABLE, "det_02", cycles=5)
        det_result = runner.run_determinism_check(spec, runs=10)
        assert det_result.passed, (
            f"Camera fault scenario not deterministic: {det_result.mismatch}"
        )

    def test_multi_fault_scenario_deterministic_x5(self, runner):
        spec = ScenarioSpec(
            scenario_id="det_03",
            category=ScenarioCategory.DETERMINISM.value,
            description="Multi-fault determinism check",
            faults=(
                FaultSpec(FaultTarget.CAMERA, FaultType.UNAVAILABLE, activation_cycle=0),
                FaultSpec(FaultTarget.PLANNING, FaultType.DEGRADED, activation_cycle=1),
            ),
            cycles=5,
            severity="HIGH",
        )
        det_result = runner.run_determinism_check(spec, runs=5)
        assert det_result.passed, (
            f"Multi-fault scenario not deterministic: {det_result.mismatch}"
        )

    def test_long_run_scenario_deterministic_x3(self, runner):
        spec = ScenarioSpec(
            scenario_id="det_04",
            category=ScenarioCategory.DETERMINISM.value,
            description="Long-run scenario determinism check",
            faults=(
                FaultSpec(FaultTarget.CAMERA, FaultType.UNAVAILABLE,
                          activation_cycle=10, duration_cycles=5),
            ),
            cycles=30,
            severity="HIGH",
        )
        det_result = runner.run_determinism_check(spec, runs=3)
        assert det_result.passed, (
            f"Long-run scenario not deterministic: {det_result.mismatch}"
        )

    def test_engine_determinism_across_identical_inputs(self, engine):
        """Same inputs to ValidationEngine always produce identical result."""
        kwargs = dict(
            scenario_id="det_eng_01",
            observed_safety_state="CRITICAL",
            observed_emergency_state="CRITICAL_EMERGENCY",
            observed_fail_safe_state="CONTROL_WITHHELD",
            observed_control_authority="OVERRIDE_REQUIRED",
            expected_control_authority="OVERRIDE_REQUIRED",
            invariants_to_check=(
                InvariantId.INVARIANT_A_NO_NORMAL_ON_CRITICAL_EMERGENCY.value,
                InvariantId.INVARIANT_B_NO_NORMAL_FROM_CRITICAL_SAFETY.value,
            ),
        )
        results = [engine.validate(**kwargs) for _ in range(5)]
        det = engine.check_determinism(results)
        assert det.passed, f"Engine not deterministic: {det.mismatch}"
