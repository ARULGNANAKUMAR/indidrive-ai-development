"""
IndiDrive AI — Phase 5.1 | Object Memory Core Tests
=====================================================
Run with:  PYTHONPATH=. pytest tests/memory/ -v

Covers every requirement from the Phase 5.1 spec:
  - Basic CRUD
  - Identity (unique IDs, duplicate handling, track association)
  - Validation (missing ID, missing type, invalid timestamps, NaN, Inf,
                invalid confidence, invalid dimensions)
  - Capacity (max entries, cleanup, determinism)
  - Lifecycle (NEW → ACTIVE → STALE → EXPIRED, tick, cleanup)
  - Serialization (to_dict, from_dict, to_json/from_json, round-trip,
                   invalid JSON, schema version)
  - Offline (no network)
  - Determinism
  - Performance (insert / lookup / update / cleanup latency)
"""
from __future__ import annotations

import math
import sys
import time
import threading
from pathlib import Path
from typing import List

import pytest

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))

from core.memory import (
    ObjectMemory,
    ObjectMemoryEntry,
    MemoryLifecycleState,
    MemoryCleanupPolicy,
    MemoryPositionSummary,
    MemoryDimensions,
    MemoryMotionSummary,
    MemoryOperationResult,
    MemoryStoreStats,
    InMemoryStore,
    validate_entry,
    MEMORY_SCHEMA_VERSION,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _entry(
    memory_id: str = "mem_test01",
    object_type: str = "CAR",
    confidence: float = 0.85,
    track_id: str = "track_42",
    observed_at: float = 1000.0,
) -> ObjectMemoryEntry:
    return ObjectMemoryEntry(
        memory_id=memory_id,
        track_id=track_id,
        object_type=object_type,
        confidence=confidence,
        observed_at=observed_at,
        created_at=observed_at,
        updated_at=observed_at,
        source="test",
        position=MemoryPositionSummary(x=10.0, y=5.0, z=0.0),
        dimensions=MemoryDimensions(length=4.5, width=1.8, height=1.5),
        motion=MemoryMotionSummary(speed_ms=8.3, heading_rad=0.5, acceleration_ms2=0.2),
    )


def _memory(**kwargs) -> ObjectMemory:
    """Return a fresh ObjectMemory with safe test defaults."""
    defaults = dict(
        max_entries=100,
        max_age_s=None,  # unlimited for most tests
        cleanup_policy=MemoryCleanupPolicy.OLDEST_FIRST,
        stale_after_s=30.0,
        enabled=True,
    )
    defaults.update(kwargs)
    return ObjectMemory(**defaults)


# ===========================================================================
# Section 1 — Basic CRUD
# ===========================================================================

class TestBasicCRUD:

    def test_create_entry(self):
        mem = _memory()
        e = _entry()
        result = mem.add(e)
        assert result.ok
        assert result.memory_id == "mem_test01"

    def test_read_entry(self):
        mem = _memory()
        e = _entry()
        mem.add(e)
        fetched = mem.get("mem_test01")
        assert fetched is not None
        assert fetched.memory_id == "mem_test01"
        assert fetched.object_type == "CAR"

    def test_read_missing_returns_none(self):
        mem = _memory()
        assert mem.get("does_not_exist") is None

    def test_update_entry(self):
        mem = _memory()
        e = _entry()
        mem.add(e)
        import dataclasses
        updated = dataclasses.replace(e, confidence=0.99, updated_at=1001.0)
        result = mem.update("mem_test01", updated)
        assert result.ok
        fetched = mem.get("mem_test01")
        assert fetched.confidence == pytest.approx(0.99)

    def test_delete_entry(self):
        mem = _memory()
        mem.add(_entry())
        result = mem.remove("mem_test01")
        assert result.ok
        assert mem.get("mem_test01") is None

    def test_delete_missing_returns_failure(self):
        mem = _memory()
        result = mem.remove("ghost_id")
        assert not result.ok
        assert "not found" in result.reason.lower()

    def test_exists_true(self):
        mem = _memory()
        mem.add(_entry())
        assert mem.exists("mem_test01")

    def test_exists_false(self):
        mem = _memory()
        assert not mem.exists("nope")

    def test_list_entries(self):
        mem = _memory()
        for i in range(5):
            mem.add(_entry(memory_id=f"mem_{i:03d}", track_id=f"t{i}"))
        entries = mem.list()
        assert len(entries) == 5

    def test_list_ids_sorted(self):
        mem = _memory()
        ids = ["mem_c", "mem_a", "mem_b"]
        for mid in ids:
            mem.add(_entry(memory_id=mid, track_id=mid))
        assert mem.list_ids() == sorted(ids)

    def test_clear_memory(self):
        mem = _memory()
        for i in range(10):
            mem.add(_entry(memory_id=f"mem_{i}", track_id=f"t{i}"))
        removed = mem.clear()
        assert removed == 10
        assert len(mem.list()) == 0


# ===========================================================================
# Section 2 — Identity
# ===========================================================================

class TestIdentity:

    def test_new_id_is_unique(self):
        mem = _memory()
        ids = {mem.new_id() for _ in range(1000)}
        assert len(ids) == 1000

    def test_new_id_with_hint_deterministic_prefix(self):
        mem = _memory()
        id1 = mem.new_id(hint="track_99")
        id2 = mem.new_id(hint="track_99")
        # Different IDs (counter differs) but same prefix pattern
        assert id1.startswith("mem_")
        assert id2.startswith("mem_")
        assert id1 != id2

    def test_duplicate_memory_id_rejected(self):
        mem = _memory()
        e = _entry()
        mem.add(e)
        result = mem.add(e)  # same memory_id
        assert not result.ok
        assert "already exists" in result.reason.lower()

    def test_track_id_association(self):
        mem = _memory()
        e = _entry(track_id="stable_track_7")
        mem.add(e)
        fetched = mem.get("mem_test01")
        assert fetched.track_id == "stable_track_7"

    def test_memory_id_survives_track_update(self):
        """Memory ID stays stable even when track_id changes (e.g. track reset)."""
        mem = _memory()
        e = _entry(track_id="old_track")
        mem.add(e)
        import dataclasses
        updated = dataclasses.replace(e, track_id="new_track", updated_at=1001.0)
        mem.update("mem_test01", updated)
        fetched = mem.get("mem_test01")
        assert fetched.memory_id == "mem_test01"  # memory_id unchanged
        assert fetched.track_id == "new_track"


# ===========================================================================
# Section 3 — Validation
# ===========================================================================

class TestValidation:

    def test_missing_memory_id_rejected(self):
        e = ObjectMemoryEntry(memory_id="", object_type="CAR", confidence=0.5,
                               observed_at=1000.0, created_at=1000.0, updated_at=1000.0)
        r = validate_entry(e)
        assert not r.ok
        assert "memory_id" in r.reason.lower()

    def test_missing_object_type_rejected(self):
        e = _entry(object_type="NOT_AVAILABLE")
        r = validate_entry(e)
        assert not r.ok
        assert "object_type" in r.reason.lower()

    def test_empty_object_type_rejected(self):
        e = _entry(object_type="")
        r = validate_entry(e)
        assert not r.ok

    def test_invalid_timestamp_nan(self):
        e = _entry(observed_at=float("nan"))
        r = validate_entry(e)
        assert not r.ok
        assert "observed_at" in r.reason.lower()

    def test_invalid_timestamp_inf(self):
        e = _entry(observed_at=float("inf"))
        r = validate_entry(e)
        assert not r.ok

    def test_invalid_timestamp_negative(self):
        e = _entry(observed_at=-1.0)
        r = validate_entry(e)
        assert not r.ok

    def test_confidence_nan(self):
        e = _entry(confidence=float("nan"))
        r = validate_entry(e)
        assert not r.ok
        assert "confidence" in r.reason.lower()

    def test_confidence_inf(self):
        e = _entry(confidence=float("inf"))
        r = validate_entry(e)
        assert not r.ok

    def test_confidence_above_1(self):
        e = _entry(confidence=1.1)
        r = validate_entry(e)
        assert not r.ok

    def test_confidence_below_0(self):
        e = _entry(confidence=-0.1)
        r = validate_entry(e)
        assert not r.ok

    def test_confidence_boundary_valid(self):
        for c in (0.0, 0.5, 1.0):
            e = _entry(confidence=c)
            assert validate_entry(e).ok, f"confidence={c} should be valid"

    def test_invalid_dimension_negative(self):
        e = _entry()
        e.dimensions = MemoryDimensions(length=-1.0, width=1.8, height=1.5)
        r = validate_entry(e)
        assert not r.ok
        assert "dimensions" in r.reason.lower()

    def test_invalid_dimension_nan(self):
        e = _entry()
        e.dimensions = MemoryDimensions(length=float("nan"), width=1.8, height=1.5)
        r = validate_entry(e)
        assert not r.ok

    def test_invalid_position_nan(self):
        e = _entry()
        e.position = MemoryPositionSummary(x=float("nan"), y=0.0, z=0.0)
        r = validate_entry(e)
        assert not r.ok
        assert "position" in r.reason.lower()

    def test_invalid_position_inf(self):
        e = _entry()
        e.position = MemoryPositionSummary(x=float("inf"), y=0.0, z=0.0)
        r = validate_entry(e)
        assert not r.ok

    def test_invalid_motion_negative_speed(self):
        e = _entry()
        e.motion = MemoryMotionSummary(speed_ms=-5.0)
        r = validate_entry(e)
        assert not r.ok
        assert "motion" in r.reason.lower()

    def test_invalid_motion_nan_heading(self):
        e = _entry()
        e.motion = MemoryMotionSummary(speed_ms=5.0, heading_rad=float("nan"))
        r = validate_entry(e)
        assert not r.ok

    def test_valid_entry_passes(self):
        e = _entry()
        assert validate_entry(e).ok

    def test_add_invalid_does_not_crash_memory(self):
        mem = _memory()
        bad = _entry(confidence=99.0)
        result = mem.add(bad)
        assert not result.ok
        assert len(mem.list()) == 0


# ===========================================================================
# Section 4 — Capacity
# ===========================================================================

class TestCapacity:

    def test_max_capacity_respected(self):
        mem = _memory(max_entries=5)
        for i in range(10):
            mem.add(_entry(memory_id=f"mem_{i:03d}", track_id=f"t{i}",
                           observed_at=float(1000 + i)))
        assert len(mem.list()) <= 5

    def test_cleanup_oldest_first(self):
        mem = _memory(max_entries=3, cleanup_policy=MemoryCleanupPolicy.OLDEST_FIRST)
        # Add 5 entries with known timestamps
        for i in range(5):
            mem.add(_entry(memory_id=f"mem_{i:03d}", track_id=f"t{i}",
                           observed_at=float(1000 + i)))
        # After cleanup, oldest should be gone
        ids = mem.list_ids()
        assert len(ids) <= 3

    def test_cleanup_stale_first(self):
        mem = _memory(max_entries=3, cleanup_policy=MemoryCleanupPolicy.STALE_FIRST,
                      stale_after_s=5.0)
        now = 1000.0
        # 2 stale entries (observed long ago)
        for i in range(2):
            e = _entry(memory_id=f"stale_{i}", track_id=f"s{i}", observed_at=900.0)
            import dataclasses
            e = dataclasses.replace(e, lifecycle_state=MemoryLifecycleState.STALE)
            mem._store.add(e)
        # 3 active entries
        for i in range(3):
            mem.add(_entry(memory_id=f"active_{i}", track_id=f"a{i}", observed_at=now))
        # Force cleanup
        mem._store.cleanup(
            policy=MemoryCleanupPolicy.STALE_FIRST,
            max_entries=3,
            max_age_s=None,
            now=now,
        )
        remaining_ids = mem.list_ids()
        assert len(remaining_ids) <= 3
        # Stale entries should have been evicted before active ones
        stale_remaining = [i for i in remaining_ids if i.startswith("stale_")]
        active_remaining = [i for i in remaining_ids if i.startswith("active_")]
        # Active entries should be preserved preferentially
        assert len(active_remaining) >= len(stale_remaining)

    def test_cleanup_lowest_confidence(self):
        mem = _memory(max_entries=2, cleanup_policy=MemoryCleanupPolicy.LOWEST_CONFIDENCE)
        mem.add(_entry(memory_id="high_conf", confidence=0.9, observed_at=1000.0))
        mem.add(_entry(memory_id="low_conf", track_id="t2", confidence=0.1, observed_at=1000.0))
        mem.add(_entry(memory_id="mid_conf", track_id="t3", confidence=0.5, observed_at=1000.0))
        # After capacity enforcement, lowest confidence should be gone
        ids = set(mem.list_ids())
        assert "high_conf" in ids

    def test_deterministic_cleanup_same_result(self):
        """Same store state → same eviction result."""
        def _build():
            store = InMemoryStore()
            for i in range(10):
                e = _entry(memory_id=f"mem_{i:04d}", track_id=f"t{i}",
                           observed_at=float(1000 + i))
                store.add(e)
            return store

        s1 = _build()
        s2 = _build()

        removed1 = s1.cleanup(MemoryCleanupPolicy.OLDEST_FIRST, 5, None, now=2000.0)
        removed2 = s2.cleanup(MemoryCleanupPolicy.OLDEST_FIRST, 5, None, now=2000.0)

        assert removed1 == removed2
        assert sorted(s1.list_ids()) == sorted(s2.list_ids())


# ===========================================================================
# Section 5 — Lifecycle
# ===========================================================================

class TestLifecycle:

    def test_new_entry_state(self):
        e = _entry()
        assert e.lifecycle_state == MemoryLifecycleState.NEW

    def test_update_changes_updated_at(self):
        mem = _memory()
        e = _entry(observed_at=1000.0)
        mem.add(e)
        import dataclasses
        updated = dataclasses.replace(e,
                                      lifecycle_state=MemoryLifecycleState.ACTIVE,
                                      updated_at=1001.0)
        mem.update("mem_test01", updated)
        fetched = mem.get("mem_test01")
        assert fetched.updated_at == pytest.approx(1001.0)

    def test_tick_transitions_to_stale(self):
        mem = _memory(stale_after_s=5.0, max_age_s=None)
        e = _entry(observed_at=1000.0)
        import dataclasses
        e = dataclasses.replace(e, lifecycle_state=MemoryLifecycleState.ACTIVE)
        mem._store.add(e)
        # Tick at t=1100 (100 seconds later → stale)
        transitions = mem.tick(now=1100.0)
        assert transitions["to_stale"] >= 1
        fetched = mem.get("mem_test01")
        assert fetched.lifecycle_state == MemoryLifecycleState.STALE

    def test_tick_transitions_to_expired(self):
        mem = _memory(stale_after_s=5.0, max_age_s=60.0)
        e = _entry(observed_at=1000.0)
        mem._store.add(e)
        transitions = mem.tick(now=1200.0)  # 200s later → expired
        assert transitions["to_expired"] >= 1
        fetched = mem.get("mem_test01")
        assert fetched.lifecycle_state == MemoryLifecycleState.EXPIRED

    def test_cleanup_removes_expired(self):
        mem = _memory(stale_after_s=5.0, max_age_s=60.0)
        e = _entry(observed_at=1000.0)
        mem._store.add(e)
        removed = mem.cleanup(now=1200.0)
        assert removed >= 1
        assert mem.get("mem_test01") is None

    def test_active_entry_not_removed_prematurely(self):
        mem = _memory(stale_after_s=30.0, max_age_s=600.0)
        e = _entry(observed_at=1000.0)
        mem.add(e)
        removed = mem.cleanup(now=1005.0)  # only 5 seconds later
        assert removed == 0
        assert mem.get("mem_test01") is not None


# ===========================================================================
# Section 6 — Serialization
# ===========================================================================

class TestSerialization:

    def test_to_dict_contains_required_keys(self):
        e = _entry()
        d = e.to_dict()
        for key in ("memory_id", "object_type", "confidence", "lifecycle_state",
                    "memory_schema_version", "observed_at", "created_at", "updated_at"):
            assert key in d, f"Missing key: {key}"

    def test_from_dict_round_trip(self):
        e = _entry()
        d = e.to_dict()
        restored = ObjectMemoryEntry.from_dict(d)
        assert restored.memory_id == e.memory_id
        assert restored.object_type == e.object_type
        assert restored.confidence == pytest.approx(e.confidence)
        assert restored.track_id == e.track_id
        assert restored.lifecycle_state == e.lifecycle_state

    def test_to_json_from_json_round_trip(self):
        e = _entry()
        json_str = e.to_json()
        restored = ObjectMemoryEntry.from_json(json_str)
        assert restored.memory_id == e.memory_id
        assert restored.confidence == pytest.approx(e.confidence)

    def test_round_trip_with_position_dimensions_motion(self):
        e = _entry()
        d = e.to_dict()
        restored = ObjectMemoryEntry.from_dict(d)
        assert restored.position is not None
        assert restored.position.x == pytest.approx(10.0)
        assert restored.dimensions is not None
        assert restored.dimensions.length == pytest.approx(4.5)
        assert restored.motion is not None
        assert restored.motion.speed_ms == pytest.approx(8.3)

    def test_invalid_json_raises_value_error(self):
        with pytest.raises(ValueError):
            ObjectMemoryEntry.from_json("not valid json {{")

    def test_wrong_schema_version_raises_value_error(self):
        e = _entry()
        d = e.to_dict()
        d["memory_schema_version"] = 999
        with pytest.raises(ValueError, match="schema_version"):
            ObjectMemoryEntry.from_dict(d)

    def test_missing_memory_id_in_dict_raises(self):
        e = _entry()
        d = e.to_dict()
        del d["memory_id"]
        with pytest.raises(ValueError):
            ObjectMemoryEntry.from_dict(d)

    def test_deterministic_json_output(self):
        """Same entry → identical JSON string (sorted keys)."""
        e = _entry()
        json1 = e.to_json()
        json2 = e.to_json()
        assert json1 == json2


# ===========================================================================
# Section 7 — Offline
# ===========================================================================

class TestOffline:

    def test_memory_works_without_network(self):
        """ObjectMemory must operate fully without any socket / network call."""
        import socket
        original_connect = socket.socket.connect

        def _no_connect(self, *args, **kwargs):
            raise RuntimeError("Network access is forbidden in Object Memory")

        socket.socket.connect = _no_connect  # type: ignore
        try:
            mem = _memory()
            e = _entry()
            mem.add(e)
            assert mem.get("mem_test01") is not None
            mem.update("mem_test01", e)
            mem.exists("mem_test01")
            mem.list()
            mem.cleanup()
            mem.clear()
        finally:
            socket.socket.connect = original_connect  # type: ignore

    def test_no_external_database_dependency(self):
        """InMemoryStore must use only built-in Python data structures."""
        import core.memory.memory_store as ms_mod
        import inspect
        src = inspect.getsource(ms_mod)
        forbidden = ("pymongo", "psycopg", "redis", "sqlite3",
                     "sqlalchemy", "motor", "aioredis")
        for lib in forbidden:
            assert lib not in src, f"Forbidden external database dependency found: {lib}"


# ===========================================================================
# Section 8 — Determinism
# ===========================================================================

class TestDeterminism:

    def test_same_input_same_memory_state(self):
        """Two identically-built stores produce identical list_ids() after cleanup."""
        def _build():
            mem = _memory(max_entries=5, cleanup_policy=MemoryCleanupPolicy.OLDEST_FIRST)
            for i in range(8):
                mem.add(_entry(memory_id=f"mem_{i:04d}", track_id=f"t{i}",
                               observed_at=float(1000 + i)))
            return mem

        m1 = _build()
        m2 = _build()
        assert m1.list_ids() == m2.list_ids()

    def test_cleanup_deterministic(self):
        """Running cleanup twice produces the same result."""
        store = InMemoryStore()
        for i in range(10):
            store.add(_entry(memory_id=f"m{i:04d}", track_id=f"t{i}",
                             observed_at=float(1000 + i)))
        r1 = store.cleanup(MemoryCleanupPolicy.OLDEST_FIRST, 6, None, now=9999.0)
        r2 = store.cleanup(MemoryCleanupPolicy.OLDEST_FIRST, 6, None, now=9999.0)
        # First call removes 4; second call removes 0 (already at capacity)
        assert r1 == 4
        assert r2 == 0


# ===========================================================================
# Section 9 — Thread Safety
# ===========================================================================

class TestThreadSafety:

    def test_concurrent_adds(self):
        mem = _memory(max_entries=10_000)
        errors: List[str] = []

        def _add(idx: int):
            try:
                e = _entry(memory_id=f"mem_{idx:06d}", track_id=f"t{idx}",
                           observed_at=float(1000 + idx))
                mem.add(e)
            except Exception as exc:
                errors.append(str(exc))

        threads = [threading.Thread(target=_add, args=(i,)) for i in range(100)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        assert errors == [], f"Concurrent add errors: {errors}"
        assert len(mem.list()) == 100

    def test_concurrent_reads(self):
        mem = _memory()
        for i in range(20):
            mem.add(_entry(memory_id=f"m{i:03d}", track_id=f"t{i}",
                           observed_at=float(1000 + i)))
        errors: List[str] = []

        def _read():
            try:
                for _ in range(50):
                    _ = mem.list()
            except Exception as exc:
                errors.append(str(exc))

        threads = [threading.Thread(target=_read) for _ in range(8)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()
        assert errors == []


# ===========================================================================
# Section 10 — Performance (actual measurements)
# ===========================================================================

class TestPerformance:

    _N = 1_000  # number of entries for benchmark

    def _populate(self, mem: ObjectMemory) -> List[str]:
        ids = []
        for i in range(self._N):
            mid = f"mem_{i:06d}"
            mem.add(_entry(memory_id=mid, track_id=f"t{i}",
                           observed_at=float(1000 + i)))
            ids.append(mid)
        return ids

    def test_insert_latency(self):
        mem = _memory(max_entries=self._N + 100)
        t0 = time.perf_counter()
        for i in range(self._N):
            mem.add(_entry(memory_id=f"perf_{i:06d}", track_id=f"t{i}",
                           observed_at=float(1000 + i)))
        elapsed = (time.perf_counter() - t0) * 1000
        avg_ms = elapsed / self._N
        # Loose budget: < 1 ms per insert for dict-backed store
        assert avg_ms < 1.0, f"Insert avg={avg_ms:.3f} ms — too slow"

    def test_lookup_latency(self):
        mem = _memory(max_entries=self._N + 100)
        ids = self._populate(mem)
        t0 = time.perf_counter()
        for mid in ids:
            _ = mem.get(mid)
        elapsed = (time.perf_counter() - t0) * 1000
        avg_ms = elapsed / self._N
        assert avg_ms < 1.0, f"Lookup avg={avg_ms:.3f} ms — too slow"

    def test_update_latency(self):
        mem = _memory(max_entries=self._N + 100)
        ids = self._populate(mem)
        import dataclasses
        t0 = time.perf_counter()
        for mid in ids:
            e = mem.get(mid)
            updated = dataclasses.replace(e, confidence=0.77, updated_at=2000.0)
            mem.update(mid, updated)
        elapsed = (time.perf_counter() - t0) * 1000
        avg_ms = elapsed / self._N
        assert avg_ms < 2.0, f"Update avg={avg_ms:.3f} ms — too slow"

    def test_cleanup_latency(self):
        store = InMemoryStore()
        for i in range(self._N):
            store.add(_entry(memory_id=f"cl_{i:06d}", track_id=f"t{i}",
                             observed_at=float(1000 + i)))
        t0 = time.perf_counter()
        store.cleanup(MemoryCleanupPolicy.OLDEST_FIRST, self._N // 2, None, now=9999.0)
        elapsed_ms = (time.perf_counter() - t0) * 1000
        assert elapsed_ms < 100.0, f"Cleanup took {elapsed_ms:.1f} ms — too slow"


# ===========================================================================
# Section 11 — Stats
# ===========================================================================

class TestStats:

    def test_stats_reflect_entries(self):
        mem = _memory()
        for i in range(7):
            mem.add(_entry(memory_id=f"s{i}", track_id=f"t{i}", observed_at=1000.0))
        s = mem.stats()
        assert s.total_entries == 7
        assert s.max_capacity == 100
        assert s.utilization_fraction == pytest.approx(7 / 100)

    def test_stats_empty_store(self):
        mem = _memory()
        s = mem.stats()
        assert s.total_entries == 0
        assert s.utilization_fraction == pytest.approx(0.0)

    def test_stats_to_dict(self):
        mem = _memory()
        mem.add(_entry())
        d = mem.stats().to_dict()
        assert "total_entries" in d
        assert d["total_entries"] == 1


# ===========================================================================
# Section 12 — Disabled memory
# ===========================================================================

class TestDisabledMemory:

    def test_disabled_add_returns_failure(self):
        mem = _memory(enabled=False)
        result = mem.add(_entry())
        assert not result.ok

    def test_disabled_update_returns_failure(self):
        import dataclasses
        mem_on = _memory(enabled=True)
        mem_on.add(_entry())
        mem_off = ObjectMemory(
            store=mem_on._store,
            max_entries=100,
            max_age_s=None,
            enabled=False,
        )
        updated = dataclasses.replace(_entry(), confidence=0.5, updated_at=1001.0)
        result = mem_off.update("mem_test01", updated)
        assert not result.ok

    def test_disabled_clear_still_works(self):
        """clear() must always work so tests can reset state."""
        mem = _memory(enabled=False)
        # Add via store directly to set up state
        mem._store.add(_entry())
        removed = mem.clear()
        assert removed == 1


# ===========================================================================
# Section 13 — Schema version
# ===========================================================================

class TestSchemaVersion:

    def test_schema_version_in_entry(self):
        e = _entry()
        assert e.memory_schema_version == MEMORY_SCHEMA_VERSION
        assert e.to_dict()["memory_schema_version"] == MEMORY_SCHEMA_VERSION

    def test_schema_version_constant(self):
        assert MEMORY_SCHEMA_VERSION == 1

    def test_wrong_schema_version_rejected_on_deserialize(self):
        e = _entry()
        d = e.to_dict()
        d["memory_schema_version"] = 0
        with pytest.raises(ValueError):
            ObjectMemoryEntry.from_dict(d)


# ===========================================================================
# Section 14 — Optional fields are None-safe
# ===========================================================================

class TestOptionalFields:

    def test_entry_without_position(self):
        e = ObjectMemoryEntry(
            memory_id="minimal",
            object_type="PEDESTRIAN",
            confidence=0.6,
            observed_at=1000.0,
            created_at=1000.0,
            updated_at=1000.0,
        )
        assert validate_entry(e).ok
        d = e.to_dict()
        assert d["position"] == "NOT_AVAILABLE"

    def test_entry_without_motion(self):
        e = _entry()
        e.motion = None
        assert validate_entry(e).ok
        d = e.to_dict()
        assert d["motion"] == "NOT_AVAILABLE"

    def test_partial_position_valid(self):
        pos = MemoryPositionSummary(x=5.0, y=None, z=None)
        assert pos.is_valid()

    def test_partial_dimensions_valid(self):
        dim = MemoryDimensions(length=4.0, width=None, height=None)
        assert dim.is_valid()

    def test_appearance_label_stored(self):
        e = _entry()
        e.appearance_label = "dark_coloured_sedan"
        mem = _memory()
        mem.add(e)
        fetched = mem.get("mem_test01")
        assert fetched.appearance_label == "dark_coloured_sedan"
