"""
IndiDrive AI — Phase 8.3 | Scene Feature / Prototype Memory Tests
===================================================================
Run with:  PYTHONPATH=. python tools/mini_pytest.py tests/memory/test_phase83_feature_memory.py -v

Coverage:
  Section 1  — ContextFeature (creation, validation, serialisation)
  Section 2  — RiskFeature (creation, validation, serialisation)
  Section 3  — FeatureNormalizer (normalization, NaN/Inf, missing fields, determinism)
  Section 4  — SituationFeatureVector (distance, similarity, serialisation, usability)
  Section 5  — SceneFeatureMemory core (create, update, routing, capacity)
  Section 6  — Prototype creation cases (empty memory, new, reuse)
  Section 7  — Prototype update stability (EMA, confidence, counts)
  Section 8  — Memory compaction (merging similar prototypes)
  Section 9  — Save / load persistence (round-trip, corrupted, empty, missing)
  Section 10 — Invalid / edge-case input handling
  Section 11 — Determinism
  Section 12 — Integration: previous phases unaffected
  Section 13 — Performance sanity (bounded memory)
"""
from __future__ import annotations

import json
import math
import sys
import tempfile
import time
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))

from core.memory import (
    # Phase 5.2 (regression touchpoints)
    ObjectFeatureSet,
    GeometryFeature,
    MotionFeature,
    MotionClass,
    validate_feature_set,
    PrototypeMemory,
    InMemoryPrototypeStore,
    # Phase 8.3
    ContextFeature,
    RiskFeature,
    RoadTypeClass,
    TrafficDensityClass,
    RoadMarkingClass,
    IntersectionClass,
    RoadDamageClass,
    RiskLevelClass,
    TtcBandClass,
    validate_context_feature,
    validate_risk_feature,
    NORMALIZER_VERSION,
    VECTOR_DIM,
    FEATURE_NAMES,
    SituationFeatureVector,
    FeatureNormalizer,
    NormalizerConfig,
    SCENE_MEMORY_SCHEMA_VERSION,
    ScenePrototype,
    SimilarityMatch,
    SceneMemoryStats,
    SceneFeatureMemory,
)


# ===========================================================================
# Shared test helpers
# ===========================================================================

def _feature(
    object_type: str = "MOTORCYCLE",
    confidence: float = 0.9,
    length: float = 2.0,
    width: float = 0.8,
    height: float = 1.2,
    speed: float = 9.0,
    heading: float = 0.1,
    motion_class: MotionClass = MotionClass.NORMAL,
) -> ObjectFeatureSet:
    return ObjectFeatureSet(
        object_type=object_type,
        confidence=confidence,
        geometry=GeometryFeature.derive(length, width, height),
        motion=MotionFeature(
            typical_speed_ms=speed,
            heading_rad=heading,
            acceleration_tendency_ms2=0.1,
            motion_class=motion_class,
        ),
    )


def _context(
    road_type: RoadTypeClass = RoadTypeClass.LOCAL,
    traffic: TrafficDensityClass = TrafficDensityClass.MODERATE,
    road_width: float = 7.0,
    obj_count: int = 5,
) -> ContextFeature:
    return ContextFeature(
        road_type=road_type,
        traffic_density=traffic,
        road_marking=RoadMarkingClass.FADED,
        intersection_context=IntersectionClass.STRAIGHT,
        road_damage=RoadDamageClass.NONE,
        road_width_m=road_width,
        object_count=obj_count,
        mixed_traffic=True,
        animal_present=False,
        context_confidence=0.85,
    )


def _risk(
    overall: RiskLevelClass = RiskLevelClass.MEDIUM,
    object_risk: RiskLevelClass = RiskLevelClass.LOW,
    ttc_band: TtcBandClass = TtcBandClass.FAR,
    ttc_s: float = 8.0,
    distance_m: float = 30.0,
) -> RiskFeature:
    return RiskFeature(
        overall_risk=overall,
        object_risk=object_risk,
        ttc_band=ttc_band,
        ttc_s=ttc_s,
        distance_m=distance_m,
        closing_speed_ms=2.5,
        collision_likelihood=0.1,
        collision_threat_present=False,
        risk_confidence=0.8,
    )


def _sfm(
    max_prototypes: int = 50,
    similarity_threshold: float = 0.85,
    update_alpha: float = 0.1,
    minimum_confidence: float = 0.0,
    object_type_strict: bool = True,
) -> SceneFeatureMemory:
    return SceneFeatureMemory(
        max_prototypes=max_prototypes,
        similarity_threshold=similarity_threshold,
        update_alpha=update_alpha,
        minimum_confidence=minimum_confidence,
        object_type_strict=object_type_strict,
    )


# ===========================================================================
# Section 1 — ContextFeature
# ===========================================================================

class TestContextFeature:

    def test_creation_defaults(self):
        ctx = ContextFeature()
        assert ctx.road_type == RoadTypeClass.UNKNOWN
        assert ctx.traffic_density == TrafficDensityClass.UNKNOWN
        assert ctx.road_width_m is None
        assert ctx.object_count is None
        assert ctx.animal_present is False
        assert ctx.context_confidence == 0.0

    def test_creation_explicit(self):
        ctx = _context()
        assert ctx.road_type == RoadTypeClass.LOCAL
        assert ctx.road_width_m == pytest.approx(7.0)
        assert ctx.mixed_traffic is True

    def test_is_valid_ok(self):
        assert _context().is_valid()

    def test_is_valid_nan_confidence(self):
        ctx = _context()
        ctx.context_confidence = float("nan")
        assert not ctx.is_valid()

    def test_is_valid_inf_confidence(self):
        ctx = _context()
        ctx.context_confidence = float("inf")
        assert not ctx.is_valid()

    def test_is_valid_negative_road_width(self):
        ctx = _context()
        ctx.road_width_m = -1.0
        assert not ctx.is_valid()

    def test_is_valid_negative_count(self):
        ctx = _context()
        ctx.object_count = -3
        assert not ctx.is_valid()

    def test_to_dict_round_trip(self):
        ctx = _context(road_width=8.5, obj_count=12)
        d = ctx.to_dict()
        ctx2 = ContextFeature.from_dict(d)
        assert ctx2.road_type == ctx.road_type
        assert ctx2.road_width_m == pytest.approx(ctx.road_width_m)
        assert ctx2.object_count == ctx.object_count
        assert ctx2.mixed_traffic == ctx.mixed_traffic

    def test_from_dict_unknown_enum(self):
        d = _context().to_dict()
        d["road_type"] = "NONEXISTENT_TYPE"
        ctx = ContextFeature.from_dict(d)
        assert ctx.road_type == RoadTypeClass.UNKNOWN

    def test_validate_context_feature_pass(self):
        ok, reason = validate_context_feature(_context())
        assert ok
        assert reason == ""

    def test_validate_context_feature_fail_nan(self):
        ctx = _context()
        ctx.context_confidence = float("nan")
        ok, reason = validate_context_feature(ctx)
        assert not ok
        assert reason != ""

    def test_validate_wrong_type(self):
        ok, reason = validate_context_feature("not a context")
        assert not ok


# ===========================================================================
# Section 2 — RiskFeature
# ===========================================================================

class TestRiskFeature:

    def test_creation_defaults(self):
        r = RiskFeature()
        assert r.overall_risk == RiskLevelClass.UNKNOWN
        assert r.ttc_s is None
        assert r.collision_likelihood is None
        assert r.risk_confidence == 0.0

    def test_creation_explicit(self):
        r = _risk(ttc_s=3.5, distance_m=20.0)
        assert r.ttc_s == pytest.approx(3.5)
        assert r.distance_m == pytest.approx(20.0)

    def test_is_valid_ok(self):
        assert _risk().is_valid()

    def test_is_valid_nan_ttc(self):
        r = _risk()
        r.ttc_s = float("nan")
        assert not r.is_valid()

    def test_is_valid_inf_distance(self):
        r = _risk()
        r.distance_m = float("inf")
        assert not r.is_valid()

    def test_is_valid_negative_hazard_count(self):
        r = _risk()
        r.critical_hazard_count = -1
        assert not r.is_valid()

    def test_is_valid_out_of_range_likelihood(self):
        r = _risk()
        r.collision_likelihood = 1.5
        assert not r.is_valid()

    def test_to_dict_round_trip(self):
        r = _risk(ttc_s=4.0, distance_m=25.0)
        r2 = RiskFeature.from_dict(r.to_dict())
        assert r2.ttc_s == pytest.approx(r.ttc_s)
        assert r2.distance_m == pytest.approx(r.distance_m)
        assert r2.overall_risk == r.overall_risk
        assert r2.collision_likelihood == pytest.approx(r.collision_likelihood)

    def test_validate_risk_feature_pass(self):
        ok, reason = validate_risk_feature(_risk())
        assert ok

    def test_validate_risk_feature_fail(self):
        r = _risk()
        r.risk_confidence = float("nan")
        ok, reason = validate_risk_feature(r)
        assert not ok

    def test_validate_wrong_type(self):
        ok, reason = validate_risk_feature(42)
        assert not ok


# ===========================================================================
# Section 3 — FeatureNormalizer
# ===========================================================================

class TestFeatureNormalizer:

    def test_vector_dim(self):
        """Normalized vector always has VECTOR_DIM slots."""
        norm = FeatureNormalizer()
        fvec = norm.normalize(_feature(), _context(), _risk())
        assert len(fvec.values) == VECTOR_DIM

    def test_all_values_in_unit_range(self):
        """All non-None values must be in [0.0, 1.0]."""
        norm = FeatureNormalizer()
        fvec = norm.normalize(_feature(), _context(), _risk())
        for v in fvec.values:
            if v is not None:
                assert 0.0 <= v <= 1.0, f"Value {v} out of [0,1]"

    def test_no_feature_set(self):
        """Without feature_set, geometry/motion slots are None."""
        norm = FeatureNormalizer()
        fvec = norm.normalize(None, _context(), _risk())
        # Slots 0-7 are geometry + motion → all None
        for i in range(8):
            assert fvec.values[i] is None, f"Index {i} should be None without feature_set"
        # Slots 8+ (context/risk) should have values
        assert any(v is not None for v in fvec.values[8:])

    def test_no_context(self):
        """Without context, context slots are None."""
        norm = FeatureNormalizer()
        fvec = norm.normalize(_feature(), None, _risk())
        # Context slots 8-16 → all None
        for i in range(8, 17):
            assert fvec.values[i] is None, f"Slot {i} (context) should be None"

    def test_no_risk(self):
        """Without risk, risk slots are None."""
        norm = FeatureNormalizer()
        fvec = norm.normalize(_feature(), _context(), None)
        # Risk slots 17-22 → all None
        for i in range(17, 23):
            assert fvec.values[i] is None

    def test_nan_geometry_treated_as_missing(self):
        """NaN in geometry fields → that slot is None in output."""
        fs = _feature()
        fs.geometry.length = float("nan")
        norm = FeatureNormalizer()
        fvec = norm.normalize(fs, None, None)
        assert fvec.values[0] is None  # slot 0 = geo.length

    def test_inf_speed_treated_as_missing(self):
        fs = _feature()
        fs.motion.typical_speed_ms = float("inf")
        norm = FeatureNormalizer()
        fvec = norm.normalize(fs, None, None)
        assert fvec.values[4] is None  # slot 4 = mot.speed

    def test_determinism(self):
        """Same inputs → exactly same output."""
        norm = FeatureNormalizer()
        fs, ctx, risk = _feature(), _context(), _risk()
        v1 = norm.normalize(fs, ctx, risk)
        v2 = norm.normalize(fs, ctx, risk)
        assert v1.values == v2.values

    def test_speed_clamped_at_max(self):
        """Speed beyond max_speed_ms clamps to 1.0."""
        cfg = NormalizerConfig(max_speed_ms=20.0)
        norm = FeatureNormalizer(config=cfg)
        fs = _feature(speed=40.0)  # 2× max
        fvec = norm.normalize(fs, None, None)
        assert fvec.values[4] == pytest.approx(1.0)

    def test_heading_circular(self):
        """Heading normalises to [0, 1] without NaN."""
        norm = FeatureNormalizer()
        # Test various headings
        for heading in [-math.pi, 0.0, math.pi / 2, math.pi, 2 * math.pi]:
            fs = _feature(heading=heading)
            fvec = norm.normalize(fs, None, None)
            h_val = fvec.values[5]  # slot 5 = mot.heading
            if h_val is not None:
                assert 0.0 <= h_val <= 1.0

    def test_none_all_groups(self):
        """All three groups None → almost all slots are None."""
        norm = FeatureNormalizer()
        fvec = norm.normalize(None, None, None)
        assert all(v is None for v in fvec.values)

    def test_available_count_consistent(self):
        """available_count matches actual non-None slots."""
        norm = FeatureNormalizer()
        fvec = norm.normalize(_feature(), _context(), _risk())
        actual = sum(1 for v in fvec.values if v is not None)
        assert fvec.available_count == actual

    def test_feature_names_count(self):
        assert len(FEATURE_NAMES) == VECTOR_DIM


# ===========================================================================
# Section 4 — SituationFeatureVector
# ===========================================================================

class TestSituationFeatureVector:

    def _full_vec(self, val=0.5):
        return SituationFeatureVector(values=[val] * VECTOR_DIM)

    def test_identical_distance_zero(self):
        v = self._full_vec(0.5)
        assert v.distance_to(v) == pytest.approx(0.0)

    def test_max_distance(self):
        v0 = self._full_vec(0.0)
        v1 = self._full_vec(1.0)
        d = v0.distance_to(v1)
        assert d == pytest.approx(1.0, abs=1e-6)

    def test_similarity_is_complement(self):
        v0 = self._full_vec(0.0)
        v1 = self._full_vec(1.0)
        assert v0.similarity_to(v1) == pytest.approx(0.0, abs=1e-6)
        assert self._full_vec(0.5).similarity_to(self._full_vec(0.5)) == pytest.approx(1.0)

    def test_partial_none_distance(self):
        """Positions where both are None are skipped."""
        v1 = SituationFeatureVector(values=[0.0] * VECTOR_DIM)
        v2 = SituationFeatureVector(values=[None] * VECTOR_DIM)
        # v1 has values, v2 is all-None → no mutually available positions
        d = v1.distance_to(v2)
        assert d == pytest.approx(1.0)

    def test_partial_mixed_distance(self):
        """Only shared non-None slots count."""
        vals_a = [0.0, 1.0] + [None] * (VECTOR_DIM - 2)
        vals_b = [1.0, 1.0] + [None] * (VECTOR_DIM - 2)
        va = SituationFeatureVector(values=vals_a)
        vb = SituationFeatureVector(values=vals_b)
        d = va.distance_to(vb)
        # Only first two slots match: diffs = [1.0, 0.0], RMSE = sqrt(0.5)
        assert 0.0 < d < 1.0

    def test_is_usable_enough_slots(self):
        v = self._full_vec(0.5)
        assert v.is_usable()

    def test_is_usable_too_few_slots(self):
        vals = [0.5, 0.5] + [None] * (VECTOR_DIM - 2)
        v = SituationFeatureVector(values=vals)
        assert not v.is_usable()

    def test_serialisation_round_trip(self):
        norm = FeatureNormalizer()
        fvec = norm.normalize(_feature(), _context(), _risk())
        d = fvec.to_dict()
        fvec2 = SituationFeatureVector.from_dict(d)
        assert fvec2.normalizer_version == fvec.normalizer_version
        assert fvec2.available_count == fvec.available_count
        for a, b in zip(fvec.values, fvec2.values):
            if a is None:
                assert b is None
            else:
                assert b == pytest.approx(a, abs=1e-6)

    def test_from_dict_nan_treated_as_none(self):
        d = {"values": [float("nan")] * VECTOR_DIM, "normalizer_version": 1}
        v = SituationFeatureVector.from_dict(d)
        assert all(val is None for val in v.values)

    def test_from_dict_wrong_length_padded(self):
        d = {"values": [0.5] * 5, "normalizer_version": 1}
        v = SituationFeatureVector.from_dict(d)
        assert len(v.values) == VECTOR_DIM


# ===========================================================================
# Section 5 — SceneFeatureMemory core
# ===========================================================================

class TestSceneFeatureMemoryCore:

    def test_initialises_empty(self):
        sfm = _sfm()
        assert sfm.prototype_count == 0

    def test_properties(self):
        sfm = _sfm(max_prototypes=100, similarity_threshold=0.75)
        assert sfm.max_prototypes == 100
        assert sfm.similarity_threshold == pytest.approx(0.75)

    def test_clear(self):
        sfm = _sfm()
        sfm.add_observation(_feature(), _context(), _risk())
        assert sfm.prototype_count == 1
        n = sfm.clear()
        assert n == 1
        assert sfm.prototype_count == 0

    def test_list_prototypes_empty(self):
        sfm = _sfm()
        assert sfm.list_prototypes() == []

    def test_stats_empty(self):
        sfm = _sfm()
        s = sfm.stats()
        assert s.total_prototypes == 0
        assert s.total_observations == 0

    def test_remove_nonexistent(self):
        sfm = _sfm()
        result = sfm.remove_prototype("SP-99999")
        assert not result.ok

    def test_get_prototype_nonexistent(self):
        sfm = _sfm()
        assert sfm.get_prototype("SP-00001") is None

    def test_add_observation_returns_success(self):
        sfm = _sfm()
        result = sfm.add_observation(_feature(), _context(), _risk())
        assert result.ok

    def test_add_observation_increments_count(self):
        sfm = _sfm()
        sfm.add_observation(_feature(), _context(), _risk())
        assert sfm.prototype_count == 1


# ===========================================================================
# Section 6 — Prototype creation / routing
# ===========================================================================

class TestPrototypeRouting:

    def test_case_a_empty_memory_creates_prototype(self):
        """CASE A: Empty memory + new observation → create prototype."""
        sfm = _sfm(similarity_threshold=0.85)
        sfm.add_observation(_feature(), _context(), _risk())
        assert sfm.prototype_count == 1

    def test_case_b_very_similar_updates_prototype(self):
        """CASE B: Very similar observation → update existing prototype."""
        sfm = _sfm(similarity_threshold=0.70)
        sfm.add_observation(_feature(speed=9.0), _context(), _risk())
        # Very similar: same type, tiny speed difference
        sfm.add_observation(_feature(speed=9.1), _context(), _risk())
        assert sfm.prototype_count == 1

    def test_case_c_different_creates_new_prototype(self):
        """CASE C: Clearly different object type → creates new prototype."""
        sfm = _sfm(similarity_threshold=0.70, object_type_strict=True)
        sfm.add_observation(_feature(object_type="MOTORCYCLE"), _context(), _risk())
        sfm.add_observation(_feature(object_type="BUS", length=12.0, width=2.5, speed=0.5), _context(), _risk())
        assert sfm.prototype_count == 2

    def test_case_d_repeated_observations_bounded_growth(self):
        """CASE D: Many similar observations → prototype count stays small."""
        sfm = _sfm(similarity_threshold=0.70, max_prototypes=50)
        for i in range(20):
            # Minor speed variation around a similar motorcycle
            sfm.add_observation(
                _feature(speed=9.0 + i * 0.05),
                _context(),
                _risk(),
            )
        # Should have far fewer than 20 prototypes
        assert sfm.prototype_count < 20

    def test_observation_count_incremented_on_update(self):
        """Prototype's observation_count increases with each matched observation."""
        sfm = _sfm(similarity_threshold=0.60)
        sfm.add_observation(_feature(speed=9.0), _context(), _risk())
        sfm.add_observation(_feature(speed=9.05), _context(), _risk())
        protos = sfm.list_prototypes()
        total_obs = sum(p.observation_count for p in protos)
        assert total_obs == 2

    def test_different_motion_class_same_type(self):
        """Different motion classes within same type may create separate prototypes."""
        sfm = _sfm(similarity_threshold=0.90)
        # Stationary motorcycle vs fast approaching motorcycle
        sfm.add_observation(
            _feature(speed=0.0, motion_class=MotionClass.STATIONARY),
            _context(),
            _risk(overall=RiskLevelClass.LOW),
        )
        sfm.add_observation(
            _feature(speed=25.0, motion_class=MotionClass.FAST),
            _context(),
            _risk(overall=RiskLevelClass.HIGH, ttc_band=TtcBandClass.NEAR),
        )
        # With high threshold, these very different observations should produce 2 prototypes
        assert sfm.prototype_count == 2

    def test_object_type_strict_prevents_cross_type_match(self):
        """With strict mode, a car obs must not update a motorcycle proto."""
        sfm = _sfm(similarity_threshold=0.50, object_type_strict=True)
        sfm.add_observation(_feature(object_type="CAR", length=4.5, width=1.8, speed=8.0), _context(), _risk())
        sfm.add_observation(_feature(object_type="MOTORCYCLE", length=2.0, width=0.8, speed=9.0), _context(), _risk())
        assert sfm.prototype_count == 2

    def test_non_strict_allows_cross_type_if_similar(self):
        """Without strict mode, very similar feature vectors may update cross-type."""
        sfm = _sfm(similarity_threshold=0.50, object_type_strict=False)
        # Two objects with nearly identical normalised features
        sfm.add_observation(_feature(object_type="CAR", length=2.0, width=0.8, speed=9.0), _context(), _risk())
        # Could merge with the above when non-strict
        sfm.add_observation(_feature(object_type="MOTORCYCLE", length=2.0, width=0.8, speed=9.0), _context(), _risk())
        # Count may be 1 (merged) or 2 depending on threshold — just verify no crash
        assert sfm.prototype_count >= 1


# ===========================================================================
# Section 7 — Prototype update stability
# ===========================================================================

class TestPrototypeUpdateStability:

    def test_ema_alpha_effect_small(self):
        """Very small alpha → prototype changes slowly."""
        sfm = _sfm(similarity_threshold=0.60, update_alpha=0.01)
        sfm.add_observation(_feature(speed=10.0), _context(), _risk())
        proto_before = sfm.list_prototypes()[0].representative.values[4]
        sfm.add_observation(_feature(speed=0.0), _context(), _risk())  # very different speed
        # With alpha=0.01 the prototype barely shifts
        # (but the second obs may create a new prototype if similarity is low)
        # Just verify no crash and counts
        assert sfm.prototype_count >= 1

    def test_confidence_running_mean(self):
        """Confidence converges toward average of observations."""
        sfm = _sfm(similarity_threshold=0.60, update_alpha=0.1)
        sfm.add_observation(_feature(confidence=1.0, speed=9.0), _context(), _risk())
        sfm.add_observation(_feature(confidence=0.0, speed=9.05), _context(), _risk())
        if sfm.prototype_count == 1:
            proto = sfm.list_prototypes()[0]
            # Confidence should be between 0 and 1
            assert 0.0 <= proto.confidence <= 1.0

    def test_observation_count_increments(self):
        sfm = _sfm(similarity_threshold=0.60, update_alpha=0.1)
        for _ in range(5):
            sfm.add_observation(_feature(speed=9.0 + _ * 0.01), _context(), _risk())
        protos = sfm.list_prototypes()
        max_count = max(p.observation_count for p in protos)
        assert max_count >= 1
        total = sum(p.observation_count for p in protos)
        assert total == 5

    def test_updated_at_advances(self):
        """updated_at should advance after each update."""
        sfm = _sfm(similarity_threshold=0.60)
        t1 = time.time()
        sfm.add_observation(_feature(speed=9.0), _context(), _risk(), observed_at=t1)
        t2 = t1 + 1.0
        sfm.add_observation(_feature(speed=9.05), _context(), _risk(), observed_at=t2)
        if sfm.prototype_count == 1:
            proto = sfm.list_prototypes()[0]
            assert proto.updated_at >= t1

    def test_ema_stays_in_unit_range(self):
        """EMA result must always stay in [0.0, 1.0] per slot."""
        sfm = _sfm(similarity_threshold=0.60, update_alpha=0.5)
        for i in range(10):
            speed = 0.0 if i % 2 == 0 else 40.0
            sfm.add_observation(_feature(speed=speed), _context(), _risk())
        for proto in sfm.list_prototypes():
            for v in proto.representative.values:
                if v is not None:
                    assert 0.0 <= v <= 1.0, f"EMA value {v} out of range"


# ===========================================================================
# Section 8 — Memory compaction
# ===========================================================================

class TestMemoryCompaction:

    def test_merge_two_identical_prototypes(self):
        """Manually merging two prototypes decreases count by 1."""
        sfm = _sfm(similarity_threshold=0.99)  # very high → always creates new
        sfm.add_observation(_feature(speed=9.0), _context(), _risk())
        sfm.add_observation(_feature(speed=9.0, object_type="MOTORCYCLE"), _context(), _risk())
        # May have 1 or 2 depending on threshold; skip if only 1
        if sfm.prototype_count >= 2:
            keys = [p.prototype_id for p in sfm.list_prototypes()]
            before = sfm.prototype_count
            result = sfm.merge_prototypes(keys[0], keys[1])
            assert result.ok
            assert sfm.prototype_count == before - 1

    def test_merge_nonexistent_fails(self):
        sfm = _sfm()
        sfm.add_observation(_feature(), _context(), _risk())
        keys = [p.prototype_id for p in sfm.list_prototypes()]
        result = sfm.merge_prototypes(keys[0], "SP-99999")
        assert not result.ok

    def test_merge_self_fails(self):
        sfm = _sfm()
        sfm.add_observation(_feature(), _context(), _risk())
        key = sfm.list_prototypes()[0].prototype_id
        result = sfm.merge_prototypes(key, key)
        assert not result.ok

    def test_merge_preserves_total_observations(self):
        """After merge, total observation_count = sum of both."""
        sfm = _sfm(similarity_threshold=0.99, update_alpha=0.1)
        sfm.add_observation(_feature(speed=9.0), _context(), _risk())
        sfm.add_observation(_feature(speed=9.0, object_type="MOTORCYCLE"), _context(), _risk())
        if sfm.prototype_count == 2:
            before_obs = sum(p.observation_count for p in sfm.list_prototypes())
            keys = [p.prototype_id for p in sfm.list_prototypes()]
            sfm.merge_prototypes(keys[0], keys[1])
            after_obs = sum(p.observation_count for p in sfm.list_prototypes())
            assert after_obs == before_obs

    def test_compact_memory_removes_near_duplicates(self):
        """compact_memory() with low threshold merges similar prototypes."""
        sfm = _sfm(similarity_threshold=0.99)  # high threshold → creates many
        # Inject many nearly identical observations
        for i in range(5):
            sfm.add_observation(
                _feature(speed=9.0 + i * 0.001),
                _context(),
                _risk(),
            )
        before = sfm.prototype_count
        removed = sfm.compact_memory(max_merge_similarity=0.50)  # very low → merge aggressively
        assert sfm.prototype_count <= before
        assert removed >= 0

    def test_compact_memory_does_not_cross_types(self):
        """compact_memory() never merges prototypes of different object_types."""
        sfm = _sfm(similarity_threshold=0.99, object_type_strict=True)
        sfm.add_observation(_feature(object_type="CAR", length=4.5, width=1.8, speed=5.0), _context(), _risk())
        sfm.add_observation(_feature(object_type="MOTORCYCLE", length=2.0, width=0.8, speed=9.0), _context(), _risk())
        sfm.compact_memory(max_merge_similarity=0.0)  # merge everything possible
        # Must still have at least 2 (one per type) if both types were created
        assert sfm.prototype_count >= 1
        types_in_memory = {p.object_type for p in sfm.list_prototypes()}
        # Both types still distinct
        for p in sfm.list_prototypes():
            assert p.object_type in ("CAR", "MOTORCYCLE")


# ===========================================================================
# Section 9 — Save / Load persistence
# ===========================================================================

class TestPersistence:

    def _populated_sfm(self, n=5) -> SceneFeatureMemory:
        sfm = _sfm(similarity_threshold=0.99)
        for i in range(n):
            sfm.add_observation(
                _feature(speed=float(i + 1) * 3.0),
                _context(obj_count=i + 1),
                _risk(ttc_s=float(i + 1) * 1.5),
            )
        return sfm

    def test_save_creates_file(self):
        sfm = self._populated_sfm(3)
        with tempfile.TemporaryDirectory() as tmpdir:
            path = f"{tmpdir}/memory.json"
            result = sfm.save(path)
            assert result.ok
            assert Path(path).exists()

    def test_save_file_is_valid_json(self):
        sfm = self._populated_sfm(2)
        with tempfile.TemporaryDirectory() as tmpdir:
            path = f"{tmpdir}/memory.json"
            sfm.save(path)
            with open(path) as f:
                data = json.load(f)
            assert "prototypes" in data
            assert "schema_version" in data
            assert data["schema_version"] == SCENE_MEMORY_SCHEMA_VERSION

    def test_case_f_save_load_equivalent_state(self):
        """CASE F: Save → Load → equivalent memory state."""
        sfm = self._populated_sfm(4)
        before_count = sfm.prototype_count
        before_types = {p.object_type for p in sfm.list_prototypes()}

        with tempfile.TemporaryDirectory() as tmpdir:
            path = f"{tmpdir}/memory.json"
            sfm.save(path)

            sfm2 = _sfm()
            result = sfm2.load(path)
            assert result.ok
            assert sfm2.prototype_count == before_count
            after_types = {p.object_type for p in sfm2.list_prototypes()}
            assert after_types == before_types

    def test_load_restores_prototype_vectors(self):
        """Loaded vectors should match saved ones."""
        sfm = self._populated_sfm(2)
        orig = {p.prototype_id: p.representative.values[:] for p in sfm.list_prototypes()}

        with tempfile.TemporaryDirectory() as tmpdir:
            path = f"{tmpdir}/memory.json"
            sfm.save(path)
            sfm2 = _sfm()
            sfm2.load(path)
            for proto in sfm2.list_prototypes():
                pid = proto.prototype_id
                assert pid in orig
                for a, b in zip(orig[pid], proto.representative.values):
                    if a is None:
                        assert b is None
                    else:
                        assert b == pytest.approx(a, abs=1e-6)

    def test_load_file_not_found(self):
        sfm = _sfm()
        result = sfm.load("/nonexistent/path/memory.json")
        assert not result.ok
        assert "not found" in result.reason.lower()

    def test_load_empty_file(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            path = f"{tmpdir}/empty.json"
            Path(path).write_text("")
            sfm = _sfm()
            result = sfm.load(path)
            assert not result.ok

    def test_load_corrupted_json(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            path = f"{tmpdir}/bad.json"
            Path(path).write_text("{{{not valid json}}}")
            sfm = _sfm()
            result = sfm.load(path)
            assert not result.ok
            # Memory should still be in a clean state
            assert sfm.prototype_count == 0

    def test_load_wrong_schema_version(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            path = f"{tmpdir}/wrongver.json"
            payload = {"schema_version": 999, "prototypes": []}
            Path(path).write_text(json.dumps(payload))
            sfm = _sfm()
            result = sfm.load(path)
            assert not result.ok

    def test_load_with_malformed_prototype_skips_it(self):
        """A single malformed prototype entry is skipped, not abort."""
        with tempfile.TemporaryDirectory() as tmpdir:
            path = f"{tmpdir}/mixed.json"
            payload = {
                "schema_version": SCENE_MEMORY_SCHEMA_VERSION,
                "normalizer_version": NORMALIZER_VERSION,
                "saved_at": time.time(),
                "prototype_count": 2,
                "prototypes": [
                    {"schema_version": SCENE_MEMORY_SCHEMA_VERSION,
                     "prototype_id": "SP-00001",
                     "object_type": "CAR",
                     "representative": {"values": [0.5] * VECTOR_DIM, "normalizer_version": 1},
                     "confidence": 0.7,
                     "observation_count": 3,
                     "created_at": time.time(),
                     "updated_at": time.time()},
                    {"schema_version": SCENE_MEMORY_SCHEMA_VERSION,
                     "prototype_id": "",  # invalid — empty ID
                     "object_type": "MALFORMED"},
                ],
            }
            Path(path).write_text(json.dumps(payload))
            sfm = _sfm()
            result = sfm.load(path)
            # Loads at least 1 good prototype, reports error
            assert sfm.prototype_count >= 1

    def test_save_to_new_directory(self):
        """Save creates intermediate directories if needed."""
        sfm = self._populated_sfm(1)
        with tempfile.TemporaryDirectory() as tmpdir:
            path = f"{tmpdir}/deep/nested/memory.json"
            result = sfm.save(path)
            assert result.ok
            assert Path(path).exists()

    def test_save_load_id_counter_advances(self):
        """After loading, new observations get IDs beyond the loaded ones."""
        sfm = self._populated_sfm(3)
        with tempfile.TemporaryDirectory() as tmpdir:
            path = f"{tmpdir}/memory.json"
            sfm.save(path)
            sfm2 = _sfm(similarity_threshold=0.99)
            sfm2.load(path)
            sfm2.add_observation(_feature(speed=99.0), _context(), _risk())
            new_proto = sfm2.list_prototypes()[-1]
            # New ID should not collide with loaded ones
            loaded_ids = {p.prototype_id for p in sfm2.list_prototypes()}
            assert len(loaded_ids) == sfm2.prototype_count


# ===========================================================================
# Section 10 — Invalid / edge-case input
# ===========================================================================

class TestEdgeCases:

    def test_case_e_nan_feature_rejected(self):
        """CASE E: NaN in feature_set → safely handled (failure returned)."""
        sfm = _sfm()
        fs = _feature()
        fs.geometry.length = float("nan")
        # validate_feature_set catches NaN
        result = sfm.add_observation(fs, _context(), _risk())
        # Either rejected outright or gracefully handled; no crash
        assert isinstance(result.ok, bool)

    def test_invalid_object_type_rejected(self):
        from core.perception.perception_types import NOT_AVAILABLE
        sfm = _sfm()
        fs = _feature()
        fs.object_type = NOT_AVAILABLE
        result = sfm.add_observation(fs, _context(), _risk())
        assert not result.ok

    def test_confidence_below_minimum_rejected(self):
        sfm = _sfm(minimum_confidence=0.5)
        result = sfm.add_observation(_feature(confidence=0.3), _context(), _risk())
        assert not result.ok

    def test_invalid_context_degrades_gracefully(self):
        """Invalid context is ignored, observation still processes."""
        sfm = _sfm()
        bad_ctx = ContextFeature()
        bad_ctx.context_confidence = float("nan")
        # Should not crash — context is dropped, feature_set still processed
        result = sfm.add_observation(_feature(), bad_ctx, _risk())
        # May succeed (context dropped) or fail (if vector unusable without context)
        assert isinstance(result.ok, bool)

    def test_none_context_none_risk_allowed(self):
        """Feature_set alone (without context/risk) is valid if vector is usable."""
        sfm = _sfm()
        result = sfm.add_observation(_feature(), None, None)
        assert isinstance(result.ok, bool)  # no crash

    def test_zero_prototypes_find_similar_empty(self):
        sfm = _sfm()
        norm = FeatureNormalizer()
        fvec = norm.normalize(_feature(), _context(), _risk())
        results = sfm.find_similar(fvec, top_k=5)
        assert results == []

    def test_get_nearest_prototype_empty_memory(self):
        sfm = _sfm()
        norm = FeatureNormalizer()
        fvec = norm.normalize(_feature(), _context(), _risk())
        match = sfm.get_nearest_prototype(fvec)
        assert match is None

    def test_capacity_bounded(self):
        """Memory never exceeds max_prototypes even with many diverse observations."""
        sfm = _sfm(max_prototypes=5, similarity_threshold=0.99)
        for i in range(20):
            sfm.add_observation(
                _feature(object_type=f"TYPE{i}", speed=float(i)),
                _context(),
                _risk(),
            )
        assert sfm.prototype_count <= 5

    def test_vector_too_few_available_features(self):
        """Observations producing near-empty vectors are rejected."""
        sfm = _sfm()
        # feature_set with no geometry and no motion → vector almost all None
        fs = ObjectFeatureSet(object_type="CAR", confidence=0.9)
        result = sfm.add_observation(fs, None, None)
        # Should fail (< 3 available slots) or succeed — just must not crash
        assert isinstance(result.ok, bool)

    def test_empty_memory_stats(self):
        sfm = _sfm()
        s = sfm.stats()
        assert s.total_prototypes == 0
        assert s.total_observations == 0
        assert s.avg_confidence == 0.0


# ===========================================================================
# Section 11 — Determinism
# ===========================================================================

class TestDeterminism:

    def test_same_input_same_prototype_id(self):
        """Given the same observations in the same order, the same prototype
        should be created (or updated) deterministically."""
        def run():
            sfm = _sfm(similarity_threshold=0.60)
            sfm.add_observation(_feature(speed=9.0), _context(), _risk())
            sfm.add_observation(_feature(speed=9.1), _context(), _risk())
            protos = sfm.list_prototypes()
            return [(p.prototype_id, p.observation_count) for p in protos]

        r1 = run()
        r2 = run()
        assert r1 == r2

    def test_normalizer_determinism(self):
        """FeatureNormalizer is stateless — same inputs → same output."""
        norm = FeatureNormalizer()
        fs, ctx, risk = _feature(), _context(), _risk()
        v1 = norm.normalize(fs, ctx, risk)
        v2 = norm.normalize(fs, ctx, risk)
        assert v1.values == v2.values

    def test_distance_deterministic(self):
        norm = FeatureNormalizer()
        v1 = norm.normalize(_feature(speed=9.0), _context(), _risk())
        v2 = norm.normalize(_feature(speed=5.0), _context(), _risk())
        d1 = v1.distance_to(v2)
        d2 = v1.distance_to(v2)
        assert d1 == d2

    def test_find_similar_order_deterministic(self):
        """find_similar returns the same ordered list on repeated calls."""
        sfm = _sfm(similarity_threshold=0.99)
        for i in range(5):
            sfm.add_observation(_feature(speed=float(i) * 2.0), _context(), _risk())
        norm = FeatureNormalizer()
        query = norm.normalize(_feature(speed=5.0), _context(), _risk())
        r1 = [m.prototype_id for m in sfm.find_similar(query, top_k=5)]
        r2 = [m.prototype_id for m in sfm.find_similar(query, top_k=5)]
        assert r1 == r2


# ===========================================================================
# Section 12 — Integration: previous phases unaffected
# ===========================================================================

class TestPreviousPhasesUnaffected:

    def test_phase52_prototype_memory_still_works(self):
        """Phase 5.2 PrototypeMemory is completely unmodified and functional."""
        from core.memory import (
            PrototypeMemory, InMemoryPrototypeStore, MemoryCleanupPolicy,
            ObjectFeatureSet, GeometryFeature, MotionFeature, MotionClass,
            DEFAULT_MAX_DESCRIPTOR_DIM, validate_feature_set,
        )
        pm = PrototypeMemory(
            store=InMemoryPrototypeStore(),
            max_prototypes=100,
            max_feature_dimension=DEFAULT_MAX_DESCRIPTOR_DIM,
            minimum_confidence=0.0,
            cleanup_policy=MemoryCleanupPolicy.OLDEST_FIRST,
            enabled=True,
        )
        fs = ObjectFeatureSet(
            object_type="MOTORCYCLE",
            confidence=0.9,
            geometry=GeometryFeature.derive(2.0, 0.8, 1.2),
            motion=MotionFeature(
                typical_speed_ms=9.0,
                heading_rad=0.1,
                motion_class=MotionClass.NORMAL,
            ),
        )
        result = pm.observe(fs)
        assert result.ok
        proto = pm.get("MOTORCYCLE")
        assert proto is not None
        assert proto.observation_count == 1

    def test_phase51_object_memory_still_works(self):
        from core.memory import ObjectMemory, ObjectMemoryEntry, MemoryLifecycleState
        om = ObjectMemory()
        from core.memory import (
            MemoryPositionSummary, MemoryDimensions, MemoryMotionSummary,
        )
        entry = ObjectMemoryEntry(
            memory_id="mem_integration_test",
            object_type="CAR",
            track_id="t_001",
            position=MemoryPositionSummary(x=10.0, y=5.0),
            dimensions=MemoryDimensions(length=4.5, width=1.8, height=1.5),
            motion=MemoryMotionSummary(speed_ms=5.0, heading_rad=0.3, acceleration_ms2=0.1),
            confidence=0.85,
            observed_at=time.time(),
        )
        result = om.add(entry)
        assert result.ok

    def test_phase53a_similarity_engine_still_works(self):
        from core.memory import SimilarityEngine, CurrentSituation, DEFAULT_SIMILARITY_WEIGHTS
        engine = SimilarityEngine()
        sit = CurrentSituation(object_type="CAR")
        from core.memory import ObjectPrototype
        proto = ObjectPrototype(prototype_key="CAR", object_type="CAR", observation_count=5, confidence=0.8)
        result = engine.compare_to_prototype(sit, proto)
        assert 0.0 <= result.overall_similarity <= 1.0

    def test_scene_feature_memory_imports_cleanly(self):
        """Phase 8.3 exports are importable from core.memory."""
        from core.memory import (
            SceneFeatureMemory, ContextFeature, RiskFeature,
            FeatureNormalizer, SituationFeatureVector,
        )
        sfm = SceneFeatureMemory()
        assert sfm is not None

    def test_phase83_does_not_modify_phase52_prototypes(self):
        """Phase 8.3 SceneFeatureMemory uses its own prototype store."""
        pm = PrototypeMemory(store=InMemoryPrototypeStore(), enabled=True)
        sfm = SceneFeatureMemory()

        fs = _feature()
        pm.observe(fs)
        sfm.add_observation(fs, _context(), _risk())

        # Phase 5.2 and 8.3 stores are independent
        assert pm.get("MOTORCYCLE") is not None  # Phase 5.2 still has it
        assert sfm.prototype_count == 1             # Phase 8.3 has it independently
        # Clearing one does not affect the other
        sfm.clear()
        assert pm.get("MOTORCYCLE") is not None


# ===========================================================================
# Section 13 — Performance sanity
# ===========================================================================

class TestPerformanceSanity:

    def test_1000_observations_bounded_memory(self):
        """1000 observations must not exceed max_prototypes."""
        sfm = _sfm(max_prototypes=50, similarity_threshold=0.75)
        for i in range(1000):
            # Cycle through a few archetypes
            speed = [0.0, 5.0, 15.0, 30.0][i % 4]
            sfm.add_observation(
                _feature(speed=speed, motion_class=[
                    MotionClass.STATIONARY, MotionClass.SLOW, MotionClass.NORMAL, MotionClass.FAST
                ][i % 4]),
                _context(traffic=TrafficDensityClass.MODERATE),
                _risk(),
            )
        assert sfm.prototype_count <= 50

    def test_100_observations_timing(self):
        """100 observations should complete in reasonable time (< 5 s offline)."""
        import time as _time
        sfm = _sfm(max_prototypes=100, similarity_threshold=0.80)
        start = _time.time()
        for i in range(100):
            sfm.add_observation(_feature(speed=float(i % 10)), _context(), _risk())
        elapsed = _time.time() - start
        assert elapsed < 5.0, f"100 observations took {elapsed:.2f}s — too slow"

    def test_find_similar_top_k_respected(self):
        """find_similar never returns more than top_k results."""
        sfm = _sfm(max_prototypes=50, similarity_threshold=0.99)
        for i in range(10):
            sfm.add_observation(_feature(speed=float(i)), _context(), _risk())
        norm = FeatureNormalizer()
        query = norm.normalize(_feature(speed=5.0), _context(), _risk())
        results = sfm.find_similar(query, top_k=3)
        assert len(results) <= 3

    def test_find_similar_sorted_by_similarity(self):
        """Results are sorted by similarity descending."""
        sfm = _sfm(max_prototypes=50, similarity_threshold=0.99)
        for i in range(5):
            sfm.add_observation(_feature(speed=float(i) * 5.0), _context(), _risk())
        norm = FeatureNormalizer()
        query = norm.normalize(_feature(speed=5.0), _context(), _risk())
        results = sfm.find_similar(query, top_k=10)
        for j in range(len(results) - 1):
            assert results[j].similarity >= results[j + 1].similarity

    def test_memory_size_after_compaction(self):
        """compact_memory() reduces or maintains prototype count."""
        sfm = _sfm(max_prototypes=100, similarity_threshold=0.99)
        for i in range(20):
            sfm.add_observation(_feature(speed=9.0 + i * 0.001), _context(), _risk())
        before = sfm.prototype_count
        removed = sfm.compact_memory(max_merge_similarity=0.30)
        after = sfm.prototype_count
        assert after == before - removed
        assert after <= before
