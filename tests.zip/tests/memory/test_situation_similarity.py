"""
IndiDrive AI — Phase 5.3A | Situation Representation + Similarity Engine Tests
================================================================================
Run with:  PYTHONPATH=. pytest tests/memory/test_situation_similarity.py -v

Covers every requirement from the Phase 5.3A spec:

  Situation Representation
    - valid situation creation (minimal, complete, field defaults)
    - missing features (geometry / shape / appearance / motion all optional)
    - invalid values (NaN, Inf, confidence out of range, bad timestamp)
    - serialisation round-trip (to_dict / from_dict / to_json / from_json)
    - schema version mismatch rejection

  Object-type similarity
    - identical type → 1.0
    - different type → 0.0
    - NOT_AVAILABLE / empty type → unavailable

  Geometry similarity
    - identical geometry → 1.0
    - similar geometry → high score
    - very different geometry → low score
    - missing geometry → unavailable

  Shape similarity
    - identical shape → 1.0
    - different shape → lower score
    - missing shape → unavailable

  Appearance similarity
    - identical appearance → 1.0
    - different dominant colour → lower score
    - missing appearance → unavailable

  Motion similarity
    - identical motion → 1.0
    - similar motion → high score
    - different motion → lower score
    - missing motion → unavailable

  Heading — circular angle
    - 359° vs 1° → nearly identical (high similarity)
    - 0° vs 180° → maximally different (0.0)
    - 0° vs 90° → mid similarity

  Weighted similarity
    - all features available
    - missing appearance only
    - missing shape only
    - only object_type available (all others None)
    - all optional features missing (only object_type)
    - custom weights (zero-weight disables a group)

  Output invariants
    - 0.0 ≤ overall_similarity ≤ 1.0 for all cases
    - breakdown keys always present
    - unavailable marked as "unavailable"

  Determinism
    - identical inputs run multiple times → identical result

  Config
    - SimilarityWeights.from_dict
    - SimilarityWeights.to_dict round-trip
    - invalid weights raise ValueError

  Regression
    - Phase 5.1 ObjectMemoryEntry import unaffected
    - Phase 5.2 ObjectFeatureSet / ObjectPrototype import unaffected
    - compare_to_feature_set API works correctly

  compare_to_prototype
    - full comparison through ObjectPrototype
"""
from __future__ import annotations

import json
import math
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))

from core.memory import (
    # Phase 5.1 regression
    ObjectMemoryEntry,
    MEMORY_SCHEMA_VERSION,
    # Phase 5.2 regression
    ObjectFeatureSet,
    GeometryFeature,
    ShapeFeature,
    AppearanceFeature,
    MotionFeature,
    MotionClass,
    ObjectPrototype,
    prototype_key_for,
    update_prototype,
    # Phase 5.3A
    SITUATION_SCHEMA_VERSION,
    CurrentSituation,
    SituationValidationResult,
    validate_situation,
    SimilarityWeights,
    DEFAULT_SIMILARITY_WEIGHTS,
    SimilarityResult,
    SimilarityEngine,
    compute_similarity,
)

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_UNAVAILABLE_STR = "unavailable"


def _deg_to_rad(deg: float) -> float:
    return deg * math.pi / 180.0


def _make_geometry(length=4.5, width=2.0, height=1.5) -> GeometryFeature:
    return GeometryFeature.derive(length, width, height)


def _make_shape(aspect_ratio=2.25, descriptor=None) -> ShapeFeature:
    return ShapeFeature(
        aspect_ratio=aspect_ratio,
        descriptor=descriptor if descriptor is not None else [0.1, 0.2, 0.3],
    )


def _make_appearance(color="white", histogram=None, descriptor=None) -> AppearanceFeature:
    return AppearanceFeature(
        dominant_color=color,
        color_histogram=histogram if histogram is not None else [0.2, 0.3, 0.5],
        descriptor=descriptor if descriptor is not None else [0.4, 0.5, 0.6],
    )


def _make_motion(speed=10.0, heading_deg=45.0, cls=MotionClass.NORMAL) -> MotionFeature:
    return MotionFeature(
        typical_speed_ms=speed,
        heading_rad=_deg_to_rad(heading_deg),
        motion_class=cls,
    )


def _make_situation(
    object_type="CAR",
    geometry=True,
    shape=True,
    appearance=True,
    motion=True,
    confidence=0.9,
) -> CurrentSituation:
    return CurrentSituation(
        object_type=object_type,
        geometry=_make_geometry() if geometry else None,
        shape=_make_shape() if shape else None,
        appearance=_make_appearance() if appearance else None,
        motion=_make_motion() if motion else None,
        confidence=confidence,
        source="test",
        timestamp=1_700_000_000.0,
    )


def _make_prototype(object_type="CAR", **kwargs) -> ObjectPrototype:
    fs = ObjectFeatureSet(
        object_type=object_type,
        confidence=0.9,
        geometry=kwargs.get("geometry", _make_geometry()),
        shape=kwargs.get("shape", _make_shape()),
        appearance=kwargs.get("appearance", _make_appearance()),
        motion=kwargs.get("motion", _make_motion()),
    )
    return update_prototype(None, fs)


def _default_engine() -> SimilarityEngine:
    return SimilarityEngine()


# ===========================================================================
# Section 1 — Situation Representation
# ===========================================================================

class TestSituationCreation:

    def test_minimal_situation(self):
        """Only object_type provided — all feature groups None."""
        s = CurrentSituation(object_type="PEDESTRIAN")
        assert s.object_type == "PEDESTRIAN"
        assert s.geometry is None
        assert s.shape is None
        assert s.appearance is None
        assert s.motion is None
        assert s.confidence == 0.0
        assert s.situation_schema_version == SITUATION_SCHEMA_VERSION

    def test_complete_situation(self):
        s = _make_situation()
        assert s.object_type == "CAR"
        assert s.geometry is not None
        assert s.shape is not None
        assert s.appearance is not None
        assert s.motion is not None
        assert s.confidence == 0.9
        assert s.source == "test"
        assert s.timestamp == 1_700_000_000.0

    def test_missing_geometry(self):
        s = _make_situation(geometry=False)
        assert s.geometry is None
        assert validate_situation(s).ok

    def test_missing_shape(self):
        s = _make_situation(shape=False)
        assert s.shape is None
        assert validate_situation(s).ok

    def test_missing_appearance(self):
        s = _make_situation(appearance=False)
        assert s.appearance is None
        assert validate_situation(s).ok

    def test_missing_motion(self):
        s = _make_situation(motion=False)
        assert s.motion is None
        assert validate_situation(s).ok

    def test_all_optional_features_missing(self):
        s = CurrentSituation(object_type="MOTORCYCLE", confidence=0.5)
        result = validate_situation(s)
        assert result.ok


class TestSituationValidation:

    def test_valid_full_situation(self):
        assert validate_situation(_make_situation()).ok

    def test_empty_object_type_rejected(self):
        s = CurrentSituation(object_type="", confidence=0.5)
        r = validate_situation(s)
        assert not r.ok
        assert "object_type" in r.reason

    def test_not_available_object_type_rejected(self):
        s = CurrentSituation(object_type="NOT_AVAILABLE", confidence=0.5)
        r = validate_situation(s)
        assert not r.ok

    def test_confidence_above_1_rejected(self):
        s = _make_situation(confidence=1.01)
        r = validate_situation(s)
        assert not r.ok
        assert "confidence" in r.reason

    def test_confidence_below_0_rejected(self):
        s = _make_situation(confidence=-0.01)
        r = validate_situation(s)
        assert not r.ok

    def test_confidence_nan_rejected(self):
        s = CurrentSituation(object_type="CAR", confidence=float("nan"))
        r = validate_situation(s)
        assert not r.ok

    def test_confidence_inf_rejected(self):
        s = CurrentSituation(object_type="CAR", confidence=float("inf"))
        r = validate_situation(s)
        assert not r.ok

    def test_confidence_boundary_values_valid(self):
        assert validate_situation(CurrentSituation(object_type="CAR", confidence=0.0)).ok
        assert validate_situation(CurrentSituation(object_type="CAR", confidence=1.0)).ok

    def test_timestamp_nan_rejected(self):
        s = CurrentSituation(object_type="CAR", confidence=0.5, timestamp=float("nan"))
        r = validate_situation(s)
        assert not r.ok
        assert "timestamp" in r.reason

    def test_timestamp_inf_rejected(self):
        s = CurrentSituation(object_type="CAR", confidence=0.5, timestamp=float("inf"))
        r = validate_situation(s)
        assert not r.ok

    def test_timestamp_none_valid(self):
        s = CurrentSituation(object_type="CAR", confidence=0.5, timestamp=None)
        assert validate_situation(s).ok

    def test_invalid_geometry_rejected(self):
        s = CurrentSituation(
            object_type="CAR",
            confidence=0.5,
            geometry=GeometryFeature(length=float("nan")),
        )
        r = validate_situation(s)
        assert not r.ok
        assert "geometry" in r.reason

    def test_negative_geometry_rejected(self):
        s = CurrentSituation(
            object_type="CAR",
            confidence=0.5,
            geometry=GeometryFeature(length=-1.0),
        )
        r = validate_situation(s)
        assert not r.ok

    def test_invalid_motion_rejected(self):
        bad_motion = MotionFeature(typical_speed_ms=float("nan"))
        s = CurrentSituation(object_type="CAR", confidence=0.5, motion=bad_motion)
        r = validate_situation(s)
        assert not r.ok
        assert "motion" in r.reason

    def test_negative_speed_rejected(self):
        bad_motion = MotionFeature(typical_speed_ms=-5.0)
        s = CurrentSituation(object_type="CAR", confidence=0.5, motion=bad_motion)
        r = validate_situation(s)
        assert not r.ok


class TestSituationSerialisation:

    def test_to_dict_contains_required_keys(self):
        s = _make_situation()
        d = s.to_dict()
        for key in ("situation_schema_version", "object_type", "confidence",
                    "geometry", "shape", "appearance", "motion", "source", "timestamp"):
            assert key in d, f"missing key: {key}"

    def test_to_dict_from_dict_round_trip_full(self):
        s = _make_situation()
        d = s.to_dict()
        s2 = CurrentSituation.from_dict(d)
        assert s2.object_type == s.object_type
        assert s2.confidence == s.confidence
        assert s2.geometry is not None
        assert abs(s2.geometry.length - s.geometry.length) < 1e-9
        assert s2.motion is not None
        assert abs(s2.motion.typical_speed_ms - s.motion.typical_speed_ms) < 1e-9

    def test_to_dict_from_dict_round_trip_minimal(self):
        s = CurrentSituation(object_type="TRUCK", confidence=0.7)
        s2 = CurrentSituation.from_dict(s.to_dict())
        assert s2.object_type == "TRUCK"
        assert s2.geometry is None
        assert s2.shape is None
        assert s2.appearance is None
        assert s2.motion is None

    def test_to_json_from_json_round_trip(self):
        s = _make_situation()
        js = s.to_json()
        s2 = CurrentSituation.from_json(js)
        assert s2.object_type == s.object_type
        assert abs(s2.confidence - s.confidence) < 1e-9

    def test_to_json_is_deterministic(self):
        s = _make_situation()
        assert s.to_json() == s.to_json()

    def test_json_keys_sorted(self):
        s = _make_situation()
        d = json.loads(s.to_json())
        keys = list(d.keys())
        assert keys == sorted(keys)

    def test_wrong_schema_version_raises_value_error(self):
        d = _make_situation().to_dict()
        d["situation_schema_version"] = 999
        with pytest.raises(ValueError):
            CurrentSituation.from_dict(d)

    def test_invalid_json_raises_value_error(self):
        with pytest.raises(ValueError):
            CurrentSituation.from_json("{not valid json}")

    def test_schema_version_constant(self):
        assert SITUATION_SCHEMA_VERSION == 1


# ===========================================================================
# Section 2 — Object-type similarity
# ===========================================================================

class TestObjectTypeSimilarity:

    def _engine(self):
        # Use uniform weights so we can isolate a single feature via
        # situations that have only object_type (all others None).
        w = SimilarityWeights(object_type=1.0, geometry=1.0, shape=1.0,
                               appearance=1.0, motion=1.0)
        return SimilarityEngine(weights=w)

    def _sit(self, obj_type):
        return CurrentSituation(object_type=obj_type, confidence=0.9)

    def _proto(self, obj_type):
        return _make_prototype(object_type=obj_type,
                                geometry=None, shape=None,
                                appearance=None, motion=None)

    def test_identical_type(self):
        eng = _default_engine()
        s = _make_situation(object_type="CAR", geometry=False, shape=False,
                             appearance=False, motion=False)
        p = _make_prototype(object_type="CAR", geometry=None, shape=None,
                             appearance=None, motion=None)
        r = eng.compare_to_prototype(s, p)
        assert r.components["object_type"] == 1.0

    def test_different_type(self):
        eng = _default_engine()
        s = _make_situation(object_type="CAR", geometry=False, shape=False,
                             appearance=False, motion=False)
        p = _make_prototype(object_type="PEDESTRIAN", geometry=None, shape=None,
                             appearance=None, motion=None)
        r = eng.compare_to_prototype(s, p)
        assert r.components["object_type"] == 0.0

    def test_type_case_insensitive(self):
        eng = _default_engine()
        s = CurrentSituation(object_type="car", confidence=0.9)
        p = _make_prototype(object_type="CAR", geometry=None, shape=None,
                             appearance=None, motion=None)
        r = eng.compare_to_prototype(s, p)
        assert r.components["object_type"] == 1.0

    def test_type_motorcycle_vs_bicycle(self):
        eng = _default_engine()
        s = _make_situation(object_type="MOTORCYCLE", geometry=False, shape=False,
                             appearance=False, motion=False)
        p = _make_prototype(object_type="BICYCLE", geometry=None, shape=None,
                             appearance=None, motion=None)
        r = eng.compare_to_prototype(s, p)
        assert r.components["object_type"] == 0.0


# ===========================================================================
# Section 3 — Geometry similarity
# ===========================================================================

class TestGeometrySimilarity:

    def _sit(self, **geo_kwargs):
        return CurrentSituation(
            object_type="CAR",
            confidence=0.9,
            geometry=GeometryFeature.derive(**geo_kwargs),
        )

    def _proto(self, **geo_kwargs):
        fs = ObjectFeatureSet(
            object_type="CAR",
            confidence=0.9,
            geometry=GeometryFeature.derive(**geo_kwargs),
        )
        return update_prototype(None, fs)

    def test_identical_geometry(self):
        eng = _default_engine()
        s = self._sit(length=4.5, width=2.0, height=1.5)
        p = self._proto(length=4.5, width=2.0, height=1.5)
        r = eng.compare_to_prototype(s, p)
        assert r.components["geometry"] == 1.0

    def test_very_similar_geometry(self):
        eng = _default_engine()
        s = self._sit(length=4.5, width=2.0, height=1.5)
        p = self._proto(length=4.6, width=2.05, height=1.52)
        r = eng.compare_to_prototype(s, p)
        assert isinstance(r.components["geometry"], float)
        assert r.components["geometry"] > 0.9

    def test_very_different_geometry(self):
        eng = _default_engine()
        s = self._sit(length=4.5, width=2.0, height=1.5)  # car-like
        p = self._proto(length=20.0, width=3.0, height=4.0)  # truck-like
        r = eng.compare_to_prototype(s, p)
        assert isinstance(r.components["geometry"], float)
        assert r.components["geometry"] < 0.5

    def test_missing_geometry_situation(self):
        eng = _default_engine()
        s = CurrentSituation(object_type="CAR", confidence=0.9, geometry=None)
        p = self._proto(length=4.5, width=2.0, height=1.5)
        r = eng.compare_to_prototype(s, p)
        assert r.components["geometry"] == _UNAVAILABLE_STR

    def test_missing_geometry_prototype(self):
        eng = _default_engine()
        s = self._sit(length=4.5, width=2.0, height=1.5)
        fs = ObjectFeatureSet(object_type="CAR", confidence=0.9, geometry=None)
        p = update_prototype(None, fs)
        r = eng.compare_to_prototype(s, p)
        assert r.components["geometry"] == _UNAVAILABLE_STR

    def test_both_geometry_missing(self):
        eng = _default_engine()
        s = CurrentSituation(object_type="CAR", confidence=0.9)
        fs = ObjectFeatureSet(object_type="CAR", confidence=0.9)
        p = update_prototype(None, fs)
        r = eng.compare_to_prototype(s, p)
        assert r.components["geometry"] == _UNAVAILABLE_STR


# ===========================================================================
# Section 4 — Shape similarity
# ===========================================================================

class TestShapeSimilarity:

    def test_identical_shape(self):
        eng = _default_engine()
        s = CurrentSituation(
            object_type="CAR", confidence=0.9,
            shape=ShapeFeature(aspect_ratio=2.25, descriptor=[0.1, 0.2, 0.3]),
        )
        fs = ObjectFeatureSet(
            object_type="CAR", confidence=0.9,
            shape=ShapeFeature(aspect_ratio=2.25, descriptor=[0.1, 0.2, 0.3]),
        )
        p = update_prototype(None, fs)
        r = eng.compare_to_prototype(s, p)
        assert r.components["shape"] == 1.0

    def test_different_shape(self):
        eng = _default_engine()
        s = CurrentSituation(
            object_type="CAR", confidence=0.9,
            shape=ShapeFeature(aspect_ratio=2.25, descriptor=[0.1, 0.2, 0.3]),
        )
        fs = ObjectFeatureSet(
            object_type="CAR", confidence=0.9,
            shape=ShapeFeature(aspect_ratio=5.0, descriptor=[0.9, 0.8, 0.7]),
        )
        p = update_prototype(None, fs)
        r = eng.compare_to_prototype(s, p)
        assert isinstance(r.components["shape"], float)
        assert r.components["shape"] < 0.8

    def test_missing_shape_situation(self):
        eng = _default_engine()
        s = CurrentSituation(object_type="CAR", confidence=0.9, shape=None)
        fs = ObjectFeatureSet(
            object_type="CAR", confidence=0.9,
            shape=ShapeFeature(aspect_ratio=2.25),
        )
        p = update_prototype(None, fs)
        r = eng.compare_to_prototype(s, p)
        assert r.components["shape"] == _UNAVAILABLE_STR

    def test_missing_shape_prototype(self):
        eng = _default_engine()
        s = CurrentSituation(
            object_type="CAR", confidence=0.9,
            shape=ShapeFeature(aspect_ratio=2.25),
        )
        fs = ObjectFeatureSet(object_type="CAR", confidence=0.9, shape=None)
        p = update_prototype(None, fs)
        r = eng.compare_to_prototype(s, p)
        assert r.components["shape"] == _UNAVAILABLE_STR


# ===========================================================================
# Section 5 — Appearance similarity
# ===========================================================================

class TestAppearanceSimilarity:

    def test_identical_appearance(self):
        eng = _default_engine()
        app = AppearanceFeature(
            dominant_color="white",
            color_histogram=[0.2, 0.3, 0.5],
            descriptor=[0.4, 0.5],
        )
        s = CurrentSituation(object_type="CAR", confidence=0.9, appearance=app)
        fs = ObjectFeatureSet(object_type="CAR", confidence=0.9, appearance=app)
        p = update_prototype(None, fs)
        r = eng.compare_to_prototype(s, p)
        assert r.components["appearance"] == 1.0

    def test_different_dominant_color(self):
        eng = _default_engine()
        s = CurrentSituation(
            object_type="CAR", confidence=0.9,
            appearance=AppearanceFeature(dominant_color="white"),
        )
        fs = ObjectFeatureSet(
            object_type="CAR", confidence=0.9,
            appearance=AppearanceFeature(dominant_color="black"),
        )
        p = update_prototype(None, fs)
        r = eng.compare_to_prototype(s, p)
        assert isinstance(r.components["appearance"], float)
        assert r.components["appearance"] < 1.0

    def test_missing_appearance_situation(self):
        eng = _default_engine()
        s = CurrentSituation(object_type="CAR", confidence=0.9, appearance=None)
        fs = ObjectFeatureSet(
            object_type="CAR", confidence=0.9,
            appearance=AppearanceFeature(dominant_color="white"),
        )
        p = update_prototype(None, fs)
        r = eng.compare_to_prototype(s, p)
        assert r.components["appearance"] == _UNAVAILABLE_STR

    def test_missing_appearance_prototype(self):
        eng = _default_engine()
        s = CurrentSituation(
            object_type="CAR", confidence=0.9,
            appearance=AppearanceFeature(dominant_color="white"),
        )
        fs = ObjectFeatureSet(object_type="CAR", confidence=0.9, appearance=None)
        p = update_prototype(None, fs)
        r = eng.compare_to_prototype(s, p)
        assert r.components["appearance"] == _UNAVAILABLE_STR

    def test_both_appearance_missing(self):
        eng = _default_engine()
        s = CurrentSituation(object_type="CAR", confidence=0.9)
        fs = ObjectFeatureSet(object_type="CAR", confidence=0.9)
        p = update_prototype(None, fs)
        r = eng.compare_to_prototype(s, p)
        assert r.components["appearance"] == _UNAVAILABLE_STR


# ===========================================================================
# Section 6 — Motion similarity
# ===========================================================================

class TestMotionSimilarity:

    def test_identical_motion(self):
        eng = _default_engine()
        mot = MotionFeature(
            typical_speed_ms=10.0,
            heading_rad=_deg_to_rad(45.0),
            motion_class=MotionClass.NORMAL,
        )
        s = CurrentSituation(object_type="CAR", confidence=0.9, motion=mot)
        fs = ObjectFeatureSet(object_type="CAR", confidence=0.9, motion=mot)
        p = update_prototype(None, fs)
        r = eng.compare_to_prototype(s, p)
        assert r.components["motion"] == 1.0

    def test_similar_motion(self):
        eng = _default_engine()
        s = CurrentSituation(
            object_type="CAR", confidence=0.9,
            motion=MotionFeature(
                typical_speed_ms=10.0,
                heading_rad=_deg_to_rad(45.0),
                motion_class=MotionClass.NORMAL,
            ),
        )
        fs = ObjectFeatureSet(
            object_type="CAR", confidence=0.9,
            motion=MotionFeature(
                typical_speed_ms=10.5,
                heading_rad=_deg_to_rad(47.0),
                motion_class=MotionClass.NORMAL,
            ),
        )
        p = update_prototype(None, fs)
        r = eng.compare_to_prototype(s, p)
        assert isinstance(r.components["motion"], float)
        assert r.components["motion"] > 0.85

    def test_very_different_motion(self):
        eng = _default_engine()
        s = CurrentSituation(
            object_type="CAR", confidence=0.9,
            motion=MotionFeature(
                typical_speed_ms=0.0,
                heading_rad=_deg_to_rad(0.0),
                motion_class=MotionClass.STATIONARY,
            ),
        )
        fs = ObjectFeatureSet(
            object_type="CAR", confidence=0.9,
            motion=MotionFeature(
                typical_speed_ms=30.0,
                heading_rad=_deg_to_rad(180.0),
                motion_class=MotionClass.FAST,
            ),
        )
        p = update_prototype(None, fs)
        r = eng.compare_to_prototype(s, p)
        assert isinstance(r.components["motion"], float)
        assert r.components["motion"] < 0.4

    def test_missing_motion_situation(self):
        eng = _default_engine()
        s = CurrentSituation(object_type="CAR", confidence=0.9, motion=None)
        fs = ObjectFeatureSet(
            object_type="CAR", confidence=0.9,
            motion=MotionFeature(typical_speed_ms=10.0),
        )
        p = update_prototype(None, fs)
        r = eng.compare_to_prototype(s, p)
        assert r.components["motion"] == _UNAVAILABLE_STR

    def test_missing_motion_prototype(self):
        eng = _default_engine()
        s = CurrentSituation(
            object_type="CAR", confidence=0.9,
            motion=MotionFeature(typical_speed_ms=10.0),
        )
        fs = ObjectFeatureSet(object_type="CAR", confidence=0.9, motion=None)
        p = update_prototype(None, fs)
        r = eng.compare_to_prototype(s, p)
        assert r.components["motion"] == _UNAVAILABLE_STR

    def test_motion_class_unknown_not_penalised(self):
        """UNKNOWN motion class on either side should NOT produce 0.0 for motion."""
        eng = _default_engine()
        s = CurrentSituation(
            object_type="CAR", confidence=0.9,
            motion=MotionFeature(
                typical_speed_ms=10.0,
                heading_rad=_deg_to_rad(45.0),
                motion_class=MotionClass.UNKNOWN,
            ),
        )
        fs = ObjectFeatureSet(
            object_type="CAR", confidence=0.9,
            motion=MotionFeature(
                typical_speed_ms=10.0,
                heading_rad=_deg_to_rad(45.0),
                motion_class=MotionClass.NORMAL,
            ),
        )
        p = update_prototype(None, fs)
        r = eng.compare_to_prototype(s, p)
        # Speed and heading are identical → high similarity even though class skipped
        assert isinstance(r.components["motion"], float)
        assert r.components["motion"] > 0.9


# ===========================================================================
# Section 7 — Heading / circular angle
# ===========================================================================

class TestHeadingSimilarity:

    def _sit_heading(self, deg):
        return CurrentSituation(
            object_type="CAR", confidence=0.9,
            motion=MotionFeature(heading_rad=_deg_to_rad(deg)),
        )

    def _proto_heading(self, deg):
        fs = ObjectFeatureSet(
            object_type="CAR", confidence=0.9,
            motion=MotionFeature(heading_rad=_deg_to_rad(deg)),
        )
        return update_prototype(None, fs)

    def test_359_vs_1_close(self):
        """359° and 1° are only 2° apart — similarity should be very high."""
        eng = _default_engine()
        r = eng.compare_to_prototype(
            self._sit_heading(359.0),
            self._proto_heading(1.0),
        )
        motion_sim = r.components["motion"]
        assert isinstance(motion_sim, float), f"expected float, got {motion_sim!r}"
        assert motion_sim > 0.97, f"Expected >0.97 for 358°/1°, got {motion_sim}"

    def test_0_vs_180_maximally_different(self):
        """0° and 180° are as different as possible for heading."""
        eng = _default_engine()
        r = eng.compare_to_prototype(
            self._sit_heading(0.0),
            self._proto_heading(180.0),
        )
        motion_sim = r.components["motion"]
        assert isinstance(motion_sim, float)
        assert motion_sim == 0.0, f"Expected 0.0 for 0°/180°, got {motion_sim}"

    def test_0_vs_90_mid(self):
        """0° and 90° → heading similarity = 0.5."""
        eng = _default_engine()
        r = eng.compare_to_prototype(
            self._sit_heading(0.0),
            self._proto_heading(90.0),
        )
        motion_sim = r.components["motion"]
        assert isinstance(motion_sim, float)
        assert abs(motion_sim - 0.5) < 0.02, f"Expected ~0.5 for 0°/90°, got {motion_sim}"

    def test_identical_heading(self):
        eng = _default_engine()
        r = eng.compare_to_prototype(
            self._sit_heading(45.0),
            self._proto_heading(45.0),
        )
        assert r.components["motion"] == 1.0

    def test_wrap_270_vs_350(self):
        """270° and 350° — shortest arc is 80° — similarity should be moderate-high."""
        eng = _default_engine()
        r = eng.compare_to_prototype(
            self._sit_heading(270.0),
            self._proto_heading(350.0),
        )
        motion_sim = r.components["motion"]
        assert isinstance(motion_sim, float)
        # 80° out of 180° max → heading_sim ≈ 1 - 80/180 ≈ 0.556
        assert 0.4 < motion_sim < 0.7, f"Unexpected heading sim: {motion_sim}"


# ===========================================================================
# Section 8 — Weighted similarity
# ===========================================================================

class TestWeightedSimilarity:

    def test_all_features_available(self):
        eng = _default_engine()
        s = _make_situation()
        p = _make_prototype()
        r = eng.compare_to_prototype(s, p)
        assert isinstance(r.overall_similarity, float)
        assert 0.0 <= r.overall_similarity <= 1.0
        # Identical inputs — should be 1.0
        assert r.overall_similarity == 1.0

    def test_missing_appearance_does_not_penalise(self):
        """If appearance is missing on both sides, overall score should
        remain high for otherwise identical features."""
        eng = _default_engine()
        s = _make_situation(appearance=False)
        fs = ObjectFeatureSet(
            object_type="CAR", confidence=0.9,
            geometry=_make_geometry(),
            shape=_make_shape(),
            appearance=None,
            motion=_make_motion(),
        )
        p = update_prototype(None, fs)
        r = eng.compare_to_prototype(s, p)
        assert r.components["appearance"] == _UNAVAILABLE_STR
        # All other features identical → overall should be very high
        assert r.overall_similarity > 0.95

    def test_missing_shape_does_not_penalise(self):
        eng = _default_engine()
        s = _make_situation(shape=False)
        fs = ObjectFeatureSet(
            object_type="CAR", confidence=0.9,
            geometry=_make_geometry(),
            shape=None,
            appearance=_make_appearance(),
            motion=_make_motion(),
        )
        p = update_prototype(None, fs)
        r = eng.compare_to_prototype(s, p)
        assert r.components["shape"] == _UNAVAILABLE_STR
        assert r.overall_similarity > 0.95

    def test_only_object_type_available(self):
        """When ALL optional features are missing on both sides, only
        object_type is comparable — matching type → 1.0, different → 0.0."""
        eng = _default_engine()
        s = CurrentSituation(object_type="CAR", confidence=0.9)
        fs = ObjectFeatureSet(object_type="CAR", confidence=0.9)
        p = update_prototype(None, fs)
        r = eng.compare_to_prototype(s, p)
        assert r.components["object_type"] == 1.0
        assert r.overall_similarity == 1.0

    def test_only_object_type_available_mismatch(self):
        eng = _default_engine()
        s = CurrentSituation(object_type="CAR", confidence=0.9)
        fs = ObjectFeatureSet(object_type="BUS", confidence=0.9)
        p = update_prototype(None, fs)
        r = eng.compare_to_prototype(s, p)
        assert r.overall_similarity == 0.0

    def test_custom_weight_zero_disables_group(self):
        """Setting appearance weight to 0 means it never contributes."""
        w = SimilarityWeights(object_type=1.0, geometry=1.0, shape=1.0,
                               appearance=0.0, motion=1.0)
        eng = SimilarityEngine(weights=w)
        # Make appearance mismatch — should not affect score
        s = _make_situation()
        s.appearance = AppearanceFeature(dominant_color="red")
        fs = ObjectFeatureSet(
            object_type="CAR", confidence=0.9,
            geometry=_make_geometry(),
            shape=_make_shape(),
            appearance=AppearanceFeature(dominant_color="blue"),
            motion=_make_motion(),
        )
        p = update_prototype(None, fs)
        r = eng.compare_to_prototype(s, p)
        # Appearance group should still appear in breakdown (as a value)
        # but its weight is 0 so the overall should be very high
        # (object_type, geometry, shape, motion all identical)
        assert r.overall_similarity > 0.95

    def test_different_weights_change_score(self):
        """Heavy object_type weight should pull score strongly toward 0 for type mismatch."""
        w_heavy = SimilarityWeights(object_type=100.0, geometry=1.0, shape=1.0,
                                     appearance=1.0, motion=1.0)
        eng_heavy = SimilarityEngine(weights=w_heavy)
        s = _make_situation(object_type="CAR")
        p = _make_prototype(object_type="TRUCK")  # type mismatch
        r_heavy = eng_heavy.compare_to_prototype(s, p)
        # Should be very low because type weight dominates and type == 0.0
        assert r_heavy.overall_similarity < 0.1

    def test_partial_features_renormalise_correctly(self):
        """Scores should not depend on which features happen to be present
        when only one feature exists and it matches perfectly."""
        eng = _default_engine()
        for feature_group in ["geometry", "shape", "motion"]:
            s = CurrentSituation(
                object_type="NOT_AVAILABLE",  # skip type
                confidence=0.9,
                geometry=_make_geometry() if feature_group == "geometry" else None,
                shape=_make_shape() if feature_group == "shape" else None,
                motion=_make_motion() if feature_group == "motion" else None,
            )
            fs = ObjectFeatureSet(
                object_type="NOT_AVAILABLE",
                confidence=0.9,
                geometry=_make_geometry() if feature_group == "geometry" else None,
                shape=_make_shape() if feature_group == "shape" else None,
                motion=_make_motion() if feature_group == "motion" else None,
            )
            p = update_prototype(None, fs)
            r = eng.compare_to_prototype(s, p)
            # The one available feature is identical so overall == 1.0
            assert r.overall_similarity == 1.0, (
                f"Expected 1.0 for identical {feature_group}, got {r.overall_similarity}"
            )


# ===========================================================================
# Section 9 — Output invariants
# ===========================================================================

class TestOutputInvariants:

    def test_score_clamped_between_0_and_1(self):
        eng = _default_engine()
        for _ in range(20):
            s = _make_situation()
            p = _make_prototype()
            r = eng.compare_to_prototype(s, p)
            assert 0.0 <= r.overall_similarity <= 1.0

    def test_score_clamped_mismatched(self):
        eng = _default_engine()
        s = _make_situation(object_type="CAR")
        p = _make_prototype(object_type="PEDESTRIAN")
        r = eng.compare_to_prototype(s, p)
        assert 0.0 <= r.overall_similarity <= 1.0

    def test_breakdown_keys_always_present(self):
        eng = _default_engine()
        s = _make_situation()
        p = _make_prototype()
        r = eng.compare_to_prototype(s, p)
        for key in ("object_type", "geometry", "shape", "appearance", "motion"):
            assert key in r.components, f"missing key: {key}"

    def test_breakdown_values_are_float_or_unavailable(self):
        eng = _default_engine()
        s = _make_situation(appearance=False)
        p = _make_prototype()
        r = eng.compare_to_prototype(s, p)
        for key, val in r.components.items():
            assert isinstance(val, (float, str)), f"{key}={val!r} is neither float nor str"
            if isinstance(val, str):
                assert val == _UNAVAILABLE_STR
            else:
                assert 0.0 <= val <= 1.0

    def test_to_dict_serialisable(self):
        eng = _default_engine()
        r = eng.compare_to_prototype(_make_situation(), _make_prototype())
        d = r.to_dict()
        json.dumps(d)  # must not raise

    def test_identical_inputs_score_one(self):
        eng = _default_engine()
        s = _make_situation()
        p = _make_prototype()
        r = eng.compare_to_prototype(s, p)
        assert r.overall_similarity == 1.0

    def test_type_mismatch_reduces_score_significantly(self):
        """When object_type mismatches (weight=2.0 out of total 5.6), the
        score is pulled well below 1.0.  All other features are identical.

        Calculation: type=0*2 + geo=1*1 + shape=1*0.8 + app=1*0.6 + mot=1*1.2
                     = 0 + 1 + 0.8 + 0.6 + 1.2 = 3.6 / 5.6 ≈ 0.643
        The test verifies the score is noticeably below 1.0 but does NOT
        require it to be below 0.5 (which would need a zero-weight on all
        other groups to be guaranteed).
        """
        eng = _default_engine()
        s = _make_situation(object_type="CAR")
        p = _make_prototype(object_type="PEDESTRIAN")
        r = eng.compare_to_prototype(s, p)
        # object_type component must be 0.0
        assert r.components["object_type"] == 0.0
        # Overall must be noticeably below a perfect score
        assert r.overall_similarity < 0.9
        # And it must be in valid range
        assert 0.0 <= r.overall_similarity <= 1.0


# ===========================================================================
# Section 10 — Determinism
# ===========================================================================

class TestDeterminism:

    def test_same_inputs_same_score_multiple_runs(self):
        eng = _default_engine()
        s = _make_situation()
        p = _make_prototype()
        scores = [eng.compare_to_prototype(s, p).overall_similarity for _ in range(20)]
        assert len(set(scores)) == 1, f"Non-deterministic scores: {scores}"

    def test_same_inputs_same_breakdown(self):
        eng = _default_engine()
        s = _make_situation()
        p = _make_prototype()
        breakdowns = [eng.compare_to_prototype(s, p).components for _ in range(5)]
        first = json.dumps(breakdowns[0], sort_keys=True)
        for b in breakdowns[1:]:
            assert json.dumps(b, sort_keys=True) == first

    def test_different_engines_same_weights_same_score(self):
        s = _make_situation()
        p = _make_prototype()
        r1 = SimilarityEngine().compare_to_prototype(s, p)
        r2 = SimilarityEngine().compare_to_prototype(s, p)
        assert r1.overall_similarity == r2.overall_similarity

    def test_situation_serialise_deserialise_same_score(self):
        """Score should be identical whether we use the original situation
        or one reconstructed from its JSON representation."""
        eng = _default_engine()
        s = _make_situation()
        p = _make_prototype()
        s2 = CurrentSituation.from_json(s.to_json())
        r1 = eng.compare_to_prototype(s, p)
        r2 = eng.compare_to_prototype(s2, p)
        assert r1.overall_similarity == r2.overall_similarity


# ===========================================================================
# Section 11 — Configuration
# ===========================================================================

class TestSimilarityWeightsConfig:

    def test_default_weights_valid(self):
        DEFAULT_SIMILARITY_WEIGHTS.validate()  # must not raise

    def test_from_dict(self):
        d = {"object_type": 3.0, "geometry": 2.0, "shape": 1.0,
             "appearance": 0.5, "motion": 1.5}
        w = SimilarityWeights.from_dict(d)
        assert w.object_type == 3.0
        assert w.geometry == 2.0
        assert w.appearance == 0.5

    def test_from_dict_uses_defaults_for_missing_keys(self):
        w = SimilarityWeights.from_dict({})
        assert w.object_type == 2.0   # default

    def test_to_dict_round_trip(self):
        w = SimilarityWeights(object_type=3.0, geometry=2.0, shape=1.0,
                               appearance=0.5, motion=1.5)
        w2 = SimilarityWeights.from_dict(w.to_dict())
        assert w2.object_type == w.object_type
        assert w2.geometry == w.geometry
        assert w2.shape == w.shape
        assert w2.appearance == w.appearance
        assert w2.motion == w.motion

    def test_negative_weight_raises(self):
        w = SimilarityWeights(object_type=-1.0)
        with pytest.raises(ValueError):
            w.validate()

    def test_nan_weight_raises(self):
        w = SimilarityWeights(geometry=float("nan"))
        with pytest.raises(ValueError):
            w.validate()

    def test_inf_weight_raises(self):
        w = SimilarityWeights(motion=float("inf"))
        with pytest.raises(ValueError):
            w.validate()

    def test_engine_rejects_invalid_weights(self):
        with pytest.raises(ValueError):
            SimilarityEngine(weights=SimilarityWeights(object_type=-1.0))

    def test_zero_weight_is_valid(self):
        w = SimilarityWeights(appearance=0.0)
        w.validate()  # must not raise


# ===========================================================================
# Section 12 — compare_to_feature_set API
# ===========================================================================

class TestCompareToFeatureSet:

    def test_identical_feature_set(self):
        eng = _default_engine()
        s = _make_situation()
        fs = ObjectFeatureSet(
            object_type="CAR", confidence=0.9,
            geometry=_make_geometry(),
            shape=_make_shape(),
            appearance=_make_appearance(),
            motion=_make_motion(),
        )
        r = eng.compare_to_feature_set(s, fs)
        assert r.overall_similarity == 1.0

    def test_type_mismatch_feature_set(self):
        eng = _default_engine()
        s = _make_situation(object_type="CAR")
        fs = ObjectFeatureSet(object_type="BICYCLE", confidence=0.9,
                               geometry=_make_geometry(), motion=_make_motion())
        r = eng.compare_to_feature_set(s, fs)
        assert r.components["object_type"] == 0.0

    def test_missing_appearance_feature_set(self):
        eng = _default_engine()
        s = _make_situation(appearance=False)
        fs = ObjectFeatureSet(
            object_type="CAR", confidence=0.9,
            geometry=_make_geometry(),
            appearance=None,
            motion=_make_motion(),
        )
        r = eng.compare_to_feature_set(s, fs)
        assert r.components["appearance"] == _UNAVAILABLE_STR


# ===========================================================================
# Section 13 — compute_similarity convenience function
# ===========================================================================

class TestComputeSimilarityFunction:

    def test_default_weights(self):
        s = _make_situation()
        p = _make_prototype()
        r = compute_similarity(s, p)
        assert r.overall_similarity == 1.0

    def test_custom_weights(self):
        """A large object_type weight makes a type mismatch dominate the score.

        With object_type=10.0 and other features identical (sim=1.0):
          type=0*10 + geo=1*1 + shape=1*1 + app=1*1 + mot=1*1 = 4 / 14 ≈ 0.286
        """
        w = SimilarityWeights(object_type=10.0, geometry=1.0, shape=1.0,
                               appearance=1.0, motion=1.0)
        s = _make_situation(object_type="CAR")
        p = _make_prototype(object_type="TRUCK")
        r = compute_similarity(s, p, weights=w)
        # type mismatch with huge weight → score significantly below 0.5
        assert r.overall_similarity < 0.4
        # And it should be less than what default weights would produce
        r_default = compute_similarity(s, p)
        assert r.overall_similarity < r_default.overall_similarity

    def test_returns_similarity_result(self):
        r = compute_similarity(_make_situation(), _make_prototype())
        assert isinstance(r, SimilarityResult)
        assert isinstance(r.overall_similarity, float)
        assert isinstance(r.components, dict)


# ===========================================================================
# Section 14 — Phase 5.1 / 5.2 regression
# ===========================================================================

class TestRegression:

    def test_phase51_imports_unaffected(self):
        """ObjectMemoryEntry and related types still import and work."""
        import uuid
        entry = ObjectMemoryEntry(
            memory_id=str(uuid.uuid4()),
            object_type="CAR",
            confidence=0.8,
        )
        d = entry.to_dict()
        assert d["object_type"] == "CAR"

    def test_phase52_feature_set_unaffected(self):
        fs = ObjectFeatureSet(
            object_type="MOTORCYCLE",
            confidence=0.9,
            geometry=GeometryFeature.derive(2.0, 0.8, 1.2),
        )
        d = fs.to_dict()
        assert d["object_type"] == "MOTORCYCLE"

    def test_phase52_prototype_update_unaffected(self):
        fs1 = ObjectFeatureSet(object_type="CAR", confidence=0.8,
                                geometry=GeometryFeature.derive(4.5, 2.0))
        fs2 = ObjectFeatureSet(object_type="CAR", confidence=0.9,
                                geometry=GeometryFeature.derive(4.6, 2.1))
        proto = update_prototype(None, fs1)
        proto = update_prototype(proto, fs2)
        assert proto.observation_count == 2

    def test_phase52_feature_distance_unaffected(self):
        from core.memory import feature_distance
        fs1 = ObjectFeatureSet(object_type="CAR", confidence=0.9)
        fs2 = ObjectFeatureSet(object_type="CAR", confidence=0.9)
        d = feature_distance(fs1, fs2)
        assert 0.0 <= d <= 1.0

    def test_schema_version_constants_unchanged(self):
        assert MEMORY_SCHEMA_VERSION == 1
        from core.memory import FEATURE_SCHEMA_VERSION, PROTOTYPE_SCHEMA_VERSION
        assert FEATURE_SCHEMA_VERSION == 1
        assert PROTOTYPE_SCHEMA_VERSION == 1

    def test_situation_schema_version_is_1(self):
        assert SITUATION_SCHEMA_VERSION == 1

    def test_current_situation_in_memory_package(self):
        """Phase 5.3A types are accessible via the core.memory package."""
        from core.memory import (
            CurrentSituation as CS,
            SimilarityEngine as SE,
            compute_similarity as cs,
        )
        assert CS is CurrentSituation
        assert SE is SimilarityEngine
        assert cs is compute_similarity
