"""
IndiDrive AI — Phase 5.2 | Feature / Prototype Memory Tests
==============================================================
Run with:  PYTHONPATH=. pytest tests/memory/test_feature_prototype_memory.py -v

Covers the Phase 5.2 spec sections:
  - Feature creation (geometry / shape / appearance / motion / composite)
  - Validation (NaN, Inf, invalid dimensions/confidence, oversized descriptors)
  - Prototype (identity, observation stats, first/last seen)
  - Incremental update (single/repeated observations, differing values)
  - Compactness (no raw image/point-cloud fields exist at all; descriptor caps)
  - Serialization (feature + prototype round trip; Phase 5.1 unaffected)
  - Distance (same/different/missing/invalid feature handling)
  - Capacity (prototype eviction, determinism)
  - Offline (no external service; pure stdlib/dataclasses)
  - Determinism (repeatable given identical input)
"""
from __future__ import annotations

import math
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))

from core.memory import (
    # Phase 5.1 (regression touchpoint only — not modified by this file)
    ObjectMemoryEntry,
    MEMORY_SCHEMA_VERSION,
    # Phase 5.2
    FEATURE_SCHEMA_VERSION,
    DEFAULT_MAX_DESCRIPTOR_DIM,
    MotionClass,
    GeometryFeature,
    ShapeFeature,
    AppearanceFeature,
    MotionFeature,
    ObjectFeatureSet,
    validate_feature_set,
    feature_distance,
    PROTOTYPE_SCHEMA_VERSION,
    ObjectPrototype,
    prototype_key_for,
    update_prototype,
    PrototypeMemory,
    InMemoryPrototypeStore,
    MemoryCleanupPolicy,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _feature(
    object_type: str = "MOTORCYCLE",
    confidence: float = 0.9,
    length: float = 2.0,
    width: float = 0.8,
    height: float = 1.2,
    speed: float = 9.0,
    heading: float = 0.1,
    motion_class: MotionClass = MotionClass.NORMAL,
) -> ObjectFeatureSet:
    return ObjectFeatureSet(
        object_type=object_type,
        confidence=confidence,
        geometry=GeometryFeature.derive(length, width, height),
        shape=ShapeFeature(aspect_ratio=length / width if width else None, descriptor=[0.1, 0.2, 0.3]),
        appearance=AppearanceFeature(dominant_color="white", color_histogram=[0.2, 0.3, 0.5]),
        motion=MotionFeature(
            typical_speed_ms=speed, heading_rad=heading,
            acceleration_tendency_ms2=0.1, turning_tendency=0.2,
            lateral_movement_tendency=0.3, motion_class=motion_class,
        ),
    )


def _pm(**kwargs) -> PrototypeMemory:
    defaults = dict(
        store=InMemoryPrototypeStore(),
        max_prototypes=100,
        max_feature_dimension=DEFAULT_MAX_DESCRIPTOR_DIM,
        minimum_confidence=0.0,
        cleanup_policy=MemoryCleanupPolicy.OLDEST_FIRST,
        enabled=True,
    )
    defaults.update(kwargs)
    return PrototypeMemory(**defaults)


# ===========================================================================
# Section 1 — Feature creation
# ===========================================================================

class TestFeatureCreation:

    def test_create_basic_object_feature(self):
        fs = ObjectFeatureSet(object_type="CAR", confidence=0.8)
        assert fs.object_type == "CAR"
        assert fs.confidence == pytest.approx(0.8)

    def test_create_geometry_feature(self):
        g = GeometryFeature.derive(4.5, 1.8, 1.5)
        assert g.length == pytest.approx(4.5)
        assert g.width == pytest.approx(1.8)
        assert g.height == pytest.approx(1.5)
        assert g.aspect_ratio == pytest.approx(4.5 / 1.8)

    def test_create_shape_feature(self):
        s = ShapeFeature(aspect_ratio=2.5, descriptor=[0.1, 0.2, 0.3])
        assert s.aspect_ratio == pytest.approx(2.5)
        assert s.descriptor == [0.1, 0.2, 0.3]

    def test_create_appearance_feature(self):
        a = AppearanceFeature(dominant_color="red", color_histogram=[0.1, 0.9])
        assert a.dominant_color == "red"
        assert a.color_histogram == [0.1, 0.9]

    def test_create_motion_feature(self):
        m = MotionFeature(typical_speed_ms=12.0, heading_rad=0.5, motion_class=MotionClass.FAST)
        assert m.typical_speed_ms == pytest.approx(12.0)
        assert m.motion_class == MotionClass.FAST

    def test_missing_optional_features_allowed(self):
        fs = ObjectFeatureSet(object_type="PEDESTRIAN", confidence=0.7)
        assert fs.geometry is None
        assert fs.shape is None
        assert fs.appearance is None
        assert fs.motion is None
        assert validate_feature_set(fs).ok


# ===========================================================================
# Section 2 — Validation
# ===========================================================================

class TestValidation:

    def test_invalid_dimensions_negative_rejected(self):
        fs = _feature()
        fs.geometry = GeometryFeature(length=-1.0, width=0.8, height=1.2)
        r = validate_feature_set(fs)
        assert not r.ok

    def test_nan_rejected(self):
        fs = _feature()
        fs.motion.typical_speed_ms = float("nan")
        r = validate_feature_set(fs)
        assert not r.ok

    def test_infinity_rejected(self):
        fs = _feature()
        fs.geometry.length = float("inf")
        r = validate_feature_set(fs)
        assert not r.ok

    def test_invalid_confidence_rejected(self):
        fs = _feature(confidence=1.5)
        r = validate_feature_set(fs)
        assert not r.ok

    def test_invalid_confidence_negative_rejected(self):
        fs = _feature(confidence=-0.1)
        r = validate_feature_set(fs)
        assert not r.ok

    def test_invalid_descriptor_non_numeric_rejected(self):
        fs = _feature()
        fs.shape.descriptor = ["not", "numeric"]
        r = validate_feature_set(fs)
        assert not r.ok

    def test_oversized_descriptor_rejected(self):
        fs = _feature()
        fs.shape.descriptor = [0.1] * (DEFAULT_MAX_DESCRIPTOR_DIM + 1)
        r = validate_feature_set(fs, max_descriptor_dim=DEFAULT_MAX_DESCRIPTOR_DIM)
        assert not r.ok

    def test_missing_object_type_rejected(self):
        fs = ObjectFeatureSet(object_type="", confidence=0.5)
        r = validate_feature_set(fs)
        assert not r.ok

    def test_invalid_speed_range_rejected(self):
        fs = _feature()
        fs.motion.speed_min_ms = 20.0
        fs.motion.speed_max_ms = 5.0
        r = validate_feature_set(fs)
        assert not r.ok


# ===========================================================================
# Section 3 — Prototype
# ===========================================================================

class TestPrototype:

    def test_create_prototype_from_first_observation(self):
        proto = update_prototype(None, _feature(), observed_at=1000.0)
        assert proto.observation_count == 1
        assert proto.object_type == "MOTORCYCLE"
        assert proto.first_seen == 1000.0
        assert proto.last_seen == 1000.0

    def test_prototype_identity_deterministic(self):
        k1 = prototype_key_for("MOTORCYCLE")
        k2 = prototype_key_for("motorcycle")
        assert k1 == k2 == "MOTORCYCLE"

    def test_prototype_identity_with_subtype(self):
        k = prototype_key_for("CAR", "SEDAN")
        assert k == "CAR::SEDAN"

    def test_add_observation_via_prototype_memory(self):
        pm = _pm()
        r = pm.observe(_feature(), observed_at=1000.0)
        assert r.ok
        proto = pm.get_for("MOTORCYCLE")
        assert proto is not None
        assert proto.observation_count == 1

    def test_update_observation_statistics(self):
        proto1 = update_prototype(None, _feature(length=2.0, width=0.8), observed_at=1000.0)
        proto2 = update_prototype(proto1, _feature(length=1.9, width=0.75), observed_at=1005.0)
        assert proto2.observation_count == 2
        assert proto2.geometry.length == pytest.approx((2.0 + 1.9) / 2)

    def test_multiple_observations_accumulate(self):
        proto = None
        for i in range(5):
            proto = update_prototype(proto, _feature(length=2.0 + i * 0.1), observed_at=1000.0 + i)
        assert proto.observation_count == 5

    def test_observation_count_increments(self):
        pm = _pm()
        for i in range(3):
            pm.observe(_feature(), observed_at=1000.0 + i)
        proto = pm.get_for("MOTORCYCLE")
        assert proto.observation_count == 3

    def test_first_and_last_timestamp_tracked(self):
        proto1 = update_prototype(None, _feature(), observed_at=1000.0)
        proto2 = update_prototype(proto1, _feature(), observed_at=1050.0)
        assert proto2.first_seen == 1000.0
        assert proto2.last_seen == 1050.0


# ===========================================================================
# Section 4 — Incremental update
# ===========================================================================

class TestIncrementalUpdate:

    def test_first_observation_adopts_values_directly(self):
        proto = update_prototype(None, _feature(length=2.0, speed=9.0), observed_at=1000.0)
        assert proto.geometry.length == pytest.approx(2.0)
        assert proto.motion.typical_speed_ms == pytest.approx(9.0)

    def test_second_observation_averages_values(self):
        proto1 = update_prototype(None, _feature(speed=9.0), observed_at=1000.0)
        proto2 = update_prototype(proto1, _feature(speed=10.0), observed_at=1005.0)
        assert proto2.motion.typical_speed_ms == pytest.approx(9.5)

    def test_repeated_observations_converge_deterministically(self):
        proto = None
        for i in range(10):
            proto = update_prototype(proto, _feature(speed=10.0), observed_at=1000.0 + i)
        assert proto.motion.typical_speed_ms == pytest.approx(10.0)
        assert proto.observation_count == 10

    def test_different_confidence_values_tracked(self):
        proto1 = update_prototype(None, _feature(confidence=0.9), observed_at=1000.0)
        proto2 = update_prototype(proto1, _feature(confidence=0.5), observed_at=1005.0)
        assert proto2.confidence == pytest.approx(0.7)
        assert proto2.confidence_min == pytest.approx(0.5)
        assert proto2.confidence_max == pytest.approx(0.9)

    def test_different_dimensions_update_running_mean(self):
        proto1 = update_prototype(None, _feature(length=2.0, width=0.8, height=1.2), observed_at=1000.0)
        proto2 = update_prototype(proto1, _feature(length=1.8, width=0.7, height=1.1), observed_at=1005.0)
        assert proto2.geometry.width == pytest.approx((0.8 + 0.7) / 2)
        assert proto2.geometry.height == pytest.approx((1.2 + 1.1) / 2)

    def test_update_never_mutates_input_prototype(self):
        proto1 = update_prototype(None, _feature(speed=9.0), observed_at=1000.0)
        snapshot = proto1.to_dict()
        update_prototype(proto1, _feature(speed=20.0), observed_at=1005.0)
        assert proto1.to_dict() == snapshot  # unchanged (pure function)

    def test_speed_range_widens_across_observations(self):
        proto1 = update_prototype(None, _feature(speed=9.0), observed_at=1000.0)
        proto2 = update_prototype(proto1, _feature(speed=15.0), observed_at=1005.0)
        proto3 = update_prototype(proto2, _feature(speed=5.0), observed_at=1010.0)
        assert proto3.speed_min_ms == pytest.approx(5.0)
        assert proto3.speed_max_ms == pytest.approx(15.0)


# ===========================================================================
# Section 5 — Compactness
# ===========================================================================

class TestCompactness:

    def test_no_raw_image_field_exists(self):
        for cls in (ObjectFeatureSet, GeometryFeature, ShapeFeature, AppearanceFeature,
                    MotionFeature, ObjectPrototype):
            field_names = {f.lower() for f in cls.__dataclass_fields__.keys()}
            for banned in ("image", "frame", "rgb", "pixels", "video"):
                assert not any(banned in name for name in field_names), (
                    f"{cls.__name__} unexpectedly has an image-like field"
                )

    def test_no_raw_pointcloud_field_exists(self):
        for cls in (ObjectFeatureSet, GeometryFeature, ShapeFeature, AppearanceFeature,
                    MotionFeature, ObjectPrototype):
            field_names = {f.lower() for f in cls.__dataclass_fields__.keys()}
            for banned in ("pointcloud", "point_cloud", "lidar_points"):
                assert not any(banned in name for name in field_names)

    def test_descriptor_size_respects_limit(self):
        fs = _feature()
        fs.shape.descriptor = [0.1] * 8
        assert validate_feature_set(fs, max_descriptor_dim=16).ok
        fs.shape.descriptor = [0.1] * 17
        assert not validate_feature_set(fs, max_descriptor_dim=16).ok


# ===========================================================================
# Section 6 — Serialization
# ===========================================================================

class TestSerialization:

    def test_feature_round_trip_dict(self):
        fs = _feature()
        restored = ObjectFeatureSet.from_dict(fs.to_dict())
        assert restored.to_dict() == fs.to_dict()

    def test_feature_round_trip_json(self):
        fs = _feature()
        restored = ObjectFeatureSet.from_json(fs.to_json())
        assert restored.to_dict() == fs.to_dict()

    def test_prototype_round_trip_dict(self):
        proto = update_prototype(None, _feature(), observed_at=1000.0)
        restored = ObjectPrototype.from_dict(proto.to_dict())
        assert restored.to_dict() == proto.to_dict()

    def test_prototype_round_trip_json(self):
        proto = update_prototype(None, _feature(), observed_at=1000.0)
        restored = ObjectPrototype.from_json(proto.to_json())
        assert restored.to_dict() == proto.to_dict()

    def test_backward_compatibility_with_phase51_memory_entry(self):
        """Phase 5.2 additions must not alter the Phase 5.1 schema."""
        e = ObjectMemoryEntry(
            memory_id="mem_x", object_type="CAR", confidence=0.5,
            observed_at=1.0, created_at=1.0, updated_at=1.0,
        )
        d = e.to_dict()
        assert d["memory_schema_version"] == MEMORY_SCHEMA_VERSION
        restored = ObjectMemoryEntry.from_dict(d)
        assert restored.to_dict() == d


# ===========================================================================
# Section 7 — Distance
# ===========================================================================

class TestFeatureDistance:

    def test_same_feature_distance_is_zero(self):
        fs = _feature()
        assert feature_distance(fs, fs) == pytest.approx(0.0)

    def test_different_feature_distance_is_positive(self):
        a = _feature(length=2.0, speed=9.0)
        b = _feature(length=4.0, speed=20.0)
        d = feature_distance(a, b)
        assert d > 0.0

    def test_distance_is_bounded(self):
        a = _feature(length=1.0, speed=1.0)
        b = _feature(length=1000.0, speed=1000.0)
        d = feature_distance(a, b)
        assert 0.0 <= d <= 1.0

    def test_missing_feature_handled_gracefully(self):
        a = ObjectFeatureSet(object_type="CAR", confidence=0.5)
        b = ObjectFeatureSet(object_type="CAR", confidence=0.5)
        # No comparable components at all -> defined as maximally distant
        assert feature_distance(a, b) == pytest.approx(1.0)

    def test_partial_missing_feature_handled(self):
        a = _feature()
        b = ObjectFeatureSet(object_type="MOTORCYCLE", confidence=0.5, geometry=a.geometry)
        d = feature_distance(a, b)
        assert 0.0 <= d <= 1.0

    def test_invalid_feature_values_do_not_crash(self):
        a = _feature()
        b = _feature()
        b.motion.typical_speed_ms = float("nan")
        d = feature_distance(a, b)
        assert math.isfinite(d)
        assert 0.0 <= d <= 1.0

    def test_distance_is_deterministic(self):
        a = _feature(length=2.0)
        b = _feature(length=3.0)
        d1 = feature_distance(a, b)
        d2 = feature_distance(a, b)
        assert d1 == d2


# ===========================================================================
# Section 8 — Capacity
# ===========================================================================

class TestCapacity:

    def test_prototype_capacity_enforced(self):
        pm = _pm(max_prototypes=2, cleanup_policy=MemoryCleanupPolicy.OLDEST_FIRST)
        pm.observe(_feature(object_type="CAR"), observed_at=1000.0)
        pm.observe(_feature(object_type="BUS"), observed_at=1001.0)
        pm.observe(_feature(object_type="TRUCK"), observed_at=1002.0)
        assert len(pm.list()) <= 2

    def test_deterministic_cleanup_oldest_first(self):
        pm = _pm(max_prototypes=2, cleanup_policy=MemoryCleanupPolicy.OLDEST_FIRST)
        pm.observe(_feature(object_type="CAR"), observed_at=1000.0)
        pm.observe(_feature(object_type="BUS"), observed_at=1001.0)
        pm.observe(_feature(object_type="TRUCK"), observed_at=1002.0)
        keys = set(pm.list_keys())
        assert "CAR" not in keys  # oldest evicted
        assert "TRUCK" in keys

    def test_deterministic_cleanup_lowest_confidence(self):
        pm = _pm(max_prototypes=2, cleanup_policy=MemoryCleanupPolicy.LOWEST_CONFIDENCE)
        pm.observe(_feature(object_type="CAR", confidence=0.9), observed_at=1000.0)
        pm.observe(_feature(object_type="BUS", confidence=0.2), observed_at=1001.0)
        pm.observe(_feature(object_type="TRUCK", confidence=0.95), observed_at=1002.0)
        keys = set(pm.list_keys())
        assert "BUS" not in keys  # lowest confidence evicted


# ===========================================================================
# Section 9 — Offline
# ===========================================================================

class TestOffline:

    def test_no_external_service_required(self):
        """Everything here is pure stdlib/dataclasses — importing and
        running must never touch the network."""
        pm = _pm()
        result = pm.observe(_feature(), observed_at=1000.0)
        assert result.ok
        assert feature_distance(_feature(), _feature()) == pytest.approx(0.0)


# ===========================================================================
# Section 10 — Determinism
# ===========================================================================

class TestDeterminism:

    def test_same_input_produces_same_feature_state(self):
        fs1 = _feature()
        fs2 = _feature()
        assert fs1.to_dict() == fs2.to_dict()

    def test_same_input_produces_same_prototype_state(self):
        proto1 = update_prototype(None, _feature(), observed_at=1000.0)
        proto2 = update_prototype(None, _feature(), observed_at=1000.0)
        assert proto1.to_dict() == proto2.to_dict()

    def test_schema_versions_are_stable_constants(self):
        assert FEATURE_SCHEMA_VERSION == 1
        assert PROTOTYPE_SCHEMA_VERSION == 1
