"""
CARLA INTEGRATION TEST — full pipeline: CARLA -> Vehicle -> Camera/LiDAR/Radar
-> SensorManager -> SensorBuffer -> Health Monitor -> Recorder.

Honesty requirement (Phase 1 spec, section 27): if a real CARLA server is
not reachable, this test reports NOT RUN with a reason — it does not fake
a pass. It is skipped (not failed) so the rest of the suite still reports
green in CI on machines without a CARLA server, which matches how the
Phase 0 test suite already treats CARLA (see tests/test_carla_client.py).
"""
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))

from core.carla_integration.connection import CarlaConnection, CarlaUnavailableError


def _carla_reachable() -> tuple[bool, str]:
    try:
        CarlaConnection(host="localhost", port=2000, timeout=2.0).connect()
        return True, ""
    except CarlaUnavailableError as e:
        return False, str(e)
    except Exception as e:  # pragma: no cover - any other connection failure
        return False, str(e)


def test_carla_integration_camera_lidar_radar_pipeline():
    reachable, reason = _carla_reachable()
    if not reachable:
        pytest.skip(
            "CARLA INTEGRATION TEST\nStatus: NOT RUN\n"
            f"Reason: CARLA server unavailable ({reason})"
        )

    # Only executes on a machine with a live CARLA server.
    from core.carla_integration.vehicle import spawn_ego_vehicle  # existing Phase 0 helper
    from core.carla_integration.sensor_interface import (
        CARLACameraSensor, CARLALiDARSensor, CARLARadarSensor,
    )
    from core.carla_integration.sensor_manager import SensorManager

    conn = CarlaConnection().connect()
    vehicle = spawn_ego_vehicle(conn.world)
    try:
        mgr = SensorManager(buffer_capacity=10)
        mgr.register(CARLACameraSensor(conn.world, vehicle))
        mgr.register(CARLALiDARSensor(conn.world, vehicle))
        mgr.register(CARLARadarSensor(conn.world, vehicle, configured=False))
        mgr.start_all()

        for _ in range(20):
            conn.tick()

        status = mgr.status_report()
        assert status["rgb_front"]["fps"] >= 0
        assert status["radar_front"]["status"] == "NOT_CONFIGURED"
        mgr.stop_all()
    finally:
        conn.cleanup_actors([vehicle])
