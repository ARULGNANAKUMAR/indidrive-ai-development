"""
IndiDrive AI — Phase 0 | Integration tests
Run with: PYTHONPATH=. pytest tests/integration/ -v
Covers spec Test 7 (existing project imports successfully),
Test 8 (existing simulator still works), Test 9 (existing planner not broken).
"""
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent.parent
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "legacy_simulator"))


# --- Test 7: Existing project imports successfully ---

def test_all_core_modules_import():
    import core.dataset.manager
    import core.models.manager
    import core.echo.echo_v2
    import core.benchmark.suite
    import core.scenarios.manager
    import core.reports.generator
    import core.deployment
    import core.carla_integration.connection
    import core.carla_integration.sensors


def test_api_server_or_clear_reason_why_not():
    # api/server.py needs fastapi/uvicorn/a2wsgi. In an environment with
    # them installed this must import cleanly; in one without them (this
    # project's own offline dev sandbox), it must fail with ImportError
    # specifically, not some other error, so app.py's error handling path
    # is exercised correctly either way.
    try:
        import api.server  # noqa: F401
    except ImportError:
        pass  # expected without fastapi/uvicorn/a2wsgi installed


# --- Test 8: Existing simulator still works ---

def test_legacy_simulator_imports_and_serves():
    import importlib
    server = importlib.import_module("server")
    client = server.app.test_client()

    r = client.get("/")
    assert r.status_code == 200

    r = client.get("/api/health")
    assert r.status_code == 200
    body = r.get_json()
    assert body["success"] is True
    assert body["data"]["status"] == "ok"


def test_legacy_simulator_scenario_generation():
    import importlib
    server = importlib.import_module("server")
    client = server.app.test_client()
    r = client.post("/api/scenario/generate", json={})
    assert r.status_code == 200
    assert r.get_json()["success"] is True


def test_legacy_simulator_hazard_scenarios_load():
    import importlib
    server = importlib.import_module("server")
    client = server.app.test_client()
    r = client.get("/api/scenario/sih")
    assert r.status_code == 200


# --- Test 9: Existing planner behavior is not broken ---

def test_planner_returns_multiple_candidate_paths():
    import importlib
    server = importlib.import_module("server")
    client = server.app.test_client()
    r = client.post("/api/ai/plan", json={
        "start": {"x": 0, "y": 0}, "goal": {"x": 0, "y": -50}, "obstacles": [],
    })
    assert r.status_code == 200
    data = r.get_json()["data"]
    assert "selected_path" in data
    assert len(data["all_paths"]) == 5  # 5 lateral offsets, matches config/planner_config.yaml


def test_planner_flags_replanning_when_path_blocked():
    import importlib
    server = importlib.import_module("server")
    client = server.app.test_client()
    # Obstacle sitting directly on every candidate path's start point.
    r = client.post("/api/ai/plan", json={
        "start": {"x": 0, "y": 0}, "goal": {"x": 0, "y": -50},
        "obstacles": [{"x": 0, "y": 0}] * 5,
    })
    data = r.get_json()["data"]
    assert data["selected_path"]["risk"] >= 0.0  # ran without error; exact value is existing behavior


def test_decision_layer_selects_lowest_risk_ok_action():
    import importlib
    server = importlib.import_module("server")
    client = server.app.test_client()
    r = client.post("/api/ai/decision", json={
        "max_risk": 0.9, "min_distance": 5, "ego_speed": 60,
        "critical_objects": [{"direction": "ahead"}],
    })
    assert r.status_code == 200
    data = r.get_json()["data"]
    assert data["selected_action"] in [
        "Continue", "Slow Down", "Brake", "Emergency Brake",
        "Steer Left", "Steer Right", "Stop", "Overtake", "Re-route",
    ]


if __name__ == "__main__":
    import traceback
    tests = [v for k, v in list(globals().items()) if k.startswith("test_") and callable(v)]
    passed = failed = 0
    for t in tests:
        try:
            t()
            print(f"PASS {t.__name__}")
            passed += 1
        except Exception:
            print(f"FAIL {t.__name__}")
            traceback.print_exc()
            failed += 1
    print(f"\n{passed} passed, {failed} failed")
