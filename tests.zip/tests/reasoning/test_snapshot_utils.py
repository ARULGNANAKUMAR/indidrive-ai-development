"""
Phase 8.1 | Snapshot Utility Tests
=====================================
Tests: age, staleness, serialisation, summary, safe copy.
"""
import json
import time
import pytest

from core.reasoning import ReasoningEngine, ReasoningState
from core.reasoning.reasoning_snapshot import (
    reasoning_snapshot_age_s,
    is_reasoning_snapshot_stale,
    reasoning_snapshot_to_json,
    reasoning_snapshot_summary,
    safe_copy_reasoning_snapshot,
)

from .conftest import make_snapshot, make_object


class TestSnapshotAge:
    def test_fresh_snapshot_age_small(self, engine):
        snap = make_snapshot()
        result = engine.assess(snap)
        age = reasoning_snapshot_age_s(result.snapshot)
        assert 0.0 <= age < 5.0

    def test_stale_detection(self, engine):
        snap = make_snapshot()
        result = engine.assess(snap)
        import dataclasses
        old = dataclasses.replace(result.snapshot, timestamp=time.time() - 10.0)
        assert is_reasoning_snapshot_stale(old, max_age_s=1.5)

    def test_fresh_not_stale(self, engine):
        snap = make_snapshot()
        result = engine.assess(snap)
        assert not is_reasoning_snapshot_stale(result.snapshot, max_age_s=10.0)


class TestSnapshotSerialization:
    def test_to_json_valid_json(self, engine):
        snap = make_snapshot(objects=[make_object()])
        result = engine.assess(snap)
        js = reasoning_snapshot_to_json(result.snapshot)
        parsed = json.loads(js)
        assert "reasoning_state" in parsed

    def test_to_json_contains_schema_version(self, engine):
        snap = make_snapshot()
        result = engine.assess(snap)
        js = reasoning_snapshot_to_json(result.snapshot)
        parsed = json.loads(js)
        assert parsed["schema_version"] == "8.1"

    def test_to_dict_nested_keys(self, engine):
        snap = make_snapshot(objects=[make_object()])
        result = engine.assess(snap)
        d = result.snapshot.to_dict()
        assert "hazards" in d
        assert "interactions" in d
        assert "risk" in d
        assert "complexity" in d
        assert "uncertainty" in d


class TestSnapshotSummary:
    def test_summary_has_required_keys(self, engine):
        snap = make_snapshot()
        result = engine.assess(snap)
        summary = reasoning_snapshot_summary(result.snapshot)
        for key in ("frame_id", "reasoning_state", "situation",
                    "complexity", "overall_risk", "total_hazards",
                    "collision_threat", "reasoning_confidence"):
            assert key in summary

    def test_summary_values_match_snapshot(self, engine):
        snap = make_snapshot()
        result = engine.assess(snap)
        summary = reasoning_snapshot_summary(result.snapshot)
        assert summary["reasoning_state"] == result.snapshot.reasoning_state.value
        assert summary["total_hazards"] == result.snapshot.hazards.total_hazards


class TestSafeCopy:
    def test_copy_is_independent(self, engine):
        snap = make_snapshot(objects=[make_object()])
        result = engine.assess(snap)
        copy = safe_copy_reasoning_snapshot(result.snapshot)
        assert copy is not result.snapshot
        assert copy.reasoning_state == result.snapshot.reasoning_state

    def test_copy_does_not_mutate_original(self, engine):
        snap = make_snapshot()
        result = engine.assess(snap)
        original_state = result.snapshot.reasoning_state
        copy = safe_copy_reasoning_snapshot(result.snapshot)
        # Mutate copy (replace is needed since it's a dataclass)
        import dataclasses
        dataclasses.replace(copy, reasoning_state=ReasoningState.CRITICAL)
        # Original must be untouched
        assert result.snapshot.reasoning_state == original_state
