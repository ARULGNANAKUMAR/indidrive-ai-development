"""
Phase 8.1 | TTC Band Classification Tests
==========================================
Tests: immediate, near, moderate, distant, missing, invalid TTC.
"""
import pytest
from core.reasoning import TtcBand
from core.reasoning.hazard_analyzer import HazardAnalyzer
from core.world_model.world_model_types import NOT_AVAILABLE

from .conftest import make_snapshot, make_object, default_config


class TestTtcImmediate:
    def test_ttc_1s_immediate(self, default_config):
        analyzer = HazardAnalyzer(default_config)
        obj = make_object(ttc_s=1.0, ttc_status="FINITE", risk_level="CRITICAL")
        snap = make_snapshot(objects=[obj])
        hazards = analyzer.extract(snap)
        assert hazards[0].ttc_band == TtcBand.IMMEDIATE

    def test_ttc_0s_immediate(self, default_config):
        analyzer = HazardAnalyzer(default_config)
        obj = make_object(ttc_s=0.1, ttc_status="FINITE")
        snap = make_snapshot(objects=[obj])
        hazards = analyzer.extract(snap)
        assert hazards[0].ttc_band == TtcBand.IMMEDIATE

    def test_ttc_at_threshold_immediate(self, default_config):
        # 1.5s == ttc_immediate_s default
        analyzer = HazardAnalyzer(default_config)
        obj = make_object(ttc_s=1.5, ttc_status="FINITE")
        snap = make_snapshot(objects=[obj])
        hazards = analyzer.extract(snap)
        assert hazards[0].ttc_band == TtcBand.IMMEDIATE


class TestTtcNearTerm:
    def test_ttc_2s_near(self, default_config):
        analyzer = HazardAnalyzer(default_config)
        obj = make_object(ttc_s=2.0, ttc_status="FINITE")
        snap = make_snapshot(objects=[obj])
        hazards = analyzer.extract(snap)
        assert hazards[0].ttc_band == TtcBand.NEAR_TERM

    def test_ttc_3s_near_term(self, default_config):
        analyzer = HazardAnalyzer(default_config)
        obj = make_object(ttc_s=3.0, ttc_status="FINITE")
        snap = make_snapshot(objects=[obj])
        hazards = analyzer.extract(snap)
        assert hazards[0].ttc_band == TtcBand.NEAR_TERM


class TestTtcModerate:
    def test_ttc_4s_moderate(self, default_config):
        analyzer = HazardAnalyzer(default_config)
        obj = make_object(ttc_s=4.0, ttc_status="FINITE")
        snap = make_snapshot(objects=[obj])
        hazards = analyzer.extract(snap)
        assert hazards[0].ttc_band == TtcBand.MODERATE

    def test_ttc_6s_moderate(self, default_config):
        analyzer = HazardAnalyzer(default_config)
        obj = make_object(ttc_s=6.0, ttc_status="FINITE")
        snap = make_snapshot(objects=[obj])
        hazards = analyzer.extract(snap)
        assert hazards[0].ttc_band == TtcBand.MODERATE


class TestTtcDistant:
    def test_ttc_10s_distant(self, default_config):
        analyzer = HazardAnalyzer(default_config)
        obj = make_object(ttc_s=10.0, ttc_status="FINITE")
        snap = make_snapshot(objects=[obj])
        hazards = analyzer.extract(snap)
        assert hazards[0].ttc_band == TtcBand.DISTANT

    def test_ttc_20s_distant(self, default_config):
        analyzer = HazardAnalyzer(default_config)
        obj = make_object(ttc_s=20.0, ttc_status="FINITE")
        snap = make_snapshot(objects=[obj])
        hazards = analyzer.extract(snap)
        assert hazards[0].ttc_band == TtcBand.DISTANT


class TestTtcMissing:
    def test_no_ttc_unavailable(self, default_config):
        analyzer = HazardAnalyzer(default_config)
        obj = make_object(ttc_s=None, ttc_status=NOT_AVAILABLE)
        snap = make_snapshot(objects=[obj])
        hazards = analyzer.extract(snap)
        assert hazards[0].ttc_band == TtcBand.UNAVAILABLE

    def test_no_ttc_not_zero_risk(self, default_config):
        """Unavailable TTC must not be treated as zero risk in priority."""
        from core.reasoning.hazard_prioritizer import HazardPrioritizer
        from core.reasoning.reasoning_types import HazardEntry, HazardCategory, RiskLevel
        prioritizer = HazardPrioritizer(default_config)
        h = HazardEntry(
            hazard_id="x", hazard_category=HazardCategory.CAR,
            risk_level=RiskLevel.MEDIUM, ttc_band=TtcBand.UNAVAILABLE,
            ttc_s=None, distance_m=20.0, collision_likelihood=None,
            confidence=0.5, uncertainty=0.5,
        )
        scored = prioritizer.prioritize([h])
        # Priority > 0 even with missing TTC and likelihood
        assert scored[0].priority_score > 0.0

    def test_no_collision_status_band(self, default_config):
        analyzer = HazardAnalyzer(default_config)
        obj = make_object(ttc_s=None, ttc_status="NO_COLLISION")
        snap = make_snapshot(objects=[obj])
        hazards = analyzer.extract(snap)
        assert hazards[0].ttc_band == TtcBand.NO_COLLISION


class TestTtcInvalid:
    def test_negative_ttc_unavailable(self, default_config):
        """Negative TTC from upstream should not crash."""
        analyzer = HazardAnalyzer(default_config)
        obj = make_object(ttc_s=-1.0, ttc_status="FINITE")
        snap = make_snapshot(objects=[obj])
        hazards = analyzer.extract(snap)
        # Should not raise; band may be IMMEDIATE (≤ threshold) or UNAVAILABLE
        assert hazards[0].ttc_band in list(TtcBand)

    def test_ttc_value_preserved(self, default_config):
        analyzer = HazardAnalyzer(default_config)
        obj = make_object(ttc_s=2.5, ttc_status="FINITE")
        snap = make_snapshot(objects=[obj])
        hazards = analyzer.extract(snap)
        assert hazards[0].ttc_s == 2.5
