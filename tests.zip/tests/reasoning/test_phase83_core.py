"""
IndiDrive AI — Phase 8.3 | Core Tests
======================================
Tests for Decision & Action Abstraction Layer.

Covers:
  - Basic: empty, normal, single hazard, multiple hazards, partial/degraded WM
  - Requirements: all major types
  - Priority: low/high risk, multiple priorities, tie-breaking
  - Uncertainty: high confidence, low confidence, missing prediction, degraded
  - Evidence type: observed, inferred, predicted, combined, unknown
  - Multi-hazard: compound scenarios
  - Indian road cases: 8 specific scenarios
  - Negative: no forbidden fields in output
  - Determinism: same input → same output across multiple runs
"""
import sys
import os
import time
import unittest

# Ensure project root is on path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..'))

from core.reasoning import (
    ActionAbstractionEngine,
    ActionAbstractionConfig,
    RequirementType,
    ResponseFamily,
    AbstractUrgency,
    AbstractSeverity,
    EvidenceType,
)
from core.reasoning.action_abstraction_validator import ActionAbstractionValidator
from core.reasoning.action_abstraction_snapshot import (
    abstraction_snapshot_summary,
    abstraction_snapshot_to_json,
    find_requirement_by_type,
)
from core.reasoning.reasoning_types import (
    HazardCategory, RiskLevel, TtcBand,
    SituationCategory, ReasoningState,
    WorldCompletenessLevel,
)
from core.reasoning.behavior_types import (
    BehaviorInteractionType, InteractionSeverity,
    TimeRelevance, EvidenceClass, IntentType,
)
from core.world_model.world_model_types import WorldModelStatus, InputModuleStatus

from tests.reasoning.test_helpers_83 import (
    make_world_model, make_anomaly,
    make_reasoning_snapshot, make_hazard, make_hazard_summary,
    make_behavior_state, make_interaction, make_intent,
)


# ---------------------------------------------------------------------------
# Forbidden fields — Phase 8.3 must NEVER produce these
# ---------------------------------------------------------------------------
FORBIDDEN_KEYS = {
    "steering", "throttle", "brake", "path_points", "waypoints",
    "trajectory", "steering_angle", "target_speed", "lane_change_command",
    "throttle_cmd", "brake_cmd", "acceleration_cmd", "steer_cmd",
}


def _has_forbidden(d: dict) -> list:
    """Recursively check for forbidden keys in a dict."""
    found = []
    for k, v in d.items():
        if k in FORBIDDEN_KEYS:
            found.append(k)
        if isinstance(v, dict):
            found.extend(_has_forbidden(v))
        elif isinstance(v, list):
            for item in v:
                if isinstance(item, dict):
                    found.extend(_has_forbidden(item))
    return found


# ---------------------------------------------------------------------------
# Basic tests
# ---------------------------------------------------------------------------

class TestBasicInputs(unittest.TestCase):

    def setUp(self):
        self.engine = ActionAbstractionEngine()

    def test_none_situation_state(self):
        """Empty input (no situation state) → degraded result, DEGRADED_OPERATION."""
        result = self.engine.generate()
        self.assertEqual(result.status, "empty")
        snap = result.snapshot
        self.assertEqual(snap.response_family, ResponseFamily.DEGRADED)
        self.assertTrue(snap.degraded)
        self.assertTrue(snap.any_safety_critical)
        req_types = [r.requirement_type for r in snap.requirements]
        self.assertIn(RequirementType.DEGRADED_OPERATION, req_types)

    def test_empty_world_no_hazards(self):
        """Normal road, no hazards → NORMAL_PROGRESS."""
        sit = make_reasoning_snapshot(
            reasoning_state=ReasoningState.NORMAL,
            situation_category=SituationCategory.OPEN_ROAD,
            overall_risk=RiskLevel.LOW,
            collision_threat=False,
            uncertainty=0.15,
            confidence=0.90,
        )
        world = make_world_model(completeness=0.90)
        result = self.engine.generate(situation_state=sit, world_model=world)
        self.assertIn(result.status, ("ok", "degraded"))
        snap = result.snapshot
        req_types = [r.requirement_type for r in snap.requirements]
        self.assertIn(RequirementType.NORMAL_PROGRESS, req_types)
        self.assertFalse(snap.any_safety_critical)

    def test_one_hazard_medium_risk(self):
        """One medium-risk hazard → MONITOR_DYNAMIC_OBJECT, not collision avoidance."""
        hazard = make_hazard(
            hazard_id="car_1",
            category=HazardCategory.CAR,
            risk=RiskLevel.MEDIUM,
            ttc_band=TtcBand.MODERATE,
            ttc_s=5.0,
            collision_likelihood=0.2,
            predicted_conflict=False,
            is_moving=True,
        )
        sit = make_reasoning_snapshot(
            overall_risk=RiskLevel.MEDIUM,
            collision_threat=False,
            hazards=make_hazard_summary([hazard]),
        )
        result = self.engine.generate(situation_state=sit)
        snap = result.snapshot
        req_types = [r.requirement_type for r in snap.requirements]
        self.assertNotIn(RequirementType.COLLISION_AVOIDANCE_REQUIRED, req_types)
        self.assertNotIn(RequirementType.NORMAL_PROGRESS, req_types)

    def test_multiple_hazards(self):
        """Multiple hazards → multiple requirements, bounded list."""
        hazards = [
            make_hazard("h1", HazardCategory.PEDESTRIAN, RiskLevel.HIGH,
                        TtcBand.NEAR_TERM, 2.5, 0.6, True, True, True),
            make_hazard("h2", HazardCategory.CAR, RiskLevel.MEDIUM,
                        TtcBand.MODERATE, 5.0, 0.3, False, True, False),
        ]
        sit = make_reasoning_snapshot(
            reasoning_state=ReasoningState.HIGH_RISK,
            overall_risk=RiskLevel.HIGH,
            collision_threat=True,
            hazards=make_hazard_summary(hazards),
            has_vru=True,
        )
        result = self.engine.generate(situation_state=sit)
        snap = result.snapshot
        self.assertGreater(snap.requirement_count, 1)
        self.assertLessEqual(snap.requirement_count, self.engine.config.max_requirements)

    def test_partial_world_model(self):
        """Partial world model → still generates requirements, no crash."""
        world = make_world_model(
            status=WorldModelStatus.PARTIAL,
            completeness=0.45,
            confidence=0.55,
            prediction_status=InputModuleStatus.DEGRADED,
        )
        sit = make_reasoning_snapshot(uncertainty=0.45, confidence=0.55)
        result = self.engine.generate(situation_state=sit, world_model=world)
        self.assertTrue(result.is_valid)
        self.assertIsNotNone(result.snapshot)

    def test_degraded_world_model(self):
        """Degraded world model → HANDLE_UNCERTAINTY or DEGRADED_OPERATION."""
        world = make_world_model(
            status=WorldModelStatus.DEGRADED,
            completeness=0.15,
            confidence=0.2,
            uncertainty=0.85,
        )
        sit = make_reasoning_snapshot(
            uncertainty=0.70,
            sensor_degradation=True,
        )
        result = self.engine.generate(situation_state=sit, world_model=world)
        snap = result.snapshot
        req_types = [r.requirement_type for r in snap.requirements]
        self.assertTrue(
            RequirementType.DEGRADED_OPERATION in req_types or
            RequirementType.HANDLE_UNCERTAINTY in req_types
        )

    def test_invalid_world_model_ignored(self):
        """INVALID world model → ignored safely, no crash."""
        world = make_world_model(status=WorldModelStatus.INVALID)
        sit = make_reasoning_snapshot()
        result = self.engine.generate(situation_state=sit, world_model=world)
        self.assertTrue(result.is_valid)

    def test_behavior_state_none(self):
        """No behavior state → degrades gracefully, still generates."""
        sit = make_reasoning_snapshot()
        result = self.engine.generate(situation_state=sit, behavior_reasoning=None)
        self.assertTrue(result.is_valid)


# ---------------------------------------------------------------------------
# Requirement type tests
# ---------------------------------------------------------------------------

class TestRequirementTypes(unittest.TestCase):

    def setUp(self):
        self.engine = ActionAbstractionEngine()

    def test_normal_progress(self):
        sit = make_reasoning_snapshot(
            overall_risk=RiskLevel.LOW,
            collision_threat=False,
            uncertainty=0.15,
            confidence=0.9,
            world_completeness=WorldCompletenessLevel.FULL,
        )
        world = make_world_model(completeness=0.9, status=WorldModelStatus.OK)
        result = self.engine.generate(situation_state=sit, world_model=world)
        snap = result.snapshot
        req_types = [r.requirement_type for r in snap.requirements]
        self.assertIn(RequirementType.NORMAL_PROGRESS, req_types)

    def test_collision_avoidance_required(self):
        hazard = make_hazard(
            hazard_id="veh_1",
            category=HazardCategory.CAR,
            risk=RiskLevel.CRITICAL,
            ttc_band=TtcBand.IMMEDIATE,
            ttc_s=0.8,
            collision_likelihood=0.9,
            predicted_conflict=True,
        )
        sit = make_reasoning_snapshot(
            reasoning_state=ReasoningState.CRITICAL,
            overall_risk=RiskLevel.CRITICAL,
            collision_threat=True,
            time_criticality=TtcBand.IMMEDIATE,
            hazards=make_hazard_summary([hazard]),
        )
        result = self.engine.generate(situation_state=sit)
        snap = result.snapshot
        req_types = [r.requirement_type for r in snap.requirements]
        self.assertIn(RequirementType.COLLISION_AVOIDANCE_REQUIRED, req_types)
        self.assertTrue(snap.any_safety_critical)

    def test_handle_vulnerable_user(self):
        hazard = make_hazard(
            hazard_id="ped_1",
            category=HazardCategory.PEDESTRIAN,
            risk=RiskLevel.HIGH,
            ttc_band=TtcBand.NEAR_TERM,
            ttc_s=2.5,
            collision_likelihood=0.55,
            predicted_conflict=True,
            is_vulnerable=True,
        )
        sit = make_reasoning_snapshot(
            overall_risk=RiskLevel.HIGH,
            collision_threat=True,
            hazards=make_hazard_summary([hazard]),
            has_vru=True,
        )
        result = self.engine.generate(situation_state=sit)
        snap = result.snapshot
        req_types = [r.requirement_type for r in snap.requirements]
        self.assertIn(RequirementType.HANDLE_VULNERABLE_USER, req_types)

    def test_handle_road_hazard(self):
        hazard = make_hazard(
            hazard_id="pothole_1",
            category=HazardCategory.POTHOLE,
            risk=RiskLevel.HIGH,
            ttc_band=TtcBand.NEAR_TERM,
            ttc_s=2.0,
            collision_likelihood=0.6,
            predicted_conflict=True,
        )
        sit = make_reasoning_snapshot(
            overall_risk=RiskLevel.HIGH,
            collision_threat=False,
            hazards=make_hazard_summary([hazard]),
        )
        result = self.engine.generate(situation_state=sit)
        snap = result.snapshot
        req_types = [r.requirement_type for r in snap.requirements]
        self.assertIn(RequirementType.HANDLE_ROAD_HAZARD, req_types)

    def test_handle_narrow_road(self):
        sit = make_reasoning_snapshot(
            is_narrow=True,
            available_width_m=3.8,
        )
        result = self.engine.generate(situation_state=sit)
        snap = result.snapshot
        req_types = [r.requirement_type for r in snap.requirements]
        self.assertIn(RequirementType.HANDLE_NARROW_ROAD, req_types)

    def test_handle_intersection(self):
        sit = make_reasoning_snapshot(
            situation_category=SituationCategory.INTERSECTION_COMPLEXITY,
            is_intersection=True,
        )
        result = self.engine.generate(situation_state=sit)
        snap = result.snapshot
        req_types = [r.requirement_type for r in snap.requirements]
        self.assertIn(RequirementType.HANDLE_INTERSECTION, req_types)

    def test_handle_merge(self):
        sit = make_reasoning_snapshot(
            situation_category=SituationCategory.MERGE_COMPLEXITY,
        )
        result = self.engine.generate(situation_state=sit)
        snap = result.snapshot
        req_types = [r.requirement_type for r in snap.requirements]
        self.assertIn(RequirementType.HANDLE_MERGE, req_types)

    def test_handle_trajectory_conflict(self):
        interaction = make_interaction(
            entity_a="ego",
            entity_b="veh_1",
            interaction_type=BehaviorInteractionType.CROSSING,
            severity=InteractionSeverity.HIGH,
            time_relevance=TimeRelevance.NEAR_TERM,
            confidence=0.80,
        )
        behavior = make_behavior_state(dominant_interactions=[interaction])
        sit = make_reasoning_snapshot(overall_risk=RiskLevel.HIGH)
        result = self.engine.generate(situation_state=sit, behavior_reasoning=behavior)
        snap = result.snapshot
        req_types = [r.requirement_type for r in snap.requirements]
        self.assertIn(RequirementType.HANDLE_TRAJECTORY_CONFLICT, req_types)

    def test_handle_uncertainty(self):
        sit = make_reasoning_snapshot(
            uncertainty=0.75,
            prediction_unavailable=True,
        )
        result = self.engine.generate(situation_state=sit)
        snap = result.snapshot
        req_types = [r.requirement_type for r in snap.requirements]
        self.assertIn(RequirementType.HANDLE_UNCERTAINTY, req_types)

    def test_degraded_operation(self):
        sit = make_reasoning_snapshot(
            uncertainty=0.90,
            sensor_degradation=True,
        )
        result = self.engine.generate(situation_state=sit)
        snap = result.snapshot
        req_types = [r.requirement_type for r in snap.requirements]
        self.assertIn(RequirementType.DEGRADED_OPERATION, req_types)

    def test_monitor_dynamic_object(self):
        hazard = make_hazard(
            hazard_id="car_2",
            category=HazardCategory.CAR,
            risk=RiskLevel.MEDIUM,
            ttc_band=TtcBand.MODERATE,
            ttc_s=5.0,
            collision_likelihood=0.2,
            predicted_conflict=False,
            is_moving=True,
        )
        sit = make_reasoning_snapshot(
            overall_risk=RiskLevel.MEDIUM,
            hazards=make_hazard_summary([hazard]),
        )
        result = self.engine.generate(situation_state=sit)
        snap = result.snapshot
        req_types = [r.requirement_type for r in snap.requirements]
        self.assertIn(RequirementType.MONITOR_DYNAMIC_OBJECT, req_types)

    def test_monitor_unpredictable_object(self):
        hazard = make_hazard(
            hazard_id="cattle_1",
            category=HazardCategory.CATTLE,
            risk=RiskLevel.MEDIUM,
            ttc_band=TtcBand.MODERATE,
            ttc_s=4.0,
            is_moving=True,
            is_vulnerable=True,
        )
        sit = make_reasoning_snapshot(
            overall_risk=RiskLevel.MEDIUM,
            hazards=make_hazard_summary([hazard]),
            has_cattle=True,
        )
        result = self.engine.generate(situation_state=sit)
        snap = result.snapshot
        req_types = [r.requirement_type for r in snap.requirements]
        self.assertIn(RequirementType.MONITOR_UNPREDICTABLE_OBJECT, req_types)


# ---------------------------------------------------------------------------
# Priority tests
# ---------------------------------------------------------------------------

class TestPriority(unittest.TestCase):

    def setUp(self):
        self.engine = ActionAbstractionEngine()

    def test_low_risk_lower_priority(self):
        hazard = make_hazard(
            category=HazardCategory.CAR,
            risk=RiskLevel.LOW,
            ttc_band=TtcBand.DISTANT,
            ttc_s=10.0,
            collision_likelihood=0.05,
        )
        sit = make_reasoning_snapshot(
            overall_risk=RiskLevel.LOW,
            hazards=make_hazard_summary([hazard]),
        )
        result = self.engine.generate(situation_state=sit)
        snap = result.snapshot
        for req in snap.requirements:
            if req.requirement_type not in (
                RequirementType.NORMAL_PROGRESS,
                RequirementType.MAINTAIN_SAFE_SPACE,
            ):
                self.assertLess(req.priority, 0.7)

    def test_critical_risk_high_priority(self):
        hazard = make_hazard(
            category=HazardCategory.CAR,
            risk=RiskLevel.CRITICAL,
            ttc_band=TtcBand.IMMEDIATE,
            ttc_s=0.9,
            collision_likelihood=0.92,
            predicted_conflict=True,
        )
        sit = make_reasoning_snapshot(
            reasoning_state=ReasoningState.CRITICAL,
            overall_risk=RiskLevel.CRITICAL,
            collision_threat=True,
            hazards=make_hazard_summary([hazard]),
        )
        result = self.engine.generate(situation_state=sit)
        snap = result.snapshot
        collision_req = find_requirement_by_type(
            snap, RequirementType.COLLISION_AVOIDANCE_REQUIRED
        )
        self.assertIsNotNone(collision_req)
        self.assertGreater(collision_req.priority, 0.5)

    def test_multiple_priorities_ordering(self):
        """Requirements are ordered: safety-critical first, then by priority."""
        hazard = make_hazard(
            category=HazardCategory.CAR,
            risk=RiskLevel.CRITICAL,
            ttc_band=TtcBand.IMMEDIATE,
            ttc_s=1.0,
            collision_likelihood=0.85,
            predicted_conflict=True,
        )
        sit = make_reasoning_snapshot(
            overall_risk=RiskLevel.CRITICAL,
            collision_threat=True,
            hazards=make_hazard_summary([hazard]),
            is_narrow=True,
            available_width_m=3.5,
        )
        result = self.engine.generate(situation_state=sit)
        snap = result.snapshot
        reqs = list(snap.requirements)
        # Safety-critical must come before non-safety-critical
        saw_non_critical = False
        for req in reqs:
            if not req.is_safety_critical:
                saw_non_critical = True
            elif saw_non_critical:
                self.fail("Safety-critical requirement after non-safety-critical")

    def test_deterministic_tie_break(self):
        """Two runs with identical input → identical requirement ordering."""
        sit = make_reasoning_snapshot(
            overall_risk=RiskLevel.HIGH,
            is_narrow=True,
            available_width_m=3.8,
            is_intersection=True,
        )
        r1 = self.engine.generate(situation_state=sit)
        r2 = self.engine.generate(situation_state=sit)
        types1 = [r.requirement_type.value for r in r1.snapshot.requirements]
        types2 = [r.requirement_type.value for r in r2.snapshot.requirements]
        self.assertEqual(types1, types2)

    def test_severity_vs_urgency_independent(self):
        """A requirement can have HIGH severity but LOW urgency."""
        hazard = make_hazard(
            category=HazardCategory.ROAD_OBSTACLE,
            risk=RiskLevel.HIGH,
            ttc_band=TtcBand.DISTANT,
            ttc_s=9.0,
            collision_likelihood=0.55,
            predicted_conflict=True,
        )
        sit = make_reasoning_snapshot(
            overall_risk=RiskLevel.HIGH,
            collision_threat=True,
            hazards=make_hazard_summary([hazard]),
        )
        result = self.engine.generate(situation_state=sit)
        snap = result.snapshot
        # At least one req should have HIGH severity
        severities = [r.severity for r in snap.requirements]
        self.assertIn(AbstractSeverity.HIGH, severities)


# ---------------------------------------------------------------------------
# Uncertainty tests
# ---------------------------------------------------------------------------

class TestUncertainty(unittest.TestCase):

    def setUp(self):
        self.engine = ActionAbstractionEngine()

    def test_high_confidence_no_uncertainty_req(self):
        sit = make_reasoning_snapshot(
            uncertainty=0.10,
            confidence=0.95,
            prediction_unavailable=False,
            sensor_degradation=False,
        )
        world = make_world_model(completeness=0.92)
        result = self.engine.generate(situation_state=sit, world_model=world)
        snap = result.snapshot
        req_types = [r.requirement_type for r in snap.requirements]
        self.assertNotIn(RequirementType.HANDLE_UNCERTAINTY, req_types)
        self.assertNotIn(RequirementType.DEGRADED_OPERATION, req_types)

    def test_low_confidence_uncertainty_present(self):
        sit = make_reasoning_snapshot(
            uncertainty=0.72,
            confidence=0.28,
        )
        result = self.engine.generate(situation_state=sit)
        snap = result.snapshot
        req_types = [r.requirement_type for r in snap.requirements]
        self.assertIn(RequirementType.HANDLE_UNCERTAINTY, req_types)

    def test_high_uncertainty_value(self):
        sit = make_reasoning_snapshot(uncertainty=0.88, sensor_degradation=False)
        result = self.engine.generate(situation_state=sit)
        snap = result.snapshot
        req_types = [r.requirement_type for r in snap.requirements]
        self.assertTrue(
            RequirementType.HANDLE_UNCERTAINTY in req_types or
            RequirementType.DEGRADED_OPERATION in req_types
        )

    def test_missing_prediction_triggers_uncertainty(self):
        sit = make_reasoning_snapshot(prediction_unavailable=True, uncertainty=0.35)
        result = self.engine.generate(situation_state=sit)
        snap = result.snapshot
        req_types = [r.requirement_type for r in snap.requirements]
        self.assertIn(RequirementType.HANDLE_UNCERTAINTY, req_types)

    def test_missing_road_boundaries_uncertainty(self):
        sit = make_reasoning_snapshot(road_info_unavailable=True, uncertainty=0.40)
        result = self.engine.generate(situation_state=sit)
        snap = result.snapshot
        req_types = [r.requirement_type for r in snap.requirements]
        self.assertIn(RequirementType.HANDLE_UNCERTAINTY, req_types)

    def test_sensor_degradation_triggers_degraded(self):
        sit = make_reasoning_snapshot(
            sensor_degradation=True,
            uncertainty=0.88,
        )
        result = self.engine.generate(situation_state=sit)
        snap = result.snapshot
        req_types = [r.requirement_type for r in snap.requirements]
        self.assertIn(RequirementType.DEGRADED_OPERATION, req_types)

    def test_conflicting_behavior_hypotheses(self):
        """Degraded behavior state → HANDLE_UNCERTAINTY."""
        sit = make_reasoning_snapshot(uncertainty=0.45)
        behavior = make_behavior_state(degraded=True, confidence=0.3, uncertainty=0.7)
        result = self.engine.generate(situation_state=sit, behavior_reasoning=behavior)
        snap = result.snapshot
        req_types = [r.requirement_type for r in snap.requirements]
        self.assertIn(RequirementType.HANDLE_UNCERTAINTY, req_types)

    def test_confidence_preserved_in_requirement(self):
        """Every requirement has confidence and uncertainty in [0, 1]."""
        sit = make_reasoning_snapshot(uncertainty=0.5, confidence=0.5)
        result = self.engine.generate(situation_state=sit)
        for req in result.snapshot.requirements:
            self.assertGreaterEqual(req.confidence, 0.0)
            self.assertLessEqual(req.confidence, 1.0)
            self.assertGreaterEqual(req.uncertainty, 0.0)
            self.assertLessEqual(req.uncertainty, 1.0)


# ---------------------------------------------------------------------------
# Evidence type tests
# ---------------------------------------------------------------------------

class TestEvidenceType(unittest.TestCase):

    def setUp(self):
        self.engine = ActionAbstractionEngine()

    def test_observed_road_hazard(self):
        hazard = make_hazard(
            category=HazardCategory.DEBRIS,
            risk=RiskLevel.HIGH,
            ttc_band=TtcBand.NEAR_TERM,
            ttc_s=2.5,
            collision_likelihood=0.6,
            predicted_conflict=True,
        )
        sit = make_reasoning_snapshot(
            overall_risk=RiskLevel.HIGH,
            collision_threat=False,
            hazards=make_hazard_summary([hazard]),
        )
        result = self.engine.generate(situation_state=sit)
        road_req = find_requirement_by_type(result.snapshot, RequirementType.HANDLE_ROAD_HAZARD)
        if road_req:
            self.assertEqual(road_req.evidence_type, EvidenceType.OBSERVED)

    def test_inferred_trajectory_conflict(self):
        interaction = make_interaction(
            interaction_type=BehaviorInteractionType.CROSSING,
            severity=InteractionSeverity.HIGH,
            state=EvidenceClass.INFERRED,
        )
        behavior = make_behavior_state(dominant_interactions=[interaction])
        sit = make_reasoning_snapshot()
        result = self.engine.generate(situation_state=sit, behavior_reasoning=behavior)
        traj_req = find_requirement_by_type(
            result.snapshot, RequirementType.HANDLE_TRAJECTORY_CONFLICT
        )
        if traj_req:
            self.assertEqual(traj_req.evidence_type, EvidenceType.INFERRED)

    def test_predicted_based_on_intent(self):
        """VRU with predicted crossing intent → COMBINED evidence type."""
        hazard = make_hazard(
            hazard_id="ped_1",
            category=HazardCategory.PEDESTRIAN,
            risk=RiskLevel.HIGH,
            ttc_band=TtcBand.NEAR_TERM,
            ttc_s=2.5,
            collision_likelihood=0.55,
            predicted_conflict=True,
            is_vulnerable=True,
        )
        intent = make_intent(
            entity_id="ped_1",
            intent_type=IntentType.POSSIBLE_CROSSING,
            confidence=0.75,
            ev_class=EvidenceClass.PREDICTED,
        )
        behavior = make_behavior_state(intent_hypotheses=[intent])
        sit = make_reasoning_snapshot(
            overall_risk=RiskLevel.HIGH,
            collision_threat=True,
            hazards=make_hazard_summary([hazard]),
            has_vru=True,
        )
        result = self.engine.generate(situation_state=sit, behavior_reasoning=behavior)
        vru_req = find_requirement_by_type(
            result.snapshot, RequirementType.HANDLE_VULNERABLE_USER
        )
        if vru_req:
            self.assertIn(
                vru_req.evidence_type,
                (EvidenceType.COMBINED, EvidenceType.OBSERVED),
            )

    def test_unknown_evidence_when_no_data(self):
        """DEGRADED_OPERATION from sensor failure → EvidenceType.OBSERVED."""
        sit = make_reasoning_snapshot(
            sensor_degradation=True,
            uncertainty=0.9,
        )
        result = self.engine.generate(situation_state=sit)
        deg_req = find_requirement_by_type(result.snapshot, RequirementType.DEGRADED_OPERATION)
        if deg_req:
            self.assertNotEqual(deg_req.evidence_type, EvidenceType.UNKNOWN)


# ---------------------------------------------------------------------------
# Multi-hazard tests
# ---------------------------------------------------------------------------

class TestMultiHazard(unittest.TestCase):

    def setUp(self):
        self.engine = ActionAbstractionEngine()

    def test_pedestrian_and_motorcycle(self):
        hazards = [
            make_hazard("ped_1", HazardCategory.PEDESTRIAN, RiskLevel.HIGH,
                        TtcBand.NEAR_TERM, 2.0, 0.65, True, True, True),
            make_hazard("moto_1", HazardCategory.MOTORCYCLE, RiskLevel.MEDIUM,
                        TtcBand.MODERATE, 4.5, 0.35, False, True, False),
        ]
        sit = make_reasoning_snapshot(
            overall_risk=RiskLevel.HIGH,
            collision_threat=True,
            hazards=make_hazard_summary(hazards),
            has_vru=True,
        )
        result = self.engine.generate(situation_state=sit)
        snap = result.snapshot
        req_types = [r.requirement_type for r in snap.requirements]
        self.assertIn(RequirementType.HANDLE_VULNERABLE_USER, req_types)
        self.assertGreater(snap.requirement_count, 1)

    def test_cattle_and_vehicle(self):
        hazards = [
            make_hazard("cattle_1", HazardCategory.CATTLE, RiskLevel.HIGH,
                        TtcBand.NEAR_TERM, 2.5, 0.55, True, True, True),
            make_hazard("veh_1", HazardCategory.CAR, RiskLevel.HIGH,
                        TtcBand.NEAR_TERM, 2.8, 0.60, True, True, False),
        ]
        sit = make_reasoning_snapshot(
            overall_risk=RiskLevel.HIGH,
            collision_threat=True,
            hazards=make_hazard_summary(hazards),
            has_cattle=True,
        )
        result = self.engine.generate(situation_state=sit)
        snap = result.snapshot
        req_types = [r.requirement_type for r in snap.requirements]
        self.assertIn(RequirementType.MONITOR_UNPREDICTABLE_OBJECT, req_types)

    def test_pothole_and_narrow_road(self):
        hazard = make_hazard(
            "pothole_1", HazardCategory.POTHOLE, RiskLevel.HIGH,
            TtcBand.NEAR_TERM, 2.0, 0.6, True,
        )
        sit = make_reasoning_snapshot(
            overall_risk=RiskLevel.HIGH,
            is_narrow=True,
            available_width_m=3.5,
            hazards=make_hazard_summary([hazard]),
        )
        result = self.engine.generate(situation_state=sit)
        snap = result.snapshot
        req_types = [r.requirement_type for r in snap.requirements]
        self.assertIn(RequirementType.HANDLE_ROAD_HAZARD, req_types)
        self.assertIn(RequirementType.HANDLE_NARROW_ROAD, req_types)

    def test_pedestrian_and_road_anomaly(self):
        hazards = [
            make_hazard("ped_1", HazardCategory.PEDESTRIAN, RiskLevel.HIGH,
                        TtcBand.NEAR_TERM, 2.5, 0.60, True, True, True),
            make_hazard("debris_1", HazardCategory.DEBRIS, RiskLevel.MEDIUM,
                        TtcBand.MODERATE, 5.0, 0.3, False),
        ]
        sit = make_reasoning_snapshot(
            overall_risk=RiskLevel.HIGH,
            collision_threat=True,
            hazards=make_hazard_summary(hazards),
            has_vru=True,
        )
        result = self.engine.generate(situation_state=sit)
        snap = result.snapshot
        req_types = [r.requirement_type for r in snap.requirements]
        self.assertIn(RequirementType.HANDLE_VULNERABLE_USER, req_types)

    def test_dense_traffic_intersection(self):
        sit = make_reasoning_snapshot(
            overall_risk=RiskLevel.HIGH,
            situation_category=SituationCategory.DENSE_TRAFFIC,
            is_intersection=True,
            traffic_density="HIGH",
            has_vru=True,
        )
        result = self.engine.generate(situation_state=sit)
        snap = result.snapshot
        req_types = [r.requirement_type for r in snap.requirements]
        self.assertIn(RequirementType.HANDLE_INTERSECTION, req_types)

    def test_multiple_simultaneous_conflicts(self):
        """Three concurrent collision threats — bounded, not unbounded."""
        hazards = [
            make_hazard(f"veh_{i}", HazardCategory.CAR, RiskLevel.CRITICAL,
                        TtcBand.IMMEDIATE, 1.0 + i * 0.3, 0.85, True)
            for i in range(3)
        ]
        sit = make_reasoning_snapshot(
            overall_risk=RiskLevel.CRITICAL,
            collision_threat=True,
            hazards=make_hazard_summary(hazards),
        )
        result = self.engine.generate(situation_state=sit)
        snap = result.snapshot
        self.assertLessEqual(snap.requirement_count, self.engine.config.max_requirements)


# ---------------------------------------------------------------------------
# Indian road scenario tests
# ---------------------------------------------------------------------------

class TestIndianRoadScenarios(unittest.TestCase):
    """
    Eight specific Indian road scenarios.
    Requirements are derived from actual input evidence — not scenario name.
    """

    def setUp(self):
        self.engine = ActionAbstractionEngine()

    def test_1_unmarked_village_road(self):
        """Unmarked narrow village road → HANDLE_NARROW_ROAD, MAINTAIN_DRIVABLE_REGION."""
        world = make_world_model(
            road_type="VILLAGE_ROAD",
            available_width_m=3.2,
        )
        sit = make_reasoning_snapshot(
            situation_category=SituationCategory.UNSTRUCTURED_ROAD,
            is_narrow=True,
            available_width_m=3.2,
            road_info_unavailable=True,
            uncertainty=0.55,
        )
        result = self.engine.generate(situation_state=sit, world_model=world)
        snap = result.snapshot
        req_types = [r.requirement_type for r in snap.requirements]
        self.assertIn(RequirementType.HANDLE_NARROW_ROAD, req_types)

    def test_2_dense_market(self):
        """Dense market → HANDLE_VULNERABLE_USER, MAINTAIN_SAFE_SPACE."""
        hazard = make_hazard(
            "ped_mkt", HazardCategory.PEDESTRIAN, RiskLevel.MEDIUM,
            TtcBand.MODERATE, 4.0, 0.35, False, True, True,
        )
        sit = make_reasoning_snapshot(
            situation_category=SituationCategory.DENSE_TRAFFIC,
            overall_risk=RiskLevel.MEDIUM,
            hazards=make_hazard_summary([hazard]),
            has_vru=True,
            has_roadside_activity=True,
            traffic_density="HIGH",
        )
        world = make_world_model(
            traffic_density="HIGH", vru_present=True, market_like=True
        )
        result = self.engine.generate(
            situation_state=sit, world_model=world
        )
        snap = result.snapshot
        req_types = [r.requirement_type for r in snap.requirements]
        self.assertIn(RequirementType.HANDLE_VULNERABLE_USER, req_types)

    def test_3_highway_merge(self):
        """Highway merge → HANDLE_MERGE, HANDLE_TRAJECTORY_CONFLICT."""
        interaction = make_interaction(
            entity_a="ego",
            entity_b="veh_merge",
            interaction_type=BehaviorInteractionType.MERGING,
            severity=InteractionSeverity.HIGH,
            time_relevance=TimeRelevance.NEAR_TERM,
        )
        sit = make_reasoning_snapshot(
            situation_category=SituationCategory.MERGE_COMPLEXITY,
            overall_risk=RiskLevel.HIGH,
        )
        behavior = make_behavior_state(dominant_interactions=[interaction])
        result = self.engine.generate(situation_state=sit, behavior_reasoning=behavior)
        snap = result.snapshot
        req_types = [r.requirement_type for r in snap.requirements]
        self.assertIn(RequirementType.HANDLE_MERGE, req_types)

    def test_4_busy_intersection(self):
        """Busy intersection with mixed traffic → HANDLE_INTERSECTION, MONITOR_DYNAMIC_OBJECT."""
        hazards = [
            make_hazard("auto_1", HazardCategory.AUTO_RICKSHAW, RiskLevel.MEDIUM,
                        TtcBand.MODERATE, 4.5, 0.3, False, True, False),
        ]
        sit = make_reasoning_snapshot(
            situation_category=SituationCategory.INTERSECTION_COMPLEXITY,
            is_intersection=True,
            overall_risk=RiskLevel.MEDIUM,
            hazards=make_hazard_summary(hazards),
            traffic_density="HIGH",
        )
        result = self.engine.generate(situation_state=sit)
        snap = result.snapshot
        req_types = [r.requirement_type for r in snap.requirements]
        self.assertIn(RequirementType.HANDLE_INTERSECTION, req_types)

    def test_5_sudden_cattle_crossing(self):
        """Sudden cattle crossing → MONITOR_UNPREDICTABLE_OBJECT, HANDLE_VULNERABLE_USER."""
        hazard = make_hazard(
            "cattle_sudden", HazardCategory.CATTLE, RiskLevel.HIGH,
            TtcBand.NEAR_TERM, 2.2, 0.60, True, True, True,
        )
        sit = make_reasoning_snapshot(
            overall_risk=RiskLevel.HIGH,
            collision_threat=True,
            hazards=make_hazard_summary([hazard]),
            has_cattle=True,
        )
        intent = make_intent(
            entity_id="cattle_sudden",
            intent_type=IntentType.POSSIBLE_CROSSING,
            confidence=0.65,
            ev_class=EvidenceClass.INFERRED,
        )
        behavior = make_behavior_state(intent_hypotheses=[intent])
        result = self.engine.generate(
            situation_state=sit, behavior_reasoning=behavior
        )
        snap = result.snapshot
        req_types = [r.requirement_type for r in snap.requirements]
        self.assertIn(RequirementType.MONITOR_UNPREDICTABLE_OBJECT, req_types)

    def test_6_wrong_side_traffic(self):
        """Wrong-side approaching vehicle → HANDLE_TRAJECTORY_CONFLICT."""
        interaction = make_interaction(
            entity_a="ego",
            entity_b="wrong_side_veh",
            interaction_type=BehaviorInteractionType.WRONG_SIDE_APPROACH,
            severity=InteractionSeverity.CRITICAL,
            time_relevance=TimeRelevance.IMMEDIATE,
            confidence=0.90,
        )
        sit = make_reasoning_snapshot(
            reasoning_state=ReasoningState.CRITICAL,
            overall_risk=RiskLevel.CRITICAL,
            collision_threat=True,
            has_wrong_side=True,
        )
        behavior = make_behavior_state(dominant_interactions=[interaction])
        result = self.engine.generate(situation_state=sit, behavior_reasoning=behavior)
        snap = result.snapshot
        req_types = [r.requirement_type for r in snap.requirements]
        self.assertIn(RequirementType.HANDLE_TRAJECTORY_CONFLICT, req_types)
        self.assertTrue(snap.any_safety_critical)

    def test_7_narrow_damaged_road(self):
        """Narrow road + pothole → HANDLE_NARROW_ROAD + HANDLE_ROAD_HAZARD."""
        anomaly = make_anomaly("pot_1", "POTHOLE", "HIGH", in_drivable_area=True)
        world = make_world_model(
            available_width_m=3.1,
            anomalies=[anomaly],
        )
        hazard = make_hazard(
            "pothole_narrow", HazardCategory.POTHOLE, RiskLevel.HIGH,
            TtcBand.NEAR_TERM, 2.5, 0.6, True,
        )
        sit = make_reasoning_snapshot(
            overall_risk=RiskLevel.HIGH,
            is_narrow=True,
            available_width_m=3.1,
            hazards=make_hazard_summary([hazard]),
        )
        result = self.engine.generate(situation_state=sit, world_model=world)
        snap = result.snapshot
        req_types = [r.requirement_type for r in snap.requirements]
        self.assertIn(RequirementType.HANDLE_NARROW_ROAD, req_types)
        self.assertIn(RequirementType.HANDLE_ROAD_HAZARD, req_types)

    def test_8_construction_area(self):
        """Construction zone → HANDLE_ROAD_HAZARD, MAINTAIN_DRIVABLE_REGION."""
        hazard = make_hazard(
            "construction_1", HazardCategory.CONSTRUCTION, RiskLevel.HIGH,
            TtcBand.NEAR_TERM, 3.0, 0.55, True,
        )
        anomaly = make_anomaly("con_1", "CONSTRUCTION", "HIGH", in_drivable_area=True)
        world = make_world_model(anomalies=[anomaly])
        sit = make_reasoning_snapshot(
            overall_risk=RiskLevel.HIGH,
            hazards=make_hazard_summary([hazard]),
        )
        result = self.engine.generate(situation_state=sit, world_model=world)
        snap = result.snapshot
        req_types = [r.requirement_type for r in snap.requirements]
        self.assertIn(RequirementType.HANDLE_ROAD_HAZARD, req_types)


# ---------------------------------------------------------------------------
# Negative tests — forbidden outputs
# ---------------------------------------------------------------------------

class TestNegativeForbiddenOutputs(unittest.TestCase):

    def setUp(self):
        self.engine = ActionAbstractionEngine()

    def _assert_no_forbidden(self, snap):
        d = snap.to_dict()
        forbidden = _has_forbidden(d)
        self.assertEqual(
            forbidden, [],
            f"Forbidden fields found in Phase 8.3 output: {forbidden}"
        )

    def test_no_forbidden_normal(self):
        sit = make_reasoning_snapshot()
        result = self.engine.generate(situation_state=sit)
        self._assert_no_forbidden(result.snapshot)

    def test_no_forbidden_collision(self):
        hazard = make_hazard(
            category=HazardCategory.CAR,
            risk=RiskLevel.CRITICAL,
            ttc_band=TtcBand.IMMEDIATE,
            ttc_s=0.9,
            collision_likelihood=0.92,
            predicted_conflict=True,
        )
        sit = make_reasoning_snapshot(
            overall_risk=RiskLevel.CRITICAL,
            collision_threat=True,
            hazards=make_hazard_summary([hazard]),
        )
        result = self.engine.generate(situation_state=sit)
        self._assert_no_forbidden(result.snapshot)

    def test_no_forbidden_degraded(self):
        result = self.engine.generate()  # no situation state
        self._assert_no_forbidden(result.snapshot)

    def test_no_forbidden_multi_hazard(self):
        hazards = [
            make_hazard("h1", HazardCategory.PEDESTRIAN, RiskLevel.HIGH,
                        TtcBand.NEAR_TERM, 2.0, 0.65, True, True, True),
            make_hazard("h2", HazardCategory.POTHOLE, RiskLevel.HIGH,
                        TtcBand.NEAR_TERM, 2.5, 0.55, True),
        ]
        sit = make_reasoning_snapshot(
            overall_risk=RiskLevel.HIGH,
            collision_threat=True,
            hazards=make_hazard_summary(hazards),
            is_narrow=True,
            available_width_m=3.5,
        )
        result = self.engine.generate(situation_state=sit)
        self._assert_no_forbidden(result.snapshot)

    def test_snapshot_has_no_path_fields(self):
        sit = make_reasoning_snapshot()
        snap = self.engine.generate(situation_state=sit).snapshot
        d = snap.to_dict()
        for req_d in d.get("requirements", []):
            for key in req_d:
                self.assertNotIn("path", key.lower(),
                    f"Path-related key '{key}' found in requirement")
                self.assertNotIn("waypoint", key.lower(),
                    f"Waypoint-related key '{key}' found in requirement")
                self.assertNotIn("steer", key.lower(),
                    f"Steer-related key '{key}' found in requirement")
                self.assertNotIn("throttle", key.lower(),
                    f"Throttle-related key '{key}' found in requirement")


# ---------------------------------------------------------------------------
# Determinism tests
# ---------------------------------------------------------------------------

class TestDeterminism(unittest.TestCase):

    def setUp(self):
        self.engine = ActionAbstractionEngine()

    def _compare_snapshots(self, s1, s2):
        """Assert two snapshots are functionally identical."""
        self.assertEqual(s1.response_family, s2.response_family)
        self.assertEqual(s1.overall_urgency, s2.overall_urgency)
        self.assertEqual(s1.overall_severity, s2.overall_severity)
        self.assertEqual(s1.any_safety_critical, s2.any_safety_critical)
        self.assertEqual(s1.requirement_count, s2.requirement_count)
        for r1, r2 in zip(s1.requirements, s2.requirements):
            self.assertEqual(r1.requirement_type, r2.requirement_type)
            self.assertAlmostEqual(r1.priority, r2.priority, places=4)
            self.assertEqual(r1.urgency, r2.urgency)
            self.assertEqual(r1.severity, r2.severity)
            self.assertEqual(r1.evidence_type, r2.evidence_type)
            self.assertEqual(r1.reason_codes, r2.reason_codes)

    def test_determinism_normal(self):
        sit = make_reasoning_snapshot()
        world = make_world_model()
        results = [self.engine.generate(situation_state=sit, world_model=world)
                   for _ in range(5)]
        for r in results[1:]:
            self._compare_snapshots(results[0].snapshot, r.snapshot)

    def test_determinism_collision(self):
        hazard = make_hazard(
            category=HazardCategory.CAR,
            risk=RiskLevel.CRITICAL,
            ttc_band=TtcBand.IMMEDIATE,
            ttc_s=1.0,
            collision_likelihood=0.88,
            predicted_conflict=True,
        )
        sit = make_reasoning_snapshot(
            overall_risk=RiskLevel.CRITICAL,
            collision_threat=True,
            hazards=make_hazard_summary([hazard]),
        )
        results = [self.engine.generate(situation_state=sit) for _ in range(5)]
        for r in results[1:]:
            self._compare_snapshots(results[0].snapshot, r.snapshot)

    def test_determinism_multi_hazard(self):
        hazards = [
            make_hazard("h1", HazardCategory.PEDESTRIAN, RiskLevel.HIGH,
                        TtcBand.NEAR_TERM, 2.5, 0.6, True, True, True),
            make_hazard("h2", HazardCategory.POTHOLE, RiskLevel.MEDIUM,
                        TtcBand.MODERATE, 5.0, 0.3, False),
        ]
        sit = make_reasoning_snapshot(
            overall_risk=RiskLevel.HIGH,
            collision_threat=True,
            hazards=make_hazard_summary(hazards),
            is_narrow=True,
            available_width_m=3.5,
        )
        results = [self.engine.generate(situation_state=sit) for _ in range(5)]
        for r in results[1:]:
            self._compare_snapshots(results[0].snapshot, r.snapshot)


# ---------------------------------------------------------------------------
# Snapshot utility tests
# ---------------------------------------------------------------------------

class TestSnapshotUtils(unittest.TestCase):

    def setUp(self):
        self.engine = ActionAbstractionEngine()

    def test_to_json_roundtrip(self):
        sit = make_reasoning_snapshot()
        snap = self.engine.generate(situation_state=sit).snapshot
        j = abstraction_snapshot_to_json(snap)
        import json
        d = json.loads(j)
        self.assertEqual(d["schema_version"], "8.3")

    def test_summary_keys(self):
        sit = make_reasoning_snapshot()
        snap = self.engine.generate(situation_state=sit).snapshot
        summary = abstraction_snapshot_summary(snap)
        expected_keys = {
            "schema_version", "timestamp", "frame_id", "response_family",
            "overall_urgency", "overall_severity", "any_safety_critical",
            "requirement_count",
        }
        self.assertTrue(expected_keys.issubset(summary.keys()))

    def test_find_requirement_by_type(self):
        sit = make_reasoning_snapshot(
            uncertainty=0.72,
            prediction_unavailable=True,
        )
        snap = self.engine.generate(situation_state=sit).snapshot
        req = find_requirement_by_type(snap, RequirementType.HANDLE_UNCERTAINTY)
        # May or may not be present; just confirm no crash and return type is correct
        if req is not None:
            self.assertEqual(req.requirement_type, RequirementType.HANDLE_UNCERTAINTY)


# ---------------------------------------------------------------------------
# Validation tests
# ---------------------------------------------------------------------------

class TestValidation(unittest.TestCase):

    def setUp(self):
        self.engine = ActionAbstractionEngine()
        self.validator = ActionAbstractionValidator()

    def test_valid_snapshot_passes(self):
        sit = make_reasoning_snapshot()
        snap = self.engine.generate(situation_state=sit).snapshot
        result = self.validator.validate(snap)
        self.assertTrue(result.is_usable)

    def test_degraded_snapshot_usable(self):
        sit = make_reasoning_snapshot(sensor_degradation=True, uncertainty=0.9)
        snap = self.engine.generate(situation_state=sit).snapshot
        result = self.validator.validate(snap)
        self.assertTrue(result.is_usable)

    def test_no_forbidden_in_validation(self):
        """Validator must report errors for any forbidden field."""
        sit = make_reasoning_snapshot()
        snap = self.engine.generate(situation_state=sit).snapshot
        vr = self.validator.validate(snap)
        forbidden_errors = [e for e in vr.errors if "forbidden" in e]
        self.assertEqual(forbidden_errors, [])

    def test_normal_progress_with_collision_is_invalid(self):
        """If normal_progress co-exists with safety_critical → validation error."""
        from core.reasoning.action_abstraction_types import (
            ActionAbstractionSnapshot, DecisionRequirement,
            RequirementType, AbstractUrgency, AbstractSeverity,
            EvidenceType, ResponseFamily,
        )
        from core.reasoning.requirement_generator import _new_req_id
        ts = time.time()
        req_normal = DecisionRequirement(
            requirement_id=_new_req_id(),
            requirement_type=RequirementType.NORMAL_PROGRESS,
            priority=0.1,
            urgency=AbstractUrgency.NONE,
            severity=AbstractSeverity.NONE,
            confidence=0.9,
            uncertainty=0.1,
            evidence_type=EvidenceType.OBSERVED,
            source="test",
            reason_codes=("TEST",),
            constraints_summary="normal_test",
            is_safety_critical=False,
            timestamp=ts,
            frame_id=1,
        )
        req_collision = DecisionRequirement(
            requirement_id=_new_req_id(),
            requirement_type=RequirementType.COLLISION_AVOIDANCE_REQUIRED,
            priority=0.95,
            urgency=AbstractUrgency.IMMEDIATE,
            severity=AbstractSeverity.CRITICAL,
            confidence=0.9,
            uncertainty=0.1,
            evidence_type=EvidenceType.OBSERVED,
            source="test",
            reason_codes=("COLLISION_THREAT_DETECTED",),
            constraints_summary="collision_threat_active",
            is_safety_critical=True,
            timestamp=ts,
            frame_id=1,
        )
        # Manually craft an invalid snapshot
        bad_snap = ActionAbstractionSnapshot(
            frame_id=1,
            timestamp=ts,
            _requirements=(req_normal, req_collision),
            _relationships=tuple(),
            response_family=ResponseFamily.SAFETY_CRITICAL,
            overall_urgency=AbstractUrgency.IMMEDIATE,
            overall_severity=AbstractSeverity.CRITICAL,
            any_safety_critical=True,
            confidence=0.9,
            uncertainty=0.1,
        )
        vr = self.validator.validate(bad_snap)
        self.assertGreater(len(vr.errors), 0)


# ---------------------------------------------------------------------------
# Thread safety test (basic — no global state)
# ---------------------------------------------------------------------------

class TestThreadSafety(unittest.TestCase):

    def test_concurrent_generation(self):
        """Multiple threads can run generate() concurrently with no errors."""
        import threading
        engine = ActionAbstractionEngine()
        errors = []

        def run():
            try:
                hazard = make_hazard(
                    category=HazardCategory.CAR,
                    risk=RiskLevel.HIGH,
                    ttc_band=TtcBand.NEAR_TERM,
                    ttc_s=2.5,
                    collision_likelihood=0.6,
                    predicted_conflict=True,
                )
                sit = make_reasoning_snapshot(
                    overall_risk=RiskLevel.HIGH,
                    collision_threat=True,
                    hazards=make_hazard_summary([hazard]),
                )
                result = engine.generate(situation_state=sit)
                assert result.is_valid
            except Exception as exc:
                errors.append(str(exc))

        threads = [threading.Thread(target=run) for _ in range(10)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        self.assertEqual(errors, [], f"Thread errors: {errors}")


# ---------------------------------------------------------------------------
# Response family tests
# ---------------------------------------------------------------------------

class TestResponseFamily(unittest.TestCase):

    def setUp(self):
        self.engine = ActionAbstractionEngine()

    def test_normal_family(self):
        sit = make_reasoning_snapshot(
            overall_risk=RiskLevel.LOW,
            uncertainty=0.10,
            confidence=0.92,
        )
        world = make_world_model(completeness=0.92, status=WorldModelStatus.OK)
        snap = self.engine.generate(situation_state=sit, world_model=world).snapshot
        req_types = [r.requirement_type for r in snap.requirements]
        if RequirementType.NORMAL_PROGRESS in req_types:
            self.assertEqual(snap.response_family, ResponseFamily.NORMAL)

    def test_safety_critical_family(self):
        hazard = make_hazard(
            category=HazardCategory.CAR,
            risk=RiskLevel.CRITICAL,
            ttc_band=TtcBand.IMMEDIATE,
            ttc_s=0.8,
            collision_likelihood=0.92,
            predicted_conflict=True,
        )
        sit = make_reasoning_snapshot(
            overall_risk=RiskLevel.CRITICAL,
            collision_threat=True,
            hazards=make_hazard_summary([hazard]),
        )
        snap = self.engine.generate(situation_state=sit).snapshot
        self.assertEqual(snap.response_family, ResponseFamily.SAFETY_CRITICAL)

    def test_degraded_family(self):
        sit = make_reasoning_snapshot(sensor_degradation=True, uncertainty=0.9)
        snap = self.engine.generate(situation_state=sit).snapshot
        self.assertEqual(snap.response_family, ResponseFamily.DEGRADED)

    def test_hazard_handling_family(self):
        hazard = make_hazard(
            category=HazardCategory.POTHOLE,
            risk=RiskLevel.HIGH,
            ttc_band=TtcBand.NEAR_TERM,
            ttc_s=2.5,
            collision_likelihood=0.5,
            predicted_conflict=True,
        )
        sit = make_reasoning_snapshot(
            overall_risk=RiskLevel.HIGH,
            collision_threat=False,  # no collision avoidance
            hazards=make_hazard_summary([hazard]),
        )
        snap = self.engine.generate(situation_state=sit).snapshot
        self.assertIn(snap.response_family, (
            ResponseFamily.HAZARD_HANDLING,
            ResponseFamily.CAUTION,
            ResponseFamily.CONFLICT_HANDLING,
        ))


if __name__ == "__main__":
    unittest.main(verbosity=2)
