"""
Phase 8.1 | Complexity Assessment Tests
=========================================
Tests: open road, dense traffic, narrow road, unmarked road,
       high hazard count, compound hazard, degraded visibility.
"""
import pytest
from core.reasoning import (
    ReasoningEngine, ComplexityLevel, SituationCategory, ReasoningState
)

from .conftest import (
    make_snapshot, make_object, make_road, make_pothole,
    make_indian_context, make_full_quality,
)


class TestOpenRoad:
    def test_open_road_low_complexity(self, engine):
        road = make_road(road_width_m=7.0, marking_state="MARKED")
        ctx = make_indian_context(traffic_density="LOW", complexity="LOW")
        snap = make_snapshot(road=road, indian_context=ctx)
        result = engine.assess(snap)
        assert result.snapshot.complexity.complexity_level == ComplexityLevel.LOW

    def test_open_road_confidence_positive(self, engine):
        snap = make_snapshot()
        result = engine.assess(snap)
        assert result.snapshot.complexity.confidence > 0.0


class TestDenseTraffic:
    def test_dense_traffic_medium_plus_complexity(self, engine):
        ctx = make_indian_context(
            traffic_density="HIGH", vru=True, complexity="HIGH"
        )
        objs = [
            make_object("VEHICLE", "CAR", distance_m=10.0, object_id="c1"),
            make_object("VEHICLE", "CAR", distance_m=15.0, object_id="c2"),
            make_object("VEHICLE", "MOTORCYCLE", distance_m=8.0, object_id="m1"),
            make_object("PEDESTRIAN", "PEDESTRIAN", distance_m=5.0, object_id="p1"),
        ]
        snap = make_snapshot(objects=objs, indian_context=ctx)
        result = engine.assess(snap)
        level = result.snapshot.complexity.complexity_level
        assert level != ComplexityLevel.LOW

    def test_dense_traffic_factor_listed(self, engine):
        ctx = make_indian_context(traffic_density="VERY_HIGH")
        snap = make_snapshot(indian_context=ctx)
        result = engine.assess(snap)
        factors = result.snapshot.complexity.contributing_factors
        assert any("TRAFFIC_DENSITY" in f for f in factors)


class TestNarrowRoadComplexity:
    def test_very_narrow_road_high_complexity(self, engine):
        road = make_road(road_width_m=2.5)
        ctx = make_indian_context(complexity="VERY_HIGH")
        snap = make_snapshot(road=road, indian_context=ctx)
        result = engine.assess(snap)
        level = result.snapshot.complexity.complexity_level
        assert level in (ComplexityLevel.HIGH, ComplexityLevel.VERY_HIGH)

    def test_narrow_road_factor_listed(self, engine):
        road = make_road(road_width_m=3.0)
        snap = make_snapshot(road=road)
        result = engine.assess(snap)
        factors = result.snapshot.complexity.contributing_factors
        assert any("NARROW" in f.upper() for f in factors)


class TestUnmarkedRoadComplexity:
    def test_unmarked_road_adds_complexity(self, engine):
        road = make_road(marking_state="UNMARKED")
        snap = make_snapshot(road=road)
        result = engine.assess(snap)
        factors = result.snapshot.complexity.contributing_factors
        assert any("UNMARKED" in f.upper() for f in factors)


class TestHighHazardCount:
    def test_many_hazards_very_high_complexity(self, engine):
        objs = [
            make_object("VEHICLE", "CAR", distance_m=10.0 + i * 5, object_id=f"c{i}")
            for i in range(10)
        ]
        snap = make_snapshot(objects=objs)
        result = engine.assess(snap)
        level = result.snapshot.complexity.complexity_level
        assert level in (ComplexityLevel.HIGH, ComplexityLevel.VERY_HIGH)

    def test_four_hazards_at_least_high(self, engine):
        objs = [
            make_object("VEHICLE", "CAR", distance_m=10 + i * 5, object_id=f"c{i}")
            for i in range(4)
        ]
        snap = make_snapshot(objects=objs)
        result = engine.assess(snap)
        level = result.snapshot.complexity.complexity_level
        assert level != ComplexityLevel.LOW


class TestCompoundHazardComplexity:
    def test_multiple_categories_compound(self, engine):
        road = make_road(road_width_m=3.5, anomalies=[make_pothole()])
        ctx = make_indian_context(
            cattle_present=True, vru=True,
            traffic_density="HIGH", complexity="VERY_HIGH"
        )
        objs = [
            make_object("PEDESTRIAN", "PEDESTRIAN", distance_m=5.0, object_id="p1"),
            make_object("CATTLE", "CATTLE", distance_m=8.0, object_id="cow1"),
            make_object("VEHICLE", "MOTORCYCLE", distance_m=12.0, object_id="m1"),
        ]
        snap = make_snapshot(objects=objs, road=road, indian_context=ctx)
        result = engine.assess(snap)
        level = result.snapshot.complexity.complexity_level
        assert level in (ComplexityLevel.HIGH, ComplexityLevel.VERY_HIGH)

    def test_compound_hazard_factors_nonempty(self, engine):
        road = make_road(road_width_m=3.0, anomalies=[make_pothole()])
        ctx = make_indian_context(cattle_present=True, market=True, vru=True)
        objs = [
            make_object("PEDESTRIAN", "PEDESTRIAN", distance_m=4.0),
            make_object("CATTLE", "CATTLE", distance_m=7.0),
        ]
        snap = make_snapshot(objects=objs, road=road, indian_context=ctx)
        result = engine.assess(snap)
        assert len(result.snapshot.complexity.contributing_factors) > 0


class TestDegradedVisibilityComplexity:
    def test_degraded_quality_increases_uncertainty(self, engine):
        from core.world_model.world_model_types import WorldDataQuality, InputModuleStatus
        dq = WorldDataQuality(
            overall_confidence=0.3,
            overall_uncertainty=0.8,
            completeness=0.5,
            freshness=0.2,  # stale → degraded visibility proxy
            perception_status=InputModuleStatus.DEGRADED,
        )
        snap = make_snapshot(data_quality=dq)
        result = engine.assess(snap)
        assert result.snapshot.complexity.uncertainty > 0.5

    def test_high_world_uncertainty_adds_complexity_factor(self, engine):
        from core.world_model.world_model_types import WorldDataQuality
        dq = WorldDataQuality(
            overall_confidence=0.2,
            overall_uncertainty=0.9,
            completeness=0.5,
            freshness=0.4,
        )
        snap = make_snapshot(data_quality=dq)
        result = engine.assess(snap)
        factors = result.snapshot.complexity.contributing_factors
        assert any("UNCERTAINTY" in f.upper() for f in factors)
