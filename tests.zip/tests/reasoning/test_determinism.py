"""
Phase 8.1 | Determinism & Snapshot Tests
==========================================
Tests:
  - Identical input → identical output (multiple runs)
  - No mutation of input World Model
  - Immutable output (interactions as tuple)
  - Stable ordering
  - Bounded collections
"""
import pytest
import time
from core.reasoning import ReasoningEngine, ReasoningConfig, ReasoningState
from core.world_model.world_model_types import WorldModelStatus

from .conftest import (
    make_snapshot, make_object, make_road, make_pothole,
    make_indian_context, make_full_quality,
)


class TestDeterminism:
    def test_same_input_same_state(self, engine):
        obj = make_object("PEDESTRIAN", "PEDESTRIAN", distance_m=6.0,
                          ttc_s=2.0, ttc_status="FINITE", risk_level="HIGH",
                          object_id="ped1")
        snap = make_snapshot(objects=[obj])
        result1 = engine.assess(snap)
        result2 = engine.assess(snap)
        assert result1.snapshot.reasoning_state == result2.snapshot.reasoning_state

    def test_same_input_same_situation(self, engine):
        snap = make_snapshot(objects=[
            make_object("CATTLE", "CATTLE", distance_m=8.0, object_id="c1")
        ])
        result1 = engine.assess(snap)
        result2 = engine.assess(snap)
        assert result1.snapshot.situation.situation_category == \
               result2.snapshot.situation.situation_category

    def test_same_input_same_risk_level(self, engine):
        snap = make_snapshot(objects=[
            make_object("VEHICLE", "CAR", distance_m=5.0, ttc_s=1.2,
                        ttc_status="FINITE", risk_level="CRITICAL",
                        predicted_conflict=True, object_id="car1")
        ])
        results = [engine.assess(snap) for _ in range(5)]
        states = [r.snapshot.reasoning_state for r in results]
        assert len(set(states)) == 1

    def test_same_input_same_hazard_count(self, engine):
        objs = [
            make_object("VEHICLE", "CAR", distance_m=10.0, object_id=f"c{i}")
            for i in range(4)
        ]
        snap = make_snapshot(objects=objs)
        r1 = engine.assess(snap)
        r2 = engine.assess(snap)
        assert r1.snapshot.hazards.total_hazards == r2.snapshot.hazards.total_hazards

    def test_same_input_same_complexity(self, engine):
        road = make_road(road_width_m=3.0, marking_state="UNMARKED")
        snap = make_snapshot(road=road)
        r1 = engine.assess(snap)
        r2 = engine.assess(snap)
        assert r1.snapshot.complexity.complexity_level == r2.snapshot.complexity.complexity_level

    def test_same_input_same_priority_scores(self, engine):
        objs = [
            make_object("PEDESTRIAN", "PEDESTRIAN", distance_m=5.0, object_id="p1",
                        ttc_s=2.0, ttc_status="FINITE", risk_level="HIGH"),
            make_object("VEHICLE", "CAR", distance_m=20.0, object_id="c1"),
        ]
        snap = make_snapshot(objects=objs)
        r1 = engine.assess(snap)
        r2 = engine.assess(snap)
        scores1 = [h.priority_score for h in r1.snapshot.hazards.top_hazards]
        scores2 = [h.priority_score for h in r2.snapshot.hazards.top_hazards]
        assert scores1 == scores2

    def test_same_input_same_interactions(self, engine):
        objs = [
            make_object("PEDESTRIAN", "PEDESTRIAN", distance_m=5.0, object_id="p1",
                        ttc_s=2.0, ttc_status="FINITE", risk_level="HIGH"),
        ]
        snap = make_snapshot(objects=objs)
        r1 = engine.assess(snap)
        r2 = engine.assess(snap)
        assert r1.snapshot.interaction_count == r2.snapshot.interaction_count

    def test_ten_runs_same_state(self, engine):
        obj = make_object("VEHICLE", "CAR", distance_m=15.0, risk_level="MEDIUM",
                          object_id="car1")
        snap = make_snapshot(objects=[obj])
        states = {engine.assess(snap).snapshot.reasoning_state for _ in range(10)}
        assert len(states) == 1


class TestNoMutation:
    def test_snapshot_objects_unchanged_after_assess(self, engine):
        obj = make_object("VEHICLE", "CAR", distance_m=20.0, object_id="car1")
        snap = make_snapshot(objects=[obj])
        original_count = len(snap.objects)
        engine.assess(snap)
        assert len(snap.objects) == original_count

    def test_world_model_status_unchanged(self, engine):
        snap = make_snapshot(status=WorldModelStatus.OK)
        engine.assess(snap)
        assert snap.status == WorldModelStatus.OK

    def test_reasoning_snapshot_interactions_immutable(self, engine):
        obj = make_object("PEDESTRIAN", "PEDESTRIAN", distance_m=5.0,
                          risk_level="HIGH", ttc_s=2.0, ttc_status="FINITE",
                          object_id="ped1")
        snap = make_snapshot(objects=[obj])
        result = engine.assess(snap)
        # interactions should be a tuple (immutable)
        assert isinstance(result.snapshot.interactions, tuple)

    def test_top_hazards_is_list_copy(self, engine):
        objs = [make_object("VEHICLE", "CAR", distance_m=20.0, object_id=f"c{i}")
                for i in range(3)]
        snap = make_snapshot(objects=objs)
        result = engine.assess(snap)
        original_len = len(result.snapshot.hazards.top_hazards)
        # Mutating the returned list should not affect snapshot's internal count
        result.snapshot.hazards.top_hazards.clear()
        r2 = engine.assess(snap)
        assert r2.snapshot.hazards.total_hazards == 3


class TestStableOrdering:
    def test_top_hazards_sorted_descending(self, engine):
        objs = [
            make_object("PEDESTRIAN", "PEDESTRIAN", distance_m=4.0, risk_level="HIGH",
                        ttc_s=1.8, ttc_status="FINITE", object_id="p1"),
            make_object("VEHICLE", "CAR", distance_m=30.0, risk_level="LOW", object_id="c1"),
        ]
        snap = make_snapshot(objects=objs)
        result = engine.assess(snap)
        scores = [h.priority_score for h in result.snapshot.hazards.top_hazards]
        assert scores == sorted(scores, reverse=True)


class TestBoundedCollections:
    def test_top_hazards_bounded(self, engine, default_config):
        objs = [
            make_object("VEHICLE", "CAR", distance_m=10.0 + i * 3, object_id=f"c{i}")
            for i in range(50)
        ]
        snap = make_snapshot(objects=objs)
        result = engine.assess(snap)
        assert len(result.snapshot.hazards.top_hazards) <= default_config.max_top_hazards

    def test_interactions_bounded(self, engine, default_config):
        objs = [
            make_object("PEDESTRIAN", "PEDESTRIAN", distance_m=4.0 + i,
                        risk_level="HIGH", ttc_s=2.0, ttc_status="FINITE",
                        object_id=f"p{i}")
            for i in range(30)
        ]
        snap = make_snapshot(objects=objs)
        result = engine.assess(snap)
        assert len(result.snapshot.interactions) <= default_config.max_interactions

    def test_hazards_bounded_in_analyzer(self, default_config):
        from core.reasoning.hazard_analyzer import HazardAnalyzer
        analyzer = HazardAnalyzer(default_config)
        objs = [
            make_object("VEHICLE", "CAR", distance_m=20.0, object_id=f"c{i}")
            for i in range(100)
        ]
        snap = make_snapshot(objects=objs)
        hazards = analyzer.extract(snap)
        assert len(hazards) <= default_config.max_hazards

    def test_reason_codes_bounded(self, engine, default_config):
        objs = [
            make_object("PEDESTRIAN", "PEDESTRIAN", distance_m=4.0,
                        risk_level="CRITICAL", ttc_s=0.8, ttc_status="FINITE",
                        predicted_conflict=True, object_id="p1"),
        ]
        snap = make_snapshot(objects=objs)
        result = engine.assess(snap)
        for h in result.snapshot.hazards.top_hazards:
            assert len(h.reason_codes) <= default_config.max_reason_codes
