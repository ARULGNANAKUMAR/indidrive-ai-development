"""
Phase 8.1 | Uncertainty Reasoning Tests
=========================================
Tests: high confidence / low uncertainty, low confidence / high uncertainty,
       missing prediction, missing lane, missing road boundary,
       sensor degradation, partial world model.

Key rule: uncertainty ≠ zero risk.
Missing information must not be converted to absence of hazard.
"""
import pytest
from core.reasoning import (
    ReasoningEngine, ReasoningState, UncertaintyLevel, WorldCompletenessLevel, RiskLevel
)
from core.world_model.world_model_types import (
    WorldDataQuality, InputModuleStatus, WorldModelStatus
)

from .conftest import make_snapshot, make_object, make_full_quality


class TestHighConfidenceLowUncertainty:
    def test_high_conf_full_completeness(self, engine):
        dq = make_full_quality(confidence=0.9)
        snap = make_snapshot(data_quality=dq)
        result = engine.assess(snap)
        unc = result.snapshot.uncertainty_info
        assert unc.overall_uncertainty <= 0.2

    def test_high_conf_world_completeness_full(self, engine):
        dq = make_full_quality(confidence=0.9)
        snap = make_snapshot(data_quality=dq)
        result = engine.assess(snap)
        assert result.snapshot.uncertainty_info.world_completeness == WorldCompletenessLevel.FULL


class TestLowConfidenceHighUncertainty:
    def test_low_conf_high_uncertainty_level(self, engine):
        dq = WorldDataQuality(
            overall_confidence=0.15,
            overall_uncertainty=0.85,
            completeness=0.3,
            freshness=0.2,
        )
        snap = make_snapshot(data_quality=dq)
        result = engine.assess(snap)
        unc_level = result.snapshot.risk.uncertainty_level
        assert unc_level in (UncertaintyLevel.HIGH, UncertaintyLevel.VERY_HIGH)

    def test_low_conf_partial_completeness(self, engine):
        dq = WorldDataQuality(
            overall_confidence=0.2,
            overall_uncertainty=0.8,
            completeness=0.45,
            freshness=0.3,
        )
        snap = make_snapshot(data_quality=dq)
        result = engine.assess(snap)
        comp = result.snapshot.uncertainty_info.world_completeness
        assert comp in (WorldCompletenessLevel.PARTIAL, WorldCompletenessLevel.MINIMAL)

    def test_low_conf_does_not_produce_high_confidence_snapshot(self, engine):
        dq = WorldDataQuality(
            overall_confidence=0.1,
            overall_uncertainty=0.9,
            completeness=0.2,
            freshness=0.1,
        )
        snap = make_snapshot(data_quality=dq)
        result = engine.assess(snap)
        assert result.snapshot.reasoning_confidence < 0.7


class TestMissingPrediction:
    def test_missing_prediction_flagged(self, engine):
        dq = WorldDataQuality(
            overall_confidence=0.6,
            overall_uncertainty=0.4,
            completeness=0.7,
            freshness=0.8,
            perception_status=InputModuleStatus.OK,
            prediction_status=InputModuleStatus.UNAVAILABLE,
            road_understanding_status=InputModuleStatus.OK,
        )
        snap = make_snapshot(data_quality=dq)
        result = engine.assess(snap)
        assert result.snapshot.uncertainty_info.prediction_unavailable

    def test_missing_prediction_listed_in_missing(self, engine):
        dq = WorldDataQuality(
            overall_confidence=0.6,
            overall_uncertainty=0.4,
            completeness=0.7,
            freshness=0.8,
            prediction_status=InputModuleStatus.UNAVAILABLE,
        )
        snap = make_snapshot(data_quality=dq)
        result = engine.assess(snap)
        assert "PREDICTION" in result.snapshot.uncertainty_info.missing_modules


class TestMissingLaneInformation:
    def test_missing_road_understanding_flagged(self, engine):
        dq = WorldDataQuality(
            overall_confidence=0.5,
            overall_uncertainty=0.5,
            completeness=0.6,
            freshness=0.7,
            road_understanding_status=InputModuleStatus.UNAVAILABLE,
        )
        snap = make_snapshot(data_quality=dq)
        result = engine.assess(snap)
        assert result.snapshot.uncertainty_info.road_info_unavailable

    def test_missing_road_in_missing_modules(self, engine):
        dq = WorldDataQuality(
            overall_confidence=0.5,
            overall_uncertainty=0.5,
            completeness=0.6,
            freshness=0.7,
            road_understanding_status=InputModuleStatus.UNAVAILABLE,
        )
        snap = make_snapshot(data_quality=dq)
        result = engine.assess(snap)
        assert "ROAD_UNDERSTANDING" in result.snapshot.uncertainty_info.missing_modules


class TestMissingRoadBoundary:
    def test_degraded_road_info_in_degraded_list(self, engine):
        dq = WorldDataQuality(
            overall_confidence=0.5,
            overall_uncertainty=0.5,
            completeness=0.6,
            freshness=0.6,
            road_understanding_status=InputModuleStatus.DEGRADED,
        )
        snap = make_snapshot(data_quality=dq)
        result = engine.assess(snap)
        assert "ROAD_UNDERSTANDING" in result.snapshot.uncertainty_info.degraded_modules


class TestSensorDegradation:
    def test_perception_degraded_flagged(self, engine):
        dq = WorldDataQuality(
            overall_confidence=0.4,
            overall_uncertainty=0.6,
            completeness=0.5,
            freshness=0.5,
            perception_status=InputModuleStatus.DEGRADED,
        )
        snap = make_snapshot(data_quality=dq)
        result = engine.assess(snap)
        assert result.snapshot.uncertainty_info.sensor_degradation

    def test_perception_unavailable_in_missing(self, engine):
        dq = WorldDataQuality(
            overall_confidence=0.2,
            overall_uncertainty=0.8,
            completeness=0.3,
            freshness=0.3,
            perception_status=InputModuleStatus.UNAVAILABLE,
        )
        snap = make_snapshot(data_quality=dq)
        result = engine.assess(snap)
        assert "PERCEPTION" in result.snapshot.uncertainty_info.missing_modules


class TestPartialWorldModel:
    def test_partial_wm_partial_completeness(self, engine):
        dq = WorldDataQuality(
            overall_confidence=0.45,
            overall_uncertainty=0.55,
            completeness=0.55,
            freshness=0.6,
            fusion_status=InputModuleStatus.DEGRADED,
            prediction_status=InputModuleStatus.UNAVAILABLE,
            is_partial=True,
        )
        snap = make_snapshot(data_quality=dq, status=WorldModelStatus.PARTIAL)
        result = engine.assess(snap)
        comp = result.snapshot.uncertainty_info.world_completeness
        assert comp == WorldCompletenessLevel.PARTIAL

    def test_minimal_completeness_minimal_level(self, engine):
        dq = WorldDataQuality(
            overall_confidence=0.2,
            overall_uncertainty=0.8,
            completeness=0.2,
            freshness=0.3,
        )
        snap = make_snapshot(data_quality=dq, status=WorldModelStatus.PARTIAL)
        result = engine.assess(snap)
        comp = result.snapshot.uncertainty_info.world_completeness
        assert comp in (WorldCompletenessLevel.MINIMAL, WorldCompletenessLevel.EMPTY)


class TestUncertaintyNotZeroRisk:
    """
    Critical: high uncertainty must NOT produce zero/low risk output when
    hazards exist with unknown properties.
    """
    def test_unknown_ttc_hazard_priority_nonzero(self, default_config):
        from core.reasoning.hazard_prioritizer import HazardPrioritizer
        from core.reasoning.reasoning_types import HazardEntry, HazardCategory, TtcBand, RiskLevel
        prioritizer = HazardPrioritizer(default_config)
        h = HazardEntry(
            hazard_id="unknown_obj",
            hazard_category=HazardCategory.UNKNOWN,
            risk_level=RiskLevel.UNKNOWN,
            ttc_band=TtcBand.UNAVAILABLE,
            ttc_s=None,
            distance_m=None,
            collision_likelihood=None,
            confidence=0.2,
            uncertainty=0.8,
        )
        scored = prioritizer.prioritize([h])
        assert scored[0].priority_score > 0.0

    def test_missing_likelihood_not_treated_as_zero(self, default_config):
        from core.reasoning.hazard_prioritizer import HazardPrioritizer
        from core.reasoning.reasoning_types import HazardEntry, HazardCategory, TtcBand, RiskLevel
        prioritizer = HazardPrioritizer(default_config)
        known = HazardEntry(
            hazard_id="known", hazard_category=HazardCategory.CAR,
            risk_level=RiskLevel.LOW, ttc_band=TtcBand.DISTANT,
            distance_m=40.0, collision_likelihood=0.05,
            confidence=0.9, uncertainty=0.1,
        )
        unknown = HazardEntry(
            hazard_id="unknown", hazard_category=HazardCategory.CAR,
            risk_level=RiskLevel.UNKNOWN, ttc_band=TtcBand.UNAVAILABLE,
            distance_m=None, collision_likelihood=None,
            confidence=0.2, uncertainty=0.8,
        )
        scored = prioritizer.prioritize([known, unknown])
        # Unknown should not rank dead last due to absent fields
        unknown_score = next(h.priority_score for h in scored if h.hazard_id == "unknown")
        assert unknown_score > 0.0
