"""
Phase 8.1 | Interaction Analysis Tests
========================================
Tests: vehicle-pedestrian, vehicle-cattle, vehicle-motorcycle,
       vehicle-vehicle conflict, road hazard, multiple interacting hazards.
"""
import pytest
from core.reasoning import ReasoningEngine, InteractionType, RiskLevel
from core.reasoning.interaction_analyzer import InteractionAnalyzer

from .conftest import (
    make_snapshot, make_object, make_road, make_pothole,
    make_indian_context, make_full_quality,
)


def _make_interaction_hazard(haz_id, category_str, risk_level_str="HIGH",
                              priority=0.7, predicted_conflict=False,
                              is_vulnerable=False, confidence=0.8):
    from core.reasoning.reasoning_types import HazardEntry, HazardCategory, TtcBand, RiskLevel
    cat_map = {
        "PEDESTRIAN": HazardCategory.PEDESTRIAN,
        "CYCLIST": HazardCategory.CYCLIST,
        "MOTORCYCLE": HazardCategory.MOTORCYCLE,
        "CATTLE": HazardCategory.CATTLE,
        "CAR": HazardCategory.CAR,
        "TRUCK": HazardCategory.TRUCK,
        "POTHOLE": HazardCategory.POTHOLE,
        "PUSHCART": HazardCategory.PUSHCART,
    }
    rl_map = {
        "CRITICAL": RiskLevel.CRITICAL,
        "HIGH": RiskLevel.HIGH,
        "MEDIUM": RiskLevel.MEDIUM,
        "LOW": RiskLevel.LOW,
    }
    return HazardEntry(
        hazard_id=haz_id,
        hazard_category=cat_map.get(category_str, HazardCategory.UNKNOWN),
        risk_level=rl_map.get(risk_level_str, RiskLevel.UNKNOWN),
        ttc_band=TtcBand.NEAR_TERM,
        distance_m=10.0,
        collision_likelihood=0.6,
        predicted_conflict=predicted_conflict,
        is_moving=True,
        is_vulnerable=is_vulnerable,
        priority_score=priority,
        confidence=confidence,
        uncertainty=1.0 - confidence,
    )


class TestVehiclePedestrianInteraction:
    def test_vehicle_ped_interaction_detected(self, default_config):
        analyzer = InteractionAnalyzer(default_config)
        snap = make_snapshot()
        ped = _make_interaction_hazard("ped1", "PEDESTRIAN", is_vulnerable=True)
        interactions = analyzer.analyze([ped], snap)
        types = [i.interaction_type for i in interactions]
        assert InteractionType.VEHICLE_PEDESTRIAN in types

    def test_vehicle_ped_severity_not_low(self, default_config):
        analyzer = InteractionAnalyzer(default_config)
        snap = make_snapshot()
        ped = _make_interaction_hazard("ped1", "PEDESTRIAN", risk_level_str="HIGH",
                                       is_vulnerable=True)
        interactions = analyzer.analyze([ped], snap)
        ped_intr = next(i for i in interactions
                        if i.interaction_type == InteractionType.VEHICLE_PEDESTRIAN)
        assert ped_intr.severity != RiskLevel.LOW

    def test_vehicle_ped_entity_b_is_hazard_id(self, default_config):
        analyzer = InteractionAnalyzer(default_config)
        snap = make_snapshot()
        ped = _make_interaction_hazard("ped_007", "PEDESTRIAN", is_vulnerable=True)
        interactions = analyzer.analyze([ped], snap)
        ped_intr = next(i for i in interactions
                        if i.interaction_type == InteractionType.VEHICLE_PEDESTRIAN)
        assert ped_intr.entity_b_id == "ped_007"

    def test_vehicle_ped_entity_a_is_ego(self, default_config):
        analyzer = InteractionAnalyzer(default_config)
        snap = make_snapshot()
        ped = _make_interaction_hazard("ped1", "PEDESTRIAN", is_vulnerable=True)
        interactions = analyzer.analyze([ped], snap)
        ped_intr = next(i for i in interactions
                        if i.interaction_type == InteractionType.VEHICLE_PEDESTRIAN)
        assert ped_intr.entity_a_id == "ego"


class TestVehicleCattleInteraction:
    def test_cattle_interaction_detected(self, default_config):
        analyzer = InteractionAnalyzer(default_config)
        snap = make_snapshot()
        cattle = _make_interaction_hazard("cow1", "CATTLE", is_vulnerable=True)
        interactions = analyzer.analyze([cattle], snap)
        types = [i.interaction_type for i in interactions]
        assert InteractionType.VEHICLE_CATTLE in types

    def test_cattle_reason_codes_present(self, default_config):
        analyzer = InteractionAnalyzer(default_config)
        snap = make_snapshot()
        cattle = _make_interaction_hazard("cow1", "CATTLE", is_vulnerable=True)
        interactions = analyzer.analyze([cattle], snap)
        cattle_intr = next(i for i in interactions
                           if i.interaction_type == InteractionType.VEHICLE_CATTLE)
        assert len(cattle_intr.reason_codes) > 0


class TestVehicleMotorcycleInteraction:
    def test_motorcycle_interaction_detected(self, default_config):
        analyzer = InteractionAnalyzer(default_config)
        snap = make_snapshot()
        moto = _make_interaction_hazard("moto1", "MOTORCYCLE")
        interactions = analyzer.analyze([moto], snap)
        types = [i.interaction_type for i in interactions]
        assert InteractionType.VEHICLE_MOTORCYCLE in types


class TestVehicleVehicleConflict:
    def test_car_conflict_detected(self, default_config):
        analyzer = InteractionAnalyzer(default_config)
        snap = make_snapshot()
        car = _make_interaction_hazard("car1", "CAR", predicted_conflict=True)
        interactions = analyzer.analyze([car], snap)
        types = [i.interaction_type for i in interactions]
        assert InteractionType.VEHICLE_VEHICLE in types

    def test_predicted_conflict_reason_code(self, default_config):
        analyzer = InteractionAnalyzer(default_config)
        snap = make_snapshot()
        car = _make_interaction_hazard("car1", "CAR", predicted_conflict=True)
        interactions = analyzer.analyze([car], snap)
        car_intr = next(i for i in interactions
                        if i.interaction_type == InteractionType.VEHICLE_VEHICLE)
        assert "PREDICTED_CONFLICT" in car_intr.reason_codes

    def test_active_when_conflict_predicted(self, default_config):
        analyzer = InteractionAnalyzer(default_config)
        snap = make_snapshot()
        car = _make_interaction_hazard("car1", "CAR", predicted_conflict=True,
                                       risk_level_str="HIGH")
        interactions = analyzer.analyze([car], snap)
        car_intr = next(i for i in interactions
                        if i.interaction_type == InteractionType.VEHICLE_VEHICLE)
        assert car_intr.is_active


class TestRoadHazardInteraction:
    def test_pothole_interaction_detected(self, default_config):
        analyzer = InteractionAnalyzer(default_config)
        snap = make_snapshot()
        pothole = _make_interaction_hazard("poth1", "POTHOLE", risk_level_str="MEDIUM")
        interactions = analyzer.analyze([pothole], snap)
        types = [i.interaction_type for i in interactions]
        assert InteractionType.VEHICLE_ROAD_ANOMALY in types


class TestMultipleInteractingHazards:
    def test_compound_interaction_multiple_high_risk(self, default_config):
        from core.reasoning import InteractionType
        analyzer = InteractionAnalyzer(default_config)
        snap = make_snapshot()
        hazards = [
            _make_interaction_hazard("ped1", "PEDESTRIAN", risk_level_str="HIGH",
                                     is_vulnerable=True),
            _make_interaction_hazard("car1", "CAR", risk_level_str="HIGH",
                                     predicted_conflict=True),
        ]
        interactions = analyzer.analyze(hazards, snap)
        types = [i.interaction_type for i in interactions]
        assert InteractionType.COMPOUND_MULTI_HAZARD in types

    def test_low_priority_hazard_no_interaction(self, default_config):
        analyzer = InteractionAnalyzer(default_config)
        snap = make_snapshot()
        from core.reasoning.reasoning_types import HazardEntry, HazardCategory, TtcBand, RiskLevel
        low = HazardEntry(
            hazard_id="far_car", hazard_category=HazardCategory.CAR,
            risk_level=RiskLevel.LOW, ttc_band=TtcBand.DISTANT,
            priority_score=0.05,  # below interaction threshold
            confidence=0.5, uncertainty=0.5,
        )
        interactions = analyzer.analyze([low], snap)
        types = [i.interaction_type for i in interactions]
        # Should not form a vehicle-vehicle interaction
        assert InteractionType.VEHICLE_VEHICLE not in types

    def test_bounded_interaction_count(self, default_config):
        analyzer = InteractionAnalyzer(default_config)
        snap = make_snapshot()
        hazards = [
            _make_interaction_hazard(f"h{i}", "CAR", priority=0.8)
            for i in range(50)
        ]
        interactions = analyzer.analyze(hazards, snap)
        assert len(interactions) <= default_config.max_interactions
