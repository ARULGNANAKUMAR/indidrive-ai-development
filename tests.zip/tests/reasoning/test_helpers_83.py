"""
IndiDrive AI — Phase 8.3 | Test Helpers & Fixture Builders
===========================================================
Shared helpers for constructing realistic test inputs without
relying on the full ingestion pipeline.

All fixtures are constructed from typed dataclasses — not raw dicts.
No fake sensor data. No scenario-name-only logic.
"""
from __future__ import annotations

import time
from typing import List, Optional

from core.reasoning.reasoning_types import (
    ComplexityInfo, ComplexityLevel, EnvironmentInfo,
    HazardCategory, HazardEntry, HazardSummary, InteractionEntry,
    ReasoningExplanation,
    ReasoningSnapshot, ReasoningState, RiskLevel, RiskSummary,
    SituationCategory, SituationInfo, TtcBand, UncertaintyInfo,
    UncertaintyLevel, WorldCompletenessLevel,
)
from core.reasoning.behavior_types import (
    BehaviorClassification, BehaviorEvidenceItem, BehaviorInteractionEntry,
    BehaviorInteractionType, BehaviorReasoningState, BehaviorState,
    CompoundSituation, EvidenceClass, IntentHypothesis, IntentType,
    InteractionGraph, InteractionSeverity, TimeRelevance,
)
from core.world_model.world_model_types import (
    WorldModelSnapshot, WorldModelStatus, WorldDataQuality,
    WorldRoadRepresentation, WorldIndianContextSummary,
    WorldDrivableSpaceInfo, WorldLaneInfo, WorldAnomalySummary,
    InputModuleStatus, RoadRepresentationStatus,
)


# ---------------------------------------------------------------------------
# World Model fixtures
# ---------------------------------------------------------------------------

def make_world_model(
    status: WorldModelStatus = WorldModelStatus.OK,
    completeness: float = 0.85,
    confidence: float = 0.80,
    uncertainty: float = 0.20,
    prediction_status: InputModuleStatus = InputModuleStatus.OK,
    road_confidence: float = 0.80,
    road_uncertainty: float = 0.20,
    available_width_m: Optional[float] = None,
    anomalies: Optional[List[WorldAnomalySummary]] = None,
    intersection_state: str = "NORMAL_ROAD",
    road_type: str = "URBAN",
    traffic_density: str = "MEDIUM",
    cattle_present: bool = False,
    vru_present: bool = False,
    market_like: bool = False,
    frame_id: int = 1,
) -> WorldModelSnapshot:
    drivable = WorldDrivableSpaceInfo(
        road_width_m=available_width_m,
        drivable_space_uncertainty=road_uncertainty,
    )
    lane_info = WorldLaneInfo(
        intersection_state=intersection_state,
    )
    road = WorldRoadRepresentation(
        status=RoadRepresentationStatus.FULL,
        drivable_space=drivable,
        lane_info=lane_info,
        anomalies=anomalies or [],
        road_confidence=road_confidence,
        road_uncertainty=road_uncertainty,
        is_degraded=False,
    )
    indian_ctx = WorldIndianContextSummary(
        available=True,
        road_type=road_type,
        traffic_density=traffic_density,
        cattle_present=cattle_present,
        vulnerable_road_users=vru_present,
        market_like_activity=market_like,
        context_confidence=confidence,
        context_uncertainty=uncertainty,
        is_degraded=False,
    )
    dq = WorldDataQuality(
        overall_confidence=confidence,
        overall_uncertainty=uncertainty,
        completeness=completeness,
        freshness=0.95,
        prediction_status=prediction_status,
        is_partial=completeness < 0.85,
    )
    return WorldModelSnapshot(
        frame_id=frame_id,
        _objects=tuple(),
        road=road,
        indian_context=indian_ctx,
        data_quality=dq,
        status=status,
    )


def make_anomaly(
    anomaly_id: str = "anomaly_1",
    anomaly_type: str = "POTHOLE",
    severity: str = "HIGH",
    in_drivable_area: bool = True,
) -> WorldAnomalySummary:
    return WorldAnomalySummary(
        anomaly_id=anomaly_id,
        anomaly_type=anomaly_type,
        severity=severity,
        in_drivable_area=in_drivable_area,
    )


# ---------------------------------------------------------------------------
# Reasoning snapshot (Phase 8.1) fixtures
# ---------------------------------------------------------------------------

def make_reasoning_snapshot(
    reasoning_state: ReasoningState = ReasoningState.NORMAL,
    situation_category: SituationCategory = SituationCategory.OPEN_ROAD,
    overall_risk: RiskLevel = RiskLevel.LOW,
    collision_threat: bool = False,
    time_criticality: TtcBand = TtcBand.DISTANT,
    uncertainty: float = 0.2,
    confidence: float = 0.85,
    hazards: Optional[HazardSummary] = None,
    interactions: Optional[List[InteractionEntry]] = None,
    is_narrow: bool = False,
    is_intersection: bool = False,
    has_vru: bool = False,
    has_cattle: bool = False,
    has_wrong_side: bool = False,
    has_roadside_activity: bool = False,
    available_width_m: Optional[float] = None,
    traffic_density: str = "LOW",
    sensor_degradation: bool = False,
    prediction_unavailable: bool = False,
    road_info_unavailable: bool = False,
    world_completeness: WorldCompletenessLevel = WorldCompletenessLevel.FULL,
    frame_id: int = 1,
) -> ReasoningSnapshot:
    ts = time.time()
    env = EnvironmentInfo(
        road_type="URBAN",
        is_narrow_road=is_narrow,
        is_intersection=is_intersection,
        has_vru=has_vru,
        has_cattle=has_cattle,
        has_wrong_side_traffic=has_wrong_side,
        has_roadside_activity=has_roadside_activity,
        available_drivable_width_m=available_width_m,
        traffic_density=traffic_density,
    )
    risk_summary = RiskSummary(
        overall_risk_level=overall_risk,
        max_hazard_risk=overall_risk,
        collision_threat_present=collision_threat,
        time_criticality=time_criticality,
        uncertainty_level=UncertaintyLevel.LOW if uncertainty < 0.4 else
                         UncertaintyLevel.MEDIUM if uncertainty < 0.6 else
                         UncertaintyLevel.HIGH,
    )
    if hazards is None:
        hazards = HazardSummary()
    unc_info = UncertaintyInfo(
        overall_uncertainty=uncertainty,
        world_completeness=world_completeness,
        sensor_degradation=sensor_degradation,
        prediction_unavailable=prediction_unavailable,
        road_info_unavailable=road_info_unavailable,
    )
    snap = ReasoningSnapshot(
        timestamp=ts,
        frame_id=frame_id,
        reasoning_state=reasoning_state,
        situation=SituationInfo(
            timestamp=ts,
            frame_id=frame_id,
            situation_category=situation_category,
            situation_confidence=confidence,
            situation_uncertainty=uncertainty,
        ),
        environment=env,
        hazards=hazards,
        _interactions=tuple(interactions or []),
        risk=risk_summary,
        complexity=ComplexityInfo(
            complexity_level=ComplexityLevel.LOW,
            confidence=confidence,
            uncertainty=uncertainty,
        ),
        uncertainty_info=unc_info,
        explanation=ReasoningExplanation(),
        reasoning_confidence=confidence,
    )
    return snap


def make_hazard(
    hazard_id: str = "h1",
    category: HazardCategory = HazardCategory.CAR,
    risk: RiskLevel = RiskLevel.MEDIUM,
    ttc_band: TtcBand = TtcBand.MODERATE,
    ttc_s: Optional[float] = 4.0,
    collision_likelihood: float = 0.3,
    predicted_conflict: bool = False,
    is_moving: bool = True,
    is_vulnerable: bool = False,
    priority_score: float = 0.4,
    confidence: float = 0.75,
    uncertainty: float = 0.25,
    reason_codes: Optional[List[str]] = None,
) -> HazardEntry:
    return HazardEntry(
        hazard_id=hazard_id,
        hazard_category=category,
        risk_level=risk,
        ttc_band=ttc_band,
        ttc_s=ttc_s,
        collision_likelihood=collision_likelihood,
        predicted_conflict=predicted_conflict,
        is_moving=is_moving,
        is_vulnerable=is_vulnerable,
        priority_score=priority_score,
        confidence=confidence,
        uncertainty=uncertainty,
        reason_codes=reason_codes or [],
    )


def make_hazard_summary(hazards: List[HazardEntry]) -> HazardSummary:
    critical = sum(1 for h in hazards if h.risk_level == RiskLevel.CRITICAL)
    high = sum(1 for h in hazards if h.risk_level == RiskLevel.HIGH)
    vru = sum(1 for h in hazards if h.is_vulnerable)
    return HazardSummary(
        total_hazards=len(hazards),
        critical_hazards=critical,
        high_risk_hazards=high,
        active_hazards=len(hazards),
        vulnerable_road_users=vru,
        top_hazards=hazards,
    )


# ---------------------------------------------------------------------------
# Behavior state (Phase 8.2) fixtures
# ---------------------------------------------------------------------------

def make_behavior_state(
    interactions: Optional[List[BehaviorInteractionEntry]] = None,
    intent_hypotheses: Optional[List[IntentHypothesis]] = None,
    dominant_interactions: Optional[List[BehaviorInteractionEntry]] = None,
    confidence: float = 0.80,
    uncertainty: float = 0.20,
    degraded: bool = False,
    frame_id: int = 1,
) -> BehaviorReasoningState:
    return BehaviorReasoningState(
        frame_id=frame_id,
        _interactions=tuple(interactions or []),
        _intent_hypotheses=tuple(intent_hypotheses or []),
        _dominant_interactions=tuple(dominant_interactions or []),
        _entity_behaviors=tuple(),
        _compound_situations=tuple(),
        interaction_graph=InteractionGraph(),
        confidence=confidence,
        uncertainty=uncertainty,
        completeness=1.0 - uncertainty,
        degraded=degraded,
        overall_interaction_complexity="LOW",
    )


def make_interaction(
    entity_a: str = "ego",
    entity_b: str = "obj_1",
    interaction_type: BehaviorInteractionType = BehaviorInteractionType.APPROACHING,
    severity: InteractionSeverity = InteractionSeverity.MEDIUM,
    time_relevance: TimeRelevance = TimeRelevance.MEDIUM_TERM,
    confidence: float = 0.75,
    uncertainty: float = 0.25,
    interaction_id: str = "int_1",
    state: EvidenceClass = EvidenceClass.OBSERVED,
) -> BehaviorInteractionEntry:
    return BehaviorInteractionEntry(
        interaction_id=interaction_id,
        entity_a_id=entity_a,
        entity_b_id=entity_b,
        interaction_type=interaction_type,
        interaction_state=state,
        severity=severity,
        time_relevance=time_relevance,
        confidence=confidence,
        uncertainty=uncertainty,
        evidence=[
            BehaviorEvidenceItem(
                code="TRAJECTORY_INTERSECTION",
                evidence_class=state,
                strength=confidence,
            )
        ],
    )


def make_intent(
    entity_id: str = "obj_1",
    intent_type: IntentType = IntentType.POSSIBLE_CROSSING,
    confidence: float = 0.70,
    uncertainty: float = 0.30,
    ev_class: EvidenceClass = EvidenceClass.INFERRED,
) -> IntentHypothesis:
    return IntentHypothesis(
        entity_id=entity_id,
        intent_type=intent_type,
        confidence=confidence,
        uncertainty=uncertainty,
        evidence_class=ev_class,
        evidence=[
            BehaviorEvidenceItem(
                code="LATERAL_DISPLACEMENT_INCREASING",
                evidence_class=ev_class,
                strength=confidence,
            )
        ],
    )
