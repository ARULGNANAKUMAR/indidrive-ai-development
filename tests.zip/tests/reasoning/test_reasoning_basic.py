"""
Phase 8.1 | Basic Reasoning Tests
===================================
Tests: empty WM, normal road, single hazard, multiple hazards,
       partial WM, degraded WM.
"""
import pytest
from core.reasoning import ReasoningEngine, ReasoningConfig, ReasoningState, SituationCategory
from core.world_model.world_model_types import WorldModelStatus, InputModuleStatus

from .conftest import (
    make_snapshot, make_empty_snapshot, make_object, make_road,
    make_indian_context, make_full_quality, make_snapshot,
    WorldModelSnapshot, WorldDataQuality,
)


class TestEmptyWorldModel:
    def test_empty_returns_result(self, engine):
        snap = make_empty_snapshot()
        result = engine.assess(snap)
        assert result is not None
        assert result.snapshot is not None

    def test_empty_state_degraded(self, engine):
        snap = make_empty_snapshot()
        result = engine.assess(snap)
        assert result.snapshot.reasoning_state == ReasoningState.DEGRADED

    def test_empty_is_valid_result(self, engine):
        snap = make_empty_snapshot()
        result = engine.assess(snap)
        assert result.is_valid  # degraded is still a valid result

    def test_empty_no_hazards(self, engine):
        snap = make_empty_snapshot()
        result = engine.assess(snap)
        assert result.snapshot.hazards.total_hazards == 0

    def test_empty_world_completeness(self, engine):
        from core.reasoning import WorldCompletenessLevel
        snap = make_empty_snapshot()
        result = engine.assess(snap)
        assert result.snapshot.uncertainty_info.world_completeness == WorldCompletenessLevel.EMPTY


class TestNormalRoad:
    def test_normal_road_no_hazards(self, engine):
        snap = make_snapshot(objects=[], status=WorldModelStatus.OK)
        result = engine.assess(snap)
        assert result.snapshot.reasoning_state == ReasoningState.NORMAL

    def test_normal_road_situation_open(self, engine):
        snap = make_snapshot(objects=[], status=WorldModelStatus.OK)
        result = engine.assess(snap)
        cat = result.snapshot.situation.situation_category
        assert cat in (SituationCategory.OPEN_ROAD, SituationCategory.NORMAL_TRAFFIC)

    def test_normal_road_no_collision_threat(self, engine):
        snap = make_snapshot(objects=[], status=WorldModelStatus.OK)
        result = engine.assess(snap)
        assert not result.snapshot.risk.collision_threat_present


class TestSingleHazard:
    def test_single_car_at_least_attention(self, engine):
        obj = make_object("VEHICLE", "CAR", distance_m=30.0, risk_level="LOW")
        snap = make_snapshot(objects=[obj])
        result = engine.assess(snap)
        assert result.snapshot.reasoning_state != ReasoningState.NORMAL

    def test_single_hazard_count(self, engine):
        obj = make_object("VEHICLE", "CAR", distance_m=30.0)
        snap = make_snapshot(objects=[obj])
        result = engine.assess(snap)
        assert result.snapshot.hazards.total_hazards == 1

    def test_single_critical_hazard_critical_state(self, engine):
        obj = make_object(
            "PEDESTRIAN", "PEDESTRIAN",
            distance_m=3.0, ttc_s=1.0, ttc_status="FINITE",
            risk_level="CRITICAL", collision_likelihood=0.9,
            predicted_conflict=True,
        )
        snap = make_snapshot(objects=[obj])
        result = engine.assess(snap)
        assert result.snapshot.reasoning_state == ReasoningState.CRITICAL

    def test_single_hazard_in_top_hazards(self, engine):
        obj = make_object("VEHICLE", "CAR")
        snap = make_snapshot(objects=[obj])
        result = engine.assess(snap)
        assert len(result.snapshot.hazards.top_hazards) >= 1


class TestMultipleHazards:
    def test_multiple_hazards_counted(self, engine):
        objs = [
            make_object("VEHICLE", "CAR", distance_m=30.0, object_id="car1"),
            make_object("PEDESTRIAN", "PEDESTRIAN", distance_m=8.0, object_id="ped1"),
            make_object("VEHICLE", "MOTORCYCLE", distance_m=15.0, object_id="moto1"),
        ]
        snap = make_snapshot(objects=objs)
        result = engine.assess(snap)
        assert result.snapshot.hazards.total_hazards == 3

    def test_multiple_hazards_vru_counted(self, engine):
        objs = [
            make_object("PEDESTRIAN", "PEDESTRIAN", distance_m=5.0, object_id="ped1"),
            make_object("CYCLIST", "CYCLIST", distance_m=10.0, object_id="cyc1"),
        ]
        snap = make_snapshot(objects=objs)
        result = engine.assess(snap)
        assert result.snapshot.hazards.vulnerable_road_users >= 1

    def test_multiple_high_risk_state_elevated(self, engine):
        objs = [
            make_object("VEHICLE", "CAR", risk_level="HIGH", object_id="c1",
                        ttc_s=2.0, ttc_status="FINITE"),
            make_object("PEDESTRIAN", "PEDESTRIAN", risk_level="HIGH", object_id="p1",
                        distance_m=5.0),
        ]
        snap = make_snapshot(objects=objs)
        result = engine.assess(snap)
        state = result.snapshot.reasoning_state
        assert state in (ReasoningState.HIGH_RISK, ReasoningState.CRITICAL, ReasoningState.CAUTION)


class TestPartialWorldModel:
    def test_partial_wm_returns_result(self, engine):
        dq = WorldDataQuality(
            overall_confidence=0.4,
            overall_uncertainty=0.6,
            completeness=0.5,
            freshness=0.5,
            perception_status=InputModuleStatus.OK,
            fusion_status=InputModuleStatus.DEGRADED,
            prediction_status=InputModuleStatus.UNAVAILABLE,
            memory_status=InputModuleStatus.OK,
            road_understanding_status=InputModuleStatus.OK,
            indian_context_status=InputModuleStatus.OK,
            is_partial=True,
        )
        snap = make_snapshot(data_quality=dq, status=WorldModelStatus.PARTIAL)
        result = engine.assess(snap)
        assert result is not None
        assert result.snapshot.uncertainty_info.prediction_unavailable

    def test_partial_wm_missing_modules_listed(self, engine):
        dq = WorldDataQuality(
            overall_confidence=0.4,
            overall_uncertainty=0.6,
            completeness=0.5,
            freshness=0.5,
            prediction_status=InputModuleStatus.UNAVAILABLE,
            is_partial=True,
        )
        snap = make_snapshot(data_quality=dq, status=WorldModelStatus.PARTIAL)
        result = engine.assess(snap)
        unc = result.snapshot.uncertainty_info
        assert "PREDICTION" in unc.missing_modules


class TestDegradedWorldModel:
    def test_degraded_wm_degraded_state(self, engine):
        snap = make_snapshot(status=WorldModelStatus.DEGRADED)
        result = engine.assess(snap)
        assert result.snapshot.reasoning_state == ReasoningState.DEGRADED

    def test_invalid_wm_degraded_state(self, engine):
        snap = make_snapshot(status=WorldModelStatus.INVALID)
        result = engine.assess(snap)
        assert result.snapshot.reasoning_state == ReasoningState.DEGRADED

    def test_degraded_wm_still_has_uncertainty_info(self, engine):
        snap = make_snapshot(status=WorldModelStatus.DEGRADED)
        result = engine.assess(snap)
        unc = result.snapshot.uncertainty_info
        assert unc is not None
