"""
Phase 8.1 | Reasoning Validator Tests
=======================================
Tests: all invalid-input cases; validator does NOT silently repair.
"""
import pytest
import dataclasses
from core.reasoning import ReasoningEngine, ReasoningConfig
from core.reasoning.reasoning_validator import ReasoningValidator
from core.reasoning.reasoning_types import (
    ReasoningSnapshot, ReasoningState, RiskLevel, TtcBand,
    ComplexityLevel, UncertaintyLevel, WorldCompletenessLevel,
    SituationInfo, EnvironmentInfo, HazardSummary, HazardEntry,
    RiskSummary, ComplexityInfo, UncertaintyInfo, ReasoningExplanation,
    SituationCategory, HazardCategory,
)

from .conftest import make_snapshot, make_object


def make_valid_snapshot(**overrides) -> ReasoningSnapshot:
    """Build a structurally valid ReasoningSnapshot."""
    s = ReasoningSnapshot(
        timestamp=1000.0,
        frame_id=1,
        reasoning_state=ReasoningState.NORMAL,
        situation=SituationInfo(
            timestamp=1000.0, frame_id=1,
            situation_category=SituationCategory.OPEN_ROAD,
            situation_confidence=0.8, situation_uncertainty=0.2,
        ),
        environment=EnvironmentInfo(),
        hazards=HazardSummary(),
        _interactions=tuple(),
        risk=RiskSummary(
            overall_risk_level=RiskLevel.LOW,
            max_hazard_risk=RiskLevel.LOW,
            time_criticality=TtcBand.DISTANT,
            uncertainty_level=UncertaintyLevel.LOW,
        ),
        complexity=ComplexityInfo(
            complexity_level=ComplexityLevel.LOW,
            confidence=0.8, uncertainty=0.2,
        ),
        uncertainty_info=UncertaintyInfo(
            overall_uncertainty=0.2,
            world_completeness=WorldCompletenessLevel.FULL,
        ),
        explanation=ReasoningExplanation(),
        reasoning_confidence=0.8,
    )
    if overrides:
        s = dataclasses.replace(s, **overrides)
    return s


class TestValidSnapshot:
    def test_valid_snapshot_passes(self):
        validator = ReasoningValidator()
        result = validator.validate(make_valid_snapshot())
        assert result.is_valid

    def test_engine_produces_valid_snapshot(self, engine):
        snap = make_snapshot(objects=[make_object()])
        result = engine.assess(snap)
        validator = ReasoningValidator()
        vr = validator.validate(result.snapshot)
        assert vr.is_valid, f"Validation errors: {vr.errors}"


class TestInvalidTimestamp:
    def test_negative_timestamp(self):
        validator = ReasoningValidator()
        s = make_valid_snapshot(timestamp=-1.0)
        result = validator.validate(s)
        assert not result.is_valid
        assert any("TIMESTAMP" in e for e in result.errors)

    def test_nan_timestamp(self):
        import math
        validator = ReasoningValidator()
        s = make_valid_snapshot(timestamp=float("nan"))
        result = validator.validate(s)
        assert not result.is_valid

    def test_inf_timestamp(self):
        validator = ReasoningValidator()
        s = make_valid_snapshot(timestamp=float("inf"))
        result = validator.validate(s)
        assert not result.is_valid


class TestInvalidFrameId:
    def test_negative_frame_id(self):
        validator = ReasoningValidator()
        s = make_valid_snapshot(frame_id=-1)
        result = validator.validate(s)
        assert not result.is_valid
        assert any("FRAME_ID" in e for e in result.errors)


class TestInvalidConfidence:
    def test_reasoning_confidence_above_one(self):
        validator = ReasoningValidator()
        s = make_valid_snapshot(reasoning_confidence=1.5)
        result = validator.validate(s)
        assert not result.is_valid

    def test_reasoning_confidence_negative(self):
        validator = ReasoningValidator()
        s = make_valid_snapshot(reasoning_confidence=-0.1)
        result = validator.validate(s)
        assert not result.is_valid


class TestInvalidHazardEntry:
    def test_priority_score_above_one(self):
        validator = ReasoningValidator()
        bad_h = HazardEntry(
            hazard_id="h1", hazard_category=HazardCategory.CAR,
            risk_level=RiskLevel.LOW, ttc_band=TtcBand.DISTANT,
            priority_score=1.5,   # invalid
            confidence=0.8, uncertainty=0.2,
        )
        summary = HazardSummary(total_hazards=1, top_hazards=[bad_h])
        s = make_valid_snapshot(hazards=summary)
        result = validator.validate(s)
        assert not result.is_valid
        assert any("PRIORITY_SCORE" in e for e in result.errors)

    def test_confidence_oob(self):
        validator = ReasoningValidator()
        bad_h = HazardEntry(
            hazard_id="h1", hazard_category=HazardCategory.CAR,
            risk_level=RiskLevel.LOW, ttc_band=TtcBand.DISTANT,
            priority_score=0.5,
            confidence=1.2,   # invalid
            uncertainty=0.2,
        )
        summary = HazardSummary(total_hazards=1, top_hazards=[bad_h])
        s = make_valid_snapshot(hazards=summary)
        result = validator.validate(s)
        assert not result.is_valid

    def test_negative_ttc(self):
        validator = ReasoningValidator()
        bad_h = HazardEntry(
            hazard_id="h1", hazard_category=HazardCategory.CAR,
            risk_level=RiskLevel.LOW, ttc_band=TtcBand.DISTANT,
            priority_score=0.3, confidence=0.8, uncertainty=0.2,
            ttc_s=-1.0,  # invalid
        )
        summary = HazardSummary(total_hazards=1, top_hazards=[bad_h])
        s = make_valid_snapshot(hazards=summary)
        result = validator.validate(s)
        assert not result.is_valid
        assert any("TTC" in e for e in result.errors)

    def test_critical_exceeds_total(self):
        validator = ReasoningValidator()
        summary = HazardSummary(total_hazards=2, critical_hazards=5)  # invalid
        s = make_valid_snapshot(hazards=summary)
        result = validator.validate(s)
        assert not result.is_valid
        assert any("CRITICAL" in e for e in result.errors)

    def test_collision_likelihood_oob(self):
        validator = ReasoningValidator()
        bad_h = HazardEntry(
            hazard_id="h1", hazard_category=HazardCategory.CAR,
            risk_level=RiskLevel.MEDIUM, ttc_band=TtcBand.MODERATE,
            priority_score=0.4, confidence=0.7, uncertainty=0.3,
            collision_likelihood=1.5,  # invalid
        )
        summary = HazardSummary(total_hazards=1, top_hazards=[bad_h])
        s = make_valid_snapshot(hazards=summary)
        result = validator.validate(s)
        assert not result.is_valid


class TestInvalidComplexity:
    def test_complexity_confidence_oob(self):
        validator = ReasoningValidator()
        cpx = ComplexityInfo(
            complexity_level=ComplexityLevel.LOW,
            confidence=1.5,  # invalid
            uncertainty=0.2,
        )
        s = make_valid_snapshot(complexity=cpx)
        result = validator.validate(s)
        assert not result.is_valid


class TestInvalidUncertainty:
    def test_uncertainty_oob(self):
        validator = ReasoningValidator()
        unc = UncertaintyInfo(
            overall_uncertainty=1.5,  # invalid
            world_completeness=WorldCompletenessLevel.PARTIAL,
        )
        s = make_valid_snapshot(uncertainty_info=unc)
        result = validator.validate(s)
        assert not result.is_valid


class TestNoSilentRepair:
    def test_invalid_snapshot_errors_not_empty(self):
        validator = ReasoningValidator()
        s = make_valid_snapshot(reasoning_confidence=2.0)
        result = validator.validate(s)
        assert len(result.errors) > 0

    def test_valid_snapshot_no_errors(self):
        validator = ReasoningValidator()
        s = make_valid_snapshot()
        result = validator.validate(s)
        assert result.errors == []
