"""
Phase 8.1 | Hazard Prioritization Tests
=========================================
Tests: pedestrian, cattle, motorcycle, vehicle, road obstacle, pothole,
       multiple hazards, tie-breaking, ordering.
"""
import pytest
from core.reasoning import ReasoningEngine, ReasoningConfig, HazardCategory, RiskLevel, TtcBand
from core.reasoning.hazard_analyzer import HazardAnalyzer
from core.reasoning.hazard_prioritizer import HazardPrioritizer

from .conftest import (
    make_snapshot, make_object, make_road, make_pothole,
    make_indian_context, make_full_quality,
)


class TestPedestrianHazard:
    def test_pedestrian_classified_correctly(self, default_config):
        analyzer = HazardAnalyzer(default_config)
        obj = make_object("PEDESTRIAN", "PEDESTRIAN", distance_m=5.0,
                          risk_level="HIGH", ttc_s=2.0, ttc_status="FINITE")
        snap = make_snapshot(objects=[obj])
        hazards = analyzer.extract(snap)
        cats = [h.hazard_category for h in hazards]
        assert HazardCategory.PEDESTRIAN in cats

    def test_pedestrian_is_vulnerable(self, default_config):
        analyzer = HazardAnalyzer(default_config)
        obj = make_object("PEDESTRIAN", "PEDESTRIAN", distance_m=5.0)
        snap = make_snapshot(objects=[obj])
        hazards = analyzer.extract(snap)
        ped = next(h for h in hazards if h.hazard_category == HazardCategory.PEDESTRIAN)
        assert ped.is_vulnerable

    def test_pedestrian_higher_priority_than_parked_car(self, default_config):
        prioritizer = HazardPrioritizer(default_config)
        from core.reasoning.reasoning_types import HazardEntry, HazardCategory, TtcBand, RiskLevel
        ped = HazardEntry(
            hazard_id="ped1", hazard_category=HazardCategory.PEDESTRIAN,
            risk_level=RiskLevel.HIGH, ttc_band=TtcBand.NEAR_TERM, ttc_s=2.5,
            distance_m=6.0, collision_likelihood=0.6, predicted_conflict=True,
            is_moving=True, is_vulnerable=True, confidence=0.8, uncertainty=0.2,
        )
        parked = HazardEntry(
            hazard_id="car1", hazard_category=HazardCategory.CAR,
            risk_level=RiskLevel.LOW, ttc_band=TtcBand.UNAVAILABLE,
            distance_m=30.0, collision_likelihood=0.05,
            is_moving=False, is_vulnerable=False, confidence=0.8, uncertainty=0.2,
        )
        scored = prioritizer.prioritize([parked, ped])
        assert scored[0].hazard_id == "ped1"


class TestCattleHazard:
    def test_cattle_classified(self, default_config):
        analyzer = HazardAnalyzer(default_config)
        obj = make_object("CATTLE", "CATTLE", distance_m=10.0)
        snap = make_snapshot(objects=[obj])
        hazards = analyzer.extract(snap)
        cats = [h.hazard_category for h in hazards]
        assert HazardCategory.CATTLE in cats

    def test_cattle_is_vulnerable(self, default_config):
        analyzer = HazardAnalyzer(default_config)
        obj = make_object("CATTLE", "COW", distance_m=10.0)
        snap = make_snapshot(objects=[obj])
        hazards = analyzer.extract(snap)
        cattle = next(h for h in hazards if h.hazard_category == HazardCategory.CATTLE)
        assert cattle.is_vulnerable

    def test_cattle_reason_code(self, default_config):
        analyzer = HazardAnalyzer(default_config)
        obj = make_object("CATTLE", "CATTLE", distance_m=10.0, risk_level="HIGH")
        snap = make_snapshot(objects=[obj])
        hazards = analyzer.extract(snap)
        cattle = next(h for h in hazards if h.hazard_category == HazardCategory.CATTLE)
        assert "CATTLE_PRESENT" in cattle.reason_codes


class TestMotorcycleHazard:
    def test_motorcycle_classified(self, default_config):
        analyzer = HazardAnalyzer(default_config)
        obj = make_object("MOTORCYCLE", "MOTORCYCLE", distance_m=12.0)
        snap = make_snapshot(objects=[obj])
        hazards = analyzer.extract(snap)
        cats = [h.hazard_category for h in hazards]
        assert HazardCategory.MOTORCYCLE in cats

    def test_motorcycle_not_vulnerable(self, default_config):
        analyzer = HazardAnalyzer(default_config)
        obj = make_object("MOTORCYCLE", "MOTORCYCLE", distance_m=12.0)
        snap = make_snapshot(objects=[obj])
        hazards = analyzer.extract(snap)
        moto = next(h for h in hazards if h.hazard_category == HazardCategory.MOTORCYCLE)
        assert not moto.is_vulnerable


class TestVehicleHazard:
    def test_car_classified(self, default_config):
        analyzer = HazardAnalyzer(default_config)
        obj = make_object("VEHICLE", "CAR", distance_m=20.0)
        snap = make_snapshot(objects=[obj])
        hazards = analyzer.extract(snap)
        cats = [h.hazard_category for h in hazards]
        assert HazardCategory.CAR in cats

    def test_truck_classified(self, default_config):
        analyzer = HazardAnalyzer(default_config)
        obj = make_object("VEHICLE", "TRUCK", distance_m=25.0)
        snap = make_snapshot(objects=[obj])
        hazards = analyzer.extract(snap)
        cats = [h.hazard_category for h in hazards]
        assert HazardCategory.TRUCK in cats


class TestRoadObstacleHazard:
    def test_pothole_in_drivable_area(self, default_config):
        analyzer = HazardAnalyzer(default_config)
        pothole = make_pothole(in_drivable=True)
        road = make_road(anomalies=[pothole])
        snap = make_snapshot(road=road)
        hazards = analyzer.extract(snap)
        cats = [h.hazard_category for h in hazards]
        assert HazardCategory.POTHOLE in cats

    def test_pothole_outside_drivable_low_severity_excluded(self, default_config):
        analyzer = HazardAnalyzer(default_config)
        pothole = make_pothole(in_drivable=False, severity="MINOR")
        road = make_road(anomalies=[pothole])
        snap = make_snapshot(road=road)
        hazards = analyzer.extract(snap)
        cats = [h.hazard_category for h in hazards]
        assert HazardCategory.POTHOLE not in cats

    def test_pothole_outside_drivable_critical_included(self, default_config):
        analyzer = HazardAnalyzer(default_config)
        from core.world_model.world_model_types import WorldAnomalySummary
        crit = WorldAnomalySummary(
            anomaly_id="a1", anomaly_type="POTHOLE", severity="CRITICAL",
            drivability_impact="BLOCKING", confidence=0.9, uncertainty=0.1,
            in_drivable_area=False, in_lane_corridor=False,
        )
        road = make_road(anomalies=[crit])
        snap = make_snapshot(road=road)
        hazards = analyzer.extract(snap)
        cats = [h.hazard_category for h in hazards]
        assert HazardCategory.POTHOLE in cats


class TestMultipleHazardsPrioritization:
    def test_ordering_descending(self, default_config):
        prioritizer = HazardPrioritizer(default_config)
        from core.reasoning.reasoning_types import HazardEntry, HazardCategory, TtcBand, RiskLevel
        high = HazardEntry(
            hazard_id="high", hazard_category=HazardCategory.PEDESTRIAN,
            risk_level=RiskLevel.HIGH, ttc_band=TtcBand.NEAR_TERM,
            distance_m=5.0, collision_likelihood=0.7, is_vulnerable=True,
            confidence=0.8, uncertainty=0.2,
        )
        med = HazardEntry(
            hazard_id="med", hazard_category=HazardCategory.CAR,
            risk_level=RiskLevel.MEDIUM, ttc_band=TtcBand.MODERATE,
            distance_m=20.0, collision_likelihood=0.3,
            confidence=0.7, uncertainty=0.3,
        )
        low = HazardEntry(
            hazard_id="low", hazard_category=HazardCategory.CAR,
            risk_level=RiskLevel.LOW, ttc_band=TtcBand.DISTANT,
            distance_m=45.0, collision_likelihood=0.05,
            confidence=0.6, uncertainty=0.4,
        )
        scored = prioritizer.prioritize([low, med, high])
        scores = [h.priority_score for h in scored]
        assert scores[0] >= scores[1] >= scores[2]

    def test_tie_same_risk_stable_order(self, default_config):
        prioritizer = HazardPrioritizer(default_config)
        from core.reasoning.reasoning_types import HazardEntry, HazardCategory, TtcBand, RiskLevel
        a = HazardEntry(
            hazard_id="a", hazard_category=HazardCategory.CAR,
            risk_level=RiskLevel.LOW, ttc_band=TtcBand.DISTANT,
            distance_m=40.0, collision_likelihood=0.1, confidence=0.7, uncertainty=0.3,
        )
        b = HazardEntry(
            hazard_id="b", hazard_category=HazardCategory.CAR,
            risk_level=RiskLevel.LOW, ttc_band=TtcBand.DISTANT,
            distance_m=40.0, collision_likelihood=0.1, confidence=0.7, uncertainty=0.3,
        )
        scored1 = prioritizer.prioritize([a, b])
        scored2 = prioritizer.prioritize([a, b])
        # Same input → same output
        assert [h.hazard_id for h in scored1] == [h.hazard_id for h in scored2]

    def test_critical_above_low(self, default_config):
        prioritizer = HazardPrioritizer(default_config)
        from core.reasoning.reasoning_types import HazardEntry, HazardCategory, TtcBand, RiskLevel
        crit = HazardEntry(
            hazard_id="crit", hazard_category=HazardCategory.PEDESTRIAN,
            risk_level=RiskLevel.CRITICAL, ttc_band=TtcBand.IMMEDIATE,
            distance_m=2.0, collision_likelihood=0.95, predicted_conflict=True,
            is_vulnerable=True, confidence=0.9, uncertainty=0.1,
        )
        low = HazardEntry(
            hazard_id="low", hazard_category=HazardCategory.CAR,
            risk_level=RiskLevel.LOW, ttc_band=TtcBand.NO_COLLISION,
            distance_m=50.0, collision_likelihood=0.02,
            confidence=0.6, uncertainty=0.4,
        )
        scored = prioritizer.prioritize([low, crit])
        assert scored[0].hazard_id == "crit"
