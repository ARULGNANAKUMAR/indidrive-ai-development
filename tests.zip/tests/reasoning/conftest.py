"""
Phase 8.1 Test Fixtures
========================
Shared helpers for building WorldModelSnapshot objects in tests.
No external sensor data; all values are synthetic and deterministic.
"""
from __future__ import annotations

import time
from typing import List, Optional

import pytest

from core.world_model.world_model_types import (
    WorldModelSnapshot,
    WorldModelStatus,
    WorldObject,
    WorldObjectPosition,
    WorldObjectVelocity,
    WorldObjectMotionSummary,
    WorldObjectPredictionSummary,
    WorldObjectCollisionInfo,
    WorldObjectQuality,
    WorldObjectLifecycle,
    WorldObjectDimensions,
    WorldRoadRepresentation,
    WorldDrivableSpaceInfo,
    WorldLaneInfo,
    WorldAnomalySummary,
    WorldIndianContextSummary,
    WorldDataQuality,
    RoadRepresentationStatus,
    CoordinateFrame,
    InputModuleStatus,
    PredictionAvailability,
    ObjectObservationState,
    NOT_AVAILABLE,
)
from core.reasoning import ReasoningEngine, ReasoningConfig


# ---------------------------------------------------------------------------
# Engine fixture
# ---------------------------------------------------------------------------

@pytest.fixture
def default_config() -> ReasoningConfig:
    return ReasoningConfig()


@pytest.fixture
def engine(default_config) -> ReasoningEngine:
    return ReasoningEngine(config=default_config)


# ---------------------------------------------------------------------------
# World Model builder helpers
# ---------------------------------------------------------------------------

def make_empty_snapshot(frame_id: int = 0, ts: Optional[float] = None) -> WorldModelSnapshot:
    """An empty WorldModelSnapshot with no objects and minimal road info."""
    return WorldModelSnapshot(
        timestamp=ts or time.time(),
        frame_id=frame_id,
        _objects=tuple(),
        status=WorldModelStatus.EMPTY,
        coordinate_frame=CoordinateFrame.VEHICLE,
        data_quality=WorldDataQuality(
            overall_confidence=0.0,
            overall_uncertainty=1.0,
            completeness=0.0,
            freshness=0.0,
            is_partial=True,
        ),
    )


def make_object(
    object_type: str = "VEHICLE",
    object_subtype: str = "CAR",
    distance_m: float = 20.0,
    x: float = 20.0,
    y: float = 0.0,
    vx: float = -5.0,
    vy: float = 0.0,
    ttc_s: Optional[float] = None,
    ttc_status: str = NOT_AVAILABLE,
    risk_level: str = "LOW",
    collision_likelihood: float = 0.1,
    predicted_conflict: bool = False,
    is_moving: bool = True,
    confidence: float = 0.8,
    object_id: Optional[str] = None,
    lifecycle: WorldObjectLifecycle = WorldObjectLifecycle.ACTIVE,
) -> WorldObject:
    pos = WorldObjectPosition(x=x, y=y, z=0.0, distance_m=distance_m)
    vel = WorldObjectVelocity(vx=vx, vy=vy, speed_ms=abs(vx))
    motion = WorldObjectMotionSummary(is_moving=is_moving, speed_ms=abs(vx))
    collision = WorldObjectCollisionInfo(
        ttc_s=ttc_s,
        ttc_status=ttc_status,
        collision_likelihood=collision_likelihood,
        risk_level=risk_level,
        predicted_conflict=predicted_conflict,
        closing_speed_ms=abs(vx) if vx < 0 else None,
    )
    quality = WorldObjectQuality(
        object_confidence=confidence,
        position_confidence=confidence,
        velocity_confidence=confidence,
        existence_probability=confidence,
        observation_state=ObjectObservationState.OBSERVED,
    )
    return WorldObject(
        object_id=object_id or f"obj_{object_type}_{id(pos)}",
        object_type=object_type,
        object_subtype=object_subtype,
        position=pos,
        velocity=vel,
        motion=motion,
        collision=collision,
        quality=quality,
        lifecycle=lifecycle,
    )


def make_road(
    road_width_m: float = 6.0,
    marking_state: str = "MARKED",
    intersection_state: str = "NORMAL_ROAD",
    anomalies: Optional[List[WorldAnomalySummary]] = None,
    road_confidence: float = 0.8,
) -> WorldRoadRepresentation:
    ds = WorldDrivableSpaceInfo(
        available=True,
        road_width_m=road_width_m,
        free_space_confidence=road_confidence,
    )
    lane = WorldLaneInfo(
        available=True,
        marking_state=marking_state,
        intersection_state=intersection_state,
        lane_confidence=road_confidence,
        lane_uncertainty=1.0 - road_confidence,
    )
    return WorldRoadRepresentation(
        status=RoadRepresentationStatus.FULL,
        drivable_space=ds,
        lane_info=lane,
        anomalies=anomalies or [],
        road_confidence=road_confidence,
        road_uncertainty=1.0 - road_confidence,
        is_degraded=False,
    )


def make_indian_context(
    road_type: str = "URBAN",
    traffic_density: str = "MEDIUM",
    cattle_present: bool = False,
    vru: bool = False,
    market: bool = False,
    unusual_indicators: Optional[List[str]] = None,
    complexity: str = "MEDIUM",
    confidence: float = 0.8,
) -> WorldIndianContextSummary:
    return WorldIndianContextSummary(
        available=True,
        road_type=road_type,
        urban_rural_class="URBAN",
        traffic_density=traffic_density,
        vulnerable_road_users=vru,
        cattle_present=cattle_present,
        market_like_activity=market,
        unusual_road_indicators=unusual_indicators or [],
        road_complexity=complexity,
        context_confidence=confidence,
        context_uncertainty=1.0 - confidence,
        is_degraded=False,
    )


def make_full_quality(confidence: float = 0.8) -> WorldDataQuality:
    return WorldDataQuality(
        overall_confidence=confidence,
        overall_uncertainty=1.0 - confidence,
        completeness=0.9,
        freshness=0.9,
        perception_status=InputModuleStatus.OK,
        fusion_status=InputModuleStatus.OK,
        prediction_status=InputModuleStatus.OK,
        memory_status=InputModuleStatus.OK,
        road_understanding_status=InputModuleStatus.OK,
        indian_context_status=InputModuleStatus.OK,
        is_partial=False,
    )


def make_snapshot(
    objects: Optional[List[WorldObject]] = None,
    road: Optional[WorldRoadRepresentation] = None,
    indian_context: Optional[WorldIndianContextSummary] = None,
    data_quality: Optional[WorldDataQuality] = None,
    status: WorldModelStatus = WorldModelStatus.OK,
    frame_id: int = 1,
) -> WorldModelSnapshot:
    return WorldModelSnapshot(
        timestamp=time.time(),
        frame_id=frame_id,
        _objects=tuple(objects or []),
        road=road or make_road(),
        indian_context=indian_context or make_indian_context(),
        data_quality=data_quality or make_full_quality(),
        status=status,
        coordinate_frame=CoordinateFrame.VEHICLE,
    )


def make_pothole(
    in_drivable: bool = True,
    severity: str = "MODERATE",
    confidence: float = 0.7,
) -> WorldAnomalySummary:
    return WorldAnomalySummary(
        anomaly_id="anomaly_pothole_1",
        anomaly_type="POTHOLE",
        position_x=10.0,
        position_y=0.5,
        approximate_width_m=0.4,
        approximate_length_m=0.5,
        severity=severity,
        drivability_impact="MEDIUM",
        confidence=confidence,
        uncertainty=1.0 - confidence,
        temporal_stability="STABLE",
        in_drivable_area=in_drivable,
        in_lane_corridor=in_drivable,
    )
