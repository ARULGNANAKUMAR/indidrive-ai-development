"""
Phase 8.1 | Indian Road Situation Tests
=========================================
Tests: unmarked village road, dense market, highway merge, cattle crossing,
       wrong-side traffic, narrow damaged road, busy intersection,
       construction area.

All classifications derive from actual World Model data —
NOT from hard-coded scenario name lookups.
"""
import pytest
from core.reasoning import (
    ReasoningEngine, ReasoningState, SituationCategory,
    HazardCategory, ComplexityLevel,
)
from core.world_model.world_model_types import WorldModelStatus

from .conftest import (
    make_snapshot, make_object, make_road, make_pothole,
    make_indian_context, make_full_quality, WorldAnomalySummary,
)


class TestUnmarkedVillageRoad:
    def test_unmarked_road_unstructured_category(self, engine):
        road = make_road(marking_state="UNMARKED", road_width_m=3.8)
        ctx = make_indian_context(
            road_type="RURAL",
            traffic_density="LOW",
            cattle_present=False,
            vru=False,  # no VRU so UNSTRUCTURED_ROAD is chosen
            complexity="HIGH",
        )
        snap = make_snapshot(road=road, indian_context=ctx)
        result = engine.assess(snap)
        cat = result.snapshot.situation.situation_category
        assert cat in (SituationCategory.UNSTRUCTURED_ROAD, SituationCategory.NARROW_ROAD,
                       SituationCategory.COMPOUND_HAZARD)

    def test_unmarked_road_complexity_elevated(self, engine):
        road = make_road(marking_state="UNMARKED", road_width_m=3.5)
        ctx = make_indian_context(road_type="RURAL", complexity="HIGH")
        snap = make_snapshot(road=road, indian_context=ctx)
        result = engine.assess(snap)
        level = result.snapshot.complexity.complexity_level
        assert level != ComplexityLevel.LOW

    def test_unmarked_road_subcategory_contains_unmarked(self, engine):
        road = make_road(marking_state="UNMARKED", road_width_m=4.0)
        ctx = make_indian_context(road_type="RURAL")
        snap = make_snapshot(road=road, indian_context=ctx)
        result = engine.assess(snap)
        sub = result.snapshot.situation.situation_subcategory
        assert "UNMARKED" in sub.upper() or "VILLAGE" in sub.upper() or sub != "NOT_AVAILABLE"


class TestDenseMarket:
    def test_market_activity_detected(self, engine):
        road = make_road(marking_state="UNMARKED", road_width_m=3.5)
        ctx = make_indian_context(
            road_type="URBAN",
            traffic_density="HIGH",
            cattle_present=False,
            vru=True,
            market=True,
            unusual_indicators=["ROADSIDE_STALLS", "PEDESTRIAN_SPILLOVER"],
            complexity="VERY_HIGH",
        )
        objs = [
            make_object("PEDESTRIAN", "PEDESTRIAN", distance_m=4.0, object_id="p1"),
            make_object("VEHICLE", "AUTO_RICKSHAW", distance_m=6.0, object_id="a1"),
        ]
        snap = make_snapshot(objects=objs, road=road, indian_context=ctx)
        result = engine.assess(snap)
        cat = result.snapshot.situation.situation_category
        # Must not be OPEN_ROAD or NORMAL_TRAFFIC
        assert cat not in (SituationCategory.OPEN_ROAD,)

    def test_market_complexity_high(self, engine):
        road = make_road(marking_state="UNMARKED", road_width_m=3.0)
        ctx = make_indian_context(
            traffic_density="HIGH", market=True, vru=True, complexity="VERY_HIGH"
        )
        objs = [
            make_object("PEDESTRIAN", "PEDESTRIAN", distance_m=4.0, object_id="p1"),
            make_object("VEHICLE", "AUTO_RICKSHAW", distance_m=7.0, object_id="a1"),
            make_object("CATTLE", "CATTLE", distance_m=12.0, object_id="c1"),
        ]
        snap = make_snapshot(objects=objs, road=road, indian_context=ctx)
        result = engine.assess(snap)
        level = result.snapshot.complexity.complexity_level
        assert level in (ComplexityLevel.HIGH, ComplexityLevel.VERY_HIGH)

    def test_market_vru_count_positive(self, engine):
        road = make_road(marking_state="UNMARKED", road_width_m=3.5)
        ctx = make_indian_context(traffic_density="HIGH", market=True, vru=True)
        objs = [make_object("PEDESTRIAN", "PEDESTRIAN", distance_m=4.0)]
        snap = make_snapshot(objects=objs, road=road, indian_context=ctx)
        result = engine.assess(snap)
        assert result.snapshot.hazards.vulnerable_road_users >= 1


class TestHighwayMerge:
    def test_highway_trajectory_conflict(self, engine):
        road = make_road(marking_state="MARKED", road_width_m=7.0,
                         intersection_state="MERGE")
        ctx = make_indian_context(
            road_type="HIGHWAY",
            traffic_density="MEDIUM",
            complexity="HIGH",
        )
        objs = [
            make_object(
                "VEHICLE", "CAR", distance_m=20.0, vx=-15.0,
                ttc_s=2.0, ttc_status="FINITE",
                risk_level="HIGH", predicted_conflict=True, object_id="fast_car",
            )
        ]
        snap = make_snapshot(objects=objs, road=road, indian_context=ctx)
        result = engine.assess(snap)
        state = result.snapshot.reasoning_state
        assert state in (
            ReasoningState.HIGH_RISK, ReasoningState.CRITICAL, ReasoningState.CAUTION
        )

    def test_highway_predicted_conflict_detected(self, engine):
        road = make_road(marking_state="MARKED", road_width_m=7.0)
        ctx = make_indian_context(road_type="HIGHWAY")
        objs = [
            make_object("VEHICLE", "CAR", ttc_s=1.8, ttc_status="FINITE",
                        risk_level="HIGH", predicted_conflict=True)
        ]
        snap = make_snapshot(objects=objs, road=road, indian_context=ctx)
        result = engine.assess(snap)
        assert result.snapshot.risk.collision_threat_present


class TestCattleCrossing:
    def test_cattle_increases_vru_count(self, engine):
        ctx = make_indian_context(cattle_present=True, vru=True)
        objs = [make_object("CATTLE", "CATTLE", distance_m=8.0, is_moving=True)]
        snap = make_snapshot(objects=objs, indian_context=ctx)
        result = engine.assess(snap)
        assert result.snapshot.hazards.vulnerable_road_users >= 1

    def test_cattle_hazard_category_present(self, engine):
        ctx = make_indian_context(cattle_present=True)
        objs = [make_object("CATTLE", "COW", distance_m=8.0)]
        snap = make_snapshot(objects=objs, indian_context=ctx)
        result = engine.assess(snap)
        cats = [h.hazard_category for h in result.snapshot.hazards.top_hazards]
        assert HazardCategory.CATTLE in cats

    def test_cattle_situation_vru_or_compound(self, engine):
        ctx = make_indian_context(cattle_present=True, road_type="RURAL")
        road = make_road(marking_state="UNMARKED")
        objs = [make_object("CATTLE", "CATTLE", distance_m=6.0, risk_level="HIGH")]
        snap = make_snapshot(objects=objs, road=road, indian_context=ctx)
        result = engine.assess(snap)
        cat = result.snapshot.situation.situation_category
        assert cat in (
            SituationCategory.VULNERABLE_ROAD_USER,
            SituationCategory.COMPOUND_HAZARD,
            SituationCategory.UNSTRUCTURED_ROAD,
        )


class TestWrongSideTraffic:
    def test_wrong_side_indicator_in_factors(self, engine):
        ctx = make_indian_context(
            unusual_indicators=["WRONG_SIDE_VEHICLE"],
            complexity="HIGH",
        )
        snap = make_snapshot(indian_context=ctx)
        result = engine.assess(snap)
        env = result.snapshot.environment
        assert env.has_wrong_side_traffic

    def test_wrong_side_wrong_side_hazard_present(self, engine):
        from core.reasoning.hazard_analyzer import HazardAnalyzer
        ctx = make_indian_context(unusual_indicators=["WRONG_SIDE_VEHICLE"])
        snap = make_snapshot(indian_context=ctx)
        analyzer = HazardAnalyzer(engine._cfg)
        hazards = analyzer.extract(snap)
        cats = [h.hazard_category for h in hazards]
        assert HazardCategory.WRONG_SIDE_TRAFFIC in cats

    def test_wrong_side_state_not_normal(self, engine):
        ctx = make_indian_context(
            unusual_indicators=["WRONG_SIDE_ONCOMING"],
            traffic_density="HIGH",
        )
        objs = [make_object("VEHICLE", "CAR", distance_m=12.0, risk_level="HIGH")]
        snap = make_snapshot(objects=objs, indian_context=ctx)
        result = engine.assess(snap)
        assert result.snapshot.reasoning_state != ReasoningState.NORMAL


class TestNarrowDamagedRoad:
    def test_narrow_with_pothole_compound(self, engine):
        road = make_road(
            road_width_m=3.2,
            marking_state="WEAKLY_MARKED",
            anomalies=[make_pothole(in_drivable=True, severity="SEVERE")]
        )
        ctx = make_indian_context(road_type="RURAL", complexity="VERY_HIGH")
        snap = make_snapshot(road=road, indian_context=ctx)
        result = engine.assess(snap)
        cat = result.snapshot.situation.situation_category
        assert cat in (
            SituationCategory.NARROW_ROAD,
            SituationCategory.ROAD_HAZARD,
            SituationCategory.COMPOUND_HAZARD,
            SituationCategory.UNSTRUCTURED_ROAD,
        )

    def test_narrow_road_detected_in_environment(self, engine):
        road = make_road(road_width_m=3.0)
        snap = make_snapshot(road=road)
        result = engine.assess(snap)
        assert result.snapshot.environment.is_narrow_road


class TestBusyIntersection:
    def test_intersection_category_detected(self, engine):
        road = make_road(intersection_state="INTERSECTION", road_width_m=6.0)
        ctx = make_indian_context(traffic_density="HIGH", vru=True)
        objs = [
            make_object("VEHICLE", "CAR", distance_m=10.0, object_id="c1"),
            make_object("PEDESTRIAN", "PEDESTRIAN", distance_m=5.0, object_id="p1"),
        ]
        snap = make_snapshot(objects=objs, road=road, indian_context=ctx)
        result = engine.assess(snap)
        cat = result.snapshot.situation.situation_category
        assert cat in (
            SituationCategory.INTERSECTION_COMPLEXITY,
            SituationCategory.COMPOUND_HAZARD,
            SituationCategory.VULNERABLE_ROAD_USER,
        )

    def test_intersection_is_intersection_flag(self, engine):
        road = make_road(intersection_state="INTERSECTION")
        snap = make_snapshot(road=road)
        result = engine.assess(snap)
        assert result.snapshot.environment.is_intersection


class TestConstructionArea:
    def test_construction_hazard_detected(self, engine):
        from core.world_model.world_model_types import WorldAnomalySummary
        construction = WorldAnomalySummary(
            anomaly_id="c1", anomaly_type="CONSTRUCTION",
            severity="SEVERE", drivability_impact="HIGH",
            confidence=0.85, uncertainty=0.15,
            in_drivable_area=True, in_lane_corridor=True,
        )
        road = make_road(anomalies=[construction])
        snap = make_snapshot(road=road)
        result = engine.assess(snap)
        cats = [h.hazard_category for h in result.snapshot.hazards.top_hazards]
        assert HazardCategory.CONSTRUCTION in cats

    def test_construction_in_lane_elevated_state(self, engine):
        from core.world_model.world_model_types import WorldAnomalySummary
        construction = WorldAnomalySummary(
            anomaly_id="c1", anomaly_type="CONSTRUCTION",
            severity="CRITICAL", drivability_impact="BLOCKING",
            confidence=0.9, uncertainty=0.1,
            in_drivable_area=True, in_lane_corridor=True,
        )
        road = make_road(anomalies=[construction])
        snap = make_snapshot(road=road)
        result = engine.assess(snap)
        assert result.snapshot.reasoning_state != ReasoningState.NORMAL
