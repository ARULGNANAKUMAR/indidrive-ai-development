"""
IndiDrive AI — Phase 12 Integration Tests
==========================================
Tests the complete Phase 12.1→12.6 chain as an observer of the
autonomous pipeline, and verifies all safety boundaries hold.

Tests:
  1. Adapter initialisation and build_default
  2. observe() with minimal snapshot — always returns
  3. Capture → Record → Evaluation chain (Phase 12.1-12.3)
  4. Retrieval → Knowledge chain (Phase 12.4-12.5)
  5. Knowledge → Decision Improvement chain (Phase 12.5-12.6)
  6. Full chain: observe → knowledge → improvement context
  7. Failure isolation: each component failure is isolated
  8. Safety boundaries: SafetyGate never bypassed
  9. Direct control protection: no actuator access
 10. Feedback loop: bounded by confidence/evidence thresholds
 11. Determinism: same inputs → same outputs
 12. Rollback: degradation triggers mode downgrade
 13. Indian road scenarios
 14. Phase 12.6 modes
"""
from __future__ import annotations

import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..'))

from core.experience.phase12_pipeline_adapter import (
    Phase12PipelineAdapter, Phase12CycleRecord,
)
from core.experience.decision_improvement import (
    DecisionImprovementEngine, ImprovementConfig, ImprovementMode,
    ImprovementOutcome, FallbackReason, SafetyVetoResult,
)
from core.experience.knowledge import (
    AdaptiveKnowledgeConfig, KnowledgeContextKey, KnowledgeStore,
    KnowledgeUpdateEngine,
)


# ---------------------------------------------------------------------------
# Minimal stub snapshot (replaces PipelineSnapshot without importing pipeline)
# ---------------------------------------------------------------------------

class _FakePlanningContext:
    def __init__(self, gate="CAUTION", situation="PEDESTRIAN_CROSSING"):
        self.safety_gate_state = gate
        self.situation_category = situation

class _FakePlannerOutput:
    def __init__(self, gate="CAUTION", situation="PEDESTRIAN_CROSSING", allowed=True):
        self.planning_context = _FakePlanningContext(gate, situation)
        self.planning_allowed = allowed
        self.planning_status = "COMPLETE" if allowed else "FAILED"

class _FakeSnapshot:
    def __init__(self, gate="CAUTION", situation="PEDESTRIAN_CROSSING",
                 status="COMPLETE", degraded=False):
        self.planner_output = _FakePlannerOutput(gate, situation)
        self.pipeline_status = status
        self.degraded = degraded


def _make_store(outcomes=None, confidence="HIGH") -> KnowledgeStore:
    if outcomes is None:
        outcomes = ["SUCCESS"] * 5
    k_cfg = AdaptiveKnowledgeConfig(
        enabled=True, minimum_evidence_count=1, minimum_confidence=0.01,
        minimum_consistency=0.0, maximum_entries=100,
    )
    store = KnowledgeStore(k_cfg)
    engine = KnowledgeUpdateEngine(k_cfg, store)
    key = KnowledgeContextKey(
        road_type="URBAN", situation_type="PEDESTRIAN_CROSSING",
        hazard_level="MEDIUM",
    )
    records = [
        {"experience_id": f"t-R{i:06d}", "evaluation_id": f"t-R{i:06d}-EVAL",
         "session_id": "t", "outcome_class": oc,
         "evaluation_confidence": confidence,
         "experience_timestamp": 1_700_000_000.0 + i * 60}
        for i, oc in enumerate(outcomes)
    ]
    engine.process_experiences(key, records)
    return store


# ---------------------------------------------------------------------------
# 1. Adapter initialisation
# ---------------------------------------------------------------------------

class TestAdapterInit:
    def test_default_construction(self):
        adapter = Phase12PipelineAdapter(session_id="test")
        assert adapter.session_id == "test"
        assert adapter.cycle_count == 0

    def test_build_default_does_not_raise(self):
        adapter = Phase12PipelineAdapter.build_default(session_id="test")
        assert adapter is not None

    def test_build_default_observation_mode(self):
        adapter = Phase12PipelineAdapter.build_default(
            session_id="test", improvement_mode="OBSERVATION_ONLY"
        )
        # Should have a decision engine
        if adapter._decision_engine is not None:
            assert adapter._decision_engine.config.mode == ImprovementMode.OBSERVATION_ONLY

    def test_build_default_invalid_mode_falls_back(self):
        adapter = Phase12PipelineAdapter.build_default(
            session_id="test", improvement_mode="NONEXISTENT"
        )
        # Should not raise; falls back to OBSERVATION_ONLY
        assert adapter is not None


# ---------------------------------------------------------------------------
# 2. observe() always returns
# ---------------------------------------------------------------------------

class TestObserveAlwaysReturns:
    def test_observe_minimal_snapshot(self):
        adapter = Phase12PipelineAdapter(session_id="t")
        result = adapter.observe(_FakeSnapshot())
        assert isinstance(result, Phase12CycleRecord)

    def test_observe_none_snapshot(self):
        adapter = Phase12PipelineAdapter(session_id="t")
        result = adapter.observe(None)
        assert isinstance(result, Phase12CycleRecord)

    def test_observe_increments_cycle(self):
        adapter = Phase12PipelineAdapter(session_id="t")
        adapter.observe(_FakeSnapshot())
        adapter.observe(_FakeSnapshot())
        assert adapter.cycle_count == 2

    def test_observe_sets_last_record(self):
        adapter = Phase12PipelineAdapter(session_id="t")
        adapter.observe(_FakeSnapshot(situation="MOTORCYCLE_CUT_IN"))
        record = adapter.get_last_cycle_record()
        assert record is not None

    def test_observe_extracts_gate_state(self):
        adapter = Phase12PipelineAdapter(session_id="t")
        record = adapter.observe(_FakeSnapshot(gate="CRITICAL"))
        assert record.safety_gate_state == "CRITICAL"

    def test_observe_with_degraded_pipeline(self):
        adapter = Phase12PipelineAdapter(session_id="t")
        result = adapter.observe(_FakeSnapshot(status="DEGRADED", degraded=True))
        assert isinstance(result, Phase12CycleRecord)
        assert result.degraded


# ---------------------------------------------------------------------------
# 3. Failure isolation
# ---------------------------------------------------------------------------

class TestFailureIsolation:
    def test_broken_knowledge_engine_does_not_crash(self):
        class BadEngine:
            def process_experiences(self, *a, **kw):
                raise RuntimeError("knowledge store broken")
        adapter = Phase12PipelineAdapter(
            session_id="t", knowledge_update_engine=BadEngine()
        )
        result = adapter.observe(_FakeSnapshot())
        assert isinstance(result, Phase12CycleRecord)

    def test_broken_decision_engine_does_not_crash(self):
        class BadDecision:
            def improve(self, **kw):
                raise RuntimeError("decision engine broken")
        adapter = Phase12PipelineAdapter(
            session_id="t", decision_improvement_engine=BadDecision()
        )
        result = adapter.observe(_FakeSnapshot())
        assert isinstance(result, Phase12CycleRecord)
        # improvement_result should be None (failure isolated)
        assert result.improvement_result is None

    def test_no_components_gives_minimal_record(self):
        adapter = Phase12PipelineAdapter(session_id="t")
        result = adapter.observe(_FakeSnapshot())
        assert isinstance(result, Phase12CycleRecord)
        assert result.improvement_available is False

    def test_exception_in_observe_returns_record(self):
        """Even if _observe_inner raises, observe() must return a record."""
        adapter = Phase12PipelineAdapter(session_id="t")
        # Pass a snapshot whose attribute access raises
        class ExplodingSnapshot:
            @property
            def pipeline_status(self): raise ValueError("boom")
            def __getattr__(self, name): raise AttributeError(name)
        result = adapter.observe(ExplodingSnapshot())
        assert isinstance(result, Phase12CycleRecord)


# ---------------------------------------------------------------------------
# 4. Knowledge → Decision Improvement chain
# ---------------------------------------------------------------------------

class TestKnowledgeToImprovement:
    def test_improvement_context_available_after_observe(self):
        store = _make_store(outcomes=["SUCCESS"] * 5)
        cfg = ImprovementConfig(
            mode=ImprovementMode.OBSERVATION_ONLY,
            minimum_knowledge_confidence=0.0,
            minimum_evidence_count=1,
        )
        d_engine = DecisionImprovementEngine(cfg, store)
        adapter = Phase12PipelineAdapter(
            session_id="t", decision_improvement_engine=d_engine
        )
        adapter.observe(_FakeSnapshot(gate="CAUTION", situation="PEDESTRIAN_CROSSING"))
        ctx = adapter.get_decision_improvement_context()
        assert ctx is not None

    def test_improvement_context_none_with_no_engine(self):
        adapter = Phase12PipelineAdapter(session_id="t")
        adapter.observe(_FakeSnapshot())
        ctx = adapter.get_decision_improvement_context()
        assert ctx is None

    def test_improvement_outcome_is_observation_by_default(self):
        store = _make_store(outcomes=["SUCCESS"] * 5)
        cfg = ImprovementConfig(mode=ImprovementMode.OBSERVATION_ONLY,
                                minimum_knowledge_confidence=0.0,
                                minimum_evidence_count=1)
        d_engine = DecisionImprovementEngine(cfg, store)
        adapter = Phase12PipelineAdapter(session_id="t", decision_improvement_engine=d_engine)
        snap = _FakeSnapshot(gate="CAUTION", situation="PEDESTRIAN_CROSSING")
        snap.planner_output.planning_context.situation_category = "PEDESTRIAN_CROSSING"
        adapter.observe(snap)
        ctx = adapter.get_decision_improvement_context()
        if ctx is not None:
            # OBSERVATION_ONLY should produce OBSERVATION outcome
            assert ctx.outcome == ImprovementOutcome.OBSERVATION

    def test_improvement_final_decision_always_set(self):
        store = _make_store()
        cfg = ImprovementConfig(mode=ImprovementMode.BOUNDED_ACTIVE,
                                minimum_knowledge_confidence=0.0,
                                minimum_evidence_count=1,
                                maximum_influence=0.10)
        d_engine = DecisionImprovementEngine(cfg, store)
        adapter = Phase12PipelineAdapter(session_id="t", decision_improvement_engine=d_engine)
        adapter.observe(_FakeSnapshot(gate="CLEAR", situation="PEDESTRIAN_CROSSING"))
        ctx = adapter.get_decision_improvement_context()
        if ctx is not None:
            assert ctx.final_decision  # must be non-empty


# ---------------------------------------------------------------------------
# 5. Safety boundaries
# ---------------------------------------------------------------------------

class TestSafetyBoundaries:
    def test_critical_gate_does_not_bypass_safety(self):
        """CRITICAL gate state must never be overridden by improvement."""
        store = _make_store(outcomes=["SUCCESS"] * 20)
        cfg = ImprovementConfig(mode=ImprovementMode.BOUNDED_ACTIVE,
                                minimum_knowledge_confidence=0.0,
                                minimum_evidence_count=1)
        d_engine = DecisionImprovementEngine(cfg, store)
        adapter = Phase12PipelineAdapter(session_id="t", decision_improvement_engine=d_engine)
        adapter.observe(_FakeSnapshot(gate="CRITICAL"))
        ctx = adapter.get_decision_improvement_context()
        if ctx is not None:
            # Safety veto must have been applied
            assert ctx.safety_veto in (SafetyVetoResult.VETOED, SafetyVetoResult.BYPASSED,
                                        SafetyVetoResult.UNKNOWN)

    def test_improvement_context_has_no_actuator_fields(self):
        store = _make_store()
        cfg = ImprovementConfig(mode=ImprovementMode.OBSERVATION_ONLY,
                                minimum_evidence_count=1)
        d_engine = DecisionImprovementEngine(cfg, store)
        adapter = Phase12PipelineAdapter(session_id="t", decision_improvement_engine=d_engine)
        adapter.observe(_FakeSnapshot())
        ctx = adapter.get_decision_improvement_context()
        if ctx is not None:
            for field_name in ('steering', 'throttle', 'brake', 'actuator'):
                assert not hasattr(ctx, field_name)

    def test_adapter_has_no_safety_gate_write(self):
        """Phase12PipelineAdapter must not have any method that writes to SafetyGate."""
        adapter = Phase12PipelineAdapter(session_id="t")
        for method_name in dir(adapter):
            assert "safety_gate" not in method_name.lower()
            assert "bypass_safety" not in method_name.lower()

    def test_fallback_always_available(self):
        """On improvement failure, baseline decision must be preserved."""
        class FailingDecision:
            def improve(self, **kw):
                raise RuntimeError("broken")
        adapter = Phase12PipelineAdapter(
            session_id="t", decision_improvement_engine=FailingDecision()
        )
        adapter.observe(_FakeSnapshot())
        # Should have no improvement context (fallback used)
        ctx = adapter.get_decision_improvement_context()
        assert ctx is None  # no context means baseline unchanged

    def test_historical_knowledge_does_not_override_current_gate(self):
        """Historical success knowledge must not override CRITICAL safety gate."""
        store = _make_store(outcomes=["SUCCESS"] * 50)
        cfg = ImprovementConfig(mode=ImprovementMode.BOUNDED_ACTIVE,
                                minimum_knowledge_confidence=0.0,
                                minimum_evidence_count=1,
                                maximum_influence=0.30)
        d_engine = DecisionImprovementEngine(cfg, store)

        # Improve directly with CRITICAL gate
        result = d_engine.improve(
            session_id="t",
            safety_gate_state="CRITICAL",
            baseline_decision="NORMAL_PROGRESS",
            baseline_score=0.80,
            context_key_dict={"road_type": "URBAN", "situation_type": "PEDESTRIAN_CROSSING"},
        )
        # Safety must win: either vetoed or baseline used
        assert result.final_decision == "NORMAL_PROGRESS" or \
               result.safety_veto == SafetyVetoResult.VETOED or \
               result.fallback_used


# ---------------------------------------------------------------------------
# 6. Direct control protection
# ---------------------------------------------------------------------------

class TestDirectControlProtection:
    def test_adapter_has_no_vehicle_control_methods(self):
        adapter = Phase12PipelineAdapter(session_id="t")
        for m in dir(adapter):
            assert "apply_control" not in m.lower()
            assert "set_steering" not in m.lower()
            assert "set_throttle" not in m.lower()

    def test_cycle_record_has_no_control_fields(self):
        adapter = Phase12PipelineAdapter(session_id="t")
        record = adapter.observe(_FakeSnapshot())
        assert not hasattr(record, 'steering_angle')
        assert not hasattr(record, 'throttle_percent')
        assert not hasattr(record, 'brake_pressure')


# ---------------------------------------------------------------------------
# 7. Feedback loop protection
# ---------------------------------------------------------------------------

class TestFeedbackLoopProtection:
    def test_repeated_cycles_do_not_amplify_unboundedly(self):
        """Repeated cycles with positive knowledge must not cause unbounded score growth."""
        store = _make_store(outcomes=["SUCCESS"] * 10)
        cfg = ImprovementConfig(mode=ImprovementMode.BOUNDED_ACTIVE,
                                minimum_knowledge_confidence=0.0,
                                minimum_evidence_count=1,
                                maximum_influence=0.10)
        d_engine = DecisionImprovementEngine(cfg, store)
        adapter = Phase12PipelineAdapter(session_id="t", decision_improvement_engine=d_engine)

        scores = []
        for _ in range(20):
            adapter.observe(_FakeSnapshot(gate="CLEAR", situation="PEDESTRIAN_CROSSING"))
            ctx = adapter.get_decision_improvement_context()
            if ctx is not None:
                scores.append(ctx.final_score)

        if scores:
            # All scores must be bounded [0, 1]
            assert all(0.0 <= s <= 1.0 for s in scores)
            # Score must not keep growing unboundedly
            assert max(scores) <= 1.0

    def test_knowledge_influence_is_bounded(self):
        """Experience adjustment must never exceed maximum_influence."""
        store = _make_store(outcomes=["SUCCESS"] * 50)
        max_inf = 0.08
        cfg = ImprovementConfig(mode=ImprovementMode.BOUNDED_ACTIVE,
                                minimum_knowledge_confidence=0.0,
                                minimum_evidence_count=1,
                                maximum_influence=max_inf)
        d_engine = DecisionImprovementEngine(cfg, store)

        for _ in range(10):
            result = d_engine.improve(
                session_id="t", safety_gate_state="CLEAR",
                baseline_decision="NORMAL_PROGRESS", baseline_score=0.70,
                context_key_dict={"road_type": "URBAN", "situation_type": "PEDESTRIAN_CROSSING"},
            )
            assert abs(result.experience_adjustment) <= max_inf + 1e-9


# ---------------------------------------------------------------------------
# 8. Determinism
# ---------------------------------------------------------------------------

class TestDeterminism:
    def test_same_inputs_same_improvement(self):
        store = _make_store(outcomes=["SUCCESS"] * 5)
        cfg = ImprovementConfig(mode=ImprovementMode.BOUNDED_ACTIVE,
                                minimum_knowledge_confidence=0.0,
                                minimum_evidence_count=1)
        results = []
        for _ in range(3):
            d_engine = DecisionImprovementEngine(cfg, store)
            result = d_engine.improve(
                session_id="t", safety_gate_state="CLEAR",
                baseline_decision="NORMAL_PROGRESS", baseline_score=0.70,
                context_key_dict={"road_type": "URBAN", "situation_type": "PEDESTRIAN_CROSSING"},
            )
            results.append(result.final_score)
        # All results should be identical
        assert len(set(round(r, 6) for r in results)) == 1


# ---------------------------------------------------------------------------
# 9. Rollback
# ---------------------------------------------------------------------------

class TestRollback:
    def test_manual_rollback_downgrades_mode(self):
        store = _make_store()
        cfg = ImprovementConfig.bounded_active()
        d_engine = DecisionImprovementEngine(cfg, store)
        assert d_engine.config.mode == ImprovementMode.BOUNDED_ACTIVE
        d_engine.rollback_to_observation("test")
        assert d_engine.config.mode == ImprovementMode.OBSERVATION_ONLY

    def test_rollback_preserves_safety(self):
        store = _make_store()
        cfg = ImprovementConfig.bounded_active()
        d_engine = DecisionImprovementEngine(cfg, store)
        d_engine.rollback_to_observation("test")
        assert d_engine.config.effective_safety_required()

    def test_rollback_does_not_corrupt_store(self):
        store = _make_store(outcomes=["SUCCESS"] * 5)
        cfg = ImprovementConfig.bounded_active()
        d_engine = DecisionImprovementEngine(cfg, store)
        d_engine.rollback_to_observation("test")
        # Store should still have its entries
        assert len(store.list_active()) >= 1


# ---------------------------------------------------------------------------
# 10. Indian road scenarios
# ---------------------------------------------------------------------------

class TestIndianRoadScenarios:
    def _run_scenario(self, situation: str, gate: str = "CAUTION",
                      outcomes=None) -> Phase12CycleRecord:
        store = _make_store(outcomes=outcomes or ["SUCCESS"] * 5)
        cfg = ImprovementConfig(mode=ImprovementMode.OBSERVATION_ONLY,
                                minimum_knowledge_confidence=0.0,
                                minimum_evidence_count=1)
        d_engine = DecisionImprovementEngine(cfg, store)
        adapter = Phase12PipelineAdapter(session_id="t", decision_improvement_engine=d_engine)
        return adapter.observe(_FakeSnapshot(gate=gate, situation=situation))

    def test_pedestrian_crossing(self):
        record = self._run_scenario("PEDESTRIAN_CROSSING")
        assert isinstance(record, Phase12CycleRecord)

    def test_cattle_crossing(self):
        record = self._run_scenario("CATTLE_CROSSING", gate="RESTRICTED")
        assert isinstance(record, Phase12CycleRecord)

    def test_motorcycle_cut_in(self):
        record = self._run_scenario("MOTORCYCLE_CUT_IN")
        assert isinstance(record, Phase12CycleRecord)

    def test_narrow_road(self):
        record = self._run_scenario("NARROW_ROAD", outcomes=["PARTIAL_SUCCESS"] * 3)
        assert isinstance(record, Phase12CycleRecord)

    def test_dense_intersection_unsafe_history(self):
        """Unsafe history must not force unsafe action."""
        store = _make_store(outcomes=["UNSAFE_OUTCOME"] * 5)
        cfg = ImprovementConfig(mode=ImprovementMode.BOUNDED_ACTIVE,
                                minimum_knowledge_confidence=0.0,
                                minimum_evidence_count=1,
                                maximum_influence=0.10)
        d_engine = DecisionImprovementEngine(cfg, store)
        result = d_engine.improve(
            session_id="t", safety_gate_state="CAUTION",
            baseline_decision="COLLISION_AVOIDANCE_REQUIRED", baseline_score=0.90,
            context_key_dict={"road_type": "URBAN", "situation_type": "DENSE_INTERSECTION"},
        )
        assert 0.0 <= result.final_score <= 1.0
        assert result.final_decision  # non-empty


# ---------------------------------------------------------------------------
# 11. Phase 12.6 modes in pipeline context
# ---------------------------------------------------------------------------

class TestPipelineModes:
    def test_disabled_mode_no_change(self):
        store = _make_store(outcomes=["SUCCESS"] * 10)
        cfg = ImprovementConfig(mode=ImprovementMode.DISABLED)
        d_engine = DecisionImprovementEngine(cfg, store)
        adapter = Phase12PipelineAdapter(session_id="t", decision_improvement_engine=d_engine)
        adapter.observe(_FakeSnapshot())
        ctx = adapter.get_decision_improvement_context()
        if ctx is not None:
            assert ctx.outcome == ImprovementOutcome.DISABLED

    def test_observation_mode_no_change(self):
        store = _make_store(outcomes=["SUCCESS"] * 10)
        cfg = ImprovementConfig(mode=ImprovementMode.OBSERVATION_ONLY,
                                minimum_knowledge_confidence=0.0, minimum_evidence_count=1)
        d_engine = DecisionImprovementEngine(cfg, store)
        adapter = Phase12PipelineAdapter(session_id="t", decision_improvement_engine=d_engine)
        adapter.observe(_FakeSnapshot(gate="CLEAR", situation="PEDESTRIAN_CROSSING"))
        ctx = adapter.get_decision_improvement_context()
        if ctx is not None:
            assert ctx.outcome == ImprovementOutcome.OBSERVATION
