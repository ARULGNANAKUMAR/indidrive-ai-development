"""Shared fixtures and helpers for Phase 4D tests."""
import math
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))

from core.perception.perception_types import Position3D, SourceSensor, HealthState
from core.fusion.fusion_types import FusedObject, FusedWorldState, FusionMode
from core.prediction.prediction_types import MotionState, PredictedState, PredictedObject
from core.prediction.phase4c_types import Phase4CObject
from core.prediction.object_behaviour import ObjectBehaviourClass
from core.prediction.sensor_quality import SensorQuality
from core.prediction.path_selector import PredictionPath
from core.prediction.ttc_engine import EgoKinematics


def fused_obj(track_id, t, x, y, vx=1.0, vy=0.0, heading=0.0, obj_class="car"):
    return FusedObject(
        fused_object_id=f"fused_{track_id}",
        object_class=obj_class,
        class_confidence=0.9,
        position_3d=Position3D(x, y, 0.0),
        velocity=(vx, vy, 0.0),
        dimensions=None,
        heading=heading,
        distance=math.hypot(x, y),
        bbox_2d=None,
        source_sensors=frozenset({SourceSensor.CAMERA}),
        position_confidence=0.9,
        existence_probability=0.9,
        track_id=track_id,
        timestamp=t,
    )


def world(objects, t=1.0, frame_id=1):
    return FusedWorldState(
        timestamp=t, frame_id=frame_id,
        fusion_mode=FusionMode.SINGLE_SENSOR,
        objects=objects,
    )


def motion_state(x=0.0, y=0.0, vx=0.0, vy=0.0, ax=0.0, ay=0.0, heading=0.0):
    speed = math.hypot(vx, vy)
    return MotionState(
        x=x, y=y, z=0.0,
        vx=vx, vy=vy, vz=0.0,
        ax=ax, ay=ay, az=0.0,
        yaw=heading, yaw_rate=0.0,
        speed=speed, heading=heading,
        timestamp=1.0,
    )


def predicted_obj(track_id="t1", x=10.0, y=0.0, vx=-2.0, vy=0.0,
                  horizons=None, obj_type="car"):
    if horizons is None:
        horizons = [0.5, 1.0, 2.0, 3.0, 5.0]
    state = motion_state(x=x, y=y, vx=vx, vy=vy)
    trajectory = []
    for h in horizons:
        trajectory.append(PredictedState(
            timestamp=1.0 + h,
            x=x + vx * h,
            y=y + vy * h,
            z=0.0,
            vx=vx, vy=vy, vz=0.0,
            yaw=0.0, speed=abs(vx),
            horizon_s=h,
        ))
    return PredictedObject(
        track_id=track_id,
        object_type=obj_type,
        current_state=state,
        trajectory=trajectory,
        prediction_confidence=0.85,
        uncertainty={"sigma_x": 0.3, "sigma_y": 0.3, "sigma_vx": 0.1, "sigma_vy": 0.1},
    )


def make_p4c_obj(track_id="t1", x=10.0, y=0.0, vx=-2.0, vy=0.0,
                 horizons=None, obj_type="car"):
    pred = predicted_obj(track_id=track_id, x=x, y=y, vx=vx, vy=vy,
                         horizons=horizons, obj_type=obj_type)
    return Phase4CObject(
        predicted=pred,
        behaviour_class=ObjectBehaviourClass.CAR,
        sensor_quality=SensorQuality.HIGH_CONFIDENCE,
        prediction_path=PredictionPath.FAST,
        coasted=False,
    )


def ego(x=0.0, y=0.0, vx=5.0, vy=0.0):
    return EgoKinematics(x=x, y=y, vx=vx, vy=vy)
