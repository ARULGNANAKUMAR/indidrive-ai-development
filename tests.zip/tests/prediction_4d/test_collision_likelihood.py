"""test_collision_likelihood.py — Collision likelihood scoring."""
import math, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))

from core.prediction.collision_likelihood import compute_collision_likelihood, classify_risk_level
from core.prediction.phase4d_types import TTCResult, TTCStatus, ClosestApproachResult, RiskLevel
from core.prediction.trajectory_intersection import IntersectionResult


def _ca(dist=10.0, t=1.0):
    return ClosestApproachResult(dist, t, 0.0, 0.0, 0.0, 0.0)


def _ir(intersects=False, overlap=0, sep=5.0):
    return IntersectionResult(
        intersects=intersects,
        earliest_intersection_s=0.5 if intersects else None,
        overlap_count=overlap,
        min_separation_m=sep,
    )


def test_imminent_collision_high_score():
    ttc = TTCResult(ttc_s=0.5, status=TTCStatus.FINITE, closing_speed_ms=20.0)
    ca = _ca(dist=1.0, t=0.5)
    ir = _ir(intersects=True, overlap=5, sep=0.0)
    score = compute_collision_likelihood(ttc, ca, ir, 0.9, {})
    assert score > 0.5


def test_diverging_low_score():
    ttc = TTCResult(ttc_s=None, status=TTCStatus.NO_COLLISION, closing_speed_ms=-5.0)
    ca = _ca(dist=80.0, t=5.0)
    ir = _ir(intersects=False, overlap=0, sep=80.0)
    score = compute_collision_likelihood(ttc, ca, ir, 0.9, {})
    assert score < 0.3


def test_score_in_range():
    for ttc_s in [0.5, 1.0, 3.0, None]:
        status = TTCStatus.FINITE if ttc_s else TTCStatus.NO_COLLISION
        ttc = TTCResult(ttc_s=ttc_s, status=status, closing_speed_ms=5.0)
        ca = _ca(dist=20.0)
        ir = _ir()
        score = compute_collision_likelihood(ttc, ca, ir, 0.8, {})
        assert 0.0 <= score <= 1.0, f"Score out of range: {score}"


def test_score_is_finite():
    ttc = TTCResult(ttc_s=2.0, status=TTCStatus.FINITE, closing_speed_ms=10.0)
    ca = _ca(dist=15.0)
    ir = _ir(intersects=True, overlap=2, sep=0.0)
    score = compute_collision_likelihood(ttc, ca, ir, 0.7, {})
    assert math.isfinite(score)


def test_unknown_ttc_conservative():
    ttc = TTCResult(ttc_s=None, status=TTCStatus.UNKNOWN, closing_speed_ms=None)
    ca = _ca(dist=5.0)
    ir = _ir()
    score = compute_collision_likelihood(ttc, ca, ir, 0.5, {})
    # Conservative — should be non-zero
    assert score > 0.0


def test_no_collision_status():
    ttc = TTCResult(ttc_s=None, status=TTCStatus.NO_COLLISION, closing_speed_ms=-2.0)
    ca = _ca(dist=100.0)
    ir = _ir(intersects=False, sep=100.0)
    score = compute_collision_likelihood(ttc, ca, ir, 0.95, {})
    assert score < 0.3


def test_classify_risk_level_boundaries():
    assert classify_risk_level(0.0) == RiskLevel.LOW
    assert classify_risk_level(0.24) == RiskLevel.LOW
    assert classify_risk_level(0.25) == RiskLevel.MEDIUM
    assert classify_risk_level(0.50) == RiskLevel.HIGH
    assert classify_risk_level(0.75) == RiskLevel.CRITICAL
    assert classify_risk_level(1.0) == RiskLevel.CRITICAL
