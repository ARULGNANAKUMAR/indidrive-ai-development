"""test_ttc_edge_cases.py — Edge cases and robustness."""
import math, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))

from core.prediction.ttc_engine import compute_ttc
from core.prediction.phase4d_types import TTCStatus


def test_missing_obj_velocity():
    r = compute_ttc(0, 0, 5, 0, 20, 0, None, None)
    # Should not crash; treated conservatively as stationary object
    assert r.status in {TTCStatus.FINITE, TTCStatus.UNKNOWN}
    if r.ttc_s is not None:
        assert math.isfinite(r.ttc_s)


def test_nan_ego_velocity():
    r = compute_ttc(0, 0, float("nan"), 0, 20, 0, 0, 0)
    assert r.status == TTCStatus.UNKNOWN
    assert r.ttc_s is None


def test_inf_obj_position():
    r = compute_ttc(0, 0, 5, 0, float("inf"), 0, 0, 0)
    assert r.status == TTCStatus.UNKNOWN


def test_nan_obj_velocity():
    r = compute_ttc(0, 0, 5, 0, 20, 0, float("nan"), 0)
    # nan vx treated as missing → treated as stationary
    assert r.status in {TTCStatus.FINITE, TTCStatus.UNKNOWN, TTCStatus.NO_COLLISION}
    if r.ttc_s is not None:
        assert math.isfinite(r.ttc_s)


def test_very_large_distance():
    r = compute_ttc(0, 0, 1, 0, 1e6, 0, 0, 0)
    assert r.status == TTCStatus.FINITE
    assert r.ttc_s > 1000


def test_very_small_collision_radius():
    r = compute_ttc(0, 0, 5, 0, 20, 0, 0, 0, collision_radius_m=0.01)
    assert r.status in {TTCStatus.FINITE, TTCStatus.NO_COLLISION}


def test_negative_ttc_never_returned():
    # Ensure no negative TTC value is ever returned
    for vx in [-5, 0, 5, 10]:
        r = compute_ttc(0, 0, vx, 0, 20, 0, -3, 0)
        if r.ttc_s is not None:
            assert r.ttc_s >= 0.0, f"Negative TTC returned: {r.ttc_s} for vx={vx}"


def test_status_is_explicit_enum():
    r = compute_ttc(0, 0, 5, 0, 20, 0, 0, 0)
    assert isinstance(r.status, TTCStatus)


def test_no_nan_no_inf_in_result():
    for scenario in [
        (0, 0, 5, 0, 20, 0, 0, 0),
        (0, 0, 0, 0, 10, 0, 0, 0),
        (0, 0, 5, 0, 5, 5, -3, 4),
        (0, 0, 10, 0, 100, 0, -10, 0),
    ]:
        r = compute_ttc(*scenario)
        if r.ttc_s is not None:
            assert math.isfinite(r.ttc_s), f"Non-finite TTC for {scenario}"
        if r.closing_speed_ms is not None:
            assert math.isfinite(r.closing_speed_ms)


def test_to_dict_no_nan():
    r = compute_ttc(0, 0, 5, 0, 20, 0, 0, 0)
    d = r.to_dict()
    for v in d.values():
        if isinstance(v, float):
            assert math.isfinite(v)
