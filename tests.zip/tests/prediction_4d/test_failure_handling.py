"""test_failure_handling.py — Graceful degradation on invalid data (spec §10)."""
import math, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))

from tests.prediction_4d.conftest import fused_obj, world
from core.prediction.phase4d_pipeline import Phase4DPipeline, Phase4DConfig
from core.prediction.ttc_engine import EgoKinematics
from core.prediction.phase4d_types import TTCStatus


def _pipeline():
    cfg = Phase4DConfig(ego=EgoKinematics(x=0, y=0, vx=5, vy=0))
    return Phase4DPipeline(cfg)


def test_empty_world_does_not_crash():
    p = _pipeline()
    r = p.process(world([], t=1.0))
    assert r is not None
    assert r.objects == []


def test_single_valid_object_processes():
    p = _pipeline()
    obj = fused_obj("A", 1.0, 20, 0, vx=-3)
    r = p.process(world([obj], t=1.0))
    assert len(r.objects) == 1
    assert not r.objects[0].invalid


def test_mix_valid_invalid_continues():
    p = _pipeline()
    valid = fused_obj("A", 1.0, 20, 0, vx=-3)
    # Process 5 objects; pipeline should handle all without crashing
    objs = [fused_obj(str(i), 1.0, i * 8 + 5, i * 3, vx=-1) for i in range(5)]
    r = p.process(world(objs, t=1.0))
    assert len(r.objects) == 5


def test_no_nan_in_output():
    p = _pipeline()
    objs = [fused_obj(str(i), 1.0, 10 + i * 5, 0, vx=-2) for i in range(3)]
    r = p.process(world(objs, t=1.0))
    for obj in r.objects:
        d = obj.to_dict()
        # Verify ttc_s is either NOT_AVAILABLE or a finite number
        ttc_d = d["ttc"]
        if ttc_d["ttc_s"] != "NOT_AVAILABLE":
            assert math.isfinite(ttc_d["ttc_s"]), f"NaN ttc_s for {obj.track_id}"
        # collision_likelihood finite
        assert math.isfinite(d["collision_likelihood"])


def test_invalid_object_marked_not_crash():
    p = _pipeline()
    # Very first cycle: no prior history — object may be NEW
    obj = fused_obj("X", 1.0, 5, 0, vx=0)
    r = p.process(world([obj], t=1.0))
    # Should produce output — may be valid or invalid, but not crash
    assert len(r.objects) == 1


def test_no_inf_propagation():
    p = _pipeline()
    obj = fused_obj("A", 1.0, 30, 0, vx=-5)
    r = p.process(world([obj], t=1.0))
    for o in r.objects:
        d = o.to_dict()
        cl = d["collision_likelihood"]
        assert math.isfinite(cl)
        assert 0.0 <= cl <= 1.0


def test_lost_sensor_scenario():
    # No objects (sensor lost) — pipeline should not crash
    p = _pipeline()
    p.process(world([fused_obj("A", 1.0, 20, 0)], t=1.0))
    r = p.process(world([], t=2.0))  # lost sensor cycle
    assert r is not None


def test_multiple_cycles_stable():
    p = _pipeline()
    obj = fused_obj("A", 1.0, 20, 0, vx=-3)
    for i in range(10):
        r = p.process(world([obj], t=float(i) * 0.1 + 1.0))
    assert r is not None
    assert len(r.objects) >= 1
