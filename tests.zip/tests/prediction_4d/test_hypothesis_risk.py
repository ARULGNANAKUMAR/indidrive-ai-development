"""test_hypothesis_risk.py — Per-hypothesis risk evaluation."""
import math, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))

from core.prediction.collision_likelihood import compute_hypothesis_risks, classify_risk_level
from core.prediction.phase4d_types import TTCResult, TTCStatus, ClosestApproachResult, RiskLevel
from core.prediction.trajectory_intersection import IntersectionResult
from core.prediction.hypothesis_types import TrackHypothesisSet, TrajectoryHypothesis, BehaviourType
from core.prediction.prediction_types import ModelType


def _hyp(behaviour, prob=0.4):
    return TrajectoryHypothesis(
        track_id="t1", model=ModelType.CV,
        behaviour=behaviour, probability=prob, confidence=prob,
    )


def _hyp_set(*behaviours_probs):
    hyps = [_hyp(b, p) for b, p in behaviours_probs]
    return TrackHypothesisSet(track_id="t1", object_type="car", is_stable=True, hypotheses=hyps)


def _ttc(ttc_s=1.5):
    return TTCResult(ttc_s=ttc_s, status=TTCStatus.FINITE, closing_speed_ms=10.0)


def _ca(dist=5.0):
    return ClosestApproachResult(dist, 1.5, 0.0, 0.0, 0.0, 0.0)


def _ir(intersects=True):
    return IntersectionResult(intersects=intersects, earliest_intersection_s=1.0,
                               overlap_count=2, min_separation_m=0.0)


def test_hypothesis_risks_returned_for_each_hypothesis():
    hs = _hyp_set(
        (BehaviourType.STRAIGHT, 0.5),
        (BehaviourType.LEFT, 0.3),
        (BehaviourType.RIGHT, 0.2),
    )
    risks = compute_hypothesis_risks(hs, 0.4, _ttc(), _ca(), _ir())
    assert len(risks) == 3
    behaviours = {r.behaviour for r in risks}
    assert "STRAIGHT" in behaviours
    assert "LEFT" in behaviours


def test_left_turn_higher_risk_than_braking():
    hs_left = _hyp_set((BehaviourType.LEFT, 1.0))
    hs_brake = _hyp_set((BehaviourType.BRAKING, 1.0))
    r_left = compute_hypothesis_risks(hs_left, 0.5, _ttc(), _ca(), _ir())
    r_brake = compute_hypothesis_risks(hs_brake, 0.5, _ttc(), _ca(), _ir())
    assert r_left[0].collision_likelihood >= r_brake[0].collision_likelihood


def test_acceleration_highest_modifier():
    hs = _hyp_set((BehaviourType.ACCELERATION, 1.0))
    r = compute_hypothesis_risks(hs, 0.5, _ttc(), _ca(), _ir())
    assert r[0].collision_likelihood > 0.5


def test_braking_reduces_risk():
    hs = _hyp_set((BehaviourType.BRAKING, 1.0))
    r = compute_hypothesis_risks(hs, 0.6, _ttc(), _ca(), _ir())
    assert r[0].collision_likelihood <= 0.6


def test_risk_level_assigned():
    hs = _hyp_set((BehaviourType.STRAIGHT, 0.7), (BehaviourType.LEFT, 0.3))
    risks = compute_hypothesis_risks(hs, 0.4, _ttc(), _ca(), _ir())
    for r in risks:
        assert isinstance(r.risk_level, RiskLevel)


def test_none_hypothesis_set_returns_empty():
    risks = compute_hypothesis_risks(None, 0.5, _ttc(), _ca(), _ir())
    assert risks == []


def test_zero_probability_hypothesis_excluded():
    hs = _hyp_set((BehaviourType.LEFT, 0.0), (BehaviourType.STRAIGHT, 0.8))
    risks = compute_hypothesis_risks(hs, 0.4, _ttc(), _ca(), _ir())
    behaviours = [r.behaviour for r in risks]
    assert "LEFT" not in behaviours


def test_collision_likelihood_in_range():
    hs = _hyp_set(
        (BehaviourType.STRAIGHT, 0.4),
        (BehaviourType.LEFT, 0.3),
        (BehaviourType.RIGHT, 0.2),
        (BehaviourType.BRAKING, 0.1),
    )
    risks = compute_hypothesis_risks(hs, 0.5, _ttc(), _ca(), _ir())
    for r in risks:
        assert 0.0 <= r.collision_likelihood <= 1.0
