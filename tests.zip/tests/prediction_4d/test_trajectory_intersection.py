"""test_trajectory_intersection.py — Trajectory intersection detection."""
import math, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))

from core.prediction.trajectory_intersection import check_trajectory_intersection
from core.prediction.closest_approach import build_ego_trajectory
from core.prediction.prediction_types import PredictedState


def make_traj(x0, y0, vx, vy, horizons=None):
    if horizons is None:
        horizons = [0.5, 1.0, 2.0, 3.0, 5.0]
    return [
        PredictedState(
            timestamp=h, x=x0 + vx * h, y=y0 + vy * h,
            z=0.0, vx=vx, vy=vy, vz=0.0,
            yaw=0.0, speed=math.hypot(vx, vy), horizon_s=h,
        )
        for h in horizons
    ]


def test_head_on_intersection_detected():
    # Use fine-grained horizons so the crossing at t=2.5 is sampled
    horizons = [0.5 * i for i in range(1, 13)]  # 0.5, 1.0 ... 6.0
    ego = make_traj(0, 0, 10, 0, horizons=horizons)
    obj = make_traj(50, 0, -10, 0, horizons=horizons)
    # At t=2.5: ego_x=25, obj_x=25 → same position
    r = check_trajectory_intersection(ego, obj, ego_half_width=2.0, obj_half_width=2.0)
    assert r.intersects
    assert r.earliest_intersection_s is not None
    assert r.earliest_intersection_s >= 0


def test_parallel_lanes_no_intersection():
    ego = make_traj(0, 0, 5, 0, horizons=[1.0, 2.0, 3.0])
    obj = make_traj(0, 10, 5, 0, horizons=[1.0, 2.0, 3.0])
    r = check_trajectory_intersection(ego, obj, ego_half_width=0.9, obj_half_width=0.9)
    assert not r.intersects


def test_overlap_count_positive_when_intersecting():
    # Object very close to ego path at same speed with large radius
    ego = make_traj(0, 0, 5, 0, horizons=[1.0, 2.0, 3.0])
    obj = make_traj(5, 0, 5, 0, horizons=[1.0, 2.0, 3.0])
    r = check_trajectory_intersection(ego, obj, ego_half_width=5.0, obj_half_width=5.0)
    if r.intersects:
        assert r.overlap_count > 0


def test_min_separation_non_negative():
    ego = make_traj(0, 0, 2, 0)
    obj = make_traj(50, 50, -2, -2)
    r = check_trajectory_intersection(ego, obj)
    assert r.min_separation_m >= 0.0


def test_empty_object_trajectory():
    ego = make_traj(0, 0, 5, 0)
    r = check_trajectory_intersection(ego, [])
    assert not r.intersects
    assert r.overlap_count == 0


def test_empty_ego_trajectory_uses_fallback():
    # Object at 0.5m — should intersect with ego at origin (large radius)
    obj = make_traj(0.5, 0, 0, 0, horizons=[0.5, 1.0])
    r = check_trajectory_intersection([], obj,
                                       ego_fallback_x=0, ego_fallback_y=0,
                                       ego_fallback_vx=0, ego_fallback_vy=0,
                                       ego_half_width=2.0, obj_half_width=2.0)
    assert r.intersects


def test_result_is_deterministic():
    ego = make_traj(0, 0, 5, 0)
    obj = make_traj(20, 0, -3, 0)
    r1 = check_trajectory_intersection(ego, obj)
    r2 = check_trajectory_intersection(ego, obj)
    assert r1.intersects == r2.intersects
    assert r1.overlap_count == r2.overlap_count


def test_crossing_paths_with_fine_horizons():
    # ego going +x, object going from x=0,y=20 downward — crossing near origin
    horizons = [i * 0.25 for i in range(1, 21)]
    ego = make_traj(0, 0, 3, 0, horizons=horizons)
    obj = make_traj(0, 15, 0, -3, horizons=horizons)
    r = check_trajectory_intersection(ego, obj, ego_half_width=3.0, obj_half_width=3.0)
    # At t~1.67: obj at y=0 (ego lane); ego at x~5; they're close
    assert isinstance(r.intersects, bool)  # just verify it runs without crash
