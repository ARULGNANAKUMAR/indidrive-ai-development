"""test_risk_levels.py — Risk level classification."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))

from core.prediction.collision_likelihood import classify_risk_level
from core.prediction.phase4d_types import RiskLevel


def test_low_risk():
    assert classify_risk_level(0.0) == RiskLevel.LOW
    assert classify_risk_level(0.1) == RiskLevel.LOW
    assert classify_risk_level(0.24) == RiskLevel.LOW


def test_medium_risk():
    assert classify_risk_level(0.25) == RiskLevel.MEDIUM
    assert classify_risk_level(0.30) == RiskLevel.MEDIUM
    assert classify_risk_level(0.49) == RiskLevel.MEDIUM


def test_high_risk():
    assert classify_risk_level(0.50) == RiskLevel.HIGH
    assert classify_risk_level(0.60) == RiskLevel.HIGH
    assert classify_risk_level(0.74) == RiskLevel.HIGH


def test_critical_risk():
    assert classify_risk_level(0.75) == RiskLevel.CRITICAL
    assert classify_risk_level(0.90) == RiskLevel.CRITICAL
    assert classify_risk_level(1.0) == RiskLevel.CRITICAL


def test_risk_is_enum():
    for score in [0.0, 0.25, 0.5, 0.75, 1.0]:
        rl = classify_risk_level(score)
        assert isinstance(rl, RiskLevel)


def test_risk_not_safety_decision():
    # Risk level is prediction-level only, not final safety decision.
    # Verify all four levels are reachable and distinct.
    levels = {
        classify_risk_level(0.1),
        classify_risk_level(0.3),
        classify_risk_level(0.6),
        classify_risk_level(0.9),
    }
    assert len(levels) == 4


def test_monotone():
    # Higher likelihood should produce >= risk level (ordinal)
    order = [RiskLevel.LOW, RiskLevel.MEDIUM, RiskLevel.HIGH, RiskLevel.CRITICAL]
    scores = [0.1, 0.3, 0.6, 0.9]
    for i, score in enumerate(scores):
        rl = classify_risk_level(score)
        assert rl == order[i]
