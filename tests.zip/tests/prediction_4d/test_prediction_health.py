"""test_prediction_health.py — Prediction health counters (spec §9)."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))

from tests.prediction_4d.conftest import fused_obj, world
from core.prediction.phase4d_pipeline import Phase4DPipeline, Phase4DConfig
from core.prediction.ttc_engine import EgoKinematics


def _pipeline():
    cfg = Phase4DConfig(ego=EgoKinematics(x=0, y=0, vx=5, vy=0))
    return Phase4DPipeline(cfg)


def test_prediction_cycles_increments():
    p = _pipeline()
    obj = fused_obj("A", 1.0, 20, 0, vx=-3)
    w = world([obj], t=1.0)
    p.process(w)
    p.process(w)
    p.process(w)
    # Get last result
    r = p.process(world([obj], t=2.0))
    assert r.metrics.prediction_cycles == 4


def test_valid_objects_counted():
    p = _pipeline()
    a = fused_obj("A", 1.0, 20, 0, vx=-3)
    b = fused_obj("B", 1.0, 10, 5, vx=0)
    r = p.process(world([a, b], t=1.0))
    assert r.metrics.valid_objects + r.metrics.invalid_objects == r.metrics.object_count


def test_object_count_matches():
    p = _pipeline()
    objs = [fused_obj(str(i), 1.0, i * 10, 0, vx=-2) for i in range(5)]
    r = p.process(world(objs, t=1.0))
    assert r.metrics.object_count == len(r.objects)


def test_average_latency_non_zero_after_cycle():
    p = _pipeline()
    obj = fused_obj("A", 1.0, 20, 0, vx=-3)
    r = p.process(world([obj], t=1.0))
    assert r.metrics.average_latency_ms > 0


def test_maximum_latency_tracked():
    p = _pipeline()
    obj = fused_obj("A", 1.0, 20, 0, vx=-3)
    for i in range(5):
        r = p.process(world([obj], t=float(i)))
    assert r.metrics.maximum_latency_ms >= r.metrics.average_latency_ms


def test_metrics_to_dict_complete():
    p = _pipeline()
    obj = fused_obj("A", 1.0, 20, 0)
    r = p.process(world([obj], t=1.0))
    d = r.metrics.to_dict()
    required = [
        "prediction_cycles", "valid_objects", "invalid_objects",
        "lost_tracks", "stale_tracks", "prediction_failures",
        "average_latency_ms", "maximum_latency_ms", "object_count",
        "ttc_latency_ms", "closest_approach_latency_ms",
        "collision_likelihood_latency_ms", "total_prediction_latency_ms",
    ]
    for key in required:
        assert key in d, f"Missing metric key: {key}"


def test_reset_clears_cycles():
    p = _pipeline()
    obj = fused_obj("A", 1.0, 20, 0)
    p.process(world([obj], t=1.0))
    p.process(world([obj], t=2.0))
    p.reset()
    r = p.process(world([obj], t=3.0))
    assert r.metrics.prediction_cycles == 1
