"""test_closest_approach.py — Closest approach calculation."""
import math, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))

from core.prediction.closest_approach import compute_closest_approach, build_ego_trajectory
from core.prediction.prediction_types import PredictedState


def make_traj(x0, y0, vx, vy, horizons=None):
    if horizons is None:
        horizons = [0.5, 1.0, 2.0, 3.0, 5.0]
    return [
        PredictedState(
            timestamp=h, x=x0 + vx * h, y=y0 + vy * h,
            z=0.0, vx=vx, vy=vy, vz=0.0,
            yaw=0.0, speed=math.hypot(vx, vy), horizon_s=h,
        )
        for h in horizons
    ]


def test_head_on_collision_closest_is_small():
    ego = make_traj(0, 0, 5, 0)
    obj = make_traj(50, 0, -5, 0)
    r = compute_closest_approach(ego, obj)
    assert r.minimum_distance_m >= 0.0
    assert math.isfinite(r.minimum_distance_m)
    # At t=5 they meet at x=25
    assert r.minimum_distance_m < 5.0


def test_parallel_same_direction_constant_separation():
    ego = make_traj(0, 0, 5, 0)
    obj = make_traj(0, 10, 5, 0)
    r = compute_closest_approach(ego, obj)
    # Should be ~10 m apart always
    assert abs(r.minimum_distance_m - 10.0) < 2.0


def test_diverging_objects():
    ego = make_traj(0, 0, -5, 0)
    obj = make_traj(10, 0, 5, 0)
    r = compute_closest_approach(ego, obj)
    assert r.minimum_distance_m > 0.0


def test_empty_obj_trajectory_falls_back():
    ego = make_traj(0, 0, 5, 0)
    r = compute_closest_approach(ego, [], ego_fallback_x=0, ego_fallback_y=0)
    assert r.minimum_distance_m >= 0.0
    assert math.isfinite(r.minimum_distance_m)


def test_empty_ego_trajectory_uses_fallback():
    obj = make_traj(20, 0, -4, 0)
    r = compute_closest_approach([], obj, ego_fallback_x=0, ego_fallback_y=0,
                                  ego_fallback_vx=5, ego_fallback_vy=0)
    assert math.isfinite(r.minimum_distance_m)


def test_time_of_closest_approach_non_negative():
    ego = make_traj(0, 0, 3, 0)
    obj = make_traj(30, 0, -3, 0)
    r = compute_closest_approach(ego, obj)
    assert r.time_of_closest_approach_s >= 0.0


def test_relative_position_finite():
    ego = make_traj(0, 0, 2, 0)
    obj = make_traj(10, 5, -1, 0)
    r = compute_closest_approach(ego, obj)
    assert math.isfinite(r.relative_position_x)
    assert math.isfinite(r.relative_position_y)
    assert math.isfinite(r.relative_velocity_x)
    assert math.isfinite(r.relative_velocity_y)


def test_build_ego_trajectory():
    traj = build_ego_trajectory(0, 0, 5, 0, [0.5, 1.0, 2.0])
    assert len(traj) == 3
    assert abs(traj[-1].x - 10.0) < 1e-6
    for s in traj:
        assert math.isfinite(s.x)
        assert math.isfinite(s.y)


def test_minimum_distance_always_non_negative():
    for x0, vx in [(20, -5), (5, 10), (100, -20)]:
        ego = make_traj(0, 0, 5, 0)
        obj = make_traj(x0, 0, vx, 0)
        r = compute_closest_approach(ego, obj)
        assert r.minimum_distance_m >= 0.0, f"Negative distance for x0={x0}, vx={vx}"
