"""
test_offline_replay.py — Offline replay: FusedWorldState → 4A → 4B → 4C → 4D.
No cloud API. No internet requirement (spec §14).
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))

from tests.prediction_4d.conftest import fused_obj, world
from core.prediction.phase4d_pipeline import Phase4DPipeline, Phase4DConfig
from core.prediction.ttc_engine import EgoKinematics
from core.prediction.phase4d_types import Phase4DWorldState


def _recorded_states():
    """Simulate a recorded sequence of FusedWorldStates."""
    frames = []
    for i in range(20):
        t = 0.1 * i + 1.0
        x = 50.0 - 5.0 * i * 0.1   # object approaching at ~5 m/s
        objs = [
            fused_obj("car_1", t, x, 0, vx=-5, vy=0),
            fused_obj("ped_1", t, 15, 3 - 0.3 * i * 0.1, vx=0, vy=-0.3, obj_class="pedestrian"),
        ]
        frames.append(world(objs, t=t, frame_id=i))
    return frames


def test_offline_replay_runs():
    cfg = Phase4DConfig(ego=EgoKinematics(x=0, y=0, vx=5, vy=0))
    p = Phase4DPipeline(cfg)
    frames = _recorded_states()
    results = []
    for frame in frames:
        r = p.process(frame)
        results.append(r)
    assert len(results) == 20


def test_offline_replay_produces_phase4d_world_state():
    cfg = Phase4DConfig(ego=EgoKinematics(x=0, y=0, vx=5, vy=0))
    p = Phase4DPipeline(cfg)
    for frame in _recorded_states():
        r = p.process(frame)
    assert isinstance(r, Phase4DWorldState)


def test_offline_replay_ttc_converges():
    """As car approaches, TTC should generally decrease over time."""
    cfg = Phase4DConfig(ego=EgoKinematics(x=0, y=0, vx=5, vy=0))
    p = Phase4DPipeline(cfg)
    ttcs = []
    for frame in _recorded_states():
        r = p.process(frame)
        for o in r.objects:
            if o.track_id == "car_1" and o.ttc.ttc_s is not None:
                ttcs.append(o.ttc.ttc_s)
    # Should have some finite TTC values
    assert len(ttcs) > 0


def test_offline_replay_no_cloud_no_internet():
    """Test runs without any network calls — verified by running offline."""
    # This test just verifies the pipeline can complete without any network dependency.
    cfg = Phase4DConfig(ego=EgoKinematics(x=0, y=0, vx=5, vy=0))
    p = Phase4DPipeline(cfg)
    objs = [fused_obj("A", 1.0, 30, 0, vx=-5)]
    r = p.process(world(objs, t=1.0))
    assert r is not None


def test_offline_replay_deterministic():
    """Same recorded frames replayed twice must produce identical output."""
    frames = _recorded_states()

    def _replay(frames):
        cfg = Phase4DConfig(ego=EgoKinematics(x=0, y=0, vx=5, vy=0))
        p = Phase4DPipeline(cfg)
        results = []
        for frame in frames:
            r = p.process(frame)
            results.append([o.collision_likelihood for o in r.objects])
        return results

    r1 = _replay(frames)
    r2 = _replay(frames)
    assert r1 == r2
