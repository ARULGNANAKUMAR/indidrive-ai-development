"""test_ttc.py — Core TTC engine tests."""
import math, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))

from core.prediction.ttc_engine import compute_ttc
from core.prediction.phase4d_types import TTCStatus


def test_stationary_obstacle_approaching():
    # ego at 0,0 moving +x at 5 m/s; obstacle at 20,0 stationary
    r = compute_ttc(0, 0, 5, 0, 20, 0, 0, 0, collision_radius_m=1.5)
    assert r.status == TTCStatus.FINITE
    assert r.ttc_s is not None
    assert 2.0 < r.ttc_s < 5.0


def test_same_direction_not_closing():
    # both moving +x at same speed
    r = compute_ttc(0, 0, 5, 0, 20, 0, 5, 0, collision_radius_m=1.5)
    assert r.status == TTCStatus.NO_COLLISION


def test_same_direction_ego_faster():
    # ego faster — closing
    r = compute_ttc(0, 0, 8, 0, 20, 0, 4, 0, collision_radius_m=1.5)
    assert r.status == TTCStatus.FINITE
    assert r.ttc_s > 0


def test_opposite_direction():
    # head-on: ego +x at 10, object -x at 10; distance 100 m
    r = compute_ttc(0, 0, 10, 0, 100, 0, -10, 0, collision_radius_m=1.5)
    assert r.status == TTCStatus.FINITE
    assert r.ttc_s is not None
    # approx 100/(10+10) = 5 s minus radius correction
    assert r.ttc_s < 5.0
    assert r.closing_speed_ms > 0


def test_crossing_scenario():
    # ego going +x; object going +y, paths cross near origin
    r = compute_ttc(0, -10, 0, 10, -10, 0, 10, 0, collision_radius_m=2.0)
    # May or may not collide depending on geometry — just verify no crash and no NaN
    assert r.status in {TTCStatus.FINITE, TTCStatus.NO_COLLISION, TTCStatus.UNKNOWN}
    if r.ttc_s is not None:
        assert math.isfinite(r.ttc_s)


def test_stationary_object_ego_stationary():
    # both stationary but not overlapping
    r = compute_ttc(0, 0, 0, 0, 10, 0, 0, 0, collision_radius_m=1.5)
    assert r.status == TTCStatus.NO_COLLISION


def test_zero_relative_velocity():
    r = compute_ttc(0, 0, 3, 1, 10, 5, 3, 1, collision_radius_m=1.5)
    assert r.status == TTCStatus.NO_COLLISION
    if r.ttc_s is not None:
        assert math.isfinite(r.ttc_s)


def test_negative_closing_velocity_diverging():
    # ego moving away from object
    r = compute_ttc(0, 0, -5, 0, 20, 0, 5, 0, collision_radius_m=1.5)
    assert r.status == TTCStatus.NO_COLLISION


def test_objects_already_overlapping():
    # distance < collision_radius
    r = compute_ttc(0, 0, 1, 0, 0.5, 0, 0, 0, collision_radius_m=1.5)
    assert r.status == TTCStatus.FINITE
    assert r.ttc_s == 0.0


def test_closing_speed_positive_when_approaching():
    r = compute_ttc(0, 0, 5, 0, 30, 0, 0, 0, collision_radius_m=1.5)
    assert r.status == TTCStatus.FINITE
    assert r.closing_speed_ms > 0


def test_ttc_finite_no_nan():
    r = compute_ttc(0, 0, 5, 0, 20, 0, 0, 0)
    assert r.ttc_s is not None
    assert math.isfinite(r.ttc_s)
    assert math.isfinite(r.closing_speed_ms)
