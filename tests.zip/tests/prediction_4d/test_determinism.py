"""Determinism: same input → identical TTC, closest approach, collision likelihood, risk level."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))

from tests.prediction_4d.conftest import fused_obj, world
from core.prediction.phase4d_pipeline import Phase4DPipeline, Phase4DConfig
from core.prediction.ttc_engine import EgoKinematics


def _run(objs, t=1.0):
    cfg = Phase4DConfig(ego=EgoKinematics(x=0, y=0, vx=5, vy=0))
    p = Phase4DPipeline(cfg)
    for i in range(3):
        p.process(world(objs, t=float(i) * 0.1 + 0.1))
    return p.process(world(objs, t=t))


def test_ttc_deterministic():
    objs = [fused_obj("A", 1.0, 20, 0, vx=-4)]
    r1 = _run(objs)
    r2 = _run(objs)
    assert r1.objects[0].ttc.status == r2.objects[0].ttc.status
    assert r1.objects[0].ttc.ttc_s == r2.objects[0].ttc.ttc_s


def test_closest_approach_deterministic():
    objs = [fused_obj("B", 1.0, 30, 5, vx=-3, vy=-1)]
    r1 = _run(objs)
    r2 = _run(objs)
    ca1 = r1.objects[0].closest_approach
    ca2 = r2.objects[0].closest_approach
    if ca1 and ca2:
        assert ca1.minimum_distance_m == ca2.minimum_distance_m
        assert ca1.time_of_closest_approach_s == ca2.time_of_closest_approach_s


def test_collision_likelihood_deterministic():
    objs = [fused_obj("C", 1.0, 15, 0, vx=-5)]
    r1 = _run(objs)
    r2 = _run(objs)
    assert r1.objects[0].collision_likelihood == r2.objects[0].collision_likelihood


def test_risk_level_deterministic():
    objs = [fused_obj("D", 1.0, 10, 0, vx=-8)]
    r1 = _run(objs)
    r2 = _run(objs)
    assert r1.objects[0].risk_level == r2.objects[0].risk_level


def test_multiple_objects_deterministic():
    objs = [fused_obj(str(i), 1.0, 10 + i * 5, i, vx=-2) for i in range(5)]
    r1 = _run(objs)
    r2 = _run(objs)
    for o1, o2 in zip(r1.objects, r2.objects):
        assert o1.ttc.status == o2.ttc.status
        assert o1.collision_likelihood == o2.collision_likelihood
        assert o1.risk_level == o2.risk_level
