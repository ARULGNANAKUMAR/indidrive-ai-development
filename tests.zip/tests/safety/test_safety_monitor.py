"""
Phase 11.1 — Safety Monitor Tests
===================================
Tests A–Y from the specification, plus negative scope tests and
Phase 10.5 regression protection.

Conventions
-----------
* T = 1000.0 is the reference timestamp used throughout.
* All snapshots are built from real project types — no mocking of
  existing Phase 0–10.5 modules.
* Each test function is independent and deterministic.
* No random values, no wall-clock time inside assertions.
"""
from __future__ import annotations

import math
import pytest

# Safety monitor imports
from core.safety import (
    SafetyMonitor,
    SafetyMonitorConfig,
    SafetyMonitorState,
    SafetyState,
    SafetyReasonCode,
    SafetyObservation,
    SafetyEvent,
    SubsystemHealth,
    SubsystemHealthState,
    SafetyConditionSeverity,
    SAFETY_MONITOR_SCHEMA_VERSION,
)

# Existing project types (no modification)
from core.world_model.world_model_types import (
    WorldModelSnapshot,
    WorldModelStatus,
    WorldDataQuality,
    InputModuleStatus,
)
from core.planning.planner_types import PlannerOutput, PlannerStatus
from core.tracking.tracking_snapshot import TrackingSnapshot
from core.tracking.tracking_types import TrackingQuality
from core.control.mpc_snapshot import MPCSnapshot
from core.control.mpc_types import MPCStatus, ConstraintStatus
from core.control.control_snapshot import VehicleControlCommand
from core.control.control_types import ControlCommandStatus
from core.vehicle.dynamics_snapshot import DynamicsSnapshot
from core.integration.pipeline_types import PipelineSnapshot, PipelineStatus

# ---------------------------------------------------------------------------
# Shared fixtures / helpers
# ---------------------------------------------------------------------------

T = 1000.0  # reference timestamp (seconds)


def _monitor(config: SafetyMonitorConfig | None = None) -> SafetyMonitor:
    return SafetyMonitor(config or SafetyMonitorConfig.default())


def _wm_ok(ts: float = T) -> WorldModelSnapshot:
    """Healthy world-model snapshot."""
    return WorldModelSnapshot(status=WorldModelStatus.OK, timestamp=ts)


def _planner_ok(ts: float = T) -> PlannerOutput:
    """Healthy planner output with safety gate CLEAR."""
    return PlannerOutput(
        timestamp=ts,
        planning_status=PlannerStatus.PLAN_AVAILABLE,
        planning_allowed=True,
        safety_gate_state="CLEAR",
        degraded=False,
        stale=False,
        confidence=0.9,
        uncertainty=0.1,
    )


def _tracking_ok(ts: float = T) -> TrackingSnapshot:
    """Healthy tracking snapshot with negligible CTE."""
    return TrackingSnapshot(
        snap_timestamp=ts,
        tracking_quality=TrackingQuality.ON_TRACK,
        degraded=False,
        confidence=0.95,
        cross_track_error_m=0.05,
    )


def _mpc_ok(ts: float = T) -> MPCSnapshot:
    """Healthy MPC snapshot."""
    return MPCSnapshot(
        snap_timestamp=ts,
        sim_timestamp=ts,
        status=MPCStatus.SUCCESS,
        feasible=True,
        constraint_status=ConstraintStatus.SATISFIED,
    )


def _ctrl_ok(ts: float = T) -> VehicleControlCommand:
    """Healthy control command."""
    return VehicleControlCommand(
        timestamp=ts,
        status=ControlCommandStatus.VALID,
    )


def _dyn_ok(ts: float = T) -> DynamicsSnapshot:
    """Healthy dynamics snapshot."""
    return DynamicsSnapshot(
        snapshot_timestamp=ts,
        sim_timestamp=ts,
        x=0.0, y=0.0, yaw=0.0, velocity=5.0, acceleration=0.0,
    )


def _pipe_ok(ts: float = T) -> PipelineSnapshot:
    """Healthy pipeline snapshot."""
    return PipelineSnapshot(
        timestamp=ts,
        pipeline_status=PipelineStatus.COMPLETED,
        degraded=False,
    )


def _assess_all_ok(ref_ts: float = T) -> SafetyMonitorState:
    """Full healthy assessment."""
    m = _monitor()
    return m.assess(
        world_model_snapshot=_wm_ok(ref_ts),
        planner_output=_planner_ok(ref_ts),
        tracking_snapshot=_tracking_ok(ref_ts),
        mpc_snapshot=_mpc_ok(ref_ts),
        control_command=_ctrl_ok(ref_ts),
        dynamics_snapshot=_dyn_ok(ref_ts),
        pipeline_snapshot=_pipe_ok(ref_ts),
        reference_timestamp=ref_ts,
    )


# ===========================================================================
# A — Normal safe state
# ===========================================================================

class TestNormalSafeState:
    def test_returns_safe_when_all_healthy(self):
        state = _assess_all_ok()
        assert state.overall_safety_state == SafetyState.SAFE

    def test_monitor_status_ok_when_safe(self):
        state = _assess_all_ok()
        assert state.monitor_status == "OK"

    def test_valid_flag_set(self):
        state = _assess_all_ok()
        assert state.valid is True

    def test_no_critical_events(self):
        state = _assess_all_ok()
        critical = [e for e in state.active_events
                    if e.severity == SafetyConditionSeverity.CRITICAL]
        assert critical == []

    def test_schema_version(self):
        state = _assess_all_ok()
        assert state.schema_version == SAFETY_MONITOR_SCHEMA_VERSION

    def test_timestamp_taken_from_inputs(self):
        state = _assess_all_ok(ref_ts=T)
        assert state.timestamp == T


# ===========================================================================
# B — Invalid world model
# ===========================================================================

class TestInvalidWorldModel:
    def test_raises_alert_on_invalid_world_model(self):
        m = _monitor()
        state = m.assess(
            world_model_snapshot=WorldModelSnapshot(
                status=WorldModelStatus.INVALID, timestamp=T
            ),
            reference_timestamp=T,
        )
        assert state.overall_safety_state in (
            SafetyState.HIGH_ALERT, SafetyState.CRITICAL,
        )

    def test_reason_code_present(self):
        m = _monitor()
        state = m.assess(
            world_model_snapshot=WorldModelSnapshot(
                status=WorldModelStatus.INVALID, timestamp=T
            ),
            reference_timestamp=T,
        )
        assert SafetyReasonCode.WORLD_MODEL_INVALID.value in state.reason_codes

    def test_world_model_health_invalid(self):
        m = _monitor()
        state = m.assess(
            world_model_snapshot=WorldModelSnapshot(
                status=WorldModelStatus.INVALID, timestamp=T
            ),
            reference_timestamp=T,
        )
        wm_health = next(
            h for h in state.subsystem_health if h.subsystem == "world_model"
        )
        assert wm_health.state == SubsystemHealthState.INVALID


# ===========================================================================
# C — Stale world model
# ===========================================================================

class TestStaleWorldModel:
    def test_stale_world_model_degrades_safety(self):
        cfg = SafetyMonitorConfig(world_model_max_age_s=0.1)
        m = SafetyMonitor(cfg)
        old_ts = T - 1.0  # 1 second old — well past 0.1s threshold
        state = m.assess(
            world_model_snapshot=WorldModelSnapshot(
                status=WorldModelStatus.OK, timestamp=old_ts
            ),
            planner_output=_planner_ok(T),
            tracking_snapshot=_tracking_ok(T),
            mpc_snapshot=_mpc_ok(T),
            control_command=_ctrl_ok(T),
            dynamics_snapshot=_dyn_ok(T),
            reference_timestamp=T,
        )
        assert state.overall_safety_state in (
            SafetyState.RESTRICTED, SafetyState.HIGH_ALERT, SafetyState.CRITICAL,
        )

    def test_stale_flag_set(self):
        cfg = SafetyMonitorConfig(world_model_max_age_s=0.1)
        m = SafetyMonitor(cfg)
        state = m.assess(
            world_model_snapshot=WorldModelSnapshot(
                status=WorldModelStatus.OK, timestamp=T - 1.0
            ),
            reference_timestamp=T,
        )
        assert state.stale is True

    def test_stale_reason_code(self):
        cfg = SafetyMonitorConfig(world_model_max_age_s=0.1)
        m = SafetyMonitor(cfg)
        state = m.assess(
            world_model_snapshot=WorldModelSnapshot(
                status=WorldModelStatus.OK, timestamp=T - 1.0
            ),
            reference_timestamp=T,
        )
        assert SafetyReasonCode.WORLD_MODEL_STALE.value in state.reason_codes


# ===========================================================================
# D — Degraded perception (reflected in world model data quality)
# ===========================================================================

class TestDegradedPerception:
    def test_degraded_perception_in_world_model(self):
        dq = WorldDataQuality(
            overall_confidence=0.2,
            overall_uncertainty=0.8,
            is_partial=True,
            perception_status=InputModuleStatus.DEGRADED,
        )
        wm = WorldModelSnapshot(
            status=WorldModelStatus.DEGRADED,
            timestamp=T,
            data_quality=dq,
        )
        m = _monitor()
        state = m.assess(
            world_model_snapshot=wm,
            reference_timestamp=T,
        )
        # Degraded world model → at least DEGRADED or worse
        assert state.overall_safety_state not in (SafetyState.SAFE,)
        assert state.degraded is True


# ===========================================================================
# E — Degraded fusion
# ===========================================================================

class TestDegradedFusion:
    def test_degraded_fusion_in_world_model(self):
        dq = WorldDataQuality(
            overall_confidence=0.3,
            is_partial=True,
            fusion_status=InputModuleStatus.DEGRADED,
        )
        wm = WorldModelSnapshot(
            status=WorldModelStatus.DEGRADED,
            timestamp=T,
            data_quality=dq,
        )
        m = _monitor()
        state = m.assess(
            world_model_snapshot=wm,
            reference_timestamp=T,
        )
        assert state.overall_safety_state not in (SafetyState.SAFE,)


# ===========================================================================
# F — Degraded prediction
# ===========================================================================

class TestDegradedPrediction:
    def test_degraded_prediction_in_world_model(self):
        dq = WorldDataQuality(
            overall_confidence=0.3,
            is_partial=True,
            prediction_status=InputModuleStatus.DEGRADED,
        )
        wm = WorldModelSnapshot(
            status=WorldModelStatus.DEGRADED,
            timestamp=T,
            data_quality=dq,
        )
        m = _monitor()
        state = m.assess(
            world_model_snapshot=wm,
            reference_timestamp=T,
        )
        assert state.overall_safety_state not in (SafetyState.SAFE,)


# ===========================================================================
# G — Invalid planner state
# ===========================================================================

class TestInvalidPlannerState:
    def test_invalid_input_planner_degrades_safety(self):
        m = _monitor()
        state = m.assess(
            world_model_snapshot=_wm_ok(),
            planner_output=PlannerOutput(
                timestamp=T,
                planning_status=PlannerStatus.INVALID_INPUT,
                safety_gate_state="CLEAR",
                degraded=False,
            ),
            tracking_snapshot=_tracking_ok(),
            mpc_snapshot=_mpc_ok(),
            control_command=_ctrl_ok(),
            dynamics_snapshot=_dyn_ok(),
            reference_timestamp=T,
        )
        assert state.overall_safety_state in (
            SafetyState.HIGH_ALERT, SafetyState.CRITICAL,
        )
        assert SafetyReasonCode.PLANNER_INVALID.value in state.reason_codes

    def test_no_feasible_candidate_degrades_safety(self):
        m = _monitor()
        state = m.assess(
            world_model_snapshot=_wm_ok(),
            planner_output=PlannerOutput(
                timestamp=T,
                planning_status=PlannerStatus.NO_FEASIBLE_CANDIDATE,
                safety_gate_state="CLEAR",
                degraded=True,
            ),
            tracking_snapshot=_tracking_ok(),
            mpc_snapshot=_mpc_ok(),
            control_command=_ctrl_ok(),
            dynamics_snapshot=_dyn_ok(),
            reference_timestamp=T,
        )
        assert state.overall_safety_state in (
            SafetyState.HIGH_ALERT, SafetyState.CRITICAL,
        )


# ===========================================================================
# H — Stale planner state
# ===========================================================================

class TestStalePlannerState:
    def test_stale_planner_degrades_safety(self):
        cfg = SafetyMonitorConfig(planner_max_age_s=0.1)
        m = SafetyMonitor(cfg)
        state = m.assess(
            world_model_snapshot=_wm_ok(),
            planner_output=PlannerOutput(
                timestamp=T - 1.0,  # 1 second old
                planning_status=PlannerStatus.PLAN_AVAILABLE,
                safety_gate_state="CLEAR",
                degraded=False,
            ),
            tracking_snapshot=_tracking_ok(),
            mpc_snapshot=_mpc_ok(),
            control_command=_ctrl_ok(),
            dynamics_snapshot=_dyn_ok(),
            reference_timestamp=T,
        )
        assert state.overall_safety_state in (
            SafetyState.RESTRICTED, SafetyState.HIGH_ALERT, SafetyState.CRITICAL,
        )
        assert SafetyReasonCode.PLANNER_STALE.value in state.reason_codes

    def test_stale_input_planner_status(self):
        m = _monitor()
        state = m.assess(
            world_model_snapshot=_wm_ok(),
            planner_output=PlannerOutput(
                timestamp=T,
                planning_status=PlannerStatus.STALE_INPUT,
                safety_gate_state="CLEAR",
                degraded=False,
            ),
            reference_timestamp=T,
        )
        assert SafetyReasonCode.PLANNER_STALE.value in state.reason_codes


# ===========================================================================
# I — Invalid tracking state
# ===========================================================================

class TestInvalidTrackingState:
    def test_invalid_tracking_input_degrades_safety(self):
        m = _monitor()
        state = m.assess(
            world_model_snapshot=_wm_ok(),
            planner_output=_planner_ok(),
            tracking_snapshot=TrackingSnapshot(
                snap_timestamp=T,
                tracking_quality=TrackingQuality.INVALID_INPUT,
                degraded=True,
                confidence=0.0,
            ),
            mpc_snapshot=_mpc_ok(),
            control_command=_ctrl_ok(),
            dynamics_snapshot=_dyn_ok(),
            reference_timestamp=T,
        )
        assert state.overall_safety_state in (
            SafetyState.HIGH_ALERT, SafetyState.CRITICAL,
        )
        assert SafetyReasonCode.TRACKING_INVALID.value in state.reason_codes

    def test_reference_lost_degrades_safety(self):
        m = _monitor()
        state = m.assess(
            world_model_snapshot=_wm_ok(),
            planner_output=_planner_ok(),
            tracking_snapshot=TrackingSnapshot(
                snap_timestamp=T,
                tracking_quality=TrackingQuality.REFERENCE_LOST,
                degraded=True,
                confidence=0.0,
            ),
            reference_timestamp=T,
        )
        assert state.overall_safety_state in (
            SafetyState.HIGH_ALERT, SafetyState.CRITICAL,
        )
        assert SafetyReasonCode.TRACKING_REFERENCE_LOST.value in state.reason_codes


# ===========================================================================
# J — Large tracking deviation
# ===========================================================================

class TestLargeTrackingDeviation:
    def test_large_cte_raises_high_alert(self):
        cfg = SafetyMonitorConfig(
            large_cross_track_error_m=2.0,
            critical_cross_track_error_m=5.0,
        )
        m = SafetyMonitor(cfg)
        state = m.assess(
            world_model_snapshot=_wm_ok(),
            planner_output=_planner_ok(),
            tracking_snapshot=TrackingSnapshot(
                snap_timestamp=T,
                tracking_quality=TrackingQuality.LARGE_DEVIATION,
                degraded=False,
                confidence=0.9,
                cross_track_error_m=3.0,
            ),
            mpc_snapshot=_mpc_ok(),
            control_command=_ctrl_ok(),
            dynamics_snapshot=_dyn_ok(),
            reference_timestamp=T,
        )
        assert state.overall_safety_state in (
            SafetyState.HIGH_ALERT, SafetyState.CRITICAL,
        )
        assert SafetyReasonCode.TRACKING_LARGE_DEVIATION.value in state.reason_codes

    def test_critical_cte_raises_critical(self):
        cfg = SafetyMonitorConfig(
            large_cross_track_error_m=2.0,
            critical_cross_track_error_m=5.0,
        )
        m = SafetyMonitor(cfg)
        state = m.assess(
            world_model_snapshot=_wm_ok(),
            planner_output=_planner_ok(),
            tracking_snapshot=TrackingSnapshot(
                snap_timestamp=T,
                tracking_quality=TrackingQuality.LARGE_DEVIATION,
                degraded=False,
                confidence=0.9,
                cross_track_error_m=6.0,
            ),
            reference_timestamp=T,
        )
        assert state.overall_safety_state == SafetyState.CRITICAL


# ===========================================================================
# K — Invalid MPC state
# ===========================================================================

class TestInvalidMPCState:
    def test_invalid_mpc_input_degrades_safety(self):
        m = _monitor()
        mpc_invalid = MPCSnapshot(
            snap_timestamp=T,
            sim_timestamp=T,
            status=MPCStatus.INVALID_INPUT,
            feasible=False,
            constraint_status=ConstraintStatus.UNCHECKED,
        )
        state = m.assess(
            world_model_snapshot=_wm_ok(),
            planner_output=_planner_ok(),
            tracking_snapshot=_tracking_ok(),
            mpc_snapshot=mpc_invalid,
            control_command=_ctrl_ok(),
            dynamics_snapshot=_dyn_ok(),
            reference_timestamp=T,
        )
        assert state.overall_safety_state in (
            SafetyState.HIGH_ALERT, SafetyState.CRITICAL,
        )
        assert SafetyReasonCode.MPC_INVALID.value in state.reason_codes

    def test_mpc_no_feasible_solution_degrades_safety(self):
        m = _monitor()
        # Build snapshot directly with T timestamp to avoid monotonic clock skew
        mpc_no_sol = MPCSnapshot(
            snap_timestamp=T,
            sim_timestamp=T,
            status=MPCStatus.NO_FEASIBLE_SOLUTION,
            feasible=False,
            constraint_status=ConstraintStatus.UNCHECKED,
        )
        state = m.assess(
            world_model_snapshot=_wm_ok(),
            planner_output=_planner_ok(),
            tracking_snapshot=_tracking_ok(),
            mpc_snapshot=mpc_no_sol,
            control_command=_ctrl_ok(),
            dynamics_snapshot=_dyn_ok(),
            reference_timestamp=T,
        )
        assert state.overall_safety_state in (
            SafetyState.HIGH_ALERT, SafetyState.CRITICAL,
        )
        assert SafetyReasonCode.MPC_NO_FEASIBLE_SOLUTION.value in state.reason_codes


# ===========================================================================
# L — Stale MPC result
# ===========================================================================

class TestStaleMPCResult:
    def test_stale_mpc_degrades_safety(self):
        cfg = SafetyMonitorConfig(mpc_max_age_s=0.1)
        m = SafetyMonitor(cfg)
        state = m.assess(
            world_model_snapshot=_wm_ok(),
            planner_output=_planner_ok(),
            tracking_snapshot=_tracking_ok(),
            mpc_snapshot=MPCSnapshot(
                snap_timestamp=T - 1.0,
                sim_timestamp=T - 1.0,
                status=MPCStatus.SUCCESS,
                feasible=True,
                constraint_status=ConstraintStatus.SATISFIED,
            ),
            control_command=_ctrl_ok(),
            dynamics_snapshot=_dyn_ok(),
            reference_timestamp=T,
        )
        assert state.overall_safety_state in (
            SafetyState.RESTRICTED, SafetyState.HIGH_ALERT, SafetyState.CRITICAL,
        )
        assert SafetyReasonCode.MPC_STALE.value in state.reason_codes


# ===========================================================================
# M — Invalid control command
# ===========================================================================

class TestInvalidControlCommand:
    def test_invalid_control_command_degrades_safety(self):
        m = _monitor()
        state = m.assess(
            world_model_snapshot=_wm_ok(),
            planner_output=_planner_ok(),
            tracking_snapshot=_tracking_ok(),
            mpc_snapshot=_mpc_ok(),
            control_command=VehicleControlCommand(
                timestamp=T,
                status=ControlCommandStatus.INVALID,
            ),
            dynamics_snapshot=_dyn_ok(),
            reference_timestamp=T,
        )
        assert state.overall_safety_state in (
            SafetyState.HIGH_ALERT, SafetyState.CRITICAL,
        )
        assert SafetyReasonCode.CONTROL_INVALID.value in state.reason_codes

    def test_no_solution_control_command(self):
        m = _monitor()
        state = m.assess(
            world_model_snapshot=_wm_ok(),
            planner_output=_planner_ok(),
            tracking_snapshot=_tracking_ok(),
            mpc_snapshot=_mpc_ok(),
            control_command=VehicleControlCommand(
                timestamp=T,
                status=ControlCommandStatus.NO_SOLUTION,
            ),
            dynamics_snapshot=_dyn_ok(),
            reference_timestamp=T,
        )
        assert state.overall_safety_state in (
            SafetyState.HIGH_ALERT, SafetyState.CRITICAL,
        )
        assert SafetyReasonCode.CONTROL_NO_SOLUTION.value in state.reason_codes


# ===========================================================================
# N — Stale control state
# ===========================================================================

class TestStaleControlState:
    def test_stale_control_command_degrades_safety(self):
        cfg = SafetyMonitorConfig(control_max_age_s=0.1)
        m = SafetyMonitor(cfg)
        state = m.assess(
            world_model_snapshot=_wm_ok(),
            planner_output=_planner_ok(),
            tracking_snapshot=_tracking_ok(),
            mpc_snapshot=_mpc_ok(),
            control_command=VehicleControlCommand(
                timestamp=T - 1.0,
                status=ControlCommandStatus.VALID,
            ),
            dynamics_snapshot=_dyn_ok(),
            reference_timestamp=T,
        )
        assert state.overall_safety_state in (
            SafetyState.RESTRICTED, SafetyState.HIGH_ALERT, SafetyState.CRITICAL,
        )
        assert SafetyReasonCode.CONTROL_STALE.value in state.reason_codes

    def test_stale_status_control_command(self):
        m = _monitor()
        state = m.assess(
            world_model_snapshot=_wm_ok(),
            planner_output=_planner_ok(),
            tracking_snapshot=_tracking_ok(),
            mpc_snapshot=_mpc_ok(),
            control_command=VehicleControlCommand.stale(reason="timeout"),
            dynamics_snapshot=_dyn_ok(),
            reference_timestamp=T,
        )
        assert SafetyReasonCode.CONTROL_STALE.value in state.reason_codes


# ===========================================================================
# O — Critical safety-gate state
# ===========================================================================

class TestCriticalSafetyGate:
    def test_critical_gate_raises_critical_state(self):
        m = _monitor()
        state = m.assess(
            world_model_snapshot=_wm_ok(),
            planner_output=PlannerOutput(
                timestamp=T,
                planning_status=PlannerStatus.SAFETY_RESTRICTED,
                safety_gate_state="CRITICAL",
                planning_allowed=False,
                degraded=False,
            ),
            tracking_snapshot=_tracking_ok(),
            mpc_snapshot=_mpc_ok(),
            control_command=_ctrl_ok(),
            dynamics_snapshot=_dyn_ok(),
            reference_timestamp=T,
        )
        assert state.overall_safety_state == SafetyState.CRITICAL
        assert SafetyReasonCode.SAFETY_GATE_CRITICAL.value in state.reason_codes

    def test_high_alert_gate_raises_high_alert(self):
        m = _monitor()
        state = m.assess(
            world_model_snapshot=_wm_ok(),
            planner_output=PlannerOutput(
                timestamp=T,
                planning_status=PlannerStatus.SAFETY_RESTRICTED,
                safety_gate_state="HIGH_ALERT",
                planning_allowed=False,
                degraded=False,
            ),
            tracking_snapshot=_tracking_ok(),
            mpc_snapshot=_mpc_ok(),
            control_command=_ctrl_ok(),
            dynamics_snapshot=_dyn_ok(),
            reference_timestamp=T,
        )
        assert state.overall_safety_state in (
            SafetyState.HIGH_ALERT, SafetyState.CRITICAL,
        )
        assert SafetyReasonCode.SAFETY_GATE_HIGH_ALERT.value in state.reason_codes

    def test_restricted_gate(self):
        m = _monitor()
        state = m.assess(
            world_model_snapshot=_wm_ok(),
            planner_output=PlannerOutput(
                timestamp=T,
                planning_status=PlannerStatus.SAFETY_RESTRICTED,
                safety_gate_state="RESTRICTED",
                planning_allowed=False,
                degraded=False,
            ),
            reference_timestamp=T,
        )
        assert SafetyReasonCode.SAFETY_GATE_RESTRICTED.value in state.reason_codes


# ===========================================================================
# P — Multiple simultaneous hazards
# ===========================================================================

class TestMultipleSimultaneousHazards:
    def test_multiple_hazards_preserved(self):
        m = _monitor()
        state = m.assess(
            world_model_snapshot=WorldModelSnapshot(
                status=WorldModelStatus.INVALID, timestamp=T
            ),
            planner_output=PlannerOutput(
                timestamp=T,
                planning_status=PlannerStatus.NO_FEASIBLE_CANDIDATE,
                safety_gate_state="HIGH_ALERT",
                degraded=True,
            ),
            tracking_snapshot=TrackingSnapshot(
                snap_timestamp=T,
                tracking_quality=TrackingQuality.REFERENCE_LOST,
                degraded=True,
                confidence=0.0,
            ),
            reference_timestamp=T,
        )
        # Multiple hazards should produce multiple reason codes
        assert len(state.reason_codes) > 1
        # All observations should be preserved
        assert len(state.observations) > 1

    def test_dominant_reason_is_most_severe(self):
        m = _monitor()
        state = m.assess(
            world_model_snapshot=_wm_ok(),
            planner_output=PlannerOutput(
                timestamp=T,
                planning_status=PlannerStatus.SAFETY_RESTRICTED,
                safety_gate_state="CRITICAL",  # most severe
                planning_allowed=False,
                degraded=False,
            ),
            tracking_snapshot=TrackingSnapshot(
                snap_timestamp=T,
                tracking_quality=TrackingQuality.LARGE_DEVIATION,
                degraded=False,
                confidence=0.8,
                cross_track_error_m=2.5,
            ),
            mpc_snapshot=_mpc_ok(),
            control_command=_ctrl_ok(),
            dynamics_snapshot=_dyn_ok(),
            reference_timestamp=T,
        )
        # CRITICAL gate should dominate
        assert state.overall_safety_state == SafetyState.CRITICAL
        assert state.dominant_reason == SafetyReasonCode.SAFETY_GATE_CRITICAL.value


# ===========================================================================
# Q — Severity priority ordering
# ===========================================================================

class TestSeverityPriority:
    def test_critical_beats_high_alert(self):
        """CRITICAL always wins over HIGH_ALERT."""
        m = _monitor()
        # CRITICAL gate + LARGE_DEVIATION (HIGH_ALERT) → CRITICAL overall
        state = m.assess(
            world_model_snapshot=_wm_ok(),
            planner_output=PlannerOutput(
                timestamp=T,
                planning_status=PlannerStatus.PLAN_AVAILABLE,
                safety_gate_state="CRITICAL",
                planning_allowed=False,
                degraded=False,
            ),
            tracking_snapshot=TrackingSnapshot(
                snap_timestamp=T,
                tracking_quality=TrackingQuality.LARGE_DEVIATION,
                degraded=False,
                confidence=0.8,
                cross_track_error_m=2.5,
            ),
            mpc_snapshot=_mpc_ok(),
            control_command=_ctrl_ok(),
            dynamics_snapshot=_dyn_ok(),
            reference_timestamp=T,
        )
        assert state.overall_safety_state == SafetyState.CRITICAL

    def test_high_alert_beats_restricted(self):
        """HIGH_ALERT always wins over RESTRICTED."""
        m = _monitor()
        # Large CTE (HIGH_ALERT) + stale world model (RESTRICTED)
        cfg = SafetyMonitorConfig(
            world_model_max_age_s=0.1,
            large_cross_track_error_m=2.0,
            critical_cross_track_error_m=5.0,
        )
        m2 = SafetyMonitor(cfg)
        state = m2.assess(
            world_model_snapshot=WorldModelSnapshot(
                status=WorldModelStatus.OK, timestamp=T - 0.5
            ),  # stale
            planner_output=_planner_ok(),
            tracking_snapshot=TrackingSnapshot(
                snap_timestamp=T,
                tracking_quality=TrackingQuality.LARGE_DEVIATION,
                degraded=False,
                confidence=0.8,
                cross_track_error_m=3.0,
            ),
            mpc_snapshot=_mpc_ok(),
            control_command=_ctrl_ok(),
            dynamics_snapshot=_dyn_ok(),
            reference_timestamp=T,
        )
        assert state.overall_safety_state in (
            SafetyState.HIGH_ALERT, SafetyState.CRITICAL,
        )

    def test_critical_over_degraded(self):
        """CRITICAL beats DEGRADED."""
        m = _monitor()
        state = m.assess(
            world_model_snapshot=WorldModelSnapshot(
                status=WorldModelStatus.DEGRADED, timestamp=T
            ),
            planner_output=PlannerOutput(
                timestamp=T,
                planning_status=PlannerStatus.PLAN_AVAILABLE,
                safety_gate_state="CRITICAL",
                planning_allowed=False,
                degraded=False,
            ),
            reference_timestamp=T,
        )
        assert state.overall_safety_state == SafetyState.CRITICAL


# ===========================================================================
# R — Unknown state
# ===========================================================================

class TestUnknownState:
    def test_all_none_produces_alert_or_unknown(self):
        """No inputs at all → HIGH_ALERT or worse (all subsystems unavailable)."""
        m = _monitor()
        state = m.assess(reference_timestamp=T)
        # All required subsystems unavailable → HIGH_ALERT at minimum
        assert state.overall_safety_state in (
            SafetyState.UNKNOWN, SafetyState.HIGH_ALERT, SafetyState.CRITICAL,
        )
        assert state.valid is False

    def test_all_none_never_safe(self):
        """Missing all inputs must never produce SAFE."""
        m = _monitor()
        state = m.assess(reference_timestamp=T)
        assert state.overall_safety_state != SafetyState.SAFE

    def test_all_none_confidence_low(self):
        m = _monitor()
        state = m.assess(reference_timestamp=T)
        assert state.confidence < 0.5

    def test_unknown_when_gate_state_unknown(self):
        """Safety gate UNKNOWN → should not be treated as SAFE."""
        m = _monitor()
        state = m.assess(
            world_model_snapshot=_wm_ok(),
            planner_output=PlannerOutput(
                timestamp=T,
                planning_status=PlannerStatus.UNKNOWN,
                safety_gate_state="UNKNOWN",
                degraded=True,
            ),
            reference_timestamp=T,
        )
        assert state.overall_safety_state != SafetyState.SAFE


# ===========================================================================
# S — Missing input (individual subsystem None)
# ===========================================================================

class TestMissingInput:
    def test_missing_world_model_raises_alert(self):
        m = _monitor()
        state = m.assess(
            world_model_snapshot=None,
            planner_output=_planner_ok(),
            tracking_snapshot=_tracking_ok(),
            mpc_snapshot=_mpc_ok(),
            control_command=_ctrl_ok(),
            dynamics_snapshot=_dyn_ok(),
            reference_timestamp=T,
        )
        assert state.overall_safety_state in (
            SafetyState.HIGH_ALERT, SafetyState.CRITICAL,
        )
        assert SafetyReasonCode.WORLD_MODEL_UNAVAILABLE.value in state.reason_codes

    def test_missing_planner_raises_alert(self):
        m = _monitor()
        state = m.assess(
            world_model_snapshot=_wm_ok(),
            planner_output=None,
            tracking_snapshot=_tracking_ok(),
            mpc_snapshot=_mpc_ok(),
            control_command=_ctrl_ok(),
            dynamics_snapshot=_dyn_ok(),
            reference_timestamp=T,
        )
        assert SafetyReasonCode.PLANNER_UNAVAILABLE.value in state.reason_codes

    def test_missing_tracking_raises_alert(self):
        m = _monitor()
        state = m.assess(
            world_model_snapshot=_wm_ok(),
            planner_output=_planner_ok(),
            tracking_snapshot=None,
            mpc_snapshot=_mpc_ok(),
            control_command=_ctrl_ok(),
            dynamics_snapshot=_dyn_ok(),
            reference_timestamp=T,
        )
        assert SafetyReasonCode.TRACKING_UNAVAILABLE.value in state.reason_codes

    def test_missing_mpc_raises_alert(self):
        m = _monitor()
        state = m.assess(
            world_model_snapshot=_wm_ok(),
            planner_output=_planner_ok(),
            tracking_snapshot=_tracking_ok(),
            mpc_snapshot=None,
            control_command=_ctrl_ok(),
            dynamics_snapshot=_dyn_ok(),
            reference_timestamp=T,
        )
        assert SafetyReasonCode.MPC_UNAVAILABLE.value in state.reason_codes

    def test_missing_control_raises_alert(self):
        m = _monitor()
        state = m.assess(
            world_model_snapshot=_wm_ok(),
            planner_output=_planner_ok(),
            tracking_snapshot=_tracking_ok(),
            mpc_snapshot=_mpc_ok(),
            control_command=None,
            dynamics_snapshot=_dyn_ok(),
            reference_timestamp=T,
        )
        assert SafetyReasonCode.CONTROL_UNAVAILABLE.value in state.reason_codes

    def test_missing_vehicle_raises_alert(self):
        m = _monitor()
        state = m.assess(
            world_model_snapshot=_wm_ok(),
            planner_output=_planner_ok(),
            tracking_snapshot=_tracking_ok(),
            mpc_snapshot=_mpc_ok(),
            control_command=_ctrl_ok(),
            dynamics_snapshot=None,
            reference_timestamp=T,
        )
        assert SafetyReasonCode.VEHICLE_DYNAMICS_UNAVAILABLE.value in state.reason_codes


# ===========================================================================
# T — NaN / Infinity
# ===========================================================================

class TestNaNInfinity:
    def test_nan_in_vehicle_dynamics(self):
        m = _monitor()
        state = m.assess(
            world_model_snapshot=_wm_ok(),
            planner_output=_planner_ok(),
            tracking_snapshot=_tracking_ok(),
            mpc_snapshot=_mpc_ok(),
            control_command=_ctrl_ok(),
            dynamics_snapshot=DynamicsSnapshot(
                snapshot_timestamp=T,
                sim_timestamp=T,
                x=float("nan"),
                y=0.0, yaw=0.0, velocity=5.0,
            ),
            reference_timestamp=T,
        )
        # NaN in position → CRITICAL or HIGH_ALERT
        assert state.overall_safety_state in (
            SafetyState.CRITICAL, SafetyState.HIGH_ALERT,
        )
        assert SafetyReasonCode.VEHICLE_DYNAMICS_INVALID.value in state.reason_codes

    def test_inf_in_vehicle_dynamics(self):
        m = _monitor()
        state = m.assess(
            world_model_snapshot=_wm_ok(),
            planner_output=_planner_ok(),
            tracking_snapshot=_tracking_ok(),
            mpc_snapshot=_mpc_ok(),
            control_command=_ctrl_ok(),
            dynamics_snapshot=DynamicsSnapshot(
                snapshot_timestamp=T,
                sim_timestamp=T,
                x=math.inf,
                y=0.0, yaw=0.0, velocity=5.0,
            ),
            reference_timestamp=T,
        )
        assert SafetyReasonCode.VEHICLE_DYNAMICS_INVALID.value in state.reason_codes

    def test_monitor_does_not_crash_on_nan_timestamp(self):
        """NaN reference timestamp → monitor returns UNKNOWN, does not crash."""
        m = _monitor()
        state = m.assess(
            world_model_snapshot=WorldModelSnapshot(
                status=WorldModelStatus.OK,
                timestamp=float("nan"),
            ),
            reference_timestamp=float("nan"),
        )
        # Should return a structured result, not raise
        assert isinstance(state, SafetyMonitorState)
        # With NaN timestamps nothing can be validated → some degraded state
        assert state.overall_safety_state in (
            SafetyState.UNKNOWN, SafetyState.HIGH_ALERT,
            SafetyState.CRITICAL, SafetyState.DEGRADED,
        )

    def test_monitor_does_not_crash_on_inf_timestamp(self):
        m = _monitor()
        state = m.assess(
            world_model_snapshot=WorldModelSnapshot(
                status=WorldModelStatus.OK,
                timestamp=math.inf,
            ),
            reference_timestamp=math.inf,
        )
        assert isinstance(state, SafetyMonitorState)


# ===========================================================================
# U — Timestamp inconsistency
# ===========================================================================

class TestTimestampInconsistency:
    def test_negative_timestamp_treated_as_invalid(self):
        m = _monitor()
        # Negative timestamps are not valid — _is_valid_timestamp rejects them
        state = m.assess(
            world_model_snapshot=WorldModelSnapshot(
                status=WorldModelStatus.OK,
                timestamp=-1.0,  # invalid
            ),
            reference_timestamp=T,
        )
        # With a negative timestamp the world model will appear stale
        # (invalid ts → _is_stale returns True conservatively)
        assert state.overall_safety_state not in (SafetyState.SAFE,)

    def test_reference_timestamp_derived_from_inputs(self):
        """When no explicit ref_ts is given, monitor derives from inputs."""
        m = _monitor()
        state = m.assess(
            world_model_snapshot=WorldModelSnapshot(
                status=WorldModelStatus.OK, timestamp=T
            ),
        )
        # Timestamp should be derived from world model
        assert state.timestamp == T


# ===========================================================================
# V — Deterministic output
# ===========================================================================

class TestDeterministicOutput:
    def test_same_input_same_output(self):
        """Identical inputs must produce identical SafetyMonitorState."""
        m = _monitor()
        kwargs = dict(
            world_model_snapshot=_wm_ok(),
            planner_output=_planner_ok(),
            tracking_snapshot=_tracking_ok(),
            mpc_snapshot=_mpc_ok(),
            control_command=_ctrl_ok(),
            dynamics_snapshot=_dyn_ok(),
            reference_timestamp=T,
        )
        state1 = m.assess(**kwargs)
        state2 = m.assess(**kwargs)
        assert state1.overall_safety_state == state2.overall_safety_state
        assert state1.reason_codes == state2.reason_codes
        assert state1.confidence == state2.confidence
        assert state1.timestamp == state2.timestamp

    def test_observation_count_stable(self):
        m = _monitor()
        state1 = _assess_all_ok()
        state2 = _assess_all_ok()
        assert len(state1.observations) == len(state2.observations)

    def test_same_hazard_same_reason_code(self):
        m = _monitor()
        po = PlannerOutput(
            timestamp=T,
            planning_status=PlannerStatus.SAFETY_RESTRICTED,
            safety_gate_state="CRITICAL",
            planning_allowed=False,
            degraded=False,
        )
        s1 = m.assess(world_model_snapshot=_wm_ok(), planner_output=po, reference_timestamp=T)
        s2 = m.assess(world_model_snapshot=_wm_ok(), planner_output=po, reference_timestamp=T)
        assert s1.dominant_reason == s2.dominant_reason


# ===========================================================================
# W — Snapshot immutability
# ===========================================================================

class TestSnapshotImmutability:
    def test_safety_monitor_state_is_frozen(self):
        state = _assess_all_ok()
        with pytest.raises((AttributeError, TypeError)):
            state.overall_safety_state = SafetyState.CRITICAL  # type: ignore

    def test_observations_tuple_not_list(self):
        state = _assess_all_ok()
        assert isinstance(state.observations, tuple)

    def test_reason_codes_tuple(self):
        state = _assess_all_ok()
        assert isinstance(state.reason_codes, tuple)

    def test_subsystem_health_tuple(self):
        state = _assess_all_ok()
        assert isinstance(state.subsystem_health, tuple)

    def test_events_tuple(self):
        state = _assess_all_ok()
        assert isinstance(state.active_events, tuple)

    def test_safety_observation_frozen(self):
        state = _assess_all_ok()
        # SafetyObservation from a problematic assess
        m = _monitor()
        bad = m.assess(
            world_model_snapshot=WorldModelSnapshot(
                status=WorldModelStatus.INVALID, timestamp=T
            ),
            reference_timestamp=T,
        )
        if bad.observations:
            obs = bad.observations[0]
            with pytest.raises((AttributeError, TypeError)):
                obs.severity = SafetyConditionSeverity.INFO  # type: ignore


# ===========================================================================
# X — Configuration validation
# ===========================================================================

class TestConfigurationValidation:
    def test_default_config_valid(self):
        cfg = SafetyMonitorConfig.default()
        assert cfg.world_model_max_age_s > 0
        assert cfg.planner_max_age_s > 0
        assert cfg.tracking_max_age_s > 0
        assert cfg.mpc_max_age_s > 0
        assert cfg.control_max_age_s > 0
        assert cfg.vehicle_max_age_s > 0

    def test_strict_config_valid(self):
        cfg = SafetyMonitorConfig.strict()
        assert cfg.world_model_max_age_s < SafetyMonitorConfig.default().world_model_max_age_s

    def test_zero_freshness_raises(self):
        with pytest.raises(ValueError):
            SafetyMonitorConfig(world_model_max_age_s=0.0)

    def test_negative_freshness_raises(self):
        with pytest.raises(ValueError):
            SafetyMonitorConfig(planner_max_age_s=-1.0)

    def test_invalid_confidence_threshold_raises(self):
        with pytest.raises(ValueError):
            SafetyMonitorConfig(min_confidence_for_valid=1.5)

    def test_critical_cte_must_exceed_large_cte(self):
        with pytest.raises(ValueError):
            SafetyMonitorConfig(
                large_cross_track_error_m=5.0,
                critical_cross_track_error_m=3.0,
            )

    def test_config_is_deterministic(self):
        cfg1 = SafetyMonitorConfig.default()
        cfg2 = SafetyMonitorConfig.default()
        assert cfg1.world_model_max_age_s == cfg2.world_model_max_age_s
        assert cfg1.required_subsystems == cfg2.required_subsystems

    def test_custom_config_applied(self):
        """Verify custom freshness thresholds are respected."""
        cfg = SafetyMonitorConfig(
            world_model_max_age_s=10.0,  # very lenient
            planner_max_age_s=10.0,
            tracking_max_age_s=10.0,
            mpc_max_age_s=10.0,
            control_max_age_s=10.0,
            vehicle_max_age_s=10.0,
        )
        m = SafetyMonitor(cfg)
        # Data 5 seconds old — should NOT be stale with 10s threshold
        state = m.assess(
            world_model_snapshot=WorldModelSnapshot(
                status=WorldModelStatus.OK, timestamp=T - 5.0
            ),
            planner_output=PlannerOutput(
                timestamp=T - 5.0,
                planning_status=PlannerStatus.PLAN_AVAILABLE,
                safety_gate_state="CLEAR",
                degraded=False,
            ),
            tracking_snapshot=TrackingSnapshot(
                snap_timestamp=T - 5.0,
                tracking_quality=TrackingQuality.ON_TRACK,
                degraded=False,
                confidence=0.9,
                cross_track_error_m=0.1,
            ),
            mpc_snapshot=MPCSnapshot(
                snap_timestamp=T - 5.0,
                sim_timestamp=T - 5.0,
                status=MPCStatus.SUCCESS,
                feasible=True,
                constraint_status=ConstraintStatus.SATISFIED,
            ),
            control_command=VehicleControlCommand(
                timestamp=T - 5.0,
                status=ControlCommandStatus.VALID,
            ),
            dynamics_snapshot=DynamicsSnapshot(
                snapshot_timestamp=T - 5.0,
                sim_timestamp=T - 5.0,
                x=0.0, y=0.0, yaw=0.0, velocity=5.0,
            ),
            pipeline_snapshot=_pipe_ok(T - 5.0),
            reference_timestamp=T,
        )
        # With lenient thresholds, 5-second-old data should not cause STALE
        assert SafetyReasonCode.WORLD_MODEL_STALE.value not in state.reason_codes


# ===========================================================================
# Y — Regression with Phase 10.5
# ===========================================================================

class TestPhase105Regression:
    """Verify Safety Monitor integrates without breaking Phase 10.5 behaviour."""

    def test_safety_monitor_does_not_modify_world_model_snapshot(self):
        wm = WorldModelSnapshot(status=WorldModelStatus.OK, timestamp=T)
        m = _monitor()
        m.assess(world_model_snapshot=wm, reference_timestamp=T)
        # World model snapshot unchanged
        assert wm.status == WorldModelStatus.OK
        assert wm.timestamp == T

    def test_safety_monitor_does_not_modify_planner_output(self):
        po = _planner_ok()
        original_status = po.planning_status
        m = _monitor()
        m.assess(planner_output=po, reference_timestamp=T)
        assert po.planning_status == original_status

    def test_safety_monitor_does_not_modify_tracking_snapshot(self):
        ts = _tracking_ok()
        original_quality = ts.tracking_quality
        m = _monitor()
        m.assess(tracking_snapshot=ts, reference_timestamp=T)
        assert ts.tracking_quality == original_quality

    def test_safety_monitor_does_not_modify_mpc_snapshot(self):
        mpc = _mpc_ok()
        original_status = mpc.status
        m = _monitor()
        m.assess(mpc_snapshot=mpc, reference_timestamp=T)
        assert mpc.status == original_status

    def test_safety_monitor_does_not_modify_control_command(self):
        cmd = _ctrl_ok()
        original_status = cmd.status
        m = _monitor()
        m.assess(control_command=cmd, reference_timestamp=T)
        assert cmd.status == original_status

    def test_safety_monitor_does_not_modify_pipeline_snapshot(self):
        pipe = _pipe_ok()
        original_status = pipe.pipeline_status
        m = _monitor()
        m.assess(pipeline_snapshot=pipe, reference_timestamp=T)
        assert pipe.pipeline_status == original_status

    def test_import_safety_module_does_not_break_existing_imports(self):
        """All existing pipeline imports still work after safety module added."""
        from core.integration.autonomous_pipeline import AutonomousPipeline
        from core.reasoning.safety_gate import SafetyGateEvaluator
        from core.control.mpc_controller import MPCController
        from core.planning.planner_types import PlannerOutput
        assert AutonomousPipeline is not None
        assert SafetyGateEvaluator is not None
        assert MPCController is not None
        assert PlannerOutput is not None

    def test_safety_monitor_result_is_a_snapshot(self):
        """Result is an immutable snapshot, not a live view of internal state."""
        m = _monitor()
        # First assess: all healthy
        s1 = _assess_all_ok()
        s1_state = s1.overall_safety_state
        s1_reason_codes = s1.reason_codes
        # Second assess: critical gate (very different)
        s2 = m.assess(
            world_model_snapshot=_wm_ok(),
            planner_output=PlannerOutput(
                timestamp=T,
                planning_status=PlannerStatus.SAFETY_RESTRICTED,
                safety_gate_state="CRITICAL",
                planning_allowed=False,
                degraded=False,
            ),
            reference_timestamp=T,
        )
        # s1 must not have been mutated by s2
        assert s1.overall_safety_state == s1_state
        assert s1.reason_codes == s1_reason_codes
        # The two assessments differ
        assert s2.overall_safety_state == SafetyState.CRITICAL
        assert s1.overall_safety_state == SafetyState.SAFE


# ===========================================================================
# Negative scope tests — Phase 11.1 MUST NOT do these things
# ===========================================================================

class TestNegativeScope:
    """Prove Phase 11.1 does NOT generate paths, commands, or control outputs."""

    def test_does_not_generate_trajectory(self):
        state = _assess_all_ok()
        assert not hasattr(state, "trajectory")
        assert not hasattr(state, "path")
        assert not hasattr(state, "waypoints")

    def test_does_not_generate_steering_command(self):
        state = _assess_all_ok()
        assert not hasattr(state, "steering_angle")
        assert not hasattr(state, "steering_command")

    def test_does_not_generate_throttle_command(self):
        state = _assess_all_ok()
        assert not hasattr(state, "throttle")
        assert not hasattr(state, "acceleration_command")
        assert not hasattr(state, "acceleration_mps2")

    def test_does_not_generate_brake_command(self):
        state = _assess_all_ok()
        assert not hasattr(state, "brake")
        assert not hasattr(state, "brake_command")
        assert not hasattr(state, "brake_mps2")

    def test_does_not_run_mpc(self):
        state = _assess_all_ok()
        assert not hasattr(state, "mpc_solution")
        assert not hasattr(state, "predicted_states")
        assert not hasattr(state, "control_sequence")

    def test_does_not_send_can_commands(self):
        state = _assess_all_ok()
        assert not hasattr(state, "can_frame")
        assert not hasattr(state, "can_message")
        assert not hasattr(state, "can_command")

    def test_does_not_override_controller(self):
        state = _assess_all_ok()
        assert not hasattr(state, "controller_override")
        assert not hasattr(state, "override_command")

    def test_does_not_select_planner_path(self):
        state = _assess_all_ok()
        assert not hasattr(state, "selected_path")
        assert not hasattr(state, "selected_candidate")
        assert not hasattr(state, "selected_candidate_id")

    def test_does_not_perform_emergency_braking(self):
        """Safety Monitor only reports — it does not brake."""
        state = _assess_all_ok()
        assert not hasattr(state, "emergency_brake")
        assert not hasattr(state, "emergency_brake_applied")

    def test_does_not_perform_emergency_steering(self):
        state = _assess_all_ok()
        assert not hasattr(state, "emergency_steer")
        assert not hasattr(state, "emergency_steer_applied")

    def test_critical_state_produces_no_actuation(self):
        """Even CRITICAL state only reports — no actuation output."""
        m = _monitor()
        state = m.assess(
            world_model_snapshot=WorldModelSnapshot(
                status=WorldModelStatus.INVALID, timestamp=T
            ),
            planner_output=PlannerOutput(
                timestamp=T,
                safety_gate_state="CRITICAL",
                planning_allowed=False,
                degraded=False,
            ),
            reference_timestamp=T,
        )
        assert state.overall_safety_state == SafetyState.CRITICAL
        # Still no actuation fields
        assert not hasattr(state, "steering_angle")
        assert not hasattr(state, "brake_mps2")
        assert not hasattr(state, "emergency_brake")
        assert not hasattr(state, "control_command")

    def test_safety_monitor_module_has_no_actuator_functions(self):
        """The SafetyMonitor class must not expose actuator methods."""
        m = _monitor()
        forbidden = [
            "brake", "steer", "accelerate", "emergency_stop",
            "send_can", "override_controller", "generate_path",
            "run_mpc", "compute_trajectory",
        ]
        for fn in forbidden:
            assert not hasattr(m, fn), f"SafetyMonitor should not have method: {fn}"


# ===========================================================================
# Additional edge-case tests
# ===========================================================================

class TestEdgeCases:
    def test_pipeline_none_does_not_crash(self):
        state = _assess_all_ok()
        m = _monitor()
        state2 = m.assess(
            world_model_snapshot=_wm_ok(),
            planner_output=_planner_ok(),
            tracking_snapshot=_tracking_ok(),
            mpc_snapshot=_mpc_ok(),
            control_command=_ctrl_ok(),
            dynamics_snapshot=_dyn_ok(),
            pipeline_snapshot=None,
            reference_timestamp=T,
        )
        assert isinstance(state2, SafetyMonitorState)

    def test_mpc_constraint_violation_raises_critical(self):
        m = _monitor()
        state = m.assess(
            world_model_snapshot=_wm_ok(),
            planner_output=_planner_ok(),
            tracking_snapshot=_tracking_ok(),
            mpc_snapshot=MPCSnapshot(
                snap_timestamp=T,
                sim_timestamp=T,
                status=MPCStatus.SUCCESS,
                feasible=True,
                constraint_status=ConstraintStatus.VIOLATED,
            ),
            control_command=_ctrl_ok(),
            dynamics_snapshot=_dyn_ok(),
            reference_timestamp=T,
        )
        assert SafetyReasonCode.MPC_CONSTRAINT_VIOLATION.value in state.reason_codes
        assert state.overall_safety_state == SafetyState.CRITICAL

    def test_pipeline_failed_raises_alert(self):
        m = _monitor()
        state = m.assess(
            world_model_snapshot=_wm_ok(),
            planner_output=_planner_ok(),
            tracking_snapshot=_tracking_ok(),
            mpc_snapshot=_mpc_ok(),
            control_command=_ctrl_ok(),
            dynamics_snapshot=_dyn_ok(),
            pipeline_snapshot=PipelineSnapshot(
                timestamp=T,
                pipeline_status=PipelineStatus.PLANNING_FAILED,
                degraded=True,
            ),
            reference_timestamp=T,
        )
        assert SafetyReasonCode.PIPELINE_FAILED.value in state.reason_codes

    def test_subsystem_health_contains_all_checked_subsystems(self):
        state = _assess_all_ok()
        names = {h.subsystem for h in state.subsystem_health}
        assert "world_model" in names
        assert "planner" in names
        assert "tracking" in names
        assert "mpc" in names
        assert "control" in names
        assert "vehicle" in names

    def test_schema_version_in_observations(self):
        m = _monitor()
        state = m.assess(
            world_model_snapshot=WorldModelSnapshot(
                status=WorldModelStatus.INVALID, timestamp=T
            ),
            reference_timestamp=T,
        )
        for obs in state.observations:
            assert obs.schema_version == SAFETY_MONITOR_SCHEMA_VERSION

    def test_safety_is_a_property_not_field(self):
        state = _assess_all_ok()
        assert state.is_safe is True
        assert state.is_critical is False
        assert state.is_unknown is False

    def test_repr_is_informative(self):
        state = _assess_all_ok()
        r = repr(state)
        assert "SafetyMonitorState" in r
        assert "SAFE" in r
