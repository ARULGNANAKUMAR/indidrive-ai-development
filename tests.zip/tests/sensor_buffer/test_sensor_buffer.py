"""UNIT TEST — SensorBuffer bounded capacity, overflow policy, thread-safety."""
import sys
import threading
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))

from core.carla_integration.sensor_buffer import SensorBuffer, DROP_OLDEST, KEEP_LATEST
from core.carla_integration.sensor_types import CameraFrame, Timestamp


def _frame(fid, sensor_time=None):
    return CameraFrame(sensor_id="cam", frame_id=fid,
                        timestamp=Timestamp(sensor_time=sensor_time if sensor_time is not None else float(fid)),
                        sequence_number=fid, payload=None, width=1, height=1, channels=1, image=None)


def test_bounded_capacity_drop_oldest():
    buf = SensorBuffer("cam", capacity=3, overflow_policy=DROP_OLDEST)
    for i in range(5):
        buf.push(_frame(i))
    assert len(buf) == 3
    snap = buf.snapshot()
    assert [f.frame_id for f in snap] == [2, 3, 4]
    assert buf.dropped_count == 2


def test_bounded_capacity_keep_latest_rejects_new():
    buf = SensorBuffer("cam", capacity=3, overflow_policy=KEEP_LATEST)
    for i in range(5):
        buf.push(_frame(i))
    assert len(buf) == 3
    snap = buf.snapshot()
    assert [f.frame_id for f in snap] == [0, 1, 2]
    assert buf.dropped_count == 2


def test_latest_returns_newest():
    buf = SensorBuffer("cam", capacity=5)
    for i in range(3):
        buf.push(_frame(i))
    assert buf.latest().frame_id == 2


def test_get_by_frame_id():
    buf = SensorBuffer("cam", capacity=5)
    for i in range(5):
        buf.push(_frame(i))
    found = buf.get_by_frame_id(3)
    assert found is not None and found.frame_id == 3
    assert buf.get_by_frame_id(999) is None


def test_get_closest_by_timestamp():
    buf = SensorBuffer("cam", capacity=10)
    for i in range(10):
        buf.push(_frame(i, sensor_time=i * 0.1))
    closest = buf.get_closest_by_timestamp(0.52)
    assert closest.frame_id == 5


def test_never_grows_unbounded():
    buf = SensorBuffer("cam", capacity=10, overflow_policy=DROP_OLDEST)
    for i in range(10_000):
        buf.push(_frame(i))
    assert len(buf) == 10


def test_thread_safety_concurrent_pushes():
    buf = SensorBuffer("cam", capacity=50, overflow_policy=DROP_OLDEST)
    errors = []

    def worker(start):
        try:
            for i in range(start, start + 200):
                buf.push(_frame(i))
        except Exception as e:  # pragma: no cover
            errors.append(e)

    threads = [threading.Thread(target=worker, args=(t * 200,)) for t in range(8)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()

    assert not errors
    assert len(buf) == 50  # capacity respected even under concurrent writers
    assert buf.total_pushed == 1600


def test_close_stops_accepting_frames():
    buf = SensorBuffer("cam", capacity=5)
    buf.push(_frame(0))
    buf.close()
    accepted = buf.push(_frame(1))
    assert accepted is False
    assert len(buf) == 0
