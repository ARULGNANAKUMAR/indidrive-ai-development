"""
IndiDrive AI — Phase 0 | Configuration tests
Run with: PYTHONPATH=. pytest tests/configuration/ -v
Covers spec Test 1 (config loads) and Test 2 (invalid config detected).
"""
import sys
import tempfile
from pathlib import Path

try:
    import pytest
    _HAS_PYTEST = True
except ImportError:
    _HAS_PYTEST = False

    class _FallbackRaises:
        """Minimal stand-in for pytest.raises() when pytest isn't installed
        (this project's own offline dev sandbox has no network access to
        install it — see docs/BASELINE.md). Only supports the plain
        `with raises(SomeError):` form used in this file."""
        def __init__(self, exc_type):
            self.exc_type = exc_type

        def __enter__(self):
            return self

        def __exit__(self, exc_type, exc_val, exc_tb):
            if exc_type is None:
                raise AssertionError(f"Expected {self.exc_type.__name__} to be raised")
            return issubclass(exc_type, self.exc_type)

    class _FallbackPytest:
        raises = staticmethod(_FallbackRaises)

    pytest = _FallbackPytest()  # type: ignore

ROOT = Path(__file__).resolve().parent.parent.parent
sys.path.insert(0, str(ROOT))

from core.config_loader import load_config, load_all_configs, ConfigError, CONFIG_FILES


# --- Test 1: Configuration loads successfully ---

def test_all_config_files_load():
    cfgs = load_all_configs()
    assert set(cfgs.keys()) == set(CONFIG_FILES.keys())
    for name, data in cfgs.items():
        assert isinstance(data, dict)
        assert len(data) > 0


def test_system_config_has_expected_keys():
    cfg = load_config("system")
    assert cfg["project_name"]
    assert cfg["server"]["port"] == 8004


def test_planner_config_matches_legacy_simai_defaults():
    cfg = load_config("planner")
    assert cfg["planner"]["lateral_offsets_m"] == [0, -2.5, 2.5, -5, 5]
    assert cfg["planner"]["waypoints_per_path"] == 11


# --- Test 2: Invalid configuration is detected ---

def test_unknown_config_name_raises():
    with pytest.raises(ConfigError):
        load_config("does_not_exist")


def test_missing_config_file_raises():
    import core.config_loader as cl
    original = cl.CONFIG_DIR
    with tempfile.TemporaryDirectory() as td:
        cl.CONFIG_DIR = Path(td)  # empty dir, no yaml files
        try:
            with pytest.raises(ConfigError):
                cl.load_config("system")
        finally:
            cl.CONFIG_DIR = original


def test_malformed_yaml_raises():
    import core.config_loader as cl
    original = cl.CONFIG_DIR
    with tempfile.TemporaryDirectory() as td:
        cl.CONFIG_DIR = Path(td)
        (Path(td) / "system_config.yaml").write_text("not: valid: yaml: [unclosed")
        try:
            with pytest.raises(ConfigError):
                cl.load_config("system")
        finally:
            cl.CONFIG_DIR = original


def test_yaml_that_is_not_a_mapping_raises():
    import core.config_loader as cl
    original = cl.CONFIG_DIR
    with tempfile.TemporaryDirectory() as td:
        cl.CONFIG_DIR = Path(td)
        (Path(td) / "system_config.yaml").write_text("- just\n- a\n- list\n")
        try:
            with pytest.raises(ConfigError):
                cl.load_config("system")
        finally:
            cl.CONFIG_DIR = original


if __name__ == "__main__":
    # Minimal manual runner for environments without pytest installed
    # (e.g. this project's own offline dev sandbox — see docs/BASELINE.md).
    import traceback
    tests = [v for k, v in list(globals().items()) if k.startswith("test_") and callable(v)]
    passed = failed = 0
    for t in tests:
        try:
            t()
            print(f"PASS {t.__name__}")
            passed += 1
        except Exception:
            print(f"FAIL {t.__name__}")
            traceback.print_exc()
            failed += 1
    print(f"\n{passed} passed, {failed} failed")
