"""UNIT TEST — SensorRecorder manifest generation and safety limits."""
import json
import sys
import tempfile
from pathlib import Path

import numpy as np
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))

from core.carla_integration.sensor_recorder import SensorRecorder, RecordingLimits
from core.carla_integration.sensor_types import CameraFrame, LiDARFrame, Timestamp


def _cam_frame(fid):
    img = np.zeros((4, 4, 3), dtype=np.uint8)
    return CameraFrame(sensor_id="cam", frame_id=fid, timestamp=Timestamp(sensor_time=float(fid)),
                        sequence_number=fid, payload=None, width=4, height=4, channels=3, image=img)


def _lidar_frame(fid):
    pts = np.random.rand(10, 4).astype(np.float32)
    return LiDARFrame(sensor_id="lidar", frame_id=fid, timestamp=Timestamp(sensor_time=float(fid)),
                       sequence_number=fid, payload=None, point_count=10, points=pts)


def test_manifest_generation():
    with tempfile.TemporaryDirectory() as tmp:
        rec = SensorRecorder(map_name="Town01", vehicle_desc="test_vehicle", base_dir=Path(tmp))
        rec.start()
        for i in range(3):
            assert rec.write_frame(_cam_frame(i))
        for i in range(2):
            assert rec.write_frame(_lidar_frame(i))
        rec.stop(reason="test_complete")

        manifest_path = rec.session_dir / "sensor_manifest.json"
        assert manifest_path.exists()
        manifest = json.loads(manifest_path.read_text())
        assert manifest["map"] == "Town01"
        assert manifest["statistics"]["total_frames"] == 5
        assert manifest["sensors"]["cam"]["frames_written"] == 3
        assert manifest["sensors"]["lidar"]["frames_written"] == 2
        # only folders for sensors actually used
        assert (rec.session_dir / "camera" / "cam").exists()
        assert (rec.session_dir / "lidar" / "lidar").exists()
        assert not (rec.session_dir / "radar").exists()


def test_max_frame_count_stops_recording_safely():
    with tempfile.TemporaryDirectory() as tmp:
        limits = RecordingLimits(max_frame_count=3)
        rec = SensorRecorder(base_dir=Path(tmp), limits=limits)
        rec.start()
        results = [rec.write_frame(_cam_frame(i)) for i in range(10)]
        assert rec.total_frames == 3
        assert not rec.is_active
        manifest = json.loads((rec.session_dir / "sensor_manifest.json").read_text())
        assert "max_frame_count" in manifest["stop_reason"]


def test_max_duration_stops_recording():
    with tempfile.TemporaryDirectory() as tmp:
        limits = RecordingLimits(max_duration_s=0.0)
        rec = SensorRecorder(base_dir=Path(tmp), limits=limits)
        rec.start()
        rec.write_frame(_cam_frame(0))
        assert not rec.is_active


def test_does_not_write_after_stop():
    with tempfile.TemporaryDirectory() as tmp:
        rec = SensorRecorder(base_dir=Path(tmp))
        rec.start()
        rec.stop()
        assert rec.write_frame(_cam_frame(0)) is False
