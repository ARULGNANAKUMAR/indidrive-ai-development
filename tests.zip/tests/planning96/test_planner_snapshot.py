"""
Phase 9.6 — test_planner_snapshot.py

Tests: snapshot immutability, field completeness, to_dict round-trip.
"""
import pytest
from core.planning.planner_engine import PlannerEngine
from core.planning.planner_types import PlannerSnapshot, PLANNER_SCHEMA_VERSION
from tests.planning96.helpers_96 import make_minimal_input, default_config


class TestPlannerSnapshot:

    def _snap(self):
        eng = PlannerEngine(default_config())
        inp = make_minimal_input()
        _, snap, _ = eng.run(inp)
        return snap

    def test_snapshot_is_created(self):
        snap = self._snap()
        assert isinstance(snap, PlannerSnapshot)

    def test_snapshot_schema_version(self):
        snap = self._snap()
        assert snap.schema_version == PLANNER_SCHEMA_VERSION

    def test_snapshot_to_dict_keys(self):
        snap = self._snap()
        d = snap.to_dict()
        required = {
            "frame_id", "timestamp", "planner_status", "planning_mode",
            "safety_gate_state", "planning_allowed", "candidate_count",
            "valid_candidate_count", "risk_evaluated_count", "high_risk_count",
            "replanning_required", "selected_candidate_id",
            "confidence", "uncertainty", "degraded", "stale",
        }
        for key in required:
            assert key in d, f"Missing key {key!r} in snapshot.to_dict()"

    def test_last_snapshot_persists(self):
        eng = PlannerEngine(default_config())
        inp = make_minimal_input()
        _, snap, _ = eng.run(inp)
        assert eng.last_snapshot is snap

    def test_reset_clears_last_snapshot(self):
        eng = PlannerEngine(default_config())
        inp = make_minimal_input()
        eng.run(inp)
        eng.reset()
        assert eng.last_snapshot is None

    def test_snapshot_frame_id_matches_input(self):
        eng = PlannerEngine(default_config())
        inp = make_minimal_input()
        _, snap, _ = eng.run(inp)
        assert snap.frame_id == inp.frame_id

    def test_snapshot_immutable_after_second_run(self):
        """Second run produces a NEW snapshot, first snap unchanged."""
        eng = PlannerEngine(default_config())
        inp1 = make_minimal_input()
        _, snap1, _ = eng.run(inp1)
        fid1 = snap1.frame_id

        inp2 = make_minimal_input()
        _, snap2, _ = eng.run(inp2)

        assert snap1.frame_id == fid1  # snap1 unchanged
        assert snap2.frame_id == inp2.frame_id
