"""
Phase 9.6 — test_indian_road_benchmarks.py

Tests all 11 mandatory Indian-road benchmark scenarios in detail.
Results are derived from actual structured inputs, not scenario-name shortcuts.
"""
import pytest
from core.planning.planner_benchmark import PlannerBenchmark, BenchmarkResult
from core.planning.planner_types import PlannerStatus, NOT_AVAILABLE


@pytest.fixture(scope="module")
def bench():
    return PlannerBenchmark()


@pytest.fixture(scope="module")
def all_results(bench):
    return {r.scenario_id: r for r in bench.run_all()}


class TestVillageUnmarked:
    def test_status(self, all_results):
        r = all_results["village_unmarked"]
        assert r.planning_status == PlannerStatus.PLAN_AVAILABLE.value

    def test_mode_is_drivable_space(self, all_results):
        assert all_results["village_unmarked"].planning_mode == "DRIVABLE_SPACE"

    def test_has_selection(self, all_results):
        assert all_results["village_unmarked"].selected_candidate_id != NOT_AVAILABLE

    def test_has_candidates(self, all_results):
        assert all_results["village_unmarked"].candidate_count >= 1


class TestNarrowVillage:
    def test_status(self, all_results):
        r = all_results["narrow_village"]
        assert r.planning_status == PlannerStatus.PLAN_AVAILABLE.value

    def test_mode_is_narrow_road(self, all_results):
        assert all_results["narrow_village"].planning_mode == "NARROW_ROAD"

    def test_has_selection(self, all_results):
        assert all_results["narrow_village"].selected_candidate_id != NOT_AVAILABLE


class TestDenseMarket:
    def test_status_plan_available(self, all_results):
        r = all_results["dense_market"]
        assert r.planning_status == PlannerStatus.PLAN_AVAILABLE.value

    def test_mode_is_mixed_traffic(self, all_results):
        assert all_results["dense_market"].planning_mode == "MIXED_TRAFFIC"

    def test_risk_evaluated(self, all_results):
        assert all_results["dense_market"].risk_evaluated_count >= 1


class TestHighwayMerge:
    def test_status(self, all_results):
        r = all_results["highway_merge"]
        assert r.planning_status == PlannerStatus.PLAN_AVAILABLE.value

    def test_mode_is_highway(self, all_results):
        assert all_results["highway_merge"].planning_mode == "HIGHWAY"

    def test_has_selection(self, all_results):
        assert all_results["highway_merge"].selected_candidate_id != NOT_AVAILABLE


class TestUnsignalizedIntersection:
    def test_status(self, all_results):
        r = all_results["unsignalized_intersection"]
        assert r.planning_status == PlannerStatus.PLAN_AVAILABLE.value

    def test_mode_is_intersection(self, all_results):
        assert all_results["unsignalized_intersection"].planning_mode == "INTERSECTION"

    def test_risk_evaluated(self, all_results):
        assert all_results["unsignalized_intersection"].risk_evaluated_count >= 1


class TestCattleCrossing:
    def test_elevated_risk_status(self, all_results):
        r = all_results["cattle_crossing"]
        assert r.planning_status in (
            PlannerStatus.REPLAN_REQUIRED.value,
            PlannerStatus.BLOCKED.value,
        ), f"Expected elevated risk response, got {r.planning_status}"

    def test_no_selection_on_high_risk(self, all_results):
        assert all_results["cattle_crossing"].selected_candidate_id == NOT_AVAILABLE

    def test_all_candidates_evaluated(self, all_results):
        assert all_results["cattle_crossing"].risk_evaluated_count >= 1

    def test_not_plan_available(self, all_results):
        r = all_results["cattle_crossing"]
        assert r.planning_status != PlannerStatus.PLAN_AVAILABLE.value


class TestWrongSideTraffic:
    def test_status_elevated(self, all_results):
        r = all_results["wrong_side_traffic"]
        assert r.planning_status in (
            PlannerStatus.PLAN_AVAILABLE.value,
            PlannerStatus.REPLAN_REQUIRED.value,
        )

    def test_has_risk_evaluations(self, all_results):
        assert all_results["wrong_side_traffic"].risk_evaluated_count >= 1

    def test_mode_is_drivable_space(self, all_results):
        assert all_results["wrong_side_traffic"].planning_mode == "DRIVABLE_SPACE"


class TestDamagedNarrowRoad:
    def test_mode_is_narrow_road(self, all_results):
        assert all_results["damaged_narrow_road"].planning_mode == "NARROW_ROAD"

    def test_plan_available_with_lower_risk_candidate(self, all_results):
        r = all_results["damaged_narrow_road"]
        assert r.planning_status == PlannerStatus.PLAN_AVAILABLE.value

    def test_has_selection(self, all_results):
        assert all_results["damaged_narrow_road"].selected_candidate_id != NOT_AVAILABLE

    def test_avoids_hazard_candidate(self, all_results):
        # c8_left has lower risk than c8_center (hazard on center path)
        sel = all_results["damaged_narrow_road"].selected_candidate_id
        assert sel == "c8_left", f"Expected c8_left (lower risk), got {sel}"


class TestPedestrianHeavyMarket:
    def test_mode_is_mixed_traffic(self, all_results):
        assert all_results["pedestrian_heavy_market"].planning_mode == "MIXED_TRAFFIC"

    def test_status(self, all_results):
        r = all_results["pedestrian_heavy_market"]
        assert r.planning_status == PlannerStatus.PLAN_AVAILABLE.value

    def test_selects_safest_candidate(self, all_results):
        r = all_results["pedestrian_heavy_market"]
        # c9_right has score=0.38, c9_center=0.55, c9_left=0.70 (HIGH_RISK)
        assert r.selected_candidate_id == "c9_right"


class TestMixedMotorcycleTraffic:
    def test_mode_is_mixed_traffic(self, all_results):
        assert all_results["mixed_motorcycle_traffic"].planning_mode == "MIXED_TRAFFIC"

    def test_status(self, all_results):
        r = all_results["mixed_motorcycle_traffic"]
        assert r.planning_status == PlannerStatus.PLAN_AVAILABLE.value

    def test_selects_lowest_risk(self, all_results):
        r = all_results["mixed_motorcycle_traffic"]
        # c10_right (0.35) < c10_center (0.42) < c10_left (0.60)
        assert r.selected_candidate_id == "c10_right"

    def test_risk_differentiation(self, all_results):
        assert all_results["mixed_motorcycle_traffic"].risk_evaluated_count >= 2


class TestConstructionZone:
    def test_mode_is_drivable_space(self, all_results):
        assert all_results["construction_zone"].planning_mode == "DRIVABLE_SPACE"

    def test_replanning_triggered(self, all_results):
        r = all_results["construction_zone"]
        assert r.planning_status == PlannerStatus.REPLAN_REQUIRED.value

    def test_selects_safe_candidate_not_available_on_replan(self, all_results):
        # REPLAN_REQUIRED → selected_candidate_id == NOT_AVAILABLE
        r = all_results["construction_zone"]
        assert r.selected_candidate_id == NOT_AVAILABLE
