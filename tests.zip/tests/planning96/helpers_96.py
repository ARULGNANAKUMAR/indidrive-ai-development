"""
Tests/planning96 — shared helpers for Phase 9.6 tests.

Builds minimal but well-formed PlannerInput objects without constructing
every upstream dataclass from scratch in every test.
"""
from __future__ import annotations

import time
from typing import Optional, List
from core.planning.planner_types import (
    NOT_AVAILABLE,
    PlannerInput,
    PlannerStatus,
)
from core.planning.planner_config import PlannerConfig
from core.planning.planner_benchmark import (
    _T0,
    _make_planning_space,
    _make_candidate,
    _make_candidate_set,
    _make_risk,
    _make_risk_set,
    _make_replan_result,
    _make_indian_result,
    _make_quality,
    _make_extent,
    _make_road_structure,
    _make_indian_context,
    _make_dynamic_obj,
    _make_static_hazard,
)
from core.planning.replanning_types import (
    ReplanningDecision,
    ReplanningUrgency,
)
from core.planning.path_risk_types import RiskLevel, RiskReasonCode
from core.planning.indian_road_planning_types import PlanningMode, NarrowRoadState
from core.planning.candidate_path_types import (
    CandidateGenerationStatus,
    GeometricValidity,
    BoundaryValidity,
    DrivableSpaceValidity,
)


_FID = 9900


def _next_fid() -> int:
    global _FID
    _FID += 1
    return _FID


def make_minimal_input(
    planning_allowed: bool = True,
    sg_state: str = "CLEAR",
    n_candidates: int = 2,
    risk_score: float = 0.3,
    replan: bool = False,
    ts_offset: float = 0.0,
) -> PlannerInput:
    """Build a minimal valid PlannerInput with n_candidates low-risk paths."""
    fid = _next_fid()
    ts = _T0 + float(fid) + ts_offset
    ps = _make_planning_space(fid, ts, planning_allowed=planning_allowed,
                              sg_state=sg_state)
    cands = [_make_candidate(f"c{i}", float(i) * 0.5 - 0.5)
             for i in range(n_candidates)]
    cs = _make_candidate_set(fid, ts, cands,
                             planning_allowed=planning_allowed, sg_state=sg_state)
    risks = [_make_risk(c.candidate_id, risk_score, RiskLevel.LOW_RISK)
             for c in cands]
    rs = _make_risk_set(fid, ts, risks)
    dec = ReplanningDecision.REPLAN_REQUIRED if replan else ReplanningDecision.NO_REPLAN
    rr = _make_replan_result(dec)
    ir = _make_indian_result(PlanningMode.DRIVABLE_SPACE)
    return PlannerInput(
        frame_id=fid,
        timestamp=ts,
        planning_space=ps,
        candidate_set=cs,
        risk_set=rs,
        replanning_result=rr,
        indian_road_result=ir,
    )


def make_high_risk_input(n: int = 2, score: float = 0.9) -> PlannerInput:
    """All candidates have unacceptable risk."""
    fid = _next_fid()
    ts = _T0 + float(fid)
    ps = _make_planning_space(fid, ts)
    cands = [_make_candidate(f"hr{i}", float(i) * 0.5) for i in range(n)]
    cs = _make_candidate_set(fid, ts, cands, planning_allowed=True)
    risks = [_make_risk(c.candidate_id, score, RiskLevel.HIGH_RISK,
                        RiskReasonCode.LOW_CLEARANCE)
             for c in cands]
    rs = _make_risk_set(fid, ts, risks)
    rr = _make_replan_result(ReplanningDecision.REPLAN_REQUIRED, ReplanningUrgency.URGENT)
    ir = _make_indian_result(PlanningMode.DRIVABLE_SPACE)
    return PlannerInput(
        frame_id=fid, timestamp=ts,
        planning_space=ps, candidate_set=cs, risk_set=rs,
        replanning_result=rr, indian_road_result=ir,
    )


def make_no_candidate_input() -> PlannerInput:
    """candidate_set is empty."""
    fid = _next_fid()
    ts = _T0 + float(fid)
    ps = _make_planning_space(fid, ts)
    cs = _make_candidate_set(fid, ts, [])
    rs = _make_risk_set(fid, ts, [])
    rr = _make_replan_result(ReplanningDecision.NO_REPLAN)
    ir = _make_indian_result(PlanningMode.DRIVABLE_SPACE)
    return PlannerInput(
        frame_id=fid, timestamp=ts,
        planning_space=ps, candidate_set=cs, risk_set=rs,
        replanning_result=rr, indian_road_result=ir,
    )


def make_safety_blocked_input(sg_state: str = "CRITICAL") -> PlannerInput:
    """planning_allowed=False due to safety gate."""
    fid = _next_fid()
    ts = _T0 + float(fid)
    ps = _make_planning_space(fid, ts, planning_allowed=False, sg_state=sg_state)
    cands = [_make_candidate(f"safe{i}", 0.0) for i in range(2)]
    cs = _make_candidate_set(fid, ts, cands, planning_allowed=False, sg_state=sg_state)
    rs = _make_risk_set(fid, ts,
                        [_make_risk(c.candidate_id, 0.2, RiskLevel.LOW_RISK) for c in cands])
    rr = _make_replan_result(ReplanningDecision.NO_REPLAN)
    ir = _make_indian_result(PlanningMode.DRIVABLE_SPACE)
    return PlannerInput(
        frame_id=fid, timestamp=ts,
        planning_space=ps, candidate_set=cs, risk_set=rs,
        replanning_result=rr, indian_road_result=ir,
    )


def default_config() -> PlannerConfig:
    cfg = PlannerConfig()
    cfg.max_acceptable_risk_score = 0.80
    cfg.allow_selection = True
    cfg.allow_degraded_planning = True
    return cfg
