"""
Phase 9.6 — test_planner_determinism.py

Same input must always produce identical output.
"""
import pytest
from core.planning.planner_engine import PlannerEngine
from core.planning.planner_types import PlannerStatus
from tests.planning96.helpers_96 import make_minimal_input, default_config


def _run_n(inp, n=5):
    results = []
    for _ in range(n):
        eng = PlannerEngine(default_config())
        output, snap, _ = eng.run(inp)
        results.append(output)
    return results


class TestDeterminism:

    def test_same_input_same_status(self):
        inp = make_minimal_input()
        results = _run_n(inp)
        statuses = {r.planning_status for r in results}
        assert len(statuses) == 1, f"Non-deterministic status: {statuses}"

    def test_same_input_same_selected_candidate(self):
        inp = make_minimal_input()
        results = _run_n(inp)
        ids = {r.selected_candidate_id for r in results}
        assert len(ids) == 1, f"Non-deterministic selection: {ids}"

    def test_same_input_same_planning_mode(self):
        inp = make_minimal_input()
        results = _run_n(inp)
        modes = {r.planning_mode for r in results}
        assert len(modes) == 1, f"Non-deterministic mode: {modes}"

    def test_same_input_same_reason_codes(self):
        inp = make_minimal_input()
        results = _run_n(inp)
        codes = {r.reason_codes for r in results}
        assert len(codes) == 1, f"Non-deterministic reason_codes: {codes}"

    def test_same_input_same_confidence(self):
        inp = make_minimal_input()
        results = _run_n(inp)
        confs = {round(r.confidence, 6) for r in results}
        assert len(confs) == 1, f"Non-deterministic confidence: {confs}"

    def test_candidate_selection_stable_across_runs(self):
        """Tie-breaking must be stable across multiple engines."""
        from tests.planning96.helpers_96 import make_minimal_input
        inp = make_minimal_input(n_candidates=3, risk_score=0.3)
        results = _run_n(inp, n=10)
        selected = {r.selected_candidate_id for r in results}
        assert len(selected) == 1
