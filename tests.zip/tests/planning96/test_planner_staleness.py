"""
Phase 9.6 — test_planner_staleness.py

Tests: stale World Model, stale PlanningContext, stale PlanningSpace,
       stale candidates, missing road understanding.
"""
import pytest, time
from core.planning.planner_engine import PlannerEngine
from core.planning.planner_validator import PlannerValidator, InputValidationStatus
from core.planning.planner_types import PlannerInput, PlannerStatus
from tests.planning96.helpers_96 import make_minimal_input, default_config


def _eng():
    return PlannerEngine(default_config())


class TestStaleness:

    def test_stale_planning_space_detected_by_validator(self):
        v = PlannerValidator(default_config())
        inp = make_minimal_input()
        # now is 100 s after input timestamp → all objects are stale
        result = v.validate_input(inp, now=inp.timestamp + 100.0)
        assert InputValidationStatus.STALE in (result.status,) or \
               any("stale" in w.lower() for w in result.warnings)

    def test_stale_input_produces_non_plan_available(self):
        """Pipeline must not silently produce PLAN_AVAILABLE on stale inputs."""
        v = PlannerValidator(default_config())
        inp = make_minimal_input()
        result = v.validate_input(inp, now=inp.timestamp + 100.0)
        # Either stale or valid_degraded — either way, staleness must be flagged
        assert result.stale_fields or result.status == InputValidationStatus.STALE or \
               any("stale" in w.lower() for w in result.warnings)

    def test_fresh_input_not_stale(self):
        v = PlannerValidator(default_config())
        inp = make_minimal_input()
        result = v.validate_input(inp, now=inp.timestamp)
        assert "planning_space" not in result.stale_fields

    def test_no_world_model_degrades_gracefully(self):
        """Missing world_model_snapshot must not crash — plan degrades."""
        inp = make_minimal_input()
        inp.world_model_snapshot = None
        output, _, _ = _eng().run(inp)
        assert output.planning_status != PlannerStatus.UNKNOWN

    def test_no_planning_context_degrades_gracefully(self):
        inp = make_minimal_input()
        inp.planning_context = None
        output, _, _ = _eng().run(inp)
        assert output.planning_status != PlannerStatus.UNKNOWN

    def test_no_indian_road_result_degrades_gracefully(self):
        inp = make_minimal_input()
        inp.indian_road_result = None
        output, _, _ = _eng().run(inp)
        assert output.planning_status != PlannerStatus.UNKNOWN

    def test_missing_risk_set_with_candidates(self):
        """Missing risk set but candidates present: selection falls back, not crash."""
        inp = make_minimal_input()
        inp.risk_set = None
        cfg = default_config()
        cfg.require_risk_set = False
        from core.planning.planner_engine import PlannerEngine
        output, _, _ = PlannerEngine(cfg).run(inp)
        # Must not crash and must not fabricate a risk score
        assert isinstance(output.planning_status, type(output.planning_status))
