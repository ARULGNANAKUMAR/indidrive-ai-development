"""
Phase 9.6 — test_planner_validation.py

Tests: input validation, missing fields, frame mismatch, output validation,
       NO_FEASIBLE_CANDIDATE, ALL_CANDIDATES_HIGH_RISK.
"""
import pytest
from core.planning.planner_engine import PlannerEngine
from core.planning.planner_validator import PlannerValidator, InputValidationStatus
from core.planning.planner_types import (
    PlannerInput, PlannerStatus, PlannerOutput, NOT_AVAILABLE, PLANNER_SCHEMA_VERSION,
)
from tests.planning96.helpers_96 import (
    make_minimal_input, make_no_candidate_input, make_high_risk_input, default_config,
)


def _eng():
    return PlannerEngine(default_config())


class TestInputValidation:

    def test_valid_input_passes(self):
        v = PlannerValidator(default_config())
        inp = make_minimal_input()
        result = v.validate_input(inp, now=inp.timestamp)
        assert result.is_valid

    def test_null_frame_id_is_error(self):
        v = PlannerValidator(default_config())
        inp = make_minimal_input()
        inp.frame_id = None  # type: ignore
        result = v.validate_input(inp, now=inp.timestamp)
        assert not result.is_valid
        assert any("frame_id" in e for e in result.errors)

    def test_missing_candidate_set_required(self):
        from core.planning.planner_config import PlannerConfig
        cfg = default_config()
        cfg.require_candidate_set = True
        v = PlannerValidator(cfg)
        inp = make_minimal_input()
        inp.candidate_set = None
        result = v.validate_input(inp, now=inp.timestamp)
        assert not result.is_valid

    def test_missing_candidate_set_optional_degrades(self):
        from core.planning.planner_config import PlannerConfig
        cfg = default_config()
        cfg.require_candidate_set = False
        v = PlannerValidator(cfg)
        inp = make_minimal_input()
        inp.candidate_set = None
        result = v.validate_input(inp, now=inp.timestamp)
        assert result.status in (InputValidationStatus.VALID, InputValidationStatus.VALID_DEGRADED)

    def test_missing_risk_set_required(self):
        from core.planning.planner_config import PlannerConfig
        cfg = default_config()
        cfg.require_risk_set = True
        v = PlannerValidator(cfg)
        inp = make_minimal_input()
        inp.risk_set = None
        result = v.validate_input(inp, now=inp.timestamp)
        assert not result.is_valid

    def test_non_finite_timestamp_is_error(self):
        v = PlannerValidator(default_config())
        inp = make_minimal_input()
        inp.timestamp = float("nan")
        result = v.validate_input(inp, now=0.0)
        assert not result.is_valid

    def test_stale_planning_space_detected(self):
        v = PlannerValidator(default_config())
        inp = make_minimal_input()
        # Make now far in the future
        result = v.validate_input(inp, now=inp.timestamp + 100.0)
        # planning_space.timestamp = inp.timestamp, now = inp.timestamp + 100 → stale
        assert InputValidationStatus.STALE in (result.status,) or any("stale" in w.lower() for w in result.warnings)


class TestOutputValidation:

    def test_valid_output_passes(self):
        v = PlannerValidator(default_config())
        inp = make_minimal_input()
        output, _, _ = _eng().run(inp)
        res = v.validate_output(output)
        assert res.is_valid

    def test_wrong_schema_version_fails(self):
        v = PlannerValidator(default_config())
        inp = make_minimal_input()
        output, _, _ = _eng().run(inp)
        output.schema_version = "BAD"  # type: ignore
        res = v.validate_output(output)
        assert not res.is_valid

    def test_plan_available_with_no_permission_fails(self):
        v = PlannerValidator(default_config())
        inp = make_minimal_input()
        output, _, _ = _eng().run(inp)
        output.planning_status = PlannerStatus.PLAN_AVAILABLE
        output.planning_allowed = False  # contradiction
        res = v.validate_output(output)
        assert not res.is_valid

    def test_confidence_in_range(self):
        v = PlannerValidator(default_config())
        inp = make_minimal_input()
        output, _, _ = _eng().run(inp)
        assert 0.0 <= output.confidence <= 1.0
        assert 0.0 <= output.uncertainty <= 1.0


class TestEdgeCases:

    def test_no_feasible_candidate(self):
        inp = make_no_candidate_input()
        output, _, _ = _eng().run(inp)
        assert output.planning_status == PlannerStatus.NO_FEASIBLE_CANDIDATE
        assert output.selected_candidate_id == NOT_AVAILABLE
        assert output.planning_allowed is True

    def test_all_high_risk_blocked_or_replan(self):
        inp = make_high_risk_input(score=0.95)
        output, _, _ = _eng().run(inp)
        assert output.planning_status in (
            PlannerStatus.BLOCKED, PlannerStatus.REPLAN_REQUIRED
        )
        assert output.selected_candidate_id == NOT_AVAILABLE

    def test_no_fabricated_path_on_high_risk(self):
        inp = make_high_risk_input(score=0.95)
        output, _, _ = _eng().run(inp)
        assert output.selected_candidate_id == NOT_AVAILABLE

    def test_empty_input_returns_structured_result(self):
        """Even a fully empty PlannerInput must not crash."""
        eng = _eng()
        inp = PlannerInput(frame_id=0, timestamp=1700000000.0)
        output, snap, metrics = eng.run(inp)
        assert isinstance(output, PlannerOutput)
        assert output.planning_status != PlannerStatus.UNKNOWN or True  # must not crash
