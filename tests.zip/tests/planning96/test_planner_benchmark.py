"""
Phase 9.6 — test_planner_benchmark.py

Tests: BenchmarkResult structure, all 11 scenarios run, latency positive,
       result determinism across two consecutive runs.
"""
import pytest
from core.planning.planner_benchmark import PlannerBenchmark, BenchmarkResult
from core.planning.planner_types import PlannerStatus, NOT_AVAILABLE


SCENARIO_IDS = [
    "village_unmarked",
    "narrow_village",
    "dense_market",
    "highway_merge",
    "unsignalized_intersection",
    "cattle_crossing",
    "wrong_side_traffic",
    "damaged_narrow_road",
    "pedestrian_heavy_market",
    "mixed_motorcycle_traffic",
    "construction_zone",
]


class TestPlannerBenchmark:

    def test_run_all_returns_11_results(self):
        b = PlannerBenchmark()
        results = b.run_all()
        assert len(results) == 11

    def test_all_results_are_benchmark_result(self):
        b = PlannerBenchmark()
        for r in b.run_all():
            assert isinstance(r, BenchmarkResult)

    def test_all_have_scenario_id(self):
        b = PlannerBenchmark()
        for r in b.run_all():
            assert r.scenario_id in SCENARIO_IDS

    def test_latency_positive(self):
        b = PlannerBenchmark()
        for r in b.run_all():
            assert r.planning_latency_ms >= 0.0

    def test_to_dict_has_required_keys(self):
        b = PlannerBenchmark()
        r = b.run_all()[0]
        d = r.to_dict()
        for key in ("scenario_id", "planning_status", "planning_mode",
                    "candidate_count", "planning_latency_ms", "reason_codes"):
            assert key in d

    @pytest.mark.parametrize("sid", SCENARIO_IDS)
    def test_single_scenario_runs(self, sid):
        b = PlannerBenchmark()
        r = b.run_scenario(sid)
        assert isinstance(r, BenchmarkResult)
        assert r.scenario_id == sid

    def test_invalid_scenario_raises(self):
        b = PlannerBenchmark()
        with pytest.raises(ValueError, match="Unknown scenario_id"):
            b.run_scenario("nonexistent_road_xyz")

    def test_cattle_crossing_high_risk_or_replan(self):
        """Cattle scenario must produce elevated risk — not PLAN_AVAILABLE."""
        b = PlannerBenchmark()
        r = b.run_scenario("cattle_crossing")
        assert r.planning_status in (
            PlannerStatus.REPLAN_REQUIRED.value,
            PlannerStatus.BLOCKED.value,
        ), f"Expected high-risk outcome, got {r.planning_status}"

    def test_cattle_crossing_no_selection(self):
        b = PlannerBenchmark()
        r = b.run_scenario("cattle_crossing")
        assert r.selected_candidate_id == NOT_AVAILABLE

    def test_determinism_two_runs(self):
        """Same benchmark must produce identical statuses across two runs."""
        b1, b2 = PlannerBenchmark(), PlannerBenchmark()
        r1 = b1.run_all()
        r2 = b2.run_all()
        for a, b in zip(r1, r2):
            assert a.planning_status == b.planning_status, \
                f"Non-deterministic: {a.scenario_id}: {a.planning_status} vs {b.planning_status}"
            assert a.selected_candidate_id == b.selected_candidate_id

    def test_no_scenario_name_shortcuts(self):
        """
        Verify planning_mode is set from actual data, not from scenario name.
        All modes should match what was specified in the structured input.
        """
        b = PlannerBenchmark()
        expected_modes = {
            "village_unmarked": "DRIVABLE_SPACE",
            "narrow_village": "NARROW_ROAD",
            "dense_market": "MIXED_TRAFFIC",
            "highway_merge": "HIGHWAY",
            "unsignalized_intersection": "INTERSECTION",
        }
        for r in b.run_all():
            if r.scenario_id in expected_modes:
                exp = expected_modes[r.scenario_id]
                assert r.planning_mode == exp, \
                    f"{r.scenario_id}: expected mode {exp!r}, got {r.planning_mode!r}"

    def test_plan_available_scenarios_have_selection(self):
        """Every PLAN_AVAILABLE scenario must have a selected candidate."""
        b = PlannerBenchmark()
        for r in b.run_all():
            if r.planning_status == PlannerStatus.PLAN_AVAILABLE.value:
                assert r.selected_candidate_id != NOT_AVAILABLE, \
                    f"{r.scenario_id} is PLAN_AVAILABLE but has no selected candidate"

    def test_candidate_count_matches_scenario(self):
        """Every scenario must generate at least one candidate."""
        b = PlannerBenchmark()
        for r in b.run_all():
            assert r.candidate_count >= 0  # not negative
