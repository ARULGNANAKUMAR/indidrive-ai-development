"""
Phase 9.6 — test_planner_pipeline.py

Tests: basic pipeline, valid input, output generation, PlannerPipeline facade.
"""
import pytest
from core.planning.planner_pipeline import PlannerPipeline, run_pipeline
from core.planning.planner_types import (
    PlannerStatus, PlannerInput, PlannerOutput, PlannerSnapshot, PlannerMetrics,
    NOT_AVAILABLE, PLANNER_SCHEMA_VERSION,
)
from tests.planning96.helpers_96 import (
    make_minimal_input, make_no_candidate_input, default_config,
)


class TestPlannerPipeline:

    def test_returns_three_tuple(self):
        p = PlannerPipeline(default_config())
        inp = make_minimal_input()
        result = p.run(
            frame_id=inp.frame_id, timestamp=inp.timestamp,
            planning_space=inp.planning_space, candidate_set=inp.candidate_set,
            risk_set=inp.risk_set, replanning_result=inp.replanning_result,
            indian_road_result=inp.indian_road_result,
        )
        assert isinstance(result, tuple) and len(result) == 3
        output, snap, metrics = result
        assert isinstance(output, PlannerOutput)
        assert isinstance(snap, PlannerSnapshot)
        assert isinstance(metrics, PlannerMetrics)

    def test_valid_plan_available(self):
        p = PlannerPipeline(default_config())
        inp = make_minimal_input()
        output, snap, _ = p.run(
            frame_id=inp.frame_id, timestamp=inp.timestamp,
            planning_space=inp.planning_space, candidate_set=inp.candidate_set,
            risk_set=inp.risk_set, replanning_result=inp.replanning_result,
            indian_road_result=inp.indian_road_result,
        )
        assert output.planning_status == PlannerStatus.PLAN_AVAILABLE
        assert output.planning_allowed is True
        assert output.schema_version == PLANNER_SCHEMA_VERSION

    def test_no_candidates_status(self):
        p = PlannerPipeline(default_config())
        inp = make_no_candidate_input()
        output, _, _ = p.run(
            frame_id=inp.frame_id, timestamp=inp.timestamp,
            planning_space=inp.planning_space, candidate_set=inp.candidate_set,
            risk_set=inp.risk_set, replanning_result=inp.replanning_result,
            indian_road_result=inp.indian_road_result,
        )
        assert output.planning_status == PlannerStatus.NO_FEASIBLE_CANDIDATE
        assert output.selected_candidate_id == NOT_AVAILABLE

    def test_run_pipeline_function(self):
        inp = make_minimal_input()
        output, snap, metrics = run_pipeline(
            frame_id=inp.frame_id, timestamp=inp.timestamp,
            planning_space=inp.planning_space, candidate_set=inp.candidate_set,
            risk_set=inp.risk_set, replanning_result=inp.replanning_result,
            indian_road_result=inp.indian_road_result,
            config=default_config(),
        )
        assert isinstance(output, PlannerOutput)
        assert output.planning_status != PlannerStatus.UNKNOWN

    def test_reset_clears_snapshot(self):
        p = PlannerPipeline(default_config())
        inp = make_minimal_input()
        p.run(frame_id=inp.frame_id, timestamp=inp.timestamp,
              planning_space=inp.planning_space, candidate_set=inp.candidate_set,
              risk_set=inp.risk_set)
        assert p.last_snapshot is not None
        p.reset()
        assert p.last_snapshot is None

    def test_snapshot_schema_version(self):
        p = PlannerPipeline(default_config())
        inp = make_minimal_input()
        _, snap, _ = p.run(
            frame_id=inp.frame_id, timestamp=inp.timestamp,
            planning_space=inp.planning_space, candidate_set=inp.candidate_set,
            risk_set=inp.risk_set, replanning_result=inp.replanning_result,
            indian_road_result=inp.indian_road_result,
        )
        assert snap.schema_version == PLANNER_SCHEMA_VERSION

    def test_metrics_latency_is_positive(self):
        p = PlannerPipeline(default_config())
        inp = make_minimal_input()
        _, _, metrics = p.run(
            frame_id=inp.frame_id, timestamp=inp.timestamp,
            planning_space=inp.planning_space, candidate_set=inp.candidate_set,
            risk_set=inp.risk_set,
        )
        assert metrics.planning_latency_ms >= 0.0

    def test_to_dict_has_required_keys(self):
        p = PlannerPipeline(default_config())
        inp = make_minimal_input()
        output, snap, metrics = p.run(
            frame_id=inp.frame_id, timestamp=inp.timestamp,
            planning_space=inp.planning_space, candidate_set=inp.candidate_set,
            risk_set=inp.risk_set, replanning_result=inp.replanning_result,
            indian_road_result=inp.indian_road_result,
        )
        d = output.to_dict()
        for key in ("planning_status", "planning_allowed", "safety_gate_state",
                    "selected_candidate_id", "confidence", "schema_version"):
            assert key in d, f"Missing key {key!r} in output.to_dict()"
