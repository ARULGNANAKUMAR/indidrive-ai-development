"""
Phase 9.6 — test_planner_regression.py

Regression: Phase 9.1–9.5 public APIs must remain accessible
after Phase 9.6 integration.
"""
import pytest


class TestPhase91Regression:
    def test_planning_space_importable(self):
        from core.planning.planning_space_types import (
            PlanningSpace, PlanningSpaceStatus, PlanningSpaceQuality,
            PlanningHorizon, SpatialExtent,
        )

    def test_planning_space_builder_importable(self):
        from core.planning.planning_space_builder import PlanningSpaceBuilder

    def test_planning_input_types_importable(self):
        from core.planning.planning_input_types import PlanningInput


class TestPhase92Regression:
    def test_candidate_path_types_importable(self):
        from core.planning.candidate_path_types import (
            CandidatePath, CandidatePathSet, GenerationMethod,
            GeometricValidity, BoundaryValidity, DrivableSpaceValidity,
        )

    def test_candidate_generator_importable(self):
        from core.planning.candidate_generator import CandidatePathGenerator


class TestPhase93Regression:
    def test_path_risk_types_importable(self):
        from core.planning.path_risk_types import (
            CandidatePathRisk, PathRiskSet, RiskLevel,
            RiskBreakdown, RiskReasonCode,
        )

    def test_path_risk_engine_importable(self):
        from core.planning.path_risk_engine import PathRiskEngine


class TestPhase94Regression:
    def test_replanning_types_importable(self):
        from core.planning.replanning_types import (
            ReplanningDecision, ReplanningUrgency,
            ReplanningDecisionResult, ReplanningRequest,
        )

    def test_replanning_engine_importable(self):
        from core.planning.replanning_engine import ReplanningEngine


class TestPhase95Regression:
    def test_indian_road_planning_types_importable(self):
        from core.planning.indian_road_planning_types import (
            IndianRoadPlanningResult, IndianRoadPlanningConstraints,
            PlanningMode, LaneUsageMode, NarrowRoadState, TrafficContextSummary,
        )

    def test_indian_road_planning_adapter_importable(self):
        from core.planning.indian_road_planning_adapter import IndianRoadPlanningAdapter


class TestPhase96NewAPIAccessible:
    def test_planner_engine_importable(self):
        from core.planning.planner_engine import PlannerEngine

    def test_planner_pipeline_importable(self):
        from core.planning.planner_pipeline import PlannerPipeline, run_pipeline

    def test_planner_types_importable(self):
        from core.planning.planner_types import (
            PlannerStatus, PlannerInput, PlannerOutput, PlannerSnapshot,
            PlannerMetrics, CandidateSummary, RiskSummary, ReplanSummary,
        )

    def test_planner_benchmark_importable(self):
        from core.planning.planner_benchmark import PlannerBenchmark, BenchmarkResult

    def test_planner_validator_importable(self):
        from core.planning.planner_validator import (
            PlannerValidator, InputValidationResult, OutputValidationResult,
        )

    def test_init_exports(self):
        from core.planning import (
            PlannerEngine, PlannerPipeline, PlannerStatus,
            PlannerBenchmark, PlannerInput, PlannerOutput,
        )


class TestCoordinateConventionConsistency:
    """Phase 9.6 must use the same +X/+Y/+Z vehicle frame as prior phases."""

    def test_planner_config_expects_vehicle_frame(self):
        from core.planning.planner_config import PlannerConfig
        cfg = PlannerConfig()
        assert cfg.expected_coordinate_frame == "VEHICLE"

    def test_benchmark_uses_vehicle_frame(self):
        from core.planning.planner_benchmark import PlannerBenchmark
        b = PlannerBenchmark()
        results = b.run_all()
        for r in results:
            if r.planning_status in ("PLAN_AVAILABLE", "REPLAN_REQUIRED"):
                # No frame mismatch errors
                assert not any("frame" in e.lower() for e in r.validation_errors), \
                    f"{r.scenario_id}: frame error: {r.validation_errors}"
