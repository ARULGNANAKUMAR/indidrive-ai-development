"""
Phase 9.6 — test_negative_scope.py

Explicitly verifies Phase 9.6 does NOT contain:
  - steering, throttle, brake, actuator commands
  - MPC, PID, vehicle dynamics controller
  - new perception, new prediction, new sensor fusion
  - LLM / cloud reasoning
"""
import ast
import inspect
import pytest
import importlib

PHASE_96_MODULES = [
    "core.planning.planner_types",
    "core.planning.planner_config",
    "core.planning.planner_validator",
    "core.planning.planner_engine",
    "core.planning.planner_pipeline",
    "core.planning.planner_benchmark",
]

FORBIDDEN_NAMES = [
    "steering", "throttle", "brake", "actuator_command",
    "wheel_angle", "motor_command", "mpc_output", "pid_output",
    "control_command",
]

FORBIDDEN_IMPORTS = [
    "openai", "anthropic", "google.generativeai", "faiss",
    "requests", "httpx", "urllib",
]

FORBIDDEN_NEW_PERCEPTION = [
    "yolo", "segment", "lane_detector", "lidar_detector",
    "radar_detector", "camera_model",
]

FORBIDDEN_NEW_PREDICTION = [
    "kalman_filter", "transformer_pred", "behavior_predictor",
]

FORBIDDEN_CONTROLLERS = [
    "class MPC", "class PID", "class SteeringController",
    "class ThrottleController", "class BrakeController",
    "class VehicleDynamics",
]


def _source(module_name: str) -> str:
    mod = importlib.import_module(module_name)
    return inspect.getsource(mod).lower()


def _ast_source(module_name: str) -> str:
    mod = importlib.import_module(module_name)
    return inspect.getsource(mod)


class TestNoVehicleControl:

    def _no_control_field_in_code(self, module: str, keyword: str) -> None:
        """
        Assert no executable assignment of vehicle control fields exists.
        Strategy: parse the AST and check that no dataclass field name,
        function parameter, or assignment target uses the keyword.
        Docstrings listing what is NOT present are allowed.
        """
        import importlib, inspect, ast
        mod = importlib.import_module(module)
        src = inspect.getsource(mod)
        try:
            tree = ast.parse(src)
        except SyntaxError:
            return  # skip unparseable source
        violations = []
        for node in ast.walk(tree):
            # Detect annotated assignments like:  steering: float = 0.0
            if isinstance(node, ast.AnnAssign) and isinstance(node.target, ast.Name):
                if keyword in node.target.id.lower():
                    violations.append(f"AnnAssign: {node.target.id}")
            # Detect plain assignments:  steering = 0.0
            elif isinstance(node, ast.Assign):
                for t in node.targets:
                    if isinstance(t, ast.Name) and keyword in t.id.lower():
                        violations.append(f"Assign: {t.id}")
            # Detect function args:  def f(self, steering: float)
            elif isinstance(node, ast.FunctionDef):
                for arg in node.args.args + node.args.kwonlyargs:
                    if keyword in arg.arg.lower():
                        violations.append(f"arg: {arg.arg} in {node.name}")
        assert not violations, (
            f"{module}: AST finds '{keyword}' as a code construct:\n"
            + "\n".join(violations)
        )

    @pytest.mark.parametrize("module", PHASE_96_MODULES)
    def test_no_steering_field(self, module):
        self._no_control_field_in_code(module, "steering")

    @pytest.mark.parametrize("module", PHASE_96_MODULES)
    def test_no_throttle_field(self, module):
        self._no_control_field_in_code(module, "throttle")

    @pytest.mark.parametrize("module", PHASE_96_MODULES)
    def test_no_brake_field(self, module):
        self._no_control_field_in_code(module, "brake")

    @pytest.mark.parametrize("module", PHASE_96_MODULES)
    def test_no_actuator_field(self, module):
        self._no_control_field_in_code(module, "actuator")


class TestNoControllerClasses:

    @pytest.mark.parametrize("module", PHASE_96_MODULES)
    def test_no_mpc_class(self, module):
        src = _ast_source(module)
        assert "class MPC" not in src, f"{module}: defines MPC class"
        assert "class Mpc" not in src, f"{module}: defines Mpc class"

    @pytest.mark.parametrize("module", PHASE_96_MODULES)
    def test_no_pid_class(self, module):
        src = _ast_source(module)
        assert "class PID" not in src, f"{module}: defines PID class"
        assert "class Pid" not in src, f"{module}: defines Pid class"


class TestNoNewPerception:

    @pytest.mark.parametrize("module", PHASE_96_MODULES)
    def test_no_yolo_import(self, module):
        src = _source(module)
        assert "import yolo" not in src
        assert "from yolo" not in src

    @pytest.mark.parametrize("module", PHASE_96_MODULES)
    def test_no_camera_model(self, module):
        src = _source(module)
        assert "camera_model" not in src or "# camera_model" in src.replace("camera model", "")


class TestNoCloudAPIs:

    @pytest.mark.parametrize("module", PHASE_96_MODULES)
    def test_no_openai(self, module):
        src = _source(module)
        assert "openai" not in src

    @pytest.mark.parametrize("module", PHASE_96_MODULES)
    def test_no_anthropic_api(self, module):
        src = _source(module)
        # anthropic.com should not appear as an API endpoint
        assert "api.anthropic.com" not in src
        assert "import anthropic" not in src

    @pytest.mark.parametrize("module", PHASE_96_MODULES)
    def test_no_faiss(self, module):
        src = _source(module)
        assert "import faiss" not in src
        assert "from faiss" not in src


class TestOutputFieldsNoControl:

    def test_output_has_no_steering_attr(self):
        from core.planning.planner_types import PlannerOutput
        output = PlannerOutput()
        assert not hasattr(output, "steering")
        assert not hasattr(output, "throttle")
        assert not hasattr(output, "brake")
        assert not hasattr(output, "actuator_command")
        assert not hasattr(output, "wheel_angle")
        assert not hasattr(output, "mpc_output")

    def test_snapshot_has_no_control_fields(self):
        from core.planning.planner_types import PlannerSnapshot
        snap = PlannerSnapshot()
        assert not hasattr(snap, "steering")
        assert not hasattr(snap, "throttle")
        assert not hasattr(snap, "brake")

    def test_output_dict_has_no_control_keys(self):
        from core.planning.planner_engine import PlannerEngine
        from tests.planning96.helpers_96 import make_minimal_input, default_config
        eng = PlannerEngine(default_config())
        output, _, _ = eng.run(make_minimal_input())
        d = output.to_dict()
        for forbidden in ("steering", "throttle", "brake", "actuator_command",
                          "wheel_angle", "mpc_output"):
            assert forbidden not in d, f"Control field {forbidden!r} found in output dict"
