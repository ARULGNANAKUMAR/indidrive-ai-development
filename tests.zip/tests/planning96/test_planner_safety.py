"""
Phase 9.6 — test_planner_safety.py

Tests: all safety gate states, planning_allowed=False handling,
       safety-restricted output validation.

The planner must NEVER return PLAN_AVAILABLE when planning_allowed=False.
"""
import pytest
from core.planning.planner_engine import PlannerEngine
from core.planning.planner_types import PlannerStatus, NOT_AVAILABLE
from tests.planning96.helpers_96 import (
    make_minimal_input, make_safety_blocked_input, default_config,
)
from core.planning.planner_benchmark import (
    _T0, _make_planning_space, _make_candidate, _make_candidate_set,
    _make_risk, _make_risk_set, _make_replan_result, _make_indian_result,
)
from core.planning.path_risk_types import RiskLevel
from core.planning.replanning_types import ReplanningDecision
from core.planning.indian_road_planning_types import PlanningMode


def _engine():
    return PlannerEngine(default_config())


def _run_with_gate(sg_state: str, planning_allowed: bool):
    fid = 8800
    ts = _T0 + float(fid)
    ps = _make_planning_space(fid, ts, planning_allowed=planning_allowed, sg_state=sg_state)
    cands = [_make_candidate("c0", 0.0)]
    cs = _make_candidate_set(fid, ts, cands, planning_allowed=planning_allowed, sg_state=sg_state)
    rs = _make_risk_set(fid, ts, [_make_risk("c0", 0.2, RiskLevel.LOW_RISK)])
    rr = _make_replan_result(ReplanningDecision.NO_REPLAN, sg_state=sg_state)
    ir = _make_indian_result(PlanningMode.DRIVABLE_SPACE)
    from core.planning.planner_types import PlannerInput
    inp = PlannerInput(
        frame_id=fid, timestamp=ts,
        planning_space=ps, candidate_set=cs, risk_set=rs,
        replanning_result=rr, indian_road_result=ir,
    )
    eng = _engine()
    output, snap, _ = eng.run(inp)
    return output, snap


class TestSafetyGate:

    def test_clear_allows_planning(self):
        output, _ = _run_with_gate("CLEAR", planning_allowed=True)
        assert output.planning_allowed is True
        assert output.planning_status == PlannerStatus.PLAN_AVAILABLE

    def test_caution_still_plans(self):
        output, _ = _run_with_gate("CAUTION", planning_allowed=True)
        assert output.planning_allowed is True
        assert output.planning_status in (PlannerStatus.PLAN_AVAILABLE, PlannerStatus.DEGRADED)

    def test_restricted_blocked(self):
        output, _ = _run_with_gate("RESTRICTED", planning_allowed=False)
        assert output.planning_allowed is False
        assert output.planning_status == PlannerStatus.SAFETY_RESTRICTED
        assert output.selected_candidate_id == NOT_AVAILABLE

    def test_high_alert_blocked(self):
        output, _ = _run_with_gate("HIGH_ALERT", planning_allowed=False)
        assert output.planning_allowed is False
        assert output.planning_status == PlannerStatus.SAFETY_RESTRICTED

    def test_critical_blocked(self):
        output, _ = _run_with_gate("CRITICAL", planning_allowed=False)
        assert output.planning_allowed is False
        assert output.planning_status == PlannerStatus.SAFETY_RESTRICTED
        assert output.selected_candidate_id == NOT_AVAILABLE

    def test_degraded_gate(self):
        output, _ = _run_with_gate("DEGRADED", planning_allowed=False)
        assert output.planning_status == PlannerStatus.SAFETY_RESTRICTED

    def test_unknown_gate_blocked(self):
        output, _ = _run_with_gate("UNKNOWN", planning_allowed=False)
        assert output.planning_status == PlannerStatus.SAFETY_RESTRICTED

    def test_plan_available_never_when_not_allowed(self):
        """The planner MUST NOT return PLAN_AVAILABLE when planning_allowed=False."""
        for sg in ("CRITICAL", "HIGH_ALERT", "RESTRICTED", "UNKNOWN", "DEGRADED"):
            output, _ = _run_with_gate(sg, planning_allowed=False)
            assert output.planning_status != PlannerStatus.PLAN_AVAILABLE, \
                f"PLAN_AVAILABLE returned with sg={sg} planning_allowed=False"

    def test_safety_restricted_has_no_selected_candidate(self):
        output, _ = _run_with_gate("CRITICAL", planning_allowed=False)
        assert output.selected_candidate_id == NOT_AVAILABLE

    def test_safety_gate_state_preserved_in_output(self):
        output, _ = _run_with_gate("CLEAR", planning_allowed=True)
        assert output.safety_gate_state == "CLEAR"
