"""
IndiDrive AI — Phase 6.5 Test Suite
=====================================
Tests for RoadUnderstandingState and RoadUnderstandingEngine.

Covers:
  - Indian-road end-to-end scenarios (spec §37)
  - Degradation modes (spec §38)
  - Timestamp validation (spec §39)
  - Frame consistency (spec §40)
  - Confidence aggregation (spec §41)
  - Uncertainty propagation (spec §42)
  - Consistency checks (spec §43)
  - Determinism (spec §44)
  - Serialization round-trip (spec §45)
  - No raw sensor data leakage (spec §46)

All tests use synthetic upstream state objects — no CARLA / real sensors.
"""
from __future__ import annotations

import copy
import math
import sys
import time
import unittest
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Optional

sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))

from core.perception.road_understanding_engine import RoadUnderstandingEngine
from core.perception.road_understanding_state import (
    RoadUnderstandingState,
    RoadUnderstandingStateConfig,
    UnifiedStatus,
    ModuleAvailability,
    TimestampConsistency,
    GeometryConsistency,
    STATE_VERSION,
)
from core.perception.perception_types import NOT_AVAILABLE


# ---------------------------------------------------------------------------
# Synthetic upstream state builders
# ---------------------------------------------------------------------------

def _ts(offset: float = 0.0) -> float:
    """Return a stable test timestamp."""
    return 1_700_000_000.0 + offset


@dataclass
class _BoundaryPoint:
    x: float; y: float; confidence: float = 0.8; point_support: int = 10
    def to_dict(self): return {"x": self.x, "y": self.y, "confidence": self.confidence}


@dataclass
class _RoadBoundary:
    side: str = "left"; points: list = field(default_factory=list)
    available: bool = True; source: str = "lidar"; confidence: float = 0.8
    def to_dict(self):
        return {"side": self.side, "available": self.available,
                "source": self.source, "confidence": self.confidence, "points": []}


@dataclass
class _WidthSample:
    distance_m: float = 5.0; width_m: Optional[float] = 6.0
    def to_dict(self): return {"distance_m": self.distance_m,
                               "width_m": self.width_m if self.width_m else NOT_AVAILABLE}


class _RUSStatus(str, Enum):
    OK = "OK"; PARTIAL = "PARTIAL"; DEGRADED = "DEGRADED"; UNAVAILABLE = "UNAVAILABLE"; INVALID = "INVALID"


@dataclass
class _DrivableArea:
    """Synthetic Phase 6.1 RoadUnderstanding."""
    timestamp: float = field(default_factory=_ts)
    frame_id: int = 1
    status: _RUSStatus = _RUSStatus.OK
    left_boundary: _RoadBoundary = field(default_factory=lambda: _RoadBoundary("left"))
    right_boundary: _RoadBoundary = field(default_factory=lambda: _RoadBoundary("right"))
    drivable_area_available: bool = True
    drivable_polygon: list = field(default_factory=lambda: [(0,3),(30,3),(30,-3),(0,-3)])
    road_width_profile: list = field(default_factory=lambda: [_WidthSample(5.0, 6.0)])
    confidence: float = 0.85
    uncertainty: float = 0.15
    source: str = "fusion"
    sensor_status: dict = field(default_factory=lambda: {"camera": "OK", "lidar": "OK"})
    warnings: list = field(default_factory=list)

    def to_dict(self): return {"timestamp": self.timestamp, "frame_id": self.frame_id,
                               "status": self.status.value, "confidence": self.confidence,
                               "uncertainty": self.uncertainty, "source": self.source}


class _LSStatus(str, Enum):
    OK = "OK"; PARTIAL = "PARTIAL"; DEGRADED = "DEGRADED"; UNAVAILABLE = "UNAVAILABLE"; INVALID = "INVALID"


class _MarkingStatus(str, Enum):
    MARKED = "MARKED"; WEAKLY_MARKED = "WEAKLY_MARKED"
    UNMARKED = "UNMARKED"; UNKNOWN = "UNKNOWN"


class _IntersectionState(str, Enum):
    NORMAL_ROAD = "NORMAL_ROAD"; INTERSECTION = "INTERSECTION"; UNKNOWN = "UNKNOWN"


class _RoadTypeHint(str, Enum):
    SINGLE_LANE = "SINGLE_LANE"; MULTI_LANE = "MULTI_LANE"
    UNDIVIDED = "UNDIVIDED"; UNMARKED_CORRIDOR = "UNMARKED_CORRIDOR"; UNKNOWN = "UNKNOWN"


@dataclass
class _LaneStructure:
    """Synthetic Phase 6.2 LaneStructure."""
    timestamp: float = field(default_factory=_ts)
    frame_id: int = 1
    status: _LSStatus = _LSStatus.OK
    lanes: list = field(default_factory=list)
    lane_count: Optional[int] = 2
    lane_count_confidence: float = 0.8
    road_heading_rad: Optional[float] = 0.0
    marking_status: _MarkingStatus = _MarkingStatus.MARKED
    road_type: _RoadTypeHint = _RoadTypeHint.MULTI_LANE
    intersection_state: _IntersectionState = _IntersectionState.NORMAL_ROAD
    confidence: float = 0.80
    uncertainty: float = 0.20
    source: str = "camera"
    sensor_status: dict = field(default_factory=lambda: {"camera": "OK"})
    warnings: list = field(default_factory=list)

    def to_dict(self): return {"timestamp": self.timestamp, "frame_id": self.frame_id,
                               "status": self.status.value, "lane_count": self.lane_count,
                               "marking_status": self.marking_status.value,
                               "confidence": self.confidence, "uncertainty": self.uncertainty}


class _AEStatus(str, Enum):
    OK = "OK"; PARTIAL = "PARTIAL"; DEGRADED = "DEGRADED"; UNAVAILABLE = "UNAVAILABLE"; ERROR = "ERROR"


class _RSQ(str, Enum):
    GOOD = "GOOD"; FAIR = "FAIR"; POOR = "POOR"; VERY_POOR = "VERY_POOR"; UNKNOWN = "UNKNOWN"


@dataclass
class _RoadAnomalyState:
    """Synthetic Phase 6.3 RoadAnomalyState."""
    timestamp: float = field(default_factory=_ts)
    frame_id: int = 1
    status: _AEStatus = _AEStatus.OK
    anomalies: list = field(default_factory=list)
    road_surface_quality: _RSQ = _RSQ.GOOD
    overall_confidence: float = 0.75
    overall_uncertainty: float = 0.25
    sensor_status: dict = field(default_factory=lambda: {"camera": "OK", "lidar": "OK"})
    degraded: bool = False
    source_summary: str = "fusion"
    stats: dict = field(default_factory=dict)
    warnings: list = field(default_factory=list)

    def to_dict(self): return {"timestamp": self.timestamp, "frame_id": self.frame_id,
                               "status": self.status.value,
                               "road_surface_quality": self.road_surface_quality.value,
                               "overall_confidence": self.overall_confidence,
                               "overall_uncertainty": self.overall_uncertainty}


class _CEStatus(str, Enum):
    OK = "OK"; PARTIAL = "PARTIAL"; DEGRADED = "DEGRADED"; UNAVAILABLE = "UNAVAILABLE"


class _RoadType(str, Enum):
    VILLAGE_ROAD = "VILLAGE_ROAD"; DISTRICT_ROAD = "DISTRICT_ROAD"
    STATE_HIGHWAY = "STATE_HIGHWAY"; NATIONAL_HIGHWAY = "NATIONAL_HIGHWAY"
    URBAN_LOCAL = "URBAN_LOCAL"; MARKET_ROAD = "MARKET_ROAD"; UNKNOWN = "UNKNOWN"


class _RWC(str, Enum):
    VERY_NARROW = "VERY_NARROW"; NARROW = "NARROW"; NORMAL = "NORMAL"
    WIDE = "WIDE"; VERY_WIDE = "VERY_WIDE"; UNKNOWN = "UNKNOWN"


class _RMS(str, Enum):
    MARKED = "MARKED"; UNMARKED = "UNMARKED"; PARTIALLY_MARKED = "PARTIALLY_MARKED"; UNKNOWN = "UNKNOWN"


class _IC(str, Enum):
    STRAIGHT = "STRAIGHT"; INTERSECTION = "INTERSECTION"; T_JUNCTION = "T_JUNCTION"; UNKNOWN = "UNKNOWN"


class _TD(str, Enum):
    VERY_LOW = "VERY_LOW"; LOW = "LOW"; MEDIUM = "MEDIUM"; HIGH = "HIGH"; VERY_HIGH = "VERY_HIGH"; UNKNOWN = "UNKNOWN"


class _RC(str, Enum):
    LOW = "LOW"; MEDIUM = "MEDIUM"; HIGH = "HIGH"; VERY_HIGH = "VERY_HIGH"; UNKNOWN = "UNKNOWN"


class _VRU(str, Enum):
    NONE = "NONE"; PRESENT = "PRESENT"; MULTIPLE_PRESENT = "MULTIPLE_PRESENT"; UNKNOWN = "UNKNOWN"


@dataclass
class _SensorSummary:
    camera_ok: bool = True; lidar_ok: bool = True; radar_ok: bool = False
    def to_dict(self): return {"camera": "OK" if self.camera_ok else "UNAVAILABLE",
                               "lidar": "OK" if self.lidar_ok else "UNAVAILABLE"}


@dataclass
class _IndianContext:
    """Synthetic Phase 6.4 IndianRoadContextState."""
    timestamp: float = field(default_factory=_ts)
    frame_id: int = 1
    status: _CEStatus = _CEStatus.OK
    road_type: _RoadType = _RoadType.DISTRICT_ROAD
    road_type_confidence: float = 0.8
    road_marking_state: _RMS = _RMS.MARKED
    estimated_road_width_m: Optional[float] = 6.0
    road_width_category: _RWC = _RWC.NORMAL
    lane_count: Optional[int] = 2
    lane_count_confidence: float = 0.75
    road_type_hint: str = "MULTI_LANE"
    boundary_availability: str = "BOTH"
    weak_boundaries: bool = False
    intersection_context: _IC = _IC.STRAIGHT
    traffic_density: _TD = _TD.LOW
    vru_presence: _VRU = _VRU.NONE
    animal_present: bool = False
    road_complexity: _RC = _RC.LOW
    complexity_score: float = 0.2
    context_flags: list = field(default_factory=list)
    confidence: float = 0.82
    uncertainty: float = 0.18
    sensor_status: _SensorSummary = field(default_factory=_SensorSummary)
    degraded: bool = False
    source_summary: str = "derived"
    warnings: list = field(default_factory=list)
    metadata: dict = field(default_factory=dict)

    def to_dict(self): return {"timestamp": self.timestamp, "frame_id": self.frame_id,
                               "status": self.status.value,
                               "road_type": self.road_type.value,
                               "road_width_category": self.road_width_category.value,
                               "road_marking_state": self.road_marking_state.value,
                               "traffic_density": self.traffic_density.value,
                               "road_complexity": self.road_complexity.value,
                               "confidence": self.confidence,
                               "uncertainty": self.uncertainty}


# ---------------------------------------------------------------------------
# Test helpers
# ---------------------------------------------------------------------------

def _build_engine(cfg: RoadUnderstandingStateConfig = None) -> RoadUnderstandingEngine:
    return RoadUnderstandingEngine(cfg)


def _full_state(ts_offset: float = 0.0, **overrides):
    """Build a set of healthy upstream states."""
    ts = _ts(ts_offset)
    da = _DrivableArea(timestamp=ts)
    ls = _LaneStructure(timestamp=ts)
    ra = _RoadAnomalyState(timestamp=ts)
    ctx = _IndianContext(timestamp=ts)
    for k, v in overrides.items():
        if hasattr(da, k): setattr(da, k, v)
        if hasattr(ls, k): setattr(ls, k, v)
        if hasattr(ra, k): setattr(ra, k, v)
        if hasattr(ctx, k): setattr(ctx, k, v)
    return da, ls, ra, ctx


# ===========================================================================
# 1. Schema and basic construction
# ===========================================================================

class TestSchemaBasics(unittest.TestCase):

    def test_state_version(self):
        e = _build_engine()
        s = e.process()
        self.assertEqual(s.state_version, STATE_VERSION)
        self.assertEqual(s.state_version, "6.5")

    def test_fully_unavailable_when_all_none(self):
        e = _build_engine()
        s = e.process()
        self.assertEqual(s.status, UnifiedStatus.UNAVAILABLE)
        self.assertFalse(s.valid)
        self.assertTrue(s.degraded)

    def test_ok_status_with_all_healthy(self):
        e = _build_engine()
        da, ls, ra, ctx = _full_state()
        s = e.process(da, ls, ra, ctx)
        self.assertIn(s.status, (UnifiedStatus.OK, UnifiedStatus.PARTIAL))
        self.assertTrue(s.valid)

    def test_module_availability_all_ok(self):
        e = _build_engine()
        da, ls, ra, ctx = _full_state()
        s = e.process(da, ls, ra, ctx)
        self.assertEqual(s.phase61_availability, ModuleAvailability.OK)
        self.assertEqual(s.phase62_availability, ModuleAvailability.OK)
        self.assertEqual(s.phase63_availability, ModuleAvailability.OK)
        self.assertEqual(s.phase64_availability, ModuleAvailability.OK)

    def test_module_availability_all_none(self):
        e = _build_engine()
        s = e.process()
        for a in (s.phase61_availability, s.phase62_availability,
                  s.phase63_availability, s.phase64_availability):
            self.assertEqual(a, ModuleAvailability.UNAVAILABLE)

    def test_state_has_timestamp(self):
        e = _build_engine()
        da, ls, ra, ctx = _full_state(0.0)
        s = e.process(da, ls, ra, ctx)
        self.assertGreater(s.timestamp, 0.0)

    def test_state_has_frame_id(self):
        e = _build_engine()
        da, ls, ra, ctx = _full_state()
        s = e.process(da, ls, ra, ctx)
        self.assertGreaterEqual(s.frame_id, 0)


# ===========================================================================
# 2. Indian-road end-to-end scenarios (spec §37)
# ===========================================================================

class TestIndianRoadScenarios(unittest.TestCase):

    def test_unmarked_village_road(self):
        """Test 1 — Unmarked village road (narrow, weak markings, minor damage, low traffic)."""
        e = _build_engine()
        da = _DrivableArea(road_width_profile=[_WidthSample(5.0, 4.0)], confidence=0.7)
        ls = _LaneStructure(marking_status=_MarkingStatus.UNMARKED, lane_count=1,
                            status=_LSStatus.PARTIAL, confidence=0.5)
        ra = _RoadAnomalyState(road_surface_quality=_RSQ.POOR, overall_confidence=0.6)
        ctx = _IndianContext(
            road_type=_RoadType.VILLAGE_ROAD,
            road_width_category=_RWC.NARROW,
            road_marking_state=_RMS.UNMARKED,
            traffic_density=_TD.VERY_LOW,
            road_complexity=_RC.LOW,
            confidence=0.72
        )
        s = e.process(da, ls, ra, ctx)

        self.assertIn(s.status, (UnifiedStatus.OK, UnifiedStatus.PARTIAL, UnifiedStatus.DEGRADED))
        self.assertEqual(s.summary.road_type, "VILLAGE_ROAD")
        self.assertEqual(s.summary.road_width_category, "NARROW")
        self.assertEqual(s.summary.lane_marking_state, "UNMARKED")
        self.assertEqual(s.summary.road_surface_quality, "POOR")
        self.assertEqual(s.summary.traffic_density, "VERY_LOW")
        # Must NOT contain any driving action
        d = s.to_dict()
        summary_str = str(d.get("summary", {}))
        for action_word in ("turn_left", "turn_right", "slow_down", "brake", "overtake", "stop", "swerve"):
            self.assertNotIn(action_word, summary_str)

    def test_busy_market_road(self):
        """Test 2 — Busy market road (high pedestrians, two-wheelers, autos, high traffic, weak marking)."""
        e = _build_engine()
        da = _DrivableArea(confidence=0.72)
        ls = _LaneStructure(marking_status=_MarkingStatus.WEAKLY_MARKED, lane_count=2, confidence=0.55)
        ra = _RoadAnomalyState(road_surface_quality=_RSQ.FAIR, overall_confidence=0.65)
        ctx = _IndianContext(
            road_type=_RoadType.MARKET_ROAD,
            road_width_category=_RWC.NARROW,
            road_marking_state=_RMS.PARTIALLY_MARKED,
            traffic_density=_TD.HIGH,
            vru_presence=_VRU.MULTIPLE_PRESENT,
            road_complexity=_RC.HIGH,
            confidence=0.68
        )
        s = e.process(da, ls, ra, ctx)

        self.assertEqual(s.summary.road_type, "MARKET_ROAD")
        self.assertEqual(s.summary.traffic_density, "HIGH")
        self.assertEqual(s.summary.vru_presence, "MULTIPLE_PRESENT")
        self.assertEqual(s.summary.road_complexity, "HIGH")
        self.assertIsNotNone(s.summary.lane_count)

    def test_highway(self):
        """Test 3 — Highway (wide, structured lanes, clear markings, low complexity)."""
        e = _build_engine()
        da = _DrivableArea(road_width_profile=[_WidthSample(5.0, 14.0)], confidence=0.92)
        ls = _LaneStructure(marking_status=_MarkingStatus.MARKED, lane_count=4,
                            intersection_state=_IntersectionState.NORMAL_ROAD, confidence=0.90)
        ra = _RoadAnomalyState(road_surface_quality=_RSQ.GOOD, overall_confidence=0.88)
        ctx = _IndianContext(
            road_type=_RoadType.NATIONAL_HIGHWAY,
            road_width_category=_RWC.VERY_WIDE,
            road_marking_state=_RMS.MARKED,
            traffic_density=_TD.LOW,
            road_complexity=_RC.LOW,
            confidence=0.91
        )
        s = e.process(da, ls, ra, ctx)

        self.assertIn(s.status, (UnifiedStatus.OK, UnifiedStatus.PARTIAL))
        self.assertEqual(s.summary.road_type, "NATIONAL_HIGHWAY")
        self.assertEqual(s.summary.road_width_category, "VERY_WIDE")
        self.assertEqual(s.summary.road_surface_quality, "GOOD")
        self.assertEqual(s.summary.road_complexity, "LOW")
        self.assertGreater(s.overall_confidence, 0.5)

    def test_damaged_narrow_road(self):
        """Test 4 — Damaged narrow road (narrow, unmarked, potholes, road-edge damage)."""
        e = _build_engine()

        class _Geom:
            center_x_m = 5.0; center_y_m = 0.5

        class _Sev(str, Enum):
            CRITICAL = "CRITICAL"

        class _DAR(str, Enum):
            INSIDE_DRIVABLE_AREA = "INSIDE_DRIVABLE_AREA"

        class _Anomaly:
            severity = _Sev.CRITICAL
            drivable_area_relation = _DAR.INSIDE_DRIVABLE_AREA
            geometry = _Geom()

        ra = _RoadAnomalyState(
            road_surface_quality=_RSQ.VERY_POOR,
            anomalies=[_Anomaly()],
            overall_confidence=0.7
        )
        da = _DrivableArea(road_width_profile=[_WidthSample(5.0, 3.5)], confidence=0.68)
        ls = _LaneStructure(marking_status=_MarkingStatus.UNMARKED, lane_count=1, confidence=0.5)
        ctx = _IndianContext(
            road_type=_RoadType.VILLAGE_ROAD,
            road_width_category=_RWC.VERY_NARROW,
            road_marking_state=_RMS.UNMARKED,
            road_complexity=_RC.HIGH,
            confidence=0.65
        )
        s = e.process(da, ls, ra, ctx)

        self.assertEqual(s.summary.road_surface_quality, "VERY_POOR")
        self.assertEqual(s.summary.road_width_category, "VERY_NARROW")
        self.assertEqual(s.summary.road_complexity, "HIGH")
        self.assertTrue(s.summary.has_critical_anomaly)
        self.assertEqual(s.summary.anomaly_count, 1)
        # No driving action in output
        d = s.to_dict()
        self.assertNotIn("avoidance_command", str(d))

    def test_cattle_crossing_context(self):
        """Test 5 — Cattle crossing (animal present, verify context, no avoidance command)."""
        e = _build_engine()
        da, ls, ra, _ = _full_state()
        ctx = _IndianContext(
            animal_present=True,
            road_complexity=_RC.MEDIUM,
            traffic_density=_TD.LOW,
            confidence=0.78
        )
        s = e.process(da, ls, ra, ctx)

        self.assertTrue(s.summary.animal_present)
        self.assertNotIn("avoid", str(s.to_dict()).lower().replace("unavailable", ""))
        self.assertNotIn("stop", str(s.to_dict()).lower().replace("status", ""))

    def test_construction_road(self):
        """Test 6 — Construction road (debris, damaged road, weak lane structure)."""
        e = _build_engine()

        class _Geom:
            center_x_m = 8.0; center_y_m = 1.0

        class _Sev(str, Enum):
            MEDIUM = "MEDIUM"

        class _DAR(str, Enum):
            PARTIALLY_OVERLAPPING_DRIVABLE_AREA = "PARTIALLY_OVERLAPPING_DRIVABLE_AREA"

        class _Anomaly:
            severity = _Sev.MEDIUM
            drivable_area_relation = _DAR.PARTIALLY_OVERLAPPING_DRIVABLE_AREA
            geometry = _Geom()

        ra = _RoadAnomalyState(
            road_surface_quality=_RSQ.POOR,
            anomalies=[_Anomaly(), _Anomaly()],
            overall_confidence=0.65
        )
        ls = _LaneStructure(marking_status=_MarkingStatus.WEAKLY_MARKED, confidence=0.5, status=_LSStatus.PARTIAL)
        ctx = _IndianContext(road_complexity=_RC.VERY_HIGH, traffic_density=_TD.MEDIUM, confidence=0.62)
        s = e.process(None, ls, ra, ctx)

        self.assertEqual(s.summary.road_surface_quality, "POOR")
        self.assertEqual(s.summary.road_complexity, "VERY_HIGH")
        self.assertEqual(s.summary.anomaly_count, 2)
        # Phase 6.1 unavailable → drivable area not invented
        self.assertIsNone(s.drivable_area_state)

    def test_complex_intersection(self):
        """Test 7 — Complex intersection (multiple roads, high traffic, mixed users)."""
        e = _build_engine()
        da, _, ra, _ = _full_state()
        ls = _LaneStructure(
            intersection_state=_IntersectionState.INTERSECTION,
            lane_count=None,   # unknown at intersection
            marking_status=_MarkingStatus.UNKNOWN,
            confidence=0.55
        )
        ctx = _IndianContext(
            intersection_context=_IC.INTERSECTION,
            traffic_density=_TD.HIGH,
            vru_presence=_VRU.MULTIPLE_PRESENT,
            road_complexity=_RC.VERY_HIGH,
            confidence=0.60
        )
        s = e.process(da, ls, ra, ctx)

        self.assertEqual(s.summary.intersection_state, "INTERSECTION")
        self.assertEqual(s.summary.road_complexity, "VERY_HIGH")
        self.assertEqual(s.summary.traffic_density, "HIGH")


# ===========================================================================
# 3. Degradation tests (spec §38)
# ===========================================================================

class TestDegradationModes(unittest.TestCase):

    def test_phase61_unavailable(self):
        """Phase 6.1 None → drivable area unavailable; rest present."""
        e = _build_engine()
        _, ls, ra, ctx = _full_state()
        s = e.process(None, ls, ra, ctx)

        self.assertIsNone(s.drivable_area_state)
        self.assertEqual(s.phase61_availability, ModuleAvailability.UNAVAILABLE)
        self.assertIsNotNone(s.lane_structure_state)
        self.assertIsNotNone(s.road_anomaly_state)
        self.assertIsNotNone(s.indian_context_state)
        self.assertTrue(s.degraded)
        self.assertTrue(s.valid)

    def test_phase62_unavailable(self):
        """Phase 6.2 None → lane state unknown, no crash."""
        e = _build_engine()
        da, _, ra, ctx = _full_state()
        s = e.process(da, None, ra, ctx)

        self.assertEqual(s.phase62_availability, ModuleAvailability.UNAVAILABLE)
        self.assertIsNone(s.lane_structure_state)
        self.assertTrue(s.valid)

    def test_phase63_unavailable(self):
        """Phase 6.3 None → anomaly state unknown, road understanding continues."""
        e = _build_engine()
        da, ls, _, ctx = _full_state()
        s = e.process(da, ls, None, ctx)

        self.assertEqual(s.phase63_availability, ModuleAvailability.UNAVAILABLE)
        self.assertIsNone(s.road_anomaly_state)
        self.assertEqual(s.summary.road_surface_quality, NOT_AVAILABLE)
        self.assertEqual(s.summary.anomaly_count, 0)
        self.assertTrue(s.valid)

    def test_phase64_unavailable(self):
        """Phase 6.4 None → raw road-understanding states remain usable."""
        e = _build_engine()
        da, ls, ra, _ = _full_state()
        s = e.process(da, ls, ra, None)

        self.assertEqual(s.phase64_availability, ModuleAvailability.UNAVAILABLE)
        self.assertIsNone(s.indian_context_state)
        self.assertIsNotNone(s.drivable_area_state)
        self.assertTrue(s.valid)

    def test_all_unavailable(self):
        """All None → UNAVAILABLE, valid=False, degraded=True."""
        e = _build_engine()
        s = e.process()

        self.assertEqual(s.status, UnifiedStatus.UNAVAILABLE)
        self.assertFalse(s.valid)
        self.assertTrue(s.degraded)

    def test_degraded_module_propagates(self):
        """A DEGRADED upstream module causes unified state.degraded=True."""
        e = _build_engine()
        da, ls, ra, ctx = _full_state()
        da.status = _RUSStatus.DEGRADED
        s = e.process(da, ls, ra, ctx)

        self.assertTrue(s.degraded)
        self.assertIn(s.phase61_availability, (ModuleAvailability.DEGRADED, ModuleAvailability.OK))

    def test_camera_unavailable(self):
        """Camera sensor unavailable → degraded propagated through sensor summary."""
        e = _build_engine()
        da, ls, ra, ctx = _full_state()
        da.sensor_status = {"camera": "UNAVAILABLE", "lidar": "OK"}
        ls.sensor_status = {"camera": "UNAVAILABLE"}
        s = e.process(da, ls, ra, ctx)

        self.assertFalse(s.sensor_availability.camera_available)
        self.assertTrue(s.sensor_availability.lidar_available)

    def test_lidar_unavailable(self):
        """LiDAR sensor unavailable → degraded."""
        e = _build_engine()
        da, ls, ra, ctx = _full_state()
        da.sensor_status = {"camera": "OK", "lidar": "UNAVAILABLE"}
        s = e.process(da, ls, ra, ctx)

        self.assertFalse(s.sensor_availability.lidar_available)


# ===========================================================================
# 4. Timestamp tests (spec §39)
# ===========================================================================

class TestTimestampValidation(unittest.TestCase):

    def test_identical_timestamps_consistent(self):
        e = _build_engine()
        da, ls, ra, ctx = _full_state()
        s = e.process(da, ls, ra, ctx)
        self.assertEqual(s.consistency.timestamp_consistency, TimestampConsistency.CONSISTENT)

    def test_small_skew_acceptable(self):
        e = _build_engine()
        da, ls, ra, ctx = _full_state()
        ls.timestamp = da.timestamp + 0.1  # 100ms skew, acceptable
        s = e.process(da, ls, ra, ctx)
        self.assertIn(s.consistency.timestamp_consistency,
                      (TimestampConsistency.CONSISTENT, TimestampConsistency.ACCEPTABLE))

    def test_large_skew_stale(self):
        e = _build_engine()
        da, ls, ra, ctx = _full_state()
        ls.timestamp = da.timestamp + 2.0   # 2 seconds → stale
        s = e.process(da, ls, ra, ctx)
        self.assertEqual(s.consistency.timestamp_consistency, TimestampConsistency.STALE)
        self.assertGreater(s.overall_uncertainty, 0.0)

    def test_missing_timestamp(self):
        e = _build_engine()
        da, ls, ra, ctx = _full_state()
        da.timestamp = 0.0
        ls.timestamp = 0.0
        ra.timestamp = 0.0
        ctx.timestamp = 0.0
        s = e.process(da, ls, ra, ctx)
        self.assertIn(s.consistency.timestamp_consistency,
                      (TimestampConsistency.MISSING, TimestampConsistency.INVALID))

    def test_single_module_no_timestamp_conflict(self):
        """Only one module → no skew check needed."""
        e = _build_engine()
        da = _DrivableArea()
        s = e.process(drivable_area=da)
        self.assertIn(s.consistency.timestamp_consistency,
                      (TimestampConsistency.CONSISTENT, TimestampConsistency.MISSING))


# ===========================================================================
# 5. Frame consistency tests (spec §40)
# ===========================================================================

class TestFrameConsistency(unittest.TestCase):

    def test_same_frame_id_no_warning(self):
        e = _build_engine()
        da, ls, ra, ctx = _full_state()
        s = e.process(da, ls, ra, ctx)
        self.assertNotIn("Frame ID mismatch", " ".join(s.warnings))

    def test_mismatched_frame_id_warning(self):
        e = _build_engine()
        da, ls, ra, ctx = _full_state()
        ls.frame_id = 999
        s = e.process(da, ls, ra, ctx)
        self.assertIn(s.consistency.geometry_consistency,
                      (GeometryConsistency.WARNING, GeometryConsistency.CONFLICT))


# ===========================================================================
# 6. Confidence tests (spec §41)
# ===========================================================================

class TestConfidenceAggregation(unittest.TestCase):

    def test_all_high_confidence(self):
        e = _build_engine()
        da, ls, ra, ctx = _full_state()
        da.confidence = ls.confidence = ra.overall_confidence = ctx.confidence = 0.95
        s = e.process(da, ls, ra, ctx)
        self.assertGreater(s.overall_confidence, 0.7)

    def test_one_low_confidence(self):
        e = _build_engine()
        da, ls, ra, ctx = _full_state()
        ls.confidence = 0.1
        s_high = e.process(*_full_state())
        s_low = e.process(da, ls, ra, ctx)
        self.assertLessEqual(s_low.overall_confidence, s_high.overall_confidence)

    def test_missing_module_lowers_confidence(self):
        e = _build_engine()
        da, ls, ra, ctx = _full_state()
        s_full = e.process(da, ls, ra, ctx)
        s_partial = e.process(da, None, ra, ctx)
        self.assertLessEqual(s_partial.overall_confidence, s_full.overall_confidence)

    def test_confidence_in_range(self):
        e = _build_engine()
        for _ in range(5):
            da, ls, ra, ctx = _full_state()
            s = e.process(da, ls, ra, ctx)
            self.assertGreaterEqual(s.overall_confidence, 0.0)
            self.assertLessEqual(s.overall_confidence, 1.0)

    def test_all_unavailable_zero_confidence(self):
        e = _build_engine()
        s = e.process()
        self.assertEqual(s.overall_confidence, 0.0)


# ===========================================================================
# 7. Uncertainty tests (spec §42)
# ===========================================================================

class TestUncertaintyPropagation(unittest.TestCase):

    def test_complete_info_low_uncertainty(self):
        e = _build_engine()
        da, ls, ra, ctx = _full_state()
        da.uncertainty = ls.uncertainty = ra.overall_uncertainty = ctx.uncertainty = 0.1
        s = e.process(da, ls, ra, ctx)
        self.assertLess(s.overall_uncertainty, 0.6)

    def test_sensor_degradation_increases_uncertainty(self):
        e = _build_engine()
        da, ls, ra, ctx = _full_state()
        s_ok = e.process(da, ls, ra, ctx)
        da.status = _RUSStatus.DEGRADED
        s_deg = e.process(da, ls, ra, ctx)
        self.assertGreaterEqual(s_deg.overall_uncertainty, s_ok.overall_uncertainty)

    def test_timestamp_skew_increases_uncertainty(self):
        e = _build_engine()
        da, ls, ra, ctx = _full_state()
        s_ok = e.process(da, ls, ra, ctx)
        ls.timestamp = da.timestamp + 2.0
        s_stale = e.process(da, ls, ra, ctx)
        self.assertGreater(s_stale.overall_uncertainty, s_ok.overall_uncertainty)

    def test_missing_module_increases_uncertainty(self):
        e = _build_engine()
        da, ls, ra, ctx = _full_state()
        s_full = e.process(da, ls, ra, ctx)
        s_partial = e.process(da, None, ra, ctx)
        self.assertGreaterEqual(s_partial.overall_uncertainty, s_full.overall_uncertainty)

    def test_uncertainty_not_negative(self):
        e = _build_engine()
        s = e.process()
        self.assertGreaterEqual(s.overall_uncertainty, 0.0)

    def test_uncertainty_not_simple_inverse(self):
        """Uncertainty must not simply be 1 - confidence."""
        e = _build_engine()
        da, ls, ra, ctx = _full_state()
        s = e.process(da, ls, ra, ctx)
        # If both are 1.0 or exactly complementary, that is suspicious
        self.assertFalse(
            abs(s.overall_confidence + s.overall_uncertainty - 1.0) < 0.001,
            "overall_uncertainty appears to be 1 - overall_confidence, which is disallowed."
        )


# ===========================================================================
# 8. Consistency checks (spec §43)
# ===========================================================================

class TestConsistencyChecks(unittest.TestCase):

    def test_valid_road_lane_geometry_no_conflict(self):
        e = _build_engine()
        da, ls, ra, ctx = _full_state()
        s = e.process(da, ls, ra, ctx)
        self.assertFalse(s.consistency.road_width_conflict)

    def test_lane_count_too_many_for_road_width(self):
        """4 lanes at 6m road → implies ≥6m minimum → conflict."""
        e = _build_engine()
        da, ls, ra, ctx = _full_state()
        da.road_width_profile = [_WidthSample(5.0, 4.0)]   # 4m road
        ls.lane_count = 4   # implies ≥6m needed
        s = e.process(da, ls, ra, ctx)
        self.assertTrue(s.consistency.road_width_conflict)
        self.assertIn(s.consistency.geometry_consistency,
                      (GeometryConsistency.CONFLICT, GeometryConsistency.WARNING))

    def test_marking_state_conflict_ls_marked_ctx_unmarked(self):
        e = _build_engine()
        da, ls, ra, ctx = _full_state()
        ls.marking_status = _MarkingStatus.MARKED
        ctx.road_marking_state = _RMS.UNMARKED
        s = e.process(da, ls, ra, ctx)
        self.assertTrue(s.consistency.marking_state_conflict)

    def test_nan_anomaly_geometry_flagged(self):
        e = _build_engine()
        da, ls, _, ctx = _full_state()

        class _BadGeom:
            center_x_m = float("nan"); center_y_m = 1.0

        class _Sev(str, Enum): LOW = "LOW"
        class _DAR(str, Enum): OUTSIDE_DRIVABLE_AREA = "OUTSIDE_DRIVABLE_AREA"

        class _BadAnomaly:
            severity = _Sev.LOW
            drivable_area_relation = _DAR.OUTSIDE_DRIVABLE_AREA
            geometry = _BadGeom()

        ra = _RoadAnomalyState(anomalies=[_BadAnomaly()])
        s = e.process(da, ls, ra, ctx)
        self.assertTrue(s.consistency.anomaly_frame_conflict)

    def test_upstream_data_not_mutated(self):
        """Consistency checks must never modify upstream state objects."""
        e = _build_engine()
        da, ls, ra, ctx = _full_state()
        orig_da_conf = da.confidence
        orig_ls_lane_count = ls.lane_count
        e.process(da, ls, ra, ctx)
        self.assertEqual(da.confidence, orig_da_conf)
        self.assertEqual(ls.lane_count, orig_ls_lane_count)


# ===========================================================================
# 9. Determinism tests (spec §44)
# ===========================================================================

class TestDeterminism(unittest.TestCase):

    def test_same_input_same_output(self):
        e = _build_engine()
        da, ls, ra, ctx = _full_state()
        results = []
        for _ in range(5):
            s = e.process(
                copy.deepcopy(da), copy.deepcopy(ls),
                copy.deepcopy(ra), copy.deepcopy(ctx)
            )
            results.append(s.to_dict())

        # All dicts should be equal (except created_at which is time-based)
        for r in results:
            r.pop("metadata", None)
        first = results[0]
        for r in results[1:]:
            self.assertEqual(r["status"], first["status"])
            self.assertEqual(r["overall_confidence"], first["overall_confidence"])
            self.assertEqual(r["overall_uncertainty"], first["overall_uncertainty"])
            self.assertEqual(r["summary"], first["summary"])
            self.assertEqual(r["consistency"], first["consistency"])

    def test_deterministic_with_all_none(self):
        e = _build_engine()
        results = [e.process().to_dict() for _ in range(3)]
        for r in results:
            self.assertEqual(r["status"], UnifiedStatus.UNAVAILABLE.value)
            self.assertEqual(r["overall_confidence"], 0.0)

    def test_state_version_constant(self):
        e = _build_engine()
        for _ in range(3):
            s = e.process()
            self.assertEqual(s.state_version, STATE_VERSION)


# ===========================================================================
# 10. Serialization round-trip (spec §45)
# ===========================================================================

class TestSerialization(unittest.TestCase):

    def test_to_dict_returns_dict(self):
        e = _build_engine()
        da, ls, ra, ctx = _full_state()
        s = e.process(da, ls, ra, ctx)
        d = s.to_dict()
        self.assertIsInstance(d, dict)

    def test_to_dict_has_required_keys(self):
        e = _build_engine()
        s = e.process()
        d = s.to_dict()
        for key in ("state_version", "timestamp", "frame_id", "status",
                    "degraded", "valid", "overall_confidence", "overall_uncertainty",
                    "summary", "consistency", "module_availability",
                    "sensor_availability", "provenance", "warnings"):
            self.assertIn(key, d, f"Missing key: {key}")

    def test_from_dict_round_trip(self):
        e = _build_engine()
        da, ls, ra, ctx = _full_state()
        s = e.process(da, ls, ra, ctx)
        d = s.to_dict()
        s2 = RoadUnderstandingState.from_dict(d)
        self.assertEqual(s.state_version, s2.state_version)
        self.assertAlmostEqual(s.overall_confidence, s2.overall_confidence, places=3)
        self.assertAlmostEqual(s.overall_uncertainty, s2.overall_uncertainty, places=3)
        self.assertEqual(s.status, s2.status)
        self.assertEqual(s.valid, s2.valid)
        self.assertEqual(s.degraded, s2.degraded)

    def test_serialization_with_none_modules(self):
        e = _build_engine()
        s = e.process()
        d = s.to_dict()
        self.assertEqual(d["drivable_area"], NOT_AVAILABLE)
        self.assertEqual(d["lane_structure"], NOT_AVAILABLE)

    def test_serialization_no_nan_inf(self):
        e = _build_engine()
        da, ls, ra, ctx = _full_state()
        s = e.process(da, ls, ra, ctx)
        d = s.to_dict()
        import json
        # Should be JSON-serializable without NaN
        serialised = json.dumps(d)
        self.assertNotIn("NaN", serialised)
        self.assertNotIn("Infinity", serialised)


# ===========================================================================
# 11. No raw sensor data leakage (spec §46)
# ===========================================================================

class TestNoRawSensorData(unittest.TestCase):

    def test_no_raw_point_cloud_in_state(self):
        """RoadUnderstandingState must not contain raw sensor arrays."""
        e = _build_engine()
        da, ls, ra, ctx = _full_state()

        # Attach a fake large array to simulate raw sensor data on upstream object
        da.raw_lidar_points = list(range(10000))

        s = e.process(da, ls, ra, ctx)
        d = s.to_dict()
        # The dict should not contain the raw lidar points
        import json
        serialised = json.dumps(d, default=str)
        # raw_lidar_points has 10000 integers; its presence would make the
        # string very long and contain those values
        self.assertNotIn("raw_lidar_points", serialised)

    def test_state_dict_is_compact(self):
        """Serialised state should not be excessively large."""
        e = _build_engine()
        da, ls, ra, ctx = _full_state()
        s = e.process(da, ls, ra, ctx)
        import json
        serialised = json.dumps(s.to_dict(), default=str)
        # Should be under 64KB (generous for structured data, very small vs raw sensors)
        self.assertLess(len(serialised.encode("utf-8")), 64 * 1024)


# ===========================================================================
# 12. API surface (spec §31)
# ===========================================================================

class TestAPIDesign(unittest.TestCase):

    def test_process_method(self):
        e = _build_engine()
        da, ls, ra, ctx = _full_state()
        s = e.process(da, ls, ra, ctx)
        self.assertIsInstance(s, RoadUnderstandingState)

    def test_build_state_alias(self):
        e = _build_engine()
        da, ls, ra, ctx = _full_state()
        s = e.build_state(da, ls, ra, ctx)
        self.assertIsInstance(s, RoadUnderstandingState)

    def test_get_snapshot_alias(self):
        e = _build_engine()
        da, ls, ra, ctx = _full_state()
        s = e.get_snapshot(da, ls, ra, ctx)
        self.assertIsInstance(s, RoadUnderstandingState)

    def test_validate_state(self):
        e = _build_engine()
        da, ls, ra, ctx = _full_state()
        s = e.process(da, ls, ra, ctx)
        errors = e.validate_state(s)
        self.assertEqual(errors, [])

    def test_validate_state_detects_wrong_version(self):
        e = _build_engine()
        s = e.process()
        s.state_version = "0.0"
        errors = e.validate_state(s)
        self.assertTrue(len(errors) > 0)

    def test_reset_noop(self):
        e = _build_engine()
        e.reset()   # should not raise
        s = e.process()
        self.assertIsInstance(s, RoadUnderstandingState)

    def test_independent_instances(self):
        e1 = _build_engine()
        e2 = _build_engine()
        da, ls, ra, ctx = _full_state()
        s1 = e1.process(da, ls, ra, ctx)
        s2 = e2.process(da, ls, ra, ctx)
        self.assertEqual(s1.state_version, s2.state_version)
        self.assertAlmostEqual(s1.overall_confidence, s2.overall_confidence, places=3)

    def test_check_consistency_method(self):
        e = _build_engine()
        s = e.process()
        cr = e.check_consistency(s)
        self.assertIsNotNone(cr)

    def test_aggregate_confidence_method(self):
        e = _build_engine()
        da, ls, ra, ctx = _full_state()
        conf = e.aggregate_confidence(da, ls, ra, ctx)
        self.assertGreaterEqual(conf, 0.0)
        self.assertLessEqual(conf, 1.0)

    def test_aggregate_uncertainty_method(self):
        e = _build_engine()
        da, ls, ra, ctx = _full_state()
        unc = e.aggregate_uncertainty(da, ls, ra, ctx)
        self.assertGreaterEqual(unc, 0.0)


# ===========================================================================
# 13. Snapshot immutability (spec §27)
# ===========================================================================

class TestSnapshotImmutability(unittest.TestCase):

    def test_mutating_original_does_not_affect_snapshot(self):
        """Changing an upstream object after process() must not mutate the snapshot."""
        e = _build_engine()
        da, ls, ra, ctx = _full_state()
        s = e.process(da, ls, ra, ctx)

        original_conf = s.drivable_area_state.confidence
        da.confidence = 0.0   # mutate original

        # Snapshot should be unaffected
        self.assertAlmostEqual(s.drivable_area_state.confidence, original_conf, places=3)


# ===========================================================================
# 14. Configuration (spec §52)
# ===========================================================================

class TestConfiguration(unittest.TestCase):

    def test_custom_timestamp_tolerance(self):
        cfg = RoadUnderstandingStateConfig(max_timestamp_skew_seconds=0.1)
        e = RoadUnderstandingEngine(cfg)
        da, ls, ra, ctx = _full_state()
        ls.timestamp = da.timestamp + 0.15  # just over 0.1s → stale
        s = e.process(da, ls, ra, ctx)
        self.assertEqual(s.consistency.timestamp_consistency, TimestampConsistency.STALE)

    def test_custom_weight_config(self):
        cfg = RoadUnderstandingStateConfig(
            weight_drivable_area=0.5,
            weight_lane_structure=0.25,
            weight_road_anomaly=0.15,
            weight_indian_context=0.10,
        )
        e = RoadUnderstandingEngine(cfg)
        da, ls, ra, ctx = _full_state()
        s = e.process(da, ls, ra, ctx)
        self.assertGreater(s.overall_confidence, 0.0)

    def test_config_from_dict(self):
        d = {"max_timestamp_skew_seconds": 1.0, "weight_drivable_area": 0.4}
        cfg = RoadUnderstandingStateConfig.from_dict(d)
        self.assertAlmostEqual(cfg.max_timestamp_skew_seconds, 1.0)
        self.assertAlmostEqual(cfg.weight_drivable_area, 0.4)

    def test_config_to_dict(self):
        cfg = RoadUnderstandingStateConfig()
        d = cfg.to_dict()
        self.assertIn("max_timestamp_skew_seconds", d)
        self.assertIn("weight_drivable_area", d)


# ===========================================================================
# 15. Imports and package integration
# ===========================================================================

class TestPackageIntegration(unittest.TestCase):

    def test_package_imports(self):
        from core.perception import (
            RoadUnderstandingEngine,
            RoadUnderstandingState,
            RoadUnderstandingStateConfig,
            UnifiedStatus,
            ModuleAvailability,
        )
        self.assertTrue(callable(RoadUnderstandingEngine))

    def test_state_version_in_package(self):
        from core.perception import STATE_VERSION
        self.assertEqual(STATE_VERSION, "6.5")


if __name__ == "__main__":
    unittest.main(verbosity=2)
