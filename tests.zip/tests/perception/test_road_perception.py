import sys
from pathlib import Path

import numpy as np
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))

from core.perception.road_perception import RoadPerceptionPipeline
from core.perception.perception_types import NOT_AVAILABLE, BackendKind


def test_drivable_area_schema_present_on_valid_image():
    pipe = RoadPerceptionPipeline(backend="CLASSICAL")
    img = np.full((240, 320, 3), 120, dtype=np.uint8)  # flat gray "road"
    result = pipe.process(img)
    assert result.status == "OK"
    assert result.drivable_area.drivable_mask_available is True
    assert result.drivable_area.drivable_mask_shape == (240, 320)
    assert result.drivable_area.backend == BackendKind.BASELINE


def test_lane_marking_unavailable_is_a_valid_state():
    pipe = RoadPerceptionPipeline(backend="CLASSICAL")
    img = np.full((100, 100, 3), 100, dtype=np.uint8)
    result = pipe.process(img)
    assert result.road_state.lane_marking == NOT_AVAILABLE


def test_segmentation_backend_without_model_is_not_configured():
    pipe = RoadPerceptionPipeline(backend="SEGMENTATION")
    img = np.zeros((50, 50, 3), dtype=np.uint8)
    result = pipe.process(img)
    assert result.status == "NOT_CONFIGURED"


def test_disabled_road_perception_reports_not_configured():
    pipe = RoadPerceptionPipeline(backend="NONE")
    img = np.zeros((50, 50, 3), dtype=np.uint8)
    result = pipe.process(img)
    assert result.status == "NOT_CONFIGURED"


def test_road_anomaly_schema_honest_not_configured():
    from core.perception.anomaly_detection import RoadAnomalyDetector
    det = RoadAnomalyDetector(backend="NOT_CONFIGURED")
    result = det.process(np.zeros((10, 10, 3), dtype=np.uint8), timestamp=0.0)
    assert result.status == "NOT_CONFIGURED"
    assert result.anomalies == []


def test_road_anomaly_real_backend_without_weights_falls_back_honestly():
    from core.perception.anomaly_detection import RoadAnomalyDetector
    det = RoadAnomalyDetector(backend="REAL", model_path="models/perception/road_damage/does_not_exist.pt")
    assert det.backend == "NOT_CONFIGURED"
    assert det.is_ready() is False
