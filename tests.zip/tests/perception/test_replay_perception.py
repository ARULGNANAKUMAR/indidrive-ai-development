"""Recorded camera + LiDAR replay -> perception, proving the perception
layer works fully offline against Phase 1's recorder/replay without any
live sensor or CARLA server."""
import sys
import tempfile
from pathlib import Path

import numpy as np
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))

from core.carla_integration.sensor_recorder import SensorRecorder
from core.carla_integration.sensor_replay import OfflineSensorReplay
from core.carla_integration.sensor_types import CameraFrame, LiDARFrame, Timestamp

from core.perception.perception_manager import PerceptionManager
from core.perception.object_detection import MockBackend


def _cam_frame(fid):
    img = np.full((32, 32, 3), fill_value=fid % 255, dtype=np.uint8)
    return CameraFrame(sensor_id="cam", frame_id=fid, timestamp=Timestamp(sensor_time=float(fid)),
                        sequence_number=fid, payload=None, width=32, height=32, channels=3, image=img)


def _lidar_frame(fid):
    pts = np.random.default_rng(fid).uniform(-10, 10, size=(50, 4)).astype(np.float32)
    pts[:, 3] = np.abs(pts[:, 3])
    return LiDARFrame(sensor_id="lidar", frame_id=fid, timestamp=Timestamp(sensor_time=float(fid)),
                       sequence_number=fid, payload=None, point_count=50, dimensions=4, points=pts)


def test_recorded_camera_replay_through_perception():
    with tempfile.TemporaryDirectory() as tmp:
        rec = SensorRecorder(base_dir=Path(tmp))
        rec.start()
        for i in range(3):
            rec.write_frame(_cam_frame(i))
        rec.stop()

        replay = OfflineSensorReplay(rec.session_dir)
        frames = replay.load_frames("cam")

        mgr = PerceptionManager()
        mgr.initialize()
        mgr.engine.camera._detector = MockBackend(n_detections=1)
        mgr.engine.camera._detector.load_model()

        results = [mgr.process_frame(camera_image=f.image, camera_timestamp=f.timestamp.sensor_time)
                   for f in frames]
        assert len(results) == 3
        assert all(r.quality.frame_valid for r in results)
        assert all(len(r.objects) == 1 for r in results)  # MockBackend is deterministic


def test_recorded_lidar_replay_through_perception():
    with tempfile.TemporaryDirectory() as tmp:
        rec = SensorRecorder(base_dir=Path(tmp))
        rec.start()
        for i in range(3):
            rec.write_frame(_lidar_frame(i))
        rec.stop()

        replay = OfflineSensorReplay(rec.session_dir)
        frames = replay.load_frames("lidar")

        mgr = PerceptionManager()
        results = [mgr.process_frame(lidar_points=f.points, lidar_timestamp=f.timestamp.sensor_time)
                   for f in frames]
        assert len(results) == 3
        for r in results:
            assert r.processing_metrics.total_perception_latency_ms >= 0.0


def test_perception_never_requires_network_access():
    """Sanity check that nothing in the perception import chain reaches
    for a network client at import/construction time."""
    import socket
    original_socket = socket.socket

    def _blocked(*a, **k):
        raise AssertionError("perception layer attempted to open a network socket")

    socket.socket = _blocked
    try:
        mgr = PerceptionManager()
        mgr.initialize()
        mgr.process_frame()
    finally:
        socket.socket = original_socket
