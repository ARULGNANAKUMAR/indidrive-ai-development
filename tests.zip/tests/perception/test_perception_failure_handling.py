"""The perception layer must fail safely: a missing model, a corrupt
image, an empty point cloud, or a missing sensor must never crash the
caller — each must report an honest status instead."""
import sys
from pathlib import Path

import numpy as np
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))

from core.perception.camera_perception import CameraPerceptionPipeline
from core.perception.lidar_perception import LiDARPerceptionPipeline
from core.perception.perception_manager import PerceptionManager
from core.perception.object_detection import resolve_backend, ModelNotFoundError, UltralyticsYOLOBackend


def test_model_missing_reports_model_not_found_not_a_crash():
    pipe = CameraPerceptionPipeline(backend="YOLO", backend_config={"weights_path": "does/not/exist.pt"})
    img = np.zeros((64, 64, 3), dtype=np.uint8)
    result = pipe.process(img, timestamp=0.0)
    assert result.status in ("MODEL_NOT_FOUND", "OK")  # OK only if it fell back to NONE gracefully
    assert result.objects == []


def test_sensor_missing_process_frame_does_not_raise():
    mgr = PerceptionManager()
    frame = mgr.process_frame(camera_image=None, lidar_points=None)
    assert frame.objects == []
    assert frame.quality.detection_count == 0


def test_invalid_frame_camera_corrupt_image_does_not_raise():
    pipe = CameraPerceptionPipeline(backend="NONE")
    corrupt = np.zeros((10, 10), dtype=np.uint8)  # missing channel dim
    result = pipe.process(corrupt, timestamp=0.0)
    assert result.status == "INVALID_FRAME"


def test_empty_lidar_does_not_raise():
    pipe = LiDARPerceptionPipeline()
    result = pipe.process(np.zeros((0, 4), dtype=np.float32), timestamp=0.0)
    assert result.status == "EMPTY_POINT_CLOUD"
    assert result.objects == []


def test_yolo_backend_missing_weights_raises_model_not_found_not_generic_error():
    backend = UltralyticsYOLOBackend(weights_path="/nonexistent/path/weights.pt")
    with pytest.raises(ModelNotFoundError):
        backend.load_model()


def test_resolve_backend_unknown_name_falls_back_to_none():
    backend = resolve_backend("SOME_UNKNOWN_BACKEND")
    assert backend.is_ready() is False
    assert backend.get_model_info().backend_kind.value == "NOT_CONFIGURED"
