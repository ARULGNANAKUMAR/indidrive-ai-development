"""Data-contract tests: PerceptionObject / PerceptionFrame schema and
'unavailable' states never get silently fabricated."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))

from core.perception.perception_types import (
    PerceptionObject, PerceptionFrame, BoundingBox2D, Position3D, Dimensions3D,
    SourceSensor, BackendKind, RoadState, DrivableArea, NOT_AVAILABLE,
)


def test_object_schema_camera_only():
    obj = PerceptionObject(
        object_id="camera_001", object_class="pedestrian", raw_class="person",
        confidence=0.91, raw_confidence=0.91, source_sensor=SourceSensor.CAMERA,
        timestamp=0.0, bbox_2d=BoundingBox2D(412, 180, 62, 155), tracking_ready=True,
        backend=BackendKind.MOCK,
    )
    d = obj.to_dict()
    assert d["class"] == "pedestrian"
    assert d["bbox_2d"] == {"x": 412, "y": 180, "width": 62, "height": 155}
    # Fields never measured for a camera-only detection must show NOT_AVAILABLE, not 0/None-as-real-value.
    assert d["position_3d"] == NOT_AVAILABLE
    assert d["distance"] == NOT_AVAILABLE
    assert d["velocity"] == NOT_AVAILABLE


def test_object_schema_lidar_object_has_3d_fields():
    obj = PerceptionObject(
        object_id="lidar_001", object_class="unknown", raw_class="cluster",
        confidence=0.6, raw_confidence=0.6, source_sensor=SourceSensor.LIDAR,
        timestamp=1.0, position_3d=Position3D(1.0, 2.0, 0.5),
        dimensions_3d=Dimensions3D(1.5, 1.0, 1.2), distance=2.24, point_count=42,
        backend=BackendKind.BASELINE,
    )
    d = obj.to_dict()
    assert d["position_3d"] == {"x": 1.0, "y": 2.0, "z": 0.5}
    assert d["point_count"] == 42
    assert d["bbox_2d"] is None  # LiDAR-only object correctly has no 2D box


def test_invalid_detection_never_fabricates_bbox():
    # An object with no bbox at all must serialize bbox_2d as None, not a fake zero-box.
    obj = PerceptionObject(
        object_id="x", object_class="unknown", raw_class="cluster",
        confidence=0.1, raw_confidence=0.1, source_sensor=SourceSensor.LIDAR, timestamp=0.0,
    )
    assert obj.to_dict()["bbox_2d"] is None


def test_perception_frame_schema_roundtrip():
    frame = PerceptionFrame(timestamp=123.45, frame_id=1024)
    d = frame.to_dict()
    for key in ("timestamp", "frame_id", "objects", "road_state", "drivable_area",
                "road_anomalies", "sensor_status", "processing_metrics", "quality", "warnings"):
        assert key in d
    assert d["objects"] == []
    assert d["road_anomalies"] == []


def test_road_state_unmarked_road_is_valid_state():
    rs = RoadState(road_present=True, road_confidence=0.7)
    assert rs.lane_marking == NOT_AVAILABLE
    assert rs.to_dict()["lane_marking"] == NOT_AVAILABLE


def test_drivable_area_mask_excluded_from_dict():
    import numpy as np
    da = DrivableArea(drivable_mask_available=True, drivable_mask_shape=(10, 10),
                       mask=np.zeros((10, 10), dtype="uint8"))
    d = da.to_dict()
    assert "mask" not in d
    assert d["drivable_mask_shape"] == [10, 10]
