"""Camera perception: validation, bbox clipping, confidence filtering,
NMS, and full pipeline behavior with the MockBackend (never hitting a
real model — Phase 2 ships no weights)."""
import sys
from pathlib import Path

import numpy as np
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))

from core.perception.camera_perception import CameraPerceptionPipeline
from core.perception.object_detection import MockBackend, NoneBackend
from core.perception.confidence import RawDetection, filter_by_confidence, non_max_suppression, validate_and_clip_boxes
from core.perception.perception_types import BoundingBox2D, BackendKind


def _pipeline_with_mock(**kwargs) -> CameraPerceptionPipeline:
    pipe = CameraPerceptionPipeline(backend="NONE", **kwargs)
    pipe._detector = MockBackend(n_detections=2)
    pipe._detector.load_model()
    return pipe


def test_camera_pipeline_none_backend_is_not_configured():
    pipe = CameraPerceptionPipeline(backend="NONE")
    img = np.zeros((100, 100, 3), dtype=np.uint8)
    result = pipe.process(img, timestamp=0.0)
    assert result.objects == []
    assert pipe.backend_kind == BackendKind.NOT_CONFIGURED


def test_invalid_image_rejected():
    pipe = _pipeline_with_mock()
    result = pipe.process(None, timestamp=0.0)
    assert result.status == "INVALID_FRAME"
    assert result.objects == []

    bad_dtype = np.zeros((10, 10, 3), dtype=np.float32)
    result2 = pipe.process(bad_dtype, timestamp=0.0)
    assert result2.status == "INVALID_FRAME"


def test_camera_perception_produces_normalized_objects():
    pipe = _pipeline_with_mock(confidence_threshold=0.0, nms_threshold=0.99)
    img = np.zeros((480, 640, 3), dtype=np.uint8)
    result = pipe.process(img, timestamp=5.0)
    assert result.status == "OK"
    assert len(result.objects) == 2
    classes = {o.object_class for o in result.objects}
    # MockBackend emits 'car' and 'person' -> normalized to 'car'/'pedestrian'.
    assert "car" in classes
    assert "pedestrian" in classes
    for o in result.objects:
        assert o.backend == BackendKind.MOCK
        assert o.source_sensor.value == "camera"
        assert 0.0 <= o.confidence <= 1.0


def test_confidence_filter():
    dets = [
        RawDetection("car", 0.9, BoundingBox2D(0, 0, 10, 10)),
        RawDetection("car", 0.2, BoundingBox2D(0, 0, 10, 10)),
    ]
    kept = filter_by_confidence(dets, threshold=0.5)
    assert len(kept) == 1 and kept[0].raw_confidence == 0.9


def test_nms_suppresses_overlapping_same_class():
    dets = [
        RawDetection("car", 0.9, BoundingBox2D(0, 0, 100, 100)),
        RawDetection("car", 0.8, BoundingBox2D(5, 5, 100, 100)),   # heavy overlap -> suppressed
        RawDetection("pedestrian", 0.7, BoundingBox2D(200, 200, 20, 20)),  # different class -> kept
    ]
    kept = non_max_suppression(dets, iou_threshold=0.3)
    assert len(kept) == 2
    kept_classes = sorted(d.raw_class for d in kept)
    assert kept_classes == ["car", "pedestrian"]


def test_bbox_clipping_drops_out_of_bounds_garbage():
    dets = [
        RawDetection("car", 0.9, BoundingBox2D(-50, -50, 10, 10)),   # fully out of bounds after clip -> may survive clipped
        RawDetection("car", 0.9, BoundingBox2D(1000, 1000, 10, 10)),  # fully outside -> dropped
        RawDetection("car", 0.9, BoundingBox2D(10, 10, 20, 20)),      # normal -> kept unchanged
    ]
    valid = validate_and_clip_boxes(dets, img_width=100, img_height=100)
    assert all(0 <= d.bbox.x <= 100 and 0 <= d.bbox.y <= 100 for d in valid)
    assert all(d.bbox.width > 0 and d.bbox.height > 0 for d in valid)


def test_none_backend_reports_not_configured_info():
    backend = NoneBackend(reason="test")
    info = backend.get_model_info()
    assert info.backend_kind == BackendKind.NOT_CONFIGURED
    assert backend.is_ready() is False
    assert backend.detect(np.zeros((5, 5, 3), dtype=np.uint8)) == []
