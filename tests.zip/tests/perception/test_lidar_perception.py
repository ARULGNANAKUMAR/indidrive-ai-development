"""LiDAR perception: NaN/Inf removal, range/height filtering, ground
removal, and cluster generation, using synthetic point clouds (no
CARLA / real sensor required)."""
import sys
from pathlib import Path

import numpy as np
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))

from core.perception.lidar_perception import LiDARPerceptionPipeline, LiDARPerceptionConfig


def _ground_plane(n=200, extent=20.0, z=0.0, seed=0):
    rng = np.random.default_rng(seed)
    xy = rng.uniform(-extent, extent, size=(n, 2))
    z_col = np.full((n, 1), z) + rng.normal(0, 0.02, size=(n, 1))
    intensity = rng.uniform(0, 1, size=(n, 1))
    return np.hstack([xy, z_col, intensity]).astype(np.float32)


def _obstacle_blob(center=(5.0, 5.0), n=30, spread=0.3, z_base=0.0, height=1.5, seed=1):
    rng = np.random.default_rng(seed)
    xy = center + rng.normal(0, spread, size=(n, 2))
    z = rng.uniform(z_base, z_base + height, size=(n, 1))
    intensity = rng.uniform(0, 1, size=(n, 1))
    return np.hstack([xy, z, intensity]).astype(np.float32)


def test_nan_and_inf_removal():
    pts = _ground_plane(n=50)
    pts[0, 0] = np.nan
    pts[1, 2] = np.inf
    pipe = LiDARPerceptionPipeline()
    result = pipe.process(pts, timestamp=0.0)
    assert result.status == "OK"
    # The two corrupted points must not survive into ground+obstacle counts.
    assert result.ground_point_count + result.obstacle_point_count <= 48


def test_empty_point_cloud_is_reported_honestly():
    pipe = LiDARPerceptionPipeline()
    result = pipe.process(np.zeros((0, 4), dtype=np.float32), timestamp=0.0)
    assert result.status == "EMPTY_POINT_CLOUD"
    assert result.objects == []


def test_invalid_frame_wrong_shape():
    pipe = LiDARPerceptionPipeline()
    result = pipe.process(np.zeros((10,), dtype=np.float32), timestamp=0.0)
    assert result.status == "INVALID_FRAME"


def test_range_and_height_filter():
    pts = _ground_plane(n=10, extent=1.0)
    far_point = np.array([[500.0, 0.0, 0.0, 1.0]], dtype=np.float32)  # beyond max_range_m
    high_point = np.array([[1.0, 1.0, 50.0, 1.0]], dtype=np.float32)   # beyond max_height_m
    pts = np.vstack([pts, far_point, high_point])
    pipe = LiDARPerceptionPipeline(LiDARPerceptionConfig(max_range_m=80.0, max_height_m=3.5, min_range_m=0.0))
    filtered = pipe._range_height_filter(pipe._clean(pts))
    assert not np.any(np.isclose(filtered[:, 0], 500.0))
    assert not np.any(np.isclose(filtered[:, 2], 50.0))


def test_ground_removal_separates_ground_from_obstacle():
    ground = _ground_plane(n=300, extent=15.0, z=0.0)
    obstacle = _obstacle_blob(center=(5.0, 5.0), n=40, z_base=0.0, height=1.5)
    pts = np.vstack([ground, obstacle])
    pipe = LiDARPerceptionPipeline(LiDARPerceptionConfig(ground_margin_m=0.2, ground_cell_size_m=1.0))
    g, o = pipe._ground_separation(pts)
    # Most ground points should be classified as ground, and the tall obstacle
    # blob should contribute a meaningful share of obstacle points.
    assert g.shape[0] > 200
    assert o.shape[0] > 10


def test_cluster_generation_finds_the_obstacle_blob():
    ground = _ground_plane(n=300, extent=15.0, z=0.0)
    obstacle = _obstacle_blob(center=(5.0, 5.0), n=40, z_base=0.0, height=1.5)
    pts = np.vstack([ground, obstacle])
    pipe = LiDARPerceptionPipeline(LiDARPerceptionConfig(min_cluster_points=4))
    result = pipe.process(pts, timestamp=1.0)
    assert result.status == "OK"
    assert len(result.objects) >= 1
    obj = result.objects[0]
    assert obj.position_3d is not None
    assert obj.dimensions_3d is not None
    assert obj.backend.value == "BASELINE"  # geometry-based, never claimed REAL/ML
