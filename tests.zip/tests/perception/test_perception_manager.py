import sys
import time
from pathlib import Path

import numpy as np
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))

from core.perception.perception_manager import PerceptionManager
from core.perception.perception_engine import PerceptionEngine, EngineConfig
from core.perception.object_detection import MockBackend


def test_perception_manager_initializes_with_default_config():
    mgr = PerceptionManager()
    mgr.initialize()
    assert mgr.engine is not None
    assert mgr.get_latest_perception() is None  # nothing processed yet
    mgr.shutdown()


def test_process_frame_with_no_sensors_is_not_configured_but_does_not_crash():
    mgr = PerceptionManager()
    frame = mgr.process_frame()
    assert frame.objects == []
    assert frame.quality.health.value in ("NOT_CONFIGURED", "DEGRADED")


def test_process_frame_with_camera_and_lidar_populates_perception_frame():
    mgr = PerceptionManager()
    mgr.initialize()
    mgr.engine.camera._detector = MockBackend(n_detections=1)
    mgr.engine.camera._detector.load_model()

    img = np.zeros((480, 640, 3), dtype=np.uint8)
    pts = np.random.default_rng(0).uniform(-5, 5, size=(200, 4)).astype(np.float32)
    pts[:, 3] = np.abs(pts[:, 3])

    frame = mgr.process_frame(camera_image=img, camera_timestamp=time.time(),
                               lidar_points=pts, lidar_timestamp=time.time())
    assert frame.frame_id == 1
    assert any(o.source_sensor.value == "camera" for o in frame.objects)
    assert frame.processing_metrics.total_perception_latency_ms > 0
    assert mgr.get_latest_perception() is frame


def test_perception_frame_history_is_bounded():
    mgr = PerceptionManager(history_size=3)
    mgr.initialize()
    for _ in range(5):
        mgr.process_frame()
    assert len(mgr.get_history()) == 3


def test_get_health_reports_component_states():
    mgr = PerceptionManager()
    mgr.process_frame()  # triggers lazy initialize()
    health = mgr.get_health()
    assert "camera" in health
    assert "radar" in health
    assert health["radar"]["status"] == "NOT_AVAILABLE"


def test_engine_object_ids_are_not_coupled_across_sensors():
    engine = PerceptionEngine(EngineConfig())
    engine.camera._detector = MockBackend(n_detections=2)
    engine.camera._detector.load_model()
    img = np.zeros((100, 100, 3), dtype=np.uint8)
    pts = np.random.default_rng(1).uniform(-5, 5, size=(100, 4)).astype(np.float32)
    frame = engine.process(camera_image=img, camera_timestamp=0.0, lidar_points=pts, lidar_timestamp=0.0)
    ids = [o.object_id for o in frame.objects]
    assert len(ids) == len(set(ids))  # all unique, no collisions across sensors
