"""
IndiDrive AI — Phase 5 test suite.
Run with: PYTHONPATH=. pytest tests/test_phase5.py -v
These exercise the real module logic (dataset dedup, ECHO clustering,
benchmark scoring, report file generation) against a temp storage dir,
not against mocked/faked results.
"""
import json
import shutil
import sys
import tempfile
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))


@pytest.fixture()
def tmp_storage(monkeypatch):
    tmp = Path(tempfile.mkdtemp())
    yield tmp
    shutil.rmtree(tmp, ignore_errors=True)


def test_dataset_create_and_import(tmp_storage):
    from core.dataset.manager import DatasetManager
    mgr = DatasetManager(storage_root=tmp_storage)
    ds = mgr.create_dataset("test_ds")
    assert ds["total_images"] == 0

    # create fake source images
    src_dir = tmp_storage / "src"
    src_dir.mkdir()
    for i in range(5):
        (src_dir / f"img_{i}.jpg").write_bytes(b"fake image data " + str(i).encode())
    # duplicate of img_0
    (src_dir / "dup_of_0.jpg").write_bytes(b"fake image data 0")

    result = mgr.import_files(ds["dataset_id"], [str(src_dir)])
    assert result["added_images"] == 5
    assert result["duplicates_skipped"] == 1

    stats = mgr.stats(ds["dataset_id"])
    assert stats["kind_counts"]["image"] == 5


def test_dataset_split_sums_correctly(tmp_storage):
    from core.dataset.manager import DatasetManager
    mgr = DatasetManager(storage_root=tmp_storage)
    ds = mgr.create_dataset("split_ds")
    src_dir = tmp_storage / "src2"
    src_dir.mkdir()
    for i in range(20):
        (src_dir / f"img_{i}.jpg").write_bytes(f"data-{i}".encode())
    mgr.import_files(ds["dataset_id"], [str(src_dir)])
    splits = mgr.split_dataset(ds["dataset_id"], 0.7, 0.2, 0.1)
    assert sum(splits.values()) == 20


def test_echo_experience_and_clustering(tmp_storage, monkeypatch):
    import core.echo.echo_v2 as echo_mod
    monkeypatch.setattr(echo_mod, "STORAGE_ROOT", tmp_storage)
    monkeypatch.setattr(echo_mod, "EXPERIENCES_PATH", tmp_storage / "experiences.jsonl")
    monkeypatch.setattr(echo_mod, "PATTERNS_PATH", tmp_storage / "patterns.json")
    monkeypatch.setattr(echo_mod, "PRINCIPLES_PATH", tmp_storage / "principles.json")
    monkeypatch.setattr(echo_mod, "CAPABILITIES_PATH", tmp_storage / "capabilities.json")

    echo = echo_mod.EchoV2()
    for i in range(10):
        echo.record_experience(
            scenario="cattle_crossing",
            features={"risk_score": 0.8, "ttc_min": 1.2, "speed": 8, "drivable_frac": 0.6, "lane_count": 1},
            action_taken="BRAKE",
            outcome="near_miss",
        )
    for i in range(10):
        echo.record_experience(
            scenario="highway",
            features={"risk_score": 0.1, "ttc_min": 10, "speed": 22, "drivable_frac": 0.95, "lane_count": 3},
            action_taken="CONTINUE",
            outcome="safe",
        )
    patterns = echo.cluster_patterns(k=2)
    assert len(patterns) == 2
    principles = echo.promote_principles(min_support=3, min_consistency=0.5)
    assert len(principles) >= 1
    growth = echo.memory_growth()
    assert growth["total_experiences"] == 20


def test_benchmark_suite_runs_offline():
    from core.benchmark.suite import BenchmarkSuite
    suite = BenchmarkSuite()
    result = suite.run_all(scenario={"road_type": "URBAN"}, seed=1)
    assert 0 <= result["overall_score"] <= 100
    assert len(result["results"]) == 10
    assert result["engine_live"] in (True, False)


def test_report_generator_json_and_csv(tmp_storage, monkeypatch):
    import core.reports.generator as rep_mod
    monkeypatch.setattr(rep_mod, "STORAGE_ROOT", tmp_storage)
    gen = rep_mod.ReportGenerator()
    path = gen.json_report("test", {"a": 1})
    assert Path(path).exists()
    csv_path = gen.csv_metrics("test_metrics", [{"a": 1, "b": 2}])
    assert Path(csv_path).exists()


def test_deployment_mode_switch(tmp_storage, monkeypatch):
    import core.deployment as dep_mod
    monkeypatch.setattr(dep_mod, "STORAGE_ROOT", tmp_storage)
    monkeypatch.setattr(dep_mod, "STATE_PATH", tmp_storage / "state.json")
    dm = dep_mod.DeploymentManager()
    dm.set_mode("benchmark")
    assert dm.get_mode()["mode"] == "benchmark"
    with pytest.raises(ValueError):
        dm.set_mode("not_a_real_mode")


def test_scenario_manager_predefined_and_random():
    from core.scenarios.manager import ScenarioManager
    sm = ScenarioManager()
    all_scenarios = sm.list_scenarios()
    assert "cattle_crossing" in all_scenarios
    r = sm.random_scenario(seed=42)
    assert r["name"] in all_scenarios
    combo = sm.combine(["rain", "night"])
    assert "low_traction" in combo["hazards"]
