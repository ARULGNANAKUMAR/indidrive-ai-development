"""
Phase 11.3 — Safety Supervisor Tests
======================================
Comprehensive tests covering normal operation, caution, restricted, emergency,
system failures, staleness, recovery, multiple hazards, determinism,
validation, snapshots, and negative scope.

Conventions
-----------
* T = 1000.0 — reference timestamp.
* Helpers build real project types — no mocks of existing modules.
"""
from __future__ import annotations

import math
import pytest

from core.safety_supervisor import (
    SafetySupervisor,
    SupervisorConfig,
    ControlAuthority,
    OverrideReason,
    SafetySupervisorDecision,
    SafetySupervisorSnapshot,
    SUPERVISOR_SCHEMA_VERSION,
    TransitionDirection,
    TransitionInfo,
)

# Phase 11.1
from core.safety import SafetyMonitor, SafetyMonitorConfig, SafetyMonitorState, SafetyState
# Phase 11.2
from core.safety import (
    EmergencyDetector, EmergencyDetectorConfig, EmergencyDetectionState,
    EmergencyState, EmergencyType,
)
from core.safety.emergency_types import EmergencyDetectionState as EDS

# Existing project types
from core.world_model.world_model_types import (
    WorldModelSnapshot, WorldModelStatus, WorldObject, WorldObjectCollisionInfo,
    WorldObjectQuality, ObjectObservationState,
)
from core.planning.planner_types import PlannerOutput, PlannerStatus
from core.tracking.tracking_snapshot import TrackingSnapshot
from core.tracking.tracking_types import TrackingQuality
from core.control.mpc_snapshot import MPCSnapshot
from core.control.mpc_types import MPCStatus, ConstraintStatus
from core.control.control_snapshot import VehicleControlCommand
from core.control.control_types import ControlCommandStatus
from core.vehicle.dynamics_snapshot import DynamicsSnapshot

T = 1000.0


# ---------------------------------------------------------------------------
# Shared helpers
# ---------------------------------------------------------------------------

def _sup(cfg=None) -> SafetySupervisor:
    return SafetySupervisor(cfg or SupervisorConfig.default())


def _sm_safe(ts=T):
    sm = SafetyMonitor(SafetyMonitorConfig.default())
    return sm.assess(
        world_model_snapshot=WorldModelSnapshot(status=WorldModelStatus.OK, timestamp=ts),
        planner_output=PlannerOutput(
            timestamp=ts, planning_status=PlannerStatus.PLAN_AVAILABLE,
            planning_allowed=True, safety_gate_state="CLEAR",
            degraded=False, stale=False, confidence=0.9,
        ),
        tracking_snapshot=TrackingSnapshot(
            snap_timestamp=ts, tracking_quality=TrackingQuality.ON_TRACK,
            degraded=False, confidence=0.95, cross_track_error_m=0.05,
        ),
        mpc_snapshot=MPCSnapshot(
            snap_timestamp=ts, sim_timestamp=ts,
            status=MPCStatus.SUCCESS, feasible=True,
            constraint_status=ConstraintStatus.SATISFIED,
        ),
        control_command=VehicleControlCommand(timestamp=ts, status=ControlCommandStatus.VALID),
        dynamics_snapshot=DynamicsSnapshot(
            snapshot_timestamp=ts, sim_timestamp=ts,
            x=0.0, y=0.0, yaw=0.0, velocity=5.0,
        ),
        reference_timestamp=ts,
    )


def _sm_critical(ts=T):
    sm = SafetyMonitor(SafetyMonitorConfig.default())
    return sm.assess(
        world_model_snapshot=WorldModelSnapshot(status=WorldModelStatus.OK, timestamp=ts),
        planner_output=PlannerOutput(
            timestamp=ts, planning_status=PlannerStatus.SAFETY_RESTRICTED,
            safety_gate_state="CRITICAL", planning_allowed=False, degraded=False,
        ),
        reference_timestamp=ts,
    )


def _em_none(ts=T) -> EmergencyDetectionState:
    d = EmergencyDetector()
    return d.detect(
        safety_monitor_state=_sm_safe(ts),
        world_model_snapshot=WorldModelSnapshot(status=WorldModelStatus.OK, timestamp=ts),
        planner_output=PlannerOutput(
            timestamp=ts, planning_status=PlannerStatus.PLAN_AVAILABLE,
            planning_allowed=True, safety_gate_state="CLEAR", degraded=False,
        ),
        reference_timestamp=ts,
    )


def _em_critical(ts=T) -> EmergencyDetectionState:
    """Emergency with critical TTC."""
    d = EmergencyDetector()
    obj = WorldObject(
        object_id="OBJ_C",
        object_type="VEHICLE",
        collision=WorldObjectCollisionInfo(
            ttc_s=0.5, ttc_status="FINITE",
            collision_likelihood=0.95, risk_level="CRITICAL",
        ),
        quality=WorldObjectQuality(object_confidence=0.9,
                                  observation_state=ObjectObservationState.TRACKED),
    )
    wm = WorldModelSnapshot(status=WorldModelStatus.OK, timestamp=ts, _objects=(obj,))
    return d.detect(world_model_snapshot=wm, reference_timestamp=ts)


def _po_ok(ts=T):
    return PlannerOutput(
        timestamp=ts, planning_status=PlannerStatus.PLAN_AVAILABLE,
        planning_allowed=True, safety_gate_state="CLEAR",
        degraded=False, stale=False, confidence=0.9,
    )


def _ts_ok(ts=T):
    return TrackingSnapshot(
        snap_timestamp=ts, tracking_quality=TrackingQuality.ON_TRACK,
        degraded=False, confidence=0.95, cross_track_error_m=0.05,
    )


def _mpc_ok(ts=T):
    return MPCSnapshot(
        snap_timestamp=ts, sim_timestamp=ts,
        status=MPCStatus.SUCCESS, feasible=True,
        constraint_status=ConstraintStatus.SATISFIED,
    )


def _ctrl_ok(ts=T):
    return VehicleControlCommand(timestamp=ts, status=ControlCommandStatus.VALID)


def _dyn_ok(ts=T):
    return DynamicsSnapshot(
        snapshot_timestamp=ts, sim_timestamp=ts,
        x=0.0, y=0.0, yaw=0.0, velocity=5.0, acceleration=0.0,
    )


def _full_normal(ts=T) -> SafetySupervisorDecision:
    """Fully healthy system → NORMAL_CONTROL."""
    s = _sup()
    return s.evaluate(
        safety_monitor_state=_sm_safe(ts),
        emergency_detection_state=_em_none(ts),
        planner_output=_po_ok(ts),
        tracking_snapshot=_ts_ok(ts),
        mpc_snapshot=_mpc_ok(ts),
        control_command=_ctrl_ok(ts),
        dynamics_snapshot=_dyn_ok(ts),
        reference_timestamp=ts,
    )


# ===========================================================================
# Normal operation
# ===========================================================================

class TestNormalOperation:
    def test_safe_system_is_normal_control(self):
        d = _full_normal()
        assert d.control_authority == ControlAuthority.NORMAL_CONTROL

    def test_normal_control_sets_allowed_flag(self):
        d = _full_normal()
        assert d.normal_control_allowed is True
        assert d.normal_control_restricted is False
        assert d.control_withheld is False
        assert d.override_required is False

    def test_schema_version(self):
        d = _full_normal()
        assert d.schema_version == SUPERVISOR_SCHEMA_VERSION

    def test_decision_id_is_non_empty(self):
        d = _full_normal()
        assert d.decision_id != ""

    def test_valid_flag_set(self):
        d = _full_normal()
        assert d.valid is True

    def test_no_reason_codes_in_normal(self):
        d = _full_normal()
        # Normal operation should have empty or no-alarm reason codes
        assert d.control_authority == ControlAuthority.NORMAL_CONTROL

    def test_repr_informative(self):
        d = _full_normal()
        r = repr(d)
        assert "SafetySupervisorDecision" in r
        assert "NORMAL_CONTROL" in r


# ===========================================================================
# Caution → LIMITED_CONTROL
# ===========================================================================

class TestCaution:
    def test_caution_sm_gives_limited_control(self):
        # Build a CAUTION SafetyMonitorState by injecting a slight degradation
        sm = SafetyMonitor(SafetyMonitorConfig.default())
        sm_state = sm.assess(
            world_model_snapshot=WorldModelSnapshot(
                status=WorldModelStatus.DEGRADED, timestamp=T
            ),
            reference_timestamp=T,
        )
        # DEGRADED world → SM DEGRADED or worse; this gives DEGRADED_CONTROL at min
        s = _sup()
        d = s.evaluate(safety_monitor_state=sm_state, reference_timestamp=T)
        # DEGRADED or more restricted is expected
        assert d.control_authority not in (ControlAuthority.NORMAL_CONTROL,)

    def test_caution_safety_state_maps_to_limited(self):
        """Direct: feed a CAUTION SafetyState via frozen state stub."""
        # Build a SafetyMonitorState with CAUTION
        # The SM doesn't directly produce CAUTION through normal inputs,
        # so we verify the engine mapping logic by a custom SM stub.
        from core.safety.safety_types import SafetyMonitorState, SafetyState
        caution_sm = SafetyMonitorState(
            timestamp=T,
            overall_safety_state=SafetyState.CAUTION,
            confidence=0.8,
            uncertainty=0.2,
            stale=False,
            degraded=False,
            valid=True,
        )
        s = _sup()
        d = s.evaluate(safety_monitor_state=caution_sm, reference_timestamp=T)
        assert d.control_authority == ControlAuthority.LIMITED_CONTROL


# ===========================================================================
# Restricted states
# ===========================================================================

class TestRestricted:
    def test_restricted_sm_gives_restricted_control(self):
        from core.safety.safety_types import SafetyMonitorState, SafetyState
        restricted_sm = SafetyMonitorState(
            timestamp=T,
            overall_safety_state=SafetyState.RESTRICTED,
            confidence=0.7, uncertainty=0.3,
            stale=False, degraded=False, valid=True,
        )
        s = _sup()
        d = s.evaluate(safety_monitor_state=restricted_sm, reference_timestamp=T)
        assert d.control_authority == ControlAuthority.RESTRICTED_CONTROL

    def test_restricted_gate_gives_restricted(self):
        s = _sup()
        d = s.evaluate(
            planner_output=PlannerOutput(
                timestamp=T, planning_status=PlannerStatus.SAFETY_RESTRICTED,
                safety_gate_state="RESTRICTED", planning_allowed=False, degraded=False,
            ),
            reference_timestamp=T,
        )
        assert d.control_authority in (
            ControlAuthority.RESTRICTED_CONTROL,
            ControlAuthority.SAFETY_CONTROL_REQUIRED,
            ControlAuthority.OVERRIDE_REQUIRED,
        )

    def test_degraded_planner_gives_degraded(self):
        s = _sup()
        d = s.evaluate(
            planner_output=PlannerOutput(
                timestamp=T, planning_status=PlannerStatus.DEGRADED,
                safety_gate_state="CLEAR", planning_allowed=True, degraded=True,
            ),
            reference_timestamp=T,
        )
        assert d.control_authority in (
            ControlAuthority.DEGRADED_CONTROL,
            ControlAuthority.RESTRICTED_CONTROL,
        )

    def test_large_tracking_deviation_restricted(self):
        s = _sup()
        d = s.evaluate(
            tracking_snapshot=TrackingSnapshot(
                snap_timestamp=T,
                tracking_quality=TrackingQuality.LARGE_DEVIATION,
                degraded=False, confidence=0.7, cross_track_error_m=3.0,
            ),
            reference_timestamp=T,
        )
        assert d.control_authority in (
            ControlAuthority.RESTRICTED_CONTROL,
            ControlAuthority.SAFETY_CONTROL_REQUIRED,
            ControlAuthority.OVERRIDE_REQUIRED,
        )


# ===========================================================================
# Emergency conditions
# ===========================================================================

class TestEmergencyConditions:
    def test_critical_emergency_gives_override(self):
        s = _sup(SupervisorConfig(enable_hysteresis=False))
        d = s.evaluate(
            emergency_detection_state=_em_critical(),
            reference_timestamp=T,
        )
        assert d.control_authority in (
            ControlAuthority.OVERRIDE_REQUIRED,
            ControlAuthority.SAFETY_CONTROL_REQUIRED,
        )

    def test_critical_sm_gives_override(self):
        s = _sup(SupervisorConfig(enable_hysteresis=False))
        d = s.evaluate(
            safety_monitor_state=_sm_critical(),
            reference_timestamp=T,
        )
        assert d.control_authority in (
            ControlAuthority.OVERRIDE_REQUIRED,
            ControlAuthority.SAFETY_CONTROL_REQUIRED,
            ControlAuthority.UNKNOWN_CONTROL_AUTHORITY,
        )

    def test_imminent_collision_reason_code(self):
        d = EmergencyDetector().detect(
            world_model_snapshot=WorldModelSnapshot(
                status=WorldModelStatus.OK, timestamp=T,
                _objects=(WorldObject(
                    object_id="C1", object_type="VEHICLE",
                    collision=WorldObjectCollisionInfo(
                        ttc_s=0.4, ttc_status="FINITE", risk_level="CRITICAL",
                    ),
                ),),
            ),
            reference_timestamp=T,
        )
        s = _sup(SupervisorConfig(enable_hysteresis=False))
        dec = s.evaluate(emergency_detection_state=d, reference_timestamp=T)
        assert dec.control_authority in (
            ControlAuthority.OVERRIDE_REQUIRED,
            ControlAuthority.SAFETY_CONTROL_REQUIRED,
        )
        assert len(dec.reason_codes) > 0

    def test_cattle_crossing_emergency(self):
        cattle = WorldObject(
            object_id="COW1", object_type="ANIMAL", object_subtype="COW",
            collision=WorldObjectCollisionInfo(
                ttc_s=0.8, ttc_status="FINITE", risk_level="CRITICAL",
            ),
            quality=WorldObjectQuality(object_confidence=0.9,
                                       observation_state=ObjectObservationState.TRACKED),
        )
        em = EmergencyDetector().detect(
            world_model_snapshot=WorldModelSnapshot(
                status=WorldModelStatus.OK, timestamp=T, _objects=(cattle,)
            ),
            reference_timestamp=T,
        )
        s = _sup(SupervisorConfig(enable_hysteresis=False))
        d = s.evaluate(emergency_detection_state=em, reference_timestamp=T)
        assert d.control_authority in (
            ControlAuthority.OVERRIDE_REQUIRED,
            ControlAuthority.SAFETY_CONTROL_REQUIRED,
        )

    def test_pedestrian_crossing_emergency(self):
        ped = WorldObject(
            object_id="PED1", object_type="PEDESTRIAN",
            collision=WorldObjectCollisionInfo(
                ttc_s=0.6, ttc_status="FINITE",
                collision_likelihood=0.9, risk_level="CRITICAL",
            ),
            quality=WorldObjectQuality(object_confidence=0.9,
                                       observation_state=ObjectObservationState.TRACKED),
        )
        em = EmergencyDetector().detect(
            world_model_snapshot=WorldModelSnapshot(
                status=WorldModelStatus.OK, timestamp=T, _objects=(ped,)
            ),
            reference_timestamp=T,
        )
        s = _sup(SupervisorConfig(enable_hysteresis=False))
        d = s.evaluate(emergency_detection_state=em, reference_timestamp=T)
        assert d.is_override or d.is_restricted

    def test_vru_conflict_reason(self):
        em = EDS(
            timestamp=T, emergency_state=EmergencyState.CRITICAL_EMERGENCY,
            dominant_emergency_type=EmergencyType.VULNERABLE_ROAD_USER_CONFLICT,
            confidence=0.9, uncertainty=0.1, valid=True, stale=False, degraded=False,
        )
        s = _sup(SupervisorConfig(enable_hysteresis=False))
        d = s.evaluate(emergency_detection_state=em, reference_timestamp=T)
        assert d.control_authority in (
            ControlAuthority.OVERRIDE_REQUIRED,
            ControlAuthority.SAFETY_CONTROL_REQUIRED,
        )
        assert OverrideReason.SUDDEN_VRU_CROSSING.value in d.reason_codes

    def test_vehicle_cut_in_reason(self):
        em = EDS(
            timestamp=T, emergency_state=EmergencyState.EMERGENCY_DETECTED,
            dominant_emergency_type=EmergencyType.VEHICLE_CUT_IN,
            confidence=0.85, uncertainty=0.15, valid=True, stale=False, degraded=False,
        )
        s = _sup(SupervisorConfig(enable_hysteresis=False))
        d = s.evaluate(emergency_detection_state=em, reference_timestamp=T)
        assert d.is_override or d.is_restricted
        assert OverrideReason.VEHICLE_CUT_IN.value in d.reason_codes

    def test_critical_path_risk(self):
        em = EDS(
            timestamp=T, emergency_state=EmergencyState.EMERGENCY_DETECTED,
            dominant_emergency_type=EmergencyType.CRITICAL_PATH_RISK,
            confidence=0.8, uncertainty=0.2, valid=True, stale=False, degraded=False,
        )
        s = _sup(SupervisorConfig(enable_hysteresis=False))
        d = s.evaluate(emergency_detection_state=em, reference_timestamp=T)
        assert d.control_authority in (
            ControlAuthority.SAFETY_CONTROL_REQUIRED,
            ControlAuthority.OVERRIDE_REQUIRED,
            ControlAuthority.RESTRICTED_CONTROL,
        )

    def test_dynamic_obstacle_intrusion(self):
        em = EDS(
            timestamp=T, emergency_state=EmergencyState.CRITICAL_EMERGENCY,
            dominant_emergency_type=EmergencyType.DYNAMIC_OBSTACLE_INTRUSION,
            confidence=0.9, uncertainty=0.1, valid=True, stale=False, degraded=False,
        )
        s = _sup(SupervisorConfig(enable_hysteresis=False))
        d = s.evaluate(emergency_detection_state=em, reference_timestamp=T)
        assert d.control_authority in (
            ControlAuthority.OVERRIDE_REQUIRED,
            ControlAuthority.SAFETY_CONTROL_REQUIRED,
        )


# ===========================================================================
# System failures
# ===========================================================================

class TestSystemFailures:
    def test_mpc_no_feasible_restricts_control(self):
        s = _sup()
        d = s.evaluate(
            mpc_snapshot=MPCSnapshot(
                snap_timestamp=T, sim_timestamp=T,
                status=MPCStatus.NO_FEASIBLE_SOLUTION,
                feasible=False, constraint_status=ConstraintStatus.UNCHECKED,
            ),
            reference_timestamp=T,
        )
        assert d.control_authority in (
            ControlAuthority.SAFETY_CONTROL_REQUIRED,
            ControlAuthority.OVERRIDE_REQUIRED,
        )
        assert OverrideReason.MPC_FAILURE.value in d.reason_codes

    def test_mpc_constraint_violated_is_override(self):
        s = _sup(SupervisorConfig(enable_hysteresis=False))
        d = s.evaluate(
            mpc_snapshot=MPCSnapshot(
                snap_timestamp=T, sim_timestamp=T,
                status=MPCStatus.SUCCESS, feasible=True,
                constraint_status=ConstraintStatus.VIOLATED,
            ),
            reference_timestamp=T,
        )
        assert d.control_authority == ControlAuthority.OVERRIDE_REQUIRED
        assert OverrideReason.MPC_CONSTRAINT_VIOLATED.value in d.reason_codes

    def test_control_failure_restricts(self):
        s = _sup()
        d = s.evaluate(
            control_command=VehicleControlCommand(
                timestamp=T, status=ControlCommandStatus.INVALID,
            ),
            reference_timestamp=T,
        )
        assert d.control_authority in (
            ControlAuthority.SAFETY_CONTROL_REQUIRED,
            ControlAuthority.OVERRIDE_REQUIRED,
        )
        assert OverrideReason.CONTROL_FAILURE.value in d.reason_codes

    def test_no_solution_control_restricts(self):
        s = _sup()
        d = s.evaluate(
            control_command=VehicleControlCommand(
                timestamp=T, status=ControlCommandStatus.NO_SOLUTION,
            ),
            reference_timestamp=T,
        )
        assert d.control_authority in (
            ControlAuthority.SAFETY_CONTROL_REQUIRED,
            ControlAuthority.OVERRIDE_REQUIRED,
        )

    def test_planner_no_feasible_restricts(self):
        s = _sup()
        d = s.evaluate(
            planner_output=PlannerOutput(
                timestamp=T, planning_status=PlannerStatus.NO_FEASIBLE_CANDIDATE,
                planning_allowed=False, degraded=True, safety_gate_state="CLEAR",
            ),
            reference_timestamp=T,
        )
        assert d.control_authority in (
            ControlAuthority.SAFETY_CONTROL_REQUIRED,
            ControlAuthority.OVERRIDE_REQUIRED,
        )
        assert OverrideReason.PLANNER_FAILURE.value in d.reason_codes

    def test_tracking_reference_lost_is_override(self):
        s = _sup(SupervisorConfig(enable_hysteresis=False))
        d = s.evaluate(
            tracking_snapshot=TrackingSnapshot(
                snap_timestamp=T,
                tracking_quality=TrackingQuality.REFERENCE_LOST,
                degraded=True, confidence=0.0,
            ),
            reference_timestamp=T,
        )
        assert d.control_authority == ControlAuthority.OVERRIDE_REQUIRED
        assert OverrideReason.TRACKING_LOST.value in d.reason_codes

    def test_invalid_vehicle_state_withheld(self):
        s = _sup()
        d = s.evaluate(
            dynamics_snapshot=DynamicsSnapshot(
                snapshot_timestamp=T, sim_timestamp=T,
                x=float("nan"), y=0.0, yaw=0.0, velocity=5.0,
            ),
            reference_timestamp=T,
        )
        assert d.control_authority == ControlAuthority.CONTROL_WITHHELD
        assert OverrideReason.INVALID_VEHICLE_STATE.value in d.reason_codes

    def test_safety_monitor_critical_gives_override(self):
        from core.safety.safety_types import SafetyMonitorState, SafetyState
        sm_crit = SafetyMonitorState(
            timestamp=T, overall_safety_state=SafetyState.CRITICAL,
            confidence=0.95, uncertainty=0.05, stale=False, degraded=False, valid=True,
        )
        s = _sup(SupervisorConfig(enable_hysteresis=False))
        d = s.evaluate(safety_monitor_state=sm_crit, reference_timestamp=T)
        assert d.control_authority in (
            ControlAuthority.OVERRIDE_REQUIRED,
            ControlAuthority.SAFETY_CONTROL_REQUIRED,
        )
        assert OverrideReason.SAFETY_MONITOR_CRITICAL.value in d.reason_codes

    def test_system_critical_failure_reason(self):
        em = EDS(
            timestamp=T, emergency_state=EmergencyState.CRITICAL_EMERGENCY,
            dominant_emergency_type=EmergencyType.SYSTEM_CRITICAL_FAILURE,
            confidence=1.0, uncertainty=0.0, valid=True, stale=False, degraded=False,
        )
        s = _sup(SupervisorConfig(enable_hysteresis=False))
        d = s.evaluate(emergency_detection_state=em, reference_timestamp=T)
        assert d.control_authority in (
            ControlAuthority.OVERRIDE_REQUIRED,
            ControlAuthority.SAFETY_CONTROL_REQUIRED,
        )


# ===========================================================================
# Stale state
# ===========================================================================

class TestStaleState:
    def _stale_cfg(self) -> SupervisorConfig:
        return SupervisorConfig(
            safety_state_timeout_s=0.1,
            emergency_state_timeout_s=0.1,
            planner_state_timeout_s=0.1,
            tracking_state_timeout_s=0.1,
            mpc_state_timeout_s=0.1,
            control_state_timeout_s=0.1,
            vehicle_state_timeout_s=0.1,
            enable_hysteresis=False,
        )

    def test_stale_safety_state(self):
        from core.safety.safety_types import SafetyMonitorState, SafetyState
        stale_sm = SafetyMonitorState(
            timestamp=T - 1.0,  # 1 second old
            overall_safety_state=SafetyState.SAFE,
            confidence=0.9, uncertainty=0.1, stale=False, degraded=False, valid=True,
        )
        s = _sup(self._stale_cfg())
        d = s.evaluate(safety_monitor_state=stale_sm, reference_timestamp=T)
        assert d.stale is True
        assert OverrideReason.STALE_SAFETY_STATE.value in d.reason_codes

    def test_stale_emergency_state(self):
        stale_em = EDS(
            timestamp=T - 1.0,
            emergency_state=EmergencyState.NO_EMERGENCY,
            confidence=1.0, uncertainty=0.0, valid=True, stale=False, degraded=False,
        )
        s = _sup(self._stale_cfg())
        d = s.evaluate(emergency_detection_state=stale_em, reference_timestamp=T)
        assert d.stale is True
        assert OverrideReason.STALE_EMERGENCY_STATE.value in d.reason_codes

    def test_stale_planner(self):
        s = _sup(self._stale_cfg())
        d = s.evaluate(
            planner_output=PlannerOutput(
                timestamp=T - 1.0, planning_status=PlannerStatus.PLAN_AVAILABLE,
                planning_allowed=True, safety_gate_state="CLEAR", degraded=False,
            ),
            reference_timestamp=T,
        )
        assert d.stale is True
        assert OverrideReason.STALE_PLANNER_STATE.value in d.reason_codes

    def test_stale_tracking(self):
        s = _sup(self._stale_cfg())
        d = s.evaluate(
            tracking_snapshot=TrackingSnapshot(
                snap_timestamp=T - 1.0,
                tracking_quality=TrackingQuality.ON_TRACK,
                degraded=False, confidence=0.95,
            ),
            reference_timestamp=T,
        )
        assert d.stale is True
        assert OverrideReason.STALE_TRACKING_STATE.value in d.reason_codes

    def test_stale_mpc(self):
        s = _sup(self._stale_cfg())
        d = s.evaluate(
            mpc_snapshot=MPCSnapshot(
                snap_timestamp=T - 1.0, sim_timestamp=T - 1.0,
                status=MPCStatus.SUCCESS, feasible=True,
                constraint_status=ConstraintStatus.SATISFIED,
            ),
            reference_timestamp=T,
        )
        assert d.stale is True
        assert OverrideReason.STALE_MPC_STATE.value in d.reason_codes

    def test_stale_control(self):
        s = _sup(self._stale_cfg())
        d = s.evaluate(
            control_command=VehicleControlCommand(
                timestamp=T - 1.0, status=ControlCommandStatus.VALID,
            ),
            reference_timestamp=T,
        )
        assert d.stale is True
        assert OverrideReason.STALE_CONTROL_STATE.value in d.reason_codes

    def test_stale_vehicle(self):
        s = _sup(self._stale_cfg())
        d = s.evaluate(
            dynamics_snapshot=DynamicsSnapshot(
                snapshot_timestamp=T - 1.0, sim_timestamp=T - 1.0,
                x=0.0, y=0.0, yaw=0.0, velocity=5.0,
            ),
            reference_timestamp=T,
        )
        assert d.stale is True
        assert OverrideReason.STALE_VEHICLE_STATE.value in d.reason_codes

    def test_stale_does_not_grant_normal_control(self):
        from core.safety.safety_types import SafetyMonitorState, SafetyState
        stale_sm = SafetyMonitorState(
            timestamp=T - 5.0, overall_safety_state=SafetyState.SAFE,
            confidence=0.9, uncertainty=0.1, stale=False, degraded=False, valid=True,
        )
        s = _sup(self._stale_cfg())
        d = s.evaluate(safety_monitor_state=stale_sm, reference_timestamp=T)
        assert d.control_authority != ControlAuthority.NORMAL_CONTROL


# ===========================================================================
# Recovery
# ===========================================================================

class TestRecovery:
    def test_emergency_does_not_instantly_clear(self):
        cfg = SupervisorConfig(
            clear_cycles=3, min_override_hold_cycles=2, enable_hysteresis=True,
        )
        s = SafetySupervisor(cfg)

        # Cycle 1: critical emergency → OVERRIDE_REQUIRED
        snap1 = s.evaluate_with_snapshot(
            emergency_detection_state=_em_critical(),
            reference_timestamp=T,
        )
        assert snap1.decision.control_authority in (
            ControlAuthority.OVERRIDE_REQUIRED,
            ControlAuthority.SAFETY_CONTROL_REQUIRED,
        )

        # Cycle 2: all clear — should NOT yet return to NORMAL
        snap2 = s.evaluate_with_snapshot(
            safety_monitor_state=_sm_safe(),
            emergency_detection_state=_em_none(),
            planner_output=_po_ok(),
            tracking_snapshot=_ts_ok(),
            mpc_snapshot=_mpc_ok(),
            control_command=_ctrl_ok(),
            dynamics_snapshot=_dyn_ok(),
            reference_timestamp=T + 0.1,
            prior_snapshot=snap1,
        )
        # Still restricted — not enough clear cycles
        assert snap2.decision.control_authority != ControlAuthority.NORMAL_CONTROL

    def test_recovery_after_sufficient_clear_cycles(self):
        cfg = SupervisorConfig(
            clear_cycles=2, min_override_hold_cycles=1, enable_hysteresis=True,
        )
        s = SafetySupervisor(cfg)

        # Build prior state at OVERRIDE_REQUIRED with 2+ hold cycles
        prior = SafetySupervisorSnapshot(
            timestamp=T - 0.3,
            decision=SafetySupervisorDecision(
                timestamp=T - 0.3,
                control_authority=ControlAuthority.OVERRIDE_REQUIRED,
                emergency_state="CRITICAL_EMERGENCY",
            ),
            prior_authority=ControlAuthority.OVERRIDE_REQUIRED,
            hold_cycles=5,
            recovery_cycles=1,
        )

        # Cycle: all safe — prior has 1 recovery cycle already, need 2
        d2 = s.evaluate(
            safety_monitor_state=_sm_safe(),
            emergency_detection_state=_em_none(),
            planner_output=_po_ok(),
            tracking_snapshot=_ts_ok(),
            mpc_snapshot=_mpc_ok(),
            control_command=_ctrl_ok(),
            dynamics_snapshot=_dyn_ok(),
            reference_timestamp=T,
            prior_snapshot=prior,
        )
        # After enough clear cycles → allow recovery
        assert d2.control_authority != ControlAuthority.OVERRIDE_REQUIRED or \
               OverrideReason.INSUFFICIENT_CLEAR_CYCLES.value in d2.reason_codes

    def test_direct_normal_from_none_prior(self):
        """Without prior state, hysteresis doesn't hold anything back."""
        s = _sup()
        d = s.evaluate(
            safety_monitor_state=_sm_safe(),
            emergency_detection_state=_em_none(),
            planner_output=_po_ok(),
            tracking_snapshot=_ts_ok(),
            mpc_snapshot=_mpc_ok(),
            control_command=_ctrl_ok(),
            dynamics_snapshot=_dyn_ok(),
            reference_timestamp=T,
        )
        assert d.control_authority == ControlAuthority.NORMAL_CONTROL


# ===========================================================================
# Multiple simultaneous hazards
# ===========================================================================

class TestMultipleHazards:
    def test_critical_ttc_plus_mpc_failure(self):
        s = _sup(SupervisorConfig(enable_hysteresis=False))
        d = s.evaluate(
            emergency_detection_state=_em_critical(),
            mpc_snapshot=MPCSnapshot(
                snap_timestamp=T, sim_timestamp=T,
                status=MPCStatus.NO_FEASIBLE_SOLUTION,
                feasible=False, constraint_status=ConstraintStatus.UNCHECKED,
            ),
            reference_timestamp=T,
        )
        assert d.control_authority in (
            ControlAuthority.OVERRIDE_REQUIRED,
            ControlAuthority.SAFETY_CONTROL_REQUIRED,
        )
        # Both reasons present
        assert OverrideReason.MPC_FAILURE.value in d.reason_codes
        assert len(d.reason_codes) > 1

    def test_tracking_lost_plus_emergency(self):
        s = _sup(SupervisorConfig(enable_hysteresis=False))
        d = s.evaluate(
            emergency_detection_state=_em_critical(),
            tracking_snapshot=TrackingSnapshot(
                snap_timestamp=T,
                tracking_quality=TrackingQuality.REFERENCE_LOST,
                degraded=True, confidence=0.0,
            ),
            reference_timestamp=T,
        )
        assert d.control_authority in (
            ControlAuthority.OVERRIDE_REQUIRED,
            ControlAuthority.SAFETY_CONTROL_REQUIRED,
        )
        assert OverrideReason.TRACKING_LOST.value in d.reason_codes

    def test_planner_failure_plus_road_hazard(self):
        em = EDS(
            timestamp=T, emergency_state=EmergencyState.CRITICAL_EMERGENCY,
            dominant_emergency_type=EmergencyType.CRITICAL_ROAD_HAZARD,
            confidence=0.9, uncertainty=0.1, valid=True, stale=False, degraded=False,
        )
        s = _sup(SupervisorConfig(enable_hysteresis=False))
        d = s.evaluate(
            emergency_detection_state=em,
            planner_output=PlannerOutput(
                timestamp=T,
                planning_status=PlannerStatus.NO_FEASIBLE_CANDIDATE,
                planning_allowed=False, degraded=True, safety_gate_state="CLEAR",
            ),
            reference_timestamp=T,
        )
        assert d.control_authority in (
            ControlAuthority.OVERRIDE_REQUIRED,
            ControlAuthority.SAFETY_CONTROL_REQUIRED,
        )
        # Both reasons should appear
        codes = set(d.reason_codes)
        assert OverrideReason.PLANNER_FAILURE.value in codes or \
               OverrideReason.CRITICAL_ROAD_HAZARD.value in codes

    def test_control_failure_plus_critical_emergency(self):
        s = _sup(SupervisorConfig(enable_hysteresis=False))
        d = s.evaluate(
            emergency_detection_state=_em_critical(),
            control_command=VehicleControlCommand(
                timestamp=T, status=ControlCommandStatus.INVALID,
            ),
            reference_timestamp=T,
        )
        assert d.control_authority in (
            ControlAuthority.OVERRIDE_REQUIRED,
            ControlAuthority.SAFETY_CONTROL_REQUIRED,
        )
        assert len(d.reason_codes) >= 2

    def test_all_reasons_preserved(self):
        """No secondary reason is silently dropped."""
        s = _sup(SupervisorConfig(enable_hysteresis=False))
        d = s.evaluate(
            emergency_detection_state=_em_critical(),
            tracking_snapshot=TrackingSnapshot(
                snap_timestamp=T,
                tracking_quality=TrackingQuality.REFERENCE_LOST,
                degraded=True, confidence=0.0,
            ),
            mpc_snapshot=MPCSnapshot(
                snap_timestamp=T, sim_timestamp=T,
                status=MPCStatus.NO_FEASIBLE_SOLUTION,
                feasible=False, constraint_status=ConstraintStatus.UNCHECKED,
            ),
            reference_timestamp=T,
        )
        assert len(d.reason_codes) >= 2


# ===========================================================================
# Determinism
# ===========================================================================

class TestDeterminism:
    def test_same_input_same_output(self):
        s = _sup()
        em = _em_critical()
        kwargs = dict(emergency_detection_state=em, reference_timestamp=T)
        d1 = s.evaluate(**kwargs)
        d2 = s.evaluate(**kwargs)
        assert d1.control_authority == d2.control_authority
        assert d1.reason_codes == d2.reason_codes
        assert d1.dominant_reason == d2.dominant_reason
        assert d1.confidence == d2.confidence

    def test_normal_state_is_stable(self):
        s = _sup()
        d1 = _full_normal()
        d2 = _full_normal()
        assert d1.control_authority == d2.control_authority
        assert d1.normal_control_allowed == d2.normal_control_allowed

    def test_decision_id_stable(self):
        s = _sup(SupervisorConfig(enable_hysteresis=False))
        em = _em_critical()
        d1 = s.evaluate(emergency_detection_state=em, reference_timestamp=T)
        d2 = s.evaluate(emergency_detection_state=em, reference_timestamp=T)
        assert d1.decision_id == d2.decision_id


# ===========================================================================
# Validation / edge cases
# ===========================================================================

class TestValidation:
    def test_nan_ref_timestamp_does_not_crash(self):
        s = _sup()
        d = s.evaluate(reference_timestamp=float("nan"))
        assert isinstance(d, SafetySupervisorDecision)

    def test_inf_in_dynamics_gives_withheld(self):
        s = _sup()
        d = s.evaluate(
            dynamics_snapshot=DynamicsSnapshot(
                snapshot_timestamp=T, sim_timestamp=T,
                x=math.inf, y=0.0, yaw=0.0, velocity=5.0,
            ),
            reference_timestamp=T,
        )
        assert d.control_authority == ControlAuthority.CONTROL_WITHHELD

    def test_nan_in_dynamics_gives_withheld(self):
        s = _sup()
        d = s.evaluate(
            dynamics_snapshot=DynamicsSnapshot(
                snapshot_timestamp=T, sim_timestamp=T,
                x=float("nan"), y=0.0, yaw=0.0, velocity=5.0,
            ),
            reference_timestamp=T,
        )
        assert d.control_authority == ControlAuthority.CONTROL_WITHHELD
        assert d.vehicle_state_valid is False

    def test_all_none_inputs_unknown_authority(self):
        """No safety inputs → supervisor cannot establish safety → UNKNOWN_CONTROL_AUTHORITY."""
        s = _sup()
        d = s.evaluate(reference_timestamp=T)
        # No SM, no emergency input → conservative UNKNOWN (not NORMAL)
        assert d.control_authority == ControlAuthority.UNKNOWN_CONTROL_AUTHORITY
        assert d.normal_control_allowed is False

    def test_unknown_sm_gives_unknown_authority(self):
        from core.safety.safety_types import SafetyMonitorState, SafetyState
        unknown_sm = SafetyMonitorState(
            timestamp=T, overall_safety_state=SafetyState.UNKNOWN,
            confidence=0.0, uncertainty=1.0, stale=False, degraded=False, valid=False,
        )
        s = _sup()
        d = s.evaluate(safety_monitor_state=unknown_sm, reference_timestamp=T)
        assert d.control_authority == ControlAuthority.UNKNOWN_CONTROL_AUTHORITY

    def test_invalid_config_raises(self):
        with pytest.raises(ValueError):
            SupervisorConfig(safety_state_timeout_s=0.0)
        with pytest.raises(ValueError):
            SupervisorConfig(clear_cycles=-1)
        with pytest.raises(ValueError):
            SupervisorConfig(min_confidence_for_valid=2.0)

    def test_confidence_in_range(self):
        d = _full_normal()
        assert 0.0 <= d.confidence <= 1.0
        assert 0.0 <= d.uncertainty <= 1.0

    def test_stale_timestamp_handling(self):
        from core.safety.safety_types import SafetyMonitorState, SafetyState
        sm = SafetyMonitorState(
            timestamp=-1.0,  # invalid negative
            overall_safety_state=SafetyState.SAFE,
            confidence=0.9, uncertainty=0.1, stale=False, degraded=False, valid=True,
        )
        s = _sup()
        d = s.evaluate(safety_monitor_state=sm, reference_timestamp=T)
        # Negative timestamp → treated as stale
        assert d.stale is True


# ===========================================================================
# Snapshot / immutability
# ===========================================================================

class TestSnapshot:
    def test_decision_is_frozen(self):
        d = _full_normal()
        with pytest.raises((AttributeError, TypeError)):
            d.control_authority = ControlAuthority.OVERRIDE_REQUIRED  # type: ignore

    def test_reason_codes_is_tuple(self):
        d = _full_normal()
        assert isinstance(d.reason_codes, tuple)

    def test_emergency_ids_is_tuple(self):
        d = _full_normal()
        assert isinstance(d.emergency_ids, tuple)

    def test_transition_is_frozen(self):
        d = _full_normal()
        assert isinstance(d.transition, TransitionInfo)
        with pytest.raises((AttributeError, TypeError)):
            d.transition.hold_cycles = 999  # type: ignore

    def test_snapshot_wraps_decision(self):
        s = _sup()
        snap = s.evaluate_with_snapshot(
            safety_monitor_state=_sm_safe(),
            emergency_detection_state=_em_none(),
            reference_timestamp=T,
        )
        assert isinstance(snap, SafetySupervisorSnapshot)
        assert isinstance(snap.decision, SafetySupervisorDecision)
        assert snap.decision.control_authority == ControlAuthority.NORMAL_CONTROL

    def test_snapshot_is_frozen(self):
        s = _sup()
        snap = s.evaluate_with_snapshot(reference_timestamp=T)
        with pytest.raises((AttributeError, TypeError)):
            snap.hold_cycles = 99  # type: ignore

    def test_snapshot_schema_version(self):
        s = _sup()
        snap = s.evaluate_with_snapshot(reference_timestamp=T)
        assert snap.schema_version == SUPERVISOR_SCHEMA_VERSION


# ===========================================================================
# Transition model
# ===========================================================================

class TestTransitionModel:
    def test_first_cycle_is_initial(self):
        d = _full_normal()
        assert d.transition.direction == TransitionDirection.INITIAL

    def test_stable_transition_when_unchanged(self):
        s = _sup(SupervisorConfig(enable_hysteresis=True, clear_cycles=0))
        snap1 = s.evaluate_with_snapshot(
            safety_monitor_state=_sm_safe(),
            emergency_detection_state=_em_none(),
            reference_timestamp=T,
        )
        snap2 = s.evaluate_with_snapshot(
            safety_monitor_state=_sm_safe(),
            emergency_detection_state=_em_none(),
            reference_timestamp=T + 0.1,
            prior_snapshot=snap1,
        )
        assert snap2.decision.transition.direction == TransitionDirection.STABLE

    def test_escalating_on_emergency(self):
        s = _sup(SupervisorConfig(enable_hysteresis=False))
        snap1 = s.evaluate_with_snapshot(
            safety_monitor_state=_sm_safe(),
            emergency_detection_state=_em_none(),
            reference_timestamp=T,
        )
        snap2 = s.evaluate_with_snapshot(
            emergency_detection_state=_em_critical(),
            reference_timestamp=T + 0.1,
            prior_snapshot=snap1,
        )
        assert snap2.decision.transition.direction == TransitionDirection.ESCALATING


# ===========================================================================
# Priority / dominant reason
# ===========================================================================

class TestPriority:
    def test_system_failure_beats_degraded(self):
        s = _sup(SupervisorConfig(enable_hysteresis=False))
        d = s.evaluate(
            mpc_snapshot=MPCSnapshot(
                snap_timestamp=T, sim_timestamp=T,
                status=MPCStatus.INVALID_INPUT, feasible=False,
                constraint_status=ConstraintStatus.UNCHECKED,
            ),
            planner_output=PlannerOutput(
                timestamp=T, planning_status=PlannerStatus.DEGRADED,
                safety_gate_state="CLEAR", planning_allowed=True, degraded=True,
            ),
            reference_timestamp=T,
        )
        # MPC failure is more critical than degraded planner
        assert d.dominant_reason in (
            OverrideReason.MPC_FAILURE.value,
            OverrideReason.DEGRADED_MPC.value,
        )
        # Overall authority driven by MPC failure
        assert d.control_authority in (
            ControlAuthority.SAFETY_CONTROL_REQUIRED,
            ControlAuthority.OVERRIDE_REQUIRED,
        )

    def test_override_reason_beats_restriction(self):
        s = _sup(SupervisorConfig(enable_hysteresis=False))
        d = s.evaluate(
            emergency_detection_state=EDS(
                timestamp=T,
                emergency_state=EmergencyState.CRITICAL_EMERGENCY,
                dominant_emergency_type=EmergencyType.IMMINENT_COLLISION,
                confidence=0.95, uncertainty=0.05,
                valid=True, stale=False, degraded=False,
            ),
            tracking_snapshot=TrackingSnapshot(
                snap_timestamp=T,
                tracking_quality=TrackingQuality.LARGE_DEVIATION,
                degraded=False, confidence=0.7, cross_track_error_m=3.0,
            ),
            reference_timestamp=T,
        )
        # IMMINENT_COLLISION is higher priority than TRACKING_LARGE_DEVIATION
        assert d.dominant_reason in (
            OverrideReason.IMMINENT_COLLISION.value,
            OverrideReason.CRITICAL_TTC.value,
            OverrideReason.CRITICAL_EMERGENCY.value,
            OverrideReason.UNAVOIDABLE_CONFLICT.value,
        )


# ===========================================================================
# Negative scope — Phase 11.3 MUST NOT do these things
# ===========================================================================

class TestNegativeScope:
    def _critical_decision(self):
        s = _sup(SupervisorConfig(enable_hysteresis=False))
        return s.evaluate(emergency_detection_state=_em_critical(), reference_timestamp=T)

    def test_no_steering_command(self):
        d = self._critical_decision()
        assert not hasattr(d, "steering_angle")
        assert not hasattr(d, "steering_command")

    def test_no_brake_command(self):
        d = self._critical_decision()
        assert not hasattr(d, "brake")
        assert not hasattr(d, "brake_command")
        assert not hasattr(d, "brake_mps2")

    def test_no_throttle_command(self):
        d = self._critical_decision()
        assert not hasattr(d, "throttle")
        assert not hasattr(d, "acceleration_command")

    def test_no_can_frame(self):
        d = self._critical_decision()
        assert not hasattr(d, "can_frame")
        assert not hasattr(d, "can_message")

    def test_no_path_generation(self):
        d = self._critical_decision()
        assert not hasattr(d, "path")
        assert not hasattr(d, "trajectory")
        assert not hasattr(d, "waypoints")

    def test_no_mpc_solution(self):
        d = self._critical_decision()
        assert not hasattr(d, "mpc_solution")
        assert not hasattr(d, "control_sequence")

    def test_no_emergency_brake(self):
        d = self._critical_decision()
        assert not hasattr(d, "emergency_brake")
        assert not hasattr(d, "emergency_brake_applied")

    def test_no_actuator_methods_on_supervisor(self):
        s = _sup()
        forbidden = [
            "brake", "steer", "accelerate", "emergency_stop",
            "send_can", "override_controller", "generate_path",
            "run_mpc", "compute_trajectory", "select_path",
        ]
        for fn in forbidden:
            assert not hasattr(s, fn), f"SafetySupervisor must not have: {fn}"

    def test_override_required_has_no_actuation(self):
        """OVERRIDE_REQUIRED only signals — no actuator output."""
        d = self._critical_decision()
        assert d.control_authority in (
            ControlAuthority.OVERRIDE_REQUIRED,
            ControlAuthority.SAFETY_CONTROL_REQUIRED,
        )
        assert not hasattr(d, "steering_angle")
        assert not hasattr(d, "brake_mps2")

    def test_supervisor_does_not_generate_new_path(self):
        s = _sup()
        assert not hasattr(s, "plan")
        assert not hasattr(s, "generate_path")
        assert not hasattr(s, "compute_trajectory")

    def test_supervisor_does_not_run_mpc(self):
        s = _sup()
        assert not hasattr(s, "run_mpc")
        assert not hasattr(s, "solve_mpc")
        assert not hasattr(s, "predict_trajectory")


# ===========================================================================
# Phase 10.5 regression protection
# ===========================================================================

class TestPhase105Regression:
    def test_all_existing_imports_intact(self):
        from core.integration.autonomous_pipeline import AutonomousPipeline
        from core.reasoning.safety_gate import SafetyGateEvaluator
        from core.control.mpc_controller import MPCController
        assert AutonomousPipeline is not None

    def test_phase_11_1_unmodified(self):
        sm = SafetyMonitor(SafetyMonitorConfig.default())
        state = sm.assess(reference_timestamp=T)
        assert isinstance(state, SafetyMonitorState)

    def test_phase_11_2_unmodified(self):
        em = EmergencyDetector().detect(reference_timestamp=T)
        assert isinstance(em, EmergencyDetectionState)

    def test_supervisor_does_not_modify_inputs(self):
        sm = _sm_safe()
        em = _em_none()
        sm_state_before = sm.overall_safety_state
        em_state_before = em.emergency_state
        _sup().evaluate(
            safety_monitor_state=sm,
            emergency_detection_state=em,
            reference_timestamp=T,
        )
        assert sm.overall_safety_state == sm_state_before
        assert em.emergency_state == em_state_before
