"""Phase 12.2 — Tests: Negative Scope
Explicitly verifies that Phase 12.2 does NOT implement any Phase 12.3+
functionality or modify autonomous pipeline decisions.
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))
sys.path.insert(0, os.path.dirname(__file__))

import pytest
import pathlib

from core.experience.record import record_types as rtypes
from core.experience.record import record_builder as rbuilder
from core.experience.record import record_store as rstore
from core.experience.record import record_engine as rengine
from core.experience.record import pipeline_record_adapter as radapter

_RECORD_MODULES = [rtypes, rbuilder, rstore, rengine, radapter]


# ------------------------------------------------------------------
# 1. No success/failure evaluation

def test_no_success_field_in_any_record_type():
    from core.experience.record.record_types import (
        SituationRecord, ActionRecord, OutcomeRecord, ExperienceRecord
    )
    for cls in [SituationRecord, ActionRecord, OutcomeRecord, ExperienceRecord]:
        inst = cls()
        assert not hasattr(inst, "success"), f"{cls.__name__} must not have 'success'"
        assert not hasattr(inst, "failure"), f"{cls.__name__} must not have 'failure'"
        assert not hasattr(inst, "reward"), f"{cls.__name__} must not have 'reward'"
        assert not hasattr(inst, "quality"), f"{cls.__name__} must not have 'quality'"
        assert not hasattr(inst, "is_successful"), f"{cls.__name__} must not have 'is_successful'"


def test_no_evaluate_method_in_engine():
    from core.experience.record.record_engine import ExperienceRecordEngine
    for name in dir(ExperienceRecordEngine):
        assert "evaluat" not in name.lower() or "validate" in name.lower(), (
            f"Unexpected evaluate method: {name}"
        )


def test_no_reward_computation_in_builder():
    src = pathlib.Path(rbuilder.__file__).read_text()
    import_lines = [l for l in src.splitlines() if l.strip().startswith(("import ", "from "))]
    for line in import_lines:
        assert "reward" not in line.lower()


# ------------------------------------------------------------------
# 2. No outcome evaluation (Phase 12.3)

def test_no_success_in_outcome_dict():
    from exp122_helpers import make_outcome
    o = make_outcome()
    d = o.to_dict()
    forbidden = {"success", "failure", "reward", "quality", "score",
                 "is_successful", "good_action", "bad_action"}
    found = forbidden & set(d.keys())
    assert not found, f"Forbidden evaluation keys in outcome dict: {found}"


def test_completeness_is_not_success():
    """RecordCompleteness represents data availability, NOT quality."""
    from core.experience.record.record_types import RecordCompleteness
    # COMPLETE = all data present, not = successful
    assert RecordCompleteness.COMPLETE.value == "COMPLETE"
    # There is no SUCCESS or FAILED enum value
    values = {e.value for e in RecordCompleteness}
    assert "SUCCESS" not in values
    assert "FAILED" not in values
    assert "GOOD" not in values


# ------------------------------------------------------------------
# 3. No experience retrieval (Phase 12.4)

def test_no_retrieve_method():
    from core.experience.record.record_engine import ExperienceRecordEngine
    from core.experience.record.record_store import ExperienceRecordStore
    for cls in [ExperienceRecordEngine, ExperienceRecordStore]:
        assert not hasattr(cls, "retrieve_similar"), f"{cls.__name__} must not have retrieve_similar"
        assert not hasattr(cls, "find_similar"), f"{cls.__name__} must not have find_similar"
        assert not hasattr(cls, "rank_records"), f"{cls.__name__} must not have rank_records"


# ------------------------------------------------------------------
# 4. No adaptive update (Phase 12.5)

def test_no_adapt_method():
    from core.experience.record.record_engine import ExperienceRecordEngine
    assert not hasattr(ExperienceRecordEngine, "adapt")
    assert not hasattr(ExperienceRecordEngine, "update_knowledge")
    assert not hasattr(ExperienceRecordEngine, "update_weights")


# ------------------------------------------------------------------
# 5. No decision improvement (Phase 12.6)

def test_no_improve_decision():
    from core.experience.record.record_engine import ExperienceRecordEngine
    assert not hasattr(ExperienceRecordEngine, "improve_decision")
    assert not hasattr(ExperienceRecordEngine, "update_policy")
    assert not hasattr(ExperienceRecordEngine, "improve_planning")


# ------------------------------------------------------------------
# 6. No new perception / prediction

def test_no_perception_import_in_builder():
    src = pathlib.Path(rbuilder.__file__).read_text()
    import_lines = [l for l in src.splitlines() if l.strip().startswith(("import ", "from "))]
    for line in import_lines:
        assert "perception" not in line.lower(), f"Unexpected import: {line}"
        assert "predictor" not in line.lower(), f"Unexpected import: {line}"


def test_no_prediction_engine_in_record_modules():
    for mod in _RECORD_MODULES:
        src = pathlib.Path(mod.__file__).read_text()
        import_lines = [l for l in src.splitlines() if l.strip().startswith(("import ", "from "))]
        for line in import_lines:
            assert "MotionPredict" not in line, f"Unexpected import in {mod.__name__}: {line}"


# ------------------------------------------------------------------
# 7. No new MPC / control generation

def test_no_mpc_solver_in_builder():
    src = pathlib.Path(rbuilder.__file__).read_text()
    assert "MPCSolver" not in src
    assert "mpc_solver" not in src.lower()
    assert "apply_control" not in src


def test_builder_does_not_generate_steering():
    from exp122_helpers import make_observation
    from core.experience.record.record_builder import RecordBuilder
    from exp122_helpers import make_record_config
    builder = RecordBuilder(make_record_config())
    obs = make_observation()
    act = builder.build_action("r-x", obs)
    # commanded values must be None — never generated
    assert act.applied.commanded_steering_rad is None
    assert act.applied.commanded_acceleration_ms2 is None


# ------------------------------------------------------------------
# 8. No cloud / LLM / network

def test_no_llm_import_in_record_modules():
    for mod in _RECORD_MODULES:
        src = pathlib.Path(mod.__file__).read_text()
        import_lines = [l for l in src.splitlines() if l.strip().startswith(("import ", "from "))]
        for line in import_lines:
            ll = line.lower()
            assert "openai" not in ll, f"LLM import in {mod.__name__}: {line}"
            assert "anthropic" not in ll, f"LLM import in {mod.__name__}: {line}"
            assert "requests" not in ll, f"Network import in {mod.__name__}: {line}"


def test_no_cloud_storage_import():
    for mod in _RECORD_MODULES:
        src = pathlib.Path(mod.__file__).read_text()
        import_lines = [l for l in src.splitlines() if l.strip().startswith(("import ", "from "))]
        for line in import_lines:
            ll = line.lower()
            assert "pymongo" not in ll
            assert "boto3" not in ll
            assert "faiss" not in ll


# ------------------------------------------------------------------
# 9. No path / trajectory generation

def test_no_path_generation_in_builder():
    src = pathlib.Path(rbuilder.__file__).read_text()
    assert "CandidatePath(" not in src
    assert "generate_path" not in src
    assert "PlannerEngine(" not in src


# ------------------------------------------------------------------
# 10. Outcome dict has no forbidden evaluation keys

def test_all_record_dicts_clean():
    from exp122_helpers import make_full_record
    r = make_full_record()
    d = r.to_dict()
    forbidden = {"success", "failure", "reward", "quality", "score",
                 "is_successful", "optimal_action", "learned_policy"}

    def _check(d, path=""):
        if isinstance(d, dict):
            found = forbidden & set(d.keys())
            assert not found, f"Forbidden keys at {path}: {found}"
            for k, v in d.items():
                _check(v, f"{path}.{k}")

    _check(d, "record")
