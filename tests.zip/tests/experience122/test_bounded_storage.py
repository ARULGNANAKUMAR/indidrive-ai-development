"""Phase 12.2 — Tests: Bounded Storage and Deterministic IDs"""
import sys, os, time
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))
sys.path.insert(0, os.path.dirname(__file__))

import pytest
from exp122_helpers import make_full_record, make_record_config

from core.experience.record.record_store import ExperienceRecordStore
from core.experience.record.record_engine import _make_record_id
from core.experience.record.record_types import RecordStoreStatus


def test_record_bound_enforced():
    """Store must not exceed max_records_per_session."""
    cfg = make_record_config(max_records=5)
    store = ExperienceRecordStore(cfg)
    store.start_session("bound-001")
    for i in range(10):
        store.add_record(make_full_record("bound-001", seq=i))
    assert store.record_count <= 5


def test_overflow_status_set():
    cfg = make_record_config(max_records=2)
    store = ExperienceRecordStore(cfg)
    store.start_session("ovf-001")
    for i in range(5):
        store.add_record(make_full_record("ovf-001", seq=i))
    assert store.store_status == RecordStoreStatus.OVERFLOW


def test_fifo_drops_oldest():
    cfg = make_record_config(max_records=3)
    store = ExperienceRecordStore(cfg)
    store.start_session("fifo-001")
    for i in range(5):
        store.add_record(make_full_record("fifo-001", seq=i))
    recent = store.get_recent_records(n=10)
    seqs = [s.sequence_id for s in recent]
    assert 0 not in seqs  # oldest dropped
    assert 4 in seqs       # newest kept


def test_no_silent_unbounded_growth():
    cfg = make_record_config(max_records=10)
    store = ExperienceRecordStore(cfg)
    store.start_session("grow-001")
    for i in range(100):
        store.add_record(make_full_record("grow-001", seq=i))
    assert store.record_count <= 10


def test_disabled_capture_no_op():
    from core.experience.record.record_types import ExperienceRecordConfig
    cfg = ExperienceRecordConfig(record_capture_enabled=False)
    store = ExperienceRecordStore(cfg)
    store.start_session("dis-001")
    ok = store.add_record(make_full_record("dis-001", seq=0))
    assert ok  # not a failure — disabled
    assert store.record_count == 0


# ------------------------------------------------------------------
# Deterministic ID tests

def test_record_id_deterministic():
    id1 = _make_record_id("session-001", 5)
    id2 = _make_record_id("session-001", 5)
    assert id1 == id2 == "session-001-R000005"


def test_record_ids_unique_within_session():
    ids = [_make_record_id("s", i) for i in range(10)]
    assert len(ids) == len(set(ids))


def test_record_id_format():
    assert _make_record_id("s", 0) == "s-R000000"
    assert _make_record_id("s", 999999) == "s-R999999"


def test_situation_id_format():
    from exp122_helpers import make_situation
    s = make_situation(session_id="det-s", seq=3)
    assert s.situation_id == "det-s-R000003-SIT"


def test_action_id_format():
    from exp122_helpers import make_action
    a = make_action(session_id="det-s", seq=3)
    assert a.action_id == "det-s-R000003-ACT"


def test_outcome_id_format():
    from exp122_helpers import make_outcome
    o = make_outcome(session_id="det-s", seq=3)
    assert o.outcome_id == "det-s-R000003-OUT"
