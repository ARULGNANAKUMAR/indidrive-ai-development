"""Phase 12.2 — Tests: Recording Failure Isolation"""
import sys, os, time
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))
sys.path.insert(0, os.path.dirname(__file__))

import pytest
from exp122_helpers import make_observation, make_event, make_record_config

from core.experience.record.pipeline_record_adapter import PipelineRecordAdapter
from core.experience.record.record_engine import ExperienceRecordEngine
from core.experience.record.record_store import ExperienceRecordStore
from core.experience.record.record_types import (
    ExperienceRecordConfig, RecordStoreStatus, NOT_AVAILABLE,
)
from core.experience.experience_types import ExperienceCaptureSnapshot, SessionStatus


def test_adapter_never_raises_on_none_snapshot():
    adapter = PipelineRecordAdapter()
    adapter.start_session("fi-001")
    snap = adapter.record_from_snapshot(None)
    assert snap is not None


def test_adapter_never_raises_without_session():
    adapter = PipelineRecordAdapter()
    snap = adapter.record_from_snapshot(
        ExperienceCaptureSnapshot(session_id="x", session_status=SessionStatus.ACTIVE)
    )
    assert snap is not None


def test_adapter_handles_empty_snapshot():
    adapter = PipelineRecordAdapter()
    adapter.start_session("fi-002")
    # Snapshot with no observations
    cap_snap = ExperienceCaptureSnapshot(
        session_id="fi-002",
        session_status=SessionStatus.ACTIVE,
        recent_observations=(),
        recent_events=(),
    )
    result = adapter.record_from_snapshot(cap_snap)
    assert result is not None


def test_adapter_handles_garbage_inputs():
    adapter = PipelineRecordAdapter()
    adapter.start_session("fi-003")
    obs = make_observation("fi-003", seq=0)

    class _BadEvent:
        @property
        def event_id(self):
            raise RuntimeError("broken event")
        frame_id = 0
        event_type = None

    snap = adapter.record_observation(obs, triggering_event=_BadEvent())
    assert snap is not None


def test_store_failure_does_not_propagate():
    store = ExperienceRecordStore(ExperienceRecordConfig())
    store._record_failure("test failure")
    assert store.store_status == RecordStoreStatus.FAILED
    # store is degraded but get_store_snapshot still works
    snap = store.get_store_snapshot()
    assert snap.store_failed is True


def test_engine_no_session_process_observation():
    engine = ExperienceRecordEngine(make_record_config())
    obs = make_observation("no-sess", seq=0, hazard_level="HIGH")
    result = engine.process_observation(obs)
    # Should silently return None — not raise
    assert result is None


def test_engine_handles_none_observation():
    engine = ExperienceRecordEngine(make_record_config())
    engine.start_session("none-obs-001")
    result = engine.process_observation(None)
    assert result is None


def test_adapter_record_observation_never_raises():
    adapter = PipelineRecordAdapter()
    adapter.start_session("fi-004")
    obs = make_observation("fi-004", seq=0, hazard_level="HIGH")
    result = adapter.record_observation(obs)
    assert result is not None


def test_adapter_empty_session_id():
    adapter = PipelineRecordAdapter()
    ok = adapter.start_session("")
    assert not ok


def test_adapter_reset_never_raises():
    adapter = PipelineRecordAdapter()
    adapter.start_session("fi-005")
    adapter.reset()
    snap = adapter.get_store_snapshot()
    assert snap is not None


def test_multiple_bad_cycles_dont_accumulate_exceptions():
    adapter = PipelineRecordAdapter()
    adapter.start_session("fi-006")
    for _ in range(5):
        snap = adapter.record_from_snapshot(None)
        assert snap is not None


def test_adapter_close_pending_never_raises_without_session():
    adapter = PipelineRecordAdapter()
    closed = adapter.close_pending_outcomes()
    assert isinstance(closed, int)
