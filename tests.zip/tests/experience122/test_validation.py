"""Phase 12.2 — Tests: RecordValidator"""
import sys, os, time
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))
sys.path.insert(0, os.path.dirname(__file__))

import pytest
from exp122_helpers import make_situation, make_action, make_outcome, make_record_config, make_full_record

from core.experience.record.record_validator import RecordValidator
from core.experience.record.record_types import (
    NOT_AVAILABLE, RECORD_SCHEMA_VERSION,
    ExperienceRecord, RecordCompleteness,
)


def _v():
    return RecordValidator(make_record_config())


def test_valid_situation():
    ok, reason = _v().validate_situation(make_situation())
    assert ok, reason


def test_valid_action():
    ok, reason = _v().validate_action(make_action())
    assert ok, reason


def test_valid_outcome():
    ok, reason = _v().validate_outcome(make_outcome())
    assert ok, reason


def test_valid_record():
    ok, reason = _v().validate_record(make_full_record())
    assert ok, reason


def test_situation_none():
    ok, _ = _v().validate_situation(None)
    assert not ok


def test_action_none():
    ok, _ = _v().validate_action(None)
    assert not ok


def test_outcome_none():
    ok, _ = _v().validate_outcome(None)
    assert not ok


def test_record_none():
    ok, _ = _v().validate_record(None)
    assert not ok


def test_situation_wrong_schema():
    s = make_situation()
    s.schema_version = "99.9"
    ok, reason = _v().validate_situation(s)
    assert not ok
    assert "schema_version" in reason


def test_situation_missing_id():
    s = make_situation()
    s.situation_id = NOT_AVAILABLE
    ok, reason = _v().validate_situation(s)
    assert not ok
    assert "situation_id" in reason


def test_situation_id_format_mismatch():
    s = make_situation()
    s.situation_id = "wrong-format"
    ok, reason = _v().validate_situation(s)
    assert not ok


def test_action_wrong_schema():
    a = make_action()
    a.schema_version = "bad"
    ok, _ = _v().validate_action(a)
    assert not ok


def test_action_missing_id():
    a = make_action()
    a.action_id = NOT_AVAILABLE
    ok, _ = _v().validate_action(a)
    assert not ok


def test_outcome_wrong_schema():
    o = make_outcome()
    o.schema_version = "bad"
    ok, _ = _v().validate_outcome(o)
    assert not ok


def test_outcome_id_format_mismatch():
    o = make_outcome()
    o.outcome_id = "wrong-format"
    ok, reason = _v().validate_outcome(o)
    assert not ok


def test_record_missing_id():
    r = make_full_record()
    r.record_id = NOT_AVAILABLE
    ok, _ = _v().validate_record(r)
    assert not ok


def test_record_id_prefix_mismatch():
    r = make_full_record(session_id="sess-A")
    r.session_id = "sess-B"  # mismatch
    ok, reason = _v().validate_record(r)
    assert not ok
    assert "record_id" in reason


def test_situation_confidence_out_of_range():
    s = make_situation()
    s.reasoning_confidence = 2.5
    ok, reason = _v().validate_situation(s)
    assert not ok
    assert "reasoning_confidence" in reason


def test_situation_uncertainty_out_of_range():
    s = make_situation()
    s.reasoning_uncertainty = -0.1
    ok, reason = _v().validate_situation(s)
    assert not ok
    assert "reasoning_uncertainty" in reason


def test_outcome_negative_window():
    o = make_outcome()
    o.observation_window_s = -1.0
    ok, _ = _v().validate_outcome(o)
    assert not ok
