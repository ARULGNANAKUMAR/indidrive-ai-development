"""
IndiDrive AI — Phase 12.2 | Test Helpers
=========================================
Shared builders for Phase 12.2 experience record tests.
Uses the exp121_helpers from Phase 12.1 where appropriate.
"""
from __future__ import annotations
import sys, os, time

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "experience121"))

from exp121_helpers import (
    make_observation,
    make_event,
    make_config as make_capture_config,
    make_world_model_stub,
    make_reasoning_stub,
    make_planner_stub,
    make_safety_stub,
)

from core.experience.experience_types import (
    NOT_AVAILABLE,
    CaptureDataValidity,
    CaptureEventType,
    ExperienceCaptureConfig,
)
from core.experience.record.record_types import (
    RECORD_SCHEMA_VERSION,
    ActionRecord,
    ActionSource,
    ActionType,
    AppliedAction,
    ExperienceRecord,
    ExperienceRecordConfig,
    OutcomeObservationState,
    OutcomeRecord,
    RecordCompleteness,
    RequestedAction,
    SituationRecord,
)
from core.experience.record.record_engine import _make_record_id


# ---------------------------------------------------------------------------
# Config builders
# ---------------------------------------------------------------------------

def make_record_config(
    max_records: int = 100,
    window: int = 20,
    immediate_window_s: float = 1.0,
    max_window_s: float = 5.0,
) -> ExperienceRecordConfig:
    return ExperienceRecordConfig(
        max_records_per_session=max_records,
        recent_window_records=window,
        immediate_outcome_window_s=immediate_window_s,
        max_outcome_window_s=max_window_s,
    )


# ---------------------------------------------------------------------------
# Record component builders
# ---------------------------------------------------------------------------

def make_situation(
    session_id: str = "sess-001",
    record_id: str = None,
    seq: int = 0,
    timestamp: float = None,
    hazard_level: str = "LOW",
    situation_type: str = "NORMAL_TRAFFIC",
    cattle: bool = False,
    vru: bool = False,
) -> SituationRecord:
    rid = record_id or f"{session_id}-R{seq:06d}"
    ts = timestamp or time.time()
    return SituationRecord(
        situation_id=f"{rid}-SIT",
        record_id=rid,
        session_id=session_id,
        sequence_id=seq,
        timestamp=ts,
        frame_id=seq,
        schema_version=RECORD_SCHEMA_VERSION,
        triggering_observation_id=f"{session_id}-O{seq:06d}",
        situation_type=situation_type,
        hazard_level=hazard_level,
        reasoning_confidence=0.8,
        reasoning_uncertainty=0.2,
        safety_state="SAFE",
        cattle_present=cattle,
        vulnerable_road_user_present=vru,
    )


def make_action(
    session_id: str = "sess-001",
    record_id: str = None,
    seq: int = 0,
    timestamp: float = None,
    action_type: ActionType = ActionType.FOLLOW_REFERENCE,
    replanning: bool = False,
) -> ActionRecord:
    rid = record_id or f"{session_id}-R{seq:06d}"
    ts = timestamp or time.time()
    req = RequestedAction(
        action_type=action_type,
        action_source=ActionSource.PLANNER,
        planning_mode="PLAN_AVAILABLE",
        planning_status="IDLE",
        replanning_active=replanning,
        is_available=True,
    )
    app = AppliedAction(
        control_status="VALID",
        steering_status="VALID",
        speed_status="VALID",
        is_available=True,
    )
    return ActionRecord(
        action_id=f"{rid}-ACT",
        record_id=rid,
        session_id=session_id,
        sequence_id=seq,
        timestamp=ts,
        frame_id=seq,
        schema_version=RECORD_SCHEMA_VERSION,
        requested=req,
        applied=app,
        triggering_observation_id=f"{session_id}-O{seq:06d}",
    )


def make_outcome(
    session_id: str = "sess-001",
    record_id: str = None,
    seq: int = 0,
    action_timestamp: float = None,
    obs_state: OutcomeObservationState = OutcomeObservationState.OBSERVED,
    hazard_after: str = "LOW",
    emergency_cleared: bool = False,
    collision_detected: bool = None,
) -> OutcomeRecord:
    rid = record_id or f"{session_id}-R{seq:06d}"
    ts = action_timestamp or time.time()
    return OutcomeRecord(
        outcome_id=f"{rid}-OUT",
        record_id=rid,
        session_id=session_id,
        sequence_id=seq,
        action_timestamp=ts,
        outcome_start_timestamp=ts,
        outcome_end_timestamp=ts + 1.0,
        observation_window_s=1.0,
        observation_state=obs_state,
        safety_state_after="SAFE",
        hazard_level_after=hazard_after,
        emergency_cleared=emergency_cleared,
        collision_detected=collision_detected,
        termination_reason="window_elapsed",
    )


def make_full_record(
    session_id: str = "sess-001",
    seq: int = 0,
    action_type: ActionType = ActionType.FOLLOW_REFERENCE,
    hazard_level: str = "LOW",
    obs_state: OutcomeObservationState = OutcomeObservationState.OBSERVED,
) -> ExperienceRecord:
    rid = _make_record_id(session_id, seq)
    ts = time.time()
    sit = make_situation(session_id, rid, seq, ts, hazard_level=hazard_level)
    act = make_action(session_id, rid, seq, ts, action_type=action_type)
    out = make_outcome(session_id, rid, seq, ts, obs_state=obs_state)
    return ExperienceRecord(
        record_id=rid,
        session_id=session_id,
        sequence_id=seq,
        schema_version=RECORD_SCHEMA_VERSION,
        created_timestamp=ts,
        last_updated_timestamp=ts,
        situation=sit,
        action=act,
        outcome=out,
        completeness=RecordCompleteness.COMPLETE,
        source_observation_id=f"{session_id}-O{seq:06d}",
    )


def make_hazard_observation(
    session_id: str = "sess-001",
    seq: int = 0,
    hazard_level: str = "HIGH",
) -> tuple:
    """Return (ExperienceObservation, CaptureEvent) for a hazard scenario."""
    obs = make_observation(
        session_id=session_id,
        seq=seq,
        hazard_level=hazard_level,
    )
    ev = make_event(
        session_id=session_id,
        seq=0,
        event_type=CaptureEventType.HAZARD_DETECTED,
    )
    return obs, ev


def make_cattle_observation(session_id: str = "sess-001", seq: int = 0):
    """Return (obs, event) for a cattle crossing scenario."""
    from core.experience.experience_types import EnvironmentSummary, SituationSummary
    obs = make_observation(session_id=session_id, seq=seq)
    obs.environment = EnvironmentSummary(
        cattle_present=True,
        nearby_object_count=1,
        world_model_validity="OK",
    )
    ev = make_event(session_id=session_id, seq=0, event_type=CaptureEventType.CATTLE_EVENT)
    return obs, ev
