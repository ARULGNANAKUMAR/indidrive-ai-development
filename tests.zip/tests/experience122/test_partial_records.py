"""Phase 12.2 — Tests: Partial, Incomplete, Degraded Records + Key Distinctions"""
import sys, os, time
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))
sys.path.insert(0, os.path.dirname(__file__))

import pytest
from exp122_helpers import (
    make_observation, make_event, make_outcome, make_record_config,
    make_full_record,
)

from core.experience.record.record_types import (
    NOT_AVAILABLE, ExperienceRecord, RecordCompleteness,
    OutcomeObservationState,
)
from core.experience.record.record_builder import RecordBuilder
from core.experience.record.record_engine import ExperienceRecordEngine
from core.experience.experience_types import CaptureDataValidity, CaptureEventType


# ------------------------------------------------------------------
# Partial: situation+action present, outcome missing

def test_partial_record_no_outcome():
    from exp122_helpers import make_situation, make_action
    r = ExperienceRecord(
        record_id="p-R000000",
        session_id="p",
        sequence_id=0,
        completeness=RecordCompleteness.PARTIAL,
        situation=make_situation("p"),
        action=make_action("p"),
        outcome=None,
    )
    assert r.completeness == RecordCompleteness.PARTIAL
    assert r.outcome is None
    d = r.to_dict()
    assert d["outcome"] is None
    assert d["completeness"] == "PARTIAL"


def test_incomplete_record_no_situation():
    r = ExperienceRecord(
        record_id="i-R000000",
        session_id="i",
        completeness=RecordCompleteness.INCOMPLETE,
    )
    assert r.situation is None
    assert r.action is None


def test_degraded_record_preserves_state():
    r = ExperienceRecord(
        record_id="d-R000000",
        session_id="d",
        completeness=RecordCompleteness.DEGRADED,
    )
    assert r.completeness == RecordCompleteness.DEGRADED


# ------------------------------------------------------------------
# Builder degrades gracefully on bad data

def test_builder_degrades_on_stale_observation():
    builder = RecordBuilder(make_record_config())
    obs = make_observation(session_id="deg-001", seq=0,
                           data_validity=CaptureDataValidity.STALE)
    sit = builder.build_situation("deg-001-R000000", obs)
    assert sit.is_stale is True


def test_builder_degrades_on_invalid_observation():
    builder = RecordBuilder(make_record_config())
    obs = make_observation(session_id="deg-002", seq=0,
                           data_validity=CaptureDataValidity.INVALID)
    sit = builder.build_situation("deg-002-R000000", obs)
    assert sit.is_degraded is True


def test_builder_outcome_incomplete_on_missing_after():
    builder = RecordBuilder(make_record_config())
    obs_before = make_observation("deg-003", seq=0)
    out = builder.build_outcome(
        "deg-003-R000000", "deg-003", 0, obs_before.timestamp,
        obs_before, None, termination_reason="no_data"
    )
    assert out.observation_state == OutcomeObservationState.INCOMPLETE
    # Must not fabricate outcome data
    assert out.ego_speed_after_ms is None


# ------------------------------------------------------------------
# Key distinction tests (from spec Step 26)

def test_distinction_emergency_cleared_not_labelled_success():
    """Emergency cleared → record must NOT label it SUCCESS."""
    out = make_outcome(emergency_cleared=True)
    assert out.emergency_cleared is True
    # No success label
    assert not hasattr(out, "success")
    assert not hasattr(out, "is_successful")
    d = out.to_dict()
    assert "success" not in d
    assert "is_successful" not in d


def test_distinction_collision_not_failed_action():
    """collision_detected=True must NOT produce 'failure' label."""
    out = make_outcome(collision_detected=True)
    assert out.collision_detected is True
    # No 'failure' or 'failed_action' field
    assert not hasattr(out, "failure")
    assert not hasattr(out, "failed_action")
    d = out.to_dict()
    assert "failure" not in d
    assert "failed_action" not in d


def test_distinction_action_unavailable_not_assumed_executed():
    """When applied action is unavailable, is_available=False — not assumed."""
    from core.experience.record.record_types import AppliedAction
    app = AppliedAction(is_available=False)
    assert app.is_available is False
    d = app.to_dict()
    assert d["is_available"] is False
    # No assumption of execution
    assert "executed" not in d
    assert "success" not in d


def test_distinction_partial_outcome_not_fabricated():
    """Partial outcome observation must not fabricate missing fields."""
    out = make_outcome(obs_state=OutcomeObservationState.PARTIAL)
    assert out.observation_state == OutcomeObservationState.PARTIAL
    # Fields we cannot observe should remain NOT_AVAILABLE or None
    # (not fabricated to look complete)
    assert out.collision_detected is None


def test_distinction_sensor_degraded_not_action_failure():
    """Sensor degradation does not imply driving action was unsuccessful."""
    from core.experience.experience_types import SafetySummary
    from exp122_helpers import make_situation
    sit = make_situation()
    sit.safety_state = "DEGRADED"
    # SituationRecord records the degraded state factually
    # But it does NOT have a 'failure' or 'bad_outcome' field
    assert not hasattr(sit, "failure")
    assert not hasattr(sit, "is_successful")
    d = sit.to_dict()
    assert "failure" not in d
    assert "is_successful" not in d


# ------------------------------------------------------------------
# Engine partial handling

def test_engine_pending_outcome_closed_as_partial_on_finalize():
    """When session ends with pending outcomes, they should become PARTIAL."""
    cfg = make_record_config(max_records=50, max_window_s=60.0)
    engine = ExperienceRecordEngine(cfg)
    engine.start_session("fin-partial-001")

    obs, ev = make_observation("fin-partial-001", seq=0, hazard_level="HIGH"), \
               make_event("fin-partial-001", seq=0, event_type=CaptureEventType.HAZARD_DETECTED)
    engine.process_observation(obs, triggering_event=ev)

    assert engine.pending_outcome_count > 0
    engine.finalize_session()

    snap = engine.get_store_snapshot()
    # After finalize, pending outcomes are closed as PARTIAL
    assert snap.total_records >= 1
