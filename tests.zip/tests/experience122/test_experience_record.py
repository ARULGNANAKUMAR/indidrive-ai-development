"""Phase 12.2 — Tests: ExperienceRecord and RecordBuilder"""
import sys, os, time
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))
sys.path.insert(0, os.path.dirname(__file__))

import pytest
from exp122_helpers import (
    make_full_record, make_situation, make_action, make_outcome,
    make_observation, make_event, make_record_config, make_hazard_observation,
)

from core.experience.record.record_types import (
    RECORD_SCHEMA_VERSION, NOT_AVAILABLE,
    ExperienceRecord, RecordCompleteness, ActionType,
)
from core.experience.record.record_builder import RecordBuilder
from core.experience.experience_types import CaptureEventType


def test_record_default_fields():
    r = ExperienceRecord()
    assert r.schema_version == RECORD_SCHEMA_VERSION
    assert r.record_id == NOT_AVAILABLE
    assert r.completeness == RecordCompleteness.UNKNOWN
    assert r.situation is None
    assert r.action is None
    assert r.outcome is None


def test_full_record_from_helper():
    r = make_full_record(session_id="sess-D", seq=0)
    assert r.record_id == "sess-D-R000000"
    assert r.situation is not None
    assert r.action is not None
    assert r.outcome is not None
    assert r.completeness == RecordCompleteness.COMPLETE


def test_record_to_dict_structure():
    r = make_full_record()
    d = r.to_dict()
    assert "record_id" in d
    assert "session_id" in d
    assert "completeness" in d
    assert "situation" in d
    assert "action" in d
    assert "outcome" in d
    assert "source_observation_id" in d


def test_record_no_success_field():
    r = make_full_record()
    assert not hasattr(r, "success")
    assert not hasattr(r, "reward")
    d = r.to_dict()
    assert "success" not in d
    assert "reward" not in d


def test_record_partial_no_outcome():
    r = ExperienceRecord(
        record_id="sess-E-R000000",
        session_id="sess-E",
        completeness=RecordCompleteness.PARTIAL,
        situation=make_situation("sess-E"),
        action=make_action("sess-E"),
        outcome=None,
    )
    assert r.outcome is None
    assert r.completeness == RecordCompleteness.PARTIAL
    d = r.to_dict()
    assert d["outcome"] is None


def test_record_no_situation():
    r = ExperienceRecord(
        record_id="x-R000000",
        session_id="x",
        completeness=RecordCompleteness.INCOMPLETE,
    )
    assert r.situation is None
    assert r.action is None


# ------------------------------------------------------------------
# RecordBuilder tests

def _builder():
    return RecordBuilder(make_record_config())


def test_builder_build_situation():
    builder = _builder()
    obs = make_observation(session_id="bs-001", seq=0, hazard_level="HIGH")
    ev = make_event(session_id="bs-001", seq=0, event_type=CaptureEventType.HAZARD_DETECTED)
    rid = "bs-001-R000000"
    sit = builder.build_situation(rid, obs, ev)
    assert sit.situation_id == f"{rid}-SIT"
    assert sit.record_id == rid
    assert sit.session_id == "bs-001"
    assert sit.triggering_event_type == CaptureEventType.HAZARD_DETECTED.value


def test_builder_build_action():
    builder = _builder()
    obs = make_observation(session_id="ba-001", seq=0)
    rid = "ba-001-R000000"
    act = builder.build_action(rid, obs)
    assert act.action_id == f"{rid}-ACT"
    assert act.record_id == rid
    assert isinstance(act.requested.action_type, ActionType)


def test_builder_build_outcome_with_after():
    builder = _builder()
    obs_before = make_observation(session_id="bo-001", seq=0)
    obs_after = make_observation(session_id="bo-001", seq=1)
    rid = "bo-001-R000000"
    out = builder.build_outcome(rid, "bo-001", 0, obs_before.timestamp,
                                obs_before, obs_after)
    assert out.outcome_id == f"{rid}-OUT"
    assert out.observation_state.value != "MISSING"


def test_builder_build_outcome_no_after():
    builder = _builder()
    obs_before = make_observation(session_id="bo-002", seq=0)
    rid = "bo-002-R000000"
    out = builder.build_outcome(rid, "bo-002", 0, obs_before.timestamp,
                                obs_before, None, termination_reason="session_end")
    from core.experience.record.record_types import OutcomeObservationState
    assert out.observation_state == OutcomeObservationState.INCOMPLETE
    assert "session_end" in out.termination_reason


def test_builder_does_not_generate_control_commands():
    """Builder must not create new steering/throttle commands."""
    builder = _builder()
    obs = make_observation()
    act = builder.build_action("r-001", obs)
    # commanded_steering_rad must be None (not generated)
    assert act.applied.commanded_steering_rad is None
    assert act.applied.commanded_acceleration_ms2 is None


def test_builder_action_source_from_safety():
    """When failsafe is active, action source should be FAILSAFE_ENGINE."""
    from core.experience.experience_types import SafetySummary
    builder = _builder()
    obs = make_observation()
    obs.safety = SafetySummary(
        safety_state="CRITICAL",
        failsafe_state="SAFE_STOP",
        supervisor_authority="NORMAL_CONTROL",
    )
    act = builder.build_action("r-002", obs)
    from core.experience.record.record_types import ActionSource
    assert act.requested.action_source == ActionSource.FAILSAFE_ENGINE


def test_builder_graceful_on_none_obs():
    """Builder must degrade gracefully, not raise."""
    builder = _builder()
    sit = builder.build_situation("r-x", None)
    assert sit is not None
    assert sit.is_degraded is True
