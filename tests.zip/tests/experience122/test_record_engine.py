"""Phase 12.2 — Tests: ExperienceRecordEngine and PipelineRecordAdapter"""
import sys, os, time
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))
sys.path.insert(0, os.path.dirname(__file__))

import pytest
from exp122_helpers import (
    make_observation, make_event, make_record_config, make_hazard_observation,
)

from core.experience.record.record_engine import ExperienceRecordEngine, _make_record_id
from core.experience.record.pipeline_record_adapter import PipelineRecordAdapter
from core.experience.record.record_types import (
    ExperienceRecordConfig, RecordCompleteness, RecordStoreStatus, NOT_AVAILABLE,
)
from core.experience.experience_types import (
    CaptureEventType, ExperienceCaptureSnapshot, SessionStatus,
)


def _engine(max_r=100, max_win=5.0):
    return ExperienceRecordEngine(make_record_config(max_records=max_r, max_window_s=max_win))


# ------------------------------------------------------------------
# Engine lifecycle

def test_engine_start_session():
    e = _engine()
    ok = e.start_session("eng-001")
    assert ok


def test_engine_invalid_session_id():
    e = _engine()
    ok = e.start_session("")
    assert not ok


def test_engine_reset():
    e = _engine()
    e.start_session("eng-002")
    obs, ev = make_hazard_observation("eng-002", seq=0)
    e.process_observation(obs, ev)
    e.reset()
    snap = e.get_store_snapshot()
    assert snap.session_id == NOT_AVAILABLE


def test_engine_process_notable_observation():
    e = _engine()
    e.start_session("eng-003")
    obs, ev = make_hazard_observation("eng-003", seq=0, hazard_level="HIGH")
    record_id = e.process_observation(obs, ev)
    assert record_id is not None
    assert record_id.startswith("eng-003-R")


def test_engine_process_normal_observation_no_record():
    """NORMAL_DRIVING observations should not create records by default."""
    e = _engine()
    e.start_session("eng-004")
    obs = make_observation("eng-004", seq=0, hazard_level="LOW")
    ev = make_event("eng-004", seq=0, event_type=CaptureEventType.NORMAL_DRIVING)
    record_id = e.process_observation(obs, ev)
    assert record_id is None


def test_engine_record_ids_are_monotonic():
    e = _engine()
    e.start_session("eng-005")
    ids = []
    for i in range(3):
        obs, ev = make_hazard_observation("eng-005", seq=i)
        rid = e.process_observation(obs, ev)
        if rid:
            ids.append(rid)
    seqs = [int(r.split("-R")[1]) for r in ids]
    assert seqs == sorted(seqs)


def test_engine_outcome_closed_by_next_observation():
    e = _engine(max_win=0.0)  # immediate window
    e.start_session("eng-006")
    obs1, ev1 = make_hazard_observation("eng-006", seq=0)
    e.process_observation(obs1, ev1)
    # Second observation should close first record's outcome
    obs2 = make_observation("eng-006", seq=1)
    obs2.frame_id = 1
    e.process_observation(obs2)
    records = e.get_recent_records()
    assert records


def test_engine_finalize_closes_pending():
    e = _engine(max_win=9999.0)  # very long window
    e.start_session("eng-007")
    obs, ev = make_hazard_observation("eng-007", seq=0)
    e.process_observation(obs, ev)
    assert e.pending_outcome_count > 0
    e.finalize_session()
    assert e.pending_outcome_count == 0


def test_engine_get_incomplete_records():
    e = _engine(max_win=9999.0)
    e.start_session("eng-008")
    obs, ev = make_hazard_observation("eng-008", seq=0)
    e.process_observation(obs, ev)
    incomplete = e.get_incomplete_records()
    # Record awaiting outcome should be incomplete
    assert len(incomplete) >= 1


def test_engine_get_record_snapshot():
    e = _engine()
    e.start_session("eng-009")
    obs, ev = make_hazard_observation("eng-009", seq=0)
    rid = e.process_observation(obs, ev)
    assert rid is not None
    snap = e.get_record_snapshot(rid)
    assert snap is not None
    assert snap.record_id == rid
    assert snap.has_situation
    assert snap.has_action


# ------------------------------------------------------------------
# Adapter

def test_adapter_start_session():
    a = PipelineRecordAdapter()
    ok = a.start_session("adap-001")
    assert ok


def test_adapter_record_observation():
    a = PipelineRecordAdapter()
    a.start_session("adap-002")
    obs, ev = make_hazard_observation("adap-002", seq=0)
    snap = a.record_observation(obs, ev)
    assert snap is not None


def test_adapter_from_capture_snapshot():
    a = PipelineRecordAdapter()
    a.start_session("adap-003")
    obs, ev = make_hazard_observation("adap-003", seq=0)
    cap_snap = ExperienceCaptureSnapshot(
        session_id="adap-003",
        session_status=SessionStatus.ACTIVE,
        recent_observations=(obs,),
        recent_events=(ev,),
        observation_count=1,
        event_count=1,
    )
    store_snap = a.record_from_snapshot(cap_snap)
    assert store_snap is not None


def test_adapter_finalize():
    a = PipelineRecordAdapter()
    a.start_session("adap-004")
    ok = a.finalize_session()
    assert ok


def test_adapter_does_not_modify_observation():
    """Adapter must be a read-only observer."""
    a = PipelineRecordAdapter()
    a.start_session("adap-005")
    obs, ev = make_hazard_observation("adap-005", seq=0)
    original_id = obs.experience_id
    a.record_observation(obs, ev)
    assert obs.experience_id == original_id  # unchanged
