"""Phase 12.2 — Tests: Temporal Consistency and Outcome Windows"""
import sys, os, time, math
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))
sys.path.insert(0, os.path.dirname(__file__))

import pytest
from exp122_helpers import (
    make_observation, make_event, make_outcome, make_record_config,
    make_situation, make_action,
)

from core.experience.record.record_validator import RecordValidator
from core.experience.record.record_builder import RecordBuilder
from core.experience.record.record_types import (
    ExperienceRecordConfig, OutcomeObservationState, RECORD_SCHEMA_VERSION,
)
from core.experience.experience_types import CaptureEventType


def _validator():
    return RecordValidator(make_record_config())


def test_situation_valid_timestamp():
    v = _validator()
    s = make_situation(timestamp=time.time())
    ok, reason = v.validate_situation(s)
    assert ok, reason


def test_situation_future_timestamp_rejected():
    v = _validator()
    s = make_situation(timestamp=time.time() + 9999.0)
    ok, reason = v.validate_situation(s)
    assert not ok
    assert "future" in reason


def test_situation_negative_timestamp_rejected():
    v = _validator()
    s = make_situation(timestamp=-1.0)
    ok, reason = v.validate_situation(s)
    assert not ok
    assert "negative" in reason


def test_action_future_timestamp_rejected():
    v = _validator()
    a = make_action(timestamp=time.time() + 9999.0)
    ok, reason = v.validate_action(a)
    assert not ok
    assert "future" in reason


def test_outcome_start_before_end():
    v = _validator()
    o = make_outcome()
    # outcome_end must be >= outcome_start
    o.outcome_end_timestamp = o.outcome_start_timestamp - 1.0
    ok, reason = v.validate_outcome(o)
    assert not ok
    assert "outcome_end_timestamp" in reason


def test_outcome_window_configurable():
    cfg = ExperienceRecordConfig(
        immediate_outcome_window_s=2.0,
        max_outcome_window_s=10.0,
    )
    assert cfg.immediate_outcome_window_s == 2.0
    assert cfg.max_outcome_window_s == 10.0


def test_builder_outcome_window_preserved():
    builder = RecordBuilder(make_record_config(immediate_window_s=3.0))
    obs_before = make_observation("tw-001", seq=0)
    obs_after = make_observation("tw-001", seq=1)
    out = builder.build_outcome(
        "tw-001-R000000", "tw-001", 0,
        obs_before.timestamp, obs_before, obs_after,
        observation_window_s=3.0,
    )
    assert out.observation_window_s == 3.0


def test_outcome_end_after_start():
    o = make_outcome()
    assert o.outcome_end_timestamp >= o.outcome_start_timestamp


def test_outcome_window_zero_is_valid():
    v = _validator()
    o = make_outcome()
    o.observation_window_s = 0.0
    ok, reason = v.validate_outcome(o)
    assert ok, reason


def test_outcome_negative_window_rejected():
    v = _validator()
    o = make_outcome()
    o.observation_window_s = -1.0
    ok, reason = v.validate_outcome(o)
    assert not ok


def test_situation_frame_id_non_negative():
    v = _validator()
    s = make_situation()
    s.frame_id = -1
    ok, reason = v.validate_situation(s)
    assert not ok
    assert "frame_id" in reason


def test_stale_situation_marked():
    """Stale data must be explicitly marked, not silently trusted."""
    from core.experience.experience_types import CaptureDataValidity
    builder = RecordBuilder(make_record_config())
    obs = make_observation("stale-001", seq=0, data_validity=CaptureDataValidity.STALE)
    sit = builder.build_situation("stale-001-R000000", obs)
    assert sit.is_stale is True
