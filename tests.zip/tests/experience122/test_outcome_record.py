"""Phase 12.2 — Tests: OutcomeRecord"""
import sys, os, time
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))
sys.path.insert(0, os.path.dirname(__file__))

import pytest
from exp122_helpers import make_outcome

from core.experience.record.record_types import (
    RECORD_SCHEMA_VERSION, NOT_AVAILABLE,
    OutcomeRecord, OutcomeObservationState,
)


def test_outcome_default_fields():
    o = OutcomeRecord()
    assert o.schema_version == RECORD_SCHEMA_VERSION
    assert o.outcome_id == NOT_AVAILABLE
    assert o.observation_state == OutcomeObservationState.UNKNOWN
    assert o.collision_detected is None
    assert o.emergency_cleared is None


def test_outcome_from_helper():
    o = make_outcome(session_id="sess-C", seq=1)
    assert o.outcome_id == "sess-C-R000001-OUT"
    assert o.record_id == "sess-C-R000001"
    assert o.session_id == "sess-C"


def test_outcome_to_dict_fields():
    o = make_outcome()
    d = o.to_dict()
    required = [
        "outcome_id", "record_id", "session_id", "schema_version",
        "action_timestamp", "outcome_start_timestamp", "outcome_end_timestamp",
        "observation_window_s", "observation_state",
        "collision_detected", "emergency_cleared", "emergency_active_after",
        "replanning_occurred", "new_event_types", "cleared_event_types",
        "unresolved_event_types", "termination_reason", "is_degraded",
        "safety_state_after", "hazard_level_after", "vehicle_state_after",
    ]
    for f in required:
        assert f in d, f"Missing field: {f}"


def test_outcome_no_success_field():
    """Phase 12.2 must NOT evaluate success/failure."""
    o = make_outcome()
    assert not hasattr(o, "success")
    assert not hasattr(o, "failure")
    assert not hasattr(o, "reward")
    assert not hasattr(o, "quality")
    d = o.to_dict()
    assert "success" not in d
    assert "failure" not in d
    assert "reward" not in d


def test_outcome_collision_detected_is_factual():
    """collision_detected is a factual observation, not an evaluation."""
    o = make_outcome(collision_detected=True)
    assert o.collision_detected is True
    # But no 'failure' or 'bad_action' field derived from it
    assert not hasattr(o, "failure")
    assert not hasattr(o, "bad_action")


def test_outcome_emergency_cleared_is_factual():
    """emergency_cleared records what happened, not whether it was good."""
    o = make_outcome(emergency_cleared=True)
    assert o.emergency_cleared is True
    # No success label
    assert not hasattr(o, "success")


def test_outcome_temporal_window():
    ts = time.time()
    o = make_outcome(action_timestamp=ts)
    assert o.action_timestamp == ts
    assert o.outcome_start_timestamp == ts
    assert o.outcome_end_timestamp >= ts


def test_outcome_all_observation_states():
    for state in OutcomeObservationState:
        o = make_outcome(obs_state=state)
        assert o.observation_state == state
        d = o.to_dict()
        assert d["observation_state"] == state.value


def test_outcome_incomplete_state():
    o = make_outcome(obs_state=OutcomeObservationState.INCOMPLETE)
    assert o.observation_state == OutcomeObservationState.INCOMPLETE


def test_outcome_id_format():
    o = make_outcome(session_id="s", seq=5)
    assert o.outcome_id == "s-R000005-OUT"
