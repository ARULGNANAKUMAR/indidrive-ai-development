"""Phase 12.2 — Tests: ExperienceRecordStore and RecordLifecycle"""
import sys, os, time
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))
sys.path.insert(0, os.path.dirname(__file__))

import pytest
from exp122_helpers import make_full_record, make_record_config

from core.experience.record.record_store import ExperienceRecordStore
from core.experience.record.record_types import (
    NOT_AVAILABLE, ExperienceRecordConfig,
    RecordCompleteness, RecordStoreStatus,
)


def _store(max_records=50):
    return ExperienceRecordStore(make_record_config(max_records=max_records))


def test_store_initial_state():
    s = _store()
    assert not s.is_active
    assert s.record_count == 0


def test_store_start_session():
    s = _store()
    ok = s.start_session("sess-s1")
    assert ok
    assert s.is_active


def test_store_invalid_session_id():
    s = _store()
    ok = s.start_session("")
    assert not ok
    ok2 = s.start_session(NOT_AVAILABLE)
    assert not ok2


def test_store_add_record():
    s = _store()
    s.start_session("sess-add")
    r = make_full_record(session_id="sess-add", seq=0)
    ok = s.add_record(r)
    assert ok
    assert s.record_count == 1


def test_store_get_record_snapshot():
    s = _store()
    s.start_session("sess-get")
    r = make_full_record(session_id="sess-get", seq=0)
    s.add_record(r)
    snap = s.get_record_snapshot(r.record_id)
    assert snap is not None
    assert snap.record_id == r.record_id
    assert snap.has_situation
    assert snap.has_action
    assert snap.has_outcome


def test_store_snapshot_not_found():
    s = _store()
    s.start_session("sess-x")
    snap = s.get_record_snapshot("nonexistent-R999999")
    assert snap is None


def test_store_get_recent_records():
    s = _store()
    s.start_session("sess-rec")
    for i in range(5):
        s.add_record(make_full_record("sess-rec", seq=i))
    recent = s.get_recent_records(n=3)
    assert len(recent) == 3


def test_store_recent_records_are_tuples():
    s = _store()
    s.start_session("sess-t")
    s.add_record(make_full_record("sess-t", seq=0))
    result = s.get_recent_records()
    assert isinstance(result, tuple)


def test_store_get_store_snapshot_idle():
    s = _store()
    snap = s.get_store_snapshot()
    assert snap.store_status == RecordStoreStatus.IDLE


def test_store_get_store_snapshot_active():
    s = _store()
    s.start_session("sess-snap")
    s.add_record(make_full_record("sess-snap", seq=0))
    snap = s.get_store_snapshot()
    assert snap.total_records == 1
    assert snap.complete_records == 1
    assert isinstance(snap.recent_records, tuple)


def test_store_update_record():
    s = _store()
    s.start_session("sess-upd")
    r = make_full_record("sess-upd", seq=0)
    s.add_record(r)
    # Update completeness
    r.completeness = RecordCompleteness.PARTIAL
    s.update_record(r)
    snap = s.get_record_snapshot(r.record_id)
    assert snap.completeness == RecordCompleteness.PARTIAL


def test_store_finalize_session():
    s = _store()
    s.start_session("sess-fin")
    ok = s.finalize_session()
    assert ok
    snap = s.get_store_snapshot()
    assert snap.store_status == RecordStoreStatus.IDLE


def test_store_clear():
    s = _store()
    s.start_session("sess-clr")
    s.add_record(make_full_record("sess-clr", seq=0))
    s.clear_session()
    assert s.record_count == 0
    assert not s.is_active


def test_store_raises_on_wrong_config():
    with pytest.raises(TypeError):
        ExperienceRecordStore(None)


def test_store_get_incomplete_records():
    s = _store()
    s.start_session("sess-inc")
    # Add one complete and one partial
    r_complete = make_full_record("sess-inc", seq=0)
    s.add_record(r_complete)
    from core.experience.record.record_types import ExperienceRecord
    r_partial = ExperienceRecord(
        record_id="sess-inc-R000001",
        session_id="sess-inc",
        sequence_id=1,
        completeness=RecordCompleteness.PARTIAL,
        situation=None, action=None, outcome=None,
    )
    s.add_record(r_partial)
    incomplete = s.get_incomplete_records()
    ids = [snap.record_id for snap in incomplete]
    assert "sess-inc-R000001" in ids
    assert "sess-inc-R000000" not in ids


def test_store_no_session_add_fails():
    s = _store()
    r = make_full_record("no-sess", seq=0)
    ok = s.add_record(r)
    assert not ok
