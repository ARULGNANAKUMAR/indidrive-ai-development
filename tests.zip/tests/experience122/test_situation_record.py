"""Phase 12.2 — Tests: SituationRecord"""
import sys, os, time
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))
sys.path.insert(0, os.path.dirname(__file__))

import pytest
from exp122_helpers import make_situation

from core.experience.record.record_types import (
    RECORD_SCHEMA_VERSION, NOT_AVAILABLE, SituationRecord, RecordCompleteness
)


def test_situation_default_fields():
    s = SituationRecord()
    assert s.schema_version == RECORD_SCHEMA_VERSION
    assert s.situation_id == NOT_AVAILABLE
    assert s.session_id == NOT_AVAILABLE
    assert s.reasoning_confidence == 0.0
    assert s.reasoning_uncertainty == 1.0


def test_situation_from_helper():
    s = make_situation(session_id="sess-A", seq=3)
    assert s.situation_id == "sess-A-R000003-SIT"
    assert s.record_id == "sess-A-R000003"
    assert s.session_id == "sess-A"
    assert s.sequence_id == 3


def test_situation_to_dict_fields():
    s = make_situation()
    d = s.to_dict()
    required = [
        "situation_id", "record_id", "session_id", "timestamp", "frame_id",
        "schema_version", "triggering_observation_id", "triggering_event_id",
        "road_type", "hazard_level", "situation_type", "safety_state",
        "reasoning_confidence", "reasoning_uncertainty", "is_degraded", "is_stale",
        "cattle_present", "vulnerable_road_user_present",
    ]
    for field in required:
        assert field in d, f"Missing field: {field}"


def test_situation_no_success_field():
    """Phase 12.2 must NOT have success/reward/quality fields."""
    s = make_situation()
    assert not hasattr(s, "success")
    assert not hasattr(s, "reward")
    assert not hasattr(s, "quality")
    d = s.to_dict()
    assert "success" not in d
    assert "reward" not in d


def test_situation_hazard_preserved():
    s = make_situation(hazard_level="HIGH")
    assert s.hazard_level == "HIGH"
    assert s.to_dict()["hazard_level"] == "HIGH"


def test_situation_indian_road_context():
    s = make_situation(cattle=True, vru=True)
    assert s.cattle_present is True
    assert s.vulnerable_road_user_present is True
    d = s.to_dict()
    assert d["cattle_present"] is True
    assert d["vulnerable_road_user_present"] is True


def test_situation_schema_version():
    s = make_situation()
    assert s.schema_version == RECORD_SCHEMA_VERSION


def test_situation_confidence_range():
    s = make_situation()
    assert 0.0 <= s.reasoning_confidence <= 1.0
    assert 0.0 <= s.reasoning_uncertainty <= 1.0


def test_situation_id_format():
    s = make_situation(session_id="my-sess", seq=7)
    assert s.situation_id == "my-sess-R000007-SIT"
    assert s.record_id == "my-sess-R000007"
