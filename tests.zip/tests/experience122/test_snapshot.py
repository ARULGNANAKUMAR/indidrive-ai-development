"""Phase 12.2 — Tests: Snapshot and Snapshot Immutability"""
import sys, os, time
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))
sys.path.insert(0, os.path.dirname(__file__))

import pytest
from exp122_helpers import make_full_record, make_record_config

from core.experience.record.record_store import ExperienceRecordStore
from core.experience.record.record_types import (
    RECORD_SCHEMA_VERSION, ExperienceRecordSnapshot,
    RecordCompleteness, RecordStoreStatus, NOT_AVAILABLE,
)


def test_snapshot_is_frozen():
    """ExperienceRecordSnapshot is a frozen dataclass — immutable."""
    snap = ExperienceRecordSnapshot(record_id="r-001", session_id="s")
    with pytest.raises((AttributeError, TypeError)):
        snap.record_id = "modified"  # type: ignore


def test_snapshot_to_dict_fields():
    snap = ExperienceRecordSnapshot(
        record_id="r-001",
        session_id="s",
        completeness=RecordCompleteness.COMPLETE,
        has_situation=True,
        has_action=True,
        has_outcome=True,
    )
    d = snap.to_dict()
    required = [
        "record_id", "session_id", "schema_version", "completeness",
        "has_situation", "has_action", "has_outcome",
        "created_timestamp", "last_updated_timestamp",
        "source_observation_id", "source_event_ids",
    ]
    for f in required:
        assert f in d, f"Missing: {f}"


def test_snapshot_schema_version():
    snap = ExperienceRecordSnapshot()
    assert snap.schema_version == RECORD_SCHEMA_VERSION


def test_store_snapshot_returns_immutable():
    """Store snapshots must return frozen ExperienceRecordSnapshot objects."""
    store = ExperienceRecordStore(make_record_config())
    store.start_session("snap-001")
    r = make_full_record("snap-001", seq=0)
    store.add_record(r)
    snap = store.get_record_snapshot(r.record_id)
    assert isinstance(snap, ExperienceRecordSnapshot)
    with pytest.raises((AttributeError, TypeError)):
        snap.record_id = "bad"  # type: ignore


def test_store_snapshot_recent_is_tuple():
    store = ExperienceRecordStore(make_record_config())
    store.start_session("snap-002")
    store.add_record(make_full_record("snap-002", seq=0))
    result = store.get_recent_records()
    assert isinstance(result, tuple)


def test_store_snapshot_consistent_on_double_read():
    store = ExperienceRecordStore(make_record_config())
    store.start_session("snap-003")
    store.add_record(make_full_record("snap-003", seq=0))
    s1 = store.get_store_snapshot()
    s2 = store.get_store_snapshot()
    assert s1.total_records == s2.total_records
    assert s1.session_id == s2.session_id


def test_record_store_snapshot_failure_state():
    from core.experience.record.record_types import RecordStoreSnapshot
    snap = RecordStoreSnapshot(
        store_failed=True,
        failure_reason="test",
        store_status=RecordStoreStatus.FAILED,
    )
    assert snap.store_failed is True
    d = snap.to_dict()
    assert d["store_failed"] is True


def test_snapshot_situation_dict_is_copy():
    """Snapshot situation_dict is a dict — not a live reference."""
    store = ExperienceRecordStore(make_record_config())
    store.start_session("snap-004")
    r = make_full_record("snap-004", seq=0)
    store.add_record(r)
    snap = store.get_record_snapshot(r.record_id)
    assert snap.situation_dict is not None
    assert isinstance(snap.situation_dict, dict)
    # Mutating the dict does not affect the store
    snap.situation_dict["hazard_level"] = "MODIFIED"
    snap2 = store.get_record_snapshot(r.record_id)
    assert snap2.situation_dict["hazard_level"] != "MODIFIED"
