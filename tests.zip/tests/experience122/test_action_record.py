"""Phase 12.2 — Tests: ActionRecord"""
import sys, os, time
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))
sys.path.insert(0, os.path.dirname(__file__))

import pytest
from exp122_helpers import make_action

from core.experience.record.record_types import (
    RECORD_SCHEMA_VERSION, NOT_AVAILABLE,
    ActionRecord, ActionType, ActionSource,
    RequestedAction, AppliedAction,
)


def test_action_default_fields():
    a = ActionRecord()
    assert a.schema_version == RECORD_SCHEMA_VERSION
    assert a.action_id == NOT_AVAILABLE
    assert a.requested.action_type == ActionType.UNKNOWN_ACTION
    assert a.applied.is_available is False


def test_action_from_helper():
    a = make_action(session_id="sess-B", seq=2)
    assert a.action_id == "sess-B-R000002-ACT"
    assert a.record_id == "sess-B-R000002"
    assert a.session_id == "sess-B"
    assert a.sequence_id == 2


def test_action_to_dict_fields():
    a = make_action()
    d = a.to_dict()
    required = [
        "action_id", "record_id", "session_id", "timestamp", "frame_id",
        "schema_version", "requested", "applied", "is_degraded", "is_stale",
    ]
    for f in required:
        assert f in d, f"Missing field: {f}"
    assert "action_type" in d["requested"]
    assert "action_source" in d["requested"]
    assert "is_available" in d["requested"]
    assert "control_status" in d["applied"]
    assert "is_available" in d["applied"]


def test_action_requested_vs_applied_distinction():
    """Requested and applied actions must be separately preserved."""
    a = make_action(action_type=ActionType.REPLAN)
    assert a.requested.action_type == ActionType.REPLAN
    # Applied tracks control-level state, not planning
    assert a.applied.control_status == "VALID"


def test_action_no_success_field():
    a = make_action()
    assert not hasattr(a, "success")
    assert not hasattr(a, "reward")
    d = a.to_dict()
    assert "success" not in d
    assert "reward" not in d


def test_all_action_types_valid():
    for at in ActionType:
        a = make_action(action_type=at)
        assert a.requested.action_type == at
        d = a.to_dict()
        assert d["requested"]["action_type"] == at.value


def test_action_source_classification():
    a = make_action()
    assert a.requested.action_source == ActionSource.PLANNER
    d = a.to_dict()
    assert d["requested"]["action_source"] == "PLANNER"


def test_action_availability_flag():
    """is_available=False means control output was missing."""
    a = ActionRecord()
    assert a.requested.is_available is False
    assert a.applied.is_available is False


def test_action_replanning_state_preserved():
    a = make_action(action_type=ActionType.REPLAN, replanning=True)
    assert a.requested.replanning_active is True
    assert a.requested.action_type == ActionType.REPLAN


def test_action_id_format():
    a = make_action(session_id="x", seq=42)
    assert a.action_id == "x-R000042-ACT"
