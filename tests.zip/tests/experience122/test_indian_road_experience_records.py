"""Phase 12.2 — Tests: Indian Road Scenario Experience Records"""
import sys, os, time
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))
sys.path.insert(0, os.path.dirname(__file__))

import pytest
from exp122_helpers import (
    make_observation, make_event, make_record_config,
    make_cattle_observation, make_hazard_observation,
)

from core.experience.record.record_engine import ExperienceRecordEngine
from core.experience.record.record_types import RecordCompleteness, ActionType
from core.experience.experience_types import CaptureEventType


def _engine():
    return ExperienceRecordEngine(make_record_config(max_records=100, max_window_s=2.0))


def _run(engine, obs, ev):
    engine.process_observation(obs, triggering_event=ev)
    return engine.get_store_snapshot()


def test_cattle_crossing_record_created():
    engine = _engine()
    engine.start_session("indian-001")
    obs, ev = make_cattle_observation("indian-001", seq=0)
    snap = _run(engine, obs, ev)
    assert snap.total_records >= 1


def test_cattle_crossing_situation_preserves_cattle_flag():
    engine = _engine()
    engine.start_session("indian-002")
    obs, ev = make_cattle_observation("indian-002", seq=0)
    engine.process_observation(obs, triggering_event=ev)
    records = engine.get_recent_records()
    assert records
    sit = records[-1].situation_dict
    assert sit is not None
    assert sit.get("cattle_present") is True


def test_hazard_detected_record_created():
    engine = _engine()
    engine.start_session("indian-003")
    obs, ev = make_hazard_observation("indian-003", seq=0, hazard_level="HIGH")
    snap = _run(engine, obs, ev)
    assert snap.total_records >= 1


def test_hazard_situation_preserves_hazard_level():
    engine = _engine()
    engine.start_session("indian-004")
    obs, ev = make_hazard_observation("indian-004", seq=0, hazard_level="CRITICAL")
    engine.process_observation(obs, triggering_event=ev)
    records = engine.get_recent_records()
    sit = records[-1].situation_dict
    assert sit["hazard_level"] == "CRITICAL"


def test_intersection_event_record():
    engine = _engine()
    engine.start_session("indian-005")
    obs = make_observation("indian-005", seq=0)
    ev = make_event("indian-005", seq=0, event_type=CaptureEventType.INTERSECTION_EVENT)
    snap = _run(engine, obs, ev)
    assert snap.total_records >= 1


def test_vru_event_record():
    engine = _engine()
    engine.start_session("indian-006")
    obs = make_observation("indian-006", seq=0)
    from core.experience.experience_types import EnvironmentSummary
    obs.environment = EnvironmentSummary(
        vulnerable_road_user_present=True, nearby_object_count=2,
        world_model_validity="OK",
    )
    ev = make_event("indian-006", seq=0, event_type=CaptureEventType.VULNERABLE_USER_EVENT)
    engine.process_observation(obs, triggering_event=ev)
    records = engine.get_recent_records()
    sit = records[-1].situation_dict
    assert sit.get("vulnerable_road_user_present") is True


def test_replanning_record():
    engine = _engine()
    engine.start_session("indian-007")
    obs = make_observation("indian-007", seq=0)
    from core.experience.experience_types import PlanningSummary
    obs.planning = PlanningSummary(
        planning_mode="PLAN_AVAILABLE",
        replanning_active=True,
        replanning_reason="PATH_RISK",
    )
    ev = make_event("indian-007", seq=0, event_type=CaptureEventType.REPLANNING_TRIGGERED)
    engine.process_observation(obs, triggering_event=ev)
    records = engine.get_recent_records()
    assert records
    act = records[-1].action_dict
    assert act is not None
    assert act["requested"]["replanning_active"] is True
    assert act["requested"]["action_type"] == ActionType.REPLAN.value


def test_road_hazard_record():
    engine = _engine()
    engine.start_session("indian-008")
    obs = make_observation("indian-008", seq=0)
    from core.experience.experience_types import EnvironmentSummary
    obs.environment = EnvironmentSummary(
        road_hazard_present=True,
        road_anomaly_summary="POTHOLE:1",
        world_model_validity="OK",
    )
    ev = make_event("indian-008", seq=0, event_type=CaptureEventType.ROAD_HAZARD_EVENT)
    engine.process_observation(obs, triggering_event=ev)
    records = engine.get_recent_records()
    sit = records[-1].situation_dict
    assert sit.get("road_hazard_present") is True


def test_emergency_record_and_no_success_label():
    """Emergency scenario recorded — must NOT carry success label."""
    engine = _engine()
    engine.start_session("indian-009")
    obs = make_observation("indian-009", seq=0)
    from core.experience.experience_types import SafetySummary
    obs.safety = SafetySummary(safety_state="CRITICAL", emergency_state="ACTIVE")
    ev = make_event("indian-009", seq=0, event_type=CaptureEventType.EMERGENCY_DETECTED)
    engine.process_observation(obs, triggering_event=ev)

    records = engine.get_recent_records()
    assert records
    act_dict = records[-1].action_dict
    # Emergency response recorded
    assert act_dict["requested"]["action_type"] == ActionType.EMERGENCY_RESPONSE_STATE.value
    # No success label anywhere in the dict
    assert "success" not in act_dict
    assert "success" not in act_dict["requested"]


def test_narrow_road_event_record():
    engine = _engine()
    engine.start_session("indian-010")
    obs = make_observation("indian-010", seq=0)
    ev = make_event("indian-010", seq=0, event_type=CaptureEventType.NARROW_ROAD_EVENT)
    snap = _run(engine, obs, ev)
    assert snap.total_records >= 1


def test_outcome_window_closes_with_next_observation():
    """Second observation closes outcome window of first record."""
    engine = _engine()
    engine.start_session("indian-011")
    obs1, ev1 = make_hazard_observation("indian-011", seq=0)
    engine.process_observation(obs1, triggering_event=ev1)

    obs2 = make_observation("indian-011", seq=1)
    engine.process_observation(obs2)

    records = engine.get_recent_records()
    # At least one record should be COMPLETE (outcome closed by obs2)
    completeness_values = [r.completeness.value for r in records]
    assert any(c in ("COMPLETE", "PARTIAL", "ACTION_ATTACHED") for c in completeness_values)
