"""
IndiDrive AI — Phase 10.5 | Tests: Determinism, Adapter, Indian Roads, Negative Scope
======================================================================================
"""
from __future__ import annotations
import math
import sys
import os
import time

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))

from core.integration import (
    AutonomousPipeline, PipelineConfig, PipelineStatus,
    adapt_planner_to_reference, make_minimal_reference,
)
from core.integration.pipeline_types import StageStatus
from tests.integration105.helpers import (
    default_pipeline_config, make_ego_state, make_straight_reference,
    make_straight_path, make_curved_path, make_candidate_set,
    make_valid_planner_output,
)


def _pipeline(cfg=None):
    p = AutonomousPipeline(cfg or default_pipeline_config())
    p.initialize(make_ego_state(velocity=5.0))
    return p


# ---------------------------------------------------------------------------
# Determinism tests
# ---------------------------------------------------------------------------

class TestDeterminism:
    def test_identical_inputs_identical_next_state(self):
        """Same initial state + same reference → identical next state."""
        FIXED_TS = 100.0

        def run_once():
            p = AutonomousPipeline(PipelineConfig.default())
            ego = make_ego_state(velocity=5.0, frame_id=0, timestamp=FIXED_TS)
            p.initialize(ego)
            ref = make_straight_reference(
                length_m=30.0, n_points=15, speed=5.0,
                frame_id=0, timestamp=FIXED_TS,
            )
            snap = p.step_with_reference(ref, frame_id=1)
            ns = snap.next_vehicle_state
            return (round(ns.x, 9), round(ns.y, 9), round(ns.yaw, 9),
                    round(ns.velocity, 9))

        r1 = run_once()
        r2 = run_once()
        r3 = run_once()
        assert r1 == r2 == r3, f"Non-deterministic: {r1} != {r2}"

    def test_different_initial_speed_different_output(self):
        FIXED_TS = 100.0

        def run(speed):
            p = AutonomousPipeline(PipelineConfig.default())
            ego = make_ego_state(velocity=speed, frame_id=0, timestamp=FIXED_TS)
            p.initialize(ego)
            ref = make_straight_reference(timestamp=FIXED_TS)
            snap = p.step_with_reference(ref)
            return snap.next_vehicle_state.x if snap.has_next_state else None

        x1 = run(3.0)
        x2 = run(8.0)
        assert x1 != x2, "Different initial speeds should yield different positions"

    def test_multi_cycle_determinism(self):
        """Same 5-cycle run must reproduce the same final position."""
        FIXED_TS = 200.0

        def run_5():
            p = AutonomousPipeline(PipelineConfig.default())
            ego = make_ego_state(velocity=5.0, timestamp=FIXED_TS)
            p.initialize(ego)
            last_x = 0.0
            for i in range(5):
                ref = make_straight_reference(
                    length_m=30.0, n_points=15, speed=5.0,
                    timestamp=FIXED_TS + i * 0.1,
                )
                snap = p.step_with_reference(ref)
                if snap.has_next_state:
                    last_x = snap.next_vehicle_state.x
            return round(last_x, 8)

        assert run_5() == run_5()


# ---------------------------------------------------------------------------
# Reference adapter tests
# ---------------------------------------------------------------------------

class TestReferenceAdapter:
    def test_adapt_valid_planner_output(self):
        path = make_straight_path(n_points=10, candidate_id="straight_1")
        cset = make_candidate_set([path])
        out  = make_valid_planner_output(candidate_id="straight_1")
        ref, reason = adapt_planner_to_reference(
            out, cset, ref_speed_mps=5.0, timestamp=time.monotonic()
        )
        assert ref is not None, f"Expected ref, got None; reason: {reason}"
        assert reason == ""
        assert not ref.is_empty

    def test_adapt_none_planner_output(self):
        ref, reason = adapt_planner_to_reference(
            None, None, ref_speed_mps=5.0, timestamp=time.monotonic()
        )
        assert ref is None
        assert len(reason) > 0

    def test_adapt_no_valid_plan(self):
        from tests.integration105.helpers import make_no_plan_planner_output
        out = make_no_plan_planner_output()
        ref, reason = adapt_planner_to_reference(
            out, None, ref_speed_mps=5.0, timestamp=time.monotonic()
        )
        assert ref is None

    def test_adapt_none_candidate_set(self):
        out = make_valid_planner_output(candidate_id="some_id")
        ref, reason = adapt_planner_to_reference(
            out, None, ref_speed_mps=5.0, timestamp=time.monotonic()
        )
        assert ref is None
        assert "candidate_set" in reason.lower() or len(reason) > 0

    def test_adapt_candidate_not_found(self):
        path = make_straight_path(candidate_id="path_A")
        cset = make_candidate_set([path])
        out  = make_valid_planner_output(candidate_id="path_B")  # wrong ID
        ref, reason = adapt_planner_to_reference(
            out, cset, ref_speed_mps=5.0, timestamp=time.monotonic()
        )
        assert ref is None

    def test_make_minimal_reference(self):
        ref = make_minimal_reference(x_end=20.0, speed=5.0, n_points=10)
        assert not ref.is_empty
        assert ref.length == 10

    def test_reference_has_correct_length(self):
        path = make_straight_path(n_points=8, candidate_id="test_8")
        cset = make_candidate_set([path])
        out  = make_valid_planner_output(candidate_id="test_8")
        ref, _ = adapt_planner_to_reference(
            out, cset, ref_speed_mps=5.0, timestamp=time.monotonic()
        )
        assert ref is not None
        assert ref.length == 8


# ---------------------------------------------------------------------------
# Indian road scenario closed-loop tests
# ---------------------------------------------------------------------------

class TestIndianRoadScenarios:
    """
    All inputs are prepared explicitly — no scenario-name-based controller logic.
    The pipeline reacts only to actual reference trajectories and vehicle states.
    """

    def _run_scenario(self, speed: float, length_m: float = 30.0,
                       n_points: int = 15, n_cycles: int = 3) -> list:
        p = AutonomousPipeline(default_pipeline_config())
        p.initialize(make_ego_state(velocity=speed))
        snaps = []
        for _ in range(n_cycles):
            ref = make_straight_reference(length_m=length_m, n_points=n_points,
                                          speed=speed)
            s = p.step_with_reference(ref)
            snaps.append(s)
        return snaps

    # Village road — low speed
    def test_village_road_low_speed(self):
        snaps = self._run_scenario(speed=6.94)  # 25 km/h
        assert all(s.is_completed for s in snaps)
        assert all(math.isfinite(s.next_vehicle_state.x)
                   for s in snaps if s.has_next_state)

    # Dense market — very low speed
    def test_dense_market_low_speed(self):
        snaps = self._run_scenario(speed=4.17)  # 15 km/h
        assert all(s.is_completed or s.pipeline_status == PipelineStatus.DEGRADED
                   for s in snaps)

    # Highway — high speed
    def test_highway_merge_high_speed(self):
        snaps = self._run_scenario(speed=22.2, length_m=50.0)  # 80 km/h
        assert all(s.is_completed for s in snaps)

    # Cattle crossing — braking input
    def test_cattle_crossing_decel(self):
        """Test that pipeline handles low target speed (stop ahead)."""
        p = AutonomousPipeline(default_pipeline_config())
        p.initialize(make_ego_state(velocity=12.0))
        # Provide ref speed = 0 to simulate stopping
        ref = make_straight_reference(length_m=10.0, n_points=8, speed=0.5)
        snap = p.step_with_reference(ref, ref_speed_mps=0.5)
        assert snap.is_completed or snap.pipeline_status == PipelineStatus.DEGRADED
        if snap.has_next_state:
            assert math.isfinite(snap.next_vehicle_state.velocity)

    # Narrow road — slow, with reference
    def test_narrow_road_slow(self):
        snaps = self._run_scenario(speed=3.0, length_m=15.0)
        assert all(s.has_next_state for s in snaps)

    # Damaged road — slow, stable
    def test_damaged_road_stable(self):
        p = AutonomousPipeline(default_pipeline_config())
        p.initialize(make_ego_state(velocity=3.5))
        for _ in range(5):
            ref = make_straight_reference(length_m=10.0, speed=3.0)
            s = p.step_with_reference(ref)
            if s.has_next_state:
                assert math.isfinite(s.next_vehicle_state.x)
                assert s.next_vehicle_state.velocity >= 0.0

    def test_no_scenario_hardcoding_in_pipeline(self):
        """Pipeline behavior must NOT depend on scenario name strings."""
        import core.integration.autonomous_pipeline as ap
        src = open(ap.__file__).read()
        forbidden = ['== "cattle"', '== "market"', '== "highway"',
                     '== "village"', '== "narrow"']
        for f in forbidden:
            assert f not in src, f"Found scenario hardcoding: {f}"


# ---------------------------------------------------------------------------
# Negative scope tests
# ---------------------------------------------------------------------------

class TestNegativeScope:
    def _code_only(self, src):
        lines = []
        in_ds = False
        for line in src.splitlines():
            s = line.strip()
            if '"""' in s or "\'\'\'" in s:
                cnt = s.count('"""') + s.count("\'\'\'")
                if cnt % 2 != 0:
                    in_ds = not in_ds
                    continue
                if in_ds:
                    continue
            if in_ds or s.startswith("#"):
                continue
            lines.append(line)
        return "\n".join(lines)

    def test_no_pid_in_pipeline(self):
        import core.integration.autonomous_pipeline as ap
        code = self._code_only(open(ap.__file__).read())
        assert "PID(" not in code

    def test_no_pure_pursuit_in_pipeline(self):
        import core.integration.autonomous_pipeline as ap
        code = self._code_only(open(ap.__file__).read())
        assert "pure_pursuit(" not in code.lower()

    def test_no_carla_apply_control(self):
        import core.integration.autonomous_pipeline as ap
        code = self._code_only(open(ap.__file__).read())
        assert "apply_control(" not in code

    def test_no_can_bus(self):
        import core.integration.autonomous_pipeline as ap
        code = self._code_only(open(ap.__file__).read()).lower()
        assert "can.send" not in code

    def test_no_llm_calls(self):
        import core.integration.autonomous_pipeline as ap
        code = self._code_only(open(ap.__file__).read()).lower()
        for word in ["openai.chatcompletion", "gpt-4.call", "anthropic.messages.create"]:
            assert word not in code

    def test_no_new_mpc_optimization(self):
        import core.integration.autonomous_pipeline as ap
        src = open(ap.__file__).read()
        assert "MPCSolver(" not in src
        assert "grid_search(" not in src

    def test_no_new_planning_algorithms(self):
        import core.integration.autonomous_pipeline as ap
        src = open(ap.__file__).read()
        for alg in ["A_star(", "dijkstra(", "RRT(", "generate_candidates("]:
            assert alg not in src

    def test_no_hardware_actuators(self):
        import core.integration.autonomous_pipeline as ap
        code = self._code_only(open(ap.__file__).read()).lower()
        assert "can.send(" not in code

    def test_pipeline_uses_existing_bicycle_model(self):
        import core.integration.autonomous_pipeline as ap
        src = open(ap.__file__).read()
        assert "KinematicBicycleModel" in src
