"""
IndiDrive AI — Phase 10.5 | Test Helpers
=========================================
Shared builders for Phase 10.5 integration tests.
"""
from __future__ import annotations

import math
import time
import uuid
from typing import Optional, Tuple, List

import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))

from core.vehicle.vehicle_state import VehicleState
from core.vehicle.vehicle_types import CoordinateFrame, StateKind
from core.planning.planner_types import (
    PlannerInput, PlannerOutput, PlannerStatus, PlannerSnapshot,
    PlannerMetrics, CandidateSummary, RiskSummary, ReplanSummary,
    InputValidationStatus, NOT_AVAILABLE,
)
from core.planning.candidate_path_types import (
    CandidatePath, CandidatePathSet, PathPoint,
    CandidateGenerationStatus, GeometricValidity,
)
from core.tracking.reference_trajectory import ReferenceTrajectory
from core.integration.pipeline_config import PipelineConfig


# ---------------------------------------------------------------------------
# VehicleState builders
# ---------------------------------------------------------------------------

def make_ego_state(
    x: float = 0.0,
    y: float = 0.0,
    yaw: float = 0.0,
    velocity: float = 5.0,
    frame_id: int = 0,
    timestamp: Optional[float] = None,
) -> VehicleState:
    if timestamp is None:
        timestamp = time.monotonic()
    return VehicleState(
        x=x, y=y, yaw=yaw, velocity=velocity,
        frame_id=frame_id, timestamp=timestamp,
        coordinate_frame=CoordinateFrame.VEHICLE,
        state_kind=StateKind.SIMULATED,
    )


# ---------------------------------------------------------------------------
# PathPoint / CandidatePath / CandidatePathSet builders
# ---------------------------------------------------------------------------

def make_straight_path(
    n_points: int = 10,
    length_m: float = 20.0,
    candidate_id: str = "test_straight",
) -> CandidatePath:
    step = length_m / max(n_points - 1, 1)
    wps = tuple(
        PathPoint(x=i * step, y=0.0, z=0.0,
                  longitudinal_s=i * step, lateral_offset_m=0.0,
                  heading=0.0, curvature=0.0)
        for i in range(n_points)
    )
    return CandidatePath(
        candidate_id=candidate_id,
        _waypoints=wps,
        generation_method=__import__(
            "core.planning.candidate_path_types",
            fromlist=["GenerationMethod"]
        ).GenerationMethod.LATERAL_OFFSET,
        geometric_validity=GeometricValidity.VALID,
    )


def make_curved_path(
    n_points: int = 10,
    length_m: float = 20.0,
    curvature: float = 0.05,
    candidate_id: str = "test_curved",
) -> CandidatePath:
    step = length_m / max(n_points - 1, 1)
    wps = []
    for i in range(n_points):
        s = i * step
        angle = curvature * s
        x = s * math.cos(angle / 2) if curvature != 0 else s
        y = s * math.sin(angle / 2) if curvature != 0 else 0.0
        wps.append(PathPoint(
            x=x, y=y, z=0.0,
            longitudinal_s=s, lateral_offset_m=0.0,
            heading=angle, curvature=curvature,
        ))
    return CandidatePath(
        candidate_id=candidate_id,
        _waypoints=tuple(wps),
        generation_method=__import__(
            "core.planning.candidate_path_types",
            fromlist=["GenerationMethod"]
        ).GenerationMethod.LATERAL_OFFSET,
        geometric_validity=GeometricValidity.VALID,
    )


def make_candidate_set(paths: list) -> CandidatePathSet:
    return CandidatePathSet(
        set_id=str(uuid.uuid4()),
        _candidates=tuple(paths),
        planning_allowed=True,
        generation_status=CandidateGenerationStatus.CANDIDATES_GENERATED,
    )


# ---------------------------------------------------------------------------
# PlannerOutput builder
# ---------------------------------------------------------------------------

def make_valid_planner_output(
    candidate_id: str = "test_straight",
    frame_id: int = 0,
    timestamp: Optional[float] = None,
) -> PlannerOutput:
    if timestamp is None:
        timestamp = time.monotonic()
    return PlannerOutput(
        frame_id=frame_id,
        timestamp=timestamp,
        planning_allowed=True,
        safety_gate_state="CLEAR",
        planning_status=PlannerStatus.PLAN_AVAILABLE,
        input_validation_status=InputValidationStatus.VALID,
        candidate_count=1,
        candidate_paths_available=True,
        risk_evaluations_available=True,
        selected_candidate_id=candidate_id,
        replanning_required=False,
        confidence=0.9,
        uncertainty=0.1,
        degraded=False,
        stale=False,
        reason_codes=(),
        warnings=(),
        validation_errors=(),
        candidate_summary=CandidateSummary(),
        risk_summary=RiskSummary(),
        replan_summary=ReplanSummary(),
    )


def make_blocked_planner_output(frame_id: int = 0) -> PlannerOutput:
    return PlannerOutput(
        frame_id=frame_id,
        timestamp=time.monotonic(),
        planning_allowed=False,
        safety_gate_state="CRITICAL",
        planning_status=PlannerStatus.SAFETY_RESTRICTED,
        input_validation_status=InputValidationStatus.VALID,
        candidate_count=0,
        candidate_paths_available=False,
        risk_evaluations_available=False,
        selected_candidate_id=NOT_AVAILABLE,
        replanning_required=False,
        confidence=0.0,
        uncertainty=1.0,
        degraded=True,
        stale=False,
        reason_codes=("SAFETY_RESTRICTED",),
        warnings=(),
        validation_errors=(),
        candidate_summary=CandidateSummary(),
        risk_summary=RiskSummary(),
        replan_summary=ReplanSummary(),
    )


def make_no_plan_planner_output(frame_id: int = 0) -> PlannerOutput:
    return PlannerOutput(
        frame_id=frame_id,
        timestamp=time.monotonic(),
        planning_allowed=True,
        safety_gate_state="CLEAR",
        planning_status=PlannerStatus.BLOCKED,
        input_validation_status=InputValidationStatus.VALID,
        candidate_count=0,
        candidate_paths_available=False,
        risk_evaluations_available=False,
        selected_candidate_id=NOT_AVAILABLE,
        confidence=0.0,
        uncertainty=1.0,
        degraded=True,
        stale=False,
        reason_codes=("NO_CANDIDATES",),
        warnings=(), validation_errors=(),
        candidate_summary=CandidateSummary(),
        risk_summary=RiskSummary(),
        replan_summary=ReplanSummary(),
    )


# ---------------------------------------------------------------------------
# PlannerInput builder
# ---------------------------------------------------------------------------

def make_planner_input(
    candidate_set: Optional[CandidatePathSet] = None,
    frame_id: int = 0,
    timestamp: Optional[float] = None,
) -> PlannerInput:
    if timestamp is None:
        timestamp = time.monotonic()
    return PlannerInput(
        frame_id=frame_id,
        timestamp=timestamp,
        candidate_set=candidate_set,
    )


# ---------------------------------------------------------------------------
# PipelineConfig builders
# ---------------------------------------------------------------------------

def default_pipeline_config() -> PipelineConfig:
    return PipelineConfig.default()


def fast_config(max_cycles: int = 5) -> PipelineConfig:
    return PipelineConfig(
        enabled=True,
        dt=0.1,
        max_cycles=max_cycles,
        stale_timeout_s=2.0,
        ref_speed_mps=5.0,
    )


# ---------------------------------------------------------------------------
# Reference trajectory builder (bypass planner for direct tests)
# ---------------------------------------------------------------------------

def make_straight_reference(
    length_m: float = 20.0,
    n_points: int = 10,
    speed: float = 5.0,
    frame_id: int = 0,
    timestamp: Optional[float] = None,
) -> ReferenceTrajectory:
    from core.integration.reference_adapter import make_minimal_reference
    if timestamp is None:
        timestamp = time.monotonic()
    return make_minimal_reference(
        x_end=length_m, speed=speed,
        n_points=n_points, frame_id=frame_id, timestamp=timestamp,
    )
