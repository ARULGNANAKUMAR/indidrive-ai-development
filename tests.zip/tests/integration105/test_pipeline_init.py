"""
IndiDrive AI — Phase 10.5 | Tests: Pipeline Config and Types
=============================================================
"""
from __future__ import annotations
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))

from core.integration.pipeline_config import PipelineConfig
from core.integration.pipeline_types import (
    PipelineStatus, StageStatus, StageResult, PipelineSnapshot,
    PIPELINE_SCHEMA_VERSION,
)
from core.integration import AutonomousPipeline

from tests.integration105.helpers import default_pipeline_config, make_ego_state


class TestPipelineConfig:
    def test_default_valid(self):
        cfg = PipelineConfig.default()
        assert cfg.enabled
        assert cfg.dt > 0
        assert cfg.stale_timeout_s > 0
        assert cfg.ref_speed_mps >= 0
        assert cfg.max_cycles >= 0

    def test_frozen(self):
        cfg = PipelineConfig.default()
        try:
            object.__setattr__(cfg, "dt", 999.0)
            assert False, "Should be frozen"
        except Exception:
            pass

    def test_invalid_dt_zero_raises(self):
        try:
            PipelineConfig(dt=0.0)
            assert False
        except ValueError:
            pass

    def test_invalid_dt_negative_raises(self):
        try:
            PipelineConfig(dt=-0.1)
            assert False
        except ValueError:
            pass

    def test_invalid_dt_nan_raises(self):
        try:
            PipelineConfig(dt=float("nan"))
            assert False
        except ValueError:
            pass

    def test_invalid_stale_timeout_raises(self):
        try:
            PipelineConfig(stale_timeout_s=0.0)
            assert False
        except ValueError:
            pass

    def test_invalid_ref_speed_negative_raises(self):
        try:
            PipelineConfig(ref_speed_mps=-1.0)
            assert False
        except ValueError:
            pass

    def test_invalid_max_cycles_negative_raises(self):
        try:
            PipelineConfig(max_cycles=-1)
            assert False
        except ValueError:
            pass

    def test_from_dict_empty_gives_defaults(self):
        cfg = PipelineConfig.from_dict({})
        default = PipelineConfig.default()
        assert cfg.dt == default.dt
        assert cfg.stale_timeout_s == default.stale_timeout_s

    def test_from_dict_custom_dt(self):
        cfg = PipelineConfig.from_dict({"dt": 0.05, "max_cycles": 10})
        assert abs(cfg.dt - 0.05) < 1e-9
        assert cfg.max_cycles == 10


class TestPipelineTypes:
    def test_pipeline_status_enum(self):
        assert PipelineStatus.COMPLETED.value == "COMPLETED"
        assert PipelineStatus.PLANNING_FAILED.value == "PLANNING_FAILED"
        assert PipelineStatus.MPC_FAILED.value == "MPC_FAILED"

    def test_stage_status_enum(self):
        assert StageStatus.PASSED.value == "PASSED"
        assert StageStatus.FAILED.value == "FAILED"
        assert StageStatus.SKIPPED.value == "SKIPPED"

    def test_stage_result_fields(self):
        sr = StageResult(stage="mpc", status=StageStatus.PASSED, reason="", duration_ms=5.0)
        assert sr.stage == "mpc"
        assert sr.status == StageStatus.PASSED
        assert sr.duration_ms == 5.0

    def test_pipeline_snapshot_defaults(self):
        snap = PipelineSnapshot()
        assert snap.schema_version == PIPELINE_SCHEMA_VERSION
        assert snap.pipeline_status == PipelineStatus.UNKNOWN
        assert not snap.is_completed
        assert not snap.has_next_state

    def test_pipeline_snapshot_frozen(self):
        snap = PipelineSnapshot()
        try:
            object.__setattr__(snap, "pipeline_status", PipelineStatus.COMPLETED)
            assert False, "Should be frozen"
        except Exception:
            pass

    def test_pipeline_snapshot_repr(self):
        snap = PipelineSnapshot(pipeline_status=PipelineStatus.COMPLETED)
        s = repr(snap)
        assert "COMPLETED" in s


class TestAutonomousPipelineInit:
    def test_wrong_config_type_raises(self):
        try:
            AutonomousPipeline({"dt": 0.1})
            assert False
        except TypeError:
            pass

    def test_initial_status_is_initializing(self):
        p = AutonomousPipeline(PipelineConfig.default())
        assert p.status == PipelineStatus.INITIALIZING

    def test_cycle_zero_before_initialize(self):
        p = AutonomousPipeline(PipelineConfig.default())
        assert p.cycle == 0

    def test_no_snapshot_before_step(self):
        p = AutonomousPipeline(PipelineConfig.default())
        assert p.get_snapshot() is None

    def test_initialize_sets_ready(self):
        p = AutonomousPipeline(PipelineConfig.default())
        ego = make_ego_state()
        p.initialize(ego)
        assert p.status == PipelineStatus.READY

    def test_step_without_initialize_returns_invalid(self):
        p = AutonomousPipeline(PipelineConfig.default())
        from core.planning.planner_types import PlannerInput
        pi = PlannerInput(frame_id=0)
        snap = p.step(pi)
        assert not snap.is_completed

    def test_reset_clears_cycle(self):
        p = AutonomousPipeline(PipelineConfig.default())
        ego = make_ego_state()
        p.initialize(ego)
        p.reset()
        assert p.cycle == 0
        assert p.status == PipelineStatus.READY
