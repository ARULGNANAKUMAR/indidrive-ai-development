"""
IndiDrive AI — Phase 7 | World Model Test Suite
================================================
Tests cover:
  - Basic construction (empty, full, partial, repeated update)
  - Object integration (single, multiple, dedup, stable-ID merge, stale)
  - Prediction integration (valid, missing, invalid, hypotheses, TTC)
  - Road integration (drivable area, lane, anomaly, missing)
  - Indian context (various road types, degraded)
  - Data quality (timestamps, stale, mismatch, confidence, uncertainty)
  - Snapshot safety (immutability, bounded counts, serialisation)
  - Determinism (same input → same output)
  - Validation (errors, warnings, structured result)
  - Performance (small, medium, max scene)

No fake data is invented to make tests pass.
All assertions test actual code behaviour.
"""
from __future__ import annotations

import copy
import math
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import List, Optional
from unittest.mock import MagicMock

import pytest

# ============================================================
# Import world model under test
# ============================================================
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))

from core.world_model import (
    WorldModel,
    WorldModelConfig,
    WorldModelStatus,
    CoordinateFrame,
    RoadRepresentationStatus,
    PredictionAvailability,
    ObjectObservationState,
    WorldObject,
    WorldObjectPosition,
    WorldObjectVelocity,
    WorldObjectDimensions,
    WorldObjectMotionSummary,
    WorldObjectPredictionSummary,
    WorldObjectCollisionInfo,
    WorldObjectQuality,
    WorldObjectLifecycle,
    WorldAnomalySummary,
    WorldRoadRepresentation,
    WorldIndianContextSummary,
    WorldDataQuality,
    WorldModelSnapshot,
    WorldModelBuildResult,
    WorldModelValidator,
    ValidationResult,
    snapshot_age_s,
    is_snapshot_stale,
    snapshot_to_json,
    snapshot_summary,
    safe_copy_snapshot,
    NOT_AVAILABLE,
)
from core.world_model.world_model_builder import WorldModelBuilder


# ============================================================
# Minimal mock helpers — only what the builder actually reads
# ============================================================

def _make_position3d(x, y, z):
    p = MagicMock()
    p.x = x
    p.y = y
    p.z = z
    return p


def _make_dims(length, width, height):
    d = MagicMock()
    d.length = length
    d.width = width
    d.height = height
    return d


def _make_fused_object(
    fused_id="fo1",
    track_id="t1",
    obj_class="VEHICLE",
    position=None,
    velocity=None,
    confidence=0.8,
    pos_confidence=0.75,
    vel_confidence=0.7,
    existence=0.9,
    lifecycle="CONFIRMED",
    heading=0.1,
    dims=None,
    timestamp=None,
    source_sensors=None,
):
    from core.fusion.fusion_types import ObjectLifecycleState
    from core.perception.perception_types import SourceSensor

    obj = MagicMock()
    obj.fused_object_id = fused_id
    obj.track_id = track_id
    obj.object_class = obj_class
    obj.class_confidence = confidence
    obj.position_confidence = pos_confidence
    obj.velocity_confidence = vel_confidence
    obj.existence_probability = existence
    obj.heading = heading
    obj.timestamp = timestamp or time.time()
    obj.position_3d = position or _make_position3d(10.0, 1.0, 0.5)
    obj.velocity = velocity or (5.0, 0.5, 0.0)
    obj.dimensions = dims or _make_dims(4.5, 2.0, 1.5)
    obj.lifecycle_state = ObjectLifecycleState(lifecycle) if lifecycle in [s.value for s in ObjectLifecycleState] else ObjectLifecycleState.CONFIRMED
    obj.source_sensors = source_sensors if source_sensors is not None else frozenset()
    obj.warnings = []
    return obj


def _make_fused_world_state(objects=None, timestamp=None, frame_id=1, fusion_mode="FULL_FUSION"):
    from core.fusion.fusion_types import FusionMode
    from core.perception.perception_types import HealthState

    fws = MagicMock()
    fws.timestamp = timestamp or time.time()
    fws.frame_id = frame_id
    fws.objects = objects or []
    fws.fusion_health = HealthState.HEALTHY
    fm_map = {
        "FULL_FUSION": FusionMode.FULL_FUSION,
        "PARTIAL_FUSION": FusionMode.PARTIAL_FUSION,
        "SINGLE_SENSOR": FusionMode.SINGLE_SENSOR,
        "NO_VALID_SENSOR": FusionMode.NO_VALID_SENSOR,
    }
    fws.fusion_mode = fm_map.get(fusion_mode, FusionMode.FULL_FUSION)
    return fws


def _make_motion_state(x=5.0, y=0.5, z=0.0, vx=3.0, vy=0.0, vz=0.0, yaw=0.1, yaw_rate=0.0, speed=3.0):
    ms = MagicMock()
    ms.x = x; ms.y = y; ms.z = z
    ms.vx = vx; ms.vy = vy; ms.vz = vz
    ms.ax = 0.0; ms.ay = 0.0; ms.az = 0.0
    ms.yaw = yaw; ms.yaw_rate = yaw_rate; ms.speed = speed
    ms.heading = yaw; ms.timestamp = time.time()
    return ms


def _make_predicted_state(x=15.0, y=0.5, z=0.0, vx=3.0, vy=0.0, vz=0.0, yaw=0.1, speed=3.0,
                           horizon_s=1.0, ts=None):
    ps = MagicMock()
    ps.x = x; ps.y = y; ps.z = z
    ps.vx = vx; ps.vy = vy; ps.vz = vz
    ps.yaw = yaw; ps.speed = speed
    ps.horizon_s = horizon_s
    ps.timestamp = ts or time.time()
    ps.covariance = None
    return ps


def _make_predicted_object(track_id="t1", obj_type="VEHICLE", confidence=0.82,
                             trajectory_len=3, lifecycle="ACTIVE", with_model=True):
    from core.prediction.prediction_types import ModelType, TrackLifecycleState
    po = MagicMock()
    po.track_id = track_id
    po.object_type = obj_type
    po.prediction_confidence = confidence
    po.uncertainty = {"sigma_x": 0.3, "sigma_y": 0.2}
    po.selected_model = ModelType.CV if with_model else ModelType.NOT_AVAILABLE
    po.lifecycle_state = TrackLifecycleState.ACTIVE
    po.current_state = _make_motion_state()
    po.trajectory = [
        _make_predicted_state(x=10.0 + i * 3, horizon_s=float(i + 1))
        for i in range(trajectory_len)
    ]
    po.warnings = []
    return po


def _make_predicted_world_state(objects=None, timestamp=None, frame_id=1):
    from core.perception.perception_types import HealthState
    pws = MagicMock()
    pws.timestamp = timestamp or time.time()
    pws.frame_id = frame_id
    pws.objects = objects or []
    pws.prediction_health = HealthState.HEALTHY
    return pws


def _make_ttc(ttc_s=3.5, status="FINITE", closing_speed=5.0):
    from core.prediction.phase4d_types import TTCStatus
    ttc = MagicMock()
    ttc.ttc_s = ttc_s
    ttc.status = TTCStatus.FINITE if status == "FINITE" else TTCStatus.NO_COLLISION
    ttc.closing_speed_ms = closing_speed
    return ttc


def _make_closest_approach(min_dist=1.2, tca=2.0):
    ca = MagicMock()
    ca.minimum_distance_m = min_dist
    ca.time_of_closest_approach_s = tca
    ca.relative_position_x = 5.0
    ca.relative_position_y = 0.5
    ca.relative_velocity_x = -3.0
    ca.relative_velocity_y = 0.0
    return ca


def _make_hypothesis_risk(behaviour="LANE_FOLLOW", prob=0.7, cl=0.15, risk="LOW"):
    from core.prediction.phase4d_types import RiskLevel
    hr = MagicMock()
    hr.behaviour = behaviour
    hr.probability = prob
    hr.collision_likelihood = cl
    risk_map = {"LOW": RiskLevel.LOW, "MEDIUM": RiskLevel.MEDIUM, "HIGH": RiskLevel.HIGH, "CRITICAL": RiskLevel.CRITICAL}
    hr.risk_level = risk_map.get(risk, RiskLevel.LOW)
    return hr


def _make_phase4d_object(track_id="t1", ttc_s=3.5, risk="LOW", cl=0.1, with_ca=True):
    from core.prediction.phase4d_types import RiskLevel
    from core.prediction.phase4c_types import Phase4CObject
    from core.prediction.prediction_types import PredictedObject

    obj = MagicMock()
    obj.track_id = track_id
    obj.object_type = "VEHICLE"
    obj.prediction_confidence = 0.8
    obj.uncertainty = {}
    obj.ttc = _make_ttc(ttc_s=ttc_s)
    obj.closest_approach = _make_closest_approach() if with_ca else None
    obj.collision_likelihood = cl
    risk_map = {"LOW": RiskLevel.LOW, "MEDIUM": RiskLevel.MEDIUM, "HIGH": RiskLevel.HIGH, "CRITICAL": RiskLevel.CRITICAL}
    obj.risk_level = risk_map.get(risk, RiskLevel.LOW)
    obj.hypothesis_risks = [_make_hypothesis_risk()]
    obj.invalid = False
    obj.invalid_reason = ""
    # phase4c proxy access
    obj.phase4c = MagicMock()
    obj.phase4c.track_id = track_id
    obj.phase4c.predicted = MagicMock()
    obj.phase4c.predicted.object_type = "VEHICLE"
    obj.phase4c.predicted.prediction_confidence = 0.8
    obj.phase4c.predicted.uncertainty = {}
    return obj


def _make_collision_state(objects=None, timestamp=None, frame_id=1):
    from core.perception.perception_types import HealthState
    cs = MagicMock()
    cs.timestamp = timestamp or time.time()
    cs.frame_id = frame_id
    cs.objects = objects or []
    cs.prediction_health = HealthState.HEALTHY
    return cs


def _make_road_understanding_state(
    overall_confidence=0.8,
    overall_uncertainty=0.2,
    valid=True,
    degraded=False,
    timestamp=None,
    with_drivable_area=True,
    with_lane=True,
    with_anomaly=True,
    with_indian_ctx=True,
    road_type="URBAN",
    anomaly_count=1,
):
    rus = MagicMock()
    rus.timestamp = timestamp or time.time()
    rus.overall_confidence = overall_confidence
    rus.overall_uncertainty = overall_uncertainty
    rus.valid = valid
    rus.degraded = degraded
    rus.warnings = []

    from core.perception.road_understanding_state import (
        RoadSummary, ModuleAvailability
    )
    summary = MagicMock()
    summary.road_type = road_type
    summary.road_width_category = "MEDIUM"
    summary.estimated_road_width_m = 7.5
    summary.lane_marking_state = "MARKED"
    summary.lane_count = 2
    summary.intersection_state = "NORMAL_ROAD"
    summary.road_surface_quality = "GOOD"
    summary.traffic_density = "MEDIUM"
    summary.road_complexity = "LOW"
    summary.animal_present = False
    summary.vru_presence = "LOW"
    summary.anomaly_count = anomaly_count if with_anomaly else 0
    summary.has_critical_anomaly = False
    rus.summary = summary

    # Drivable area state
    if with_drivable_area:
        da = MagicMock()
        da.confidence = 0.85
        da.uncertainty = 0.15
        da.road_width_m = 7.5
        da.status = MagicMock()
        da.status.value = "OK"
        da.left_boundary = MagicMock()
        da.left_boundary.points = []
        da.right_boundary = MagicMock()
        da.right_boundary.points = []
        rus.drivable_area_state = da
        rus.phase61_availability = ModuleAvailability.OK
    else:
        rus.drivable_area_state = None
        rus.phase61_availability = ModuleAvailability.UNAVAILABLE

    # Lane state
    if with_lane:
        ls = MagicMock()
        ls.confidence = 0.75
        ls.uncertainty = 0.25
        ls.marking_status = MagicMock()
        ls.marking_status.value = "MARKED"
        ls.lane_count = 2
        ls.lane_width_m = 3.5
        ls.status = MagicMock()
        ls.status.value = "OK"
        rus.lane_structure_state = ls
        rus.phase62_availability = ModuleAvailability.OK
    else:
        rus.lane_structure_state = None
        rus.phase62_availability = ModuleAvailability.UNAVAILABLE

    # Road anomaly state
    if with_anomaly and anomaly_count > 0:
        ra_state = MagicMock()
        anomalies = []
        for i in range(anomaly_count):
            obs = MagicMock()
            obs.anomaly_id = f"a{i}"
            obs.anomaly_type = MagicMock()
            obs.anomaly_type.value = "POTHOLE"
            obs.severity = MagicMock()
            obs.severity.value = "MODERATE"
            obs.confidence = 0.7
            obs.uncertainty = 0.3
            obs.drivability_impact = MagicMock()
            obs.drivability_impact.value = "MEDIUM"
            obs.temporal_state = MagicMock()
            obs.temporal_state.value = "STABLE"
            obs.geometry = MagicMock()
            obs.geometry.centroid_x = 5.0 + i
            obs.geometry.centroid_y = 0.5
            obs.geometry.width_m = 0.4
            obs.geometry.length_m = 0.5
            obs.drivable_area_relation = MagicMock()
            obs.drivable_area_relation.value = "INSIDE_DRIVABLE_AREA"
            obs.lane_relation = MagicMock()
            obs.lane_relation.value = "INSIDE_LANE"
            anomalies.append(obs)
        ra_state.anomalies = anomalies
        rus.road_anomaly_state = ra_state
        rus.phase63_availability = ModuleAvailability.OK
    else:
        rus.road_anomaly_state = None
        rus.phase63_availability = ModuleAvailability.UNAVAILABLE

    # Indian context state
    if with_indian_ctx:
        ctx = MagicMock()
        ctx.road_type = MagicMock()
        ctx.road_type.value = road_type
        ctx.traffic_density = MagicMock()
        ctx.traffic_density.value = "MEDIUM"
        ctx.road_complexity = MagicMock()
        ctx.road_complexity.value = "LOW"
        ctx.animal_activity = MagicMock()
        ctx.animal_activity.value = "NONE"
        ctx.vru_presence = MagicMock()
        ctx.vru_presence.value = "LOW"
        ctx.intersection_context = MagicMock()
        ctx.intersection_context.value = "NORMAL"
        ctx.context_stability = MagicMock()
        ctx.context_stability.value = "STABLE"
        ctx.context_flags = []
        ctx.confidence = 0.82
        ctx.uncertainty = 0.18
        ctx.status = MagicMock()
        ctx.status.value = "OK"
        ctx.traffic_mix_summary = None
        ctx.roadside_activity = None
        rus.indian_context_state = ctx
        rus.phase64_availability = ModuleAvailability.OK
    else:
        rus.indian_context_state = None
        rus.phase64_availability = ModuleAvailability.UNAVAILABLE

    return rus


def _default_config():
    return WorldModelConfig(snapshot_buffer_size=5)


# ============================================================
# Basic construction tests
# ============================================================

class TestBasicConstruction:

    def test_empty_world_model(self):
        wm = WorldModel(config=_default_config())
        result = wm.build()
        assert isinstance(result, WorldModelBuildResult)
        snap = result.snapshot
        assert isinstance(snap, WorldModelSnapshot)
        assert snap.object_count == 0
        assert snap.status in (WorldModelStatus.EMPTY, WorldModelStatus.PARTIAL, WorldModelStatus.DEGRADED)

    def test_snapshot_has_schema_version(self):
        wm = WorldModel(config=_default_config())
        result = wm.build()
        assert result.snapshot.schema_version == "7.0"

    def test_snapshot_has_positive_timestamp(self):
        wm = WorldModel(config=_default_config())
        t0 = time.time()
        result = wm.build()
        assert result.snapshot.timestamp >= t0

    def test_snapshot_coordinate_frame_is_vehicle(self):
        wm = WorldModel(config=_default_config())
        result = wm.build()
        assert result.snapshot.coordinate_frame == CoordinateFrame.VEHICLE

    def test_full_build_returns_build_result(self):
        wm = WorldModel(config=_default_config())
        fobj = _make_fused_object()
        fws = _make_fused_world_state(objects=[fobj])
        result = wm.build(fused_world_state=fws)
        assert isinstance(result, WorldModelBuildResult)
        assert result.snapshot.object_count == 1

    def test_partial_build_no_fused_state(self):
        wm = WorldModel(config=_default_config())
        rus = _make_road_understanding_state()
        result = wm.build(road_understanding_state=rus)
        snap = result.snapshot
        assert snap.object_count == 0
        assert snap.road.status != RoadRepresentationStatus.NONE

    def test_repeated_update_produces_new_snapshots(self):
        wm = WorldModel(config=_default_config())
        r1 = wm.build()
        r2 = wm.build()
        assert r1.snapshot is not r2.snapshot

    def test_snapshot_creation_stores_in_history(self):
        cfg = WorldModelConfig(snapshot_buffer_size=5)
        wm = WorldModel(config=cfg)
        for _ in range(3):
            wm.build()
        assert len(wm.snapshot_history()) == 3

    def test_snapshot_buffer_bounded(self):
        cfg = WorldModelConfig(snapshot_buffer_size=3)
        wm = WorldModel(config=cfg)
        for _ in range(10):
            wm.build()
        assert len(wm.snapshot_history()) <= 3

    def test_latest_snapshot_matches_most_recent(self):
        wm = WorldModel(config=_default_config())
        wm.build(ref_timestamp=1000.0)
        wm.build(ref_timestamp=2000.0)
        snap = wm.latest_snapshot()
        assert snap.timestamp == 2000.0

    def test_health_status_string(self):
        wm = WorldModel(config=_default_config())
        wm.build()
        hs = wm.health_status()
        assert isinstance(hs, str)


# ============================================================
# Object integration tests
# ============================================================

class TestObjectIntegration:

    def test_single_object(self):
        wm = WorldModel(config=_default_config())
        fobj = _make_fused_object(fused_id="fo1", track_id="t1")
        fws = _make_fused_world_state(objects=[fobj])
        result = wm.build(fused_world_state=fws)
        assert result.snapshot.object_count == 1

    def test_multiple_objects(self):
        wm = WorldModel(config=_default_config())
        fobjs = [
            _make_fused_object(fused_id=f"fo{i}", track_id=f"t{i}", position=_make_position3d(i * 5.0, 0.0, 0.0))
            for i in range(5)
        ]
        fws = _make_fused_world_state(objects=fobjs)
        result = wm.build(fused_world_state=fws)
        assert result.snapshot.object_count == 5

    def test_duplicate_track_id_deduplication(self):
        """Two objects with the same track_id must be deduplicated."""
        wm = WorldModel(config=_default_config())
        fobj1 = _make_fused_object(fused_id="fo1", track_id="t1", confidence=0.9)
        fobj2 = _make_fused_object(fused_id="fo2", track_id="t1", confidence=0.5)
        fws = _make_fused_world_state(objects=[fobj1, fobj2])
        result = wm.build(fused_world_state=fws)
        assert result.snapshot.object_count == 1
        # Higher confidence kept
        assert result.snapshot.objects[0].quality.object_confidence == pytest.approx(0.9, abs=1e-3)

    def test_duplicate_fused_id_deduplication(self):
        """Two objects with the same fused_id (no track_id) must be deduplicated."""
        wm = WorldModel(config=_default_config())
        fobj1 = _make_fused_object(fused_id="fo1", track_id=None, confidence=0.8)
        fobj1.track_id = None
        fobj2 = _make_fused_object(fused_id="fo1", track_id=None, confidence=0.6)
        fobj2.track_id = None
        fws = _make_fused_world_state(objects=[fobj1, fobj2])
        result = wm.build(fused_world_state=fws)
        assert result.snapshot.object_count == 1

    def test_different_objects_same_type_not_merged(self):
        """Two VEHICLEs far apart must NOT be merged even if same type."""
        wm = WorldModel(config=WorldModelConfig(object_merge_distance_m=0.5))
        fobj1 = _make_fused_object(fused_id=None, track_id=None, obj_class="VEHICLE",
                                    position=_make_position3d(10.0, 0.0, 0.0))
        fobj1.fused_object_id = None
        fobj1.track_id = None
        fobj2 = _make_fused_object(fused_id=None, track_id=None, obj_class="VEHICLE",
                                    position=_make_position3d(30.0, 0.0, 0.0))
        fobj2.fused_object_id = None
        fobj2.track_id = None
        fws = _make_fused_world_state(objects=[fobj1, fobj2])
        result = wm.build(fused_world_state=fws)
        assert result.snapshot.object_count == 2

    def test_object_position_populated(self):
        wm = WorldModel(config=_default_config())
        fobj = _make_fused_object(position=_make_position3d(15.0, 2.0, 0.3))
        fws = _make_fused_world_state(objects=[fobj])
        result = wm.build(fused_world_state=fws)
        obj = result.snapshot.objects[0]
        assert obj.position.x == pytest.approx(15.0, abs=1e-3)
        assert obj.position.y == pytest.approx(2.0, abs=1e-3)

    def test_object_velocity_populated(self):
        wm = WorldModel(config=_default_config())
        fobj = _make_fused_object(velocity=(8.0, 1.0, 0.0))
        fws = _make_fused_world_state(objects=[fobj])
        result = wm.build(fused_world_state=fws)
        obj = result.snapshot.objects[0]
        assert obj.velocity.vx == pytest.approx(8.0, abs=1e-3)

    def test_object_is_moving_flag(self):
        wm = WorldModel(config=_default_config())
        fobj_moving = _make_fused_object(velocity=(5.0, 0.0, 0.0))
        fobj_static = _make_fused_object(fused_id="fo2", track_id="t2", velocity=(0.1, 0.0, 0.0))
        fws = _make_fused_world_state(objects=[fobj_moving, fobj_static])
        result = wm.build(fused_world_state=fws)
        moving = [o for o in result.snapshot.objects if o.motion.is_moving]
        static = [o for o in result.snapshot.objects if not o.motion.is_moving]
        assert len(moving) == 1
        assert len(static) == 1

    def test_stale_object_marked(self):
        cfg = WorldModelConfig(max_data_age_seconds=0.5)
        wm = WorldModel(config=cfg)
        old_ts = time.time() - 2.0  # 2 seconds old
        fobj = _make_fused_object(timestamp=old_ts)
        fws = _make_fused_world_state(objects=[fobj], timestamp=time.time())
        result = wm.build(fused_world_state=fws)
        obj = result.snapshot.objects[0]
        assert obj.quality.is_stale

    def test_object_missing_identifiers(self):
        """Object with no fused_id and no track_id — must still be included."""
        wm = WorldModel(config=_default_config())
        fobj = _make_fused_object(fused_id=None, track_id=None)
        fobj.fused_object_id = None
        fobj.track_id = None
        fws = _make_fused_world_state(objects=[fobj])
        result = wm.build(fused_world_state=fws)
        assert result.snapshot.object_count == 1
        assert result.snapshot.objects[0].primary_id() is None

    def test_object_count_limited_by_config(self):
        cfg = WorldModelConfig(max_objects=3)
        wm = WorldModel(config=cfg)
        fobjs = [
            _make_fused_object(fused_id=f"fo{i}", track_id=f"t{i}",
                                position=_make_position3d(float(i * 5), 0.0, 0.0))
            for i in range(10)
        ]
        fws = _make_fused_world_state(objects=fobjs)
        result = wm.build(fused_world_state=fws)
        assert result.snapshot.object_count <= 3

    def test_object_type_classification(self):
        wm = WorldModel(config=_default_config())
        fobj = _make_fused_object(obj_class="PEDESTRIAN")
        fws = _make_fused_world_state(objects=[fobj])
        result = wm.build(fused_world_state=fws)
        assert result.snapshot.objects[0].object_type == "PEDESTRIAN"

    def test_object_dimensions_populated(self):
        wm = WorldModel(config=_default_config())
        fobj = _make_fused_object(dims=_make_dims(length=4.5, width=2.0, height=1.5))
        fws = _make_fused_world_state(objects=[fobj])
        result = wm.build(fused_world_state=fws)
        obj = result.snapshot.objects[0]
        assert obj.dimensions.length_m == pytest.approx(4.5, abs=1e-3)

    def test_objects_by_risk_sorting(self):
        wm = WorldModel(config=_default_config())
        fobjs = [
            _make_fused_object(fused_id="fo1", track_id="t1"),
            _make_fused_object(fused_id="fo2", track_id="t2"),
        ]
        fws = _make_fused_world_state(objects=fobjs)
        cobj_high = _make_phase4d_object(track_id="t1", risk="HIGH")
        cobj_low = _make_phase4d_object(track_id="t2", risk="LOW")
        cs = _make_collision_state(objects=[cobj_high, cobj_low])
        result = wm.build(fused_world_state=fws, collision_state=cs)
        sorted_objs = result.snapshot.objects_by_risk()
        risk_order = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3}
        risks = [risk_order.get(o.collision.risk_level, 4) for o in sorted_objs]
        assert risks == sorted(risks)


# ============================================================
# Prediction integration tests
# ============================================================

class TestPredictionIntegration:

    def test_valid_prediction_attached(self):
        wm = WorldModel(config=_default_config())
        fobj = _make_fused_object(track_id="t1")
        fws = _make_fused_world_state(objects=[fobj])
        pobj = _make_predicted_object(track_id="t1", trajectory_len=3)
        pws = _make_predicted_world_state(objects=[pobj])
        result = wm.build(fused_world_state=fws, prediction_state=pws)
        obj = result.snapshot.objects[0]
        assert obj.prediction.availability != PredictionAvailability.NONE
        assert len(obj.prediction.trajectory) == 3

    def test_missing_prediction_state(self):
        wm = WorldModel(config=_default_config())
        fobj = _make_fused_object(track_id="t1")
        fws = _make_fused_world_state(objects=[fobj])
        result = wm.build(fused_world_state=fws, prediction_state=None)
        obj = result.snapshot.objects[0]
        assert obj.prediction.availability == PredictionAvailability.NONE

    def test_trajectory_bounded(self):
        cfg = WorldModelConfig(max_trajectory_points=5)
        wm = WorldModel(config=cfg)
        fobj = _make_fused_object(track_id="t1")
        fws = _make_fused_world_state(objects=[fobj])
        pobj = _make_predicted_object(track_id="t1", trajectory_len=20)
        pws = _make_predicted_world_state(objects=[pobj])
        result = wm.build(fused_world_state=fws, prediction_state=pws)
        obj = result.snapshot.objects[0]
        assert len(obj.prediction.trajectory) <= 5

    def test_prediction_confidence_populated(self):
        wm = WorldModel(config=_default_config())
        fobj = _make_fused_object(track_id="t1")
        fws = _make_fused_world_state(objects=[fobj])
        pobj = _make_predicted_object(track_id="t1", confidence=0.87)
        pws = _make_predicted_world_state(objects=[pobj])
        result = wm.build(fused_world_state=fws, prediction_state=pws)
        obj = result.snapshot.objects[0]
        assert obj.prediction.prediction_confidence == pytest.approx(0.87, abs=1e-3)

    def test_prediction_uncertainty_preserved(self):
        wm = WorldModel(config=_default_config())
        fobj = _make_fused_object(track_id="t1")
        fws = _make_fused_world_state(objects=[fobj])
        pobj = _make_predicted_object(track_id="t1")
        pobj.uncertainty = {"sigma_x": 0.3, "sigma_y": 0.2}
        pws = _make_predicted_world_state(objects=[pobj])
        result = wm.build(fused_world_state=fws, prediction_state=pws)
        obj = result.snapshot.objects[0]
        assert "sigma_x" in obj.prediction.prediction_uncertainty

    def test_ttc_integration(self):
        wm = WorldModel(config=_default_config())
        fobj = _make_fused_object(track_id="t1")
        fws = _make_fused_world_state(objects=[fobj])
        cobj = _make_phase4d_object(track_id="t1", ttc_s=2.5)
        cs = _make_collision_state(objects=[cobj])
        result = wm.build(fused_world_state=fws, collision_state=cs)
        obj = result.snapshot.objects[0]
        assert obj.collision.ttc_s == pytest.approx(2.5, abs=1e-3)
        assert obj.collision.ttc_status == "FINITE"

    def test_closest_approach_integration(self):
        wm = WorldModel(config=_default_config())
        fobj = _make_fused_object(track_id="t1")
        fws = _make_fused_world_state(objects=[fobj])
        cobj = _make_phase4d_object(track_id="t1", with_ca=True)
        cs = _make_collision_state(objects=[cobj])
        result = wm.build(fused_world_state=fws, collision_state=cs)
        obj = result.snapshot.objects[0]
        assert obj.collision.min_distance_m is not None
        assert obj.collision.min_distance_m >= 0

    def test_collision_likelihood_integration(self):
        wm = WorldModel(config=_default_config())
        fobj = _make_fused_object(track_id="t1")
        fws = _make_fused_world_state(objects=[fobj])
        cobj = _make_phase4d_object(track_id="t1", cl=0.35, risk="MEDIUM")
        cs = _make_collision_state(objects=[cobj])
        result = wm.build(fused_world_state=fws, collision_state=cs)
        obj = result.snapshot.objects[0]
        assert obj.collision.collision_likelihood == pytest.approx(0.35, abs=1e-3)
        assert obj.collision.risk_level == "MEDIUM"

    def test_hypothesis_risk_integration(self):
        wm = WorldModel(config=_default_config())
        fobj = _make_fused_object(track_id="t1")
        fws = _make_fused_world_state(objects=[fobj])
        cobj = _make_phase4d_object(track_id="t1")
        cobj.hypothesis_risks = [
            _make_hypothesis_risk("LANE_FOLLOW", 0.7, 0.1, "LOW"),
            _make_hypothesis_risk("OVERTAKE", 0.3, 0.6, "HIGH"),
        ]
        cs = _make_collision_state(objects=[cobj])
        result = wm.build(fused_world_state=fws, collision_state=cs)
        obj = result.snapshot.objects[0]
        assert len(obj.prediction.hypotheses) == 2

    def test_no_collision_ttc_status(self):
        wm = WorldModel(config=_default_config())
        fobj = _make_fused_object(track_id="t1")
        fws = _make_fused_world_state(objects=[fobj])
        cobj = _make_phase4d_object(track_id="t1")
        cobj.ttc = _make_ttc(ttc_s=None, status="NO_COLLISION")
        cs = _make_collision_state(objects=[cobj])
        result = wm.build(fused_world_state=fws, collision_state=cs)
        obj = result.snapshot.objects[0]
        assert obj.collision.ttc_status == "NO_COLLISION"
        assert obj.collision.ttc_s is None

    def test_missing_collision_state(self):
        wm = WorldModel(config=_default_config())
        fobj = _make_fused_object(track_id="t1")
        fws = _make_fused_world_state(objects=[fobj])
        result = wm.build(fused_world_state=fws, collision_state=None)
        obj = result.snapshot.objects[0]
        assert obj.collision.ttc_s is None
        assert obj.collision.collision_likelihood is None


# ============================================================
# Road integration tests
# ============================================================

class TestRoadIntegration:

    def test_drivable_area_populated(self):
        wm = WorldModel(config=_default_config())
        rus = _make_road_understanding_state(with_drivable_area=True)
        result = wm.build(road_understanding_state=rus)
        assert result.snapshot.road.drivable_space.available

    def test_road_boundaries_available(self):
        wm = WorldModel(config=_default_config())
        rus = _make_road_understanding_state(with_drivable_area=True)
        result = wm.build(road_understanding_state=rus)
        road = result.snapshot.road
        # Boundary objects exist (even if empty in mock)
        assert road.drivable_space.left_boundary is not None
        assert road.drivable_space.right_boundary is not None

    def test_lane_structure_available(self):
        wm = WorldModel(config=_default_config())
        rus = _make_road_understanding_state(with_lane=True)
        result = wm.build(road_understanding_state=rus)
        assert result.snapshot.road.lane_info.available

    def test_lane_count_populated(self):
        wm = WorldModel(config=_default_config())
        rus = _make_road_understanding_state(with_lane=True)
        result = wm.build(road_understanding_state=rus)
        assert result.snapshot.road.lane_info.lane_count == 2

    def test_unmarked_road_lane_info(self):
        wm = WorldModel(config=_default_config())
        rus = _make_road_understanding_state(with_lane=True)
        rus.lane_structure_state.marking_status.value = "UNMARKED"
        result = wm.build(road_understanding_state=rus)
        assert result.snapshot.road.lane_info.marking_state == "UNMARKED"

    def test_road_anomaly_populated(self):
        wm = WorldModel(config=_default_config())
        rus = _make_road_understanding_state(with_anomaly=True, anomaly_count=1)
        result = wm.build(road_understanding_state=rus)
        assert result.snapshot.road.anomaly_count == 1
        a = result.snapshot.road.anomalies[0]
        assert a.anomaly_type == "POTHOLE"

    def test_multiple_anomalies(self):
        wm = WorldModel(config=_default_config())
        rus = _make_road_understanding_state(with_anomaly=True, anomaly_count=3)
        result = wm.build(road_understanding_state=rus)
        assert result.snapshot.road.anomaly_count == 3

    def test_anomaly_count_bounded(self):
        cfg = WorldModelConfig(max_anomalies=2)
        wm = WorldModel(config=cfg)
        rus = _make_road_understanding_state(with_anomaly=True, anomaly_count=5)
        result = wm.build(road_understanding_state=rus)
        assert result.snapshot.road.anomaly_count <= 2

    def test_missing_road_understanding_input(self):
        wm = WorldModel(config=_default_config())
        result = wm.build(road_understanding_state=None)
        road = result.snapshot.road
        assert road.status == RoadRepresentationStatus.NONE
        assert road.is_degraded

    def test_road_confidence_populated(self):
        wm = WorldModel(config=_default_config())
        rus = _make_road_understanding_state(overall_confidence=0.88)
        result = wm.build(road_understanding_state=rus)
        assert result.snapshot.road.road_confidence == pytest.approx(0.88, abs=1e-3)

    def test_intersection_state(self):
        wm = WorldModel(config=_default_config())
        rus = _make_road_understanding_state(with_lane=True)
        result = wm.build(road_understanding_state=rus)
        # intersection_state from summary mock
        lane = result.snapshot.road.lane_info
        assert lane.intersection_state in ("NORMAL_ROAD", "INTERSECTION", "UNKNOWN", NOT_AVAILABLE)


# ============================================================
# Indian context integration tests
# ============================================================

class TestIndianContextIntegration:

    def test_village_road_context(self):
        wm = WorldModel(config=_default_config())
        rus = _make_road_understanding_state(road_type="VILLAGE_ROAD", with_indian_ctx=True)
        result = wm.build(road_understanding_state=rus)
        ctx = result.snapshot.indian_context
        assert ctx.available
        assert "VILLAGE" in ctx.road_type

    def test_dense_market_context(self):
        wm = WorldModel(config=_default_config())
        rus = _make_road_understanding_state(road_type="URBAN", with_indian_ctx=True)
        rus.indian_context_state.roadside_activity = MagicMock()
        rus.indian_context_state.roadside_activity.market_like = True
        result = wm.build(road_understanding_state=rus)
        ctx = result.snapshot.indian_context
        assert ctx.available

    def test_highway_like_road(self):
        wm = WorldModel(config=_default_config())
        rus = _make_road_understanding_state(road_type="HIGHWAY", with_indian_ctx=True)
        result = wm.build(road_understanding_state=rus)
        ctx = result.snapshot.indian_context
        assert "HIGHWAY" in ctx.road_type or ctx.road_type != NOT_AVAILABLE

    def test_cattle_crossing_context(self):
        wm = WorldModel(config=_default_config())
        rus = _make_road_understanding_state(with_indian_ctx=True)
        rus.indian_context_state.animal_activity.value = "CATTLE_CROSSING"
        result = wm.build(road_understanding_state=rus)
        ctx = result.snapshot.indian_context
        assert ctx.cattle_present

    def test_construction_context(self):
        wm = WorldModel(config=_default_config())
        rus = _make_road_understanding_state(with_indian_ctx=True)
        rus.indian_context_state.road_complexity.value = "VERY_HIGH"
        result = wm.build(road_understanding_state=rus)
        ctx = result.snapshot.indian_context
        assert ctx.available

    def test_damaged_narrow_road(self):
        wm = WorldModel(config=_default_config())
        rus = _make_road_understanding_state(road_type="VILLAGE_ROAD", with_indian_ctx=True)
        result = wm.build(road_understanding_state=rus)
        ctx = result.snapshot.indian_context
        assert ctx.available

    def test_degraded_context(self):
        wm = WorldModel(config=_default_config())
        rus = _make_road_understanding_state(with_indian_ctx=True)
        rus.indian_context_state.status.value = "DEGRADED"
        result = wm.build(road_understanding_state=rus)
        ctx = result.snapshot.indian_context
        assert ctx.is_degraded

    def test_no_indian_context(self):
        wm = WorldModel(config=_default_config())
        rus = _make_road_understanding_state(with_indian_ctx=False)
        result = wm.build(road_understanding_state=rus)
        ctx = result.snapshot.indian_context
        assert not ctx.available

    def test_traffic_density_preserved(self):
        wm = WorldModel(config=_default_config())
        rus = _make_road_understanding_state(with_indian_ctx=True)
        result = wm.build(road_understanding_state=rus)
        ctx = result.snapshot.indian_context
        assert ctx.traffic_density == "MEDIUM"

    def test_urban_rural_classification(self):
        wm = WorldModel(config=_default_config())
        rus_urban = _make_road_understanding_state(road_type="URBAN", with_indian_ctx=True)
        rus_rural = _make_road_understanding_state(road_type="VILLAGE_ROAD", with_indian_ctx=True)
        r_urban = wm.build(road_understanding_state=rus_urban)
        r_rural = wm.build(road_understanding_state=rus_rural)
        assert r_urban.snapshot.indian_context.urban_rural_class == "URBAN"
        assert r_rural.snapshot.indian_context.urban_rural_class == "RURAL"


# ============================================================
# Data quality tests
# ============================================================

class TestDataQuality:

    def test_completeness_zero_when_no_inputs(self):
        wm = WorldModel(config=_default_config())
        result = wm.build()
        dq = result.snapshot.data_quality
        assert dq.completeness == pytest.approx(0.0, abs=1e-3)

    def test_completeness_increases_with_modules(self):
        wm = WorldModel(config=_default_config())
        r1 = wm.build()
        r2 = wm.build(fused_world_state=_make_fused_world_state())
        assert r2.snapshot.data_quality.completeness >= r1.snapshot.data_quality.completeness

    def test_stale_input_raises_uncertainty(self):
        cfg = WorldModelConfig(max_data_age_seconds=0.5)
        wm = WorldModel(config=cfg)
        old_ts = time.time() - 5.0
        fws = _make_fused_world_state(timestamp=old_ts)
        result = wm.build(fused_world_state=fws)
        dq = result.snapshot.data_quality
        # Uncertainty should be non-trivial given stale input
        assert dq.overall_uncertainty > 0.0

    def test_missing_module_adds_warning(self):
        wm = WorldModel(config=_default_config())
        result = wm.build()  # no inputs
        dq = result.snapshot.data_quality
        assert len(dq.warnings) > 0

    def test_is_partial_when_some_modules_missing(self):
        wm = WorldModel(config=_default_config())
        fws = _make_fused_world_state()
        result = wm.build(fused_world_state=fws)
        dq = result.snapshot.data_quality
        assert dq.is_partial  # prediction and road are still missing

    def test_freshness_near_one_for_fresh_data(self):
        wm = WorldModel(config=_default_config())
        fws = _make_fused_world_state(timestamp=time.time())
        result = wm.build(fused_world_state=fws)
        dq = result.snapshot.data_quality
        assert dq.freshness > 0.5

    def test_overall_confidence_bounded(self):
        wm = WorldModel(config=_default_config())
        fobj = _make_fused_object(confidence=1.0)
        fws = _make_fused_world_state(objects=[fobj])
        rus = _make_road_understanding_state(overall_confidence=1.0)
        result = wm.build(fused_world_state=fws, road_understanding_state=rus)
        dq = result.snapshot.data_quality
        assert 0.0 <= dq.overall_confidence <= 1.0

    def test_module_status_fields_populated(self):
        wm = WorldModel(config=_default_config())
        fws = _make_fused_world_state()
        result = wm.build(fused_world_state=fws)
        dq = result.snapshot.data_quality
        from core.world_model import InputModuleStatus
        assert dq.fusion_status in list(InputModuleStatus)
        assert dq.prediction_status in list(InputModuleStatus)

    def test_invalid_confidence_handled_gracefully(self):
        """Objects with NaN confidence must not crash the builder."""
        wm = WorldModel(config=_default_config())
        fobj = _make_fused_object(confidence=float("nan"))
        fws = _make_fused_world_state(objects=[fobj])
        result = wm.build(fused_world_state=fws)
        # Should not crash; confidence clamped to 0
        obj = result.snapshot.objects[0]
        assert 0.0 <= obj.quality.object_confidence <= 1.0


# ============================================================
# Snapshot safety tests
# ============================================================

class TestSnapshotSafety:

    def test_objects_tuple_immutable(self):
        wm = WorldModel(config=_default_config())
        fobj = _make_fused_object()
        fws = _make_fused_world_state(objects=[fobj])
        result = wm.build(fused_world_state=fws)
        snap = result.snapshot
        assert isinstance(snap.objects, tuple)
        with pytest.raises((AttributeError, TypeError)):
            snap.objects[0] = None  # type: ignore

    def test_snapshot_not_mutated_by_second_build(self):
        wm = WorldModel(config=_default_config())
        fobj1 = _make_fused_object(fused_id="fo1", track_id="t1")
        fws1 = _make_fused_world_state(objects=[fobj1])
        result1 = wm.build(fused_world_state=fws1, ref_timestamp=1000.0)
        snap1 = result1.snapshot

        fobj2 = _make_fused_object(fused_id="fo2", track_id="t2",
                                    position=_make_position3d(20.0, 0.0, 0.0))
        fws2 = _make_fused_world_state(objects=[fobj2])
        wm.build(fused_world_state=fws2, ref_timestamp=2000.0)

        # First snapshot must be unchanged
        assert snap1.timestamp == pytest.approx(1000.0, abs=1e-3)
        assert snap1.object_count == 1

    def test_safe_copy_produces_independent_copy(self):
        wm = WorldModel(config=_default_config())
        result = wm.build()
        snap = result.snapshot
        snap_copy = safe_copy_snapshot(snap)
        assert snap_copy is not snap
        assert snap_copy.schema_version == snap.schema_version

    def test_snapshot_to_json_is_string(self):
        wm = WorldModel(config=_default_config())
        result = wm.build()
        j = snapshot_to_json(result.snapshot)
        assert isinstance(j, str)
        import json
        d = json.loads(j)
        assert "schema_version" in d

    def test_snapshot_summary_dict(self):
        wm = WorldModel(config=_default_config())
        result = wm.build()
        s = snapshot_summary(result.snapshot)
        assert "object_count" in s
        assert "status" in s

    def test_snapshot_age(self):
        wm = WorldModel(config=_default_config())
        ts = time.time() - 1.0
        result = wm.build(ref_timestamp=ts)
        age = snapshot_age_s(result.snapshot)
        assert age >= 1.0

    def test_snapshot_stale_check(self):
        wm = WorldModel(config=_default_config())
        old_ts = time.time() - 5.0
        result = wm.build(ref_timestamp=old_ts)
        assert is_snapshot_stale(result.snapshot, max_age_s=2.0)
        assert not is_snapshot_stale(result.snapshot, max_age_s=100.0)

    def test_snapshot_history_is_copy(self):
        cfg = WorldModelConfig(snapshot_buffer_size=5)
        wm = WorldModel(config=cfg)
        wm.build()
        history = wm.snapshot_history()
        assert isinstance(history, list)
        # Mutating the returned list must not affect internal buffer
        history.clear()
        assert len(wm.snapshot_history()) == 1

    def test_snapshot_json_deterministic(self):
        """Same snapshot serialised twice → same JSON."""
        wm = WorldModel(config=_default_config())
        result = wm.build(ref_timestamp=1234567890.0)
        j1 = snapshot_to_json(result.snapshot)
        j2 = snapshot_to_json(result.snapshot)
        assert j1 == j2


# ============================================================
# Validation tests
# ============================================================

class TestValidation:

    def setup_method(self):
        self.cfg = _default_config()
        self.validator = WorldModelValidator(self.cfg)

    def _make_minimal_snapshot(self, ts=None):
        return WorldModelSnapshot(
            schema_version="7.0",
            timestamp=ts if ts is not None else time.time(),
            frame_id=0,
            _objects=tuple(),
        )

    def test_valid_empty_snapshot(self):
        snap = self._make_minimal_snapshot()
        result = self.validator.validate(snap)
        assert result.status in ("valid", "partial")

    def test_invalid_timestamp_zero(self):
        snap = self._make_minimal_snapshot(ts=0.0)
        result = self.validator.validate(snap)
        assert result.status in ("partial", "invalid", "degraded")

    def test_invalid_timestamp_negative(self):
        snap = self._make_minimal_snapshot(ts=-1.0)
        result = self.validator.validate(snap)
        assert "non-positive" in " ".join(result.errors)

    def test_invalid_coordinate_frame(self):
        snap = self._make_minimal_snapshot()
        snap.coordinate_frame = CoordinateFrame.INVALID
        result = self.validator.validate(snap)
        assert any("INVALID" in e or "coordinate" in e.lower() for e in result.errors)

    def test_unknown_coordinate_frame_warning(self):
        snap = self._make_minimal_snapshot()
        snap.coordinate_frame = CoordinateFrame.UNKNOWN
        result = self.validator.validate(snap)
        assert any("UNKNOWN" in w or "coordinate" in w.lower() for w in result.warnings)

    def test_object_count_exceeded_error(self):
        cfg = WorldModelConfig(max_objects=2)
        validator = WorldModelValidator(cfg)
        objs = tuple(
            WorldObject(track_id=f"t{i}", object_type="VEHICLE",
                        observation_timestamp=time.time())
            for i in range(5)
        )
        snap = self._make_minimal_snapshot()
        snap._objects = objs
        result = validator.validate(snap)
        assert any("max_objects" in e for e in result.errors)

    def test_duplicate_track_id_error(self):
        t = time.time()
        objs = tuple(
            WorldObject(track_id="t1", object_type="VEHICLE", observation_timestamp=t)
            for _ in range(2)
        )
        snap = self._make_minimal_snapshot()
        snap._objects = objs
        result = self.validator.validate(snap)
        assert any("duplicate" in e.lower() for e in result.errors)

    def test_invalid_confidence_value(self):
        obj = WorldObject(
            track_id="t1",
            observation_timestamp=time.time(),
            quality=WorldObjectQuality(object_confidence=1.5),  # > 1.0
        )
        snap = self._make_minimal_snapshot()
        snap._objects = (obj,)
        result = self.validator.validate(snap)
        assert any("object_confidence" in e for e in result.errors)

    def test_invalid_road_confidence(self):
        snap = self._make_minimal_snapshot()
        snap.road.road_confidence = -0.1
        result = self.validator.validate(snap)
        assert any("road_confidence" in e for e in result.errors)

    def test_validation_result_is_usable(self):
        snap = self._make_minimal_snapshot()
        result = self.validator.validate(snap)
        assert result.is_usable

    def test_invalid_anomaly_confidence(self):
        snap = self._make_minimal_snapshot()
        anomaly = WorldAnomalySummary(anomaly_id="a1", confidence=2.0)  # > 1.0
        snap.road._WorldRoadRepresentation__dict__ = {}  # bypass
        snap.road.anomalies = [anomaly]
        result = self.validator.validate(snap)
        assert any("anomaly" in e.lower() or "confidence" in e.lower() for e in result.errors)

    def test_invalid_indian_context_confidence(self):
        snap = self._make_minimal_snapshot()
        snap.indian_context.context_confidence = -0.5
        result = self.validator.validate(snap)
        assert any("context_confidence" in e for e in result.errors)


# ============================================================
# Determinism tests
# ============================================================

class TestDeterminism:

    def test_same_input_same_output(self):
        cfg = _default_config()
        ts = 999999.0
        fobj = _make_fused_object(timestamp=ts - 0.1)
        fws = _make_fused_world_state(objects=[fobj], timestamp=ts)
        rus = _make_road_understanding_state(timestamp=ts)

        r1 = WorldModel(config=cfg).build(
            fused_world_state=fws, road_understanding_state=rus, ref_timestamp=ts
        )
        r2 = WorldModel(config=cfg).build(
            fused_world_state=fws, road_understanding_state=rus, ref_timestamp=ts
        )

        assert r1.snapshot.object_count == r2.snapshot.object_count
        assert r1.snapshot.status == r2.snapshot.status
        assert r1.snapshot.data_quality.overall_confidence == pytest.approx(
            r2.snapshot.data_quality.overall_confidence, abs=1e-6
        )

    def test_stable_object_ordering(self):
        cfg = _default_config()
        fobjs = [
            _make_fused_object(fused_id=f"fo{i}", track_id=f"t{i}",
                                position=_make_position3d(float(i * 5), 0.0, 0.0))
            for i in range(5)
        ]
        fws = _make_fused_world_state(objects=fobjs)

        r1 = WorldModel(config=cfg).build(fused_world_state=fws, ref_timestamp=1000.0)
        r2 = WorldModel(config=cfg).build(fused_world_state=fws, ref_timestamp=1000.0)

        ids1 = [o.fused_id for o in r1.snapshot.objects]
        ids2 = [o.fused_id for o in r2.snapshot.objects]
        assert ids1 == ids2

    def test_stable_validation_result(self):
        cfg = _default_config()
        ts = 1234567.0
        snap = WorldModelSnapshot(
            schema_version="7.0",
            timestamp=ts,
            frame_id=0,
            _objects=tuple(),
        )
        validator = WorldModelValidator(cfg)
        r1 = validator.validate(snap)
        r2 = validator.validate(snap)
        assert r1.status == r2.status
        assert r1.errors == r2.errors

    def test_confidence_aggregation_stable(self):
        cfg = _default_config()
        fobj = _make_fused_object(confidence=0.9)
        fws = _make_fused_world_state(objects=[fobj], timestamp=5000.0)

        c1 = WorldModel(config=cfg).build(fused_world_state=fws, ref_timestamp=5000.0)
        c2 = WorldModel(config=cfg).build(fused_world_state=fws, ref_timestamp=5000.0)

        assert c1.snapshot.data_quality.overall_confidence == pytest.approx(
            c2.snapshot.data_quality.overall_confidence, abs=1e-6
        )


# ============================================================
# Performance tests
# ============================================================

class TestPerformance:

    def test_empty_scene_performance(self):
        """Empty scene should build in well under 50ms."""
        wm = WorldModel(config=_default_config())
        t0 = time.perf_counter()
        for _ in range(100):
            wm.build()
        elapsed = time.perf_counter() - t0
        avg_ms = elapsed / 100 * 1000
        assert avg_ms < 50.0, f"Empty build took {avg_ms:.2f}ms avg (>50ms)"

    def test_small_scene_performance(self):
        """5 objects scene should build in under 20ms per call."""
        wm = WorldModel(config=_default_config())
        fobjs = [
            _make_fused_object(fused_id=f"fo{i}", track_id=f"t{i}",
                                position=_make_position3d(float(i * 5), 0.0, 0.0))
            for i in range(5)
        ]
        fws = _make_fused_world_state(objects=fobjs)
        rus = _make_road_understanding_state()

        t0 = time.perf_counter()
        for _ in range(50):
            wm.build(fused_world_state=fws, road_understanding_state=rus)
        elapsed = time.perf_counter() - t0
        avg_ms = elapsed / 50 * 1000
        assert avg_ms < 100.0, f"Small scene took {avg_ms:.2f}ms avg (>100ms)"

    def test_medium_scene_performance(self):
        """20 objects should complete in under 100ms per call."""
        wm = WorldModel(config=_default_config())
        fobjs = [
            _make_fused_object(fused_id=f"fo{i}", track_id=f"t{i}",
                                position=_make_position3d(float(i * 2), float(i % 3), 0.0))
            for i in range(20)
        ]
        fws = _make_fused_world_state(objects=fobjs)
        rus = _make_road_understanding_state(anomaly_count=5)

        t0 = time.perf_counter()
        for _ in range(20):
            wm.build(fused_world_state=fws, road_understanding_state=rus)
        elapsed = time.perf_counter() - t0
        avg_ms = elapsed / 20 * 1000
        assert avg_ms < 200.0, f"Medium scene took {avg_ms:.2f}ms avg (>200ms)"

    def test_max_scene_performance(self):
        """Max configured objects must complete without OOM."""
        cfg = WorldModelConfig(max_objects=128)
        wm = WorldModel(config=cfg)
        fobjs = [
            _make_fused_object(fused_id=f"fo{i}", track_id=f"t{i}",
                                position=_make_position3d(float(i * 1.5), float(i % 5), 0.0))
            for i in range(128)
        ]
        fws = _make_fused_world_state(objects=fobjs)
        t0 = time.perf_counter()
        result = wm.build(fused_world_state=fws)
        elapsed = time.perf_counter() - t0
        assert result.snapshot.object_count <= 128
        assert elapsed < 5.0, f"Max scene took {elapsed:.2f}s (>5s)"


# ============================================================
# Config tests
# ============================================================

class TestConfig:

    def test_default_config_loads(self):
        cfg = WorldModelConfig()
        assert cfg.max_objects > 0
        assert cfg.max_trajectory_points > 0
        assert cfg.max_data_age_seconds > 0

    def test_config_from_dict(self):
        d = {"max_objects": 64, "max_data_age_seconds": 0.5}
        cfg = WorldModelConfig.from_dict(d)
        assert cfg.max_objects == 64
        assert cfg.max_data_age_seconds == pytest.approx(0.5)

    def test_config_unknown_keys_ignored(self):
        d = {"max_objects": 32, "totally_made_up_key": "ignored"}
        cfg = WorldModelConfig.from_dict(d)
        assert cfg.max_objects == 32

    def test_config_to_dict_round_trip(self):
        cfg = WorldModelConfig(max_objects=55)
        d = cfg.to_dict()
        cfg2 = WorldModelConfig.from_dict(d)
        assert cfg2.max_objects == 55

    def test_config_version_present(self):
        cfg = WorldModelConfig()
        assert cfg.config_version == "7.0"

    def test_world_model_uses_config(self):
        cfg = WorldModelConfig(max_objects=2)
        wm = WorldModel(config=cfg)
        assert wm.config.max_objects == 2


# ============================================================
# WorldObject unit tests
# ============================================================

class TestWorldObjectTypes:

    def test_position_is_valid(self):
        pos = WorldObjectPosition(x=5.0, y=1.0, z=0.3)
        assert pos.is_valid()

    def test_position_invalid_when_none(self):
        pos = WorldObjectPosition(x=None, y=None)
        assert not pos.is_valid()

    def test_position_distance_computed(self):
        pos = WorldObjectPosition(x=3.0, y=4.0, z=0.0)
        d = pos.compute_distance()
        assert d == pytest.approx(5.0, abs=1e-3)

    def test_velocity_is_valid(self):
        vel = WorldObjectVelocity(vx=3.0, vy=0.5, vz=0.0)
        assert vel.is_valid()

    def test_dimensions_is_valid(self):
        dim = WorldObjectDimensions(length_m=4.5, width_m=2.0, height_m=1.5)
        assert dim.is_valid()

    def test_dimensions_invalid_when_zero(self):
        dim = WorldObjectDimensions(length_m=0.0, width_m=2.0, height_m=1.5)
        assert not dim.is_valid()

    def test_world_object_primary_id_priority(self):
        obj = WorldObject(object_id="mem1", track_id="t1", fused_id="f1")
        assert obj.primary_id() == "mem1"

    def test_world_object_primary_id_falls_back(self):
        obj = WorldObject(track_id="t1", fused_id="f1")
        assert obj.primary_id() == "t1"

    def test_world_object_to_dict(self):
        obj = WorldObject(
            track_id="t1",
            object_type="VEHICLE",
            observation_timestamp=time.time(),
        )
        d = obj.to_dict()
        assert "track_id" in d
        assert "object_type" in d
        assert d["object_type"] == "VEHICLE"

    def test_high_risk_detection(self):
        obj = WorldObject(
            collision=WorldObjectCollisionInfo(risk_level="HIGH")
        )
        assert obj.is_high_risk()

    def test_low_risk_not_high_risk(self):
        obj = WorldObject(
            collision=WorldObjectCollisionInfo(risk_level="LOW")
        )
        assert not obj.is_high_risk()
