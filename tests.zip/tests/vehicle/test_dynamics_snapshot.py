"""
Phase 10.1 — Tests: DynamicsSnapshot (Section 56)
"""
import math

from core.vehicle.vehicle_parameters import VehicleParameters
from core.vehicle.vehicle_state import VehicleState
from core.vehicle.dynamics_snapshot import DynamicsSnapshot
from core.vehicle.vehicle_types import ModelVersion, CoordinateFrame, VEHICLE_SCHEMA_VERSION


class TestDynamicsSnapshot:
    def setup_method(self):
        self.params = VehicleParameters.default()
        self.state = VehicleState(
            x=10.0, y=2.0, yaw=0.3,
            velocity=12.0, acceleration=1.0,
            steering_angle=0.15, yaw_rate=0.7,
            timestamp=5.0, frame_id=50,
        )

    def test_from_state_factory(self):
        snap = DynamicsSnapshot.from_state(self.state, self.params)
        assert snap.x == self.state.x
        assert snap.y == self.state.y
        assert snap.velocity == self.state.velocity
        assert snap.steering_angle == self.state.steering_angle
        assert snap.sim_timestamp == self.state.timestamp
        assert snap.frame_id == self.state.frame_id

    def test_model_version_set(self):
        snap = DynamicsSnapshot.from_state(self.state, self.params)
        assert snap.model_version == ModelVersion.KINEMATIC_BICYCLE_V1

    def test_schema_version_set(self):
        snap = DynamicsSnapshot.from_state(self.state, self.params)
        assert snap.schema_version == VEHICLE_SCHEMA_VERSION

    def test_coordinate_frame(self):
        snap = DynamicsSnapshot.from_state(self.state, self.params)
        assert snap.coordinate_frame == CoordinateFrame.VEHICLE

    def test_curvature_derived(self):
        delta = self.state.steering_angle
        L = self.params.wheelbase_m
        expected = math.tan(delta) / L
        snap = DynamicsSnapshot.from_state(self.state, self.params)
        assert abs(snap.curvature - expected) < 1e-9

    def test_snapshot_is_immutable(self):
        """frozen=True — modification must raise."""
        snap = DynamicsSnapshot.from_state(self.state, self.params)
        try:
            snap.x = 999.0
            assert False, "Should have raised"
        except (AttributeError, TypeError):
            pass

    def test_snapshot_not_affected_by_state_change(self):
        """Snapshot stores scalar copies; mutating source state should not
        affect snapshot values."""
        snap = DynamicsSnapshot.from_state(self.state, self.params)
        x_snap = snap.x
        # Mutate source state (dataclass is not frozen)
        self.state.x = 9999.0
        # Snapshot must be unchanged
        assert snap.x == x_snap

    def test_wheelbase_preserved(self):
        snap = DynamicsSnapshot.from_state(self.state, self.params)
        assert snap.wheelbase_m == self.params.wheelbase_m

    def test_repr_contains_model_version(self):
        snap = DynamicsSnapshot.from_state(self.state, self.params)
        assert "KINEMATIC_BICYCLE_V1" in repr(snap)

    def test_turning_radius_for_zero_steering(self):
        state_zero = VehicleState(steering_angle=0.0, velocity=10.0)
        snap = DynamicsSnapshot.from_state(state_zero, self.params)
        assert math.isinf(snap.turning_radius)
