"""
Phase 10.1 — Tests: VehicleParameters
"""
import math

from core.vehicle.vehicle_parameters import VehicleParameters


class TestVehicleParametersDefaults:
    def test_default_construction(self):
        p = VehicleParameters.default()
        assert p.wheelbase_m > 0
        assert p.vehicle_length_m >= p.wheelbase_m
        assert p.vehicle_width_m > 0
        assert p.max_steering_angle_rad > 0
        assert p.max_steering_rate_rad_s > 0
        assert p.min_velocity_mps >= 0
        assert p.max_velocity_mps > p.min_velocity_mps
        assert p.max_acceleration_mps2 > 0
        assert p.min_acceleration_mps2 < 0

    def test_all_finite(self):
        p = VehicleParameters.default()
        for name in [
            "wheelbase_m", "front_axle_distance_m", "rear_axle_distance_m",
            "vehicle_length_m", "vehicle_width_m", "max_steering_angle_rad",
            "max_steering_rate_rad_s", "min_velocity_mps", "max_velocity_mps",
            "min_acceleration_mps2", "max_acceleration_mps2",
        ]:
            assert math.isfinite(getattr(p, name)), f"{name} is not finite"

    def test_axle_sum_equals_wheelbase(self):
        p = VehicleParameters.default()
        assert abs(p.front_axle_distance_m + p.rear_axle_distance_m - p.wheelbase_m) < 1e-9

    def test_frozen(self):
        p = VehicleParameters.default()
        try:
            p.wheelbase_m = 99.0
            assert False, "Should have raised"
        except (AttributeError, TypeError):
            pass  # expected — frozen dataclass


class TestVehicleParametersValidation:
    def _make(self, **kwargs):
        defaults = dict(
            wheelbase_m=2.85, front_axle_distance_m=1.50,
            rear_axle_distance_m=1.35, vehicle_length_m=4.50,
            vehicle_width_m=1.80, max_steering_angle_rad=0.61,
            max_steering_rate_rad_s=0.70, min_velocity_mps=0.0,
            max_velocity_mps=33.33, min_acceleration_mps2=-8.0,
            max_acceleration_mps2=4.0,
        )
        defaults.update(kwargs)
        return VehicleParameters(**defaults)

    def test_zero_wheelbase_rejected(self):
        try:
            self._make(wheelbase_m=0.0, front_axle_distance_m=0.0,
                       rear_axle_distance_m=0.0)
            assert False
        except (ValueError, Exception):
            pass

    def test_negative_wheelbase_rejected(self):
        try:
            self._make(wheelbase_m=-1.0)
            assert False
        except (ValueError, Exception):
            pass

    def test_zero_width_rejected(self):
        try:
            self._make(vehicle_width_m=0.0)
            assert False
        except (ValueError, Exception):
            pass

    def test_nan_rejected(self):
        try:
            self._make(wheelbase_m=float("nan"))
            assert False
        except (ValueError, Exception):
            pass

    def test_inf_rejected(self):
        try:
            self._make(max_velocity_mps=float("inf"))
            assert False
        except (ValueError, Exception):
            pass

    def test_negative_max_accel_rejected(self):
        try:
            self._make(max_acceleration_mps2=-1.0)
            assert False
        except (ValueError, Exception):
            pass

    def test_positive_min_accel_rejected(self):
        try:
            self._make(min_acceleration_mps2=1.0)
            assert False
        except (ValueError, Exception):
            pass

    def test_max_vel_less_than_min_vel_rejected(self):
        try:
            self._make(min_velocity_mps=10.0, max_velocity_mps=5.0)
            assert False
        except (ValueError, Exception):
            pass

    def test_negative_min_velocity_rejected(self):
        try:
            self._make(min_velocity_mps=-1.0)
            assert False
        except (ValueError, Exception):
            pass

    def test_length_less_than_wheelbase_rejected(self):
        try:
            self._make(vehicle_length_m=1.0, wheelbase_m=2.85,
                       front_axle_distance_m=1.50, rear_axle_distance_m=1.35)
            assert False
        except (ValueError, Exception):
            pass

    def test_axle_mismatch_rejected(self):
        try:
            self._make(wheelbase_m=2.85, front_axle_distance_m=1.00,
                       rear_axle_distance_m=1.00)  # sum=2.00 ≠ 2.85
            assert False
        except (ValueError, Exception):
            pass


class TestVehicleParametersHelpers:
    def setup_method(self):
        self.p = VehicleParameters.default()

    def test_clamp_steering_at_limit(self):
        lim = self.p.max_steering_angle_rad
        assert abs(self.p.clamp_steering(lim) - lim) < 1e-9
        assert abs(self.p.clamp_steering(-lim) - (-lim)) < 1e-9

    def test_clamp_steering_beyond_limit(self):
        lim = self.p.max_steering_angle_rad
        assert abs(self.p.clamp_steering(lim * 2) - lim) < 1e-9
        assert abs(self.p.clamp_steering(-lim * 2) - (-lim)) < 1e-9

    def test_clamp_acceleration_within(self):
        a = (self.p.min_acceleration_mps2 + self.p.max_acceleration_mps2) / 2
        assert abs(self.p.clamp_acceleration(a) - a) < 1e-9

    def test_clamp_acceleration_beyond_max(self):
        big = self.p.max_acceleration_mps2 * 10
        assert abs(self.p.clamp_acceleration(big) - self.p.max_acceleration_mps2) < 1e-9

    def test_clamp_acceleration_beyond_min(self):
        small = self.p.min_acceleration_mps2 * 10
        assert abs(self.p.clamp_acceleration(small) - self.p.min_acceleration_mps2) < 1e-9

    def test_clamp_velocity(self):
        assert self.p.clamp_velocity(-5.0) == self.p.min_velocity_mps
        assert self.p.clamp_velocity(9999.0) == self.p.max_velocity_mps

    def test_half_width(self):
        assert abs(self.p.half_width_m - self.p.vehicle_width_m / 2) < 1e-9
