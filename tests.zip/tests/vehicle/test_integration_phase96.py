"""
Phase 10.1 — Integration Test with Phase 9.6 (Section 58)

Tests that Phase 10.1 vehicle model can be initialised from data types
produced by the Phase 9.6 planner output, and that kinematic propagation
works on that initialised state.

This test does NOT:
    * build a Planner → Controller closed loop
    * send anything to CARLA
    * implement trajectory tracking

It only performs:
    Phase 9.6 planner output
        → vehicle-state initialisation
        → kinematic bicycle-model propagation
"""
import math

from core.vehicle.vehicle_state import VehicleState
from core.vehicle.vehicle_input import VehicleControlInput
from core.vehicle.vehicle_parameters import VehicleParameters
from core.vehicle.bicycle_model import KinematicBicycleModel
from core.vehicle.vehicle_types import StateKind, CoordinateFrame


class TestPhase96Integration:
    """
    Simulates consuming a Phase 9.6 PlannerOutput candidate path and
    propagating the ego vehicle from an assumed initial state.

    Phase 9.6 produces:
        selected_candidate_id  — string ID of the chosen candidate
        PlannerOutput          — planning-level result (no actuator commands)

    Phase 10.1 accepts:
        An initialised VehicleState (from localisation / sensor pipeline)
        A simplified control sequence (future Phase 10.2–10.4 will derive this)
    """

    def _make_ego_state_from_planner_context(self) -> VehicleState:
        """
        In a real system, ego state comes from localisation, not the planner.
        Here we build a representative state for the integration test.
        """
        return VehicleState(
            x=0.0,
            y=0.0,
            yaw=0.0,
            velocity=8.33,   # ~30 km/h
            acceleration=0.0,
            steering_angle=0.0,
            yaw_rate=0.0,
            timestamp=0.0,
            frame_id=0,
            coordinate_frame=CoordinateFrame.VEHICLE,
            state_kind=StateKind.ESTIMATED,
        )

    def test_propagate_from_planner_context(self):
        """
        Propagate ego state forward as if Phase 10.2 had issued a
        basic straight-line control input.
        """
        params = VehicleParameters.default()
        model  = KinematicBicycleModel(params)
        ego    = self._make_ego_state_from_planner_context()

        ego.validate()  # must pass

        # Simulate: 10 steps of straight-line motion
        dt  = 0.1
        seq = [VehicleControlInput.zero(timestamp=i * dt) for i in range(10)]
        traj = model.simulate(ego, seq, dt=dt)

        assert traj.length == 11
        # Moving forward on straight road
        assert traj.states[-1].x > ego.x
        assert abs(traj.states[-1].y - ego.y) < 1e-6
        assert abs(traj.states[-1].yaw - ego.yaw) < 1e-6
        # All states finite and valid
        for s in traj.states:
            s.validate()

    def test_planner_candidate_id_is_not_in_vehicle_state(self):
        """
        Phase 9.6 selected_candidate_id is a planning artifact, NOT part
        of VehicleState.  Confirm VehicleState has no such field.
        """
        s = VehicleState()
        assert not hasattr(s, "selected_candidate_id")
        assert not hasattr(s, "candidate_id")
        assert not hasattr(s, "planning_status")

    def test_state_kind_updated_to_simulated(self):
        """
        After step(), state_kind must be SIMULATED — regardless of the
        source state's kind (ESTIMATED from localisation → SIMULATED
        after bicycle-model propagation).
        """
        params = VehicleParameters.default()
        model  = KinematicBicycleModel(params)
        ego    = self._make_ego_state_from_planner_context()
        assert ego.state_kind == StateKind.ESTIMATED

        u  = VehicleControlInput.zero()
        s1 = model.step(ego, u, dt=0.1)
        assert s1.state_kind == StateKind.SIMULATED

    def test_coordinate_frame_vehicle(self):
        """
        Both Phase 9.6 and Phase 10.1 use vehicle-frame coordinates
        (+X forward, +Y left, +Z up, origin = rear-axle centre).
        """
        s = VehicleState()
        assert s.coordinate_frame == CoordinateFrame.VEHICLE

    def test_no_planner_import_needed_for_propagation(self):
        """
        Vehicle propagation must not depend on the planner modules.
        This ensures clean separation.
        """
        # Import succeeds without importing any planning module
        from core.vehicle.bicycle_model import KinematicBicycleModel
        from core.vehicle.vehicle_state import VehicleState
        from core.vehicle.vehicle_input import VehicleControlInput
        from core.vehicle.vehicle_parameters import VehicleParameters

        m  = KinematicBicycleModel(VehicleParameters.default())
        s  = VehicleState(velocity=10.0)
        u  = VehicleControlInput(steering_angle=0.1)
        s1 = m.step(s, u, dt=0.1)
        assert s1.is_finite()
