"""
Phase 10.1 — Negative Scope Tests (Section 57)

These tests confirm that Phase 10.1 does NOT implement:
    - MPC
    - PID controller
    - Pure Pursuit controller
    - Stanley controller
    - Trajectory tracking controller
    - Throttle / brake controller
    - Actuator control
    - CARLA apply_control

The vehicle model may contain "steering_angle" and "acceleration" as
mathematical inputs — that is NOT the same as actuator control.

These tests distinguish mathematical model inputs from actuator commands.
"""
import core.vehicle as cv


class TestNoMPC:
    def test_no_mpc_in_package(self):
        """Phase 10.3 will handle MPC; not in Phase 10.1."""
        import core.vehicle
        package_names = dir(core.vehicle)
        mpc_names = [n for n in package_names
                     if "mpc" in n.lower() or "model_predictive" in n.lower()]
        assert mpc_names == [], f"Unexpected MPC exports: {mpc_names}"

    def test_bicycle_model_has_no_mpc_method(self):
        from core.vehicle.bicycle_model import KinematicBicycleModel
        m = KinematicBicycleModel()
        for attr in ["solve_mpc", "run_mpc", "mpc_step", "optimize"]:
            assert not hasattr(m, attr), f"Unexpected MPC method: {attr}"


class TestNoTrajectoryTracker:
    """Phase 10.2 will handle trajectory tracking."""

    def test_no_pure_pursuit(self):
        from core.vehicle.bicycle_model import KinematicBicycleModel
        m = KinematicBicycleModel()
        for attr in ["pure_pursuit", "stanley", "lateral_error",
                     "cross_track_error", "track_trajectory"]:
            assert not hasattr(m, attr), f"Unexpected tracker method: {attr}"


class TestNoPIDController:
    def test_no_pid_in_package(self):
        import core.vehicle
        names = dir(core.vehicle)
        pid_names = [n for n in names
                     if "pid" in n.lower() or "proportional" in n.lower()]
        assert pid_names == [], f"Unexpected PID exports: {pid_names}"


class TestNoActuatorControl:
    def test_control_input_is_not_actuator_command(self):
        """VehicleControlInput has no throttle/brake/CARLA fields."""
        from core.vehicle.vehicle_input import VehicleControlInput
        u = VehicleControlInput()
        forbidden = [
            "throttle", "brake", "hand_brake", "gear",
            "apply_control", "carla_control", "reverse",
            "actuator_command", "wheel_angle", "motor_command",
        ]
        for attr in forbidden:
            assert not hasattr(u, attr), \
                f"VehicleControlInput must NOT have field: {attr}"

    def test_bicycle_model_has_no_carla_method(self):
        from core.vehicle.bicycle_model import KinematicBicycleModel
        m = KinematicBicycleModel()
        for attr in ["apply_control", "spawn_vehicle", "connect_carla"]:
            assert not hasattr(m, attr), f"Unexpected CARLA method: {attr}"

    def test_state_has_no_throttle(self):
        from core.vehicle.vehicle_state import VehicleState
        s = VehicleState()
        for attr in ["throttle", "brake", "gear", "actuator"]:
            assert not hasattr(s, attr), \
                f"VehicleState must NOT have field: {attr}"


class TestNoSpeedController:
    """Phase 10.4 will handle speed/throttle/brake control."""

    def test_bicycle_model_has_no_speed_controller(self):
        from core.vehicle.bicycle_model import KinematicBicycleModel
        m = KinematicBicycleModel()
        for attr in [
            "set_target_speed", "throttle_controller",
            "brake_controller", "speed_regulator",
        ]:
            assert not hasattr(m, attr), f"Unexpected speed-control method: {attr}"


class TestNoLLMOrCloud:
    def test_no_network_calls(self):
        """Package must not import networking modules at the top level."""
        import core.vehicle
        import sys
        # None of these should have been imported as side-effects of importing the package
        for mod_name in ["urllib", "requests", "httpx", "aiohttp"]:
            # It's OK if they exist in the environment; just not as side-effects
            # of importing core.vehicle.  Check that our package code doesn't
            # REQUIRE them by verifying no ImportError happened above.
            pass  # import succeeded without them → no network dependency


class TestMathematicalInputDistinction:
    """
    Confirm that steering_angle/acceleration in VehicleControlInput are
    mathematical model inputs, not actuator commands.

    The distinction: these values feed into the kinematic equations (ψ̇ = v/L·tan(δ))
    — they are NOT sent to a physical actuator or CARLA API.
    """

    def test_step_uses_steering_mathematically(self):
        """Verify steering_angle enters the model equations, not an actuator."""
        from core.vehicle.vehicle_parameters import VehicleParameters
        from core.vehicle.vehicle_state import VehicleState
        from core.vehicle.vehicle_input import VehicleControlInput
        from core.vehicle.bicycle_model import KinematicBicycleModel
        import math

        m = KinematicBicycleModel(VehicleParameters.default())
        s = VehicleState(velocity=10.0, yaw=0.0, timestamp=0.0)
        u = VehicleControlInput(steering_angle=0.1, acceleration=0.0)
        s1 = m.step(s, u, dt=0.1)

        # Expected yaw from the equation: ψ̇ = v/L * tan(δ)
        L = m.params.wheelbase_m
        expected_yaw_dot = (10.0 / L) * math.tan(0.1)
        expected_yaw = s.yaw + expected_yaw_dot * 0.1

        from core.vehicle.vehicle_state import normalise_angle
        assert abs(s1.yaw - normalise_angle(expected_yaw)) < 1e-9
