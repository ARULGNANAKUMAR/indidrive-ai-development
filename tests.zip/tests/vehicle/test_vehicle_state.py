"""
Phase 10.1 — Tests: VehicleState and angle normalisation
"""
import math

from core.vehicle.vehicle_state import VehicleState, normalise_angle
from core.vehicle.vehicle_types import CoordinateFrame, StateKind


class TestAngleNormalisation:
    def test_zero(self):
        assert abs(normalise_angle(0.0)) < 1e-12

    def test_pi_wraps_to_negative_pi(self):
        result = normalise_angle(math.pi)
        assert abs(result - (-math.pi)) < 1e-9

    def test_negative_pi_stays_negative_pi(self):
        result = normalise_angle(-math.pi)
        assert abs(result - (-math.pi)) < 1e-9

    def test_three_pi(self):
        # 3π ≡ π (mod 2π) → wraps to -π
        result = normalise_angle(3 * math.pi)
        assert abs(abs(result) - math.pi) < 1e-9

    def test_two_pi(self):
        result = normalise_angle(2 * math.pi)
        assert abs(result) < 1e-9

    def test_negative_two_pi(self):
        result = normalise_angle(-2 * math.pi)
        assert abs(result) < 1e-9

    def test_quarter_pi(self):
        result = normalise_angle(math.pi / 4)
        assert abs(result - math.pi / 4) < 1e-9

    def test_large_positive(self):
        result = normalise_angle(100 * math.pi)
        assert -math.pi <= result < math.pi

    def test_large_negative(self):
        result = normalise_angle(-100 * math.pi)
        assert -math.pi <= result < math.pi

    def test_result_in_range(self):
        for angle in [0, 0.5, 1.0, 1.5, 2.0, 2.5, 3.0, 3.5, -0.5, -1.0,
                      -1.5, -2.0, -3.0, -3.5, math.pi, -math.pi]:
            r = normalise_angle(angle)
            assert -math.pi <= r < math.pi, f"angle={angle} → {r}"


class TestVehicleStateConstruction:
    def test_default_state(self):
        s = VehicleState()
        assert s.x == 0.0
        assert s.y == 0.0
        assert s.yaw == 0.0
        assert s.velocity == 0.0
        assert s.coordinate_frame == CoordinateFrame.VEHICLE
        assert s.state_kind == StateKind.SIMULATED

    def test_yaw_normalised_on_construction(self):
        s = VehicleState(yaw=math.pi)
        assert abs(s.yaw - (-math.pi)) < 1e-9

    def test_is_finite_on_default(self):
        assert VehicleState().is_finite()

    def test_origin_factory(self):
        s = VehicleState.origin(timestamp=5.0)
        assert s.timestamp == 5.0
        assert s.x == 0.0

    def test_copy_is_independent(self):
        s = VehicleState(x=1.0, y=2.0, velocity=10.0)
        c = s.copy()
        assert c.x == s.x
        assert c.y == s.y
        # Modify original — copy unaffected
        s.x = 99.0
        assert c.x == 1.0


class TestVehicleStateValidation:
    def test_valid_state_passes(self):
        s = VehicleState(x=1.0, y=2.0, yaw=0.5, velocity=10.0, timestamp=1.0)
        s.validate()  # should not raise

    def test_nan_x_rejected(self):
        s = VehicleState(x=float("nan"))
        try:
            s.validate()
            assert False
        except ValueError:
            pass

    def test_nan_velocity_rejected(self):
        s = VehicleState(velocity=float("nan"))
        try:
            s.validate()
            assert False
        except ValueError:
            pass

    def test_inf_rejected(self):
        s = VehicleState(y=float("inf"))
        try:
            s.validate()
            assert False
        except ValueError:
            pass

    def test_negative_velocity_rejected(self):
        s = VehicleState(velocity=-1.0)
        try:
            s.validate()
            assert False
        except ValueError:
            pass

    def test_negative_frame_id_rejected(self):
        s = VehicleState(frame_id=-1)
        try:
            s.validate()
            assert False
        except ValueError:
            pass

    def test_zero_velocity_accepted(self):
        s = VehicleState(velocity=0.0)
        s.validate()  # must not raise

    def test_is_finite_with_nan(self):
        s = VehicleState(x=float("nan"))
        assert not s.is_finite()

    def test_repr_contains_velocity(self):
        s = VehicleState(velocity=10.0)
        assert "10.00 m/s" in repr(s)
