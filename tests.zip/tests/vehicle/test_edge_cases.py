"""
Phase 10.1 — Edge Cases and Numerical Safety
"""
import math

from core.vehicle.vehicle_parameters import VehicleParameters
from core.vehicle.vehicle_state import VehicleState
from core.vehicle.vehicle_input import VehicleControlInput
from core.vehicle.bicycle_model import KinematicBicycleModel
from core.vehicle.dynamics_snapshot import DynamicsSnapshot
from core.vehicle.dynamics_config import DynamicsConfig
from core.vehicle.vehicle_types import SteeringPolicy


def _model(policy=SteeringPolicy.CLAMP):
    return KinematicBicycleModel(VehicleParameters.default(), steering_policy=policy)


class TestEdgeCases:
    def test_very_small_dt(self):
        """Very small but positive dt should work."""
        m = _model()
        s = VehicleState(velocity=10.0)
        u = VehicleControlInput(steering_angle=0.1, acceleration=0.0)
        s1 = m.step(s, u, dt=1e-6)
        assert s1.is_finite()

    def test_very_small_velocity(self):
        """Near-zero velocity should not blow up."""
        m = _model()
        s = VehicleState(velocity=1e-9)
        u = VehicleControlInput(steering_angle=0.3, acceleration=0.0)
        s1 = m.step(s, u, dt=0.1)
        assert s1.is_finite()
        assert s1.velocity >= 0.0

    def test_max_velocity_clamped(self):
        """Velocity cannot exceed max_velocity_mps."""
        m = _model()
        p = m.params
        s = VehicleState(velocity=p.max_velocity_mps - 0.1)
        u = VehicleControlInput(acceleration=100.0)
        s1 = m.step(s, u, dt=0.5)
        assert s1.velocity <= p.max_velocity_mps + 1e-9

    def test_multiple_full_rotations(self):
        """After many steps the yaw must stay normalised."""
        m = _model()
        s = VehicleState(velocity=5.0, yaw=0.0)
        u = VehicleControlInput(steering_angle=0.5)  # fast turning
        for _ in range(200):
            s = m.step(s, u, dt=0.1)
        assert -math.pi <= s.yaw < math.pi

    def test_zero_acceleration_coast(self):
        v0 = 15.0
        m = _model()
        s = VehicleState(velocity=v0)
        u = VehicleControlInput(acceleration=0.0)
        for _ in range(50):
            s = m.step(s, u, dt=0.1)
        assert abs(s.velocity - v0) < 1e-9

    def test_snapshot_from_zero_state(self):
        params = VehicleParameters.default()
        state  = VehicleState()
        snap   = DynamicsSnapshot.from_state(state, params)
        assert snap.curvature == 0.0
        assert math.isinf(snap.turning_radius)
        assert snap.velocity == 0.0

    def test_config_default(self):
        cfg = DynamicsConfig.default()
        assert cfg.params is not None
        assert cfg.dt_max_s > 0

    def test_config_from_dict_partial(self):
        cfg = DynamicsConfig.from_dict({"max_velocity_mps": 20.0})
        assert abs(cfg.params.max_velocity_mps - 20.0) < 1e-9

    def test_simulate_single_step(self):
        m = _model()
        s0 = VehicleState(velocity=10.0, timestamp=0.0)
        u  = VehicleControlInput(steering_angle=0.0, acceleration=0.0)
        traj = m.simulate(s0, [u], dt=0.1)
        assert traj.length == 2

    def test_dt_validation_helper(self):
        from core.vehicle.dynamics_validator import DynamicsValidator
        try:
            DynamicsValidator.validate_dt(0.0)
            assert False
        except ValueError:
            pass
        try:
            DynamicsValidator.validate_dt(-1.0)
            assert False
        except ValueError:
            pass
        DynamicsValidator.validate_dt(0.1)  # should not raise

    def test_clamp_policy_never_raises_for_any_finite_input(self):
        """CLAMP policy must handle any finite steering without raising."""
        m = _model(policy=SteeringPolicy.CLAMP)
        s = VehicleState(velocity=10.0)
        for big_delta in [1e6, -1e6, math.pi, -math.pi, 0.0]:
            u = VehicleControlInput(steering_angle=big_delta)
            s1 = m.step(s, u, dt=0.1)
            assert s1.is_finite()
