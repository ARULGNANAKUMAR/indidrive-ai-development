"""
Phase 10.1 — Tests: State Propagation and Simulation API
"""
import math

from core.vehicle.vehicle_parameters import VehicleParameters
from core.vehicle.vehicle_state import VehicleState
from core.vehicle.vehicle_input import VehicleControlInput
from core.vehicle.bicycle_model import KinematicBicycleModel, VehicleTrajectory
from core.vehicle.dynamics_validator import DynamicsValidator


def _model():
    return KinematicBicycleModel(VehicleParameters.default())


def _state(v=10.0, yaw=0.0, x=0.0, y=0.0, ts=0.0):
    return VehicleState(x=x, y=y, yaw=yaw, velocity=v, timestamp=ts)


def _input(delta=0.0, a=0.0, ts=0.0):
    return VehicleControlInput(steering_angle=delta, acceleration=a, timestamp=ts)


class TestStatePropagationBasics:
    def test_step_returns_new_object(self):
        m = _model()
        s = _state()
        u = _input()
        s1 = m.step(s, u, dt=0.1)
        assert s1 is not s

    def test_step_does_not_mutate_state(self):
        m = _model()
        s = _state(v=10.0, x=5.0)
        x_before = s.x
        v_before = s.velocity
        m.step(s, _input(), dt=0.1)
        assert s.x == x_before
        assert s.velocity == v_before

    def test_timestamp_increments_by_dt(self):
        m = _model()
        s = _state(ts=1.0)
        s1 = m.step(s, _input(), dt=0.05)
        assert abs(s1.timestamp - 1.05) < 1e-9

    def test_frame_id_increments(self):
        m = _model()
        s = _state()
        s.frame_id = 5
        s1 = m.step(s, _input(), dt=0.1)
        assert s1.frame_id == 6

    def test_state_kind_is_simulated(self):
        from core.vehicle.vehicle_types import StateKind
        m = _model()
        s = _state()
        s1 = m.step(s, _input(), dt=0.1)
        assert s1.state_kind == StateKind.SIMULATED

    def test_coordinate_frame_preserved(self):
        from core.vehicle.vehicle_types import CoordinateFrame
        m = _model()
        s = _state()
        assert s.coordinate_frame == CoordinateFrame.VEHICLE
        s1 = m.step(s, _input(), dt=0.1)
        assert s1.coordinate_frame == CoordinateFrame.VEHICLE


class TestSimulationAPI:
    """Section 54 — short control-sequence simulation test."""

    def test_empty_sequence_returns_initial(self):
        m = _model()
        s0 = _state(v=10.0, ts=0.0)
        traj = m.simulate(s0, [], dt=0.1)
        assert traj.length == 1
        assert traj.states[0].x == s0.x

    def test_sequence_length(self):
        m = _model()
        s0 = _state(v=10.0)
        seq = [_input() for _ in range(10)]
        traj = m.simulate(s0, seq, dt=0.1)
        assert traj.length == 11  # initial + 10

    def test_timestamps_monotone(self):
        m = _model()
        s0 = _state(v=10.0, ts=0.0)
        seq = [_input() for _ in range(20)]
        traj = m.simulate(s0, seq, dt=0.05)
        for i in range(1, traj.length):
            assert traj.states[i].timestamp > traj.states[i - 1].timestamp

    def test_velocity_increases_with_accel(self):
        m = _model()
        s0 = _state(v=10.0)
        seq = [_input(a=2.0) for _ in range(5)]
        traj = m.simulate(s0, seq, dt=0.1)
        assert traj.states[-1].velocity > traj.states[0].velocity

    def test_trajectory_is_valid(self):
        m = _model()
        s0 = _state(v=10.0)
        seq = [_input(delta=0.1, a=1.0)] * 5 + [_input()] * 5
        traj = m.simulate(s0, seq, dt=0.1)
        DynamicsValidator.validate_trajectory(traj)

    def test_complex_sequence(self):
        """Straight → accelerate → steer → continue (Section 54)."""
        m = _model()
        s0 = _state(v=5.0, ts=0.0)
        # Straight (coast)
        seq = [_input(delta=0.0, a=0.0)] * 5
        # Accelerate
        seq += [_input(delta=0.0, a=2.0)] * 5
        # Steer
        seq += [_input(delta=0.15, a=0.0)] * 5
        # Continue
        seq += [_input(delta=0.15, a=0.0)] * 5

        traj = m.simulate(s0, seq, dt=0.1)

        assert traj.length == 21
        # Velocity increased after acceleration phase
        assert traj.states[10].velocity > traj.states[5].velocity
        # Yaw changed after steering phase
        assert traj.states[15].yaw != traj.states[10].yaw
        # All states finite
        for s in traj.states:
            assert s.is_finite()

    def test_trajectory_duration(self):
        m = _model()
        s0 = _state(ts=0.0)
        n_steps = 10
        dt = 0.05
        seq = [_input()] * n_steps
        traj = m.simulate(s0, seq, dt=dt)
        assert abs(traj.duration_s() - n_steps * dt) < 1e-9


class TestTrajectoryValidation:
    def test_validate_all_finite(self):
        m = _model()
        s0 = _state(v=10.0)
        traj = m.simulate(s0, [_input()] * 10, dt=0.1)
        DynamicsValidator.validate_trajectory(traj)

    def test_against_params_within_limits(self):
        m = _model()
        s0 = _state(v=5.0)
        seq = [_input(delta=0.1, a=1.0)] * 10
        traj = m.simulate(s0, seq, dt=0.1)
        DynamicsValidator.validate_trajectory_against_params(traj, m.params)

    def test_continuity_check_passes(self):
        m = _model()
        s0 = _state(v=10.0, ts=0.0)
        seq = [_input()] * 10
        traj = m.simulate(s0, seq, dt=0.1)
        DynamicsValidator.validate_state_sequence_continuity(traj.states, dt=0.1)

    def test_empty_trajectory_rejected(self):
        traj = VehicleTrajectory(states=[])
        try:
            DynamicsValidator.validate_trajectory(traj)
            assert False
        except ValueError:
            pass
