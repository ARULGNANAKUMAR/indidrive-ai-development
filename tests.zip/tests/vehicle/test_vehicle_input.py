"""
Phase 10.1 — Tests: VehicleControlInput
"""
import math

from core.vehicle.vehicle_input import VehicleControlInput


class TestVehicleControlInputConstruction:
    def test_default(self):
        u = VehicleControlInput()
        assert u.steering_angle == 0.0
        assert u.acceleration == 0.0
        assert u.timestamp == 0.0
        assert u.frame_id == 0

    def test_zero_factory(self):
        u = VehicleControlInput.zero(timestamp=1.5)
        assert u.steering_angle == 0.0
        assert u.acceleration == 0.0
        assert u.timestamp == 1.5

    def test_is_finite_on_default(self):
        assert VehicleControlInput().is_finite()


class TestVehicleControlInputValidation:
    def test_valid_passes(self):
        u = VehicleControlInput(steering_angle=0.2, acceleration=1.0, timestamp=0.5)
        u.validate()  # should not raise

    def test_nan_steering_rejected(self):
        u = VehicleControlInput(steering_angle=float("nan"))
        try:
            u.validate()
            assert False
        except ValueError:
            pass

    def test_inf_acceleration_rejected(self):
        u = VehicleControlInput(acceleration=float("inf"))
        try:
            u.validate()
            assert False
        except ValueError:
            pass

    def test_nan_timestamp_rejected(self):
        u = VehicleControlInput(timestamp=float("nan"))
        try:
            u.validate()
            assert False
        except ValueError:
            pass

    def test_negative_frame_id_rejected(self):
        u = VehicleControlInput(frame_id=-1)
        try:
            u.validate()
            assert False
        except ValueError:
            pass

    def test_repr_contains_units(self):
        u = VehicleControlInput(steering_angle=0.1, acceleration=2.0)
        r = repr(u)
        assert "m/s²" in r or "m/s" in r


class TestVehicleControlInputIsNotActuatorCommand:
    """
    Confirm VehicleControlInput has no actuator/CARLA fields.

    VehicleControlInput is a mathematical model input, NOT an actuator command.
    It must NOT contain:
        throttle, brake, hand_brake, gear, reverse, CARLA fields.
    """

    def test_no_throttle_field(self):
        u = VehicleControlInput()
        assert not hasattr(u, "throttle")

    def test_no_brake_field(self):
        u = VehicleControlInput()
        assert not hasattr(u, "brake")

    def test_no_carla_field(self):
        u = VehicleControlInput()
        for attr in ["apply_control", "carla_control", "gear", "hand_brake", "reverse"]:
            assert not hasattr(u, attr), f"Should not have field: {attr}"
