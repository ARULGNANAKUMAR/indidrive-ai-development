"""
Phase 10.1 — Tests: Determinism (Section 55)
Same inputs → same outputs, always.
"""
import math

from core.vehicle.vehicle_parameters import VehicleParameters
from core.vehicle.vehicle_state import VehicleState
from core.vehicle.vehicle_input import VehicleControlInput
from core.vehicle.bicycle_model import KinematicBicycleModel


def _model():
    return KinematicBicycleModel(VehicleParameters.default())


def _state(v=10.0, yaw=0.3, x=1.0, y=2.0, ts=0.0):
    return VehicleState(x=x, y=y, yaw=yaw, velocity=v, timestamp=ts)


def _run(model, s0, seq, dt):
    return model.simulate(s0, seq, dt=dt)


class TestDeterminism:
    def test_identical_step_output(self):
        m = _model()
        s = _state()
        u = VehicleControlInput(steering_angle=0.15, acceleration=1.0)
        s1a = m.step(s, u, dt=0.1)
        s1b = m.step(s, u, dt=0.1)
        assert s1a.x   == s1b.x
        assert s1a.y   == s1b.y
        assert s1a.yaw == s1b.yaw
        assert s1a.velocity == s1b.velocity

    def test_identical_trajectory(self):
        m = _model()
        s0 = _state()
        seq = [
            VehicleControlInput(steering_angle=0.1, acceleration=1.0),
            VehicleControlInput(steering_angle=0.2, acceleration=0.0),
            VehicleControlInput(steering_angle=-0.1, acceleration=-1.0),
        ]
        t1 = _run(m, s0, seq, 0.1)
        t2 = _run(m, s0, seq, 0.1)
        assert t1.length == t2.length
        for a, b in zip(t1.states, t2.states):
            assert a.x        == b.x
            assert a.y        == b.y
            assert a.yaw      == b.yaw
            assert a.velocity == b.velocity
            assert a.timestamp== b.timestamp

    def test_two_separate_model_instances(self):
        """Two fresh model instances with same params → same result."""
        m1 = KinematicBicycleModel(VehicleParameters.default())
        m2 = KinematicBicycleModel(VehicleParameters.default())
        s0 = _state()
        seq = [VehicleControlInput(steering_angle=0.2, acceleration=0.5)]
        t1 = m1.simulate(s0, seq, dt=0.05)
        t2 = m2.simulate(s0, seq, dt=0.05)
        for a, b in zip(t1.states, t2.states):
            assert a.x == b.x
            assert a.y == b.y
            assert a.yaw == b.yaw

    def test_curvature_deterministic(self):
        m = _model()
        delta = 0.25
        c1 = m.curvature(delta)
        c2 = m.curvature(delta)
        assert c1 == c2

    def test_derivative_deterministic(self):
        m = _model()
        s = _state()
        u = VehicleControlInput(steering_angle=0.1, acceleration=0.5)
        d1 = m.state_derivative(s, u)
        d2 = m.state_derivative(s, u)
        assert d1.x_dot   == d2.x_dot
        assert d1.y_dot   == d2.y_dot
        assert d1.yaw_dot == d2.yaw_dot
        assert d1.v_dot   == d2.v_dot
