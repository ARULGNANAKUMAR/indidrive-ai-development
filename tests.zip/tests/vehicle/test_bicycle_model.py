"""
Phase 10.1 — Tests: KinematicBicycleModel
Mathematical correctness and numerical safety.
"""
import math

from core.vehicle.vehicle_parameters import VehicleParameters
from core.vehicle.vehicle_state import VehicleState
from core.vehicle.vehicle_input import VehicleControlInput
from core.vehicle.bicycle_model import KinematicBicycleModel, StateDerivative
from core.vehicle.vehicle_types import SteeringPolicy, StateKind


def _model(policy=SteeringPolicy.CLAMP):
    return KinematicBicycleModel(VehicleParameters.default(), steering_policy=policy)


def _state(v=10.0, yaw=0.0, x=0.0, y=0.0, ts=0.0):
    return VehicleState(x=x, y=y, yaw=yaw, velocity=v, timestamp=ts)


def _input(delta=0.0, a=0.0, ts=0.0):
    return VehicleControlInput(steering_angle=delta, acceleration=a, timestamp=ts)


class TestStraightMotion:
    """Sections 44 — straight motion test."""

    def test_x_increases(self):
        m = _model()
        s = _state(v=10.0, yaw=0.0)
        u = _input(delta=0.0, a=0.0)
        s1 = m.step(s, u, dt=0.1)
        assert s1.x > s.x

    def test_y_constant(self):
        m = _model()
        s = _state(v=10.0, yaw=0.0)
        u = _input(delta=0.0, a=0.0)
        s1 = m.step(s, u, dt=0.1)
        assert abs(s1.y - s.y) < 1e-9

    def test_yaw_constant(self):
        m = _model()
        s = _state(v=10.0, yaw=0.0)
        u = _input(delta=0.0, a=0.0)
        s1 = m.step(s, u, dt=0.1)
        assert abs(s1.yaw - s.yaw) < 1e-9

    def test_velocity_constant(self):
        m = _model()
        s = _state(v=10.0, yaw=0.0)
        u = _input(delta=0.0, a=0.0)
        s1 = m.step(s, u, dt=0.1)
        assert abs(s1.velocity - s.velocity) < 1e-9

    def test_x_increment_correct(self):
        """x_next = x + v*cos(yaw)*dt"""
        m = _model()
        v, yaw, dt = 10.0, 0.0, 0.1
        s = _state(v=v, yaw=yaw)
        u = _input(delta=0.0, a=0.0)
        s1 = m.step(s, u, dt=dt)
        expected_x = v * math.cos(yaw) * dt
        assert abs(s1.x - expected_x) < 1e-9


class TestTurning:
    """Section 45 — turning test."""

    def test_positive_steering_yaw_increases(self):
        m = _model()
        s = _state(v=10.0)
        u = _input(delta=0.2)
        s1 = m.step(s, u, dt=0.1)
        # Positive steering → positive yaw rate → yaw increases
        assert s1.yaw > s.yaw

    def test_negative_steering_yaw_decreases(self):
        m = _model()
        s = _state(v=10.0)
        u = _input(delta=-0.2)
        s1 = m.step(s, u, dt=0.1)
        assert s1.yaw < s.yaw

    def test_yaw_rate_sign_positive(self):
        m = _model()
        s = _state(v=10.0)
        u = _input(delta=0.2)
        s1 = m.step(s, u, dt=0.1)
        assert s1.yaw_rate > 0

    def test_yaw_rate_sign_negative(self):
        m = _model()
        s = _state(v=10.0)
        u = _input(delta=-0.2)
        s1 = m.step(s, u, dt=0.1)
        assert s1.yaw_rate < 0

    def test_curvature_sign_positive(self):
        m = _model()
        assert m.curvature(0.2) > 0

    def test_curvature_sign_negative(self):
        m = _model()
        assert m.curvature(-0.2) < 0

    def test_curvature_zero(self):
        m = _model()
        assert m.curvature(0.0) == 0.0

    def test_curvature_formula(self):
        m = _model()
        delta = 0.3
        L = m.params.wheelbase_m
        expected = math.tan(delta) / L
        assert abs(m.curvature(delta) - expected) < 1e-9


class TestLeftRightSymmetry:
    """Section 46 — symmetry test."""

    def test_positive_negative_yaw_mirror(self):
        m = _model()
        s = _state(v=10.0)
        u_pos = _input(delta=0.2)
        u_neg = _input(delta=-0.2)
        s_pos = m.step(s, u_pos, dt=0.1)
        s_neg = m.step(s, u_neg, dt=0.1)
        # Lateral: mirror
        assert abs(s_pos.y + s_neg.y) < 1e-9
        # Yaw: mirror
        assert abs(s_pos.yaw + s_neg.yaw) < 1e-9
        # Speed: equal
        assert abs(s_pos.velocity - s_neg.velocity) < 1e-9

    def test_curvature_symmetry(self):
        m = _model()
        assert abs(m.curvature(0.2) + m.curvature(-0.2)) < 1e-9

    def test_yaw_rate_symmetry(self):
        m = _model()
        yr_pos = m.yaw_rate(10.0, 0.2)
        yr_neg = m.yaw_rate(10.0, -0.2)
        assert abs(yr_pos + yr_neg) < 1e-9


class TestAcceleration:
    """Section 47 — acceleration test."""

    def test_positive_accel_increases_velocity(self):
        m = _model()
        s = _state(v=10.0)
        u = _input(a=2.0)
        s1 = m.step(s, u, dt=0.1)
        assert s1.velocity > s.velocity

    def test_negative_accel_decreases_velocity(self):
        m = _model()
        s = _state(v=10.0)
        u = _input(a=-2.0)
        s1 = m.step(s, u, dt=0.1)
        assert s1.velocity < s.velocity

    def test_velocity_increment_correct(self):
        m = _model()
        v0, a, dt = 10.0, 2.0, 0.1
        s = _state(v=v0)
        u = _input(a=a)
        s1 = m.step(s, u, dt=dt)
        expected = v0 + a * dt
        assert abs(s1.velocity - expected) < 1e-9

    def test_velocity_not_negative_on_hard_brake(self):
        m = _model()
        s = _state(v=1.0)
        u = _input(a=-100.0)  # extreme deceleration
        s1 = m.step(s, u, dt=1.0)
        assert s1.velocity >= 0.0


class TestZeroVelocity:
    """Section 48 — zero velocity test."""

    def test_no_translation_at_zero_v(self):
        m = _model()
        s = _state(v=0.0)
        u = _input(delta=0.2, a=0.0)
        s1 = m.step(s, u, dt=0.1)
        assert abs(s1.x) < 1e-12
        assert abs(s1.y) < 1e-12

    def test_no_yaw_change_at_zero_v(self):
        m = _model()
        s = _state(v=0.0, yaw=0.5)
        u = _input(delta=0.3, a=0.0)
        s1 = m.step(s, u, dt=0.1)
        assert abs(s1.yaw - s.yaw) < 1e-12

    def test_yaw_rate_zero_at_zero_v(self):
        m = _model()
        s = _state(v=0.0)
        u = _input(delta=0.2, a=0.0)
        s1 = m.step(s, u, dt=0.1)
        # yaw_rate uses post-step velocity; after dt=0.1 with a=0 → v still 0
        assert abs(s1.yaw_rate) < 1e-12

    def test_is_finite_at_zero_v(self):
        m = _model()
        s = _state(v=0.0)
        u = _input(delta=0.5, a=0.0)
        s1 = m.step(s, u, dt=0.1)
        assert s1.is_finite()


class TestStateDerivative:
    """Section 24 — state derivative API."""

    def test_straight_motion_derivative(self):
        m = _model()
        v = 10.0
        s = _state(v=v, yaw=0.0)
        u = _input(delta=0.0, a=0.0)
        d = m.state_derivative(s, u)
        assert isinstance(d, StateDerivative)
        assert abs(d.x_dot - v) < 1e-9
        assert abs(d.y_dot) < 1e-9
        assert abs(d.yaw_dot) < 1e-9
        assert abs(d.v_dot) < 1e-9

    def test_derivative_with_steering(self):
        m = _model()
        v, delta = 10.0, 0.2
        L = m.params.wheelbase_m
        s = _state(v=v, yaw=0.0)
        u = _input(delta=delta, a=1.0)
        d = m.state_derivative(s, u)
        assert abs(d.yaw_dot - (v / L * math.tan(delta))) < 1e-9
        assert abs(d.v_dot - 1.0) < 1e-9

    def test_derivative_at_heading_90deg(self):
        m = _model()
        v = 5.0
        yaw = math.pi / 2  # pointing +Y
        s = _state(v=v, yaw=yaw)
        u = _input(delta=0.0, a=0.0)
        d = m.state_derivative(s, u)
        assert abs(d.x_dot) < 1e-9
        assert abs(d.y_dot - v) < 1e-9


class TestTimestep:
    """Section 51 — dt validation."""

    def test_positive_dt_ok(self):
        m = _model()
        s = _state(v=10.0)
        u = _input()
        m.step(s, u, dt=0.05)  # should not raise

    def test_zero_dt_rejected(self):
        m = _model()
        s = _state(v=10.0)
        u = _input()
        try:
            m.step(s, u, dt=0.0)
            assert False
        except ValueError:
            pass

    def test_negative_dt_rejected(self):
        m = _model()
        s = _state(v=10.0)
        u = _input()
        try:
            m.step(s, u, dt=-0.1)
            assert False
        except ValueError:
            pass

    def test_nan_dt_rejected(self):
        m = _model()
        s = _state(v=10.0)
        u = _input()
        try:
            m.step(s, u, dt=float("nan"))
            assert False
        except ValueError:
            pass

    def test_inf_dt_rejected(self):
        m = _model()
        s = _state(v=10.0)
        u = _input()
        try:
            m.step(s, u, dt=float("inf"))
            assert False
        except ValueError:
            pass


class TestSteeringLimits:
    """Section 49 — steering limit tests."""

    def test_exact_max_accepted(self):
        m = _model()
        lim = m.params.max_steering_angle_rad
        s = _state(v=10.0)
        u = _input(delta=lim)
        s1 = m.step(s, u, dt=0.1)
        assert abs(s1.steering_angle - lim) < 1e-9

    def test_beyond_max_clamped(self):
        m = _model(policy=SteeringPolicy.CLAMP)
        lim = m.params.max_steering_angle_rad
        s = _state(v=10.0)
        u = _input(delta=lim * 2)
        s1 = m.step(s, u, dt=0.1)
        assert abs(s1.steering_angle - lim) < 1e-9

    def test_beyond_min_clamped(self):
        m = _model(policy=SteeringPolicy.CLAMP)
        lim = m.params.max_steering_angle_rad
        s = _state(v=10.0)
        u = _input(delta=-lim * 2)
        s1 = m.step(s, u, dt=0.1)
        assert abs(s1.steering_angle - (-lim)) < 1e-9

    def test_reject_policy_raises(self):
        m = _model(policy=SteeringPolicy.REJECT)
        lim = m.params.max_steering_angle_rad
        s = _state(v=10.0)
        u = _input(delta=lim * 1.5)
        try:
            m.step(s, u, dt=0.1)
            assert False
        except ValueError:
            pass

    def test_within_limits_reject_passes(self):
        m = _model(policy=SteeringPolicy.REJECT)
        lim = m.params.max_steering_angle_rad
        s = _state(v=10.0)
        u = _input(delta=lim * 0.5)
        m.step(s, u, dt=0.1)  # should not raise


class TestAccelerationLimits:
    """Section 50 — acceleration limit tests."""

    def test_max_accel_applied(self):
        m = _model()
        p = m.params
        s = _state(v=10.0)
        u = _input(a=p.max_acceleration_mps2)
        s1 = m.step(s, u, dt=0.1)
        expected = p.clamp_velocity(10.0 + p.max_acceleration_mps2 * 0.1)
        assert abs(s1.velocity - expected) < 1e-9

    def test_beyond_max_accel_clamped(self):
        m = _model()
        p = m.params
        big_a = p.max_acceleration_mps2 * 10
        s = _state(v=10.0)
        u = _input(a=big_a)
        s1 = m.step(s, u, dt=0.1)
        expected_v = p.clamp_velocity(10.0 + p.max_acceleration_mps2 * 0.1)
        assert abs(s1.velocity - expected_v) < 1e-9

    def test_beyond_min_accel_clamped(self):
        m = _model()
        p = m.params
        s = _state(v=10.0)
        u = _input(a=p.min_acceleration_mps2 * 10)
        s1 = m.step(s, u, dt=0.1)
        assert s1.velocity >= 0.0


class TestAngleWrap:
    """Section 52 — yaw wrap-around test."""

    def test_yaw_wraps_at_pi(self):
        m = _model()
        # Start just below π; positive steering → yaw crosses π
        s = _state(v=10.0, yaw=math.pi * 0.99)
        u = _input(delta=0.3)
        s1 = m.step(s, u, dt=0.5)
        assert -math.pi <= s1.yaw < math.pi

    def test_yaw_wraps_at_negative_pi(self):
        m = _model()
        s = _state(v=10.0, yaw=-math.pi * 0.99)
        u = _input(delta=-0.3)
        s1 = m.step(s, u, dt=0.5)
        assert -math.pi <= s1.yaw < math.pi

    def test_yaw_stays_normalised_multiple_steps(self):
        m = _model()
        s = _state(v=5.0, yaw=0.0)
        u = _input(delta=0.5)
        for _ in range(50):
            s = m.step(s, u, dt=0.1)
            assert -math.pi <= s.yaw < math.pi, f"yaw={s.yaw} out of range"


class TestNumericalSafety:
    """Section 53 — numerical safety tests."""

    def test_nan_state_rejected(self):
        m = _model()
        s = VehicleState(x=float("nan"))
        u = _input()
        try:
            m.step(s, u, dt=0.1)
            assert False
        except ValueError:
            pass

    def test_inf_velocity_rejected(self):
        m = _model()
        s = VehicleState(velocity=float("inf"))
        try:
            s.validate()
            assert False
        except ValueError:
            pass

    def test_zero_wheelbase_rejected(self):
        try:
            VehicleParameters(
                wheelbase_m=0.0,
                front_axle_distance_m=0.0,
                rear_axle_distance_m=0.0,
                vehicle_length_m=4.50,
                vehicle_width_m=1.80,
                max_steering_angle_rad=0.61,
                max_steering_rate_rad_s=0.70,
                min_velocity_mps=0.0,
                max_velocity_mps=33.33,
                min_acceleration_mps2=-8.0,
                max_acceleration_mps2=4.0,
            )
            assert False
        except ValueError:
            pass

    def test_output_always_finite(self):
        m = _model()
        s = _state(v=10.0, yaw=1.0)
        u = _input(delta=0.3, a=1.0)
        s1 = m.step(s, u, dt=0.1)
        assert s1.is_finite()


class TestTurningRadius:
    def test_turning_radius_formula(self):
        m = _model()
        delta = 0.3
        L = m.params.wheelbase_m
        expected = L / math.tan(delta)
        assert abs(m.turning_radius(delta) - expected) < 1e-9

    def test_turning_radius_zero_steering(self):
        m = _model()
        r = m.turning_radius(0.0)
        assert math.isinf(r)

    def test_yaw_rate_formula(self):
        m = _model()
        v, delta = 10.0, 0.2
        L = m.params.wheelbase_m
        expected = v / L * math.tan(delta)
        assert abs(m.yaw_rate(v, delta) - expected) < 1e-9
