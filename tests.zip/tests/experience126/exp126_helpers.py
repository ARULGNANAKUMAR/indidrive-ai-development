"""
IndiDrive AI — Phase 12.6 | Test Helpers
=========================================
Shared fixtures for Phase 12.6 test suite.
"""
from __future__ import annotations

import time
from typing import List, Optional

from core.experience.decision_improvement import (
    DecisionImprovementEngine,
    ImprovementConfig,
    ImprovementMode,
)
from core.experience.knowledge import (
    AdaptiveKnowledgeConfig,
    KnowledgeContextKey,
    KnowledgeStore,
    KnowledgeUpdateEngine,
)

NOT_AVAILABLE = "NOT_AVAILABLE"


# ---------------------------------------------------------------------------
# Knowledge store helpers
# ---------------------------------------------------------------------------

def build_store_with_knowledge(
    road_type: str = "URBAN",
    situation_type: str = "PEDESTRIAN_CROSSING",
    outcomes: Optional[List[str]] = None,
    outcome_confidence: str = "HIGH",
) -> KnowledgeStore:
    """Create a KnowledgeStore pre-populated with knowledge from given outcomes."""
    if outcomes is None:
        outcomes = ["SUCCESS"] * 5

    k_cfg = AdaptiveKnowledgeConfig(
        enabled=True,
        minimum_evidence_count=1,
        minimum_confidence=0.01,
        minimum_consistency=0.0,
        maximum_entries=100,
        maximum_history_per_entry=5,
        maximum_evidence_per_entry=50,
    )
    store = KnowledgeStore(k_cfg)
    k_engine = KnowledgeUpdateEngine(k_cfg, store)

    key = KnowledgeContextKey(
        road_type=road_type,
        situation_type=situation_type,
        hazard_level="MEDIUM",
        traffic_density="MEDIUM",
    )
    records = [
        {
            "experience_id": f"test-R{i:06d}",
            "evaluation_id": f"test-R{i:06d}-EVAL",
            "session_id": "test",
            "outcome_class": oc,
            "evaluation_confidence": outcome_confidence,
            "experience_timestamp": 1_700_000_000.0 + i * 60,
        }
        for i, oc in enumerate(outcomes)
    ]
    k_engine.process_experiences(key, records)
    return store


def empty_store() -> KnowledgeStore:
    """Return an empty knowledge store."""
    cfg = AdaptiveKnowledgeConfig()
    return KnowledgeStore(cfg)


# ---------------------------------------------------------------------------
# Engine factories
# ---------------------------------------------------------------------------

def make_observation_engine(store=None) -> DecisionImprovementEngine:
    cfg = ImprovementConfig.observation_only()
    return DecisionImprovementEngine(cfg, store or empty_store())


def make_bounded_engine(store=None, max_influence: float = 0.10) -> DecisionImprovementEngine:
    cfg = ImprovementConfig.bounded_active(maximum_influence=max_influence)
    return DecisionImprovementEngine(cfg, store or empty_store())


def make_disabled_engine(store=None) -> DecisionImprovementEngine:
    cfg = ImprovementConfig(mode=ImprovementMode.DISABLED)
    return DecisionImprovementEngine(cfg, store or empty_store())


def make_advisory_engine(store=None) -> DecisionImprovementEngine:
    cfg = ImprovementConfig.advisory()
    return DecisionImprovementEngine(cfg, store or empty_store())


# ---------------------------------------------------------------------------
# Standard improvement call
# ---------------------------------------------------------------------------

def run_improve(
    engine: DecisionImprovementEngine,
    situation: str = "PEDESTRIAN_CROSSING",
    gate: str = "CAUTION",
    baseline: str = "NORMAL_PROGRESS",
    score: float = 0.70,
    road_type: str = "URBAN",
):
    return engine.improve(
        session_id="test-session",
        current_situation=situation,
        safety_gate_state=gate,
        baseline_decision=baseline,
        baseline_score=score,
        context_key_dict={
            "road_type": road_type,
            "situation_type": situation,
        },
    )
