"""
IndiDrive AI — Phase 12.6 | Eligibility, Scoring, Safety & Negative Scope Tests
================================================================================
Tests: knowledge eligibility, conflicting knowledge, stale knowledge,
       safety veto, score bounds, Indian road context, rollback,
       no direct actuator access, no policy mutation, no RL,
       Phase 12.7 not implemented.
"""
from __future__ import annotations

import inspect
import sys

from core.experience.decision_improvement import (
    DecisionImprovementEngine,
    ImprovementConfig,
    ImprovementMode,
    ImprovementOutcome,
    FallbackReason,
    KnowledgeEligibility,
    SafetyVetoResult,
    DecisionImprovementResult,
    assess_eligibility,
    filter_knowledge,
    score_candidate,
    score_baseline,
    veto_check,
)
from core.experience.knowledge import (
    AdaptiveKnowledgeConfig,
    KnowledgeConfidenceClass,
    KnowledgeContextKey,
    KnowledgeEntrySnapshot,
    KnowledgeStatus,
    KnowledgeStore,
    KnowledgeType,
    KnowledgeUpdateEngine,
)
from tests.experience126.exp126_helpers import (
    build_store_with_knowledge, empty_store,
    make_observation_engine, make_bounded_engine, make_disabled_engine,
    run_improve,
)


# ---------------------------------------------------------------------------
# Knowledge eligibility
# ---------------------------------------------------------------------------

def _make_snap(
    confidence: float = 0.70,
    status: KnowledgeStatus = KnowledgeStatus.ACTIVE,
    valid_count: int = 5,
    success_count: int = 4,
    degraded: bool = False,
    uncertainty: float = 0.1,
    kid: str = "K-TEST0001",
) -> KnowledgeEntrySnapshot:
    key = KnowledgeContextKey(road_type="URBAN", situation_type="PEDESTRIAN_CROSSING")
    return KnowledgeEntrySnapshot(
        knowledge_id=kid,
        schema_version="12.5",
        knowledge_type=KnowledgeType.CONTEXTUAL,
        context_key=key,
        observed_relationship="Test observational relationship.",
        evidence_count=valid_count,
        valid_evidence_count=valid_count,
        success_evidence_count=success_count,
        failure_evidence_count=max(0, valid_count - success_count),
        unsafe_evidence_count=0,
        weighted_score=float(success_count),
        confidence=confidence,
        confidence_class=KnowledgeConfidenceClass.HIGH,
        consistency=1.0,
        uncertainty=uncertainty,
        status=status,
        degraded=degraded,
        version=1,
        parent_version=None,
        supporting_experience_ids=tuple(f"exp-{i}" for i in range(valid_count)),
        supporting_evaluation_ids=tuple(f"eval-{i}" for i in range(valid_count)),
    )


class TestKnowledgeEligibility:
    def test_active_high_confidence_eligible(self):
        snap = _make_snap(confidence=0.70, status=KnowledgeStatus.ACTIVE, valid_count=5)
        cfg = ImprovementConfig()
        assert assess_eligibility(snap, cfg) == KnowledgeEligibility.ELIGIBLE

    def test_low_confidence_not_eligible(self):
        snap = _make_snap(confidence=0.20, status=KnowledgeStatus.ACTIVE, valid_count=5)
        cfg = ImprovementConfig(minimum_knowledge_confidence=0.50)
        assert assess_eligibility(snap, cfg) == KnowledgeEligibility.LOW_CONFIDENCE

    def test_insufficient_evidence_not_eligible(self):
        snap = _make_snap(confidence=0.80, status=KnowledgeStatus.ACTIVE, valid_count=1)
        cfg = ImprovementConfig(minimum_evidence_count=3)
        assert assess_eligibility(snap, cfg) == KnowledgeEligibility.INSUFFICIENT_EVIDENCE

    def test_stale_excluded_by_default(self):
        snap = _make_snap(status=KnowledgeStatus.STALE, valid_count=5)
        cfg = ImprovementConfig(stale_knowledge_policy="exclude")
        assert assess_eligibility(snap, cfg) == KnowledgeEligibility.STALE

    def test_stale_allowed_by_policy(self):
        snap = _make_snap(confidence=0.70, status=KnowledgeStatus.STALE, valid_count=5)
        cfg = ImprovementConfig(
            stale_knowledge_policy="allow",
            minimum_knowledge_confidence=0.30,
            minimum_evidence_count=3,
        )
        assert assess_eligibility(snap, cfg) == KnowledgeEligibility.ELIGIBLE

    def test_conflicting_excluded_by_default(self):
        snap = _make_snap(status=KnowledgeStatus.CONFLICTING, valid_count=5)
        cfg = ImprovementConfig(allow_conflicting_knowledge=False)
        assert assess_eligibility(snap, cfg) == KnowledgeEligibility.CONFLICTING

    def test_conflicting_allowed_by_config(self):
        snap = _make_snap(confidence=0.70, status=KnowledgeStatus.CONFLICTING, valid_count=5)
        cfg = ImprovementConfig(
            allow_conflicting_knowledge=True,
            minimum_knowledge_confidence=0.30,
            minimum_evidence_count=3,
        )
        assert assess_eligibility(snap, cfg) == KnowledgeEligibility.ELIGIBLE

    def test_deprecated_always_excluded(self):
        snap = _make_snap(confidence=0.99, status=KnowledgeStatus.DEPRECATED, valid_count=10)
        cfg = ImprovementConfig(minimum_knowledge_confidence=0.0, minimum_evidence_count=1)
        result = assess_eligibility(snap, cfg)
        assert result != KnowledgeEligibility.ELIGIBLE

    def test_rejected_always_excluded(self):
        snap = _make_snap(confidence=0.99, status=KnowledgeStatus.REJECTED, valid_count=10)
        cfg = ImprovementConfig(minimum_knowledge_confidence=0.0, minimum_evidence_count=1)
        result = assess_eligibility(snap, cfg)
        assert result != KnowledgeEligibility.ELIGIBLE

    def test_filter_partitions_correctly(self):
        snaps = [
            _make_snap(confidence=0.80, status=KnowledgeStatus.ACTIVE, valid_count=5, kid="K-A"),
            _make_snap(confidence=0.10, status=KnowledgeStatus.ACTIVE, valid_count=5, kid="K-B"),
            _make_snap(confidence=0.80, status=KnowledgeStatus.DEPRECATED, valid_count=5, kid="K-C"),
        ]
        cfg = ImprovementConfig(minimum_knowledge_confidence=0.50, minimum_evidence_count=3)
        eligible, ineligible = filter_knowledge(snaps, cfg)
        assert len(eligible) == 1
        assert eligible[0].knowledge_id == "K-A"
        assert len(ineligible) == 2


# ---------------------------------------------------------------------------
# Decision scoring
# ---------------------------------------------------------------------------

class TestScoring:
    def test_baseline_score_unchanged(self):
        cand = score_baseline("NORMAL_PROGRESS", 0.75)
        assert cand.baseline_score == 0.75
        assert cand.experience_adjustment == 0.0
        assert cand.final_score == 0.75
        assert cand.is_baseline

    def test_no_knowledge_returns_baseline(self):
        cand = score_candidate("NORMAL_PROGRESS", 0.75, [], ImprovementConfig())
        assert cand.experience_adjustment == 0.0
        assert cand.final_score == 0.75

    def test_positive_knowledge_positive_adjustment(self):
        snap = _make_snap(confidence=0.80, valid_count=5, success_count=5)
        cfg = ImprovementConfig(maximum_influence=0.10)
        cand = score_candidate("NORMAL_PROGRESS", 0.70, [snap], cfg)
        assert cand.experience_adjustment > 0.0

    def test_negative_knowledge_reduces_support(self):
        snap = _make_snap(confidence=0.80, valid_count=5, success_count=0)
        snap.failure_evidence_count = 5
        snap.unsafe_evidence_count = 0
        cfg = ImprovementConfig(maximum_influence=0.10)
        cand = score_candidate("NORMAL_PROGRESS", 0.70, [snap], cfg)
        # Negative evidence should not produce positive adjustment
        assert cand.experience_adjustment <= 0.0

    def test_adjustment_bounded_by_max_influence(self):
        snap = _make_snap(confidence=0.99, valid_count=20, success_count=20)
        for max_inf in [0.05, 0.10, 0.20]:
            cfg = ImprovementConfig(maximum_influence=max_inf)
            cand = score_candidate("NORMAL_PROGRESS", 0.70, [snap], cfg)
            assert abs(cand.experience_adjustment) <= max_inf + 1e-9

    def test_final_score_in_range(self):
        snap = _make_snap(confidence=0.99, valid_count=20, success_count=20)
        cfg = ImprovementConfig(maximum_influence=0.10)
        cand = score_candidate("NORMAL_PROGRESS", 0.95, [snap], cfg)
        assert 0.0 <= cand.final_score <= 1.0

    def test_deterministic_scoring(self):
        snap = _make_snap(confidence=0.75, valid_count=5, success_count=4)
        cfg = ImprovementConfig(maximum_influence=0.10)
        c1 = score_candidate("NORMAL_PROGRESS", 0.70, [snap], cfg)
        c2 = score_candidate("NORMAL_PROGRESS", 0.70, [snap], cfg)
        assert c1.final_score == c2.final_score
        assert c1.experience_adjustment == c2.experience_adjustment


# ---------------------------------------------------------------------------
# Safety veto
# ---------------------------------------------------------------------------

class TestSafetyVeto:
    def _make_candidates(self, ctype: str = "NORMAL_PROGRESS"):
        bl = score_baseline(ctype, 0.70)
        imp = score_baseline(ctype, 0.78)  # slightly improved
        imp.is_baseline = False
        imp.is_experience_improved = True
        imp.baseline_score = 0.70
        imp.final_score = 0.78
        return bl, imp

    def test_clear_gate_approves(self):
        bl, imp = self._make_candidates()
        veto, reason, selected = veto_check("CLEAR", bl, imp)
        assert veto == SafetyVetoResult.APPROVED

    def test_critical_gate_vetoes_non_conservative(self):
        bl, imp = self._make_candidates("NORMAL_PROGRESS")
        veto, reason, selected = veto_check("CRITICAL", bl, imp)
        assert veto == SafetyVetoResult.VETOED
        assert selected is bl

    def test_critical_gate_allows_collision_avoidance(self):
        bl = score_baseline("COLLISION_AVOIDANCE_REQUIRED", 0.90)
        imp = score_baseline("COLLISION_AVOIDANCE_REQUIRED", 0.92)
        imp.is_baseline = False
        veto, reason, selected = veto_check("CRITICAL", bl, imp)
        assert veto == SafetyVetoResult.APPROVED

    def test_high_alert_vetoes_non_conservative(self):
        bl, imp = self._make_candidates("MAINTAIN_SAFE_SPACE")
        veto, reason, selected = veto_check("HIGH_ALERT", bl, imp)
        assert veto == SafetyVetoResult.VETOED

    def test_unknown_gate_vetoes_non_conservative(self):
        bl, imp = self._make_candidates("NORMAL_PROGRESS")
        veto, reason, selected = veto_check("UNKNOWN", bl, imp)
        assert veto == SafetyVetoResult.VETOED

    def test_veto_always_returns_baseline(self):
        bl, imp = self._make_candidates("NORMAL_PROGRESS")
        _, _, selected = veto_check("CRITICAL", bl, imp)
        assert selected.final_score == bl.final_score

    def test_safety_veto_in_pipeline(self):
        store = build_store_with_knowledge(outcomes=["SUCCESS"] * 8)
        engine = make_bounded_engine(store=store, max_influence=0.10)
        result = engine.improve(
            session_id="s", current_situation="SOMETHING",
            safety_gate_state="CRITICAL",
            baseline_decision="NORMAL_PROGRESS",
            baseline_score=0.70,
            context_key_dict={"road_type": "URBAN", "situation_type": "PEDESTRIAN_CROSSING"},
        )
        # Safety veto must have been applied
        assert result.safety_veto in (SafetyVetoResult.VETOED, SafetyVetoResult.BYPASSED,
                                       SafetyVetoResult.UNKNOWN)
        assert result.final_decision == "NORMAL_PROGRESS"

    def test_safety_always_wins_over_history(self):
        """Historical success must not override current safety gate."""
        store = build_store_with_knowledge(outcomes=["SUCCESS"] * 20)
        engine = make_bounded_engine(store=store)
        result = engine.improve(
            session_id="s", current_situation="EMERGENCY",
            safety_gate_state="CRITICAL",
            baseline_decision="COLLISION_AVOIDANCE_REQUIRED",
            baseline_score=0.95,
            context_key_dict={"road_type": "URBAN", "situation_type": "PEDESTRIAN_CROSSING"},
        )
        # Final decision must remain safety-conservative
        assert result.final_decision in (
            "COLLISION_AVOIDANCE_REQUIRED", "NORMAL_PROGRESS",
        )
        assert result.final_score >= 0.0


# ---------------------------------------------------------------------------
# Indian road context
# ---------------------------------------------------------------------------

class TestIndianRoadContext:
    def test_pedestrian_crossing_risk_amplified(self):
        from core.experience.decision_improvement.experience_scorer import INDIAN_RISK_FACTOR, _is_indian_high_risk
        snap = _make_snap(confidence=0.70, valid_count=5, success_count=2)
        snap.context_key = KnowledgeContextKey(
            situation_type="PEDESTRIAN_CROSSING",
            road_type="URBAN",
        )
        assert _is_indian_high_risk(snap)

    def test_cattle_crossing_is_high_risk(self):
        from core.experience.decision_improvement.experience_scorer import _is_indian_high_risk
        snap = _make_snap()
        snap.context_key = KnowledgeContextKey(situation_type="CATTLE_CROSSING")
        assert _is_indian_high_risk(snap)

    def test_narrow_road_is_high_risk(self):
        from core.experience.decision_improvement.experience_scorer import _is_indian_high_risk
        snap = _make_snap()
        snap.context_key = KnowledgeContextKey(situation_type="NARROW_ROAD")
        assert _is_indian_high_risk(snap)

    def test_highway_cruise_not_high_risk(self):
        from core.experience.decision_improvement.experience_scorer import _is_indian_high_risk
        snap = _make_snap()
        snap.context_key = KnowledgeContextKey(situation_type="CRUISE", road_type="HIGHWAY")
        assert not _is_indian_high_risk(snap)

    def test_indian_context_aware_amplifies_risk(self):
        snap = _make_snap(confidence=0.70, valid_count=5, success_count=1)
        snap.failure_evidence_count = 4
        snap.context_key = KnowledgeContextKey(situation_type="PEDESTRIAN_CROSSING")
        cfg_on = ImprovementConfig(maximum_influence=0.10, indian_road_context_aware=True)
        cfg_off = ImprovementConfig(maximum_influence=0.10, indian_road_context_aware=False)
        c_on = score_candidate("NORMAL_PROGRESS", 0.70, [snap], cfg_on)
        c_off = score_candidate("NORMAL_PROGRESS", 0.70, [snap], cfg_off)
        # Risk amplified → adjustment should be more negative with indian context on
        assert c_on.experience_adjustment <= c_off.experience_adjustment


# ---------------------------------------------------------------------------
# Conflicting and stale knowledge
# ---------------------------------------------------------------------------

class TestConflictingAndStaleKnowledge:
    def test_conflicting_knowledge_excluded_by_default(self):
        snap = _make_snap(status=KnowledgeStatus.CONFLICTING, confidence=0.70, valid_count=5)
        cfg = ImprovementConfig(allow_conflicting_knowledge=False,
                                minimum_knowledge_confidence=0.0)
        el, inel = filter_knowledge([snap], cfg)
        assert len(el) == 0
        assert len(inel) == 1
        assert inel[0][1] == KnowledgeEligibility.CONFLICTING

    def test_conflicting_knowledge_triggers_fallback_in_pipeline(self):
        store = build_store_with_knowledge(outcomes=["SUCCESS", "FAILURE", "UNSAFE_OUTCOME"] * 3)
        # Force CONFLICTING status manually
        entry = list(store._entries.values())[0] if store._entries else None
        if entry:
            entry.status = KnowledgeStatus.CONFLICTING
        engine = make_bounded_engine(store=store)
        result = run_improve(engine)
        # Either fallback or the conflicting entry is excluded
        assert result.final_decision == "NORMAL_PROGRESS"

    def test_stale_excluded_gives_fallback(self):
        store = build_store_with_knowledge(outcomes=["SUCCESS"] * 5)
        # Force STALE status
        for entry in store._entries.values():
            entry.status = KnowledgeStatus.STALE
        engine = make_bounded_engine(store=store)
        result = run_improve(engine)
        assert result.fallback_used


# ---------------------------------------------------------------------------
# Rollback
# ---------------------------------------------------------------------------

class TestRollback:
    def test_manual_rollback_changes_mode(self):
        cfg = ImprovementConfig.bounded_active()
        engine = DecisionImprovementEngine(cfg, empty_store())
        assert engine.config.mode == ImprovementMode.BOUNDED_ACTIVE
        engine.rollback_to_observation("test")
        assert engine.config.mode == ImprovementMode.OBSERVATION_ONLY

    def test_rollback_does_not_disable_safety(self):
        cfg = ImprovementConfig.bounded_active()
        engine = DecisionImprovementEngine(cfg, empty_store())
        engine.rollback_to_observation("test")
        assert engine.config.effective_safety_required()

    def test_rollback_preserves_fallback(self):
        cfg = ImprovementConfig.bounded_active()
        engine = DecisionImprovementEngine(cfg, empty_store())
        engine.rollback_to_observation("test")
        assert engine.config.effective_fallback()


# ---------------------------------------------------------------------------
# No direct actuator access
# ---------------------------------------------------------------------------

class TestNoDirectActuatorAccess:
    def test_result_has_no_steering_field(self):
        for f in DecisionImprovementResult.__dataclass_fields__:
            assert "steering" not in f.lower()
            assert "throttle" not in f.lower()
            assert "brake" not in f.lower()
            assert "actuator" not in f.lower()

    def test_engine_has_no_actuator_methods(self):
        engine = make_observation_engine()
        for method in dir(engine):
            assert "steering" not in method.lower()
            assert "throttle" not in method.lower()
            assert "brake" not in method.lower()

    def test_veto_check_has_no_control_output(self):
        """veto_check returns (SafetyVetoResult, str, DecisionCandidate) — no vehicle command."""
        bl = score_baseline("NORMAL_PROGRESS", 0.70)
        imp = score_baseline("NORMAL_PROGRESS", 0.75)
        result = veto_check("CLEAR", bl, imp)
        assert len(result) == 3
        veto_res, reason_str, candidate = result
        assert isinstance(reason_str, str)
        assert not hasattr(candidate, "steering_angle")
        assert not hasattr(candidate, "throttle_percent")

    def test_result_final_decision_is_abstract(self):
        engine = make_disabled_engine()
        result = run_improve(engine)
        # final_decision must be a RequirementType / ResponseFamily string, not a vehicle command
        assert result.final_decision in (
            "NORMAL_PROGRESS", "COLLISION_AVOIDANCE_REQUIRED",
            "HANDLE_VULNERABLE_USER", "HANDLE_ROAD_HAZARD",
            "MAINTAIN_SAFE_SPACE", "HANDLE_UNCERTAINTY", "DEGRADED_OPERATION",
            "HANDLE_INTERSECTION", "MONITOR_DYNAMIC_OBJECT",
            "SAFETY_CRITICAL", "NORMAL", "CAUTION", "DEGRADED",
            "HAZARD_HANDLING", "CONFLICT_HANDLING", "UNCERTAINTY_MANAGEMENT",
            "NOT_AVAILABLE",  # baseline passthrough
        ) or len(result.final_decision) > 0  # any string from existing vocabulary


# ---------------------------------------------------------------------------
# No policy mutation / no RL / phase boundary
# ---------------------------------------------------------------------------

class TestNegativeScope:
    def test_no_mpc_in_improvement_types(self):
        import ast
        import core.experience.decision_improvement.improvement_types as mod
        tree = ast.parse(inspect.getsource(mod))
        code = ast.unparse(tree)
        for token in ("MpcConfig", "mpc_config", "mpc_tuning"):
            assert token not in code

    def test_no_reward_in_engine(self):
        import ast
        import core.experience.decision_improvement.improvement_engine as mod
        tree = ast.parse(inspect.getsource(mod))
        code = ast.unparse(tree)
        for token in ("reward_function", "compute_reward", "rl_reward"):
            assert token not in code.lower()

    def test_no_safety_gate_write_in_engine(self):
        import ast
        import core.experience.decision_improvement.improvement_engine as mod
        tree = ast.parse(inspect.getsource(mod))
        code = ast.unparse(tree)
        for token in ("SafetyGate(", "bypass_safety", "disable_safety",
                      "set_collision_threshold"):
            assert token not in code

    def test_no_planner_import_in_engine(self):
        import ast
        import core.experience.decision_improvement.improvement_engine as mod
        tree = ast.parse(inspect.getsource(mod))
        import_names = [
            node.names[0].name if isinstance(node, ast.Import) else (node.module or "")
            for node in ast.walk(tree)
            if isinstance(node, (ast.Import, ast.ImportFrom))
        ]
        for name in import_names:
            assert "planner_engine" not in (name or "").lower()

    def test_schema_version_is_12_6(self):
        from core.experience.decision_improvement import IMPROVEMENT_SCHEMA_VERSION
        assert IMPROVEMENT_SCHEMA_VERSION == "12.6"

    def test_no_phase_12_7_module(self):
        for mod_name in sys.modules:
            assert "12_7" not in mod_name.lower()
            assert "phase127" not in mod_name.lower()

    def test_safety_veto_not_bypassable(self):
        """Even with explicit config, safety_required is always True."""
        cfg = ImprovementConfig(safety_required=False)
        assert cfg.effective_safety_required() is True

    def test_fallback_not_disableable(self):
        """Even with explicit config, fallback_to_baseline is always True."""
        cfg = ImprovementConfig(fallback_to_baseline=False)
        assert cfg.effective_fallback() is True

    def test_improvement_does_not_call_mpc(self):
        import ast
        import core.experience.decision_improvement.experience_scorer as mod
        tree = ast.parse(inspect.getsource(mod))
        code = ast.unparse(tree)
        assert "mpc_" not in code.lower()
        assert "tracking_" not in code.lower()
