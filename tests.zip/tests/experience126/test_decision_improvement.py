"""
IndiDrive AI — Phase 12.6 | Core Decision Improvement Tests
============================================================
Tests: baseline decision, knowledge available/unavailable, improved/unchanged/
       fallback decisions, modes, scoring, explanation, audit trail.
"""
from __future__ import annotations

from core.experience.decision_improvement import (
    DecisionImprovementEngine,
    ImprovementConfig,
    ImprovementMode,
    ImprovementOutcome,
    FallbackReason,
    SafetyVetoResult,
    DecisionImprovementResult,
)
from tests.experience126.exp126_helpers import (
    build_store_with_knowledge, empty_store,
    make_observation_engine, make_bounded_engine,
    make_disabled_engine, make_advisory_engine,
    run_improve,
)


# ---------------------------------------------------------------------------
# Baseline decision (no improvement)
# ---------------------------------------------------------------------------

class TestBaselineDecision:
    def test_disabled_mode_returns_baseline(self):
        engine = make_disabled_engine()
        result = run_improve(engine)
        assert result.final_decision == "NORMAL_PROGRESS"
        assert result.fallback_used

    def test_disabled_outcome(self):
        engine = make_disabled_engine()
        result = run_improve(engine)
        assert result.outcome == ImprovementOutcome.DISABLED

    def test_no_knowledge_returns_baseline(self):
        engine = make_bounded_engine(store=empty_store())
        result = run_improve(engine)
        assert result.final_decision == "NORMAL_PROGRESS"
        assert result.fallback_used

    def test_result_is_always_valid(self):
        engine = make_disabled_engine()
        result = run_improve(engine)
        assert isinstance(result, DecisionImprovementResult)
        assert result.final_decision != ""
        assert result.baseline_decision != ""

    def test_baseline_score_preserved_on_fallback(self):
        engine = make_bounded_engine(store=empty_store())
        result = run_improve(engine, score=0.82)
        assert result.final_score == result.baseline_score


# ---------------------------------------------------------------------------
# Knowledge available
# ---------------------------------------------------------------------------

class TestKnowledgeAvailable:
    def test_knowledge_loaded_into_context(self):
        store = build_store_with_knowledge(outcomes=["SUCCESS"] * 5)
        engine = make_bounded_engine(store=store)
        result = run_improve(engine)
        assert len(result.knowledge_ids) >= 1

    def test_experience_ids_populated(self):
        store = build_store_with_knowledge(outcomes=["SUCCESS"] * 5)
        engine = make_bounded_engine(store=store)
        result = run_improve(engine)
        assert len(result.experience_ids) >= 1

    def test_knowledge_confidence_positive(self):
        store = build_store_with_knowledge(outcomes=["SUCCESS"] * 5)
        engine = make_bounded_engine(store=store)
        result = run_improve(engine)
        assert result.knowledge_confidence > 0.0

    def test_positive_knowledge_improves_or_confirms(self):
        store = build_store_with_knowledge(outcomes=["SUCCESS"] * 8)
        engine = make_bounded_engine(store=store)
        result = run_improve(engine, gate="CLEAR")
        assert result.outcome in (ImprovementOutcome.IMPROVED, ImprovementOutcome.UNCHANGED)


# ---------------------------------------------------------------------------
# Knowledge unavailable
# ---------------------------------------------------------------------------

class TestKnowledgeUnavailable:
    def test_empty_store_gives_fallback(self):
        engine = make_bounded_engine(store=empty_store())
        result = run_improve(engine)
        assert result.fallback_used
        assert result.outcome == ImprovementOutcome.FALLBACK

    def test_no_store_gives_fallback(self):
        cfg = ImprovementConfig.bounded_active()
        engine = DecisionImprovementEngine(cfg, knowledge_store=None)
        result = run_improve(engine)
        assert result.fallback_used

    def test_fallback_reason_set(self):
        engine = make_bounded_engine(store=empty_store())
        result = run_improve(engine)
        assert result.fallback_reason != FallbackReason.NONE


# ---------------------------------------------------------------------------
# Improved decision
# ---------------------------------------------------------------------------

class TestImprovedDecision:
    def test_improvement_applied_in_bounded_active(self):
        store = build_store_with_knowledge(outcomes=["SUCCESS"] * 8,
                                          outcome_confidence="HIGH")
        cfg = ImprovementConfig(
            mode=ImprovementMode.BOUNDED_ACTIVE,
            minimum_knowledge_confidence=0.0,
            minimum_evidence_count=1,
            maximum_influence=0.10,
        )
        engine = DecisionImprovementEngine(cfg, store)
        result = run_improve(engine, gate="CLEAR", score=0.70)
        # With strong positive evidence, outcome is IMPROVED or UNCHANGED
        assert result.outcome in (ImprovementOutcome.IMPROVED, ImprovementOutcome.UNCHANGED)

    def test_improvement_bounded(self):
        store = build_store_with_knowledge(outcomes=["SUCCESS"] * 20)
        engine = make_bounded_engine(store=store, max_influence=0.08)
        result = run_improve(engine, gate="CLEAR")
        adj = abs(result.experience_adjustment)
        assert adj <= 0.08 + 1e-9

    def test_final_score_in_range(self):
        store = build_store_with_knowledge(outcomes=["SUCCESS"] * 5)
        engine = make_bounded_engine(store=store)
        result = run_improve(engine, gate="CLEAR")
        assert 0.0 <= result.final_score <= 1.0

    def test_improvement_explanation_populated(self):
        store = build_store_with_knowledge(outcomes=["SUCCESS"] * 5)
        engine = make_bounded_engine(store=store)
        result = run_improve(engine, gate="CLEAR")
        assert result.explanation != ""
        assert result.explanation is not None


# ---------------------------------------------------------------------------
# Unchanged decision
# ---------------------------------------------------------------------------

class TestUnchangedDecision:
    def test_unchanged_when_adjustment_zero(self):
        store = build_store_with_knowledge(
            outcomes=["INCONCLUSIVE"] * 5  # zero weight → zero adjustment
        )
        cfg = ImprovementConfig(
            mode=ImprovementMode.BOUNDED_ACTIVE,
            minimum_knowledge_confidence=0.0,
            minimum_evidence_count=1,
            maximum_influence=0.10,
        )
        engine = DecisionImprovementEngine(cfg, store)
        result = run_improve(engine, gate="CLEAR")
        # Zero adjustment → UNCHANGED or FALLBACK (inconclusive gives 0 confidence)
        assert result.outcome in (
            ImprovementOutcome.UNCHANGED, ImprovementOutcome.FALLBACK,
            ImprovementOutcome.OBSERVATION,
        )

    def test_baseline_preserved_on_unchanged(self):
        engine = make_observation_engine(store=empty_store())
        result = run_improve(engine, score=0.65)
        assert result.final_decision == "NORMAL_PROGRESS"


# ---------------------------------------------------------------------------
# Fallback decision
# ---------------------------------------------------------------------------

class TestFallbackDecision:
    def test_fallback_final_equals_baseline(self):
        engine = make_bounded_engine(store=empty_store())
        result = run_improve(engine)
        assert result.final_decision == result.baseline_decision

    def test_fallback_score_equals_baseline(self):
        engine = make_bounded_engine(store=empty_store())
        result = run_improve(engine, score=0.77)
        assert abs(result.final_score - 0.77) < 1e-6

    def test_fallback_used_true(self):
        engine = make_bounded_engine(store=empty_store())
        result = run_improve(engine)
        assert result.fallback_used

    def test_exception_gives_fallback(self):
        """If knowledge store raises, result is fallback."""
        class BadStore:
            def list_contexts(self, **kw): raise RuntimeError("store broken")
            def get(self, kid): raise RuntimeError("store broken")
        cfg = ImprovementConfig.bounded_active()
        engine = DecisionImprovementEngine(cfg, BadStore())
        result = run_improve(engine)
        assert result.fallback_used
        assert result.final_decision == "NORMAL_PROGRESS"


# ---------------------------------------------------------------------------
# Operation modes
# ---------------------------------------------------------------------------

class TestOperationModes:
    def test_disabled_mode_no_change(self):
        store = build_store_with_knowledge(outcomes=["SUCCESS"] * 8)
        engine = make_disabled_engine(store=store)
        result = run_improve(engine, gate="CLEAR")
        assert result.outcome == ImprovementOutcome.DISABLED
        assert result.final_decision == "NORMAL_PROGRESS"

    def test_observation_mode_no_change(self):
        store = build_store_with_knowledge(outcomes=["SUCCESS"] * 8)
        engine = make_observation_engine(store=store)
        result = run_improve(engine, gate="CLEAR")
        assert result.outcome == ImprovementOutcome.OBSERVATION
        assert result.final_decision == "NORMAL_PROGRESS"

    def test_advisory_mode_no_change(self):
        store = build_store_with_knowledge(outcomes=["SUCCESS"] * 8)
        engine = make_advisory_engine(store=store)
        result = run_improve(engine, gate="CLEAR")
        # Advisory computes but does not apply
        assert result.outcome == ImprovementOutcome.OBSERVATION
        assert result.final_decision == "NORMAL_PROGRESS"

    def test_bounded_active_can_improve(self):
        store = build_store_with_knowledge(outcomes=["SUCCESS"] * 8)
        cfg = ImprovementConfig(
            mode=ImprovementMode.BOUNDED_ACTIVE,
            minimum_knowledge_confidence=0.0,
            minimum_evidence_count=1,
            maximum_influence=0.10,
        )
        engine = DecisionImprovementEngine(cfg, store)
        result = run_improve(engine, gate="CLEAR")
        assert result.outcome in (
            ImprovementOutcome.IMPROVED, ImprovementOutcome.UNCHANGED,
        )


# ---------------------------------------------------------------------------
# Audit trail
# ---------------------------------------------------------------------------

class TestAuditTrail:
    def test_audit_record_created(self):
        engine = make_observation_engine()
        run_improve(engine)
        audit = engine.get_audit_log()
        assert len(audit) == 1

    def test_audit_record_has_decision_fields(self):
        engine = make_observation_engine()
        run_improve(engine)
        record = engine.get_audit_log()[0]
        assert record.baseline_decision == "NORMAL_PROGRESS"
        assert record.session_id == "test-session"

    def test_audit_log_grows(self):
        engine = make_observation_engine()
        run_improve(engine)
        run_improve(engine)
        assert len(engine.get_audit_log()) == 2

    def test_audit_record_mode(self):
        engine = make_observation_engine()
        run_improve(engine)
        record = engine.get_audit_log()[0]
        assert record.decision_mode == ImprovementMode.OBSERVATION_ONLY


# ---------------------------------------------------------------------------
# Monitor counters
# ---------------------------------------------------------------------------

class TestMonitor:
    def test_total_cycles_increments(self):
        engine = make_observation_engine()
        run_improve(engine)
        run_improve(engine)
        assert engine.monitor.total_cycles == 2

    def test_fallback_count_increments_on_empty(self):
        engine = make_bounded_engine(store=empty_store())
        run_improve(engine)
        assert engine.monitor.baseline_fallback_count >= 1

    def test_observation_count_in_observation_mode(self):
        engine = make_observation_engine()
        run_improve(engine)
        assert engine.monitor.observation_only_count == 1


# ---------------------------------------------------------------------------
# Explanation
# ---------------------------------------------------------------------------

class TestExplanation:
    def test_explanation_not_empty(self):
        engine = make_observation_engine()
        result = run_improve(engine)
        assert result.explanation and len(result.explanation) > 10

    def test_explanation_contains_baseline(self):
        engine = make_observation_engine()
        result = run_improve(engine)
        assert "NORMAL_PROGRESS" in result.explanation or \
               "Baseline" in result.explanation

    def test_explanation_contains_outcome(self):
        engine = make_disabled_engine()
        result = run_improve(engine)
        assert "DISABLED" in result.explanation or "disabled" in result.explanation.lower()
