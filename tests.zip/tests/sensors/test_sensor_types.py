"""UNIT TEST — SensorFrame validation (camera/LiDAR/radar), no CARLA needed."""
import sys
from pathlib import Path

import numpy as np
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))

from core.carla_integration.sensor_types import (
    CameraFrame, LiDARFrame, RadarFrame, RadarDetection, Timestamp,
    validate_camera_frame, validate_lidar_frame, validate_radar_frame,
)


def _ts():
    return Timestamp(sensor_time=1.0, reception_time=1.001)


def test_valid_camera_frame_passes():
    img = np.zeros((600, 800, 3), dtype=np.uint8)
    frame = CameraFrame(sensor_id="rgb_front", frame_id=1, timestamp=_ts(),
                         sequence_number=1, payload=None, width=800, height=600,
                         channels=3, image=img)
    ok, reason = validate_camera_frame(frame)
    assert ok, reason


def test_camera_frame_missing_image_fails():
    frame = CameraFrame(sensor_id="rgb_front", frame_id=1, timestamp=_ts(),
                         sequence_number=1, payload=None, width=800, height=600, image=None)
    ok, reason = validate_camera_frame(frame)
    assert not ok
    assert "image" in reason


def test_camera_frame_shape_mismatch_fails():
    img = np.zeros((10, 10, 3), dtype=np.uint8)
    frame = CameraFrame(sensor_id="rgb_front", frame_id=1, timestamp=_ts(),
                         sequence_number=1, payload=None, width=800, height=600, image=img)
    ok, reason = validate_camera_frame(frame)
    assert not ok


def test_valid_lidar_frame_passes():
    pts = np.random.rand(500, 4).astype(np.float32)
    frame = LiDARFrame(sensor_id="lidar_top", frame_id=1, timestamp=_ts(),
                        sequence_number=1, payload=None, point_count=500, points=pts)
    ok, reason = validate_lidar_frame(frame)
    assert ok, reason


def test_lidar_frame_nan_fails():
    pts = np.random.rand(10, 4).astype(np.float32)
    pts[0, 0] = np.nan
    frame = LiDARFrame(sensor_id="lidar_top", frame_id=1, timestamp=_ts(),
                        sequence_number=1, payload=None, point_count=10, points=pts)
    ok, reason = validate_lidar_frame(frame)
    assert not ok
    assert "NaN" in reason or "Inf" in reason


def test_lidar_frame_empty_fails():
    pts = np.zeros((0, 4), dtype=np.float32)
    frame = LiDARFrame(sensor_id="lidar_top", frame_id=1, timestamp=_ts(),
                        sequence_number=1, payload=None, point_count=0, points=pts)
    ok, reason = validate_lidar_frame(frame)
    assert not ok


def test_valid_radar_frame_passes():
    dets = [RadarDetection(depth=10.0, velocity=2.0, azimuth=0.1, altitude=0.0)]
    frame = RadarFrame(sensor_id="radar_front", frame_id=1, timestamp=_ts(),
                        sequence_number=1, payload=None, detection_count=1, detections=dets)
    ok, reason = validate_radar_frame(frame)
    assert ok, reason


def test_radar_frame_count_mismatch_fails():
    dets = [RadarDetection(depth=10.0, velocity=2.0, azimuth=0.1, altitude=0.0)]
    frame = RadarFrame(sensor_id="radar_front", frame_id=1, timestamp=_ts(),
                        sequence_number=1, payload=None, detection_count=5, detections=dets)
    ok, reason = validate_radar_frame(frame)
    assert not ok
