"""MOCK TEST — SensorManager wired to fake SensorInterface implementations
(no CARLA, no real sockets). Exercises registration, invalid-frame handling,
dropped-frame counting, and basic timestamp/frame association."""
import sys
import time
from pathlib import Path

import numpy as np
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))

from core.carla_integration.sensor_manager import SensorManager
from core.carla_integration.sensor_interface import SensorInterface
from core.carla_integration.sensor_types import (
    CameraFrame, LiDARFrame, SensorType, SensorAvailability, Timestamp, validate_camera_frame,
    validate_lidar_frame, FrameStatus,
)


class FakeCameraSensor(SensorInterface):
    sensor_type = SensorType.CAMERA

    def __init__(self, sensor_id="cam", n_frames=5, bad_frame_indices=()):
        self.sensor_id = sensor_id
        self._n = n_frames
        self._bad = set(bad_frame_indices)
        self._started = False

    def start(self, on_frame):
        self._started = True
        for i in range(self._n):
            if i in self._bad:
                img = None  # will fail validation
            else:
                img = np.zeros((4, 4, 3), dtype=np.uint8)
            frame = CameraFrame(sensor_id=self.sensor_id, frame_id=i,
                                 timestamp=Timestamp(sensor_time=i * 0.1),
                                 sequence_number=i, payload=None, width=4, height=4,
                                 channels=3, image=img)
            ok, reason = validate_camera_frame(frame)
            if not ok:
                frame.status = FrameStatus.INVALID
                frame.metadata["invalid_reason"] = reason
            on_frame(frame)

    def stop(self):
        self._started = False


class FakeLidarSensor(SensorInterface):
    sensor_type = SensorType.LIDAR

    def __init__(self, sensor_id="lidar", n_frames=5):
        self.sensor_id = sensor_id
        self._n = n_frames

    def start(self, on_frame):
        for i in range(self._n):
            pts = np.random.rand(20, 4).astype(np.float32)
            frame = LiDARFrame(sensor_id=self.sensor_id, frame_id=i,
                                timestamp=Timestamp(sensor_time=i * 0.1 + 0.002),
                                sequence_number=i, payload=None, point_count=20, points=pts)
            on_frame(frame)

    def stop(self):
        pass


class FakeNotConfiguredRadar(SensorInterface):
    sensor_type = SensorType.RADAR
    sensor_id = "radar_front"

    @property
    def availability(self):
        return SensorAvailability.NOT_CONFIGURED

    def start(self, on_frame):
        pass  # never called since not available

    def stop(self):
        pass


def test_register_and_start_camera():
    mgr = SensorManager(buffer_capacity=10)
    mgr.register(FakeCameraSensor(n_frames=5))
    ok = mgr.start("cam")
    assert ok
    assert mgr.latest("cam").frame_id == 4
    assert len(mgr.buffer("cam")) == 5


def test_invalid_frames_are_not_buffered_and_increment_errors():
    mgr = SensorManager(buffer_capacity=10)
    mgr.register(FakeCameraSensor(n_frames=5, bad_frame_indices={2}))
    mgr.start("cam")
    assert len(mgr.buffer("cam")) == 4  # frame 2 rejected
    status = mgr.status_report()
    assert status["cam"]["error_count"] == 1


def test_not_configured_sensor_never_starts():
    mgr = SensorManager()
    mgr.register(FakeNotConfiguredRadar())
    ok = mgr.start("radar_front")
    assert ok is False
    status = mgr.status_report()
    assert status["radar_front"]["status"] == "NOT_CONFIGURED"


def test_dropped_frame_counting_on_buffer_overflow():
    mgr = SensorManager(buffer_capacity=2, overflow_policy="DROP_OLDEST")
    mgr.register(FakeCameraSensor(n_frames=10))
    mgr.start("cam")
    buf_stats = mgr.buffer("cam").stats()
    assert buf_stats["size"] == 2
    assert buf_stats["dropped_count"] == 8
    status = mgr.status_report()
    assert status["cam"]["dropped_frames"] == 8


def test_basic_frame_association_camera_lidar():
    mgr = SensorManager(buffer_capacity=20)
    mgr.register(FakeCameraSensor(n_frames=5))
    mgr.register(FakeLidarSensor(n_frames=5))
    mgr.start("cam")
    mgr.start("lidar")

    related = mgr.closest_related_frames("cam", reference_sensor_time=0.3, other_sensor_ids=["lidar"])
    assert related["cam"].frame_id == 3
    # lidar frame 3 has sensor_time 0.302, closest to 0.3
    assert related["lidar"].frame_id == 3


def test_stop_all_marks_offline_and_closes_buffers():
    mgr = SensorManager()
    mgr.register(FakeCameraSensor(n_frames=3))
    mgr.start("cam")
    mgr.stop_all()
    status = mgr.status_report()
    assert status["cam"]["status"] == "OFFLINE"
    assert len(mgr.buffer("cam")) == 0
