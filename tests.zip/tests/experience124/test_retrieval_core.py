"""Tests for ExperienceIndex, ExperienceRetriever core, ranking and filtering."""
import sys, os, time
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))

from exp124_helpers import (
    make_retriever, make_query, make_record_with_features,
    make_eval_snapshot, populate_index,
)
from core.experience.evaluation.evaluation_types import (
    EvaluationConfidence, EvaluationStatus, OutcomeClass,
)
from core.experience.record.record_types import ActionType, RecordCompleteness
from core.experience.retrieval.experience_index import ExperienceIndex
from core.experience.retrieval.experience_retriever import ExperienceRetriever
from core.experience.retrieval.retrieval_types import (
    ExperienceRetrievalConfig, RetrievalPolicy, RetrievalStatus,
    ExperienceQuality,
)
from core.experience.evaluation.evaluation_types import OutcomeClass


class TestExperienceIndex:
    def test_add_and_get(self):
        idx = ExperienceIndex()
        rec = make_record_with_features(session_id="idx-s", seq=0)
        ev = make_eval_snapshot(rec.record_id)
        assert idx.add(rec, ev) is True
        entry = idx.get(rec.record_id)
        assert entry is not None
        assert entry.experience_id == rec.record_id

    def test_size_after_add(self):
        idx = ExperienceIndex()
        for i in range(3):
            rec = make_record_with_features(session_id="idx-s2", seq=i)
            ev = make_eval_snapshot(rec.record_id)
            idx.add(rec, ev)
        assert idx.size() == 3

    def test_fifo_eviction(self):
        idx = ExperienceIndex(max_size=3)
        ids = []
        for i in range(5):
            rec = make_record_with_features(session_id="fifo", seq=i)
            ev = make_eval_snapshot(rec.record_id)
            idx.add(rec, ev)
            ids.append(rec.record_id)
        assert idx.size() == 3
        # Oldest 2 evicted
        assert idx.get(ids[0]) is None
        assert idx.get(ids[1]) is None
        assert idx.get(ids[4]) is not None

    def test_update_existing(self):
        idx = ExperienceIndex()
        rec = make_record_with_features(session_id="upd", seq=0)
        ev1 = make_eval_snapshot(rec.record_id, outcome_class=OutcomeClass.SUCCESS)
        ev2 = make_eval_snapshot(rec.record_id, outcome_class=OutcomeClass.FAILURE)
        idx.add(rec, ev1)
        idx.add(rec, ev2)
        assert idx.size() == 1
        entry = idx.get(rec.record_id)
        assert entry.outcome_class == OutcomeClass.FAILURE.value

    def test_remove(self):
        idx = ExperienceIndex()
        rec = make_record_with_features(session_id="rem", seq=0)
        ev = make_eval_snapshot(rec.record_id)
        idx.add(rec, ev)
        assert idx.remove(rec.record_id) is True
        assert idx.get(rec.record_id) is None
        assert idx.size() == 0

    def test_none_evaluation_indexable(self):
        idx = ExperienceIndex()
        rec = make_record_with_features(session_id="nev", seq=0)
        assert idx.add(rec, None) is True

    def test_query_candidates_policy_filter(self):
        idx = ExperienceIndex()
        # Add SUCCESS
        rec_s = make_record_with_features(session_id="pol", seq=0)
        ev_s = make_eval_snapshot(rec_s.record_id, outcome_class=OutcomeClass.SUCCESS)
        idx.add(rec_s, ev_s)
        # Add FAILURE
        rec_f = make_record_with_features(session_id="pol", seq=1)
        ev_f = make_eval_snapshot(rec_f.record_id, outcome_class=OutcomeClass.FAILURE)
        idx.add(rec_f, ev_f)

        cfg_quality = ExperienceRetrievalConfig(
            retrieval_policy=RetrievalPolicy.QUALITY_ONLY,
            include_failures=True,
        )
        cands_quality = idx.query_candidates(cfg_quality, RetrievalPolicy.QUALITY_ONLY)
        classes = {c.outcome_class for c in cands_quality}
        # QUALITY_ONLY: SUCCESS and PARTIAL_SUCCESS only
        assert OutcomeClass.FAILURE.value not in classes
        assert OutcomeClass.SUCCESS.value in classes


class TestExperienceRetriever:
    def test_empty_store_gives_empty_status(self):
        r = make_retriever()
        q = make_query()
        result = r.retrieve(q)
        assert result.retrieval_status == RetrievalStatus.EMPTY
        assert result.returned_count == 0

    def test_single_experience_retrieved(self):
        r = make_retriever()
        rec = make_record_with_features(session_id="ret-s", seq=0,
                                        road_type="URBAN", hazard_level="HIGH")
        ev = make_eval_snapshot(rec.record_id, outcome_class=OutcomeClass.SUCCESS)
        r.index_experience(rec, ev)
        q = make_query(road_type="URBAN", hazard_level="HIGH")
        result = r.retrieve(q)
        assert result.retrieval_status == RetrievalStatus.SUCCESS
        assert result.returned_count == 1

    def test_multiple_experiences_top_k(self):
        r = make_retriever()
        populate_index(r, n=8, session_id="topk")
        q = make_query(max_results=3)
        result = r.retrieve(q)
        assert result.returned_count <= 3

    def test_high_relevance_before_low(self):
        r = make_retriever()
        # Exact match
        rec_high = make_record_with_features(
            session_id="rank", seq=0, road_type="URBAN",
            hazard_level="HIGH", cattle=True, action_type=ActionType.STOP,
        )
        ev_h = make_eval_snapshot(rec_high.record_id, outcome_class=OutcomeClass.SUCCESS)
        r.index_experience(rec_high, ev_h)
        # Mismatch on most features
        rec_low = make_record_with_features(
            session_id="rank", seq=1, road_type="HIGHWAY",
            hazard_level="NONE", cattle=False, action_type=ActionType.FOLLOW_REFERENCE,
        )
        ev_l = make_eval_snapshot(rec_low.record_id, outcome_class=OutcomeClass.SUCCESS)
        r.index_experience(rec_low, ev_l)

        q = make_query(road_type="URBAN", hazard_level="HIGH", cattle=True,
                       action_type="STOP", max_results=2)
        result = r.retrieve(q)
        assert result.returned_count == 2
        exps = result.retrieved_experiences
        assert exps[0].relevance_score >= exps[1].relevance_score

    def test_result_id_format(self):
        r = make_retriever()
        q = make_query(session_id="fmt-sess")
        result = r.retrieve(q)
        assert result.result_id == f"{q.query_id}-RES"

    def test_retrieval_disabled(self):
        cfg = ExperienceRetrievalConfig(enabled=False)
        idx = ExperienceIndex()
        r = ExperienceRetriever(idx, cfg)
        populate_index(r, n=3)
        q = make_query()
        result = r.retrieve(q)
        assert result.retrieval_status == RetrievalStatus.DISABLED
        assert result.returned_count == 0

    def test_minimum_relevance_filters(self):
        r = make_retriever()
        # Add completely unmatched experience
        rec = make_record_with_features(
            session_id="minrel", seq=0, road_type="HIGHWAY",
            hazard_level="NONE", cattle=False,
        )
        ev = make_eval_snapshot(rec.record_id, outcome_class=OutcomeClass.SUCCESS)
        r.index_experience(rec, ev)
        # Query that won't match
        q = make_query(road_type="VILLAGE_ROAD", hazard_level="CRITICAL",
                       cattle=True, min_relevance=0.9)
        result = r.retrieve(q)
        assert result.returned_count == 0

    def test_outcome_class_preserved(self):
        r = make_retriever()
        rec = make_record_with_features(session_id="oc", seq=0)
        ev = make_eval_snapshot(rec.record_id, outcome_class=OutcomeClass.FAILURE)
        r.index_experience(rec, ev)
        q = make_query(policy=RetrievalPolicy.ALL_EVALUATED)
        result = r.retrieve(q)
        if result.returned_count > 0:
            exp = result.retrieved_experiences[0]
            assert exp.outcome_class == OutcomeClass.FAILURE.value

    def test_schema_version_in_result(self):
        r = make_retriever()
        q = make_query()
        result = r.retrieve(q)
        assert result.schema_version == "12.4"

    def test_failure_isolated_from_pipeline(self):
        """Retrieval failure must not raise — returns error result."""
        r = make_retriever()
        result = r.retrieve(None)  # type: ignore
        assert result is not None
        assert result.retrieval_status in (
            RetrievalStatus.ERROR, RetrievalStatus.EMPTY
        )


class TestDeterministicRetrieval:
    def test_same_query_same_ordering(self):
        r = make_retriever()
        populate_index(r, n=5, session_id="det")
        q = make_query(session_id="det-q")
        q.timestamp = 1000.0  # pin timestamp for determinism
        r1 = r.retrieve(q)
        r2 = r.retrieve(q)
        ids1 = [e.experience_id for e in r1.retrieved_experiences]
        ids2 = [e.experience_id for e in r2.retrieved_experiences]
        assert ids1 == ids2

    def test_same_query_same_scores(self):
        r = make_retriever()
        populate_index(r, n=5, session_id="det2")
        q = make_query(session_id="det2-q")
        q.timestamp = 2000.0
        r1 = r.retrieve(q)
        r2 = r.retrieve(q)
        scores1 = [e.relevance_score for e in r1.retrieved_experiences]
        scores2 = [e.relevance_score for e in r2.retrieved_experiences]
        assert scores1 == scores2


class TestReuseContext:
    def test_reuse_context_outcome_counts(self):
        r = make_retriever()
        for i, oc in enumerate([OutcomeClass.SUCCESS, OutcomeClass.FAILURE,
                                 OutcomeClass.UNSAFE_OUTCOME]):
            rec = make_record_with_features(session_id="ctx", seq=i)
            ev = make_eval_snapshot(rec.record_id, outcome_class=oc)
            r.index_experience(rec, ev)

        q = make_query(policy=RetrievalPolicy.ALL_EVALUATED, max_results=10)
        result = r.retrieve(q)
        ctx = r.build_reuse_context(q, result)

        assert ctx.retrieved_count == result.returned_count
        assert ctx.success_count + ctx.failure_count + ctx.unsafe_count <= ctx.retrieved_count

    def test_reuse_context_is_informational_only(self):
        r = make_retriever()
        q = make_query()
        result = r.retrieve(q)
        ctx = r.build_reuse_context(q, result)
        # Must have no vehicle command fields
        d = ctx.to_dict()
        for field in ("steering", "throttle", "brake", "trajectory", "path"):
            assert field not in d

    def test_build_query_from_record(self):
        r = make_retriever()
        rec = make_record_with_features(road_type="VILLAGE_ROAD")
        q = r.build_query_from_record(rec, "test-Q000000")
        assert q.query_id == "test-Q000000"
        assert q.road_context.road_type == "VILLAGE_ROAD"
