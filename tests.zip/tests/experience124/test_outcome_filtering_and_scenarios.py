"""
Tests for outcome class filtering, validator, safety authority,
failure isolation, and Indian road retrieval scenarios.
"""
import sys, os, time, inspect
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))

from exp124_helpers import (
    make_retriever, make_query, make_record_with_features,
    make_eval_snapshot, populate_index,
)
from core.experience.evaluation.evaluation_types import (
    EvaluationConfidence, OutcomeClass,
)
from core.experience.record.record_types import ActionType, RecordCompleteness
from core.experience.retrieval.retrieval_types import (
    ExperienceRetrievalConfig, RetrievalPolicy, RetrievalStatus,
    ExperienceQuality,
)
from core.experience.retrieval.retrieval_validator import RetrievalValidator
import core.experience.retrieval.experience_retriever as _retriever_mod
import core.experience.retrieval.relevance_scorer as _scorer_mod
import core.experience.retrieval.retrieval_types as _types_mod


# ---------------------------------------------------------------------------
# Outcome class filtering — all classes
# ---------------------------------------------------------------------------

class TestOutcomeClassFiltering:
    """Verify each outcome class is preserved and properly filtered."""

    def _index_one(self, r, oc, seq=0):
        rec = make_record_with_features(session_id=f"oc-{oc.value}", seq=seq)
        ev = make_eval_snapshot(rec.record_id, outcome_class=oc)
        r.index_experience(rec, ev)
        return rec.record_id

    def _query_all(self):
        return make_query(
            policy=RetrievalPolicy.ALL_EVALUATED,
            max_results=20,
        )

    def test_success_retrieved(self):
        r = make_retriever()
        self._index_one(r, OutcomeClass.SUCCESS)
        result = r.retrieve(self._query_all())
        classes = {e.outcome_class for e in result.retrieved_experiences}
        assert OutcomeClass.SUCCESS.value in classes

    def test_partial_success_retrieved_when_included(self):
        r = make_retriever()
        self._index_one(r, OutcomeClass.PARTIAL_SUCCESS)
        result = r.retrieve(self._query_all())
        classes = {e.outcome_class for e in result.retrieved_experiences}
        assert OutcomeClass.PARTIAL_SUCCESS.value in classes

    def test_failure_retrieved_when_included(self):
        r = make_retriever()
        self._index_one(r, OutcomeClass.FAILURE)
        result = r.retrieve(self._query_all())
        classes = {e.outcome_class for e in result.retrieved_experiences}
        assert OutcomeClass.FAILURE.value in classes

    def test_unsafe_outcome_retrieved_when_included(self):
        r = make_retriever()
        self._index_one(r, OutcomeClass.UNSAFE_OUTCOME)
        result = r.retrieve(self._query_all())
        classes = {e.outcome_class for e in result.retrieved_experiences}
        assert OutcomeClass.UNSAFE_OUTCOME.value in classes

    def test_degraded_retrieved_when_included(self):
        r = make_retriever()
        self._index_one(r, OutcomeClass.DEGRADED)
        result = r.retrieve(self._query_all())
        classes = {e.outcome_class for e in result.retrieved_experiences}
        assert OutcomeClass.DEGRADED.value in classes

    def test_inconclusive_retrieved_when_included(self):
        r = make_retriever()
        self._index_one(r, OutcomeClass.INCONCLUSIVE)
        result = r.retrieve(self._query_all())
        classes = {e.outcome_class for e in result.retrieved_experiences}
        assert OutcomeClass.INCONCLUSIVE.value in classes

    def test_failure_not_presented_as_success(self):
        """FAILURE must never appear as SUCCESS in retrieved result."""
        r = make_retriever()
        self._index_one(r, OutcomeClass.FAILURE)
        result = r.retrieve(self._query_all())
        for exp in result.retrieved_experiences:
            if exp.experience_id:
                assert exp.outcome_class != OutcomeClass.SUCCESS.value or \
                       exp.outcome_class == OutcomeClass.FAILURE.value  # preserved
        # More direct: check outcome_class is preserved
        for exp in result.retrieved_experiences:
            # If we stored a FAILURE, outcome_class must be FAILURE
            pass  # ordering doesn't change classification

    def test_outcome_classification_preserved_not_upgraded(self):
        """INCONCLUSIVE must not become SUCCESS during retrieval."""
        r = make_retriever()
        rid = self._index_one(r, OutcomeClass.INCONCLUSIVE)
        result = r.retrieve(self._query_all())
        for exp in result.retrieved_experiences:
            if exp.experience_id == rid:
                assert exp.outcome_class == OutcomeClass.INCONCLUSIVE.value

    def test_partial_excluded_when_flag_off(self):
        cfg = ExperienceRetrievalConfig(
            include_partial=False,
            retrieval_policy=RetrievalPolicy.CUSTOM,
        )
        from core.experience.retrieval.experience_index import ExperienceIndex
        from core.experience.retrieval.experience_retriever import ExperienceRetriever
        idx = ExperienceIndex()
        r = ExperienceRetriever(idx, cfg)
        rec = make_record_with_features(session_id="nopart", seq=0)
        ev = make_eval_snapshot(rec.record_id, outcome_class=OutcomeClass.PARTIAL_SUCCESS)
        r.index_experience(rec, ev)
        q = make_query(policy=RetrievalPolicy.CUSTOM)
        result = r.retrieve(q)
        for exp in result.retrieved_experiences:
            assert exp.outcome_class != OutcomeClass.PARTIAL_SUCCESS.value

    def test_invalid_not_indexed_as_valid(self):
        """INVALID records should not appear in quality-only retrieval."""
        r = make_retriever()
        rec = make_record_with_features(
            session_id="inv", seq=0,
            completeness=RecordCompleteness.INVALID,
        )
        ev = make_eval_snapshot(rec.record_id, outcome_class=OutcomeClass.INVALID)
        r.index_experience(rec, ev)
        q = make_query(policy=RetrievalPolicy.QUALITY_ONLY)
        result = r.retrieve(q)
        for exp in result.retrieved_experiences:
            assert exp.outcome_class != OutcomeClass.INVALID.value


# ---------------------------------------------------------------------------
# Retrieval validator
# ---------------------------------------------------------------------------

class TestRetrievalValidator:
    def setup_method(self):
        self.v = RetrievalValidator()
        self.r = make_retriever()

    def test_valid_query_passes(self):
        q = make_query()
        ok, reason = self.v.validate_query(q)
        assert ok, reason

    def test_none_query_fails(self):
        ok, _ = self.v.validate_query(None)
        assert not ok

    def test_missing_query_id_fails(self):
        q = make_query()
        q.query_id = "NOT_AVAILABLE"
        ok, _ = self.v.validate_query(q)
        assert not ok

    def test_valid_result_passes(self):
        populate_index(self.r, n=2)
        q = make_query()
        result = self.r.retrieve(q)
        ok, reason = self.v.validate_result(result)
        assert ok, reason

    def test_empty_result_valid(self):
        q = make_query()
        result = self.r.retrieve(q)
        ok, reason = self.v.validate_result(result)
        assert ok, reason

    def test_valid_reuse_context_passes(self):
        q = make_query()
        result = self.r.retrieve(q)
        ctx = self.r.build_reuse_context(q, result)
        ok, reason = self.v.validate_reuse_context(ctx)
        assert ok, reason

    def test_returned_count_mismatch_fails(self):
        q = make_query()
        result = self.r.retrieve(q)
        # Corrupt the count
        result.returned_count = 99
        ok, _ = self.v.validate_result(result)
        assert not ok


# ---------------------------------------------------------------------------
# Safety authority — retrieval must not override safety
# ---------------------------------------------------------------------------

class TestSafetyAuthority:
    def test_unsafe_outcome_preserved_not_downgraded(self):
        r = make_retriever()
        rec = make_record_with_features(session_id="safe", seq=0)
        ev = make_eval_snapshot(rec.record_id,
                                outcome_class=OutcomeClass.UNSAFE_OUTCOME)
        r.index_experience(rec, ev)
        q = make_query(policy=RetrievalPolicy.ALL_EVALUATED)
        result = r.retrieve(q)
        for exp in result.retrieved_experiences:
            if exp.experience_id == rec.record_id:
                assert exp.outcome_class == OutcomeClass.UNSAFE_OUTCOME.value

    def test_retriever_source_has_no_safety_override(self):
        src = inspect.getsource(_retriever_mod)
        forbidden = [
            "disable_safety",
            "bypass_safety",
            "safety_gate.override",
            "emergency_override",
            "set_steering",
            "set_throttle",
            "set_braking",
        ]
        for f in forbidden:
            assert f not in src, f"Forbidden safety override in retriever: {f!r}"

    def test_reuse_context_has_no_control_fields(self):
        r = make_retriever()
        q = make_query()
        result = r.retrieve(q)
        ctx = r.build_reuse_context(q, result)
        d = ctx.to_dict()
        control_fields = ("steering", "throttle", "braking", "trajectory",
                          "path_command", "emergency_command")
        for f in control_fields:
            assert f not in d


# ---------------------------------------------------------------------------
# Failure isolation
# ---------------------------------------------------------------------------

class TestFailureIsolation:
    def test_none_query_returns_error_not_exception(self):
        r = make_retriever()
        result = r.retrieve(None)  # type: ignore
        assert result is not None
        assert result.retrieval_status in (RetrievalStatus.ERROR, RetrievalStatus.EMPTY)

    def test_corrupted_record_does_not_crash(self):
        r = make_retriever()
        from core.experience.record.record_types import ExperienceRecord
        corrupt = ExperienceRecord()  # all defaults
        ev = make_eval_snapshot("bad-id", outcome_class=OutcomeClass.INVALID)
        # May succeed or fail — must not crash
        r.index_experience(corrupt, ev)

    def test_empty_store_after_all_filtered(self):
        """If all candidates fail quality filter, returns EMPTY gracefully."""
        cfg = ExperienceRetrievalConfig(
            minimum_quality=ExperienceQuality.HIGH,
            retrieval_policy=RetrievalPolicy.ALL_EVALUATED,
        )
        from core.experience.retrieval.experience_index import ExperienceIndex
        from core.experience.retrieval.experience_retriever import ExperienceRetriever
        idx = ExperienceIndex()
        r = ExperienceRetriever(idx, cfg)
        rec = make_record_with_features(session_id="qual", seq=0)
        ev = make_eval_snapshot(rec.record_id,
                                confidence=EvaluationConfidence.UNKNOWN)
        r.index_experience(rec, ev)
        q = make_query()
        result = r.retrieve(q)
        # Should be EMPTY or SUCCESS with 0 results — not a crash
        assert result is not None
        assert result.returned_count == 0

    def test_evaluation_failure_does_not_affect_driving(self):
        """Index failure does not crash; returns False not exception."""
        from core.experience.retrieval.experience_index import ExperienceIndex
        idx = ExperienceIndex()
        result = idx.add(None, None)  # type: ignore
        assert result is False  # error, but no exception


# ---------------------------------------------------------------------------
# Negative scope — Phase 12.4 must NOT do these things
# ---------------------------------------------------------------------------

class TestNegativeScope:
    def test_no_policy_update_in_retriever(self):
        src = inspect.getsource(_retriever_mod)
        for term in ("update_policy", "update_prototype", "train(",
                     "backward(", "gradient", "optimizer", "weight_update"):
            assert term not in src, f"Forbidden learning: {term!r}"

    def test_no_rl_in_retriever(self):
        src = inspect.getsource(_retriever_mod)
        for term in ("reward", "q_value", "advantage", "policy_gradient",
                     "replay_buffer"):
            assert term not in src, f"Forbidden RL: {term!r}"

    def test_no_llm_in_retriever(self):
        src = inspect.getsource(_retriever_mod)
        for mod in (_retriever_mod, _scorer_mod, _types_mod):
            s = inspect.getsource(mod)
            for term in ("openai", "anthropic.messages", "gpt-", "claude_api"):
                assert term not in s.lower(), (
                    f"External AI call in {mod.__name__}: {term!r}"
                )

    def test_no_external_db(self):
        src = inspect.getsource(_retriever_mod)
        for term in ("faiss", "pinecone", "milvus", "weaviate", "qdrant",
                     "chromadb", "vector_db"):
            assert term not in src.lower(), f"External DB: {term!r}"

    def test_no_http_requests(self):
        for mod in (_retriever_mod, _scorer_mod, _types_mod):
            s = inspect.getsource(mod)
            for term in ("requests.get", "urllib.request", "http.client",
                         "aiohttp", "httpx"):
                assert term not in s, f"HTTP in {mod.__name__}: {term!r}"

    def test_retrieval_produces_no_vehicle_commands(self):
        r = make_retriever()
        populate_index(r, n=3)
        q = make_query()
        result = r.retrieve(q)
        ctx = r.build_reuse_context(q, result)
        for exp in result.retrieved_experiences:
            assert not hasattr(exp, "steering_command")
            assert not hasattr(exp, "throttle_command")
            assert not hasattr(exp, "brake_command")
            assert not hasattr(exp, "trajectory")


# ---------------------------------------------------------------------------
# Indian road retrieval scenarios
# ---------------------------------------------------------------------------

class TestIndianRoadRetrieval:
    def _base_retriever(self):
        return make_retriever()

    def test_1_village_road_retrieval(self):
        r = self._base_retriever()
        rec = make_record_with_features(
            session_id="ind", seq=0,
            road_type="VILLAGE_ROAD", hazard_level="LOW",
            action_type=ActionType.FOLLOW_REFERENCE,
        )
        ev = make_eval_snapshot(rec.record_id, outcome_class=OutcomeClass.SUCCESS)
        r.index_experience(rec, ev)
        q = make_query(road_type="VILLAGE_ROAD", hazard_level="LOW", max_results=5,
                       policy=RetrievalPolicy.ALL_EVALUATED)
        result = r.retrieve(q)
        assert result.returned_count >= 1
        assert result.retrieved_experiences[0].outcome_class == OutcomeClass.SUCCESS.value

    def test_2_cattle_crossing_retrieved(self):
        r = self._base_retriever()
        rec = make_record_with_features(
            session_id="cattle", seq=0,
            road_type="VILLAGE_ROAD", hazard_level="HIGH",
            cattle=True, action_type=ActionType.STOP,
        )
        ev = make_eval_snapshot(rec.record_id, outcome_class=OutcomeClass.SUCCESS)
        r.index_experience(rec, ev)
        q = make_query(road_type="VILLAGE_ROAD", cattle=True, hazard_level="HIGH",
                       action_type="STOP", policy=RetrievalPolicy.ALL_EVALUATED)
        result = r.retrieve(q)
        assert result.returned_count >= 1
        exp = result.retrieved_experiences[0]
        assert exp.cattle_present is True

    def test_3_vru_crossing_retrieved(self):
        r = self._base_retriever()
        rec = make_record_with_features(
            session_id="vru", seq=0,
            road_type="URBAN", hazard_level="HIGH",
            vru=True, action_type=ActionType.SLOW_DOWN,
        )
        ev = make_eval_snapshot(rec.record_id, outcome_class=OutcomeClass.SUCCESS)
        r.index_experience(rec, ev)
        q = make_query(road_type="URBAN", vru=True, hazard_level="HIGH",
                       action_type="SLOW_DOWN", policy=RetrievalPolicy.ALL_EVALUATED)
        result = r.retrieve(q)
        assert result.returned_count >= 1
        exp = result.retrieved_experiences[0]
        assert exp.vru_present is True

    def test_4_unsafe_cattle_collision_preserved(self):
        r = self._base_retriever()
        rec = make_record_with_features(
            session_id="unsafe", seq=0, cattle=True, hazard_level="HIGH",
        )
        ev = make_eval_snapshot(rec.record_id,
                                outcome_class=OutcomeClass.UNSAFE_OUTCOME)
        r.index_experience(rec, ev)
        q = make_query(cattle=True, hazard_level="HIGH",
                       policy=RetrievalPolicy.ALL_EVALUATED)
        result = r.retrieve(q)
        for exp in result.retrieved_experiences:
            if exp.cattle_present:
                assert exp.outcome_class == OutcomeClass.UNSAFE_OUTCOME.value

    def test_5_mixed_traffic_urban_intersection(self):
        r = self._base_retriever()
        rec = make_record_with_features(
            session_id="urban", seq=0,
            road_type="URBAN", vru=True, traffic_density="HIGH",
            hazard_level="HIGH", action_type=ActionType.SLOW_DOWN,
        )
        ev = make_eval_snapshot(rec.record_id, outcome_class=OutcomeClass.SUCCESS)
        r.index_experience(rec, ev)
        q = make_query(road_type="URBAN", vru=True, traffic_density="HIGH",
                       hazard_level="HIGH", policy=RetrievalPolicy.ALL_EVALUATED)
        result = r.retrieve(q)
        assert result.returned_count >= 1

    def test_6_highway_merge_different_road_type(self):
        r = self._base_retriever()
        # Store a highway experience
        rec = make_record_with_features(
            session_id="hw", seq=0,
            road_type="HIGHWAY", hazard_level="MEDIUM",
            action_type=ActionType.ADAPT_PATH,
        )
        ev = make_eval_snapshot(rec.record_id, outcome_class=OutcomeClass.SUCCESS)
        r.index_experience(rec, ev)
        # Query for urban — highway experience has lower road score
        q_urban = make_query(road_type="URBAN", hazard_level="MEDIUM")
        q_hw = make_query(road_type="HIGHWAY", hazard_level="MEDIUM")
        r1 = r.retrieve(q_urban)
        r2 = r.retrieve(q_hw)
        # Highway query should score higher for the stored experience
        if r1.returned_count > 0 and r2.returned_count > 0:
            score_urban = r1.retrieved_experiences[0].relevance_score
            score_hw = r2.retrieved_experiences[0].relevance_score
            assert score_hw >= score_urban

    def test_7_partial_success_preserved(self):
        r = self._base_retriever()
        rec = make_record_with_features(
            session_id="partial", seq=0, hazard_level="HIGH",
        )
        ev = make_eval_snapshot(rec.record_id,
                                outcome_class=OutcomeClass.PARTIAL_SUCCESS)
        r.index_experience(rec, ev)
        q = make_query(policy=RetrievalPolicy.ALL_EVALUATED)
        result = r.retrieve(q)
        for exp in result.retrieved_experiences:
            if exp.outcome_class == OutcomeClass.PARTIAL_SUCCESS.value:
                assert exp.outcome_class != OutcomeClass.SUCCESS.value

    def test_8_failure_experience_available_for_context(self):
        r = self._base_retriever()
        rec = make_record_with_features(
            session_id="fail", seq=0, road_type="URBAN", hazard_level="HIGH",
        )
        ev = make_eval_snapshot(rec.record_id, outcome_class=OutcomeClass.FAILURE)
        r.index_experience(rec, ev)
        q = make_query(road_type="URBAN", hazard_level="HIGH",
                       policy=RetrievalPolicy.ALL_EVALUATED)
        result = r.retrieve(q)
        classes = {e.outcome_class for e in result.retrieved_experiences}
        assert OutcomeClass.FAILURE.value in classes

    def test_9_experience_has_match_reasons(self):
        r = self._base_retriever()
        rec = make_record_with_features(
            session_id="reasons", seq=0,
            road_type="URBAN", hazard_level="HIGH", cattle=True,
        )
        ev = make_eval_snapshot(rec.record_id, outcome_class=OutcomeClass.SUCCESS)
        r.index_experience(rec, ev)
        q = make_query(road_type="URBAN", hazard_level="HIGH", cattle=True)
        result = r.retrieve(q)
        if result.returned_count > 0:
            exp = result.retrieved_experiences[0]
            assert len(exp.match_reasons) > 0

    def test_10_explanation_includes_outcome(self):
        r = self._base_retriever()
        rec = make_record_with_features(session_id="exp", seq=0, hazard_level="HIGH")
        ev = make_eval_snapshot(rec.record_id, outcome_class=OutcomeClass.SUCCESS,
                                evidence=("NO_COLLISION_OBSERVED", "HAZARD_RESOLVED"))
        r.index_experience(rec, ev)
        q = make_query(hazard_level="HIGH", policy=RetrievalPolicy.ALL_EVALUATED)
        result = r.retrieve(q)
        if result.returned_count > 0:
            exp = result.retrieved_experiences[0]
            assert exp.outcome_class != "NOT_AVAILABLE"
            assert len(exp.outcome_evidence) > 0
