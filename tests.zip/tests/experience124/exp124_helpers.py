"""
IndiDrive AI — Phase 12.4 | Test Helpers
=========================================
Shared builders for Phase 12.4 retrieval tests.
"""
from __future__ import annotations
import sys, os, time

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "experience122"))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "experience123"))

from exp122_helpers import make_record_config, make_situation, make_action, make_outcome
from exp123_helpers import make_evaluator, make_full_record, make_cattle_crossing_record

from core.experience.record.record_types import (
    RECORD_SCHEMA_VERSION, NOT_AVAILABLE, ActionType, ExperienceRecord,
    OutcomeObservationState, RecordCompleteness, SituationRecord, ActionRecord,
)
from core.experience.record.record_engine import _make_record_id
from core.experience.evaluation.evaluation_types import (
    EvaluationConfidence, EvaluationStatus, OutcomeClass,
    OutcomeEvaluation, OutcomeEvaluationSnapshot, EVALUATION_SCHEMA_VERSION,
)
from core.experience.retrieval.retrieval_types import (
    RETRIEVAL_SCHEMA_VERSION,
    ExperienceQuality, ExperienceRetrievalConfig, ExperienceRetrievalQuery,
    HazardContext, PlanningContext, RetrievalPolicy, RoadContext,
    SafetyContext, TrafficContext, VehicleContext,
)
from core.experience.retrieval.experience_index import ExperienceIndex
from core.experience.retrieval.experience_retriever import ExperienceRetriever


# ---------------------------------------------------------------------------
# Evaluation snapshot builders
# ---------------------------------------------------------------------------

def make_eval_snapshot(
    record_id: str,
    session_id: str = "sess-001",
    outcome_class: OutcomeClass = OutcomeClass.SUCCESS,
    confidence: EvaluationConfidence = EvaluationConfidence.HIGH,
    evidence=("NO_COLLISION_OBSERVED", "HAZARD_RESOLVED"),
) -> OutcomeEvaluationSnapshot:
    ev_id = f"{record_id}-EVAL"
    return OutcomeEvaluationSnapshot(
        evaluation_id=ev_id,
        experience_id=record_id,
        session_id=session_id,
        schema_version=EVALUATION_SCHEMA_VERSION,
        evaluation_timestamp=time.time(),
        evaluation_status=EvaluationStatus.COMPLETE,
        outcome_class=outcome_class,
        confidence=confidence,
        evidence=tuple(evidence),
        reason_codes=tuple(evidence[:1]),
        uncertainty=0.1,
        is_degraded=False,
    )


# ---------------------------------------------------------------------------
# Record builders for retrieval
# ---------------------------------------------------------------------------

def make_record_with_features(
    session_id: str = "sess-r",
    seq: int = 0,
    road_type: str = "URBAN",
    hazard_level: str = "HIGH",
    cattle: bool = False,
    vru: bool = False,
    action_type: ActionType = ActionType.STOP,
    situation_type: str = "HAZARD_RESPONSE",
    traffic_density: str = "MEDIUM",
    completeness: RecordCompleteness = RecordCompleteness.COMPLETE,
    ego_speed: float = 3.0,
) -> ExperienceRecord:
    rid = _make_record_id(session_id, seq)
    ts = time.time()
    sit = make_situation(session_id, rid, seq, ts, hazard_level=hazard_level,
                         cattle=cattle)
    sit.road_type = road_type
    sit.traffic_density = traffic_density
    sit.vulnerable_road_user_present = vru
    sit.situation_type = situation_type
    sit.ego_speed_ms = ego_speed
    act = make_action(session_id, rid, seq, ts, action_type=action_type)
    out = make_outcome(session_id, rid, seq, ts,
                       obs_state=OutcomeObservationState.OBSERVED)
    out.collision_detected = False
    out.safety_state_after = "SAFE"
    out.cleared_event_types = ("HAZARD_DETECTED",)
    out.hazard_level_after = "NONE"
    return ExperienceRecord(
        record_id=rid, session_id=session_id, sequence_id=seq,
        schema_version=RECORD_SCHEMA_VERSION, created_timestamp=ts,
        last_updated_timestamp=ts, situation=sit, action=act, outcome=out,
        completeness=completeness,
        source_observation_id=f"{session_id}-O{seq:06d}",
    )


def make_retriever(
    cfg: ExperienceRetrievalConfig = None,
    max_index: int = 200,
) -> ExperienceRetriever:
    if cfg is None:
        cfg = ExperienceRetrievalConfig(
            enabled=True,
            max_results=5,
            minimum_relevance=0.0,
            include_partial=True,
            include_failures=True,
            include_unsafe=True,
            include_degraded=True,
            include_inconclusive=True,
            retrieval_policy=RetrievalPolicy.ALL_EVALUATED,
        )
    idx = ExperienceIndex(max_size=max_index)
    return ExperienceRetriever(idx, cfg)


def make_query(
    session_id: str = "q-sess",
    seq: int = 0,
    road_type: str = "URBAN",
    hazard_level: str = "HIGH",
    cattle: bool = False,
    vru: bool = False,
    action_type: str = "STOP",
    traffic_density: str = "MEDIUM",
    max_results: int = 5,
    min_relevance: float = 0.0,
    policy: RetrievalPolicy = RetrievalPolicy.ALL_EVALUATED,
) -> ExperienceRetrievalQuery:
    query_id = f"{session_id}-Q{seq:06d}"
    return ExperienceRetrievalQuery(
        query_id=query_id,
        session_id=session_id,
        sequence_id=seq,
        timestamp=time.time(),
        schema_version=RETRIEVAL_SCHEMA_VERSION,
        situation_type="HAZARD_RESPONSE",
        road_context=RoadContext(road_type=road_type),
        traffic_context=TrafficContext(
            traffic_density=traffic_density,
            cattle_present=cattle,
            vulnerable_road_user_present=vru,
        ),
        hazard_context=HazardContext(hazard_level=hazard_level),
        vehicle_context=VehicleContext(speed_ms=3.0, is_stopped=True),
        planning_context=PlanningContext(action_type=action_type),
        safety_context=SafetyContext(safety_state="SAFE"),
        maximum_results=max_results,
        minimum_relevance=min_relevance,
        retrieval_policy=policy.value,
    )


def populate_index(
    retriever: ExperienceRetriever,
    n: int = 5,
    session_id: str = "pop-sess",
    road_type: str = "URBAN",
    hazard_level: str = "HIGH",
    outcome_class: OutcomeClass = OutcomeClass.SUCCESS,
) -> list:
    """Add n records to the retriever index. Returns list of record_ids."""
    ids = []
    for i in range(n):
        rec = make_record_with_features(
            session_id=session_id, seq=i,
            road_type=road_type, hazard_level=hazard_level,
        )
        ev = make_eval_snapshot(rec.record_id, session_id, outcome_class)
        retriever.index_experience(rec, ev)
        ids.append(rec.record_id)
    return ids
