"""Tests for Phase 12.4 retrieval types."""
import sys, os, time
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))

from core.experience.retrieval.retrieval_types import (
    RETRIEVAL_SCHEMA_VERSION, NOT_AVAILABLE,
    ExperienceQuality, ExperienceRetrievalConfig, ExperienceRetrievalQuery,
    ExperienceRetrievalResult, ExperienceReuseContext, HazardContext,
    PlanningContext, RetrievalPolicy, RetrievalStatus, RetrievedExperience,
    RoadContext, SafetyContext, TrafficContext, VehicleContext,
)


class TestSchemaVersion:
    def test_schema_version_is_12_4(self):
        assert RETRIEVAL_SCHEMA_VERSION == "12.4"


class TestRetrievalStatus:
    def test_all_statuses_present(self):
        vals = {s.value for s in RetrievalStatus}
        assert "SUCCESS" in vals
        assert "DEGRADED" in vals
        assert "EMPTY" in vals
        assert "ERROR" in vals
        assert "DISABLED" in vals


class TestRetrievalPolicy:
    def test_all_policies_present(self):
        vals = {p.value for p in RetrievalPolicy}
        assert "QUALITY_ONLY" in vals
        assert "ALL_EVALUATED" in vals
        assert "ALL_COMPLETED" in vals
        assert "CUSTOM" in vals


class TestExperienceQuality:
    def test_all_quality_levels(self):
        vals = {q.value for q in ExperienceQuality}
        assert "HIGH" in vals
        assert "MEDIUM" in vals
        assert "LOW" in vals
        assert "UNKNOWN" in vals


class TestContextDefaults:
    def test_road_context_defaults(self):
        rc = RoadContext()
        assert rc.road_type == NOT_AVAILABLE
        d = rc.to_dict()
        assert "road_type" in d

    def test_traffic_context_defaults(self):
        tc = TrafficContext()
        assert tc.cattle_present is False
        assert tc.vulnerable_road_user_present is False

    def test_hazard_context_defaults(self):
        hc = HazardContext()
        assert hc.event_types == ()

    def test_vehicle_context_defaults(self):
        vc = VehicleContext()
        assert vc.speed_ms is None

    def test_planning_context_defaults(self):
        pc = PlanningContext()
        assert pc.action_type == NOT_AVAILABLE

    def test_safety_context_defaults(self):
        sc = SafetyContext()
        assert sc.safety_state == NOT_AVAILABLE


class TestExperienceRetrievalQuery:
    def test_defaults(self):
        q = ExperienceRetrievalQuery()
        assert q.schema_version == RETRIEVAL_SCHEMA_VERSION
        assert q.maximum_results == 5
        assert q.event_types == ()

    def test_to_dict(self):
        q = ExperienceRetrievalQuery(
            query_id="sess-Q000000",
            session_id="sess",
            timestamp=1000.0,
        )
        d = q.to_dict()
        assert d["query_id"] == "sess-Q000000"
        assert "road_context" in d
        assert "hazard_context" in d
        assert "maximum_results" in d


class TestRetrievedExperience:
    def test_defaults(self):
        re = RetrievedExperience()
        assert re.relevance_score == 0.0
        assert re.match_reasons == ()
        assert re.mismatch_reasons == ()
        assert re.experience_quality == ExperienceQuality.UNKNOWN

    def test_to_dict(self):
        re = RetrievedExperience(
            experience_id="EXP-001",
            session_id="sess",
            relevance_score=0.85,
            outcome_class="SUCCESS",
        )
        d = re.to_dict()
        assert d["experience_id"] == "EXP-001"
        assert d["relevance_score"] == 0.85
        assert "match_reasons" in d
        assert "mismatch_reasons" in d


class TestExperienceRetrievalResult:
    def test_defaults(self):
        r = ExperienceRetrievalResult()
        assert r.schema_version == RETRIEVAL_SCHEMA_VERSION
        assert r.retrieved_experiences == ()
        assert r.returned_count == 0

    def test_to_dict(self):
        r = ExperienceRetrievalResult(
            query_id="q-001",
            result_id="q-001-RES",
            retrieval_status=RetrievalStatus.SUCCESS,
        )
        d = r.to_dict()
        assert d["query_id"] == "q-001"
        assert d["retrieval_status"] == "SUCCESS"
        assert "retrieved_experiences" in d


class TestExperienceReuseContext:
    def test_defaults(self):
        ctx = ExperienceReuseContext()
        assert ctx.schema_version == RETRIEVAL_SCHEMA_VERSION
        assert ctx.experiences == ()
        assert ctx.has_experiences is False
        assert ctx.best_experience is None

    def test_has_experiences(self):
        exp = RetrievedExperience(experience_id="EXP-001", session_id="s")
        ctx = ExperienceReuseContext(experiences=(exp,), retrieved_count=1)
        assert ctx.has_experiences is True
        assert ctx.best_experience is exp

    def test_to_dict_no_commands(self):
        ctx = ExperienceReuseContext()
        d = ctx.to_dict()
        # Must NOT contain vehicle control fields
        assert "steering" not in d
        assert "throttle" not in d
        assert "brake" not in d
        assert "trajectory" not in d


class TestExperienceRetrievalConfig:
    def test_defaults(self):
        cfg = ExperienceRetrievalConfig.default()
        assert cfg.enabled is True
        assert cfg.max_results == 5
        assert cfg.minimum_relevance == 0.0
        assert cfg.retrieval_policy == RetrievalPolicy.QUALITY_ONLY

    def test_to_dict(self):
        cfg = ExperienceRetrievalConfig.default()
        d = cfg.to_dict()
        assert "enabled" in d
        assert "max_results" in d
        assert "retrieval_policy" in d
        assert "temporal_decay_per_hour" in d
