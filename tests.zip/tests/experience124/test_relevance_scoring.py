"""Tests for relevance scoring, feature extraction, and scoring dimensions."""
import sys, os, time
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "experience122"))

from exp124_helpers import make_query, make_record_with_features, make_retriever

from core.experience.retrieval.retrieval_types import (
    ExperienceRetrievalConfig, HazardContext, PlanningContext,
    RetrievalPolicy, RoadContext, SafetyContext, TrafficContext, VehicleContext,
)
from core.experience.retrieval.relevance_scorer import (
    RelevanceScorer, ScoringWeights,
    _score_road, _score_traffic, _score_hazard,
    _score_vehicle, _score_planning, _score_safety,
    _apply_temporal_decay,
)
from core.experience.retrieval.feature_extractor import FeatureExtractor


class TestScoringWeights:
    def test_weights_sum_to_one(self):
        total = (ScoringWeights.road + ScoringWeights.traffic +
                 ScoringWeights.hazard + ScoringWeights.vehicle +
                 ScoringWeights.planning + ScoringWeights.safety)
        assert abs(total - 1.0) < 1e-9

    def test_all_weights_positive(self):
        for w in (ScoringWeights.road, ScoringWeights.traffic,
                  ScoringWeights.hazard, ScoringWeights.vehicle,
                  ScoringWeights.planning, ScoringWeights.safety):
            assert w > 0


class TestRoadScoring:
    def test_exact_road_type_match(self):
        q = RoadContext(road_type="URBAN")
        c = RoadContext(road_type="URBAN")
        score, match, miss = _score_road(q, c)
        assert score > 0
        assert any("road_type" in m for m in match)

    def test_road_type_mismatch(self):
        q = RoadContext(road_type="URBAN")
        c = RoadContext(road_type="HIGHWAY")
        score, match, miss = _score_road(q, c)
        assert any("road_type" in m for m in miss)

    def test_score_in_range(self):
        q = RoadContext(road_type="URBAN", road_structure="SINGLE_LANE")
        c = RoadContext(road_type="URBAN", road_structure="DUAL_LANE")
        score, _, _ = _score_road(q, c)
        assert 0.0 <= score <= 1.0


class TestTrafficScoring:
    def test_cattle_match_high_weight(self):
        q = TrafficContext(cattle_present=True, traffic_density="HIGH")
        c = TrafficContext(cattle_present=True, traffic_density="HIGH")
        score, match, _ = _score_traffic(q, c)
        assert score > 0.5
        assert any("cattle" in m for m in match)

    def test_cattle_mismatch_penalised(self):
        q = TrafficContext(cattle_present=True)
        c = TrafficContext(cattle_present=False)
        score_mis, _, _ = _score_traffic(q, c)
        q2 = TrafficContext(cattle_present=True)
        c2 = TrafficContext(cattle_present=True)
        score_match, _, _ = _score_traffic(q2, c2)
        assert score_match > score_mis

    def test_vru_match(self):
        q = TrafficContext(vulnerable_road_user_present=True)
        c = TrafficContext(vulnerable_road_user_present=True)
        _, match, _ = _score_traffic(q, c)
        assert any("vru" in m for m in match)

    def test_adjacent_density_partial_credit(self):
        q = TrafficContext(traffic_density="LOW")
        c_exact = TrafficContext(traffic_density="LOW")
        c_adj = TrafficContext(traffic_density="MEDIUM")
        c_far = TrafficContext(traffic_density="CONGESTED")
        s_exact, _, _ = _score_traffic(q, c_exact)
        s_adj, _, _ = _score_traffic(q, c_adj)
        s_far, _, _ = _score_traffic(q, c_far)
        assert s_exact >= s_adj >= s_far


class TestHazardScoring:
    def test_hazard_level_exact_match(self):
        q = HazardContext(hazard_level="HIGH")
        c = HazardContext(hazard_level="HIGH")
        score, match, _ = _score_hazard(q, c)
        assert score >= 0.4
        assert any("hazard_level" in m for m in match)

    def test_hazard_level_adjacent(self):
        q = HazardContext(hazard_level="HIGH")
        c_adj = HazardContext(hazard_level="MEDIUM")
        c_far = HazardContext(hazard_level="NONE")
        s_adj, _, _ = _score_hazard(q, c_adj)
        s_far, _, _ = _score_hazard(q, c_far)
        assert s_adj > s_far

    def test_road_hazard_flag_match(self):
        q = HazardContext(road_hazard_present=True)
        c = HazardContext(road_hazard_present=True)
        _, match, _ = _score_hazard(q, c)
        assert any("road_hazard" in m for m in match)


class TestVehicleScoring:
    def test_same_speed_band(self):
        q = VehicleContext(speed_ms=5.0, is_stopped=False)
        c = VehicleContext(speed_ms=7.0, is_stopped=False)  # within 5 m/s
        score, match, _ = _score_vehicle(q, c)
        assert any("speed_band" in m for m in match)

    def test_different_speed_band(self):
        q = VehicleContext(speed_ms=0.0)
        c = VehicleContext(speed_ms=20.0)
        _, _, miss = _score_vehicle(q, c)
        assert any("speed_ms" in m for m in miss)

    def test_braking_match(self):
        q = VehicleContext(is_braking=True)
        c = VehicleContext(is_braking=True)
        _, match, _ = _score_vehicle(q, c)
        assert any("is_braking" in m for m in match)

    def test_stopped_match(self):
        q = VehicleContext(is_stopped=True)
        c = VehicleContext(is_stopped=True)
        _, match, _ = _score_vehicle(q, c)
        assert any("is_stopped" in m for m in match)


class TestPlanningScoring:
    def test_action_type_exact_match(self):
        q = PlanningContext(action_type="STOP")
        c = PlanningContext(action_type="STOP")
        score, match, _ = _score_planning(q, c)
        assert score >= 0.7
        assert any("action_type" in m for m in match)

    def test_action_type_mismatch(self):
        q = PlanningContext(action_type="STOP")
        c = PlanningContext(action_type="FOLLOW_REFERENCE")
        _, _, miss = _score_planning(q, c)
        assert any("action_type" in m for m in miss)


class TestSafetyScoring:
    def test_safety_state_match(self):
        q = SafetyContext(safety_state="SAFE")
        c = SafetyContext(safety_state="SAFE")
        score, match, _ = _score_safety(q, c)
        assert score >= 0.4
        assert any("safety_state" in m for m in match)

    def test_emergency_match(self):
        q = SafetyContext(emergency_state="ACTIVE")
        c = SafetyContext(emergency_state="ACTIVE")
        _, match, _ = _score_safety(q, c)
        assert any("emergency_state" in m for m in match)


class TestTemporalDecay:
    def test_no_decay_unchanged(self):
        s = _apply_temporal_decay(0.8, 1000.0, 999.0, 0.0, 0.0)
        assert s == 0.8

    def test_decay_reduces_score(self):
        # 1 hour old experience with decay
        s = _apply_temporal_decay(1.0, 3600.0, 0.0, 1.0, 0.0)
        assert s < 1.0

    def test_max_age_filters_old(self):
        # 2 hours old, max_age 1 hour → score = 0
        s = _apply_temporal_decay(1.0, 7200.0, 0.0, 0.0, 3600.0)
        assert s == 0.0

    def test_within_max_age_kept(self):
        # 30 min old, max_age 1 hour → kept
        s = _apply_temporal_decay(0.8, 1800.0, 0.0, 0.0, 3600.0)
        assert s == 0.8

    def test_decay_deterministic(self):
        s1 = _apply_temporal_decay(0.9, 5000.0, 1000.0, 0.5, 0.0)
        s2 = _apply_temporal_decay(0.9, 5000.0, 1000.0, 0.5, 0.0)
        assert s1 == s2


class TestFullScorer:
    def _make_scorer(self, decay=0.0):
        cfg = ExperienceRetrievalConfig(temporal_decay_per_hour=decay)
        return RelevanceScorer(cfg)

    def _make_query(self):
        from exp124_helpers import make_query
        return make_query(road_type="URBAN", hazard_level="HIGH",
                          cattle=True, action_type="STOP")

    def test_exact_match_high_score(self):
        scorer = self._make_scorer()
        q = self._make_query()
        score, match, miss = scorer.score(
            q,
            RoadContext(road_type="URBAN"),
            TrafficContext(cattle_present=True, traffic_density="MEDIUM"),
            HazardContext(hazard_level="HIGH"),
            VehicleContext(speed_ms=3.0, is_stopped=True),
            PlanningContext(action_type="STOP"),
            SafetyContext(safety_state="SAFE"),
            time.time(),
        )
        assert score > 0.5
        assert len(match) > 0

    def test_unrelated_candidate_low_score(self):
        scorer = self._make_scorer()
        q = self._make_query()
        score, match, miss = scorer.score(
            q,
            RoadContext(road_type="HIGHWAY"),
            TrafficContext(cattle_present=False, traffic_density="LOW"),
            HazardContext(hazard_level="NONE"),
            VehicleContext(speed_ms=30.0, is_stopped=False),
            PlanningContext(action_type="FOLLOW_REFERENCE"),
            SafetyContext(safety_state="NOMINAL"),
            time.time(),
        )
        assert score < 0.5

    def test_score_bounded(self):
        scorer = self._make_scorer()
        q = self._make_query()
        score, _, _ = scorer.score(
            q,
            RoadContext(road_type="URBAN"),
            TrafficContext(cattle_present=True),
            HazardContext(hazard_level="HIGH"),
            VehicleContext(),
            PlanningContext(action_type="STOP"),
            SafetyContext(),
            time.time(),
        )
        assert 0.0 <= score <= 1.0

    def test_score_deterministic(self):
        scorer = self._make_scorer()
        q = self._make_query()
        kwargs = dict(
            cand_road=RoadContext(road_type="URBAN"),
            cand_traffic=TrafficContext(cattle_present=True),
            cand_hazard=HazardContext(hazard_level="HIGH"),
            cand_vehicle=VehicleContext(speed_ms=3.0, is_stopped=True),
            cand_planning=PlanningContext(action_type="STOP"),
            cand_safety=SafetyContext(safety_state="SAFE"),
            cand_timestamp=1000.0,
        )
        s1, m1, x1 = scorer.score(q, **kwargs)
        s2, m2, x2 = scorer.score(q, **kwargs)
        assert s1 == s2
        assert m1 == m2
        assert x1 == x2


class TestFeatureExtractor:
    def setup_method(self):
        self.ext = FeatureExtractor()

    def test_none_situation_gives_defaults(self):
        ctx = self.ext.road_context_from_situation(None)
        assert ctx.road_type == "NOT_AVAILABLE"

    def test_extracts_road_type(self):
        sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "experience122"))
        from exp122_helpers import make_situation
        from core.experience.record.record_engine import _make_record_id
        import time
        rid = _make_record_id("t", 0)
        sit = make_situation("t", rid, 0, time.time())
        sit.road_type = "VILLAGE_ROAD"
        ctx = self.ext.road_context_from_situation(sit)
        assert ctx.road_type == "VILLAGE_ROAD"

    def test_extracts_cattle(self):
        sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "experience122"))
        from exp122_helpers import make_situation
        from core.experience.record.record_engine import _make_record_id
        import time
        rid = _make_record_id("t", 0)
        sit = make_situation("t", rid, 0, time.time(), cattle=True)
        ctx = self.ext.traffic_context_from_situation(sit)
        assert ctx.cattle_present is True

    def test_none_action_gives_defaults(self):
        ctx = self.ext.planning_context_from_action(None)
        assert ctx.action_type == "NOT_AVAILABLE"

    def test_build_query_from_record(self):
        from exp124_helpers import make_record_with_features
        cfg = ExperienceRetrievalConfig.default()
        rec = make_record_with_features(road_type="HIGHWAY")
        ctx = self.ext.build_query(rec, "sess-Q000000", cfg)
        assert ctx.query_id == "sess-Q000000"
        assert ctx.road_context.road_type == "HIGHWAY"
