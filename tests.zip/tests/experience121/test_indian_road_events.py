"""
Phase 12.1 — Tests: Indian Road Scenario Events
Verifies that the capture layer correctly classifies Indian-road events
from existing pipeline state without inventing new perception logic.
"""
import sys, os, time
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))

import pytest
from exp121_helpers import (
    make_config,
    make_world_model_stub,
    make_reasoning_stub,
    make_planner_stub,
    make_safety_stub,
)

from core.experience.capture_engine import ExperienceCaptureEngine
from core.experience.experience_types import CaptureEventType


def _run_scenario(wm=None, rs=None, ps=None, safety=None, sup=None, fs=None):
    engine = ExperienceCaptureEngine(make_config())
    engine.start_session("indian-test-001")
    safety_obj = safety
    snap = engine.capture_cycle(
        world_model_snapshot=wm,
        reasoning_snapshot=rs,
        planner_snapshot=ps,
        safety_state=safety_obj,
        supervisor_snapshot=sup,
        failsafe_snapshot=fs,
        frame_id=0,
    )
    return [e.event_type for e in snap.recent_events]


def test_cattle_crossing_event():
    wm = make_world_model_stub(cattle=True)
    types = _run_scenario(wm=wm)
    assert CaptureEventType.CATTLE_EVENT in types


def test_vulnerable_road_user_event():
    wm = make_world_model_stub(vru=True)
    types = _run_scenario(wm=wm)
    assert CaptureEventType.VULNERABLE_USER_EVENT in types


def test_intersection_event():
    rs = make_reasoning_stub(situation_cat="INTERSECTION_COMPLEXITY")
    types = _run_scenario(rs=rs)
    assert CaptureEventType.INTERSECTION_EVENT in types


def test_highway_merge_event():
    rs = make_reasoning_stub(situation_cat="MERGE_COMPLEXITY")
    types = _run_scenario(rs=rs)
    assert CaptureEventType.HIGHWAY_MERGE_EVENT in types


def test_narrow_road_event():
    rs = make_reasoning_stub(situation_cat="NARROW_ROAD")
    types = _run_scenario(rs=rs)
    assert CaptureEventType.NARROW_ROAD_EVENT in types


def test_unmarked_road_event():
    rs = make_reasoning_stub(situation_cat="UNSTRUCTURED_ROAD")
    types = _run_scenario(rs=rs)
    assert CaptureEventType.UNMARKED_ROAD_EVENT in types


def test_dense_traffic_mixed_event():
    rs = make_reasoning_stub(situation_cat="DENSE_TRAFFIC")
    types = _run_scenario(rs=rs)
    assert CaptureEventType.MIXED_TRAFFIC_EVENT in types


def test_hazard_event_from_critical_risk():
    rs = make_reasoning_stub(hazard_level="CRITICAL")
    types = _run_scenario(rs=rs)
    assert CaptureEventType.HAZARD_DETECTED in types


def test_road_hazard_from_anomaly():
    wm = make_world_model_stub()
    # Inject anomaly
    class _Anomaly:
        anomaly_type = "POTHOLE"
        severity = "MODERATE"

    wm.road.anomalies = [_Anomaly()]
    types = _run_scenario(wm=wm)
    assert CaptureEventType.ROAD_HAZARD_EVENT in types


def test_replanning_triggered_event():
    ps = make_planner_stub(replanning=True)
    types = _run_scenario(ps=ps)
    assert CaptureEventType.REPLANNING_TRIGGERED in types


def test_normal_driving_no_hazards():
    wm = make_world_model_stub(n_objects=1)
    rs = make_reasoning_stub(situation_cat="NORMAL_TRAFFIC", hazard_level="LOW")
    ps = make_planner_stub()
    types = _run_scenario(wm=wm, rs=rs, ps=ps)
    assert CaptureEventType.NORMAL_DRIVING in types


def test_safety_restriction_event():
    """Safety supervisor override should trigger SAFETY_RESTRICTION event."""
    class _AuthVal:
        value = "SAFETY_CONTROL_REQUIRED"

    class _Supervisor:
        control_authority = _AuthVal()

    types = _run_scenario(sup=_Supervisor())
    assert CaptureEventType.SAFETY_RESTRICTION in types


def test_emergency_event():
    """Critical safety state should trigger EMERGENCY_DETECTED event."""
    class _StateVal:
        value = "CRITICAL"

    class _SafetyMon:
        safety_state = _StateVal()

    types = _run_scenario(safety=_SafetyMon())
    assert CaptureEventType.EMERGENCY_DETECTED in types


def test_cattle_and_vru_together():
    """Multiple Indian-road events can coexist in one cycle."""
    wm = make_world_model_stub(cattle=True, vru=True)
    types = _run_scenario(wm=wm)
    assert CaptureEventType.CATTLE_EVENT in types
    assert CaptureEventType.VULNERABLE_USER_EVENT in types
