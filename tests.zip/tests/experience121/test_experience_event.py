"""
Phase 12.1 — Tests: CaptureEvent and CaptureEventType
"""
import sys, os, time
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))

import pytest
from exp121_helpers import make_event

from core.experience.experience_types import (
    EXPERIENCE_SCHEMA_VERSION,
    NOT_AVAILABLE,
    CaptureDataValidity,
    CaptureEvent,
    CaptureEventEvidence,
    CaptureEventType,
)


def test_event_default_fields():
    ev = CaptureEvent()
    assert ev.event_id == NOT_AVAILABLE
    assert ev.schema_version == EXPERIENCE_SCHEMA_VERSION
    assert ev.event_type == CaptureEventType.UNKNOWN_EVENT


def test_event_from_helper():
    ev = make_event(session_id="sess-B", seq=3, event_type=CaptureEventType.HAZARD_DETECTED)
    assert ev.event_id == "sess-B-E000003"
    assert ev.event_type == CaptureEventType.HAZARD_DETECTED
    assert ev.session_id == "sess-B"


def test_event_to_dict():
    ev = make_event()
    d = ev.to_dict()
    assert "event_id" in d
    assert "event_type" in d
    assert "evidence" in d
    assert "timestamp" in d
    assert "schema_version" in d
    assert "data_validity" in d


def test_all_event_types_are_valid_enum():
    for et in CaptureEventType:
        ev = make_event(event_type=et)
        assert ev.event_type == et
        d = ev.to_dict()
        assert d["event_type"] == et.value


def test_event_evidence_confidence_bounds():
    ev = make_event()
    ev_dict = ev.to_dict()
    evidence = ev_dict["evidence"]
    assert 0.0 <= evidence["confidence"] <= 1.0
    assert 0.0 <= evidence["uncertainty"] <= 1.0


def test_event_evidence_event_type_matches():
    ev = make_event(event_type=CaptureEventType.CATTLE_EVENT)
    assert ev.evidence.event_type == CaptureEventType.CATTLE_EVENT


def test_indian_road_event_types_exist():
    """Verify all Indian-road event types exist in the enum."""
    indian_types = [
        CaptureEventType.CATTLE_EVENT,
        CaptureEventType.VULNERABLE_USER_EVENT,
        CaptureEventType.INTERSECTION_EVENT,
        CaptureEventType.HIGHWAY_MERGE_EVENT,
        CaptureEventType.UNMARKED_ROAD_EVENT,
        CaptureEventType.NARROW_ROAD_EVENT,
        CaptureEventType.MIXED_TRAFFIC_EVENT,
        CaptureEventType.ROAD_HAZARD_EVENT,
    ]
    for et in indian_types:
        assert isinstance(et, CaptureEventType)


def test_safety_event_types_exist():
    safety_types = [
        CaptureEventType.EMERGENCY_DETECTED,
        CaptureEventType.SAFETY_RESTRICTION,
        CaptureEventType.FAIL_SAFE_EVENT,
        CaptureEventType.SENSOR_DEGRADATION,
    ]
    for et in safety_types:
        assert isinstance(et, CaptureEventType)


def test_degradation_event_types_exist():
    deg_types = [
        CaptureEventType.CONTROL_DEGRADATION,
        CaptureEventType.TRACKING_DEGRADATION,
        CaptureEventType.PLANNING_DEGRADATION,
        CaptureEventType.MPC_DEGRADATION,
    ]
    for et in deg_types:
        assert isinstance(et, CaptureEventType)


def test_event_id_format():
    ev = make_event(session_id="my-session", seq=42)
    assert ev.event_id == "my-session-E000042"


def test_event_stale_flag():
    ev = make_event()
    assert isinstance(ev.evidence.is_stale, bool)
    assert isinstance(ev.evidence.is_degraded, bool)
