"""
Phase 12.1 — Tests: Pipeline Integration
Verifies the adapter connects cleanly to the existing pipeline
without modifying any pipeline output.
"""
import sys, os, time
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))

import pytest
from exp121_helpers import (
    make_config,
    make_world_model_stub,
    make_reasoning_stub,
    make_planner_stub,
    make_safety_stub,
)

from core.experience.pipeline_capture_adapter import PipelineCaptureAdapter
from core.experience.experience_types import (
    ExperienceCaptureConfig,
    ExperienceCaptureStatus,
    SessionStatus,
)


def test_adapter_default_config():
    adapter = PipelineCaptureAdapter()
    assert adapter is not None


def test_adapter_custom_config():
    cfg = make_config(max_obs=200, max_events=100)
    adapter = PipelineCaptureAdapter(config=cfg)
    assert adapter is not None


def test_adapter_full_pipeline_cycle():
    adapter = PipelineCaptureAdapter()
    adapter.start_session("pipe-001")

    wm = make_world_model_stub(n_objects=3)
    rs = make_reasoning_stub()
    ps = make_planner_stub()
    safety, supervisor, failsafe = make_safety_stub()

    snap = adapter.observe(
        world_model_snapshot=wm,
        reasoning_snapshot=rs,
        planner_snapshot=ps,
        safety_state=safety,
        supervisor_snapshot=supervisor,
        failsafe_snapshot=failsafe,
        frame_id=1,
    )
    assert snap is not None
    assert snap.session_id == "pipe-001"
    assert snap.session_status == SessionStatus.ACTIVE
    assert snap.observation_count >= 1


def test_adapter_multi_cycle_session():
    adapter = PipelineCaptureAdapter()
    adapter.start_session("pipe-multi-001")
    for i in range(10):
        snap = adapter.observe(frame_id=i)
    assert snap.observation_count == 10


def test_adapter_finalize_session():
    adapter = PipelineCaptureAdapter()
    adapter.start_session("pipe-fin-001")
    adapter.observe(frame_id=0)
    ok = adapter.finalize_session()
    assert ok
    snap = adapter.get_snapshot()
    assert snap.session_status == SessionStatus.COMPLETED


def test_adapter_does_not_modify_world_model():
    """Adapter must not mutate any pipeline objects."""
    adapter = PipelineCaptureAdapter()
    adapter.start_session("pipe-immut-001")
    wm = make_world_model_stub(n_objects=2)
    obj_count_before = len(wm.objects)
    rs = make_reasoning_stub()
    adapter.observe(world_model_snapshot=wm, reasoning_snapshot=rs, frame_id=0)
    assert len(wm.objects) == obj_count_before


def test_adapter_reset():
    adapter = PipelineCaptureAdapter()
    adapter.start_session("pipe-reset-001")
    adapter.observe(frame_id=0)
    adapter.reset()
    snap = adapter.get_snapshot()
    assert snap.session_status == SessionStatus.UNKNOWN


def test_adapter_capture_status_active():
    adapter = PipelineCaptureAdapter()
    adapter.start_session("pipe-status-001")
    adapter.observe(frame_id=0)
    assert adapter.capture_status in (
        ExperienceCaptureStatus.ACTIVE,
        ExperienceCaptureStatus.OVERFLOW,
        ExperienceCaptureStatus.DEGRADED,
    )


def test_adapter_new_session_replaces_old():
    adapter = PipelineCaptureAdapter()
    adapter.start_session("pipe-s1")
    adapter.observe(frame_id=0)
    adapter.start_session("pipe-s2")
    snap = adapter.observe(frame_id=0)
    assert snap.session_id == "pipe-s2"
