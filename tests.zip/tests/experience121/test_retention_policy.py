"""
Phase 12.1 — Tests: Retention Policy
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))

import pytest
from exp121_helpers import make_observation, make_event

from core.experience.capture_store import ExperienceCaptureStore
from core.experience.experience_types import (
    ExperienceCaptureConfig,
    CaptureEventType,
    RetentionPolicy,
)


def _bounded_store(max_obs=5, max_ev=5, policy=RetentionPolicy.BOUNDED_FIFO):
    cfg = ExperienceCaptureConfig(
        max_observations_per_session=max_obs,
        max_events_per_session=max_ev,
        recent_window_observations=max_obs,
        recent_window_events=max_ev,
        retention_policy=policy,
    )
    store = ExperienceCaptureStore(cfg)
    return store


def test_fifo_oldest_dropped():
    store = _bounded_store(max_obs=3)
    store.start_session("ret-001")
    for i in range(5):
        store.append_observation(make_observation(session_id="ret-001", seq=i))
    recent = store.get_recent_observations(n=10)
    seqs = [o.sequence_id for o in recent]
    assert len(seqs) == 3
    assert 0 not in seqs  # oldest dropped
    assert 1 not in seqs
    assert 4 in seqs      # newest kept


def test_fifo_events_oldest_dropped():
    store = _bounded_store(max_ev=3)
    store.start_session("ret-002")
    for i in range(5):
        store.append_event(make_event(session_id="ret-002", seq=i))
    recent = store.get_recent_events(n=10)
    seqs = [e.sequence_id for e in recent]
    assert len(seqs) == 3
    assert 4 in seqs


def test_event_priority_drops_normal_first():
    store = _bounded_store(max_ev=3, policy=RetentionPolicy.EVENT_PRIORITY)
    store.start_session("ret-003")
    # 3 NORMAL_DRIVING
    for i in range(3):
        ev = make_event(session_id="ret-003", seq=i,
                        event_type=CaptureEventType.NORMAL_DRIVING)
        store.append_event(ev)
    # Add a HAZARD_DETECTED — should push out a NORMAL_DRIVING
    hazard_ev = make_event(session_id="ret-003", seq=3,
                           event_type=CaptureEventType.HAZARD_DETECTED)
    store.append_event(hazard_ev)
    recent = store.get_recent_events(n=10)
    types = [e.event_type for e in recent]
    assert CaptureEventType.HAZARD_DETECTED in types
    assert len(recent) <= 3


def test_event_priority_falls_back_to_fifo():
    """If all events are non-NORMAL, EVENT_PRIORITY falls back to FIFO."""
    store = _bounded_store(max_ev=2, policy=RetentionPolicy.EVENT_PRIORITY)
    store.start_session("ret-004")
    for i in range(3):
        ev = make_event(session_id="ret-004", seq=i,
                        event_type=CaptureEventType.HAZARD_DETECTED)
        store.append_event(ev)
    recent = store.get_recent_events(n=10)
    assert len(recent) <= 2


def test_config_retention_policy_stored():
    cfg = ExperienceCaptureConfig(retention_policy=RetentionPolicy.EVENT_PRIORITY)
    assert cfg.retention_policy == RetentionPolicy.EVENT_PRIORITY


def test_retention_policy_enum_values():
    assert RetentionPolicy.BOUNDED_FIFO.value == "BOUNDED_FIFO"
    assert RetentionPolicy.EVENT_PRIORITY.value == "EVENT_PRIORITY"


def test_store_count_matches_actual():
    store = _bounded_store(max_obs=5)
    store.start_session("ret-005")
    for i in range(4):
        store.append_observation(make_observation(session_id="ret-005", seq=i))
    snap = store.get_session_snapshot()
    # observation_count should equal actual stored count
    recent = store.get_recent_observations(n=10)
    assert snap.observation_count == len(recent)
