"""
Phase 12.1 — Tests: Negative Scope
Explicitly verifies that Phase 12.1 does NOT implement any
Phase 12.2+ functionality or modify autonomous pipeline decisions.
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))

import pytest
import inspect

from core.experience import (
    ExperienceCaptureEngine,
    ExperienceCaptureConfig,
    ExperienceObservation,
    CaptureEvent,
    ExperienceCaptureSnapshot,
    DrivingExperienceSession,
    PipelineCaptureAdapter,
)
import core.experience.experience_types as etypes
import core.experience.capture_engine as cengine
import core.experience.capture_store as cstore
import core.experience.capture_validator as cvalidator
import core.experience.pipeline_capture_adapter as padapter


# ---------------------------------------------------------------------------
# 1. No learning / model update
# ---------------------------------------------------------------------------

def test_no_train_method_anywhere():
    modules = [etypes, cengine, cstore, cvalidator, padapter]
    for mod in modules:
        for name in dir(mod):
            assert "train" not in name.lower() or name.startswith("_"), (
                f"Unexpected 'train' symbol in {mod.__name__}: {name}"
            )


def test_no_update_weights_method():
    for cls in [ExperienceCaptureEngine, PipelineCaptureAdapter]:
        for name in dir(cls):
            assert "weight" not in name.lower(), (
                f"Unexpected 'weight' method in {cls.__name__}: {name}"
            )


def test_no_reward_field_in_observation():
    obs = ExperienceObservation()
    assert not hasattr(obs, "reward"), "ExperienceObservation must not have reward field"
    d = obs.to_dict()
    assert "reward" not in d


def test_no_success_field_in_observation():
    obs = ExperienceObservation()
    assert not hasattr(obs, "success")
    d = obs.to_dict()
    assert "success" not in d


def test_no_optimal_action_field():
    obs = ExperienceObservation()
    assert not hasattr(obs, "optimal_action")
    assert not hasattr(obs, "best_action")


def test_no_learned_policy_field():
    obs = ExperienceObservation()
    assert not hasattr(obs, "learned_policy")


# ---------------------------------------------------------------------------
# 2. No outcome evaluation (Phase 12.3)
# ---------------------------------------------------------------------------

def test_no_evaluate_success_method():
    for cls in [ExperienceCaptureEngine, PipelineCaptureAdapter]:
        for name in dir(cls):
            assert "evaluat" not in name.lower() or "validate" in name.lower(), (
                f"Unexpected evaluate method in {cls.__name__}: {name}"
            )


def test_no_outcome_field_in_snapshot():
    snap = ExperienceCaptureSnapshot()
    assert not hasattr(snap, "outcome")
    assert not hasattr(snap, "success_rate")
    d = snap.to_dict()
    assert "outcome" not in d


# ---------------------------------------------------------------------------
# 3. No experience retrieval (Phase 12.4)
# ---------------------------------------------------------------------------

def test_no_retrieve_method():
    for cls in [ExperienceCaptureEngine, PipelineCaptureAdapter]:
        assert not hasattr(cls, "retrieve_similar"), (
            f"{cls.__name__} must not have retrieve_similar (Phase 12.4)"
        )
        assert not hasattr(cls, "find_similar"), (
            f"{cls.__name__} must not have find_similar"
        )
        assert not hasattr(cls, "rank_experiences"), (
            f"{cls.__name__} must not have rank_experiences"
        )


def test_no_similarity_engine_imported():
    """capture_engine must not import similarity/retrieval modules."""
    import ast, pathlib
    src = pathlib.Path(cengine.__file__).read_text()
    assert "similarity_engine" not in src, "capture_engine must not use similarity_engine"
    assert "retrieval_engine" not in src, "capture_engine must not use retrieval_engine"


# ---------------------------------------------------------------------------
# 4. No adaptive knowledge update (Phase 12.5)
# ---------------------------------------------------------------------------

def test_no_adapt_method():
    for cls in [ExperienceCaptureEngine, PipelineCaptureAdapter]:
        assert not hasattr(cls, "adapt"), f"{cls.__name__} must not have adapt()"
        assert not hasattr(cls, "update_knowledge"), (
            f"{cls.__name__} must not have update_knowledge()"
        )


# ---------------------------------------------------------------------------
# 5. No decision improvement (Phase 12.6)
# ---------------------------------------------------------------------------

def test_no_improve_decision_method():
    for cls in [ExperienceCaptureEngine, PipelineCaptureAdapter]:
        assert not hasattr(cls, "improve_decision")
        assert not hasattr(cls, "update_policy")


# ---------------------------------------------------------------------------
# 6. No new perception / prediction
# ---------------------------------------------------------------------------

def test_no_perception_import_in_engine():
    """Capture engine must not import from core.perception.*"""
    import pathlib
    src = pathlib.Path(cengine.__file__).read_text()
    # Check import statements only — not comments/docstrings
    import_lines = [l for l in src.splitlines() if l.strip().startswith(("import ", "from "))]
    for line in import_lines:
        assert "perception" not in line.lower(), (
            f"capture_engine must not import perception modules: {line}"
        )


def test_no_prediction_call_in_engine():
    """Capture engine must not import from core.prediction.*"""
    import pathlib
    src = pathlib.Path(cengine.__file__).read_text()
    import_lines = [l for l in src.splitlines() if l.strip().startswith(("import ", "from "))]
    for line in import_lines:
        assert "predictor" not in line.lower(), f"Unexpected import: {line}"
        assert "MotionPredict" not in line, f"Unexpected import: {line}"


# ---------------------------------------------------------------------------
# 7. No new MPC / control generation
# ---------------------------------------------------------------------------

def test_no_mpc_generation_in_engine():
    import pathlib
    src = pathlib.Path(cengine.__file__).read_text()
    assert "mpc_solver" not in src.lower()
    assert "MPCSolver" not in src
    assert "apply_control" not in src


def test_no_steering_command_generated():
    import pathlib
    src = pathlib.Path(cengine.__file__).read_text()
    assert "steering_angle" not in src or "steering_status" in src
    # steering_status is only read; ensure no 'set steering' pattern
    assert "commanded_steering" not in src


# ---------------------------------------------------------------------------
# 8. No cloud / LLM / network
# ---------------------------------------------------------------------------

def test_no_llm_import():
    import pathlib
    for mod_file in [cengine.__file__, cstore.__file__, padapter.__file__]:
        src = pathlib.Path(mod_file).read_text()
        assert "openai" not in src.lower()
        assert "anthropic" not in src.lower()
        assert "requests" not in src.lower()
        assert "urllib" not in src.lower()


def test_no_cloud_storage_import():
    """Capture modules must not import external DB/cloud storage libraries."""
    import pathlib
    for mod_file in [cengine.__file__, cstore.__file__]:
        src = pathlib.Path(mod_file).read_text()
        import_lines = [l for l in src.splitlines()
                        if l.strip().startswith(("import ", "from "))]
        for line in import_lines:
            ll = line.lower()
            assert "pymongo" not in ll, f"Unexpected DB import: {line}"
            assert "boto3" not in ll, f"Unexpected cloud import: {line}"
            assert "faiss" not in ll, f"Unexpected vector DB import: {line}"
            # redis may appear in comments — check import lines only
            assert "import redis" not in ll, f"Unexpected import: {line}"


# ---------------------------------------------------------------------------
# 9. No path / trajectory generation
# ---------------------------------------------------------------------------

def test_no_path_generation_in_engine():
    import pathlib
    src = pathlib.Path(cengine.__file__).read_text()
    assert "CandidatePath(" not in src, (
        "capture_engine must not generate CandidatePath objects"
    )
    assert "generate_path" not in src


def test_capture_engine_does_not_call_planner():
    import pathlib
    src = pathlib.Path(cengine.__file__).read_text()
    assert "PlannerEngine(" not in src
    assert "planner_engine.run" not in src


# ---------------------------------------------------------------------------
# 10. Observation schema has no forbidden evaluation fields
# ---------------------------------------------------------------------------

def test_observation_dict_has_no_evaluation_keys():
    from exp121_helpers import make_observation
    obs = make_observation()
    d = obs.to_dict()
    forbidden = {"success", "reward", "optimal_action", "learned_policy",
                 "improvement", "best_action", "policy_update", "reinforcement"}
    found = forbidden & set(d.keys())
    assert not found, f"Forbidden keys found in observation dict: {found}"
