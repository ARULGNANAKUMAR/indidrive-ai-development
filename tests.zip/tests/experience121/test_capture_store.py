"""
Phase 12.1 — Tests: ExperienceCaptureStore
"""
import sys, os, time
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))

import pytest
from exp121_helpers import make_config, make_observation, make_event

from core.experience.capture_store import ExperienceCaptureStore
from core.experience.experience_types import (
    CaptureEventType,
    ExperienceCaptureStatus,
    RetentionPolicy,
    SessionStatus,
)


def test_store_initial_state():
    store = ExperienceCaptureStore(make_config())
    assert not store.is_active
    assert not store.has_session
    assert store.capture_status == ExperienceCaptureStatus.IDLE


def test_store_start_session():
    store = ExperienceCaptureStore(make_config())
    ok = store.start_session("s-001")
    assert ok
    assert store.has_session
    assert store.is_active


def test_store_invalid_session_id():
    store = ExperienceCaptureStore(make_config())
    ok = store.start_session("")
    assert not ok


def test_store_append_observation():
    store = ExperienceCaptureStore(make_config())
    store.start_session("s-001")
    obs = make_observation(session_id="s-001", seq=0)
    ok = store.append_observation(obs)
    assert ok
    recent = store.get_recent_observations()
    assert len(recent) == 1


def test_store_append_event():
    store = ExperienceCaptureStore(make_config())
    store.start_session("s-001")
    ev = make_event(session_id="s-001", seq=0)
    ok = store.append_event(ev)
    assert ok
    recent = store.get_recent_events()
    assert len(recent) == 1


def test_store_no_active_session_append():
    store = ExperienceCaptureStore(make_config())
    obs = make_observation()
    ok = store.append_observation(obs)
    assert not ok


def test_store_snapshot_idle():
    store = ExperienceCaptureStore(make_config())
    snap = store.get_session_snapshot()
    assert snap.capture_status == ExperienceCaptureStatus.IDLE


def test_store_snapshot_active():
    store = ExperienceCaptureStore(make_config())
    store.start_session("s-002")
    obs = make_observation(session_id="s-002", seq=0)
    store.append_observation(obs)
    snap = store.get_session_snapshot()
    assert snap.session_id == "s-002"
    assert snap.session_status == SessionStatus.ACTIVE
    assert snap.observation_count == 1


def test_store_finalize():
    store = ExperienceCaptureStore(make_config())
    store.start_session("s-003")
    ok = store.finalize_session()
    assert ok
    snap = store.get_session_snapshot()
    assert snap.session_status == SessionStatus.COMPLETED


def test_store_finalize_degraded():
    store = ExperienceCaptureStore(make_config())
    store.start_session("s-004")
    store.finalize_session(degraded=True)
    snap = store.get_session_snapshot()
    assert snap.session_status == SessionStatus.DEGRADED


def test_store_clear():
    store = ExperienceCaptureStore(make_config())
    store.start_session("s-005")
    store.append_observation(make_observation(session_id="s-005"))
    store.clear_session()
    assert not store.has_session
    snap = store.get_session_snapshot()
    assert snap.session_status == SessionStatus.UNKNOWN


def test_store_recent_window():
    cfg = make_config(max_obs=200, window=5)
    store = ExperienceCaptureStore(cfg)
    store.start_session("s-006")
    for i in range(10):
        store.append_observation(make_observation(session_id="s-006", seq=i))
    recent = store.get_recent_observations()
    assert len(recent) == 5  # window=5


def test_store_recent_observations_are_tuple():
    store = ExperienceCaptureStore(make_config())
    store.start_session("s-007")
    store.append_observation(make_observation(session_id="s-007"))
    result = store.get_recent_observations()
    assert isinstance(result, tuple)


def test_store_snapshot_immutable_recent():
    """Snapshot recent_observations is a tuple — cannot be mutated."""
    store = ExperienceCaptureStore(make_config())
    store.start_session("s-008")
    store.append_observation(make_observation(session_id="s-008"))
    snap = store.get_session_snapshot()
    assert isinstance(snap.recent_observations, tuple)
    assert isinstance(snap.recent_events, tuple)
