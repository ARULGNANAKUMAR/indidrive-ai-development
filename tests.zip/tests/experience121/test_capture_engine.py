"""
Phase 12.1 — Tests: ExperienceCaptureEngine
"""
import sys, os, time
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))

import pytest
from exp121_helpers import (
    make_config,
    make_world_model_stub,
    make_reasoning_stub,
    make_planner_stub,
    make_safety_stub,
)

from core.experience.capture_engine import ExperienceCaptureEngine
from core.experience.experience_types import (
    ExperienceCaptureConfig,
    ExperienceCaptureStatus,
    SessionStatus,
    NOT_AVAILABLE,
)


def _engine():
    return ExperienceCaptureEngine(make_config())


def test_engine_start_session():
    engine = _engine()
    ok = engine.start_session("s-E001")
    assert ok


def test_engine_capture_cycle_no_session():
    engine = _engine()
    snap = engine.capture_cycle(frame_id=0)
    # No session started — should return idle/unknown state without crashing
    assert snap is not None


def test_engine_capture_cycle_basic():
    engine = _engine()
    engine.start_session("s-E002")
    snap = engine.capture_cycle(frame_id=0)
    assert snap is not None
    assert snap.session_id == "s-E002"
    assert snap.session_status == SessionStatus.ACTIVE


def test_engine_capture_with_stubs():
    engine = _engine()
    engine.start_session("s-E003")
    wm = make_world_model_stub(n_objects=3)
    rs = make_reasoning_stub()
    ps = make_planner_stub()
    safety, supervisor, failsafe = make_safety_stub()
    snap = engine.capture_cycle(
        world_model_snapshot=wm,
        reasoning_snapshot=rs,
        planner_snapshot=ps,
        safety_state=safety,
        supervisor_snapshot=supervisor,
        failsafe_snapshot=failsafe,
        frame_id=1,
    )
    assert snap.observation_count >= 1


def test_engine_generates_observations_over_cycles():
    engine = _engine()
    engine.start_session("s-E004")
    for i in range(5):
        engine.capture_cycle(frame_id=i)
    snap = engine.get_snapshot()
    assert snap.observation_count == 5


def test_engine_generates_events():
    engine = _engine()
    engine.start_session("s-E005")
    engine.capture_cycle(frame_id=0)
    snap = engine.get_snapshot()
    # At minimum, NORMAL_DRIVING event should be captured
    assert snap.event_count >= 1


def test_engine_finalize_session():
    engine = _engine()
    engine.start_session("s-E006")
    engine.capture_cycle(frame_id=0)
    ok = engine.finalize_session()
    assert ok
    snap = engine.get_snapshot()
    assert snap.session_status == SessionStatus.COMPLETED


def test_engine_reset():
    engine = _engine()
    engine.start_session("s-E007")
    engine.capture_cycle(frame_id=0)
    engine.reset()
    snap = engine.get_snapshot()
    assert snap.session_id == NOT_AVAILABLE


def test_engine_deterministic_ids():
    """Same session + same sequence → same observation ID format."""
    engine = _engine()
    engine.start_session("sess-fixed")
    engine.capture_cycle(frame_id=0)
    snap = engine.get_snapshot()
    obs = snap.recent_observations
    if obs:
        assert obs[0].experience_id == "sess-fixed-O000000"


def test_engine_does_not_modify_world_model():
    """Engine must be a read-only observer."""
    engine = _engine()
    engine.start_session("s-E009")
    wm = make_world_model_stub(n_objects=2)
    original_count = len(wm.objects)
    engine.capture_cycle(world_model_snapshot=wm, frame_id=0)
    # World model unchanged
    assert len(wm.objects) == original_count


def test_engine_hazard_event_captured():
    """High hazard level should produce HAZARD_DETECTED event."""
    engine = _engine()
    engine.start_session("s-E010")
    rs = make_reasoning_stub(hazard_level="CRITICAL")
    engine.capture_cycle(reasoning_snapshot=rs, frame_id=0)
    snap = engine.get_snapshot()
    event_types = [e.event_type.value for e in snap.recent_events]
    assert "HAZARD_DETECTED" in event_types


def test_engine_config_required():
    with pytest.raises(TypeError):
        ExperienceCaptureEngine("not-a-config")
