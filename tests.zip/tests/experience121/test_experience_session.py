"""
Phase 12.1 — Tests: DrivingExperienceSession
"""
import sys, os, time
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))

import pytest
from core.experience.experience_types import (
    EXPERIENCE_SCHEMA_VERSION,
    NOT_AVAILABLE,
    DrivingExperienceSession,
    SessionStatus,
)


def test_session_default_fields():
    s = DrivingExperienceSession()
    assert s.session_id == NOT_AVAILABLE
    assert s.status == SessionStatus.UNKNOWN
    assert s.observation_count == 0
    assert s.event_count == 0
    assert s.schema_version == EXPERIENCE_SCHEMA_VERSION


def test_session_status_enum_values():
    for st in SessionStatus:
        assert isinstance(st.value, str)


def test_session_to_dict():
    s = DrivingExperienceSession(
        session_id="sess-001",
        start_timestamp=1000.0,
        last_timestamp=1010.0,
        status=SessionStatus.ACTIVE,
        observation_count=5,
        event_count=2,
    )
    d = s.to_dict()
    assert d["session_id"] == "sess-001"
    assert d["status"] == "ACTIVE"
    assert d["observation_count"] == 5
    assert d["event_count"] == 2
    assert d["schema_version"] == EXPERIENCE_SCHEMA_VERSION


def test_session_internal_lists_not_exposed():
    """Internal _observations and _events are not in to_dict()."""
    s = DrivingExperienceSession(session_id="x")
    d = s.to_dict()
    assert "_observations" not in d
    assert "_events" not in d
    assert "observations" not in d
    assert "events" not in d


def test_session_all_statuses():
    statuses = [
        SessionStatus.ACTIVE,
        SessionStatus.PAUSED,
        SessionStatus.COMPLETED,
        SessionStatus.DEGRADED,
        SessionStatus.INVALID,
        SessionStatus.UNKNOWN,
    ]
    for st in statuses:
        s = DrivingExperienceSession(session_id="x", status=st)
        assert s.status == st


def test_session_timestamp_ordering():
    s = DrivingExperienceSession(
        session_id="sess-002",
        start_timestamp=500.0,
        last_timestamp=600.0,
    )
    assert s.last_timestamp >= s.start_timestamp
