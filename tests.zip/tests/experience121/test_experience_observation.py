"""
Phase 12.1 — Tests: ExperienceObservation
"""
import sys, os, time
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))

import pytest
from exp121_helpers import make_observation

from core.experience.experience_types import (
    EXPERIENCE_SCHEMA_VERSION,
    NOT_AVAILABLE,
    CaptureDataValidity,
    ExperienceObservation,
    EgoContextSummary,
    EnvironmentSummary,
    SituationSummary,
    PlanningSummary,
    ControlSummary,
    SafetySummary,
)


def test_observation_default_fields():
    obs = ExperienceObservation()
    assert obs.schema_version == EXPERIENCE_SCHEMA_VERSION
    assert obs.experience_id == NOT_AVAILABLE
    assert obs.session_id == NOT_AVAILABLE
    assert obs.sequence_id == 0
    assert obs.data_validity == CaptureDataValidity.UNKNOWN


def test_observation_from_helper():
    obs = make_observation(session_id="sess-A", seq=5)
    assert obs.experience_id == "sess-A-O000005"
    assert obs.session_id == "sess-A"
    assert obs.sequence_id == 5
    assert obs.data_validity == CaptureDataValidity.VALID


def test_observation_to_dict_structure():
    obs = make_observation()
    d = obs.to_dict()
    assert "experience_id" in d
    assert "session_id" in d
    assert "sequence_id" in d
    assert "timestamp" in d
    assert "frame_id" in d
    assert "schema_version" in d
    assert "data_validity" in d
    assert "ego_context" in d
    assert "environment" in d
    assert "situation" in d
    assert "planning" in d
    assert "control" in d
    assert "safety" in d


def test_observation_no_success_field():
    """Phase 12.1 must NOT have success/reward/optimal_action fields."""
    obs = make_observation()
    assert not hasattr(obs, "success")
    assert not hasattr(obs, "reward")
    assert not hasattr(obs, "optimal_action")
    assert not hasattr(obs, "learned_policy")
    d = obs.to_dict()
    assert "success" not in d
    assert "reward" not in d
    assert "optimal_action" not in d
    assert "learned_policy" not in d


def test_ego_context_to_dict():
    ego = EgoContextSummary(
        position_x=10.0, velocity_ms=8.0, vehicle_state_validity="VALID"
    )
    d = ego.to_dict()
    assert d["position_x"] == 10.0
    assert d["velocity_ms"] == 8.0
    assert d["vehicle_state_validity"] == "VALID"
    assert d["position_y"] == NOT_AVAILABLE


def test_environment_summary_to_dict():
    env = EnvironmentSummary(nearby_object_count=3, cattle_present=True)
    d = env.to_dict()
    assert d["nearby_object_count"] == 3
    assert d["cattle_present"] is True


def test_situation_summary_confidence_bounds():
    sit = SituationSummary(reasoning_confidence=0.75, reasoning_uncertainty=0.25)
    d = sit.to_dict()
    assert 0.0 <= d["reasoning_confidence"] <= 1.0
    assert 0.0 <= d["reasoning_uncertainty"] <= 1.0


def test_planning_summary_to_dict():
    plan = PlanningSummary(planning_mode="PLAN_AVAILABLE", replanning_active=False)
    d = plan.to_dict()
    assert d["planning_mode"] == "PLAN_AVAILABLE"
    assert d["replanning_active"] is False


def test_control_summary_to_dict():
    ctrl = ControlSummary(control_status="VALID", steering_status="VALID")
    d = ctrl.to_dict()
    assert d["control_status"] == "VALID"


def test_safety_summary_to_dict():
    safety = SafetySummary(safety_state="SAFE", supervisor_authority="NORMAL_CONTROL")
    d = safety.to_dict()
    assert d["safety_state"] == "SAFE"
    assert d["supervisor_authority"] == "NORMAL_CONTROL"


def test_observation_schema_version():
    obs = make_observation()
    assert obs.schema_version == EXPERIENCE_SCHEMA_VERSION
    assert obs.to_dict()["schema_version"] == EXPERIENCE_SCHEMA_VERSION


def test_stale_observation():
    obs = make_observation(
        timestamp=time.time() - 100,
        data_validity=CaptureDataValidity.STALE,
    )
    assert obs.data_validity == CaptureDataValidity.STALE


def test_degraded_observation():
    obs = make_observation(data_validity=CaptureDataValidity.DEGRADED)
    assert obs.data_validity == CaptureDataValidity.DEGRADED
