"""
Phase 12.1 — Tests: ExperienceCaptureSnapshot Semantics and Immutability
"""
import sys, os, time
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))

import pytest
from exp121_helpers import make_config, make_observation, make_event

from core.experience.capture_store import ExperienceCaptureStore
from core.experience.experience_types import (
    EXPERIENCE_SCHEMA_VERSION,
    ExperienceCaptureSnapshot,
    ExperienceCaptureStatus,
    SessionStatus,
    NOT_AVAILABLE,
)


def test_snapshot_to_dict_fields():
    snap = ExperienceCaptureSnapshot(
        session_id="s-snap-001",
        session_status=SessionStatus.ACTIVE,
        capture_status=ExperienceCaptureStatus.ACTIVE,
        observation_count=3,
        event_count=1,
    )
    d = snap.to_dict()
    assert "schema_version" in d
    assert "session_id" in d
    assert "session_status" in d
    assert "capture_status" in d
    assert "observation_count" in d
    assert "event_count" in d
    assert "recent_observation_count" in d
    assert "capture_failed" in d
    assert "failure_reason" in d


def test_snapshot_recent_are_tuples():
    snap = ExperienceCaptureSnapshot()
    assert isinstance(snap.recent_observations, tuple)
    assert isinstance(snap.recent_events, tuple)


def test_snapshot_does_not_expose_mutable_list():
    """Snapshot recent_observations must be a tuple, not a list."""
    store = ExperienceCaptureStore(make_config())
    store.start_session("s-snap-002")
    store.append_observation(make_observation(session_id="s-snap-002"))
    snap = store.get_session_snapshot()
    # These should be tuples — not mutable lists
    assert isinstance(snap.recent_observations, tuple)
    assert isinstance(snap.recent_events, tuple)


def test_snapshot_schema_version():
    snap = ExperienceCaptureSnapshot()
    assert snap.schema_version == EXPERIENCE_SCHEMA_VERSION


def test_snapshot_does_not_change_active_state():
    """Calling get_session_snapshot twice returns consistent view."""
    store = ExperienceCaptureStore(make_config())
    store.start_session("s-snap-003")
    obs = make_observation(session_id="s-snap-003")
    store.append_observation(obs)
    snap1 = store.get_session_snapshot()
    snap2 = store.get_session_snapshot()
    # Store is unchanged — snapshots are consistent
    assert snap1.observation_count == snap2.observation_count
    assert snap1.session_id == snap2.session_id


def test_snapshot_failure_not_propagated():
    """Snapshot with failure should not raise during inspection."""
    snap = ExperienceCaptureSnapshot(
        capture_failed=True,
        failure_reason="test failure",
        capture_status=ExperienceCaptureStatus.FAILED,
    )
    assert snap.capture_failed
    assert "test failure" in snap.failure_reason
    d = snap.to_dict()
    assert d["capture_failed"] is True


def test_snapshot_idle_state():
    store = ExperienceCaptureStore(make_config())
    snap = store.get_session_snapshot()
    assert snap.capture_status == ExperienceCaptureStatus.IDLE
    assert snap.session_id == NOT_AVAILABLE


def test_snapshot_completed_session():
    store = ExperienceCaptureStore(make_config())
    store.start_session("s-snap-004")
    store.append_observation(make_observation(session_id="s-snap-004"))
    store.finalize_session()
    snap = store.get_session_snapshot()
    assert snap.session_status == SessionStatus.COMPLETED
