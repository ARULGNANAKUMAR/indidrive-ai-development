"""
Phase 12.1 — Tests: Thread Safety
Verifies that concurrent access to the capture store and adapter
does not cause data corruption or race conditions.
"""
import sys, os, time, threading
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))

import pytest
from exp121_helpers import make_config, make_observation, make_event

from core.experience.capture_store import ExperienceCaptureStore
from core.experience.pipeline_capture_adapter import PipelineCaptureAdapter
from core.experience.experience_types import ExperienceCaptureConfig


def test_concurrent_append_observations():
    """Multiple threads appending observations must not corrupt state."""
    cfg = make_config(max_obs=500, max_events=500)
    store = ExperienceCaptureStore(cfg)
    store.start_session("thread-obs-001")

    errors = []

    def worker(thread_id):
        for i in range(20):
            obs = make_observation(
                session_id="thread-obs-001",
                seq=thread_id * 100 + i,
            )
            try:
                store.append_observation(obs)
            except Exception as exc:
                errors.append(str(exc))

    threads = [threading.Thread(target=worker, args=(t,)) for t in range(5)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()

    assert not errors, f"Thread errors: {errors}"
    snap = store.get_session_snapshot()
    # Count must be within bounds
    assert snap.observation_count <= cfg.max_observations_per_session


def test_concurrent_append_events():
    """Multiple threads appending events must not corrupt state."""
    cfg = make_config(max_obs=500, max_events=500)
    store = ExperienceCaptureStore(cfg)
    store.start_session("thread-ev-001")

    errors = []

    def worker(thread_id):
        for i in range(20):
            ev = make_event(
                session_id="thread-ev-001",
                seq=thread_id * 100 + i,
            )
            try:
                store.append_event(ev)
            except Exception as exc:
                errors.append(str(exc))

    threads = [threading.Thread(target=worker, args=(t,)) for t in range(5)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()

    assert not errors, f"Thread errors: {errors}"
    snap = store.get_session_snapshot()
    assert snap.event_count <= cfg.max_events_per_session


def test_concurrent_snapshot_reads():
    """Multiple threads reading snapshots concurrently must not crash."""
    store = ExperienceCaptureStore(make_config())
    store.start_session("thread-snap-001")
    for i in range(10):
        store.append_observation(make_observation(session_id="thread-snap-001", seq=i))

    errors = []

    def reader():
        for _ in range(20):
            try:
                snap = store.get_session_snapshot()
                assert snap is not None
            except Exception as exc:
                errors.append(str(exc))

    threads = [threading.Thread(target=reader) for _ in range(4)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()

    assert not errors


def test_adapter_concurrent_observe():
    """Adapter observe() called concurrently must not crash."""
    adapter = PipelineCaptureAdapter()
    adapter.start_session("thread-adapt-001")

    errors = []

    def worker():
        for i in range(10):
            try:
                snap = adapter.observe(frame_id=i)
                assert snap is not None
            except Exception as exc:
                errors.append(str(exc))

    threads = [threading.Thread(target=worker) for _ in range(4)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()

    assert not errors


def test_snapshot_is_consistent_under_concurrent_writes():
    """Snapshot returned during concurrent writes is consistent (not partially-written)."""
    cfg = make_config(max_obs=500)
    store = ExperienceCaptureStore(cfg)
    store.start_session("thread-cons-001")

    done = threading.Event()
    snapshots = []

    def writer():
        for i in range(50):
            store.append_observation(
                make_observation(session_id="thread-cons-001", seq=i)
            )
        done.set()

    def reader():
        while not done.is_set():
            snap = store.get_session_snapshot()
            snapshots.append(snap.observation_count)

    wt = threading.Thread(target=writer)
    rt = threading.Thread(target=reader)
    wt.start(); rt.start()
    wt.join(); rt.join()

    # All sampled counts must be non-negative (no corruption)
    assert all(c >= 0 for c in snapshots)
