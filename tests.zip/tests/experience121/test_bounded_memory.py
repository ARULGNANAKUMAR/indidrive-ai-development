"""
Phase 12.1 — Tests: Bounded Memory and Retention Policy
"""
import sys, os, time
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))

import pytest
from exp121_helpers import make_config, make_observation, make_event

from core.experience.capture_store import ExperienceCaptureStore
from core.experience.experience_types import (
    CaptureEventType,
    ExperienceCaptureStatus,
    RetentionPolicy,
)


def test_observation_bound_enforced():
    """Store must not exceed max_observations_per_session."""
    cfg = make_config(max_obs=5, max_events=100)
    store = ExperienceCaptureStore(cfg)
    store.start_session("bound-001")
    for i in range(10):
        store.append_observation(make_observation(session_id="bound-001", seq=i))
    snap = store.get_session_snapshot()
    # Count must not exceed bound
    assert snap.observation_count <= 5


def test_event_bound_enforced():
    """Store must not exceed max_events_per_session."""
    cfg = make_config(max_obs=100, max_events=3)
    store = ExperienceCaptureStore(cfg)
    store.start_session("bound-002")
    for i in range(10):
        store.append_event(make_event(session_id="bound-002", seq=i))
    snap = store.get_session_snapshot()
    assert snap.event_count <= 3


def test_fifo_policy_drops_oldest():
    """BOUNDED_FIFO: when full, oldest observation is dropped."""
    cfg = make_config(max_obs=3, max_events=100, policy=RetentionPolicy.BOUNDED_FIFO)
    store = ExperienceCaptureStore(cfg)
    store.start_session("fifo-001")
    for i in range(5):
        obs = make_observation(session_id="fifo-001", seq=i)
        store.append_observation(obs)
    recent = store.get_recent_observations(n=10)
    assert len(recent) == 3
    # Most recent observations should be retained (higher sequence IDs)
    seq_ids = [o.sequence_id for o in recent]
    assert max(seq_ids) == 4  # last appended


def test_event_priority_policy_prefers_non_normal():
    """EVENT_PRIORITY: NORMAL_DRIVING events dropped before others."""
    cfg = make_config(
        max_obs=100,
        max_events=3,
        policy=RetentionPolicy.EVENT_PRIORITY,
    )
    store = ExperienceCaptureStore(cfg)
    store.start_session("evpri-001")
    # Fill with NORMAL_DRIVING
    for i in range(3):
        ev = make_event(session_id="evpri-001", seq=i,
                        event_type=CaptureEventType.NORMAL_DRIVING)
        store.append_event(ev)
    # Now add a HAZARD_DETECTED — should drop a NORMAL_DRIVING first
    ev_hazard = make_event(session_id="evpri-001", seq=3,
                           event_type=CaptureEventType.HAZARD_DETECTED)
    store.append_event(ev_hazard)
    recent = store.get_recent_events(n=10)
    types = [e.event_type for e in recent]
    assert CaptureEventType.HAZARD_DETECTED in types
    assert len(recent) <= 3


def test_overflow_status_set():
    """Status must reflect OVERFLOW when bounds are reached."""
    cfg = make_config(max_obs=2, max_events=100)
    store = ExperienceCaptureStore(cfg)
    store.start_session("ovf-001")
    for i in range(5):
        store.append_observation(make_observation(session_id="ovf-001", seq=i))
    # After overflow, status should be OVERFLOW (not FAILED)
    assert store.capture_status == ExperienceCaptureStatus.OVERFLOW


def test_no_silent_unbounded_growth():
    """After many appends, observation_count never exceeds configured bound."""
    cfg = make_config(max_obs=10, max_events=200)
    store = ExperienceCaptureStore(cfg)
    store.start_session("growth-001")
    for i in range(100):
        store.append_observation(make_observation(session_id="growth-001", seq=i))
    snap = store.get_session_snapshot()
    assert snap.observation_count <= 10


def test_disabled_capture_does_not_store():
    """When observation_capture_enabled=False, appends are no-ops."""
    cfg = ExperienceCaptureStore.__module__  # just check import worked
    from core.experience.experience_types import ExperienceCaptureConfig
    cfg = ExperienceCaptureConfig(observation_capture_enabled=False)
    store = ExperienceCaptureStore(cfg)
    store.start_session("disabled-001")
    obs = make_observation(session_id="disabled-001")
    ok = store.append_observation(obs)
    assert ok  # not a failure — just disabled
    snap = store.get_session_snapshot()
    assert snap.observation_count == 0
