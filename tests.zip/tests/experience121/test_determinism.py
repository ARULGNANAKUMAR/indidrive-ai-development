"""
Phase 12.1 — Tests: Determinism
"""
import sys, os, time
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))

import pytest
from exp121_helpers import make_config, make_world_model_stub, make_reasoning_stub

from core.experience.capture_engine import ExperienceCaptureEngine
from core.experience.capture_engine import _make_observation_id, _make_event_id


def test_observation_id_is_deterministic():
    """Same session_id + same seq → same observation ID, always."""
    id1 = _make_observation_id("session-001", 42)
    id2 = _make_observation_id("session-001", 42)
    assert id1 == id2 == "session-001-O000042"


def test_event_id_is_deterministic():
    id1 = _make_event_id("session-001", 7)
    id2 = _make_event_id("session-001", 7)
    assert id1 == id2 == "session-001-E000007"


def test_observation_ids_are_unique_within_session():
    engine = ExperienceCaptureEngine(make_config())
    engine.start_session("det-session")
    for _ in range(5):
        engine.capture_cycle(frame_id=0)
    snap = engine.get_snapshot()
    obs_ids = [o.experience_id for o in snap.recent_observations]
    assert len(obs_ids) == len(set(obs_ids)), "Observation IDs must be unique"


def test_event_ids_are_unique_within_session():
    engine = ExperienceCaptureEngine(make_config())
    engine.start_session("det-session-2")
    for _ in range(5):
        engine.capture_cycle(frame_id=0)
    snap = engine.get_snapshot()
    ev_ids = [e.event_id for e in snap.recent_events]
    assert len(ev_ids) == len(set(ev_ids)), "Event IDs must be unique"


def test_sequence_ids_are_monotonically_increasing():
    engine = ExperienceCaptureEngine(make_config())
    engine.start_session("mono-001")
    for _ in range(3):
        engine.capture_cycle(frame_id=0)
    snap = engine.get_snapshot()
    seqs = [o.sequence_id for o in snap.recent_observations]
    assert seqs == sorted(seqs)


def test_session_reset_restarts_sequence():
    engine = ExperienceCaptureEngine(make_config())
    engine.start_session("reset-001")
    engine.capture_cycle(frame_id=0)
    engine.capture_cycle(frame_id=1)
    engine.start_session("reset-002")  # new session resets counters
    engine.capture_cycle(frame_id=0)
    snap = engine.get_snapshot()
    if snap.recent_observations:
        # First observation in new session should have sequence_id=0
        assert snap.recent_observations[0].sequence_id == 0


def test_id_format_padded():
    """IDs use 6-digit zero-padded sequence numbers."""
    assert _make_observation_id("s", 0) == "s-O000000"
    assert _make_observation_id("s", 999999) == "s-O999999"
    assert _make_event_id("s", 1) == "s-E000001"
