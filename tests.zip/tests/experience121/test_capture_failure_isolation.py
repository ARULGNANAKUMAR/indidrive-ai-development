"""
Phase 12.1 — Tests: Failure Isolation
Verifies that capture failures NEVER crash or modify the autonomous pipeline.
"""
import sys, os, time
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))

import pytest

from core.experience.pipeline_capture_adapter import PipelineCaptureAdapter
from core.experience.capture_engine import ExperienceCaptureEngine
from core.experience.capture_store import ExperienceCaptureStore
from core.experience.experience_types import (
    ExperienceCaptureConfig,
    ExperienceCaptureStatus,
    SessionStatus,
)


def test_adapter_observe_never_raises_without_session():
    adapter = PipelineCaptureAdapter()
    # No session started — must not raise
    snap = adapter.observe(frame_id=0)
    assert snap is not None


def test_adapter_observe_with_none_inputs():
    adapter = PipelineCaptureAdapter()
    adapter.start_session("fail-001")
    # All inputs None — must not raise
    snap = adapter.observe(
        world_model_snapshot=None,
        reasoning_snapshot=None,
        planner_snapshot=None,
        pipeline_snapshot=None,
        control_snapshot=None,
        safety_state=None,
        failsafe_snapshot=None,
        supervisor_snapshot=None,
        frame_id=0,
    )
    assert snap is not None


def test_adapter_observe_with_garbage_inputs():
    """Adapter must not raise even with completely invalid inputs."""
    adapter = PipelineCaptureAdapter()
    adapter.start_session("fail-002")
    snap = adapter.observe(
        world_model_snapshot="not-a-snapshot",
        reasoning_snapshot=42,
        planner_snapshot=[1, 2, 3],
        frame_id=0,
    )
    # Must return a snapshot — not raise
    assert snap is not None


def test_adapter_capture_failed_does_not_propagate():
    """Capture failure status stays inside capture — does not modify pipeline state."""
    adapter = PipelineCaptureAdapter()
    adapter.start_session("fail-003")

    # Simulate by passing objects that will cause attribute errors inside extractor
    class _Broken:
        @property
        def objects(self):
            raise RuntimeError("simulated pipeline attribute error")

    snap = adapter.observe(world_model_snapshot=_Broken(), frame_id=0)
    # The adapter must survive and return a snapshot
    assert snap is not None
    # Even if capture failed, the adapter returns a snapshot object
    # (not an exception)


def test_store_failure_does_not_crash():
    """store._record_failure is internal — must not raise."""
    store = ExperienceCaptureStore(ExperienceCaptureConfig.default())
    store._record_failure("test internal failure")
    assert store.capture_status == ExperienceCaptureStatus.FAILED
    snap = store.get_session_snapshot()
    assert snap.capture_failed
    assert "test internal failure" in snap.failure_reason


def test_adapter_start_session_with_empty_id():
    adapter = PipelineCaptureAdapter()
    ok = adapter.start_session("")
    assert not ok  # must fail gracefully


def test_engine_no_session_capture_cycle():
    """Engine capture_cycle without active session must not crash."""
    engine = ExperienceCaptureEngine(ExperienceCaptureConfig.default())
    snap = engine.capture_cycle(frame_id=0)
    assert snap is not None


def test_adapter_get_snapshot_before_any_observe():
    adapter = PipelineCaptureAdapter()
    snap = adapter.get_snapshot()
    assert snap is not None


def test_capture_failure_does_not_set_planning_failed():
    """Verifies semantic isolation: capture failure ≠ planning failure."""
    adapter = PipelineCaptureAdapter()
    adapter.start_session("fail-004")
    # Inject a bad world model
    class _Bad:
        @property
        def status(self):
            raise ValueError("bad status")
        objects = ()
        road = None
        indian_context = None
    snap = adapter.observe(world_model_snapshot=_Bad(), frame_id=0)
    # Capture layer may record failure, but snapshot is returned (not raised)
    assert snap is not None
    # capture_failed may or may not be set — but the autonomous pipeline is unaffected


def test_multiple_bad_cycles_dont_accumulate_exceptions():
    adapter = PipelineCaptureAdapter()
    adapter.start_session("fail-005")
    for i in range(5):
        snap = adapter.observe(world_model_snapshot="garbage", frame_id=i)
        assert snap is not None
