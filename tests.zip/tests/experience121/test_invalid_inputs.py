"""
Phase 12.1 — Tests: Invalid Inputs and Upstream Failure Handling
"""
import sys, os, time
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))

import pytest
from exp121_helpers import make_config

from core.experience.capture_engine import ExperienceCaptureEngine
from core.experience.pipeline_capture_adapter import PipelineCaptureAdapter
from core.experience.capture_store import ExperienceCaptureStore
from core.experience.capture_validator import CaptureValidator
from core.experience.experience_types import (
    NOT_AVAILABLE,
    ExperienceCaptureConfig,
    SessionStatus,
)


def test_engine_none_world_model():
    engine = ExperienceCaptureEngine(make_config())
    engine.start_session("inv-001")
    snap = engine.capture_cycle(world_model_snapshot=None, frame_id=0)
    assert snap is not None


def test_engine_none_reasoning():
    engine = ExperienceCaptureEngine(make_config())
    engine.start_session("inv-002")
    snap = engine.capture_cycle(reasoning_snapshot=None, frame_id=0)
    assert snap is not None


def test_engine_none_planner():
    engine = ExperienceCaptureEngine(make_config())
    engine.start_session("inv-003")
    snap = engine.capture_cycle(planner_snapshot=None, frame_id=0)
    assert snap is not None


def test_engine_none_safety():
    engine = ExperienceCaptureEngine(make_config())
    engine.start_session("inv-004")
    snap = engine.capture_cycle(safety_state=None, frame_id=0)
    assert snap is not None


def test_engine_all_none_inputs():
    engine = ExperienceCaptureEngine(make_config())
    engine.start_session("inv-005")
    snap = engine.capture_cycle(
        world_model_snapshot=None,
        reasoning_snapshot=None,
        planner_snapshot=None,
        pipeline_snapshot=None,
        control_snapshot=None,
        safety_state=None,
        failsafe_snapshot=None,
        supervisor_snapshot=None,
        frame_id=0,
    )
    assert snap is not None


def test_engine_raises_on_wrong_config_type():
    with pytest.raises(TypeError):
        ExperienceCaptureEngine(None)

    with pytest.raises(TypeError):
        ExperienceCaptureEngine({"max_obs": 100})


def test_store_raises_on_wrong_config_type():
    with pytest.raises(TypeError):
        ExperienceCaptureStore(None)


def test_store_append_without_session():
    from exp121_helpers import make_observation
    store = ExperienceCaptureStore(make_config())
    obs = make_observation()
    ok = store.append_observation(obs)
    assert not ok


def test_store_append_event_without_session():
    from exp121_helpers import make_event
    store = ExperienceCaptureStore(make_config())
    ev = make_event()
    ok = store.append_event(ev)
    assert not ok


def test_engine_start_empty_session_id():
    engine = ExperienceCaptureEngine(make_config())
    ok = engine.start_session("")
    assert not ok


def test_engine_start_not_available_session_id():
    engine = ExperienceCaptureEngine(make_config())
    ok = engine.start_session(NOT_AVAILABLE)
    assert not ok


def test_adapter_bad_world_model_type():
    adapter = PipelineCaptureAdapter()
    adapter.start_session("inv-bad-wm")
    snap = adapter.observe(world_model_snapshot={"objects": "not-a-list"}, frame_id=0)
    assert snap is not None


def test_adapter_exception_in_observer_is_caught():
    class _AlwaysRaises:
        @property
        def objects(self):
            raise RuntimeError("catastrophic failure")

    adapter = PipelineCaptureAdapter()
    adapter.start_session("inv-exc-001")
    snap = adapter.observe(world_model_snapshot=_AlwaysRaises(), frame_id=0)
    assert snap is not None


def test_validator_none_session():
    v = CaptureValidator(make_config())
    ok, reason = v.validate_session(None)
    assert not ok


def test_validator_none_observation():
    v = CaptureValidator(make_config())
    ok, reason = v.validate_observation(None)
    assert not ok


def test_validator_none_event():
    v = CaptureValidator(make_config())
    ok, reason = v.validate_event(None)
    assert not ok


def test_engine_handles_broken_attribute_in_reasoning():
    class _BrokenReasoning:
        @property
        def situation(self):
            raise AttributeError("no situation")

    engine = ExperienceCaptureEngine(make_config())
    engine.start_session("inv-reason-001")
    snap = engine.capture_cycle(reasoning_snapshot=_BrokenReasoning(), frame_id=0)
    assert snap is not None
