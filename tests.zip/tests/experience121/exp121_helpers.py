"""
IndiDrive AI — Phase 12.1 | Test Helpers
=========================================
Shared builders and stubs for Phase 12.1 experience capture tests.
All helpers produce minimal valid objects without importing real pipeline modules.
"""
from __future__ import annotations

import sys
import os
import time

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))

from core.experience.experience_types import (
    NOT_AVAILABLE,
    EXPERIENCE_SCHEMA_VERSION,
    CaptureDataValidity,
    CaptureEvent,
    CaptureEventEvidence,
    CaptureEventType,
    ControlSummary,
    DrivingExperienceSession,
    EgoContextSummary,
    EnvironmentSummary,
    ExperienceCaptureConfig,
    ExperienceCaptureSnapshot,
    ExperienceCaptureStatus,
    ExperienceObservation,
    PlanningSummary,
    RetentionPolicy,
    SafetySummary,
    SessionStatus,
    SituationSummary,
)


# ---------------------------------------------------------------------------
# Config builders
# ---------------------------------------------------------------------------

def make_config(
    max_obs: int = 100,
    max_events: int = 50,
    window: int = 20,
    policy: RetentionPolicy = RetentionPolicy.BOUNDED_FIFO,
) -> ExperienceCaptureConfig:
    return ExperienceCaptureConfig(
        max_observations_per_session=max_obs,
        max_events_per_session=max_events,
        recent_window_observations=window,
        recent_window_events=window,
        retention_policy=policy,
    )


# ---------------------------------------------------------------------------
# Observation builders
# ---------------------------------------------------------------------------

def make_observation(
    session_id: str = "sess-001",
    seq: int = 0,
    timestamp: float = None,
    frame_id: int = 0,
    data_validity: CaptureDataValidity = CaptureDataValidity.VALID,
    hazard_level: str = "LOW",
) -> ExperienceObservation:
    ts = timestamp if timestamp is not None else time.time()
    obs_id = f"{session_id}-O{seq:06d}"
    sit = SituationSummary(
        situation_type="NORMAL_TRAFFIC",
        hazard_level=hazard_level,
        reasoning_confidence=0.8,
        reasoning_uncertainty=0.2,
    )
    return ExperienceObservation(
        experience_id=obs_id,
        session_id=session_id,
        sequence_id=seq,
        timestamp=ts,
        frame_id=frame_id,
        data_validity=data_validity,
        ego_context=EgoContextSummary(
            position_x=10.0,
            position_y=0.0,
            velocity_ms=8.0,
            yaw_rad=0.0,
            vehicle_state_validity="VALID",
        ),
        environment=EnvironmentSummary(
            nearby_object_count=2,
            world_model_validity="OK",
        ),
        situation=sit,
        planning=PlanningSummary(planning_mode="PLAN_AVAILABLE"),
        control=ControlSummary(control_status="VALID"),
        safety=SafetySummary(safety_state="SAFE", supervisor_authority="NORMAL_CONTROL"),
    )


# ---------------------------------------------------------------------------
# Event builders
# ---------------------------------------------------------------------------

def make_event(
    session_id: str = "sess-001",
    seq: int = 0,
    timestamp: float = None,
    frame_id: int = 0,
    event_type: CaptureEventType = CaptureEventType.NORMAL_DRIVING,
) -> CaptureEvent:
    ts = timestamp if timestamp is not None else time.time()
    ev_id = f"{session_id}-E{seq:06d}"
    evidence = CaptureEventEvidence(
        event_type=event_type,
        source_subsystem="test_helper",
        confidence=0.8,
        uncertainty=0.2,
        timestamp=ts,
        frame_id=frame_id,
    )
    return CaptureEvent(
        event_id=ev_id,
        session_id=session_id,
        sequence_id=seq,
        event_type=event_type,
        evidence=evidence,
        timestamp=ts,
        frame_id=frame_id,
        data_validity=CaptureDataValidity.VALID,
    )


# ---------------------------------------------------------------------------
# Minimal pipeline state stubs
# ---------------------------------------------------------------------------

class _Attr:
    """Simple attribute holder stub."""
    def __init__(self, **kwargs):
        for k, v in kwargs.items():
            setattr(self, k, v)


def make_world_model_stub(
    n_objects: int = 2,
    cattle: bool = False,
    vru: bool = False,
    status_value: str = "OK",
):
    """Minimal WorldModelSnapshot-like stub."""

    class _Pos:
        def __init__(self):
            self.x, self.y = 5.0, 1.0

    class _Vel:
        pass

    class _Coll:
        risk_level = "LOW"

    class _Motion:
        is_moving = True

    class _Qual:
        pass

    class _Obj:
        def __init__(self, i):
            self.object_id = f"obj-{i:03d}"
            self.track_id = None
            self.fused_id = None
            self.object_type = "CAR"
            self.object_subtype = "SEDAN"
            self.position = _Pos()
            self.velocity = _Vel()
            self.collision = _Coll()
            self.motion = _Motion()
            self.quality = _Qual()

        def primary_id(self):
            return self.object_id

    class _Lane:
        marking_state = "MARKED"
        intersection_state = "NORMAL_ROAD"

    class _Road:
        def __init__(self):
            self.lane_info = _Lane()
            self.anomalies = []

    class _Indian:
        road_type = "URBAN"
        traffic_density = "MEDIUM"
        traffic_mix = "MIXED"
        vulnerable_road_users = vru
        cattle_present = cattle
        context_confidence = 0.8
        context_uncertainty = 0.2

    class _Status:
        value = status_value

    class _WM:
        def __init__(self):
            self.objects = tuple(_Obj(i) for i in range(n_objects))
            self.road = _Road()
            self.indian_context = _Indian()
            self.status = _Status()
            self.data_quality = _Attr(overall_confidence=0.8)

    return _WM()


def make_reasoning_stub(
    situation_cat: str = "NORMAL_TRAFFIC",
    hazard_level: str = "LOW",
    confidence: float = 0.8,
    state: str = "NORMAL",
):
    class _Cat:
        def __init__(self, v):
            self.value = v

    class _Sit:
        def __init__(self):
            self.situation_category = _Cat(situation_cat)

    class _Hazards:
        top_hazards = []
        critical_hazards = 0

    class _Risk:
        def __init__(self):
            self.overall_risk_level = _Cat(hazard_level)
            self.collision_threat_present = False

    class _State:
        def __init__(self, v):
            self.value = v

    class _Uncertainty:
        overall_uncertainty = 0.2

    class _RS:
        def __init__(self):
            self.situation = _Sit()
            self.hazards = _Hazards()
            self.risk = _Risk()
            self.reasoning_state = _State(state)
            self.reasoning_confidence = confidence
            self.uncertainty_info = _Uncertainty()
            self.interactions = None

    return _RS()


def make_planner_stub(
    status: str = "PLAN_AVAILABLE",
    replanning: bool = False,
    risk_level: str = "LOW",
):
    class _Val:
        def __init__(self, v):
            self.value = v

    class _Candidates:
        generation_status = "VALID"
        candidate_count = 2
        valid_candidate_count = 2

    class _Risk:
        def __init__(self):
            self.overall_risk_level = _Val(risk_level)

    class _Replan:
        def __init__(self):
            self.replan_required = replanning
            self.trigger_reason = _Val("PATH_RISK") if replanning else None

    class _PS:
        def __init__(self):
            self.status = _Val(status)
            self.state = _Val("IDLE")
            self.candidates = _Candidates()
            self.risk = _Risk()
            self.replan = _Replan()

    return _PS()


def make_safety_stub(
    safety_state: str = "SAFE",
    authority: str = "NORMAL_CONTROL",
    failsafe: str = "NORMAL_OPERATION",
):
    class _Val:
        def __init__(self, v):
            self.value = v

    class _SS:
        def __init__(self):
            self.safety_state = _Val(safety_state)

    class _Sup:
        def __init__(self):
            self.control_authority = _Val(authority)

    class _FS:
        def __init__(self):
            self.decision = _Attr(failsafe_state=_Val(failsafe))
            self.active_sensor_failures = ()
            self.active_subsystem_failures = ()

    return _SS(), _Sup(), _FS()
