"""
Phase 12.1 — Tests: CaptureValidator
"""
import sys, os, time
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))

import pytest
from exp121_helpers import make_config, make_observation, make_event

from core.experience.capture_validator import CaptureValidator
from core.experience.experience_types import (
    EXPERIENCE_SCHEMA_VERSION,
    NOT_AVAILABLE,
    CaptureDataValidity,
    CaptureEvent,
    CaptureEventEvidence,
    CaptureEventType,
    DrivingExperienceSession,
    ExperienceCaptureConfig,
    ExperienceObservation,
    SessionStatus,
    SituationSummary,
)


def _validator():
    return CaptureValidator(make_config())


def test_valid_observation():
    v = _validator()
    obs = make_observation()
    ok, reason = v.validate_observation(obs)
    assert ok, reason


def test_valid_event():
    v = _validator()
    ev = make_event()
    ok, reason = v.validate_event(ev)
    assert ok, reason


def test_valid_session():
    v = _validator()
    s = DrivingExperienceSession(
        session_id="s-001",
        status=SessionStatus.ACTIVE,
        observation_count=5,
        event_count=2,
        start_timestamp=1000.0,
        last_timestamp=1010.0,
    )
    ok, reason = v.validate_session(s)
    assert ok, reason


def test_invalid_observation_none():
    v = _validator()
    ok, reason = v.validate_observation(None)
    assert not ok


def test_invalid_event_none():
    v = _validator()
    ok, reason = v.validate_event(None)
    assert not ok


def test_invalid_session_none():
    v = _validator()
    ok, reason = v.validate_session(None)
    assert not ok


def test_observation_wrong_schema():
    v = _validator()
    obs = make_observation()
    obs.schema_version = "99.9"
    ok, reason = v.validate_observation(obs)
    assert not ok
    assert "schema_version" in reason


def test_observation_missing_experience_id():
    v = _validator()
    obs = make_observation()
    obs.experience_id = NOT_AVAILABLE
    ok, reason = v.validate_observation(obs)
    assert not ok


def test_observation_negative_sequence_id():
    v = _validator()
    obs = make_observation()
    obs.sequence_id = -1
    ok, reason = v.validate_observation(obs)
    assert not ok


def test_observation_invalid_timestamp():
    v = _validator()
    obs = make_observation(timestamp=0.0)
    # timestamp 0 is technically valid (non-negative, finite)
    ok, reason = v.validate_observation(obs)
    assert ok  # 0.0 is valid


def test_observation_future_timestamp():
    v = _validator()
    obs = make_observation(timestamp=time.time() + 1000.0)
    ok, reason = v.validate_observation(obs)
    assert not ok
    assert "future" in reason


def test_observation_confidence_out_of_range():
    v = _validator()
    obs = make_observation()
    obs.situation = SituationSummary(reasoning_confidence=1.5, reasoning_uncertainty=0.5)
    ok, reason = v.validate_observation(obs)
    assert not ok
    assert "reasoning_confidence" in reason


def test_observation_uncertainty_out_of_range():
    v = _validator()
    obs = make_observation()
    obs.situation = SituationSummary(reasoning_confidence=0.5, reasoning_uncertainty=-0.1)
    ok, reason = v.validate_observation(obs)
    assert not ok


def test_event_wrong_schema():
    v = _validator()
    ev = make_event()
    ev.schema_version = "99.9"
    ok, reason = v.validate_event(ev)
    assert not ok


def test_event_missing_event_id():
    v = _validator()
    ev = make_event()
    ev.event_id = NOT_AVAILABLE
    ok, reason = v.validate_event(ev)
    assert not ok


def test_event_confidence_out_of_range():
    v = _validator()
    ev = make_event()
    ev.evidence.confidence = 2.0
    ok, reason = v.validate_event(ev)
    assert not ok


def test_session_counts_exceed_max():
    cfg = make_config(max_obs=10, max_events=5)
    v = CaptureValidator(cfg)
    s = DrivingExperienceSession(
        session_id="s-002",
        status=SessionStatus.ACTIVE,
        observation_count=20,  # exceeds max=10
        event_count=2,
        start_timestamp=1000.0,
        last_timestamp=1010.0,
    )
    ok, reason = v.validate_session(s)
    assert not ok
    assert "observation_count" in reason


def test_session_invalid_timestamp_ordering():
    v = _validator()
    s = DrivingExperienceSession(
        session_id="s-003",
        status=SessionStatus.ACTIVE,
        start_timestamp=1010.0,
        last_timestamp=900.0,  # before start
    )
    ok, reason = v.validate_session(s)
    assert not ok
    assert "last_timestamp" in reason


def test_observation_id_prefix_mismatch():
    v = _validator()
    obs = make_observation(session_id="sess-X", seq=0)
    obs.session_id = "sess-Y"  # mismatch
    ok, reason = v.validate_observation(obs)
    assert not ok
    assert "experience_id" in reason
