"""Phase 9.3 Tests — closest approach risk component."""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "../.."))

from core.planning.path_risk_engine import _compute_closest_approach_risk
from core.planning.path_risk_config import PathRiskConfig
from core.planning.path_risk_types import RiskReasonCode


def test_large_separation_low_risk():
    cfg = PathRiskConfig()
    risk, codes = _compute_closest_approach_risk(15.0, cfg)
    assert risk < 0.15, f"Expected low risk for 15m separation, got {risk}"


def test_small_separation_high_risk():
    cfg = PathRiskConfig()
    risk, codes = _compute_closest_approach_risk(0.3, cfg)
    assert risk > 0.7
    assert RiskReasonCode.CLOSE_APPROACH in codes


def test_moderate_separation_moderate_risk():
    cfg = PathRiskConfig()
    risk_far, _ = _compute_closest_approach_risk(10.0, cfg)
    risk_near, _ = _compute_closest_approach_risk(1.0, cfg)
    assert risk_far < risk_near


def test_none_distance_no_crash():
    cfg = PathRiskConfig()
    risk, codes = _compute_closest_approach_risk(None, cfg)
    assert risk == 0.0


def test_zero_distance_high_risk():
    cfg = PathRiskConfig()
    risk, codes = _compute_closest_approach_risk(0.0, cfg)
    assert risk >= 0.9
