"""Phase 9.3 Tests — validation (Test 20 from spec)."""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "../.."))

from core.planning.path_risk_types import (
    CandidatePathRisk, PathRiskSet, PathRiskStatus,
    RiskLevel, RiskReasonCode, NOT_AVAILABLE,
)
from core.planning.path_risk_validator import (
    PathRiskValidator, PathRiskValidationResult,
)


def _validator():
    return PathRiskValidator()


def test_valid_risk_passes():
    validator = _validator()
    risk = CandidatePathRisk(
        candidate_id="P1",
        frame_id=1,
        coordinate_frame="VEHICLE",
        total_risk=0.45,
        risk_level=RiskLevel.MODERATE_RISK,
        confidence=0.8,
        uncertainty=0.2,
    )
    result = validator.validate_risk(risk)
    assert result.is_valid, f"Expected valid, errors: {result.errors}"


def test_missing_candidate_id_fails():
    validator = _validator()
    risk = CandidatePathRisk(candidate_id=NOT_AVAILABLE)
    result = validator.validate_risk(risk)
    assert not result.is_valid
    assert any("candidate_id" in e for e in result.errors)


def test_risk_out_of_range_fails():
    """Test 20 (spec): invalid risk range → validation failure."""
    validator = _validator()
    risk = CandidatePathRisk(candidate_id="P_BAD", total_risk=1.5)
    result = validator.validate_risk(risk)
    assert not result.is_valid
    assert any("total_risk" in e for e in result.errors)


def test_negative_risk_fails():
    validator = _validator()
    risk = CandidatePathRisk(candidate_id="P_NEG", total_risk=-0.1)
    result = validator.validate_risk(risk)
    assert not result.is_valid


def test_wrong_coordinate_frame_fails():
    validator = _validator()
    risk = CandidatePathRisk(candidate_id="P_FRAME", coordinate_frame="WORLD")
    result = validator.validate_risk(risk)
    assert not result.is_valid
    assert any("coordinate_frame" in e for e in result.errors)


def test_confidence_out_of_range_fails():
    validator = _validator()
    risk = CandidatePathRisk(candidate_id="P_CONF", confidence=1.5)
    result = validator.validate_risk(risk)
    assert not result.is_valid


def test_no_forbidden_fields():
    """Forbidden fields must never appear in output."""
    validator = _validator()
    risk = CandidatePathRisk(candidate_id="P_GOOD",
                             total_risk=0.3, risk_level=RiskLevel.LOW_RISK)
    for ff in validator.FORBIDDEN_FIELDS:
        assert not hasattr(risk, ff), f"Forbidden field '{ff}' found"


def test_valid_risk_set_passes():
    validator = _validator()
    r = CandidatePathRisk(
        candidate_id="PS1",
        frame_id=1,
        coordinate_frame="VEHICLE",
        total_risk=0.3,
        risk_level=RiskLevel.LOW_RISK,
        confidence=0.8,
        uncertainty=0.2,
    )
    risk_set = PathRiskSet(
        set_id="SET_V",
        frame_id=1,
        coordinate_frame="VEHICLE",
        status=PathRiskStatus.EVALUATED,
        _risks=(r,),
    )
    result = validator.validate_risk_set(risk_set)
    assert result.is_valid, f"Errors: {result.errors}"


def test_engine_output_passes_validation():
    """End-to-end: engine output passes validator."""
    from core.planning.path_risk_engine import PathRiskEngine
    from tests.planning93.helpers_93 import (
        make_candidate, FakeWorldObject, FakeWorldModelSnapshot,
    )
    engine = PathRiskEngine()
    validator = PathRiskValidator()

    candidates = [
        make_candidate("VLD_P1"),
        make_candidate("VLD_P2", lateral_offset_m=0.75),
    ]
    obj = FakeWorldObject("VLD_OBJ", "CAR", x=10.0, y=0.3,
                          ttc_s=2.0, ttc_status="FINITE", collision_likelihood=0.4)
    wm = FakeWorldModelSnapshot(objects=[obj])

    result_set = engine.evaluate(candidates, wm, frame_id=20, set_id="VSET")
    validation = validator.validate_risk_set(result_set)

    assert validation.is_valid, (
        f"Engine output failed validation:\n"
        f"Errors: {validation.errors}\n"
        f"Warnings: {validation.warnings}"
    )
