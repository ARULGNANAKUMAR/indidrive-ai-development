"""Phase 9.3 Tests — uncertainty risk component."""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "../.."))

from core.planning.path_risk_engine import _compute_uncertainty_risk
from core.planning.path_risk_config import PathRiskConfig
from core.planning.path_risk_types import RiskReasonCode


def test_high_confidence_low_uncertainty_risk():
    cfg = PathRiskConfig()
    risk, codes = _compute_uncertainty_risk(0.95, is_stale=False, is_degraded=False, cfg=cfg)
    assert risk < 0.1


def test_low_confidence_higher_uncertainty_risk():
    cfg = PathRiskConfig()
    risk_hi_conf, _ = _compute_uncertainty_risk(0.9, False, False, cfg)
    risk_lo_conf, _ = _compute_uncertainty_risk(0.1, False, False, cfg)
    assert risk_lo_conf > risk_hi_conf


def test_stale_data_flagged():
    cfg = PathRiskConfig()
    _, codes = _compute_uncertainty_risk(0.5, is_stale=True, is_degraded=False, cfg=cfg)
    assert RiskReasonCode.STALE_PREDICTION in codes


def test_degraded_flagged():
    cfg = PathRiskConfig()
    _, codes = _compute_uncertainty_risk(0.5, is_stale=False, is_degraded=True, cfg=cfg)
    assert RiskReasonCode.DEGRADED_SENSOR_INPUT in codes


def test_high_uncertainty_test18():
    """Test 18 (spec): high uncertainty → uncertainty represented separately."""
    cfg = PathRiskConfig()
    from core.planning.path_risk_engine import PathRiskEngine
    from tests.planning93.helpers_93 import (
        make_candidate, FakeWorldObject, FakeWorldModelSnapshot,
    )
    engine = PathRiskEngine()
    candidate = make_candidate("PATH_UNC")
    obj = FakeWorldObject(
        "OBJ_UNC", "CAR",
        x=10.0, y=0.0,
        prediction_confidence=0.05,  # very low confidence
        is_degraded=True,
        ttc_status="UNKNOWN",
    )
    wm = FakeWorldModelSnapshot(objects=[obj])
    result = engine.evaluate([candidate], wm, frame_id=18)
    risk = result.risks[0]

    # Uncertainty must be represented as a separate field, not just total_risk
    assert risk.breakdown.uncertainty_risk > 0.0
    # uncertainty field must be populated
    assert 0.0 <= risk.uncertainty <= 1.0
    # total_risk must still be in [0, 1]
    assert 0.0 <= risk.total_risk <= 1.0
