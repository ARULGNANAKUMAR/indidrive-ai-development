"""
Phase 9.3 Tests — PathRiskEngine core behaviour
Tests 1–6 from the spec (basic scenarios).
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "../.."))

from core.planning.path_risk_engine import PathRiskEngine
from core.planning.path_risk_config import PathRiskConfig
from core.planning.path_risk_types import (
    RiskLevel, PathRiskStatus, NOT_AVAILABLE,
)
from tests.planning93.helpers_93 import (
    make_candidate, FakeWorldObject, FakeWorldModelSnapshot, FakePlanningContext,
)


def _engine():
    return PathRiskEngine()


# ------------------------------------------------------------------
# Test 1: No dynamic objects → valid output, no crash, low risk
# ------------------------------------------------------------------

def test_no_dynamic_objects():
    """Test 1 (spec): no objects → valid output, low/neutral risk."""
    engine = _engine()
    candidate = make_candidate("PATH_01")
    wm = FakeWorldModelSnapshot(objects=[], confidence=0.8)
    ctx = FakePlanningContext()

    result = engine.evaluate([candidate], wm, ctx, frame_id=1, set_id="SET_1")

    assert result.status in (PathRiskStatus.EVALUATED, PathRiskStatus.DEGRADED)
    assert result.risk_count == 1
    risk = result.risks[0]
    assert risk.candidate_id == "PATH_01"
    assert 0.0 <= risk.total_risk <= 1.0
    assert risk.dynamic_object_count == 0
    # Risk should be low with no objects
    assert risk.total_risk < 0.4, f"Expected low risk with no objects, got {risk.total_risk}"


# ------------------------------------------------------------------
# Test 2: Object far from path → low spatial risk
# ------------------------------------------------------------------

def test_object_far_from_path():
    """Test 2 (spec): object far away → low clearance risk."""
    engine = _engine()
    candidate = make_candidate("PATH_02", lateral_offset_m=0.0)
    obj = FakeWorldObject("OBJ_FAR", "CAR", x=50.0, y=8.0, ttc_status="NO_COLLISION")
    wm = FakeWorldModelSnapshot(objects=[obj])

    result = engine.evaluate([candidate], wm, frame_id=2)
    risk = result.risks[0]

    assert risk.total_risk < 0.35, f"Expected low risk for far object, got {risk.total_risk}"


# ------------------------------------------------------------------
# Test 3: Object directly on candidate path → high risk
# ------------------------------------------------------------------

def test_object_on_path():
    """Test 3 (spec): object on path → high risk contribution."""
    engine = _engine()
    candidate = make_candidate("PATH_03", lateral_offset_m=0.0)
    # Object directly on path centerline, close
    obj = FakeWorldObject(
        "OBJ_ON", "CAR",
        x=10.0, y=0.0,
        ttc_s=1.0, ttc_status="FINITE",
        min_distance_m=0.2,
        collision_likelihood=0.85,
        risk_level="CRITICAL",
    )
    wm = FakeWorldModelSnapshot(objects=[obj])

    result = engine.evaluate([candidate], wm, frame_id=3)
    risk = result.risks[0]

    assert risk.total_risk > 0.55, f"Expected high risk for object on path, got {risk.total_risk}"


# ------------------------------------------------------------------
# Test 4: Object crossing path → temporal/intersection risk
# ------------------------------------------------------------------

def test_object_crossing_path():
    """Test 4 (spec): crossing object → temporal/intersection risk detected."""
    engine = _engine()
    candidate = make_candidate("PATH_04", lateral_offset_m=0.0)
    # Object moving laterally across the path
    traj = [(10.0 + 1.0*t, 4.0 - 2.0*t, 0.0, float(t)) for t in range(5)]
    obj = FakeWorldObject(
        "OBJ_CROSS", "CAR",
        x=10.0, y=4.0, vx=0.0, vy=-3.0,
        ttc_status="FINITE", ttc_s=2.0,
        min_distance_m=1.0,
        collision_likelihood=0.5,
        trajectory=traj,
    )
    wm = FakeWorldModelSnapshot(objects=[obj])

    result = engine.evaluate([candidate], wm, frame_id=4)
    risk = result.risks[0]

    assert risk.total_risk > 0.2
    # Some temporal or intersection reason code should be present
    rc_values = [rc.value for rc in risk.reason_codes]
    has_dynamic = any(
        "TRAJECTORY" in rc or "CROSSING" in rc or "APPROACHING" in rc or "TEMPORAL" in rc
        for rc in rc_values
    )
    assert has_dynamic, f"Expected dynamic reason code, got {rc_values}"


# ------------------------------------------------------------------
# Test 5: Object moving away → risk differs from approaching
# ------------------------------------------------------------------

def test_object_moving_away_vs_approaching():
    """Test 5 (spec): receding object has lower risk than approaching object."""
    engine = _engine()
    candidate = make_candidate("PATH_05")

    # Approaching
    obj_approaching = FakeWorldObject(
        "OBJ_APPROACH", "CAR",
        x=12.0, y=0.5, vx=-4.0, vy=0.0,   # moving toward origin = approaching path
        ttc_s=3.0, ttc_status="FINITE",
        min_distance_m=3.0, collision_likelihood=0.4,
    )
    wm_approach = FakeWorldModelSnapshot(objects=[obj_approaching])
    result_a = engine.evaluate([candidate], wm_approach, frame_id=5)
    risk_a = result_a.risks[0].total_risk

    # Receding (same position, but moving away in +X)
    obj_receding = FakeWorldObject(
        "OBJ_RECEDE", "CAR",
        x=12.0, y=0.5, vx=10.0, vy=0.0,   # moving away fast
        ttc_status="NO_COLLISION", ttc_s=None,
        min_distance_m=8.0, collision_likelihood=0.0,
    )
    wm_recede = FakeWorldModelSnapshot(objects=[obj_receding])
    result_r = engine.evaluate([candidate], wm_recede, frame_id=5)
    risk_r = result_r.risks[0].total_risk

    assert risk_a >= risk_r, (
        f"Approaching object should have >= risk than receding: "
        f"approaching={risk_a:.3f}, receding={risk_r:.3f}"
    )


# ------------------------------------------------------------------
# Test 6: Low TTC → increased TTC risk
# ------------------------------------------------------------------

def test_low_ttc_increases_risk():
    """Test 6 (spec): low TTC → high TTC risk contribution."""
    engine = _engine()
    candidate = make_candidate("PATH_06")

    obj_low_ttc = FakeWorldObject(
        "OBJ_LOW_TTC", "CAR",
        x=8.0, y=0.0,
        ttc_s=0.8, ttc_status="FINITE",
        min_distance_m=2.0, collision_likelihood=0.7,
    )
    wm = FakeWorldModelSnapshot(objects=[obj_low_ttc])
    result = engine.evaluate([candidate], wm, frame_id=6)
    risk = result.risks[0]

    assert risk.breakdown.ttc_risk > 0.5, (
        f"Expected high TTC risk for TTC=0.8s, got {risk.breakdown.ttc_risk}"
    )
    assert risk.total_risk > 0.3


# ------------------------------------------------------------------
# Test 7: High TTC → lower TTC contribution
# ------------------------------------------------------------------

def test_high_ttc_lower_risk():
    """Test 7 (spec): high TTC → lower TTC contribution."""
    engine = _engine()
    candidate = make_candidate("PATH_07")

    obj_high_ttc = FakeWorldObject(
        "OBJ_HIGH_TTC", "CAR",
        x=50.0, y=0.0,
        ttc_s=15.0, ttc_status="FINITE",
        min_distance_m=10.0, collision_likelihood=0.05,
    )
    wm = FakeWorldModelSnapshot(objects=[obj_high_ttc])
    result = engine.evaluate([candidate], wm, frame_id=7)
    risk = result.risks[0]

    assert risk.breakdown.ttc_risk < 0.15, (
        f"Expected low TTC risk for TTC=15s, got {risk.breakdown.ttc_risk}"
    )


# ------------------------------------------------------------------
# Planning not allowed → PLANNING_RESTRICTED status
# ------------------------------------------------------------------

def test_planning_not_allowed():
    """Phase 8.4 planning_allowed=False → PLANNING_RESTRICTED, no evaluation."""
    engine = _engine()
    candidate = make_candidate("PATH_NOPE")
    wm = FakeWorldModelSnapshot()
    ctx = FakePlanningContext(planning_allowed=False)

    result = engine.evaluate([candidate], wm, ctx, frame_id=99)

    assert result.status == PathRiskStatus.PLANNING_RESTRICTED
    assert result.risk_count == 0


# ------------------------------------------------------------------
# No candidates → NO_CANDIDATES status
# ------------------------------------------------------------------

def test_no_candidates():
    engine = _engine()
    wm = FakeWorldModelSnapshot()
    result = engine.evaluate([], wm, frame_id=10)
    assert result.status == PathRiskStatus.NO_CANDIDATES
    assert result.risk_count == 0


# ------------------------------------------------------------------
# Multiple candidates — one risk per candidate
# ------------------------------------------------------------------

def test_multiple_candidates_one_risk_each():
    engine = _engine()
    candidates = [
        make_candidate("PATH_A", lateral_offset_m=0.0),
        make_candidate("PATH_B", lateral_offset_m=0.75),
        make_candidate("PATH_C", lateral_offset_m=-0.75),
    ]
    wm = FakeWorldModelSnapshot()
    result = engine.evaluate(candidates, wm, frame_id=11)

    assert result.risk_count == 3
    ids = {r.candidate_id for r in result.risks}
    assert ids == {"PATH_A", "PATH_B", "PATH_C"}


# ------------------------------------------------------------------
# No selected/best path in output
# ------------------------------------------------------------------

def test_no_best_path_in_output():
    """Phase 9.3 must never expose a selected/best path."""
    engine = _engine()
    candidates = [make_candidate("P1"), make_candidate("P2")]
    wm = FakeWorldModelSnapshot()
    result = engine.evaluate(candidates, wm, frame_id=12)

    # Set-level check
    for ff in ["selected_path", "best_path", "optimal_path", "winner"]:
        assert not hasattr(result, ff), f"Forbidden field '{ff}' on PathRiskSet"

    # Per-risk check
    for r in result.risks:
        for ff in ["selected_path", "best_path", "optimal_path"]:
            assert not hasattr(r, ff), f"Forbidden field '{ff}' on CandidatePathRisk"


# ------------------------------------------------------------------
# World model None → degraded but not crash
# ------------------------------------------------------------------

def test_world_model_none_does_not_crash():
    engine = _engine()
    candidate = make_candidate("PATH_NONE_WM")
    result = engine.evaluate([candidate], world_model_snapshot=None, frame_id=99)
    assert result.risk_count == 1
    risk = result.risks[0]
    assert risk.degraded is True
    assert 0.0 <= risk.total_risk <= 1.0
