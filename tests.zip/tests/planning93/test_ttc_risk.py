"""Phase 9.3 Tests — TTC risk component."""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "../.."))

from core.planning.path_risk_engine import _compute_ttc_risk
from core.planning.path_risk_config import PathRiskConfig
from core.planning.path_risk_types import RiskReasonCode


def test_low_ttc_high_risk():
    cfg = PathRiskConfig()
    risk, codes = _compute_ttc_risk(0.5, "FINITE", 0.0, cfg)
    assert risk >= 0.9
    assert RiskReasonCode.LOW_TTC in codes


def test_high_ttc_low_risk():
    cfg = PathRiskConfig()
    risk, codes = _compute_ttc_risk(20.0, "FINITE", 0.0, cfg)
    assert risk < 0.1


def test_no_collision_zero_risk():
    cfg = PathRiskConfig()
    risk, codes = _compute_ttc_risk(None, "NO_COLLISION", 0.0, cfg)
    assert risk == 0.0


def test_unknown_ttc_fallback():
    """Unknown TTC must NOT return zero risk."""
    cfg = PathRiskConfig()
    risk, codes = _compute_ttc_risk(None, "UNKNOWN", 0.0, cfg)
    assert risk > 0.0
    assert risk == cfg.ttc_unavailable_near_fallback


def test_missing_ttc_fallback():
    """None TTC with NOT_AVAILABLE status must not crash."""
    cfg = PathRiskConfig()
    risk, codes = _compute_ttc_risk(None, "NOT_AVAILABLE", 0.0, cfg)
    assert 0.0 <= risk <= 1.0


def test_stale_data_flagged():
    cfg = PathRiskConfig()
    _, codes = _compute_ttc_risk(5.0, "FINITE", data_age_s=3.0, cfg=cfg)
    assert RiskReasonCode.STALE_PREDICTION in codes


def test_infinite_ttc_not_crash():
    cfg = PathRiskConfig()
    import math
    risk, _ = _compute_ttc_risk(math.inf, "FINITE", 0.0, cfg)
    assert 0.0 <= risk <= 1.0
