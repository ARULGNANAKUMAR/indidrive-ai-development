"""Phase 9.3 Tests — degraded inputs (Tests 16–17 from spec)."""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "../.."))

from core.planning.path_risk_engine import PathRiskEngine
from core.planning.path_risk_types import RiskReasonCode, PathRiskStatus
from tests.planning93.helpers_93 import (
    make_candidate, FakeWorldObject, FakeWorldModelSnapshot,
)


def _engine():
    return PathRiskEngine()


def test_missing_ttc_graceful():
    """Test 16 (spec): missing TTC → graceful handling, no crash."""
    engine = _engine()
    candidate = make_candidate("PATH_NOTTC")

    obj = FakeWorldObject(
        "OBJ_NOTTC", "CAR",
        x=10.0, y=0.5,
        ttc_s=None,
        ttc_status="UNKNOWN",
    )
    wm = FakeWorldModelSnapshot(objects=[obj])
    result = engine.evaluate([candidate], wm, frame_id=16)

    assert not result.status == PathRiskStatus.ERROR
    assert result.risk_count == 1
    risk = result.risks[0]
    assert 0.0 <= risk.total_risk <= 1.0
    # Should not silently produce zero risk for missing TTC
    # (unavailability != no risk)
    # At least uncertain object motion should appear
    rc_vals = [rc.value for rc in risk.reason_codes]
    has_uncertainty = any(
        "UNCERTAIN" in rv or "STALE" in rv for rv in rc_vals
    )
    assert has_uncertainty or risk.breakdown.ttc_risk > 0.0, (
        f"Missing TTC should produce some uncertainty signal. codes={rc_vals}"
    )


def test_missing_trajectory_graceful():
    """Test 17 (spec): missing trajectory → graceful handling, no crash."""
    engine = _engine()
    candidate = make_candidate("PATH_NOTRAJ")

    obj = FakeWorldObject(
        "OBJ_NOTRAJ", "CAR",
        x=10.0, y=0.5,
        trajectory=None,
        prediction_confidence=0.0,
    )
    wm = FakeWorldModelSnapshot(objects=[obj])
    result = engine.evaluate([candidate], wm, frame_id=17)

    assert result.risk_count == 1
    risk = result.risks[0]
    assert 0.0 <= risk.total_risk <= 1.0


def test_nan_position_no_crash():
    """Object with NaN position must not crash or produce NaN risk."""
    import math
    engine = _engine()
    candidate = make_candidate("PATH_NAN")

    obj = FakeWorldObject("NAN_OBJ", "CAR", x=float("nan"), y=float("nan"))
    wm = FakeWorldModelSnapshot(objects=[obj])
    result = engine.evaluate([candidate], wm, frame_id=70)

    risk = result.risks[0]
    assert math.isfinite(risk.total_risk)


def test_empty_waypoints_candidate_no_crash():
    """Candidate with zero waypoints must not crash."""
    engine = _engine()
    candidate = make_candidate("PATH_EMPTY", n_waypoints=0)
    wm = FakeWorldModelSnapshot()
    result = engine.evaluate([candidate], wm, frame_id=71)
    assert result.risk_count == 1
    assert 0.0 <= result.risks[0].total_risk <= 1.0


def test_degraded_world_model_degraded_flag():
    """Partial world model → degraded flag on risk output."""
    engine = _engine()
    candidate = make_candidate("PATH_DEG")
    wm = FakeWorldModelSnapshot(is_partial=True, confidence=0.3)
    result = engine.evaluate([candidate], wm, frame_id=72)
    risk = result.risks[0]
    # degraded flag should reflect the WM state
    assert isinstance(risk.degraded, bool)


def test_geometrically_invalid_candidate():
    """Geometrically invalid candidate → CRITICAL_RISK, not just high risk."""
    engine = _engine()
    candidate = make_candidate("PATH_INVALID", geometric_valid=False)
    wm = FakeWorldModelSnapshot()
    result = engine.evaluate([candidate], wm, frame_id=73)
    risk = result.risks[0]

    assert risk.is_geometrically_invalid is True
    assert risk.total_risk == 1.0
    from core.planning.path_risk_types import RiskLevel
    assert risk.risk_level == RiskLevel.CRITICAL_RISK
