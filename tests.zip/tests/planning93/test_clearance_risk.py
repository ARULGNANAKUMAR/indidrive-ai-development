"""Phase 9.3 Tests — clearance risk component."""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "../.."))

from core.planning.path_risk_engine import _compute_clearance_risk
from core.planning.path_risk_config import PathRiskConfig
from tests.planning93.helpers_93 import make_candidate


def test_clearance_far_object_low_risk():
    cfg = PathRiskConfig()
    path = make_candidate("PATH_CLR", lateral_offset_m=0.0)
    risk = _compute_clearance_risk(path, obj_x=20.0, obj_y=10.0, obj_half_width=0.9, cfg=cfg)
    assert risk < 0.2, f"Expected low clearance risk for distant object, got {risk}"


def test_clearance_very_close_object_high_risk():
    cfg = PathRiskConfig()
    path = make_candidate("PATH_CLR2", lateral_offset_m=0.0)
    # Object directly on path, nearly touching
    risk = _compute_clearance_risk(path, obj_x=5.0, obj_y=0.0, obj_half_width=0.9, cfg=cfg)
    assert risk > 0.7, f"Expected high clearance risk for near object, got {risk}"


def test_clearance_missing_position():
    cfg = PathRiskConfig()
    path = make_candidate("PATH_CLR3")
    risk = _compute_clearance_risk(path, obj_x=None, obj_y=None, obj_half_width=0.9, cfg=cfg)
    assert risk == 0.0


def test_clearance_monotone():
    """Closer objects produce >= risk than farther ones."""
    cfg = PathRiskConfig()
    path = make_candidate("PATH_CLR4", lateral_offset_m=0.0)
    r_far = _compute_clearance_risk(path, obj_x=5.0, obj_y=8.0, obj_half_width=0.9, cfg=cfg)
    r_mid = _compute_clearance_risk(path, obj_x=5.0, obj_y=3.0, obj_half_width=0.9, cfg=cfg)
    r_near = _compute_clearance_risk(path, obj_x=5.0, obj_y=0.5, obj_half_width=0.9, cfg=cfg)
    assert r_far <= r_mid <= r_near, f"{r_far} <= {r_mid} <= {r_near}"
