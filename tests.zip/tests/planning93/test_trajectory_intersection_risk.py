"""Phase 9.3 Tests — trajectory intersection risk component."""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "../.."))

from core.planning.path_risk_engine import _compute_trajectory_intersection_risk
from core.planning.path_risk_config import PathRiskConfig
from core.planning.path_risk_types import RiskReasonCode
from tests.planning93.helpers_93 import make_candidate


def test_empty_trajectory_no_crash():
    cfg = PathRiskConfig()
    path = make_candidate("PATH_TRAJ1")
    risk, codes = _compute_trajectory_intersection_risk(path, [], cfg)
    assert 0.0 <= risk <= 1.0


def test_trajectory_far_from_path_low_risk():
    """Trajectory that stays far from path → low intersection risk."""
    cfg = PathRiskConfig()
    path = make_candidate("PATH_TRAJ2", lateral_offset_m=0.0)
    # Trajectory at y=10 — far from path center (y=0)
    traj = [(float(i)*2, 10.0, 0.0, float(i)) for i in range(5)]
    risk, codes = _compute_trajectory_intersection_risk(path, traj, cfg)
    assert risk < 0.35, f"Expected low intersection risk for far trajectory, got {risk}"


def test_trajectory_crossing_path_high_risk():
    """Trajectory crossing from y=4 to y=-4 → intersection detected."""
    cfg = PathRiskConfig()
    path = make_candidate("PATH_TRAJ3", lateral_offset_m=0.0)
    # Trajectory sweeping across path at x=10
    traj = [(10.0, 4.0 - 2.0*t, 0.0, float(t)) for t in range(5)]
    risk, codes = _compute_trajectory_intersection_risk(path, traj, cfg)
    assert risk > 0.3, f"Expected higher risk for crossing trajectory, got {risk}"


def test_trajectory_intersection_reason_code():
    """Intersection detection → TRAJECTORY_INTERSECTION reason code."""
    cfg = PathRiskConfig()
    path = make_candidate("PATH_TRAJ4", lateral_offset_m=0.0)
    # Object trajectory goes through path at close range
    traj = [(8.0, 0.5, 0.0, 1.0), (10.0, 0.0, 0.0, 2.0), (12.0, -0.5, 0.0, 3.0)]
    risk, codes = _compute_trajectory_intersection_risk(path, traj, cfg)
    # If intersection is detected codes should include TRAJECTORY_INTERSECTION
    if risk > 0.5:
        assert RiskReasonCode.TRAJECTORY_INTERSECTION in codes


def test_trajectory_with_bad_values_no_crash():
    """Malformed trajectory points must not crash."""
    cfg = PathRiskConfig()
    path = make_candidate("PATH_TRAJ5")
    bad_traj = [(None, None, None, None), (float("nan"), 0.0, 0.0, 1.0), "not_a_point"]
    risk, codes = _compute_trajectory_intersection_risk(path, bad_traj, cfg)
    assert 0.0 <= risk <= 1.0
