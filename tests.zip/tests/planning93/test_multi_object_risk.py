"""Phase 9.3 Tests — multiple objects (Test 11 from spec)."""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "../.."))

from core.planning.path_risk_engine import PathRiskEngine
from core.planning.path_risk_types import RiskReasonCode
from tests.planning93.helpers_93 import (
    make_candidate, FakeWorldObject, FakeWorldModelSnapshot,
)


def _engine():
    return PathRiskEngine()


def test_multiple_objects_ids_preserved():
    """Test 11 (spec): multiple objects → all IDs preserved."""
    engine = _engine()
    candidate = make_candidate("PATH_MULTI")
    objs = [
        FakeWorldObject("OBJ_A", "CAR", x=8.0, y=0.0,
                        ttc_s=2.0, ttc_status="FINITE", collision_likelihood=0.5),
        FakeWorldObject("OBJ_B", "MOTORCYCLE", x=12.0, y=1.0,
                        ttc_s=3.5, ttc_status="FINITE", collision_likelihood=0.3),
        FakeWorldObject("OBJ_C", "PEDESTRIAN", x=6.0, y=-0.5,
                        ttc_s=1.5, ttc_status="FINITE", collision_likelihood=0.6),
    ]
    wm = FakeWorldModelSnapshot(objects=objs)
    result = engine.evaluate([candidate], wm, frame_id=11)
    risk = result.risks[0]

    assert risk.dynamic_object_count == 3
    # Affected object IDs must be preserved
    assert len(risk.affected_object_ids) >= 1

    # All contributing object IDs should be from our set
    expected_ids = {"OBJ_A", "OBJ_B", "OBJ_C"}
    for oid in risk.affected_object_ids:
        assert oid in expected_ids, f"Unexpected object ID: {oid}"


def test_multiple_objects_higher_risk_than_single():
    """Multiple objects near path → aggregate risk > single object."""
    engine = _engine()
    candidate = make_candidate("PATH_MULTI2", lateral_offset_m=0.0)

    single_obj = FakeWorldObject("SING", "CAR", x=8.0, y=0.5,
                                 ttc_s=2.0, ttc_status="FINITE",
                                 collision_likelihood=0.4)
    many_objs = [
        FakeWorldObject("M1", "CAR", x=6.0, y=0.3,
                        ttc_s=2.0, ttc_status="FINITE", collision_likelihood=0.4),
        FakeWorldObject("M2", "MOTORCYCLE", x=9.0, y=-0.3,
                        ttc_s=2.5, ttc_status="FINITE", collision_likelihood=0.35),
        FakeWorldObject("M3", "CAR", x=13.0, y=0.6,
                        ttc_s=3.0, ttc_status="FINITE", collision_likelihood=0.3),
    ]

    wm_single = FakeWorldModelSnapshot(objects=[single_obj])
    wm_many = FakeWorldModelSnapshot(objects=many_objs)

    result_single = engine.evaluate([candidate], wm_single, frame_id=200)
    result_many = engine.evaluate([candidate], wm_many, frame_id=200)

    risk_single = result_single.risks[0].total_risk
    risk_many = result_many.risks[0].total_risk

    # Multiple close objects should produce >= risk (not necessarily strictly >)
    assert risk_many >= risk_single - 0.05, (
        f"Many objects risk {risk_many:.3f} should be >= single {risk_single:.3f}"
    )


def test_critical_object_count_tracked():
    """Critical objects (high risk) should be counted separately."""
    engine = _engine()
    candidate = make_candidate("PATH_CRIT")
    objs = [
        FakeWorldObject("CRIT_1", "CAR", x=4.0, y=0.0,
                        ttc_s=0.5, ttc_status="FINITE",
                        collision_likelihood=0.95, risk_level="CRITICAL"),
        FakeWorldObject("SAFE_1", "CAR", x=80.0, y=5.0,
                        ttc_status="NO_COLLISION", collision_likelihood=0.0),
    ]
    wm = FakeWorldModelSnapshot(objects=objs)
    result = engine.evaluate([candidate], wm, frame_id=21)
    risk = result.risks[0]

    assert risk.critical_object_count >= 1
    assert risk.dynamic_object_count == 2


def test_many_objects_bounded():
    """Engine must not crash with many objects (bounding enforced)."""
    engine = _engine()
    candidate = make_candidate("PATH_MANY")
    objs = [
        FakeWorldObject(f"OBJ_{i:03d}", "CAR", x=float(i)*2.0, y=float(i % 3))
        for i in range(50)
    ]
    wm = FakeWorldModelSnapshot(objects=objs)
    result = engine.evaluate([candidate], wm, frame_id=22)

    assert result.risk_count == 1
    assert 0.0 <= result.risks[0].total_risk <= 1.0
