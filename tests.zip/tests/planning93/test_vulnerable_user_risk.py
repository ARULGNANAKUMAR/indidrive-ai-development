"""Phase 9.3 Tests — VRU risk (Tests 8, 9, 10 from spec)."""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "../.."))

from core.planning.path_risk_engine import PathRiskEngine, _is_vru
from core.planning.path_risk_config import PathRiskConfig
from core.planning.path_risk_types import RiskReasonCode
from tests.planning93.helpers_93 import (
    make_candidate, FakeWorldObject, FakeWorldModelSnapshot,
)


def _engine():
    return PathRiskEngine()


# -----------------------------------------------------------------------
# Test 8: Pedestrian near path → VRU contribution
# -----------------------------------------------------------------------

def test_pedestrian_near_path_vru_contribution():
    """Test 8 (spec): pedestrian near path → vulnerable-user contribution."""
    engine = _engine()
    candidate = make_candidate("PATH_PED", lateral_offset_m=0.0)
    ped = FakeWorldObject(
        "PED_001", "PEDESTRIAN",
        x=8.0, y=0.5,
        ttc_s=3.0, ttc_status="FINITE",
        min_distance_m=1.0,
        collision_likelihood=0.4,
    )
    wm = FakeWorldModelSnapshot(objects=[ped])
    result = engine.evaluate([candidate], wm, frame_id=8)
    risk = result.risks[0]

    # VRU risk must contribute
    assert risk.breakdown.vulnerable_user_risk > 0.0, (
        "Expected VRU risk contribution for pedestrian"
    )
    assert RiskReasonCode.VULNERABLE_USER_NEAR_PATH in risk.reason_codes


# -----------------------------------------------------------------------
# Test 9: Cattle crossing → dynamic interaction risk
# -----------------------------------------------------------------------

def test_cattle_crossing_risk():
    """Test 9 (spec): cattle crossing path → interaction risk."""
    engine = _engine()
    candidate = make_candidate("PATH_CATTLE", lateral_offset_m=0.0)
    cattle = FakeWorldObject(
        "CATTLE_001", "CATTLE",
        x=12.0, y=3.0, vx=0.0, vy=-1.5,  # moving toward path
        ttc_s=4.0, ttc_status="FINITE",
        min_distance_m=2.5,
        collision_likelihood=0.35,
    )
    wm = FakeWorldModelSnapshot(objects=[cattle])
    result = engine.evaluate([candidate], wm, frame_id=9)
    risk = result.risks[0]

    assert risk.total_risk > 0.2
    assert risk.breakdown.vulnerable_user_risk >= 0.0  # VRU type
    assert risk.dynamic_object_count == 1


# -----------------------------------------------------------------------
# Test 10: Motorcycle lateral movement → crossing/lateral risk
# -----------------------------------------------------------------------

def test_motorcycle_lateral_movement():
    """Test 10 (spec): motorcycle lateral movement → crossing/lateral risk."""
    engine = _engine()
    candidate = make_candidate("PATH_MOTO", lateral_offset_m=0.0)
    moto = FakeWorldObject(
        "MOTO_001", "MOTORCYCLE",
        x=10.0, y=3.5, vx=0.5, vy=-2.5,  # moving toward path center
        ttc_s=2.5, ttc_status="FINITE",
        min_distance_m=2.0,
        collision_likelihood=0.45,
    )
    wm = FakeWorldModelSnapshot(objects=[moto])
    result = engine.evaluate([candidate], wm, frame_id=10)
    risk = result.risks[0]

    # Temporal risk should detect lateral approach
    assert risk.total_risk > 0.15
    assert risk.dynamic_object_count == 1


# -----------------------------------------------------------------------
# VRU type identification
# -----------------------------------------------------------------------

def test_vru_types_identified():
    cfg = PathRiskConfig()
    for vru_type in ["PEDESTRIAN", "CYCLIST", "CYCLE", "CATTLE", "CHILD"]:
        assert _is_vru(vru_type, cfg), f"{vru_type} should be VRU"


def test_non_vru_not_flagged():
    cfg = PathRiskConfig()
    for non_vru in ["CAR", "BUS", "TRUCK"]:
        assert not _is_vru(non_vru, cfg), f"{non_vru} should NOT be VRU"


# -----------------------------------------------------------------------
# VRU vs non-VRU same position: VRU has higher or equal risk
# -----------------------------------------------------------------------

def test_vru_higher_risk_than_car_same_position():
    engine = _engine()
    candidate = make_candidate("PATH_VRU_CMP", lateral_offset_m=0.0)

    ped = FakeWorldObject("PED_CMP", "PEDESTRIAN", x=5.0, y=0.5,
                          ttc_s=3.0, ttc_status="FINITE",
                          min_distance_m=1.0, collision_likelihood=0.4)
    car = FakeWorldObject("CAR_CMP", "CAR", x=5.0, y=0.5,
                          ttc_s=3.0, ttc_status="FINITE",
                          min_distance_m=1.0, collision_likelihood=0.4)

    wm_ped = FakeWorldModelSnapshot(objects=[ped])
    wm_car = FakeWorldModelSnapshot(objects=[car])

    result_ped = engine.evaluate([candidate], wm_ped, frame_id=100)
    result_car = engine.evaluate([candidate], wm_car, frame_id=100)

    risk_ped = result_ped.risks[0].total_risk
    risk_car = result_car.risks[0].total_risk

    assert risk_ped >= risk_car, (
        f"Pedestrian risk ({risk_ped:.3f}) should be >= car risk ({risk_car:.3f})"
    )
