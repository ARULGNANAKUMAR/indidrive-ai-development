"""
IndiDrive AI — Phase 9.3 Tests | Shared Helpers & Fixtures
===========================================================
Factories for building minimal test objects without importing CARLA,
cloud APIs, or large ML models.

All helpers produce deterministic outputs for the same inputs.
No random data, no real-world metrics.
"""
from __future__ import annotations

import time
from typing import List, Optional, Tuple

# -----------------------------------------------------------------------
# Minimal stub classes (used instead of importing full heavy modules)
# -----------------------------------------------------------------------

class _Pos:
    def __init__(self, x=0.0, y=0.0, z=0.0, dist=None):
        self.x = x
        self.y = y
        self.z = z
        self.distance_m = dist if dist is not None else (x**2 + y**2)**0.5

class _Vel:
    def __init__(self, vx=0.0, vy=0.0, speed=None):
        self.vx = vx
        self.vy = vy
        self.speed_ms = speed if speed is not None else (vx**2 + vy**2)**0.5

class _Dims:
    def __init__(self, length=4.0, width=1.8, height=1.5):
        self.length_m = length
        self.width_m = width
        self.height_m = height

class _Motion:
    def __init__(self, is_moving=True, speed=5.0):
        self.is_moving = is_moving
        self.speed_ms = speed

class _Prediction:
    def __init__(self, trajectory=None, confidence=0.8, uncertainty=None):
        from core.world_model.world_model_types import PredictionAvailability
        self.availability = (
            PredictionAvailability.FULL if trajectory else PredictionAvailability.NONE
        )
        self.trajectory = trajectory or []
        self.prediction_confidence = confidence
        self.prediction_uncertainty = uncertainty or {}
        self.hypotheses = []
        self.motion_model = "CV"
        self.prediction_horizon_s = 3.0

class _Collision:
    def __init__(
        self,
        ttc_s=None,
        ttc_status="NO_COLLISION",
        closing_speed=None,
        min_distance_m=10.0,
        tca=2.0,
        collision_likelihood=0.0,
        risk_level="LOW",
        predicted_conflict=False,
    ):
        self.ttc_s = ttc_s
        self.ttc_status = ttc_status
        self.closing_speed_ms = closing_speed
        self.min_distance_m = min_distance_m
        self.time_of_closest_approach_s = tca
        self.collision_likelihood = collision_likelihood
        self.risk_level = risk_level
        self.predicted_conflict = predicted_conflict

class _Quality:
    def __init__(
        self,
        confidence=0.8,
        is_stale=False,
        is_degraded=False,
        data_age_s=0.1,
    ):
        self.object_confidence = confidence
        self.position_confidence = confidence
        self.velocity_confidence = confidence
        self.existence_probability = confidence
        self.is_stale = is_stale
        self.is_degraded = is_degraded
        self.data_age_s = data_age_s
        self.observation_state = "OBSERVED"
        self.source_sensors = "CAMERA+LIDAR"


class FakeWorldObject:
    """Minimal WorldObject-compatible stub."""

    def __init__(
        self,
        object_id: str = "OBJ_001",
        object_type: str = "CAR",
        x: float = 20.0,
        y: float = 0.0,
        vx: float = 0.0,
        vy: float = 0.0,
        ttc_s: Optional[float] = None,
        ttc_status: str = "NO_COLLISION",
        min_distance_m: float = 10.0,
        collision_likelihood: float = 0.0,
        risk_level: str = "LOW",
        trajectory: Optional[List[Tuple[float, float, float, float]]] = None,
        prediction_confidence: float = 0.8,
        is_stale: bool = False,
        is_degraded: bool = False,
        data_age_s: float = 0.1,
        width_m: float = 1.8,
    ):
        self.object_id = object_id
        self.track_id = object_id
        self.fused_id = object_id
        self.object_type = object_type
        self.object_subtype = object_type
        self.position = _Pos(x=x, y=y)
        self.velocity = _Vel(vx=vx, vy=vy)
        self.dimensions = _Dims(width=width_m)
        self.motion = _Motion(is_moving=(abs(vx) + abs(vy)) > 0.1, speed=(vx**2 + vy**2)**0.5)
        self.prediction = _Prediction(
            trajectory=trajectory, confidence=prediction_confidence
        )
        self.collision = _Collision(
            ttc_s=ttc_s,
            ttc_status=ttc_status,
            min_distance_m=min_distance_m,
            collision_likelihood=collision_likelihood,
            risk_level=risk_level,
        )
        self.quality = _Quality(
            confidence=prediction_confidence,
            is_stale=is_stale,
            is_degraded=is_degraded,
            data_age_s=data_age_s,
        )
        self.lifecycle = "ACTIVE"
        self.observation_timestamp = time.time()


class _DataQuality:
    def __init__(self, confidence=0.75, uncertainty=0.3, is_partial=False):
        self.overall_confidence = confidence
        self.overall_uncertainty = uncertainty
        self.completeness = 0.9
        self.freshness = 0.9
        self.is_partial = is_partial
        self.warnings = []


class _Road:
    def __init__(self, anomalies=None):
        self.anomalies = anomalies or []
        self.status = "PARTIAL"
        self.road_confidence = 0.7
        self.road_uncertainty = 0.3
        self.is_degraded = False


class FakeWorldModelSnapshot:
    """Minimal WorldModelSnapshot-compatible stub."""

    def __init__(
        self,
        objects: Optional[List[FakeWorldObject]] = None,
        anomalies: Optional[list] = None,
        confidence: float = 0.75,
        is_partial: bool = False,
    ):
        self._objects = tuple(objects or [])
        self.data_quality = _DataQuality(
            confidence=confidence, is_partial=is_partial
        )
        self.road = _Road(anomalies=anomalies)
        self.timestamp = time.time()
        self.frame_id = 1
        self.status = "OK"

    @property
    def objects(self):
        return self._objects


class _FakeConstraint:
    def __init__(self, kind="MAINTAIN_CLEARANCE"):
        self.kind = kind


class FakePlanningContext:
    """Minimal PlanningContext-compatible stub."""

    def __init__(self, planning_allowed: bool = True):
        self.planning_allowed = planning_allowed
        self.safety_gate_state = "NOMINAL" if planning_allowed else "BLOCKED"
        self.uncertainty_level = "LOW"
        self.frame_id = 1
        self.context_id = "CTX_001"
        self._hard_constraints = tuple()
        self._soft_constraints = tuple()

    @property
    def hard_constraints(self):
        return self._hard_constraints

    @property
    def soft_constraints(self):
        return self._soft_constraints


class FakeAnomaly:
    """Minimal WorldAnomalySummary-compatible stub."""
    def __init__(
        self,
        anomaly_id="ANOM_001",
        anomaly_type="POTHOLE",
        position_x=15.0,
        position_y=0.0,
        severity="MODERATE",
        drivability_impact="MEDIUM",
        width_m=0.5,
        length_m=0.3,
    ):
        self.anomaly_id = anomaly_id
        self.anomaly_type = anomaly_type
        self.position_x = position_x
        self.position_y = position_y
        self.severity = severity
        self.drivability_impact = drivability_impact
        self.approximate_width_m = width_m
        self.approximate_length_m = length_m
        self.confidence = 0.8
        self.uncertainty = 0.2
        self.in_drivable_area = True
        self.in_lane_corridor = True


# ---------------------------------------------------------------------------
# Candidate path builder
# ---------------------------------------------------------------------------

def make_candidate(
    candidate_id: str = "PATH_01",
    lateral_offset_m: float = 0.0,
    length_m: float = 30.0,
    n_waypoints: int = 16,
    geometric_valid: bool = True,
    boundary_valid: bool = True,
) -> object:
    """
    Build a minimal CandidatePath stub compatible with PathRiskEngine.

    The path is a straight-forward path (+X direction) with the given
    lateral offset in +Y.
    """
    from core.planning.candidate_path_types import (
        CandidatePath, PathPoint, CandidateMetadata,
        GeometricValidity, BoundaryValidity, DrivableSpaceValidity,
        GenerationMethod,
    )

    step = length_m / max(n_waypoints - 1, 1)
    waypoints = []
    for i in range(n_waypoints):
        x = step * i
        y = lateral_offset_m
        wp = PathPoint(
            x=x,
            y=y,
            z=0.0,
            longitudinal_s=x,
            lateral_offset_m=lateral_offset_m,
            heading=0.0,
        )
        waypoints.append(wp)

    geo_val = GeometricValidity.VALID if geometric_valid else GeometricValidity.INVALID
    bnd_val = BoundaryValidity.VALID if boundary_valid else BoundaryValidity.INVALID

    meta = CandidateMetadata(
        candidate_index=0,
        generation_timestamp=time.time(),
        path_length_m=length_m,
        waypoint_count=n_waypoints,
        nominal_lateral_offset_m=lateral_offset_m,
    )

    cp = CandidatePath(
        candidate_id=candidate_id,
        frame_id=1,
        timestamp=time.time(),
        coordinate_frame="VEHICLE",
        _waypoints=tuple(waypoints),
        longitudinal_extent_m=length_m,
        lateral_offset_m=lateral_offset_m,
        generation_method=GenerationMethod.CENTER,
        geometric_validity=geo_val,
        boundary_validity=bnd_val,
        drivable_space_validity=DrivableSpaceValidity.VALID,
        metadata=meta,
    )
    return cp
