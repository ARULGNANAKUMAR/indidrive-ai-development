"""Phase 9.3 Tests — stale data handling (Test 15 from spec)."""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "../.."))

from core.planning.path_risk_engine import PathRiskEngine
from core.planning.path_risk_config import PathRiskConfig
from core.planning.path_risk_types import RiskReasonCode
from tests.planning93.helpers_93 import (
    make_candidate, FakeWorldObject, FakeWorldModelSnapshot,
)


def _engine():
    return PathRiskEngine()


def test_stale_prediction_flagged():
    """Test 15 (spec): stale prediction → uncertainty/degraded indication."""
    engine = _engine()
    candidate = make_candidate("PATH_STALE")

    stale_obj = FakeWorldObject(
        "STALE_OBJ", "CAR",
        x=10.0, y=0.5,
        is_stale=True,
        data_age_s=3.0,       # very old
        prediction_confidence=0.2,
        ttc_status="UNKNOWN",
    )
    wm = FakeWorldModelSnapshot(objects=[stale_obj])
    result = engine.evaluate([candidate], wm, frame_id=15)
    risk = result.risks[0]

    # STALE_PREDICTION reason code must appear
    assert RiskReasonCode.STALE_PREDICTION in risk.reason_codes, (
        f"Expected STALE_PREDICTION in reason codes, got: "
        f"{[rc.value for rc in risk.reason_codes]}"
    )


def test_stale_vs_fresh_uncertainty_differs():
    """Stale object should have higher uncertainty risk than fresh."""
    engine = _engine()
    candidate = make_candidate("PATH_FRESH")

    fresh_obj = FakeWorldObject("FRESH", "CAR", x=10.0, y=0.5,
                                is_stale=False, data_age_s=0.05,
                                prediction_confidence=0.9)
    stale_obj = FakeWorldObject("STALE", "CAR", x=10.0, y=0.5,
                                is_stale=True, data_age_s=3.5,
                                prediction_confidence=0.15)

    wm_fresh = FakeWorldModelSnapshot(objects=[fresh_obj])
    wm_stale = FakeWorldModelSnapshot(objects=[stale_obj])

    res_fresh = engine.evaluate([candidate], wm_fresh, frame_id=151)
    res_stale = engine.evaluate([candidate], wm_stale, frame_id=152)

    unc_fresh = res_fresh.risks[0].breakdown.uncertainty_risk
    unc_stale = res_stale.risks[0].breakdown.uncertainty_risk

    assert unc_stale >= unc_fresh, (
        f"Stale uncertainty_risk ({unc_stale:.3f}) should be >= "
        f"fresh ({unc_fresh:.3f})"
    )


def test_freshness_threshold_config():
    """Staleness threshold is configurable."""
    cfg = PathRiskConfig()
    cfg.stale_data_age_s = 0.2  # very sensitive

    from core.planning.path_risk_engine import _compute_ttc_risk
    _, codes = _compute_ttc_risk(5.0, "FINITE", data_age_s=0.3, cfg=cfg)
    assert RiskReasonCode.STALE_PREDICTION in codes
