"""Phase 9.3 Tests — multi-hazard risk (Test 12 from spec)."""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "../.."))

from core.planning.path_risk_engine import PathRiskEngine
from core.planning.path_risk_types import RiskReasonCode
from tests.planning93.helpers_93 import (
    make_candidate, FakeWorldObject, FakeWorldModelSnapshot, FakeAnomaly,
)


def _engine():
    return PathRiskEngine()


def test_multiple_hazards_combined_breakdown():
    """Test 12 (spec): multiple hazards → combined breakdown preserved."""
    engine = _engine()
    candidate = make_candidate("PATH_MULTIHAZ", lateral_offset_m=0.0)

    pedestrian = FakeWorldObject("PED_H", "PEDESTRIAN", x=8.0, y=0.5,
                                 ttc_s=2.5, ttc_status="FINITE",
                                 collision_likelihood=0.4)
    motorcycle = FakeWorldObject("MOTO_H", "MOTORCYCLE", x=11.0, y=-0.4,
                                 ttc_s=3.0, ttc_status="FINITE",
                                 collision_likelihood=0.35)
    pothole = FakeAnomaly("POT_H", "POTHOLE", position_x=14.0, position_y=0.2,
                          severity="MODERATE")

    wm = FakeWorldModelSnapshot(
        objects=[pedestrian, motorcycle],
        anomalies=[pothole],
    )
    result = engine.evaluate([candidate], wm, frame_id=12)
    risk = result.risks[0]

    bd = risk.breakdown
    # Multiple components should be non-zero
    non_zero = sum([
        bd.ttc_risk > 0.0,
        bd.vulnerable_user_risk > 0.0,
        bd.road_hazard_risk > 0.0,
    ])
    assert non_zero >= 2, (
        f"Expected multiple risk components, got: "
        f"ttc={bd.ttc_risk:.3f}, vru={bd.vulnerable_user_risk:.3f}, "
        f"hazard={bd.road_hazard_risk:.3f}"
    )

    # Reason codes should reflect multiple sources
    rc_values = [rc.value for rc in risk.reason_codes]
    assert len(rc_values) >= 2, f"Expected multiple reason codes, got {rc_values}"


def test_multiple_hazards_one_low_does_not_hide_critical():
    """Test 12 (spec): one low-risk object must not hide critical interaction."""
    engine = _engine()
    candidate = make_candidate("PATH_HIDE_TEST", lateral_offset_m=0.0)

    critical_obj = FakeWorldObject(
        "CRIT_OBJ", "CAR", x=5.0, y=0.0,
        ttc_s=0.5, ttc_status="FINITE",
        collision_likelihood=0.9, risk_level="CRITICAL",
    )
    safe_obj = FakeWorldObject(
        "SAFE_OBJ", "CAR", x=200.0, y=30.0,
        ttc_status="NO_COLLISION", collision_likelihood=0.0,
    )

    wm = FakeWorldModelSnapshot(objects=[critical_obj, safe_obj])
    result = engine.evaluate([candidate], wm, frame_id=120)
    risk = result.risks[0]

    # Critical object risk must dominate — total_risk must be high
    assert risk.total_risk > 0.5, (
        f"Critical object hidden by safe object: total_risk={risk.total_risk:.3f}"
    )
    assert risk.critical_object_count >= 1


def test_pothole_and_pedestrian_combined():
    """Pothole + pedestrian → both contribute to breakdown."""
    engine = _engine()
    candidate = make_candidate("PATH_POT_PED", lateral_offset_m=0.0)

    ped = FakeWorldObject("PED_PP", "PEDESTRIAN", x=8.0, y=0.3,
                          ttc_s=3.0, ttc_status="FINITE", collision_likelihood=0.4)
    pot = FakeAnomaly("POT_PP", severity="SEVERE", position_x=12.0, position_y=0.1)
    wm = FakeWorldModelSnapshot(objects=[ped], anomalies=[pot])

    result = engine.evaluate([candidate], wm, frame_id=130)
    risk = result.risks[0]

    assert risk.breakdown.vulnerable_user_risk > 0.0
    assert risk.breakdown.road_hazard_risk > 0.0
    assert RiskReasonCode.ROAD_HAZARD_INTERACTION in risk.reason_codes
    assert RiskReasonCode.VULNERABLE_USER_NEAR_PATH in risk.reason_codes
