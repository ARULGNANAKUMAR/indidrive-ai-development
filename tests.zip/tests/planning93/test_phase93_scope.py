"""
Phase 9.3 Tests — Scope confirmation (spec §37, §2).
Explicit negative tests ensuring Phase 9.3 does NOT output or implement
any vehicle control, path selection, or future-phase logic.
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "../.."))

from core.planning.path_risk_types import (
    CandidatePathRisk, PathRiskSet, RiskBreakdown, ObjectRiskContribution,
)
from core.planning.path_risk_engine import PathRiskEngine
from tests.planning93.helpers_93 import (
    make_candidate, FakeWorldObject, FakeWorldModelSnapshot,
)


# Forbidden fields that must never appear on Phase 9.3 output types
FORBIDDEN_ON_RISK = [
    "steering_angle", "throttle", "brake", "target_speed",
    "acceleration_cmd", "selected_path", "best_path", "optimal_path",
    "chosen_path", "winner", "replan", "adaptive_replan", "replan_trigger",
    "lane_change_decision", "mpc_output", "carla_command",
    "vehicle_command", "waypoint_generation", "trajectory_optimization",
    "controller_command",
]

FORBIDDEN_ON_SET = [
    "selected_path", "best_path", "optimal_path", "chosen_path",
    "winner", "risk_ranking_for_selection", "sorted_for_selection",
    "steering_angle", "throttle", "brake", "target_speed",
]


def test_no_forbidden_fields_on_candidate_path_risk():
    r = CandidatePathRisk()
    for ff in FORBIDDEN_ON_RISK:
        assert not hasattr(r, ff), (
            f"Forbidden field '{ff}' found on CandidatePathRisk"
        )


def test_no_forbidden_fields_on_path_risk_set():
    s = PathRiskSet()
    for ff in FORBIDDEN_ON_SET:
        assert not hasattr(s, ff), (
            f"Forbidden field '{ff}' found on PathRiskSet"
        )


def test_no_forbidden_fields_on_breakdown():
    b = RiskBreakdown()
    for ff in FORBIDDEN_ON_RISK:
        assert not hasattr(b, ff)


def test_no_forbidden_fields_on_object_contribution():
    oc = ObjectRiskContribution()
    for ff in FORBIDDEN_ON_RISK:
        assert not hasattr(oc, ff)


def test_engine_output_no_selected_path():
    """Engine must never expose selected/best path."""
    engine = PathRiskEngine()
    candidates = [
        make_candidate("SCOPE_A"),
        make_candidate("SCOPE_B", lateral_offset_m=0.75),
    ]
    wm = FakeWorldModelSnapshot(objects=[
        FakeWorldObject("OBJ_S", "CAR", x=10.0, y=0.0,
                        ttc_s=2.0, ttc_status="FINITE", collision_likelihood=0.4)
    ])
    result = engine.evaluate(candidates, wm, frame_id=99)

    # Set-level check
    for ff in FORBIDDEN_ON_SET:
        assert not hasattr(result, ff), f"Forbidden field '{ff}' on engine output"

    # Per-risk check
    for r in result.risks:
        for ff in FORBIDDEN_ON_RISK:
            assert not hasattr(r, ff), f"Forbidden field '{ff}' on CandidatePathRisk"


def test_engine_has_no_path_generation():
    """PathRiskEngine must not have path generation methods."""
    engine = PathRiskEngine()
    generation_methods = [
        "generate_paths", "generate_candidate", "plan_path",
        "create_path", "build_path", "select_path", "choose_path",
    ]
    for method in generation_methods:
        assert not hasattr(engine, method), (
            f"PathRiskEngine must not have '{method}' method"
        )


def test_engine_has_no_vehicle_control():
    """PathRiskEngine must not have vehicle control outputs."""
    engine = PathRiskEngine()
    control_methods = [
        "steer", "throttle", "brake", "accelerate", "decelerate",
        "set_target_speed", "issue_command",
    ]
    for method in control_methods:
        assert not hasattr(engine, method), (
            f"PathRiskEngine must not have '{method}' method"
        )


def test_no_replanning():
    """Phase 9.3 must not trigger replanning."""
    engine = PathRiskEngine()
    for attr in ["replan", "trigger_replan", "request_replan", "adaptive_replan"]:
        assert not hasattr(engine, attr), f"Forbidden attribute '{attr}' found"


def test_path_risk_types_not_imported_from_future_phases():
    """Phase 9.3 must not import path selection / MPC / control types."""
    import core.planning.path_risk_types as prt
    import inspect
    source = inspect.getsource(prt)
    # Check that these modules/classes are not *imported* (import statements only)
    import_lines = [
        line.strip() for line in source.splitlines()
        if line.strip().startswith("import ") or line.strip().startswith("from ")
    ]
    import_block = "\n".join(import_lines)
    for forbidden_import in ["CarlaVehicle", "SteeringController", "MPCController",
                             "carla_integration", "mpc_engine"]:
        assert forbidden_import not in import_block, (
            f"Forbidden import '{forbidden_import}' in path_risk_types.py imports"
        )
    # Also verify no *field definitions* using forbidden names (not comments/docstrings)
    code_lines = [
        line for line in source.splitlines()
        if not line.strip().startswith("#") and "\"\"\"" not in line
        and "'''" not in line
    ]
    code_block = "\n".join(code_lines)
    for forbidden_field in ["mpc_output:", "carla_command:", "steering_angle:"]:
        assert forbidden_field not in code_block, (
            f"Forbidden field definition '{forbidden_field}' in path_risk_types.py"
        )


def test_scope_no_new_perception():
    """Phase 9.3 module must not import perception internals."""
    import core.planning.path_risk_engine as pre
    import inspect
    source = inspect.getsource(pre)
    # Must not create new perception / sensor processing
    for forbidden in ["lidar_perception", "camera_perception", "radar_perception",
                      "object_detection", "FusionEngine", "KalmanFilter"]:
        assert forbidden not in source, (
            f"Phase 9.3 must not reference '{forbidden}' (perception reimplementation)"
        )
