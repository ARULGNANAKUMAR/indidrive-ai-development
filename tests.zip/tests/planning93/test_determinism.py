"""Phase 9.3 Tests — determinism (Test 19 from spec)."""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "../.."))

from core.planning.path_risk_engine import PathRiskEngine
from tests.planning93.helpers_93 import (
    make_candidate, FakeWorldObject, FakeWorldModelSnapshot,
)


def _build_scenario():
    """Build a fixed deterministic scenario."""
    candidates = [
        make_candidate("PATH_DET_A", lateral_offset_m=0.0),
        make_candidate("PATH_DET_B", lateral_offset_m=0.75),
        make_candidate("PATH_DET_C", lateral_offset_m=-0.75),
    ]
    objects = [
        FakeWorldObject("D_OBJ1", "CAR", x=10.0, y=0.0,
                        ttc_s=2.5, ttc_status="FINITE",
                        min_distance_m=2.0, collision_likelihood=0.45),
        FakeWorldObject("D_OBJ2", "PEDESTRIAN", x=7.0, y=0.8,
                        ttc_s=3.0, ttc_status="FINITE",
                        min_distance_m=1.5, collision_likelihood=0.35),
    ]
    wm = FakeWorldModelSnapshot(objects=objects, confidence=0.8)
    return candidates, wm


def test_determinism_same_input_same_output():
    """Test 19 (spec): same input twice → identical result."""
    engine = PathRiskEngine()
    candidates, wm = _build_scenario()

    result_1 = engine.evaluate(list(candidates), wm, frame_id=19)
    result_2 = engine.evaluate(list(candidates), wm, frame_id=19)

    assert result_1.risk_count == result_2.risk_count

    for r1, r2 in zip(result_1.risks, result_2.risks):
        assert r1.candidate_id == r2.candidate_id
        # Risk scores must be bit-identical (deterministic)
        assert r1.total_risk == r2.total_risk, (
            f"Non-deterministic total_risk for {r1.candidate_id}: "
            f"{r1.total_risk} vs {r2.total_risk}"
        )
        assert r1.risk_level == r2.risk_level
        assert set(r1.reason_codes) == set(r2.reason_codes), (
            f"Non-deterministic reason_codes for {r1.candidate_id}"
        )
        assert r1.dynamic_object_count == r2.dynamic_object_count
        assert r1.critical_object_count == r2.critical_object_count


def test_determinism_ordering_stable():
    """Output order matches input order deterministically."""
    engine = PathRiskEngine()
    candidates, wm = _build_scenario()

    result = engine.evaluate(list(candidates), wm, frame_id=191)
    ids = [r.candidate_id for r in result.risks]

    result2 = engine.evaluate(list(candidates), wm, frame_id=191)
    ids2 = [r.candidate_id for r in result2.risks]

    assert ids == ids2, f"Output ordering changed: {ids} vs {ids2}"


def test_determinism_breakdown_components():
    """Every breakdown component must be identical across runs."""
    engine = PathRiskEngine()
    candidates, wm = _build_scenario()

    r1 = engine.evaluate(list(candidates), wm, frame_id=192).risks[0]
    r2 = engine.evaluate(list(candidates), wm, frame_id=192).risks[0]

    bd1 = r1.breakdown.to_dict()
    bd2 = r2.breakdown.to_dict()

    for key in bd1:
        assert bd1[key] == bd2[key], (
            f"Non-deterministic breakdown.{key}: {bd1[key]} vs {bd2[key]}"
        )
