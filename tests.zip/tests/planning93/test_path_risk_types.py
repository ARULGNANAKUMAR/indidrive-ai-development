"""
Phase 9.3 Tests — path_risk_types.py
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "../.."))

from core.planning.path_risk_types import (
    CandidatePathRisk, PathRiskSet, RiskBreakdown, ObjectRiskContribution,
    RiskLevel, RiskReasonCode, PathRiskStatus,
    NOT_AVAILABLE, PATH_RISK_SCHEMA_VERSION,
)


def test_risk_level_values():
    assert RiskLevel.LOW_RISK.value == "LOW_RISK"
    assert RiskLevel.MODERATE_RISK.value == "MODERATE_RISK"
    assert RiskLevel.HIGH_RISK.value == "HIGH_RISK"
    assert RiskLevel.CRITICAL_RISK.value == "CRITICAL_RISK"
    assert RiskLevel.UNKNOWN_RISK.value == "UNKNOWN_RISK"


def test_reason_code_values():
    """All reason codes must be str enum values."""
    for rc in RiskReasonCode:
        assert isinstance(rc.value, str)
        assert len(rc.value) > 0


def test_risk_breakdown_defaults():
    bd = RiskBreakdown()
    assert bd.clearance_risk == 0.0
    assert bd.ttc_risk == 0.0
    assert bd.vulnerable_user_risk == 0.0
    d = bd.to_dict()
    assert "clearance_risk" in d
    assert "road_hazard_risk" in d


def test_object_risk_contribution_defaults():
    oc = ObjectRiskContribution()
    assert oc.object_id == NOT_AVAILABLE
    assert oc.combined_object_risk == 0.0
    assert oc.reason_codes == tuple()
    d = oc.to_dict()
    assert "combined_object_risk" in d
    assert "is_critical" in d


def test_candidate_path_risk_defaults():
    r = CandidatePathRisk()
    assert r.candidate_id == NOT_AVAILABLE
    assert r.total_risk == 0.0
    assert r.risk_level == RiskLevel.UNKNOWN_RISK
    assert r.schema_version == PATH_RISK_SCHEMA_VERSION
    assert r.reason_codes == tuple()
    assert r.object_contributions == tuple()
    assert r.affected_object_ids == tuple()


def test_candidate_path_risk_to_dict():
    r = CandidatePathRisk(
        candidate_id="PATH_01",
        frame_id=5,
        total_risk=0.42,
        risk_level=RiskLevel.MODERATE_RISK,
        confidence=0.8,
        uncertainty=0.2,
    )
    d = r.to_dict()
    assert d["candidate_id"] == "PATH_01"
    assert d["frame_id"] == 5
    assert abs(d["total_risk"] - 0.42) < 0.001
    assert d["risk_level"] == "MODERATE_RISK"
    # Forbidden fields must not be present
    for ff in ["selected_path", "best_path", "steering_angle", "throttle", "brake"]:
        assert ff not in d


def test_path_risk_set_defaults():
    s = PathRiskSet()
    assert s.risk_count == 0
    assert not s.has_risks
    assert s.schema_version == PATH_RISK_SCHEMA_VERSION


def test_path_risk_set_to_dict():
    r1 = CandidatePathRisk(candidate_id="P1", total_risk=0.1, risk_level=RiskLevel.LOW_RISK)
    r2 = CandidatePathRisk(candidate_id="P2", total_risk=0.9, risk_level=RiskLevel.CRITICAL_RISK)
    s = PathRiskSet(
        set_id="SET_001",
        frame_id=1,
        status=PathRiskStatus.EVALUATED,
        _risks=(r1, r2),
    )
    d = s.to_dict()
    assert d["risk_count"] == 2
    assert d["critical_count"] == 1
    # No selection fields
    for ff in ["selected_path", "best_path", "optimal_path"]:
        assert ff not in d


def test_path_risk_status_values():
    for ps in PathRiskStatus:
        assert isinstance(ps.value, str)
