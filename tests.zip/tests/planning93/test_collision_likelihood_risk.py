"""Phase 9.3 Tests — collision likelihood risk component."""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "../.."))

from core.planning.path_risk_engine import _compute_collision_likelihood_risk
from core.planning.path_risk_config import PathRiskConfig
from core.planning.path_risk_types import RiskReasonCode


def test_high_likelihood_high_risk():
    cfg = PathRiskConfig()
    risk, codes = _compute_collision_likelihood_risk(0.9, cfg)
    assert risk >= 0.7
    assert RiskReasonCode.HIGH_COLLISION_LIKELIHOOD in codes


def test_zero_likelihood_zero_risk():
    cfg = PathRiskConfig()
    risk, codes = _compute_collision_likelihood_risk(0.0, cfg)
    assert risk == 0.0


def test_none_likelihood_no_crash():
    cfg = PathRiskConfig()
    risk, codes = _compute_collision_likelihood_risk(None, cfg)
    assert risk == 0.0


def test_likelihood_clamped_to_one():
    """Likelihood > 1.0 (shouldn't happen but guard anyway) is clamped."""
    cfg = PathRiskConfig()
    risk, _ = _compute_collision_likelihood_risk(2.0, cfg)
    assert risk <= 1.0


def test_likelihood_distinguishes_low_high():
    cfg = PathRiskConfig()
    risk_low, _ = _compute_collision_likelihood_risk(0.05, cfg)
    risk_high, _ = _compute_collision_likelihood_risk(0.85, cfg)
    assert risk_low < risk_high
