"""
Phase 9.3 Tests — Indian Road Scenarios (spec §36, Tests 13–14)
Synthetic test fixtures for realistic Indian road conditions.
These are unit/integration scenarios only — no real-world performance metrics.
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "../.."))

from core.planning.path_risk_engine import PathRiskEngine
from core.planning.path_risk_types import RiskReasonCode
from tests.planning93.helpers_93 import (
    make_candidate, FakeWorldObject, FakeWorldModelSnapshot, FakeAnomaly,
)


def _engine():
    return PathRiskEngine()


# ---------------------------------------------------------------------------
# Scenario: village_unmarked_road — cattle + pedestrian on narrow road
# ---------------------------------------------------------------------------

def test_village_unmarked_road():
    """Cattle + pedestrian on narrow village road → combined VRU risk."""
    engine = _engine()
    candidate = make_candidate("PATH_VIL", lateral_offset_m=0.0, length_m=25.0)

    cattle = FakeWorldObject("CATTLE_V", "CATTLE", x=12.0, y=0.8,
                             vx=0.0, vy=-0.8,
                             ttc_s=4.0, ttc_status="FINITE",
                             min_distance_m=2.0, collision_likelihood=0.3)
    ped = FakeWorldObject("PED_V", "PEDESTRIAN", x=8.0, y=-0.5,
                          vx=-0.5, vy=0.5,
                          ttc_s=5.0, ttc_status="FINITE",
                          min_distance_m=2.5, collision_likelihood=0.2)

    wm = FakeWorldModelSnapshot(objects=[cattle, ped])
    result = engine.evaluate([candidate], wm, frame_id=50)
    risk = result.risks[0]

    assert risk.breakdown.vulnerable_user_risk > 0.0
    assert risk.dynamic_object_count == 2
    assert 0.0 <= risk.total_risk <= 1.0


# ---------------------------------------------------------------------------
# Scenario: busy_market — pedestrians + motorcycles + pushcarts
# ---------------------------------------------------------------------------

def test_busy_market():
    """Dense urban market: multiple pedestrians, motorcycles, pushcarts."""
    engine = _engine()
    candidate = make_candidate("PATH_MKT", lateral_offset_m=0.0, length_m=20.0)

    objects = [
        FakeWorldObject("PED_MKT1", "PEDESTRIAN", x=5.0, y=0.3,
                        ttc_s=2.0, ttc_status="FINITE", collision_likelihood=0.5),
        FakeWorldObject("PED_MKT2", "PEDESTRIAN", x=8.0, y=-0.4,
                        ttc_s=3.0, ttc_status="FINITE", collision_likelihood=0.4),
        FakeWorldObject("MOTO_MKT", "MOTORCYCLE", x=10.0, y=0.6,
                        ttc_s=1.5, ttc_status="FINITE", collision_likelihood=0.55),
        FakeWorldObject("CART_MKT", "PUSHCART", x=6.0, y=0.2,
                        ttc_s=4.0, ttc_status="FINITE", collision_likelihood=0.25),
    ]
    wm = FakeWorldModelSnapshot(objects=objects)
    result = engine.evaluate([candidate], wm, frame_id=51)
    risk = result.risks[0]

    assert risk.dynamic_object_count == 4
    assert risk.total_risk > 0.3, "Market scenario should have notable risk"
    assert risk.breakdown.vulnerable_user_risk > 0.0


# ---------------------------------------------------------------------------
# Scenario: highway_merge — high-speed vehicle
# ---------------------------------------------------------------------------

def test_highway_merge():
    """Highway merge: fast vehicle with short TTC."""
    engine = _engine()
    candidate = make_candidate("PATH_HWY", lateral_offset_m=0.0, length_m=60.0)

    fast_car = FakeWorldObject(
        "FAST_HWY", "CAR",
        x=30.0, y=1.5, vx=-15.0, vy=-1.5,  # approaching fast
        ttc_s=1.2, ttc_status="FINITE",
        min_distance_m=1.5, collision_likelihood=0.7,
    )
    wm = FakeWorldModelSnapshot(objects=[fast_car])
    result = engine.evaluate([candidate], wm, frame_id=52)
    risk = result.risks[0]

    assert risk.total_risk > 0.4
    assert risk.breakdown.ttc_risk > 0.5


# ---------------------------------------------------------------------------
# Scenario: unsignalized_intersection — crossing vehicles
# ---------------------------------------------------------------------------

def test_unsignalized_intersection():
    """Unsignalized intersection: vehicle crossing from side."""
    engine = _engine()
    candidate = make_candidate("PATH_INT", lateral_offset_m=0.0)

    # Vehicle coming from the left, crossing path
    cross_vehicle = FakeWorldObject(
        "CROSS_INT", "CAR",
        x=15.0, y=5.0, vx=0.0, vy=-5.0,
        ttc_s=2.0, ttc_status="FINITE",
        min_distance_m=2.0, collision_likelihood=0.55,
        trajectory=[(15.0, 5.0 - 2.0*t, 0.0, float(t)) for t in range(5)],
    )
    wm = FakeWorldModelSnapshot(objects=[cross_vehicle])
    result = engine.evaluate([candidate], wm, frame_id=53)
    risk = result.risks[0]

    assert risk.total_risk > 0.3


# ---------------------------------------------------------------------------
# Scenario: cattle_crossing (Test 13 variant — pothole interaction)
# ---------------------------------------------------------------------------

def test_cattle_crossing_scenario():
    """Cattle crossing + pothole on path."""
    engine = _engine()
    candidate = make_candidate("PATH_CATT", lateral_offset_m=0.0)

    cattle = FakeWorldObject("CATTLE_C", "CATTLE",
                             x=10.0, y=2.5, vx=0.0, vy=-1.5,
                             ttc_s=3.0, ttc_status="FINITE",
                             min_distance_m=2.0, collision_likelihood=0.35)
    pot = FakeAnomaly("POT_C", "POTHOLE", position_x=8.0, position_y=0.3,
                      severity="MODERATE")

    wm = FakeWorldModelSnapshot(objects=[cattle], anomalies=[pot])
    result = engine.evaluate([candidate], wm, frame_id=54)
    risk = result.risks[0]

    assert risk.breakdown.vulnerable_user_risk > 0.0
    assert risk.breakdown.road_hazard_risk > 0.0


# ---------------------------------------------------------------------------
# Test 13 (spec): Pothole interaction → road-hazard contribution
# ---------------------------------------------------------------------------

def test_pothole_road_hazard_contribution():
    """Test 13 (spec): pothole on path → road_hazard_risk contribution."""
    engine = _engine()
    candidate = make_candidate("PATH_POT", lateral_offset_m=0.0)
    pot = FakeAnomaly("POTHOLE_1", "POTHOLE",
                      position_x=10.0, position_y=0.2,
                      severity="MODERATE")
    wm = FakeWorldModelSnapshot(objects=[], anomalies=[pot])
    result = engine.evaluate([candidate], wm, frame_id=55)
    risk = result.risks[0]

    assert risk.breakdown.road_hazard_risk > 0.0, (
        f"Expected road hazard contribution, got {risk.breakdown.road_hazard_risk}"
    )
    assert RiskReasonCode.ROAD_HAZARD_INTERACTION in risk.reason_codes


# ---------------------------------------------------------------------------
# Test 14 (spec): Narrow road → clearance sensitivity
# ---------------------------------------------------------------------------

def test_narrow_road_clearance_sensitivity():
    """Test 14 (spec): narrow road → path close to object → clearance sensitivity."""
    engine = _engine()

    # Narrow candidate (close to boundary)
    candidate_narrow = make_candidate("PATH_NARROW", lateral_offset_m=0.5, length_m=20.0)
    candidate_wide = make_candidate("PATH_WIDE", lateral_offset_m=2.0, length_m=20.0)

    obj = FakeWorldObject("OBJ_NRW", "CAR", x=10.0, y=1.5,
                          ttc_s=4.0, ttc_status="FINITE", collision_likelihood=0.3)
    wm = FakeWorldModelSnapshot(objects=[obj])

    result_narrow = engine.evaluate([candidate_narrow], wm, frame_id=60)
    result_wide = engine.evaluate([candidate_wide], wm, frame_id=60)

    risk_narrow = result_narrow.risks[0]
    risk_wide = result_wide.risks[0]

    # The narrow candidate (offset 0.5) is closer to the object at y=1.5
    # than the wide candidate (offset 2.0 → further from y=1.5 if object is at y=1.5)
    # Both should have valid risk scores
    assert 0.0 <= risk_narrow.total_risk <= 1.0
    assert 0.0 <= risk_wide.total_risk <= 1.0


# ---------------------------------------------------------------------------
# Scenario: wrong_side_vehicle
# ---------------------------------------------------------------------------

def test_wrong_side_vehicle():
    """Wrong-side vehicle approaching head-on: very low TTC, high risk."""
    engine = _engine()
    candidate = make_candidate("PATH_WRG", lateral_offset_m=0.0, length_m=50.0)

    wrong_side = FakeWorldObject(
        "WRONG_SIDE", "CAR",
        x=25.0, y=0.0, vx=-12.0, vy=0.0,  # head-on
        ttc_s=1.5, ttc_status="FINITE",
        min_distance_m=0.5, collision_likelihood=0.85,
    )
    wm = FakeWorldModelSnapshot(objects=[wrong_side])
    result = engine.evaluate([candidate], wm, frame_id=61)
    risk = result.risks[0]

    assert risk.total_risk > 0.5
    assert risk.risk_level.value in ("HIGH_RISK", "CRITICAL_RISK")


# ---------------------------------------------------------------------------
# Scenario: damaged_narrow_road
# ---------------------------------------------------------------------------

def test_damaged_narrow_road():
    """Multiple potholes on narrow road → elevated road hazard risk."""
    engine = _engine()
    candidate = make_candidate("PATH_DMG", lateral_offset_m=0.0, length_m=30.0)

    anomalies = [
        FakeAnomaly(f"DMG_{i}", "POTHOLE",
                    position_x=5.0 + i * 4.0, position_y=0.1,
                    severity="SEVERE")
        for i in range(3)
    ]
    wm = FakeWorldModelSnapshot(objects=[], anomalies=anomalies)
    result = engine.evaluate([candidate], wm, frame_id=62)
    risk = result.risks[0]

    assert risk.breakdown.road_hazard_risk > 0.0
    assert RiskReasonCode.ROAD_HAZARD_INTERACTION in risk.reason_codes


# ---------------------------------------------------------------------------
# Scenario: motorcycle_swarm
# ---------------------------------------------------------------------------

def test_motorcycle_swarm():
    """Multiple motorcycles around candidate path."""
    engine = _engine()
    candidate = make_candidate("PATH_SWRM", lateral_offset_m=0.0)

    motos = [
        FakeWorldObject(f"MOTO_{i}", "MOTORCYCLE",
                        x=5.0 + i * 3.0, y=(-1)**i * 0.8,
                        ttc_s=1.5 + i * 0.3, ttc_status="FINITE",
                        collision_likelihood=0.4 - i * 0.05)
        for i in range(5)
    ]
    wm = FakeWorldModelSnapshot(objects=motos)
    result = engine.evaluate([candidate], wm, frame_id=63)
    risk = result.risks[0]

    assert risk.dynamic_object_count == 5
    assert risk.total_risk > 0.2
