import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))

from core.perception.perception_types import Position3D, SourceSensor
from core.fusion.fusion_types import (
    FusedObject, FusedWorldState, FusionMode, ConflictState,
    ObjectLifecycleState, source_label, NOT_AVAILABLE,
)


def test_fused_object_to_dict_reports_not_available_for_missing_fields():
    obj = FusedObject(
        fused_object_id="fused_1", object_class="car", class_confidence=0.8,
        position_3d=None, velocity=None, dimensions=None, heading=None,
        distance=None, bbox_2d=None, source_sensors=frozenset({SourceSensor.CAMERA}),
    )
    d = obj.to_dict()
    assert d["position_3d"] == NOT_AVAILABLE
    assert d["velocity"] == NOT_AVAILABLE
    assert d["track_id"] == NOT_AVAILABLE


def test_fused_object_sensor_count_matches_sources():
    obj = FusedObject(
        fused_object_id="fused_2", object_class="car", class_confidence=0.8,
        position_3d=Position3D(1, 2, 3), velocity=None, dimensions=None, heading=None,
        distance=None, bbox_2d=None,
        source_sensors=frozenset({SourceSensor.CAMERA, SourceSensor.LIDAR}),
    )
    assert obj.sensor_count == 2
    assert obj.to_dict()["source_sensors"] == "CAMERA+LIDAR"


def test_source_label_orders_camera_lidar_radar():
    label = source_label(frozenset({SourceSensor.RADAR, SourceSensor.CAMERA}))
    assert label == "CAMERA+RADAR"


def test_source_label_empty_is_not_available():
    assert source_label(frozenset()) == NOT_AVAILABLE


def test_fused_world_state_defaults_to_no_valid_sensor():
    ws = FusedWorldState(timestamp=1.0, frame_id=1)
    assert ws.fusion_mode == FusionMode.NO_VALID_SENSOR
    d = ws.to_dict()
    assert d["objects"] == []
    assert d["fusion_mode"] == "NO_VALID_SENSOR"


def test_conflict_and_lifecycle_enums_serialize_as_plain_strings():
    obj = FusedObject(
        fused_object_id="fused_3", object_class="car", class_confidence=0.5,
        position_3d=None, velocity=None, dimensions=None, heading=None,
        distance=None, bbox_2d=None, conflict_state=ConflictState.MAJOR_CONFLICT,
        lifecycle_state=ObjectLifecycleState.CONFIRMED,
    )
    d = obj.to_dict()
    assert d["conflict_state"] == "MAJOR_CONFLICT"
    assert d["lifecycle_state"] == "CONFIRMED"
