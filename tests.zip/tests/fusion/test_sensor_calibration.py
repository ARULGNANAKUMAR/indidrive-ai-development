import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))

from core.fusion.sensor_calibration import SensorCalibration


def test_default_calibration_reports_not_configured_for_all_sensors():
    calib = SensorCalibration(None)
    for sensor in ("camera", "lidar", "radar"):
        entry = calib.get(sensor)
        assert entry.configured is False
        assert entry.status == "NOT_CONFIGURED"


def test_calibration_report_shape():
    calib = SensorCalibration(None)
    report = calib.report()
    assert set(report.keys()) == {"camera", "lidar", "radar"}
    assert report["camera"]["configured"] is False


def test_configured_camera_calibration_loads_intrinsics_and_extrinsics():
    raw = {"calibration": {"camera": {
        "configured": True,
        "extrinsics": {"translation": [0, 0, 1.5], "rotation_rpy": [0, 0, 0]},
        "intrinsics": {"fx": 500, "fy": 500, "cx": 320, "cy": 240,
                        "image_width": 640, "image_height": 480},
    }}}
    calib = SensorCalibration(raw)
    entry = calib.get("camera")
    assert entry.configured is True
    assert entry.intrinsics.fx == 500
    assert entry.extrinsics.translation == (0, 0, 1.5)


def test_is_configured_helper():
    calib = SensorCalibration({"calibration": {"lidar": {"configured": True, "file": "lidar.yaml"}}})
    assert calib.is_configured("lidar") is True
    assert calib.is_configured("radar") is False
