import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))

from core.fusion.timestamp_alignment import TimestampAligner, SyncConfig
from core.fusion.fusion_types import SyncStatus


def test_perfect_synchronization_all_ok():
    aligner = TimestampAligner()
    result = aligner.align({"camera": 100.000, "lidar": 100.001, "radar": None})
    assert result.status["camera"] == SyncStatus.OK
    assert result.status["lidar"] == SyncStatus.OK
    assert result.status["radar"] == SyncStatus.MISSING
    assert result.synchronization_quality > 0.5


def test_small_timestamp_difference_within_window_is_ok():
    aligner = TimestampAligner(SyncConfig(max_timestamp_delta_ms=50))
    result = aligner.align({"camera": 100.000, "lidar": 100.020, "radar": None})
    assert result.status["lidar"] == SyncStatus.OK


def test_large_timestamp_difference_marks_stale():
    aligner = TimestampAligner(SyncConfig(max_timestamp_delta_ms=50, stale_threshold_ms=200))
    # lidar (100.5) is numerically newest -> becomes the reference;
    # camera (100.0) is 500ms behind it -> stale relative to reference.
    result = aligner.align({"camera": 100.000, "lidar": 100.5, "radar": None})
    assert result.status["camera"] == SyncStatus.STALE
    assert any("stale" in w for w in result.warnings)


def test_stale_frame_beyond_stale_threshold_still_reported_as_stale():
    aligner = TimestampAligner(SyncConfig(max_timestamp_delta_ms=50, stale_threshold_ms=200))
    result = aligner.align({"camera": 100.000, "lidar": 105.0, "radar": None})
    assert result.status["camera"] == SyncStatus.STALE


def test_missing_sensor_reported_missing_not_fabricated():
    aligner = TimestampAligner()
    result = aligner.align({"camera": 100.0, "lidar": None, "radar": None})
    assert result.status["lidar"] == SyncStatus.MISSING
    assert result.status["radar"] == SyncStatus.MISSING


def test_all_missing_returns_zero_quality_and_no_reference():
    aligner = TimestampAligner()
    result = aligner.align({"camera": None, "lidar": None, "radar": None})
    assert result.reference_timestamp is None
    assert result.synchronization_quality == 0.0
    assert result.usable_sensors() == []


def test_out_of_order_frame_uses_max_as_reference():
    aligner = TimestampAligner()
    # lidar timestamp arrives "before" camera in dict order but is
    # numerically later -> reference should track the newest data.
    result = aligner.align({"camera": 90.0, "lidar": 95.0, "radar": None})
    assert result.reference_timestamp == 95.0


def test_duplicate_frame_timestamp_is_perfectly_synchronized():
    aligner = TimestampAligner()
    result = aligner.align({"camera": 42.0, "lidar": 42.0, "radar": None})
    assert result.status["camera"] == SyncStatus.OK
    assert result.status["lidar"] == SyncStatus.OK
    assert result.deltas_ms["camera"] == 0.0
