import sys
import time
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))

from core.perception.perception_manager import PerceptionManager
from core.perception.object_detection import MockBackend
from core.perception.perception_types import (
    PerceptionObject, SourceSensor, Position3D, Dimensions3D, BoundingBox2D,
)
from core.fusion.data_association import DataAssociator
from core.fusion.object_fusion import ObjectFusion
from core.fusion.fusion_manager import FusionManager


def test_camera_and_lidar_object_fuse_into_one_multi_sensor_object():
    cam = PerceptionObject(
        object_id="c1", object_class="car", raw_class="car", confidence=0.85, raw_confidence=0.85,
        source_sensor=SourceSensor.CAMERA, timestamp=1.0,
        bbox_2d=BoundingBox2D(10, 10, 50, 40), distance=12.0,
    )
    lid = PerceptionObject(
        object_id="l1", object_class="car", raw_class="car", confidence=0.7, raw_confidence=0.7,
        source_sensor=SourceSensor.LIDAR, timestamp=1.0,
        position_3d=Position3D(12.0, 0.0, 0.0), dimensions_3d=Dimensions3D(4.2, 1.8, 1.6), distance=12.0,
    )
    associations = DataAssociator().associate({"camera": [cam], "lidar": [lid], "radar": []})
    fused = [ObjectFusion().fuse(a, timestamp=1.0) for a in associations]
    assert len(fused) == 1
    obj = fused[0]
    assert obj.sensor_count == 2
    assert obj.position_3d is not None          # position came from LiDAR
    assert obj.bbox_2d is not None               # class/box came from camera
    assert obj.dimensions is not None


def test_single_sensor_object_stays_single_sensor():
    lid = PerceptionObject(
        object_id="l2", object_class="unknown", raw_class="unknown", confidence=0.6, raw_confidence=0.6,
        source_sensor=SourceSensor.LIDAR, timestamp=1.0, position_3d=Position3D(5, 0, 0),
    )
    associations = DataAssociator().associate({"camera": [], "lidar": [lid], "radar": []})
    fused = [ObjectFusion().fuse(a, timestamp=1.0) for a in associations]
    assert len(fused) == 1
    assert fused[0].sensor_count == 1


def test_full_perception_manager_to_fusion_manager_pipeline_runs_end_to_end():
    pmgr = PerceptionManager()
    pmgr.initialize()
    pmgr.engine.camera._detector = MockBackend(n_detections=1)
    pmgr.engine.camera._detector.load_model()

    img = np.zeros((480, 640, 3), dtype=np.uint8)
    rng = np.random.default_rng(1)
    pts = rng.uniform(-5, 5, size=(200, 4)).astype(np.float32)
    pts[:, 3] = np.abs(pts[:, 3])

    ts = time.time()
    frame = pmgr.process_frame(camera_image=img, camera_timestamp=ts, lidar_points=pts, lidar_timestamp=ts)

    fmgr = FusionManager()
    world_state = fmgr.process(frame)

    assert world_state.frame_id == 1
    assert world_state.fusion_mode.value in ("PARTIAL_FUSION", "FULL_FUSION", "SINGLE_SENSOR")
    assert world_state.metrics.fusion_latency_ms >= 0.0
    assert fmgr.get_latest_world_state() is world_state
