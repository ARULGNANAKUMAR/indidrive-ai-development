import sys
import time
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))

from core.perception.perception_manager import PerceptionManager
from core.perception.object_detection import MockBackend
from core.fusion.fusion_manager import FusionManager
from core.fusion.utils import replay_perception_frames


def _make_frames(n=4):
    pmgr = PerceptionManager()
    pmgr.initialize()
    pmgr.engine.camera._detector = MockBackend(n_detections=1)
    pmgr.engine.camera._detector.load_model()
    img = np.zeros((480, 640, 3), dtype=np.uint8)
    rng = np.random.default_rng(7)
    frames = []
    sensor_timestamps = []
    base_ts = 1000.0
    for i in range(n):
        pts = rng.uniform(-5, 5, size=(100, 4)).astype(np.float32)
        pts[:, 3] = np.abs(pts[:, 3])
        ts = base_ts + i * 0.1
        frames.append(pmgr.process_frame(camera_image=img, camera_timestamp=ts,
                                          lidar_points=pts, lidar_timestamp=ts))
        sensor_timestamps.append(ts)
    return frames, sensor_timestamps


def test_replay_preserves_original_frame_timestamps():
    # Phase 2's PerceptionFrame.timestamp is a wall-clock processing
    # stamp (see PerceptionManager.process_frame), not the sensor
    # capture time -- so fusion anchors each cycle to the actual
    # per-object sensor timestamps it was given, which is what this
    # checks (never a fabricated or dropped timestamp).
    frames, sensor_timestamps = _make_frames(3)
    fm = FusionManager()
    results = replay_perception_frames(frames, fm)
    assert len(results) == 3
    for expected_ts, fused in zip(sensor_timestamps, results):
        assert abs(fused.timestamp - expected_ts) < 1e-6


def test_replay_produces_monotonically_increasing_frame_ids():
    frames, _ = _make_frames(3)
    fm = FusionManager()
    results = replay_perception_frames(frames, fm)
    ids = [r.frame_id for r in results]
    assert ids == sorted(ids)
    assert ids == [1, 2, 3]


def test_replay_history_matches_replayed_count():
    frames, _ = _make_frames(4)
    fm = FusionManager(history_size=10)
    replay_perception_frames(frames, fm)
    assert len(fm.get_history()) == 4
