import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))

from core.perception.perception_types import PerceptionObject, SourceSensor, Position3D
from core.fusion.data_association import DataAssociator
from core.fusion.object_fusion import ObjectFusion
from core.fusion.fusion_types import FusionMode
from core.fusion.fusion_engine import FusionEngine
from core.perception.perception_manager import PerceptionManager


def test_radar_pipeline_reports_not_available_no_fake_detections():
    from core.perception.radar_perception import RadarPerceptionPipeline
    pipeline = RadarPerceptionPipeline()
    assert pipeline.is_available() is False
    result = pipeline.process(None, timestamp=0.0)
    assert result.objects == []
    assert result.status == "NOT_AVAILABLE"


def test_fusion_engine_with_no_radar_configured_never_reports_full_fusion():
    pmgr = PerceptionManager()
    frame = pmgr.process_frame()  # no camera/lidar/radar input at all
    engine = FusionEngine()
    world_state = engine.process(frame)
    assert world_state.sync_status["radar"] == "MISSING"
    assert world_state.fusion_mode != FusionMode.FULL_FUSION


def test_radar_object_when_present_contributes_measured_velocity_only():
    # Exercises the association+fusion path a real radar object would
    # take, without fabricating radar hardware/data (this repo has none —
    # see radar_perception.py). Uses a synthetic PerceptionObject tagged
    # SourceSensor.RADAR the same shape a real radar pipeline would emit.
    lid = PerceptionObject(
        object_id="l1", object_class="car", raw_class="car", confidence=0.7, raw_confidence=0.7,
        source_sensor=SourceSensor.LIDAR, timestamp=1.0, position_3d=Position3D(10, 0, 0), distance=10.0,
    )
    radar = PerceptionObject(
        object_id="r1", object_class="car", raw_class="car", confidence=0.6, raw_confidence=0.6,
        source_sensor=SourceSensor.RADAR, timestamp=1.0, distance=10.0, velocity=(-2.0, 0.0, 0.0),
    )
    associations = DataAssociator().associate({"camera": [], "lidar": [lid], "radar": [radar]})
    fused = [ObjectFusion().fuse(a, timestamp=1.0) for a in associations]
    matched = [f for f in fused if f.sensor_count == 2]
    assert len(matched) == 1
    assert matched[0].velocity == (-2.0, 0.0, 0.0)
    assert matched[0].velocity_confidence > 0.0
