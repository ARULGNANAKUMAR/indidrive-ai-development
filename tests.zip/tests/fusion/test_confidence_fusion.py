import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))

from core.perception.perception_types import PerceptionObject, SourceSensor, Position3D
from core.fusion.confidence_fusion import ConfidenceFusion
from core.fusion.fusion_types import ConflictState


def _obj(sensor, obj_class="car", confidence=0.8, velocity=None):
    return PerceptionObject(
        object_id=f"{sensor}_1", object_class=obj_class, raw_class=obj_class,
        confidence=confidence, raw_confidence=confidence,
        source_sensor=SourceSensor(sensor), timestamp=0.0,
        position_3d=Position3D(1, 1, 1), velocity=velocity,
    )


def test_multi_sensor_agreement_raises_existence_probability_above_either_alone():
    cf = ConfidenceFusion()
    single = cf.fuse({"camera": _obj("camera", confidence=0.6)})
    multi = cf.fuse({"camera": _obj("camera", confidence=0.6), "lidar": _obj("lidar", confidence=0.6)})
    assert multi.existence_probability > single.existence_probability


def test_conflicting_classes_marked_as_conflict():
    cf = ConfidenceFusion()
    result = cf.fuse({"camera": _obj("camera", obj_class="car"), "lidar": _obj("lidar", obj_class="cattle")})
    assert result.conflict_state != ConflictState.CONSISTENT


def test_consistent_classes_marked_consistent():
    cf = ConfidenceFusion()
    result = cf.fuse({"camera": _obj("camera", obj_class="car"), "lidar": _obj("lidar", obj_class="car")})
    assert result.conflict_state == ConflictState.CONSISTENT


def test_velocity_confidence_zero_without_velocity_measurement():
    cf = ConfidenceFusion()
    result = cf.fuse({"camera": _obj("camera"), "lidar": _obj("lidar")})
    assert result.velocity_confidence == 0.0


def test_radar_velocity_yields_highest_velocity_confidence():
    cf = ConfidenceFusion()
    result = cf.fuse({"radar": _obj("radar", velocity=(1.0, 0.0, 0.0))})
    assert result.velocity_confidence > 0.0


def test_low_synchronization_quality_reduces_overall_quality():
    cf = ConfidenceFusion()
    good_sync = cf.fuse({"camera": _obj("camera")}, synchronization_quality=1.0)
    bad_sync = cf.fuse({"camera": _obj("camera")}, synchronization_quality=0.2)
    assert bad_sync.overall_quality < good_sync.overall_quality


def test_empty_members_returns_zero_confidence_and_unresolved():
    cf = ConfidenceFusion()
    result = cf.fuse({})
    assert result.overall_quality == 0.0
    assert result.conflict_state == ConflictState.UNRESOLVED
