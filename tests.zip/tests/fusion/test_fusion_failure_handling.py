import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))

from core.perception.perception_manager import PerceptionManager
from core.fusion.fusion_engine import FusionEngine
from core.fusion.fusion_types import FusionMode
from core.perception.perception_types import HealthState


def test_camera_unavailable_falls_back_to_lidar_only():
    pmgr = PerceptionManager()
    import numpy as np
    rng = np.random.default_rng(2)
    pts = rng.uniform(-5, 5, size=(150, 4)).astype(np.float32)
    pts[:, 3] = np.abs(pts[:, 3])
    frame = pmgr.process_frame(lidar_points=pts, lidar_timestamp=1.0)
    engine = FusionEngine()
    ws = engine.process(frame)
    assert ws.fusion_mode in (FusionMode.SINGLE_SENSOR, FusionMode.NO_VALID_SENSOR)
    assert ws.sync_status["camera"] == "MISSING"


def test_lidar_unavailable_falls_back_to_camera_only():
    from core.perception.object_detection import MockBackend
    import numpy as np
    pmgr = PerceptionManager()
    pmgr.initialize()
    pmgr.engine.camera._detector = MockBackend(n_detections=1)
    pmgr.engine.camera._detector.load_model()
    img = np.zeros((480, 640, 3), dtype=np.uint8)
    frame = pmgr.process_frame(camera_image=img, camera_timestamp=1.0)
    engine = FusionEngine()
    ws = engine.process(frame)
    assert ws.sync_status["lidar"] == "MISSING"


def test_all_sensors_unavailable_is_no_valid_perception_but_does_not_crash():
    pmgr = PerceptionManager()
    frame = pmgr.process_frame()
    engine = FusionEngine()
    ws = engine.process(frame)
    assert ws.fusion_mode == FusionMode.NO_VALID_SENSOR
    assert ws.fusion_health == HealthState.FAILED
    assert ws.objects == []


def test_corrupt_perception_frame_with_malformed_object_does_not_crash_engine():
    from core.perception.perception_types import PerceptionFrame, PerceptionObject, SourceSensor
    frame = PerceptionFrame(timestamp=1.0, frame_id=1)
    frame.objects.append(PerceptionObject(
        object_id="bad", object_class="unknown", raw_class="unknown",
        confidence=float("nan"), raw_confidence=0.0,
        source_sensor=SourceSensor.CAMERA, timestamp=1.0,
    ))
    engine = FusionEngine()
    ws = engine.process(frame)  # must not raise
    assert isinstance(ws.objects, list)


def test_invalid_calibration_does_not_block_fusion_only_reports_not_configured():
    pmgr = PerceptionManager()
    frame = pmgr.process_frame()
    engine = FusionEngine(raw_config={"calibration": {"camera": {"configured": "not-a-bool"}}})
    ws = engine.process(frame)  # must not raise despite malformed calibration value
    assert ws is not None


def test_fusion_disabled_via_config_reports_not_configured_health():
    from core.fusion.fusion_engine import FusionEngineConfig
    pmgr = PerceptionManager()
    frame = pmgr.process_frame()
    engine = FusionEngine(FusionEngineConfig(enabled=False))
    ws = engine.process(frame)
    assert ws.fusion_health == HealthState.NOT_CONFIGURED
    assert "fusion disabled" in " ".join(ws.warnings)
