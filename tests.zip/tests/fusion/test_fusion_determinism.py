import sys
import time
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))

from core.perception.perception_manager import PerceptionManager
from core.perception.object_detection import MockBackend
from core.fusion.fusion_engine import FusionEngine


def _frame_from_fixed_input():
    pmgr = PerceptionManager()
    pmgr.initialize()
    pmgr.engine.camera._detector = MockBackend(n_detections=2)
    pmgr.engine.camera._detector.load_model()
    img = np.zeros((480, 640, 3), dtype=np.uint8)
    rng = np.random.default_rng(99)
    pts = rng.uniform(-5, 5, size=(120, 4)).astype(np.float32)
    pts[:, 3] = np.abs(pts[:, 3])
    ts = 1234.5
    return pmgr.process_frame(camera_image=img, camera_timestamp=ts, lidar_points=pts, lidar_timestamp=ts)


def test_same_input_produces_same_object_count_and_classes_across_runs():
    frame_a = _frame_from_fixed_input()
    frame_b = _frame_from_fixed_input()

    ws_a = FusionEngine().process(frame_a)
    ws_b = FusionEngine().process(frame_b)

    assert len(ws_a.objects) == len(ws_b.objects)
    classes_a = sorted(o.object_class for o in ws_a.objects)
    classes_b = sorted(o.object_class for o in ws_b.objects)
    assert classes_a == classes_b


def test_same_input_produces_same_fusion_mode_and_sync_status():
    frame_a = _frame_from_fixed_input()
    frame_b = _frame_from_fixed_input()
    ws_a = FusionEngine().process(frame_a)
    ws_b = FusionEngine().process(frame_b)
    assert ws_a.fusion_mode == ws_b.fusion_mode
    assert ws_a.sync_status == ws_b.sync_status


def test_no_randomness_in_association_or_confidence_given_identical_objects():
    """Feeding the exact same PerceptionFrame object through two fresh
    engines must give numerically identical confidence/position outputs
    -- nothing in core/fusion samples from a PRNG."""
    frame = _frame_from_fixed_input()
    ws_a = FusionEngine().process(frame)
    ws_b = FusionEngine().process(frame)
    qualities_a = sorted(round(o.quality, 6) for o in ws_a.objects)
    qualities_b = sorted(round(o.quality, 6) for o in ws_b.objects)
    assert qualities_a == qualities_b
