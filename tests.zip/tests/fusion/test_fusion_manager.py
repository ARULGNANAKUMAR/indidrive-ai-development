import sys
import time
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))

from core.perception.perception_manager import PerceptionManager
from core.perception.object_detection import MockBackend
from core.fusion.fusion_manager import FusionManager


def test_fusion_manager_initializes_with_default_config():
    fm = FusionManager()
    fm.initialize()
    assert fm.engine is not None
    assert fm.get_latest_world_state() is None
    fm.shutdown()


def test_process_from_perception_manager_returns_none_when_nothing_processed():
    pmgr = PerceptionManager()
    fm = FusionManager()
    assert fm.process_from_perception_manager(pmgr) is None


def test_process_from_perception_manager_bridges_latest_frame():
    pmgr = PerceptionManager()
    pmgr.process_frame()
    fm = FusionManager()
    ws = fm.process_from_perception_manager(pmgr)
    assert ws is not None
    assert fm.get_latest_world_state() is ws


def test_fusion_world_state_history_is_bounded():
    fm = FusionManager(history_size=3)
    pmgr = PerceptionManager()
    for _ in range(5):
        frame = pmgr.process_frame()
        fm.process(frame)
    assert len(fm.get_history()) == 3


def test_get_health_before_any_processing_is_not_configured():
    fm = FusionManager()
    health = fm.get_health()
    assert health["fusion_health"] == "NOT_CONFIGURED"


def test_get_health_and_metrics_after_processing():
    fm = FusionManager()
    pmgr = PerceptionManager()
    pmgr.initialize()
    pmgr.engine.camera._detector = MockBackend(n_detections=1)
    pmgr.engine.camera._detector.load_model()
    img = np.zeros((480, 640, 3), dtype=np.uint8)
    frame = pmgr.process_frame(camera_image=img, camera_timestamp=time.time())
    fm.process(frame)
    health = fm.get_health()
    assert health["fusion_health"] in ("HEALTHY", "DEGRADED", "FAILED")
    metrics = fm.get_metrics()
    assert "fusion_latency_ms" in metrics


def test_reset_clears_history_but_stays_initialized():
    fm = FusionManager()
    pmgr = PerceptionManager()
    frame = pmgr.process_frame()
    fm.process(frame)
    assert len(fm.get_history()) == 1
    fm.reset()
    assert len(fm.get_history()) == 0
    assert fm._initialized is True
