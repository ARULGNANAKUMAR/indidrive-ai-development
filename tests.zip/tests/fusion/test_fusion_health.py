import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))

from core.perception.perception_types import HealthState
from core.fusion.fusion_health import FusionHealthMonitor
from core.fusion.fusion_types import FusionMode


def test_no_active_sensors_is_failed_and_no_valid_sensor():
    monitor = FusionHealthMonitor()
    report = monitor.assess(active_sensors=set(), synchronization_quality=0.0,
                             fusion_latency_ms=1.0, calibration_report={})
    assert report.state == HealthState.FAILED
    assert report.fusion_mode == FusionMode.NO_VALID_SENSOR


def test_single_sensor_is_degraded_single_sensor_mode():
    monitor = FusionHealthMonitor()
    report = monitor.assess(active_sensors={"lidar"}, synchronization_quality=1.0,
                             fusion_latency_ms=1.0, calibration_report={})
    assert report.fusion_mode == FusionMode.SINGLE_SENSOR
    assert report.state == HealthState.DEGRADED


def test_two_sensors_healthy_partial_fusion():
    monitor = FusionHealthMonitor()
    report = monitor.assess(active_sensors={"camera", "lidar"}, synchronization_quality=0.9,
                             fusion_latency_ms=5.0, calibration_report={})
    assert report.fusion_mode == FusionMode.PARTIAL_FUSION
    assert report.state == HealthState.HEALTHY


def test_three_sensors_full_fusion():
    monitor = FusionHealthMonitor()
    report = monitor.assess(active_sensors={"camera", "lidar", "radar"}, synchronization_quality=0.95,
                             fusion_latency_ms=5.0, calibration_report={})
    assert report.fusion_mode == FusionMode.FULL_FUSION


def test_high_latency_degrades_health():
    monitor = FusionHealthMonitor(max_latency_ms=10.0)
    report = monitor.assess(active_sensors={"camera", "lidar"}, synchronization_quality=1.0,
                             fusion_latency_ms=999.0, calibration_report={})
    assert report.state == HealthState.DEGRADED
    assert any("latency" in r for r in report.reasons)


def test_low_sync_quality_degrades_health():
    monitor = FusionHealthMonitor(min_sync_quality=0.5)
    report = monitor.assess(active_sensors={"camera", "lidar"}, synchronization_quality=0.1,
                             fusion_latency_ms=1.0, calibration_report={})
    assert report.state == HealthState.DEGRADED


def test_missing_calibration_adds_warning_but_not_necessarily_degraded():
    monitor = FusionHealthMonitor()
    calib_report = {"camera": {"configured": False}, "lidar": {"configured": False}}
    report = monitor.assess(active_sensors={"camera", "lidar"}, synchronization_quality=1.0,
                             fusion_latency_ms=1.0, calibration_report=calib_report)
    assert any("calibration" in r for r in report.reasons)
