import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))

from core.perception.perception_types import (
    PerceptionObject, SourceSensor, BoundingBox2D, Position3D,
)
from core.fusion.data_association import DataAssociator, AssociationConfig


def _cam(obj_class="car", ts=0.0, bbox=None, distance=None, obj_id="c1"):
    return PerceptionObject(
        object_id=obj_id, object_class=obj_class, raw_class=obj_class, confidence=0.8,
        raw_confidence=0.8, source_sensor=SourceSensor.CAMERA, timestamp=ts,
        bbox_2d=bbox, distance=distance,
    )


def _lidar(obj_class="car", ts=0.0, position=None, distance=None, obj_id="l1"):
    return PerceptionObject(
        object_id=obj_id, object_class=obj_class, raw_class=obj_class, confidence=0.7,
        raw_confidence=0.7, source_sensor=SourceSensor.LIDAR, timestamp=ts,
        position_3d=position, distance=distance,
    )


def test_clear_match_by_position_and_distance():
    cam = _cam(distance=10.0)
    lid = _lidar(position=Position3D(10.0, 0.0, 0.0), distance=10.0)
    assoc = DataAssociator().associate({"camera": [cam], "lidar": [lid], "radar": []})
    fused_groups = [a for a in assoc if len(a.members) == 2]
    assert len(fused_groups) == 1
    assert set(fused_groups[0].members.keys()) == {"camera", "lidar"}


def test_multiple_candidates_picks_lowest_cost():
    cam = _cam(distance=10.0)
    near = _lidar(position=Position3D(10.0, 0.0, 0.0), distance=10.0, obj_id="near")
    far = _lidar(position=Position3D(10.0, 0.0, 0.0), distance=14.0, obj_id="far")
    assoc = DataAssociator().associate({"camera": [cam], "lidar": [near, far], "radar": []})
    matched = [a for a in assoc if len(a.members) == 2][0]
    assert matched.members["lidar"].object_id == "near"


def test_no_match_when_nothing_geometric_in_common():
    cam = _cam()  # no bbox given here (bbox is set), remove position/distance signal entirely
    cam_no_geo = PerceptionObject(
        object_id="c2", object_class="car", raw_class="car", confidence=0.8,
        raw_confidence=0.8, source_sensor=SourceSensor.CAMERA, timestamp=0.0,
    )
    lidar_no_geo = PerceptionObject(
        object_id="l2", object_class="car", raw_class="car", confidence=0.7,
        raw_confidence=0.7, source_sensor=SourceSensor.LIDAR, timestamp=0.0,
    )
    assoc = DataAssociator().associate({"camera": [cam_no_geo], "lidar": [lidar_no_geo], "radar": []})
    assert all(len(a.members) == 1 for a in assoc)


def test_wrong_class_increases_cost_but_does_not_block_by_itself():
    cam = _cam(obj_class="car", distance=10.0)
    lid = _lidar(obj_class="truck", position=Position3D(10.0, 0.0, 0.0), distance=10.0)
    assoc = DataAssociator(AssociationConfig(max_cost=2.0)).associate(
        {"camera": [cam], "lidar": [lid], "radar": []})
    matched = [a for a in assoc if len(a.members) == 2]
    assert len(matched) == 1  # still associates -- class alone never gates (spec section 12)


def test_large_distance_rejects_match():
    cam = _cam(distance=10.0)
    lid = _lidar(position=Position3D(50.0, 0.0, 0.0), distance=50.0)
    assoc = DataAssociator(AssociationConfig(max_position_distance_m=3.0)).associate(
        {"camera": [cam], "lidar": [lid], "radar": []})
    assert all(len(a.members) == 1 for a in assoc)


def test_low_iou_between_two_camera_like_boxes_with_no_depth_rejected():
    a = _cam(bbox=BoundingBox2D(0, 0, 10, 10), obj_id="a")
    b = _cam(bbox=BoundingBox2D(500, 500, 10, 10), obj_id="b")
    assoc = DataAssociator().associate({"camera": [a, b], "lidar": [], "radar": []})
    # same-sensor objects are never cross-associated with each other anyway
    assert len(assoc) == 2


def test_depth_mismatch_beyond_threshold_rejects_match():
    cam = _cam(distance=10.0)
    lid = _lidar(position=Position3D(10.0, 0.0, 0.0), distance=25.0)
    assoc = DataAssociator(AssociationConfig(max_depth_error_m=5.0)).associate(
        {"camera": [cam], "lidar": [lid], "radar": []})
    assert all(len(a.members) == 1 for a in assoc)


def test_timestamp_mismatch_beyond_threshold_rejects_match():
    cam = _cam(distance=10.0, ts=0.0)
    lid = _lidar(position=Position3D(10.0, 0.0, 0.0), distance=10.0, ts=5.0)
    assoc = DataAssociator(AssociationConfig(max_timestamp_delta_s=0.2)).associate(
        {"camera": [cam], "lidar": [lid], "radar": []})
    assert all(len(a.members) == 1 for a in assoc)
