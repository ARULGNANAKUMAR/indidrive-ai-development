import math
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))

from core.fusion.sensor_calibration import SensorCalibration
from core.fusion.coordinate_transform import Transform3D, CoordinateTransformer


def test_identity_transform_leaves_point_unchanged():
    t = Transform3D.identity()
    p = t.apply((1.0, 2.0, 3.0))
    assert p == (1.0, 2.0, 3.0)


def test_translation_only_transform():
    t = Transform3D(rotation=[[1, 0, 0], [0, 1, 0], [0, 0, 1]], translation=(1.0, -2.0, 0.5))
    p = t.apply((0.0, 0.0, 0.0))
    assert p == (1.0, -2.0, 0.5)


def test_rotation_yaw_90_degrees():
    from core.fusion.coordinate_transform import _rotation_matrix, _matvec
    r = _rotation_matrix((0.0, 0.0, math.pi / 2))
    x, y, z = _matvec(r, (1.0, 0.0, 0.0))
    assert math.isclose(x, 0.0, abs_tol=1e-9)
    assert math.isclose(y, 1.0, abs_tol=1e-9)


def _configured_camera_calibration():
    raw = {
        "calibration": {
            "camera": {
                "configured": True,
                "extrinsics": {"translation": [0.0, 0.0, 0.0], "rotation_rpy": [0.0, 0.0, 0.0]},
                "intrinsics": {"fx": 600.0, "fy": 600.0, "cx": 320.0, "cy": 240.0,
                                "image_width": 640, "image_height": 480},
            },
            "lidar": {"configured": False, "file": ""},
            "radar": {"configured": False, "file": ""},
        }
    }
    return SensorCalibration(raw)


def test_camera_projection_with_configured_calibration():
    calib = _configured_camera_calibration()
    transformer = CoordinateTransformer(calib)
    pixel, status = transformer.project_to_camera((0.0, 0.0, 5.0))
    assert status == "OK"
    u, v, z = pixel
    assert math.isclose(u, 320.0, abs_tol=1e-6)  # centered point projects to principal point
    assert z == 5.0


def test_camera_projection_without_calibration_reports_not_configured():
    calib = SensorCalibration({"calibration": {}})
    transformer = CoordinateTransformer(calib)
    result, status = transformer.project_to_camera((0.0, 0.0, 5.0))
    assert result is None
    assert status == "NOT_CONFIGURED"


def test_invalid_point_behind_camera_is_rejected():
    calib = _configured_camera_calibration()
    transformer = CoordinateTransformer(calib)
    result, status = transformer.project_to_camera((0.0, 0.0, -3.0))
    assert result is None
    assert status == "BEHIND_CAMERA"


def test_point_outside_image_bounds_is_rejected():
    calib = _configured_camera_calibration()
    transformer = CoordinateTransformer(calib)
    # far off to the side -> projects way outside a 640-wide image
    result, status = transformer.project_to_camera((100.0, 0.0, 1.0))
    assert result is None
    assert status == "OUTSIDE_IMAGE"


def test_sensor_to_vehicle_without_extrinsics_not_configured():
    calib = SensorCalibration({"calibration": {}})
    transformer = CoordinateTransformer(calib)
    result, status = transformer.sensor_to_vehicle("lidar", (1.0, 1.0, 1.0))
    assert result is None
    assert status == "NOT_CONFIGURED"


def test_vehicle_to_world_without_ego_pose_not_available():
    calib = SensorCalibration({"calibration": {}})
    transformer = CoordinateTransformer(calib)
    result, status = transformer.vehicle_to_world((1.0, 1.0, 1.0))
    assert result is None
    assert status == "NOT_AVAILABLE"
