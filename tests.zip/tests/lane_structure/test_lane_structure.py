"""
IndiDrive AI — Phase 6.2 Test Suite: Lane & Road-Structure Understanding.

All tests use synthetic data only — no CARLA, no network, no real sensor
required.  Follows the style of tests/road_understanding/test_road_understanding.py.

Coverage:
  - Basic structure (valid / empty / unavailable / disabled)
  - Lane markings (solid / dashed / unknown / missing / weak)
  - Lane boundaries (single / two-lane / curved / asymmetric / partial)
  - Centreline (valid / insufficient data / curved)
  - Unmarked roads (village / narrow / wide / asymmetric / partial)
  - Lane count (1 / 2 / unknown)
  - Lane width (valid / narrow / missing / invalid)
  - Road curvature (straight / left / right / changing)
  - Intersection hint (normal / detected / unknown)
  - Sensor degradation (camera only / lidar only / both missing / stale)
  - Confidence (high / low / missing)
  - Geometry validation (NaN / Inf / impossible width)
  - Phase 6.1 consistency
  - Determinism
"""
from __future__ import annotations

import math
import sys
from pathlib import Path

import numpy as np
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))

from core.perception.lane_structure import LaneStructureEngine, LaneStructureConfig
from core.perception.lane_structure_types import (
    LaneStructure, LaneStructureStatus,
    MarkingStatus, MarkingType, EvidenceKind, RoadTypeHint, IntersectionState,
    LaneBoundary, LaneBoundaryPoint, LaneCenterline, CenterlinePoint, LaneDescriptor,
)
from core.perception.road_understanding import RoadUnderstandingPipeline, RoadUnderstandingConfig
from core.perception.road_understanding_types import (
    RoadUnderstanding, RoadUnderstandingStatus, BoundaryAvailability,
    BoundaryPoint, RoadBoundary, RoadWidthSample,
)
from core.perception.perception_types import (
    RoadState, DrivableArea, BackendKind, NOT_AVAILABLE,
)
from core.perception.lidar_perception import LiDARPerceptionPipeline


# ---------------------------------------------------------------------------
# Synthetic point-cloud helpers (vehicle frame: +X forward, +Y left, +Z up)
# ---------------------------------------------------------------------------

def _straight_road(width=6.0, length=40.0, n_ground=600, seed=0):
    rng = np.random.default_rng(seed)
    x = rng.uniform(0, length, n_ground)
    y = rng.uniform(-width / 2 + 0.3, width / 2 - 0.3, n_ground)
    z = rng.normal(0, 0.02, n_ground)
    ground = np.stack([x, y, z, rng.uniform(0, 1, n_ground)], axis=1)
    xs = np.repeat(np.arange(2, length, 4.0), 5)
    jitter = rng.normal(0, 0.2, xs.shape[0])
    left_obs = np.stack([
        xs + jitter,
        np.full(xs.shape[0], width / 2) + rng.normal(0, 0.05, xs.shape[0]),
        rng.uniform(0.2, 1.0, xs.shape[0]),
        rng.uniform(0, 1, xs.shape[0]),
    ], axis=1)
    right_obs = np.stack([
        xs + jitter,
        np.full(xs.shape[0], -width / 2) + rng.normal(0, 0.05, xs.shape[0]),
        rng.uniform(0.2, 1.0, xs.shape[0]),
        rng.uniform(0, 1, xs.shape[0]),
    ], axis=1)
    return np.vstack([ground, left_obs, right_obs]).astype(np.float32)


def _curved_road(width=6.0, length=40.0, n_ground=800, curvature=0.02, seed=1):
    rng = np.random.default_rng(seed)
    x = rng.uniform(0, length, n_ground)
    center = curvature * x ** 2
    y = center + rng.uniform(-width / 2 + 0.3, width / 2 - 0.3, n_ground)
    z = rng.normal(0, 0.02, n_ground)
    ground = np.stack([x, y, z, rng.uniform(0, 1, n_ground)], axis=1)
    xs = np.repeat(np.arange(2, length, 4.0), 5)
    jitter = rng.normal(0, 0.2, xs.shape[0])
    c = curvature * xs ** 2
    left_obs = np.stack([
        xs + jitter, c + width / 2 + rng.normal(0, 0.05, xs.shape[0]),
        rng.uniform(0.2, 1.0, xs.shape[0]), rng.uniform(0, 1, xs.shape[0]),
    ], axis=1)
    right_obs = np.stack([
        xs + jitter, c - width / 2 + rng.normal(0, 0.05, xs.shape[0]),
        rng.uniform(0.2, 1.0, xs.shape[0]), rng.uniform(0, 1, xs.shape[0]),
    ], axis=1)
    return np.vstack([ground, left_obs, right_obs]).astype(np.float32)


def _asymmetric_road(left_w=3.0, right_w=5.0, length=40.0, seed=2):
    rng = np.random.default_rng(seed)
    n = 600
    x = rng.uniform(0, length, n)
    y = rng.uniform(-right_w + 0.3, left_w - 0.3, n)
    z = rng.normal(0, 0.02, n)
    ground = np.stack([x, y, z, rng.uniform(0, 1, n)], axis=1)
    xs = np.repeat(np.arange(2, length, 4.0), 5)
    jitter = rng.normal(0, 0.2, xs.shape[0])
    left_obs = np.stack([
        xs + jitter, np.full(xs.shape[0], left_w) + rng.normal(0, 0.05, xs.shape[0]),
        rng.uniform(0.2, 1.0, xs.shape[0]), rng.uniform(0, 1, xs.shape[0]),
    ], axis=1)
    right_obs = np.stack([
        xs + jitter, np.full(xs.shape[0], -right_w) + rng.normal(0, 0.05, xs.shape[0]),
        rng.uniform(0.2, 1.0, xs.shape[0]), rng.uniform(0, 1, xs.shape[0]),
    ], axis=1)
    return np.vstack([ground, left_obs, right_obs]).astype(np.float32)


def _narrow_road(width=3.0, length=30.0, seed=3):
    return _straight_road(width=width, length=length, seed=seed)


def _left_boundary_only(width=6.0, length=40.0, seed=4):
    """Only left boundary has LiDAR returns."""
    rng = np.random.default_rng(seed)
    n = 400
    x = rng.uniform(0, length, n)
    y = rng.uniform(0.3, width / 2 - 0.3, n)
    z = rng.normal(0, 0.02, n)
    ground = np.stack([x, y, z, rng.uniform(0, 1, n)], axis=1)
    xs = np.repeat(np.arange(2, length, 4.0), 5)
    jitter = rng.normal(0, 0.2, xs.shape[0])
    left_obs = np.stack([
        xs + jitter, np.full(xs.shape[0], width / 2) + rng.normal(0, 0.05, xs.shape[0]),
        rng.uniform(0.2, 1.0, xs.shape[0]), rng.uniform(0, 1, xs.shape[0]),
    ], axis=1)
    return np.vstack([ground, left_obs]).astype(np.float32)


# ---------------------------------------------------------------------------
# RoadUnderstanding factory from LiDAR point cloud
# ---------------------------------------------------------------------------

_RU_PIPELINE = RoadUnderstandingPipeline()


def _make_ru(points: np.ndarray, ts: float = 1000.0, frame_id: int = 1) -> RoadUnderstanding:
    return _RU_PIPELINE.process(lidar_points=points, timestamp=ts, frame_id=frame_id)


def _marked_road_state(lane_marking: str = "solid",
                       road_confidence: float = 0.85,
                       lane_count: int = None) -> RoadState:
    return RoadState(
        road_present=True,
        road_confidence=road_confidence,
        lane_marking=lane_marking,
        lane_count_estimate=lane_count,
        backend=BackendKind.BASELINE,
    )


def _unmarked_road_state(road_confidence: float = 0.75) -> RoadState:
    return RoadState(
        road_present=True,
        road_confidence=road_confidence,
        lane_marking="unmarked",
        backend=BackendKind.BASELINE,
    )


def _make_engine(**kwargs) -> LaneStructureEngine:
    return LaneStructureEngine(LaneStructureConfig(**kwargs))


# ---------------------------------------------------------------------------
# 1. Basic Structure
# ---------------------------------------------------------------------------

class TestBasicStructure:

    def test_valid_road_structure_returns_ok_or_partial(self):
        pts = _straight_road(width=7.0)
        ru = _make_ru(pts)
        rs = _marked_road_state()
        engine = _make_engine()
        result = engine.process(road_understanding=ru, road_state=rs, timestamp=1000.0)
        assert isinstance(result, LaneStructure)
        assert result.status in (LaneStructureStatus.OK, LaneStructureStatus.PARTIAL)
        assert result.confidence > 0.0
        assert result.uncertainty == pytest.approx(1.0 - result.confidence, abs=1e-3)

    def test_empty_input_returns_unavailable(self):
        engine = _make_engine()
        result = engine.process(timestamp=1000.0)
        assert result.status == LaneStructureStatus.UNAVAILABLE

    def test_disabled_config_returns_unavailable(self):
        engine = _make_engine(enabled=False)
        pts = _straight_road()
        ru = _make_ru(pts)
        rs = _marked_road_state()
        result = engine.process(road_understanding=ru, road_state=rs, timestamp=1000.0)
        assert result.status == LaneStructureStatus.UNAVAILABLE
        assert "disabled" in result.warnings[0].lower()

    def test_to_dict_valid(self):
        pts = _straight_road(width=7.0)
        ru = _make_ru(pts)
        rs = _marked_road_state()
        engine = _make_engine()
        result = engine.process(road_understanding=ru, road_state=rs, timestamp=1000.0)
        d = result.to_dict()
        assert "status" in d
        assert "lanes" in d
        assert "lane_count" in d
        assert "confidence" in d
        assert "uncertainty" in d
        assert "marking_status" in d
        assert "road_heading_rad" in d
        assert "source" in d
        assert "warnings" in d
        assert "sensor_status" in d

    def test_complete_input_produces_lanes(self):
        pts = _straight_road(width=7.0)
        ru = _make_ru(pts)
        rs = _marked_road_state()
        engine = _make_engine()
        result = engine.process(road_understanding=ru, road_state=rs, timestamp=1000.0)
        assert len(result.lanes) >= 1

    def test_partial_input_road_state_only(self):
        rs = _marked_road_state(road_confidence=0.6)
        engine = _make_engine()
        result = engine.process(road_state=rs, timestamp=1000.0)
        # Camera-only path: partial or degraded
        assert result.status in (LaneStructureStatus.PARTIAL, LaneStructureStatus.DEGRADED,
                                  LaneStructureStatus.UNAVAILABLE)

    def test_frame_id_propagated(self):
        pts = _straight_road()
        ru = _make_ru(pts, ts=2000.0, frame_id=42)
        engine = _make_engine()
        result = engine.process(road_understanding=ru, frame_id=42, timestamp=2000.0)
        assert result.frame_id == 42

    def test_timestamp_propagated(self):
        pts = _straight_road()
        ru = _make_ru(pts, ts=5555.5)
        engine = _make_engine()
        result = engine.process(road_understanding=ru, timestamp=5555.5)
        assert result.timestamp == pytest.approx(5555.5)


# ---------------------------------------------------------------------------
# 2. Lane Markings
# ---------------------------------------------------------------------------

class TestLaneMarkings:

    def test_solid_marking_recognised(self):
        pts = _straight_road(width=7.0)
        ru = _make_ru(pts)
        rs = _marked_road_state(lane_marking="solid")
        result = _make_engine().process(road_understanding=ru, road_state=rs, timestamp=1000.0)
        assert result.marking_status == MarkingStatus.MARKED

    def test_dashed_marking_recognised(self):
        pts = _straight_road(width=7.0)
        ru = _make_ru(pts)
        rs = _marked_road_state(lane_marking="dashed")
        result = _make_engine().process(road_understanding=ru, road_state=rs, timestamp=1000.0)
        assert result.marking_status == MarkingStatus.MARKED

    def test_unknown_marking_string(self):
        pts = _straight_road(width=7.0)
        ru = _make_ru(pts)
        rs = _marked_road_state(lane_marking="some_unknown_value")
        result = _make_engine().process(road_understanding=ru, road_state=rs, timestamp=1000.0)
        # UNKNOWN is acceptable for unrecognised strings
        assert result.marking_status in (MarkingStatus.UNKNOWN, MarkingStatus.MARKED)

    def test_missing_marking_no_road_state(self):
        pts = _straight_road(width=7.0)
        ru = _make_ru(pts)
        result = _make_engine().process(road_understanding=ru, timestamp=1000.0)
        # Without camera/road_state, marking_status should be UNKNOWN
        assert result.marking_status == MarkingStatus.UNKNOWN

    def test_weak_marking_recognised(self):
        pts = _straight_road(width=7.0)
        ru = _make_ru(pts)
        rs = _marked_road_state(lane_marking="weak")
        result = _make_engine().process(road_understanding=ru, road_state=rs, timestamp=1000.0)
        assert result.marking_status == MarkingStatus.WEAKLY_MARKED

    def test_unmarked_marking(self):
        pts = _straight_road(width=5.0)
        ru = _make_ru(pts)
        rs = _unmarked_road_state()
        result = _make_engine().process(road_understanding=ru, road_state=rs, timestamp=1000.0)
        assert result.marking_status == MarkingStatus.UNMARKED

    def test_not_available_marking(self):
        pts = _straight_road(width=7.0)
        ru = _make_ru(pts)
        rs = RoadState(road_present=True, road_confidence=0.8,
                       lane_marking=NOT_AVAILABLE, backend=BackendKind.BASELINE)
        result = _make_engine().process(road_understanding=ru, road_state=rs, timestamp=1000.0)
        assert result.marking_status in (MarkingStatus.UNKNOWN, MarkingStatus.MARKED)


# ---------------------------------------------------------------------------
# 3. Lane Boundaries
# ---------------------------------------------------------------------------

class TestLaneBoundaries:

    def test_single_lane_has_two_boundaries(self):
        pts = _narrow_road(width=3.5)
        ru = _make_ru(pts)
        rs = _marked_road_state(lane_count=1)
        result = _make_engine().process(road_understanding=ru, road_state=rs, timestamp=1000.0)
        assert len(result.lanes) >= 1
        lane0 = result.lanes[0]
        # Both boundaries present for a fully-observed single lane
        assert lane0.left_boundary is not None or lane0.right_boundary is not None

    def test_two_lane_road_produces_two_lanes(self):
        pts = _straight_road(width=8.0)
        ru = _make_ru(pts)
        rs = _marked_road_state(lane_marking="solid", lane_count=2)
        result = _make_engine(min_road_width_for_lane_split_m=5.0).process(
            road_understanding=ru, road_state=rs, timestamp=1000.0)
        assert len(result.lanes) == 2

    def test_boundary_points_are_finite(self):
        pts = _straight_road(width=7.0)
        ru = _make_ru(pts)
        rs = _marked_road_state()
        result = _make_engine().process(road_understanding=ru, road_state=rs, timestamp=1000.0)
        for lane in result.lanes:
            for bnd in (lane.left_boundary, lane.right_boundary):
                if bnd is not None:
                    for pt in bnd.points:
                        assert np.isfinite(pt.x), f"x is not finite: {pt.x}"
                        assert np.isfinite(pt.y), f"y is not finite: {pt.y}"

    def test_straight_boundary_sorted_by_x(self):
        pts = _straight_road(width=7.0)
        ru = _make_ru(pts)
        rs = _marked_road_state()
        result = _make_engine().process(road_understanding=ru, road_state=rs, timestamp=1000.0)
        for lane in result.lanes:
            for bnd in (lane.left_boundary, lane.right_boundary):
                if bnd is None or not bnd.points:
                    continue
                xs = [p.x for p in bnd.points]
                assert xs == sorted(xs), "Boundary points not sorted by x"

    def test_curved_boundary_finite(self):
        pts = _curved_road(curvature=0.02)
        ru = _make_ru(pts)
        rs = _marked_road_state()
        result = _make_engine().process(road_understanding=ru, road_state=rs, timestamp=1000.0)
        assert result.status != LaneStructureStatus.INVALID
        for lane in result.lanes:
            for bnd in (lane.left_boundary, lane.right_boundary):
                if bnd is not None:
                    for pt in bnd.points:
                        assert np.isfinite(pt.x) and np.isfinite(pt.y)

    def test_asymmetric_road_boundaries(self):
        pts = _asymmetric_road(left_w=3.0, right_w=5.0)
        ru = _make_ru(pts)
        rs = _marked_road_state()
        result = _make_engine().process(road_understanding=ru, road_state=rs, timestamp=1000.0)
        assert len(result.lanes) >= 1
        assert result.status != LaneStructureStatus.INVALID

    def test_left_boundary_only(self):
        pts = _left_boundary_only()
        ru = _make_ru(pts)
        rs = _marked_road_state()
        result = _make_engine().process(road_understanding=ru, road_state=rs, timestamp=1000.0)
        # Partial is acceptable when only one side is visible
        assert result.status in (LaneStructureStatus.PARTIAL, LaneStructureStatus.OK,
                                  LaneStructureStatus.DEGRADED)

    def test_boundary_evidence_is_inferred_from_road_edges(self):
        pts = _straight_road(width=7.0)
        ru = _make_ru(pts)
        rs = _marked_road_state()
        result = _make_engine().process(road_understanding=ru, road_state=rs, timestamp=1000.0)
        for lane in result.lanes:
            for bnd in (lane.left_boundary, lane.right_boundary):
                if bnd is not None and bnd.points:
                    # Road-edge-derived boundaries are INFERRED
                    assert bnd.evidence in (EvidenceKind.INFERRED, EvidenceKind.OBSERVED)


# ---------------------------------------------------------------------------
# 4. Centreline
# ---------------------------------------------------------------------------

class TestCenterline:

    def test_valid_centerline_from_two_boundaries(self):
        pts = _straight_road(width=7.0)
        ru = _make_ru(pts)
        rs = _marked_road_state()
        result = _make_engine().process(road_understanding=ru, road_state=rs, timestamp=1000.0)
        found = any(
            lane.centerline is not None and lane.centerline.available
            for lane in result.lanes
        )
        assert found, "Expected at least one lane with an available centerline"

    def test_centerline_points_are_finite(self):
        pts = _straight_road(width=7.0)
        ru = _make_ru(pts)
        rs = _marked_road_state()
        result = _make_engine().process(road_understanding=ru, road_state=rs, timestamp=1000.0)
        for lane in result.lanes:
            cl = lane.centerline
            if cl is None or not cl.available:
                continue
            for pt in cl.points:
                assert np.isfinite(pt.x) and np.isfinite(pt.y)

    def test_centerline_between_boundaries(self):
        """Centreline y must be between left and right boundary y at each x."""
        pts = _straight_road(width=7.0)
        ru = _make_ru(pts)
        rs = _marked_road_state()
        result = _make_engine().process(road_understanding=ru, road_state=rs, timestamp=1000.0)
        for lane in result.lanes:
            cl = lane.centerline
            lb = lane.left_boundary
            rb = lane.right_boundary
            if cl is None or lb is None or rb is None:
                continue
            for cpt in cl.points:
                ly_vals = [p.y for p in lb.points if abs(p.x - cpt.x) < 2.0]
                ry_vals = [p.y for p in rb.points if abs(p.x - cpt.x) < 2.0]
                if not ly_vals or not ry_vals:
                    continue
                ly = np.mean(ly_vals)
                ry = np.mean(ry_vals)
                if ly > ry:
                    assert ry - 0.5 <= cpt.y <= ly + 0.5, (
                        f"Centreline y={cpt.y:.2f} outside boundaries [{ry:.2f}, {ly:.2f}]"
                    )

    def test_curved_centerline(self):
        pts = _curved_road(curvature=0.02)
        ru = _make_ru(pts)
        rs = _marked_road_state()
        result = _make_engine().process(road_understanding=ru, road_state=rs, timestamp=1000.0)
        found = any(
            lane.centerline is not None and lane.centerline.available
            for lane in result.lanes
        )
        assert found

    def test_no_centerline_when_both_boundaries_missing(self):
        ru = RoadUnderstanding(
            timestamp=1000.0, frame_id=1,
            status=RoadUnderstandingStatus.UNAVAILABLE,
        )
        engine = _make_engine()
        result = engine.process(road_understanding=ru, timestamp=1000.0)
        assert result.status == LaneStructureStatus.UNAVAILABLE

    def test_centerline_evidence_is_inferred(self):
        pts = _straight_road(width=7.0)
        ru = _make_ru(pts)
        rs = _marked_road_state()
        result = _make_engine().process(road_understanding=ru, road_state=rs, timestamp=1000.0)
        for lane in result.lanes:
            cl = lane.centerline
            if cl is not None and cl.available:
                assert cl.evidence == EvidenceKind.INFERRED

    def test_heading_in_centerline_points(self):
        pts = _straight_road(width=7.0)
        ru = _make_ru(pts)
        rs = _marked_road_state()
        result = _make_engine().process(road_understanding=ru, road_state=rs, timestamp=1000.0)
        for lane in result.lanes:
            cl = lane.centerline
            if cl is None or len(cl.points) < 2:
                continue
            headings = [p.heading_rad for p in cl.points if p.heading_rad is not None]
            # At least some centreline points should have a heading estimate
            assert len(headings) > 0


# ---------------------------------------------------------------------------
# 5. Unmarked Roads
# ---------------------------------------------------------------------------

class TestUnmarkedRoads:

    def test_unmarked_village_road_inferred_corridor(self):
        pts = _narrow_road(width=4.0)
        ru = _make_ru(pts)
        rs = _unmarked_road_state()
        result = _make_engine().process(road_understanding=ru, road_state=rs, timestamp=1000.0)
        assert result.marking_status == MarkingStatus.UNMARKED
        assert result.road_type == RoadTypeHint.UNMARKED_CORRIDOR
        assert len(result.lanes) >= 1

    def test_unmarked_not_marked_as_observed_lane(self):
        """CRITICAL: inferred corridors must NOT be labelled as OBSERVED."""
        pts = _narrow_road(width=4.0)
        ru = _make_ru(pts)
        rs = _unmarked_road_state()
        result = _make_engine().process(road_understanding=ru, road_state=rs, timestamp=1000.0)
        for lane in result.lanes:
            assert lane.marking_status != MarkingStatus.MARKED, (
                "Unmarked road incorrectly reported as MARKED"
            )
            assert lane.evidence != EvidenceKind.OBSERVED, (
                "Unmarked road corridor evidence must not be OBSERVED"
            )
            for bnd in (lane.left_boundary, lane.right_boundary):
                if bnd is None:
                    continue
                for pt in bnd.points:
                    assert pt.evidence != EvidenceKind.OBSERVED

    def test_narrow_unmarked_road(self):
        pts = _narrow_road(width=3.0)
        ru = _make_ru(pts)
        rs = _unmarked_road_state()
        result = _make_engine().process(road_understanding=ru, road_state=rs, timestamp=1000.0)
        assert result.status not in (LaneStructureStatus.INVALID,)
        assert result.marking_status == MarkingStatus.UNMARKED

    def test_wide_unmarked_road(self):
        pts = _straight_road(width=10.0)
        ru = _make_ru(pts)
        rs = _unmarked_road_state()
        result = _make_engine().process(road_understanding=ru, road_state=rs, timestamp=1000.0)
        assert result.status not in (LaneStructureStatus.INVALID,)

    def test_asymmetric_unmarked_road(self):
        pts = _asymmetric_road(left_w=2.0, right_w=4.0)
        ru = _make_ru(pts)
        rs = _unmarked_road_state()
        result = _make_engine().process(road_understanding=ru, road_state=rs, timestamp=1000.0)
        assert result.status != LaneStructureStatus.INVALID

    def test_partially_observed_unmarked_road(self):
        pts = _left_boundary_only(width=5.0)
        ru = _make_ru(pts)
        rs = _unmarked_road_state()
        result = _make_engine().process(road_understanding=ru, road_state=rs, timestamp=1000.0)
        assert result.status in (LaneStructureStatus.PARTIAL, LaneStructureStatus.OK,
                                  LaneStructureStatus.DEGRADED)

    def test_unmarked_inference_can_be_disabled(self):
        pts = _straight_road(width=5.0)
        ru = _make_ru(pts)
        rs = _unmarked_road_state()
        result = _make_engine(allow_unmarked_inference=False).process(
            road_understanding=ru, road_state=rs, timestamp=1000.0)
        # With inference off and no markings, should fall back or degrade
        assert result.status != LaneStructureStatus.INVALID


# ---------------------------------------------------------------------------
# 6. Lane Count
# ---------------------------------------------------------------------------

class TestLaneCount:

    def test_single_lane_count(self):
        pts = _narrow_road(width=3.5)
        ru = _make_ru(pts)
        rs = _marked_road_state(lane_count=1)
        result = _make_engine().process(road_understanding=ru, road_state=rs, timestamp=1000.0)
        assert result.lane_count is not None
        assert result.lane_count >= 1

    def test_two_lane_count(self):
        pts = _straight_road(width=8.0)
        ru = _make_ru(pts)
        rs = _marked_road_state(lane_marking="solid", lane_count=2)
        result = _make_engine(min_road_width_for_lane_split_m=5.0).process(
            road_understanding=ru, road_state=rs, timestamp=1000.0)
        assert result.lane_count == 2

    def test_unknown_count_when_unavailable(self):
        engine = _make_engine()
        result = engine.process(timestamp=1000.0)
        assert result.lane_count is None

    def test_lane_count_confidence_bounded(self):
        pts = _straight_road(width=7.0)
        ru = _make_ru(pts)
        rs = _marked_road_state()
        result = _make_engine().process(road_understanding=ru, road_state=rs, timestamp=1000.0)
        assert 0.0 <= result.lane_count_confidence <= 1.0

    def test_road_state_lane_count_respected(self):
        pts = _straight_road(width=7.0)
        ru = _make_ru(pts)
        rs = _marked_road_state(lane_count=1)
        result = _make_engine().process(road_understanding=ru, road_state=rs, timestamp=1000.0)
        # When RoadState provides lane_count=1, output should not claim more
        # (lane_count from RS takes priority)
        assert result.lane_count == 1


# ---------------------------------------------------------------------------
# 7. Lane Width
# ---------------------------------------------------------------------------

class TestLaneWidth:

    def test_valid_lane_width(self):
        pts = _straight_road(width=7.0)
        ru = _make_ru(pts)
        rs = _marked_road_state(lane_count=1)
        result = _make_engine().process(road_understanding=ru, road_state=rs, timestamp=1000.0)
        has_width = False
        for lane in result.lanes:
            for ws in lane.width_samples:
                if ws.estimated_width_m is not None:
                    assert ws.estimated_width_m > 0
                    assert np.isfinite(ws.estimated_width_m)
                    has_width = True
        assert has_width

    def test_narrow_lane(self):
        pts = _narrow_road(width=3.0)
        ru = _make_ru(pts)
        rs = _marked_road_state(lane_count=1)
        result = _make_engine(min_plausible_lane_width_m=1.5).process(
            road_understanding=ru, road_state=rs, timestamp=1000.0)
        for lane in result.lanes:
            for ws in lane.width_samples:
                if ws.estimated_width_m is not None:
                    assert ws.estimated_width_m >= 1.5

    def test_missing_width_on_one_boundary(self):
        pts = _left_boundary_only()
        ru = _make_ru(pts)
        rs = _marked_road_state()
        result = _make_engine().process(road_understanding=ru, road_state=rs, timestamp=1000.0)
        # Should not crash; width may be None/missing
        assert result.status != LaneStructureStatus.INVALID

    def test_width_bounds_respected(self):
        pts = _straight_road(width=7.0)
        ru = _make_ru(pts)
        rs = _marked_road_state()
        cfg = LaneStructureConfig(min_plausible_lane_width_m=1.5, max_plausible_lane_width_m=6.0)
        result = LaneStructureEngine(cfg).process(
            road_understanding=ru, road_state=rs, timestamp=1000.0)
        for lane in result.lanes:
            for ws in lane.width_samples:
                if ws.estimated_width_m is not None:
                    assert 1.5 <= ws.estimated_width_m <= 6.0

    def test_width_confidence_bounded(self):
        pts = _straight_road(width=7.0)
        ru = _make_ru(pts)
        rs = _marked_road_state()
        result = _make_engine().process(road_understanding=ru, road_state=rs, timestamp=1000.0)
        for lane in result.lanes:
            for ws in lane.width_samples:
                assert 0.0 <= ws.confidence <= 1.0


# ---------------------------------------------------------------------------
# 8. Road Curvature
# ---------------------------------------------------------------------------

class TestRoadCurvature:

    def test_straight_road(self):
        pts = _straight_road(width=7.0)
        ru = _make_ru(pts)
        rs = _marked_road_state()
        result = _make_engine().process(road_understanding=ru, road_state=rs, timestamp=1000.0)
        assert result.status not in (LaneStructureStatus.INVALID, LaneStructureStatus.UNAVAILABLE)
        # Straight road: heading near 0
        if result.road_heading_rad is not None:
            assert abs(result.road_heading_rad) < 0.3

    def test_left_curve(self):
        pts = _curved_road(curvature=0.03)
        ru = _make_ru(pts)
        rs = _marked_road_state()
        result = _make_engine().process(road_understanding=ru, road_state=rs, timestamp=1000.0)
        assert result.status != LaneStructureStatus.INVALID

    def test_right_curve(self):
        pts = _curved_road(curvature=-0.03)
        ru = _make_ru(pts)
        rs = _marked_road_state()
        result = _make_engine().process(road_understanding=ru, road_state=rs, timestamp=1000.0)
        assert result.status != LaneStructureStatus.INVALID

    def test_changing_curvature(self):
        """S-curve: combine left and right sections."""
        left = _curved_road(curvature=0.02, seed=10)
        right = _curved_road(curvature=-0.02, seed=11)
        pts = np.vstack([left, right])
        ru = _make_ru(pts)
        rs = _marked_road_state()
        result = _make_engine().process(road_understanding=ru, road_state=rs, timestamp=1000.0)
        assert result.status != LaneStructureStatus.INVALID

    def test_road_heading_is_finite_when_available(self):
        pts = _straight_road(width=7.0)
        ru = _make_ru(pts)
        rs = _marked_road_state()
        result = _make_engine().process(road_understanding=ru, road_state=rs, timestamp=1000.0)
        if result.road_heading_rad is not None:
            assert np.isfinite(result.road_heading_rad)
        if result.road_heading_confidence > 0:
            assert 0.0 <= result.road_heading_confidence <= 1.0

    def test_heading_wrapped_to_pi(self):
        pts = _straight_road(width=7.0)
        ru = _make_ru(pts)
        rs = _marked_road_state()
        result = _make_engine().process(road_understanding=ru, road_state=rs, timestamp=1000.0)
        if result.road_heading_rad is not None:
            assert -math.pi <= result.road_heading_rad <= math.pi


# ---------------------------------------------------------------------------
# 9. Intersection
# ---------------------------------------------------------------------------

class TestIntersection:

    def test_normal_road_is_normal(self):
        pts = _straight_road(width=7.0)
        ru = _make_ru(pts)
        result = _make_engine().process(road_understanding=ru, timestamp=1000.0)
        # Normal road should not be flagged as intersection
        assert result.intersection_state in (
            IntersectionState.NORMAL_ROAD, IntersectionState.UNKNOWN)

    def test_diverging_width_hints_intersection(self):
        """Build a RoadUnderstanding with dramatically widening road profile."""
        # Manually craft a RoadUnderstanding with diverging width.
        ru = RoadUnderstanding(
            timestamp=1000.0, frame_id=1,
            status=RoadUnderstandingStatus.OK,
            boundary_availability=BoundaryAvailability.BOTH,
            left_boundary=RoadBoundary(
                side="left", available=True, source="lidar", confidence=0.8,
                points=[
                    BoundaryPoint(x=0, y=3.0, confidence=0.8),
                    BoundaryPoint(x=10, y=3.5, confidence=0.8),
                    BoundaryPoint(x=20, y=8.0, confidence=0.7),
                    BoundaryPoint(x=30, y=15.0, confidence=0.6),
                ],
            ),
            right_boundary=RoadBoundary(
                side="right", available=True, source="lidar", confidence=0.8,
                points=[
                    BoundaryPoint(x=0, y=-3.0, confidence=0.8),
                    BoundaryPoint(x=10, y=-3.5, confidence=0.8),
                    BoundaryPoint(x=20, y=-8.0, confidence=0.7),
                    BoundaryPoint(x=30, y=-15.0, confidence=0.6),
                ],
            ),
            road_width_profile=[
                RoadWidthSample(distance_m=0, width_m=6.0, availability=BoundaryAvailability.BOTH),
                RoadWidthSample(distance_m=10, width_m=7.0, availability=BoundaryAvailability.BOTH),
                RoadWidthSample(distance_m=20, width_m=16.0, availability=BoundaryAvailability.BOTH),
                RoadWidthSample(distance_m=30, width_m=30.0, availability=BoundaryAvailability.BOTH),
            ],
            confidence=0.75, source="lidar", uncertainty=0.25,
        )
        result = _make_engine().process(road_understanding=ru, timestamp=1000.0)
        assert result.intersection_state == IntersectionState.INTERSECTION

    def test_unknown_intersection_when_no_boundaries(self):
        ru = RoadUnderstanding(
            timestamp=1000.0, frame_id=1,
            status=RoadUnderstandingStatus.UNAVAILABLE,
        )
        result = _make_engine().process(road_understanding=ru, timestamp=1000.0)
        assert result.intersection_state == IntersectionState.UNKNOWN


# ---------------------------------------------------------------------------
# 10. Sensor Degradation
# ---------------------------------------------------------------------------

class TestSensorDegradation:

    def test_camera_unavailable_lidar_ok(self):
        pts = _straight_road(width=7.0)
        ru = _make_ru(pts)
        # No road_state = no camera
        result = _make_engine().process(road_understanding=ru, timestamp=1000.0)
        assert result.status in (LaneStructureStatus.OK, LaneStructureStatus.PARTIAL)
        assert result.source in ("lidar", "fusion")

    def test_lidar_unavailable_camera_ok(self):
        rs = _marked_road_state()
        result = _make_engine().process(road_state=rs, timestamp=1000.0)
        # Camera-only: should be PARTIAL/DEGRADED, not crash
        assert result.status in (LaneStructureStatus.PARTIAL, LaneStructureStatus.DEGRADED,
                                  LaneStructureStatus.UNAVAILABLE)

    def test_both_unavailable(self):
        result = _make_engine().process(timestamp=1000.0)
        assert result.status == LaneStructureStatus.UNAVAILABLE

    def test_stale_road_understanding(self):
        pts = _straight_road(width=7.0)
        ru = _make_ru(pts, ts=0.0)  # very old timestamp
        result = _make_engine(max_road_understanding_staleness_s=1.0).process(
            road_understanding=ru, timestamp=5000.0)  # 5000s later
        # Stale input: should be unavailable or degraded
        assert result.status in (LaneStructureStatus.UNAVAILABLE, LaneStructureStatus.DEGRADED,
                                  LaneStructureStatus.PARTIAL)

    def test_empty_road_understanding_status_unavailable(self):
        ru = RoadUnderstanding(
            timestamp=1000.0, frame_id=1,
            status=RoadUnderstandingStatus.UNAVAILABLE,
        )
        result = _make_engine().process(road_understanding=ru, timestamp=1000.0)
        assert result.status == LaneStructureStatus.UNAVAILABLE

    def test_invalid_road_understanding_propagates(self):
        ru = RoadUnderstanding(
            timestamp=1000.0, frame_id=1,
            status=RoadUnderstandingStatus.INVALID,
        )
        result = _make_engine().process(road_understanding=ru, timestamp=1000.0)
        assert result.status in (LaneStructureStatus.UNAVAILABLE, LaneStructureStatus.INVALID,
                                  LaneStructureStatus.DEGRADED)

    def test_fusion_source_when_both_available(self):
        pts = _straight_road(width=7.0)
        ru = _make_ru(pts)
        rs = _marked_road_state()
        result = _make_engine().process(road_understanding=ru, road_state=rs, timestamp=1000.0)
        assert result.source == "fusion"


# ---------------------------------------------------------------------------
# 11. Confidence
# ---------------------------------------------------------------------------

class TestConfidence:

    def test_high_confidence_good_data(self):
        pts = _straight_road(width=7.0, n_ground=1200)
        ru = _make_ru(pts)
        rs = _marked_road_state(road_confidence=0.95)
        result = _make_engine().process(road_understanding=ru, road_state=rs, timestamp=1000.0)
        assert result.confidence > 0.2

    def test_low_confidence_sparse_data(self):
        # With very sparse LiDAR (20 pts), Phase 6.1 produces DEGRADED (no boundary
        # points meet min_points_per_sample), so lane_structure falls back to the
        # camera-only path → PARTIAL confidence since road_confidence=0.3.
        pts = _straight_road(width=7.0, n_ground=20)
        ru = _make_ru(pts)
        rs = _marked_road_state(road_confidence=0.3)
        result = _make_engine().process(road_understanding=ru, road_state=rs, timestamp=1000.0)
        # PARTIAL is acceptable (camera-only qualitative output) as well as DEGRADED/UNAVAILABLE
        assert result.status in (LaneStructureStatus.DEGRADED, LaneStructureStatus.PARTIAL,
                                  LaneStructureStatus.UNAVAILABLE, LaneStructureStatus.OK)

    def test_confidence_bounded(self):
        pts = _straight_road(width=7.0)
        ru = _make_ru(pts)
        rs = _marked_road_state()
        result = _make_engine().process(road_understanding=ru, road_state=rs, timestamp=1000.0)
        assert 0.0 <= result.confidence <= 1.0
        assert 0.0 <= result.uncertainty <= 1.0

    def test_uncertainty_complement_of_confidence(self):
        pts = _straight_road(width=7.0)
        ru = _make_ru(pts)
        rs = _marked_road_state()
        result = _make_engine().process(road_understanding=ru, road_state=rs, timestamp=1000.0)
        assert result.uncertainty == pytest.approx(1.0 - result.confidence, abs=1e-3)

    def test_below_min_confidence_is_degraded(self):
        pts = _straight_road(width=7.0, n_ground=10)
        ru = _make_ru(pts)
        result = _make_engine(minimum_confidence=0.99).process(
            road_understanding=ru, timestamp=1000.0)
        # Almost impossible to hit 0.99 with sparse data → DEGRADED
        assert result.status in (LaneStructureStatus.DEGRADED, LaneStructureStatus.PARTIAL,
                                  LaneStructureStatus.UNAVAILABLE)


# ---------------------------------------------------------------------------
# 12. Geometry Validation
# ---------------------------------------------------------------------------

class TestGeometryValidation:

    def test_nan_in_boundary_points_triggers_invalid_or_filtered(self):
        """Inject NaN into a RoadUnderstanding and verify it doesn't propagate."""
        ru = RoadUnderstanding(
            timestamp=1000.0, frame_id=1,
            status=RoadUnderstandingStatus.OK,
            boundary_availability=BoundaryAvailability.BOTH,
            left_boundary=RoadBoundary(
                side="left", available=True, source="lidar", confidence=0.8,
                points=[
                    BoundaryPoint(x=0, y=float("nan"), confidence=0.8),
                    BoundaryPoint(x=10, y=3.0, confidence=0.8),
                ],
            ),
            right_boundary=RoadBoundary(
                side="right", available=True, source="lidar", confidence=0.8,
                points=[
                    BoundaryPoint(x=0, y=-3.0, confidence=0.8),
                    BoundaryPoint(x=10, y=-3.0, confidence=0.8),
                ],
            ),
            confidence=0.8, source="lidar", uncertainty=0.2,
        )
        result = _make_engine().process(road_understanding=ru, timestamp=1000.0)
        # NaN must not propagate into output
        for lane in result.lanes:
            for bnd in (lane.left_boundary, lane.right_boundary):
                if bnd is None:
                    continue
                for pt in bnd.points:
                    assert np.isfinite(pt.x), "NaN propagated in boundary x"
                    assert np.isfinite(pt.y), "NaN propagated in boundary y"

    def test_inf_in_boundary_points_filtered(self):
        ru = RoadUnderstanding(
            timestamp=1000.0, frame_id=1,
            status=RoadUnderstandingStatus.OK,
            boundary_availability=BoundaryAvailability.BOTH,
            left_boundary=RoadBoundary(
                side="left", available=True, source="lidar", confidence=0.7,
                points=[
                    BoundaryPoint(x=0, y=float("inf"), confidence=0.7),
                    BoundaryPoint(x=10, y=3.0, confidence=0.7),
                ],
            ),
            right_boundary=RoadBoundary(
                side="right", available=True, source="lidar", confidence=0.7,
                points=[
                    BoundaryPoint(x=0, y=-3.0, confidence=0.7),
                ],
            ),
            confidence=0.7, source="lidar", uncertainty=0.3,
        )
        result = _make_engine().process(road_understanding=ru, timestamp=1000.0)
        for lane in result.lanes:
            for bnd in (lane.left_boundary, lane.right_boundary):
                if bnd is None:
                    continue
                for pt in bnd.points:
                    assert np.isfinite(pt.y), "Inf propagated in boundary y"

    def test_impossible_lane_width_rejected(self):
        """Width < min_plausible or > max_plausible must be dropped."""
        pts = _straight_road(width=7.0)
        ru = _make_ru(pts)
        rs = _marked_road_state()
        cfg = LaneStructureConfig(
            min_plausible_lane_width_m=2.0,
            max_plausible_lane_width_m=5.0,
        )
        result = LaneStructureEngine(cfg).process(
            road_understanding=ru, road_state=rs, timestamp=1000.0)
        for lane in result.lanes:
            for ws in lane.width_samples:
                if ws.estimated_width_m is not None:
                    assert 2.0 <= ws.estimated_width_m <= 5.0

    def test_all_nan_boundaries_returns_unavailable_or_invalid(self):
        ru = RoadUnderstanding(
            timestamp=1000.0, frame_id=1,
            status=RoadUnderstandingStatus.OK,
            boundary_availability=BoundaryAvailability.BOTH,
            left_boundary=RoadBoundary(
                side="left", available=True, source="lidar", confidence=0.7,
                points=[BoundaryPoint(x=float("nan"), y=float("nan"), confidence=0.7)],
            ),
            right_boundary=RoadBoundary(
                side="right", available=True, source="lidar", confidence=0.7,
                points=[BoundaryPoint(x=float("nan"), y=float("nan"), confidence=0.7)],
            ),
            confidence=0.7, source="lidar", uncertainty=0.3,
        )
        result = _make_engine().process(road_understanding=ru, timestamp=1000.0)
        assert result.status in (
            LaneStructureStatus.INVALID, LaneStructureStatus.UNAVAILABLE,
            LaneStructureStatus.DEGRADED, LaneStructureStatus.PARTIAL,
        )
        # Regardless of status, no NaN in output
        for lane in result.lanes:
            for bnd in (lane.left_boundary, lane.right_boundary):
                if bnd is None:
                    continue
                for pt in bnd.points:
                    assert np.isfinite(pt.x) and np.isfinite(pt.y)


# ---------------------------------------------------------------------------
# 13. Phase 6.1 Consistency
# ---------------------------------------------------------------------------

class TestPhase61Consistency:

    def test_lane_does_not_exceed_road_boundary(self):
        """
        Lane outer boundaries derived from road edges must stay within the
        Phase 6.1 road boundary (within a small tolerance for interpolation).
        """
        pts = _straight_road(width=7.0)
        ru = _make_ru(pts)
        rs = _marked_road_state()
        result = _make_engine().process(road_understanding=ru, road_state=rs, timestamp=1000.0)

        # Get road boundary approximate y extents from Phase 6.1
        left_rb = ru.left_boundary
        right_rb = ru.right_boundary

        if not (left_rb.available and right_rb.available):
            return  # Can't check consistency without both road boundaries

        max_left_y = max(p.y for p in left_rb.points) if left_rb.points else float("inf")
        min_right_y = min(p.y for p in right_rb.points) if right_rb.points else float("-inf")

        tolerance = 0.5  # allow small interpolation error
        for lane in result.lanes:
            for bnd in (lane.left_boundary, lane.right_boundary):
                if bnd is None or not bnd.points:
                    continue
                for pt in bnd.points:
                    assert pt.y <= max_left_y + tolerance, (
                        f"Lane boundary y={pt.y:.2f} exceeds road left boundary y={max_left_y:.2f}"
                    )
                    assert pt.y >= min_right_y - tolerance, (
                        f"Lane boundary y={pt.y:.2f} exceeds road right boundary y={min_right_y:.2f}"
                    )

    def test_lane_structure_status_consistent_with_road_understanding(self):
        """If Phase 6.1 is UNAVAILABLE, Phase 6.2 must also be UNAVAILABLE."""
        ru = RoadUnderstanding(
            timestamp=1000.0, frame_id=1,
            status=RoadUnderstandingStatus.UNAVAILABLE,
        )
        result = _make_engine().process(road_understanding=ru, timestamp=1000.0)
        assert result.status == LaneStructureStatus.UNAVAILABLE

    def test_source_tags_consistent(self):
        """If both RU and RS available, source must be 'fusion'."""
        pts = _straight_road(width=7.0)
        ru = _make_ru(pts)
        rs = _marked_road_state()
        result = _make_engine().process(road_understanding=ru, road_state=rs, timestamp=1000.0)
        assert result.source == "fusion"


# ---------------------------------------------------------------------------
# 14. Determinism
# ---------------------------------------------------------------------------

class TestDeterminism:

    def test_identical_input_produces_identical_output(self):
        pts = _straight_road(width=7.0, seed=0)
        ru = _make_ru(pts, ts=1234.5)
        rs = _marked_road_state()
        engine = _make_engine()

        results = []
        for _ in range(5):
            r = engine.process(road_understanding=ru, road_state=rs, timestamp=1234.5)
            results.append(r.to_dict())

        ref = results[0]
        for r in results[1:]:
            assert r["status"] == ref["status"]
            assert r["lane_count"] == ref["lane_count"]
            assert r["marking_status"] == ref["marking_status"]
            assert r["confidence"] == ref["confidence"]
            assert r["road_type"] == ref["road_type"]
            assert r["intersection_state"] == ref["intersection_state"]

    def test_different_seeds_may_differ(self):
        """Sanity check: two truly different roads produce possibly different counts."""
        pts1 = _straight_road(width=3.0, seed=0)
        pts2 = _straight_road(width=9.0, seed=99)
        ru1 = _make_ru(pts1, ts=1000.0)
        ru2 = _make_ru(pts2, ts=1000.0)
        engine = _make_engine()
        r1 = engine.process(road_understanding=ru1, timestamp=1000.0)
        r2 = engine.process(road_understanding=ru2, timestamp=1000.0)
        # They might differ in confidence at minimum
        _ = r1.confidence, r2.confidence  # just ensure no crash


# ---------------------------------------------------------------------------
# 15. Road type hints
# ---------------------------------------------------------------------------

class TestRoadTypeHints:

    def test_narrow_unmarked_is_unmarked_corridor(self):
        pts = _narrow_road(width=3.5)
        ru = _make_ru(pts)
        rs = _unmarked_road_state()
        result = _make_engine().process(road_understanding=ru, road_state=rs, timestamp=1000.0)
        assert result.road_type == RoadTypeHint.UNMARKED_CORRIDOR

    def test_single_lane_marked(self):
        pts = _narrow_road(width=4.0)
        ru = _make_ru(pts)
        rs = _marked_road_state(lane_marking="solid", lane_count=1)
        result = _make_engine().process(road_understanding=ru, road_state=rs, timestamp=1000.0)
        assert result.road_type == RoadTypeHint.SINGLE_LANE

    def test_multi_lane_marked(self):
        pts = _straight_road(width=8.0)
        ru = _make_ru(pts)
        rs = _marked_road_state(lane_marking="solid", lane_count=2)
        result = _make_engine(min_road_width_for_lane_split_m=5.0).process(
            road_understanding=ru, road_state=rs, timestamp=1000.0)
        assert result.road_type == RoadTypeHint.MULTI_LANE


# ---------------------------------------------------------------------------
# 16. API surface
# ---------------------------------------------------------------------------

class TestAPI:

    def test_process_accepts_perception_kwarg(self):
        """perception kwarg fallback works when road_understanding not passed directly."""

        class FakePerception:
            frame_id = 7
            road_understanding = None
            road_state = _marked_road_state()

        result = _make_engine().process(perception=FakePerception(), timestamp=1000.0)
        assert isinstance(result, LaneStructure)

    def test_default_timestamp_is_set(self):
        result = _make_engine().process()
        assert result.timestamp > 0

    def test_warnings_list_is_list(self):
        result = _make_engine().process(timestamp=1000.0)
        assert isinstance(result.warnings, list)

    def test_sensor_status_dict_present(self):
        result = _make_engine().process(timestamp=1000.0)
        assert isinstance(result.sensor_status, dict)

    def test_lane_descriptor_to_dict(self):
        pts = _straight_road(width=7.0)
        ru = _make_ru(pts)
        rs = _marked_road_state()
        result = _make_engine().process(road_understanding=ru, road_state=rs, timestamp=1000.0)
        for lane in result.lanes:
            d = lane.to_dict()
            assert "lane_id" in d
            assert "marking_status" in d
            assert "evidence" in d
            assert "confidence" in d
