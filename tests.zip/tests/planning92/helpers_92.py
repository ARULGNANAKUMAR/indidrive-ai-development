"""
IndiDrive AI — Phase 9.2 | Test Helpers
=========================================
Minimal mock factories and helpers for Phase 9.2 tests.

Builds on Phase 9.1 helpers (helpers_91.py) — reuses existing mocks where
possible and adds only what is strictly needed for candidate generation tests.
"""
from __future__ import annotations

import sys
import os
import time
from dataclasses import dataclass, field
from typing import List, Optional, Tuple

# Ensure project root is on sys.path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))

from tests.planning.helpers_91 import (
    MockWorldModelSnapshot,
    MockPlanningContext,
    MockSafetyGateState,
    MockPlanningMode,
    MockBoundaryPoint,
    MockBoundarySummary,
    MockDrivableSpaceInfo,
    MockLaneInfo,
    MockAnomalySummary,
    make_planning_input,
    make_empty_input,
    make_village_road_world_model,
    make_market_road_world_model,
    make_cattle_crossing_world_model,
    make_highway_world_model,
    make_pothole_world_model,
    make_unsignalized_intersection_world_model,
    make_planning_context_with_gate,
)

from core.planning import (
    PlanningInput,
    PlanningSpace,
    PlanningSpaceBuilder,
    PlanningSpaceConfig,
    CandidatePathGenerator,
    CandidateGeneratorConfig,
    CandidatePathSet,
    CandidatePath,
    CandidateGenerationStatus,
    GeometricValidity,
    BoundaryValidity,
    DrivableSpaceValidity,
    GenerationMethod,
)


# ---------------------------------------------------------------------------
# Default test config (narrow offsets for predictable boundary tests)
# ---------------------------------------------------------------------------

def make_generator_config(**overrides) -> CandidateGeneratorConfig:
    """Create a CandidateGeneratorConfig with sensible test defaults."""
    defaults = dict(
        enabled=True,
        max_candidates=5,
        sample_resolution_m=5.0,   # coarse for fast tests
        lateral_offsets_m=[0.0, 0.75, -0.75, 1.5, -1.5],
        minimum_path_length_m=5.0,
        maximum_path_length_m=60.0,
        min_waypoints=2,
        max_waypoints=50,
        vehicle_half_width_m=0.5,
        max_lateral_jump_m=2.0,
        boundary_check_enabled=True,
        drivable_space_check_enabled=True,
        deterministic=True,
    )
    defaults.update(overrides)
    return CandidateGeneratorConfig(**defaults)


def make_generator(**config_overrides) -> CandidatePathGenerator:
    return CandidatePathGenerator(make_generator_config(**config_overrides))


# ---------------------------------------------------------------------------
# Planning space factories
# ---------------------------------------------------------------------------

def _build_space(world_model=None, planning_context=None) -> PlanningSpace:
    """Build a PlanningSpace from world model + planning context mocks."""
    builder = PlanningSpaceBuilder()
    pi = make_planning_input(
        world_model=world_model or MockWorldModelSnapshot(),
        planning_context=planning_context or MockPlanningContext(),
    )
    snapshot = builder.build(pi)
    return snapshot.space


def make_default_space() -> PlanningSpace:
    """Standard wide-road planning space (marked, 8 m road, 50 m horizon)."""
    return _build_space()


def make_narrow_space(road_width_m: float = 4.0) -> PlanningSpace:
    """Narrow road planning space."""
    wm = MockWorldModelSnapshot()
    wm.road.drivable_space.road_width_m = road_width_m
    wm.road.drivable_space.left_boundary = MockBoundarySummary(
        available=True,
        points=[
            MockBoundaryPoint(x=0.0, y=road_width_m / 2),
            MockBoundaryPoint(x=50.0, y=road_width_m / 2),
        ],
        confidence=0.7,
    )
    wm.road.drivable_space.right_boundary = MockBoundarySummary(
        available=True,
        points=[
            MockBoundaryPoint(x=0.0, y=-road_width_m / 2),
            MockBoundaryPoint(x=50.0, y=-road_width_m / 2),
        ],
        confidence=0.7,
    )
    return _build_space(wm)


def make_curved_left_space() -> PlanningSpace:
    """Road that curves left: right boundary curves inward, left boundary curves out."""
    wm = MockWorldModelSnapshot()
    wm.road.lane_info.curvature_summary = "MILD_CURVE"
    # Left boundary: starts at y=4, curves to y=6 at x=40
    wm.road.drivable_space.left_boundary = MockBoundarySummary(
        available=True,
        points=[
            MockBoundaryPoint(x=0.0, y=4.0),
            MockBoundaryPoint(x=20.0, y=5.0),
            MockBoundaryPoint(x=40.0, y=6.0),
        ],
        confidence=0.8,
    )
    # Right boundary: starts at y=-4, curves to y=-2 at x=40 (road curving left)
    wm.road.drivable_space.right_boundary = MockBoundarySummary(
        available=True,
        points=[
            MockBoundaryPoint(x=0.0, y=-4.0),
            MockBoundaryPoint(x=20.0, y=-3.0),
            MockBoundaryPoint(x=40.0, y=-2.0),
        ],
        confidence=0.8,
    )
    wm.road.drivable_space.road_width_m = 8.0
    return _build_space(wm)


def make_curved_right_space() -> PlanningSpace:
    """Road that curves right."""
    wm = MockWorldModelSnapshot()
    wm.road.lane_info.curvature_summary = "MILD_CURVE"
    # Left boundary curves inward to the right
    wm.road.drivable_space.left_boundary = MockBoundarySummary(
        available=True,
        points=[
            MockBoundaryPoint(x=0.0, y=4.0),
            MockBoundaryPoint(x=20.0, y=3.0),
            MockBoundaryPoint(x=40.0, y=2.0),
        ],
        confidence=0.8,
    )
    # Right boundary curves out
    wm.road.drivable_space.right_boundary = MockBoundarySummary(
        available=True,
        points=[
            MockBoundaryPoint(x=0.0, y=-4.0),
            MockBoundaryPoint(x=20.0, y=-5.0),
            MockBoundaryPoint(x=40.0, y=-6.0),
        ],
        confidence=0.8,
    )
    wm.road.drivable_space.road_width_m = 8.0
    return _build_space(wm)


def make_unmarked_road_space() -> PlanningSpace:
    """Unmarked road: no lane markings, only boundary info."""
    wm = make_village_road_world_model()
    return _build_space(wm)


def make_restricted_space(gate_state: str = "CRITICAL") -> PlanningSpace:
    """Planning space with an active safety gate restriction."""
    pc = make_planning_context_with_gate(gate_state)
    return _build_space(planning_context=pc)


def make_highway_space() -> PlanningSpace:
    """Wide highway planning space."""
    wm = make_highway_world_model()
    return _build_space(wm)


def make_empty_geometry_space() -> PlanningSpace:
    """Planning space with no boundary / geometry data."""
    wm = MockWorldModelSnapshot()
    wm.road.drivable_space.available = False
    return _build_space(wm)


# ---------------------------------------------------------------------------
# Assertion helpers
# ---------------------------------------------------------------------------

def assert_no_forbidden_fields(path_set: CandidatePathSet) -> None:
    """Recursively verify that no forbidden scoring/control fields exist."""
    FORBIDDEN_ATTRS = {
        "risk_score", "collision_score", "safety_score", "utility_score",
        "path_cost", "obstacle_cost", "ttc_score", "best_score",
        "steering", "throttle", "brake", "acceleration_command", "target_speed",
        "vehicle_control", "mpc", "selected_path", "best_path", "optimal_path",
        "replanning_decision", "winner", "replan", "adaptive_replan",
    }
    # Check set-level
    set_dict = path_set.to_dict()
    for key in FORBIDDEN_ATTRS:
        assert key not in set_dict, f"Forbidden field '{key}' found in CandidatePathSet"

    for candidate in path_set.candidates:
        c_dict = candidate.to_dict()
        for key in FORBIDDEN_ATTRS:
            assert key not in c_dict, (
                f"Forbidden field '{key}' found in candidate {candidate.candidate_id}"
            )
        meta_dict = candidate.metadata.to_dict()
        for key in FORBIDDEN_ATTRS:
            assert key not in meta_dict, (
                f"Forbidden field '{key}' found in candidate metadata"
            )
        for wp in candidate.waypoints:
            wp_dict = wp.to_dict()
            for key in FORBIDDEN_ATTRS:
                assert key not in wp_dict, (
                    f"Forbidden field '{key}' found in PathPoint"
                )


def assert_candidates_deterministic(
    gen: CandidatePathGenerator,
    pi: PlanningInput,
    space: PlanningSpace,
    runs: int = 3,
) -> None:
    """Assert that repeated calls produce identical results."""
    results = [gen.generate(pi, space) for _ in range(runs)]
    first = results[0]
    for r in results[1:]:
        assert r.candidate_count == first.candidate_count, (
            "candidate count differs across runs (non-deterministic)"
        )
        for i, (ca, cb) in enumerate(zip(first.candidates, r.candidates)):
            assert ca.candidate_id == cb.candidate_id, (
                f"candidate[{i}].candidate_id differs: {ca.candidate_id} vs {cb.candidate_id}"
            )
            assert len(ca.waypoints) == len(cb.waypoints), (
                f"candidate[{i}] waypoint count differs"
            )
            for j, (wa, wb) in enumerate(zip(ca.waypoints, cb.waypoints)):
                assert abs(wa.x - wb.x) < 1e-9, (
                    f"candidate[{i}] waypoint[{j}].x differs"
                )
                assert abs(wa.y - wb.y) < 1e-9, (
                    f"candidate[{i}] waypoint[{j}].y differs"
                )
