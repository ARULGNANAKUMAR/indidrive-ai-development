"""
IndiDrive AI — Phase 9.2 | Candidate Geometry Tests
====================================================
Tests geometric properties: lateral offsets, boundary containment,
curved road following, narrow road adaptation, candidate diversity.
"""
from __future__ import annotations

import sys
import os
import math
import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))

from core.planning import (
    CandidatePathGenerator,
    CandidateGeneratorConfig,
    CandidateGenerationStatus,
    GeometricValidity,
    BoundaryValidity,
    GenerationMethod,
)
from tests.planning92.helpers_92 import (
    make_generator,
    make_generator_config,
    make_default_space,
    make_narrow_space,
    make_curved_left_space,
    make_curved_right_space,
    make_unmarked_road_space,
    make_highway_space,
    make_planning_input,
)


# ===========================================================================
# 1. Lateral offset candidates
# ===========================================================================

class TestLateralOffsets:

    def test_center_candidate_present(self):
        gen = make_generator(lateral_offsets_m=[0.0, 0.75, -0.75])
        space = make_default_space()
        pi = make_planning_input()
        result = gen.generate(pi, space)
        ids = [c.candidate_id for c in result.candidates]
        assert "CENTER" in ids, f"CENTER not found in {ids}"

    def test_left_offset_candidate_present(self):
        gen = make_generator(lateral_offsets_m=[0.0, 0.75, -0.75], max_candidates=5)
        space = make_default_space()
        pi = make_planning_input()
        result = gen.generate(pi, space)
        ids = [c.candidate_id for c in result.candidates]
        assert any("LEFT" in cid for cid in ids), f"No LEFT candidate in {ids}"

    def test_right_offset_candidate_present(self):
        gen = make_generator(lateral_offsets_m=[0.0, 0.75, -0.75], max_candidates=5)
        space = make_default_space()
        pi = make_planning_input()
        result = gen.generate(pi, space)
        ids = [c.candidate_id for c in result.candidates]
        assert any("RIGHT" in cid for cid in ids), f"No RIGHT candidate in {ids}"

    def test_center_candidate_y_near_road_center(self):
        gen = make_generator(lateral_offsets_m=[0.0])
        space = make_default_space()
        pi = make_planning_input()
        result = gen.generate(pi, space)
        center = next((c for c in result.candidates if c.candidate_id == "CENTER"), None)
        if center is None:
            pytest.skip("No CENTER candidate generated")
        for wp in center.waypoints:
            assert abs(wp.lateral_offset_m) < 1e-6, (
                f"CENTER candidate has non-zero lateral_offset_m: {wp.lateral_offset_m}"
            )

    def test_left_candidate_y_positive_offset(self):
        gen = make_generator(lateral_offsets_m=[0.0, 0.75], max_candidates=5)
        space = make_default_space()
        pi = make_planning_input()
        result = gen.generate(pi, space)
        left = next((c for c in result.candidates if "LEFT" in c.candidate_id), None)
        if left is None:
            pytest.skip("No LEFT candidate generated")
        # lateral_offset_m should be > 0 (left = positive Y)
        assert left.lateral_offset_m > 0, (
            f"LEFT candidate should have positive lateral offset, got {left.lateral_offset_m}"
        )

    def test_right_candidate_y_negative_offset(self):
        gen = make_generator(lateral_offsets_m=[0.0, -0.75], max_candidates=5)
        space = make_default_space()
        pi = make_planning_input()
        result = gen.generate(pi, space)
        right = next((c for c in result.candidates if "RIGHT" in c.candidate_id), None)
        if right is None:
            pytest.skip("No RIGHT candidate generated")
        assert right.lateral_offset_m < 0, (
            f"RIGHT candidate should have negative lateral offset, got {right.lateral_offset_m}"
        )

    def test_candidates_are_geometrically_distinct(self):
        gen = make_generator(lateral_offsets_m=[0.0, 0.75, -0.75, 1.5, -1.5])
        space = make_default_space()
        pi = make_planning_input()
        result = gen.generate(pi, space)
        if result.candidate_count < 2:
            pytest.skip("Need at least 2 candidates to test distinctness")
        # All candidates must have distinct IDs
        ids = [c.candidate_id for c in result.candidates]
        assert len(ids) == len(set(ids)), f"Duplicate candidate IDs: {ids}"

    def test_candidate_ids_are_unique_in_set(self):
        gen = make_generator()
        space = make_default_space()
        pi = make_planning_input()
        result = gen.generate(pi, space)
        ids = [c.candidate_id for c in result.candidates]
        assert len(ids) == len(set(ids))

    def test_candidate_id_naming_convention(self):
        """CENTER, LEFT_N, RIGHT_N naming must be consistent."""
        gen = make_generator(
            lateral_offsets_m=[0.0, 0.75, 1.5, -0.75, -1.5],
            max_candidates=5
        )
        space = make_default_space()
        pi = make_planning_input()
        result = gen.generate(pi, space)
        for c in result.candidates:
            cid = c.candidate_id
            assert (
                cid == "CENTER"
                or cid.startswith("LEFT_")
                or cid.startswith("RIGHT_")
            ), f"Unexpected candidate ID format: '{cid}'"


# ===========================================================================
# 2. Boundary containment
# ===========================================================================

class TestBoundaryContainment:

    def test_candidates_not_outside_boundary_on_wide_road(self):
        """On a wide 8m road, all generated candidates should be within boundaries."""
        gen = make_generator(
            lateral_offsets_m=[0.0, 0.75, -0.75],
            vehicle_half_width_m=0.5,
        )
        space = make_default_space()  # 8 m wide
        pi = make_planning_input()
        result = gen.generate(pi, space)
        for c in result.candidates:
            assert c.boundary_validity != BoundaryValidity.INVALID, (
                f"Candidate {c.candidate_id} marked INVALID boundary on wide road"
            )

    def test_narrow_road_rejects_wide_offsets(self):
        """On a very narrow 3m road, large offsets should be filtered or rejected."""
        gen = make_generator(
            lateral_offsets_m=[0.0, 0.75, -0.75, 1.5, -1.5],
            vehicle_half_width_m=0.5,
        )
        space = make_narrow_space(road_width_m=3.0)
        pi = make_planning_input()
        result = gen.generate(pi, space)
        # On a 3m road, 1.5m offset from centre hits the boundary
        for c in result.candidates:
            # No candidate should report boundary INVALID within the generated set
            # (invalid candidates should have been filtered during offset filtering)
            pass  # generator should have excluded wide offsets
        # At minimum, CENTER should be present and boundary valid
        center = next((c for c in result.candidates if c.candidate_id == "CENTER"), None)
        if center:
            assert center.boundary_validity in (
                BoundaryValidity.VALID, BoundaryValidity.UNKNOWN
            ), f"CENTER candidate boundary invalid on narrow road: {center.boundary_validity}"

    def test_narrow_road_still_generates_some_candidates(self):
        gen = make_generator(vehicle_half_width_m=0.5)
        space = make_narrow_space(road_width_m=4.0)
        pi = make_planning_input()
        result = gen.generate(pi, space)
        assert result.has_candidates, "Should produce at least one candidate on narrow road"

    def test_waypoints_x_does_not_exceed_horizon(self):
        gen = make_generator()
        space = make_default_space()
        pi = make_planning_input()
        result = gen.generate(pi, space)
        horizon = space.horizon.longitudinal_m
        for c in result.candidates:
            for wp in c.waypoints:
                assert wp.x <= horizon + 0.1, (
                    f"Candidate {c.candidate_id} waypoint x={wp.x:.2f} exceeds "
                    f"horizon={horizon:.2f}"
                )


# ===========================================================================
# 3. Curved road candidates
# ===========================================================================

class TestCurvedRoadCandidates:

    def test_curved_left_road_generates_candidates(self):
        gen = make_generator()
        space = make_curved_left_space()
        pi = make_planning_input()
        result = gen.generate(pi, space)
        assert result.has_candidates, "No candidates on curved-left road"

    def test_curved_right_road_generates_candidates(self):
        gen = make_generator()
        space = make_curved_right_space()
        pi = make_planning_input()
        result = gen.generate(pi, space)
        assert result.has_candidates, "No candidates on curved-right road"

    def test_curved_road_waypoints_are_not_straight_line(self):
        """Waypoints on a curved road should not all have the same y."""
        gen = make_generator(lateral_offsets_m=[0.0], sample_resolution_m=5.0)
        space = make_curved_left_space()
        pi = make_planning_input()
        result = gen.generate(pi, space)
        center = next((c for c in result.candidates if c.candidate_id == "CENTER"), None)
        if center is None or len(center.waypoints) < 3:
            pytest.skip("Need at least 3 CENTER waypoints")
        ys = [wp.y for wp in center.waypoints]
        # On a curved road, y values should vary
        y_range = max(ys) - min(ys)
        assert y_range > 0.01, (
            f"Curved road CENTER candidate appears straight: y range={y_range:.4f}"
        )

    def test_curved_candidates_geometry_valid(self):
        gen = make_generator()
        space = make_curved_left_space()
        pi = make_planning_input()
        result = gen.generate(pi, space)
        for c in result.candidates:
            assert c.geometric_validity in (
                GeometricValidity.VALID, GeometricValidity.PARTIALLY_VALID
            ), f"Candidate {c.candidate_id} has bad geometry on curved road"


# ===========================================================================
# 4. Unmarked road candidates
# ===========================================================================

class TestUnmarkedRoadCandidates:

    def test_unmarked_road_generates_candidates(self):
        gen = make_generator()
        space = make_unmarked_road_space()
        pi = make_planning_input()
        result = gen.generate(pi, space)
        # Should produce at least CENTER even on unmarked road
        assert result.has_candidates or result.generation_status in (
            CandidateGenerationStatus.NO_CANDIDATES_INSUFFICIENT_SPACE,
            CandidateGenerationStatus.EMPTY_NO_VALID_GEOMETRY,
        )

    def test_unmarked_road_method_is_appropriate(self):
        gen = make_generator(lateral_offsets_m=[0.0])
        space = make_unmarked_road_space()
        pi = make_planning_input()
        result = gen.generate(pi, space)
        if not result.has_candidates:
            pytest.skip("No candidates on unmarked road")
        for c in result.candidates:
            assert c.generation_method in (
                GenerationMethod.CENTER,
                GenerationMethod.UNMARKED_ROAD_INFERRED,
                GenerationMethod.LATERAL_OFFSET,
                GenerationMethod.DEGRADED_PARTIAL,
            )


# ===========================================================================
# 5. Highway candidates
# ===========================================================================

class TestHighwayCandidates:

    def test_highway_generates_multiple_candidates(self):
        gen = make_generator(
            lateral_offsets_m=[0.0, 0.75, -0.75, 1.5, -1.5],
            max_candidates=5,
            vehicle_half_width_m=0.5,
        )
        space = make_highway_space()
        pi = make_planning_input()
        result = gen.generate(pi, space)
        assert result.candidate_count >= 2, (
            f"Expected multiple candidates on highway, got {result.candidate_count}"
        )

    def test_highway_wider_allows_more_offsets(self):
        """Wide highway should accommodate more lateral offsets than a village road."""
        gen_hw = make_generator(
            lateral_offsets_m=[0.0, 0.75, -0.75, 1.5, -1.5],
            max_candidates=5, vehicle_half_width_m=0.5,
        )
        gen_vr = make_generator(
            lateral_offsets_m=[0.0, 0.75, -0.75, 1.5, -1.5],
            max_candidates=5, vehicle_half_width_m=0.5,
        )
        pi = make_planning_input()
        hw_result = gen_hw.generate(pi, make_highway_space())
        vr_result = gen_vr.generate(pi, make_unmarked_road_space())
        # Highway should have at least as many candidates as village road
        assert hw_result.candidate_count >= vr_result.candidate_count
