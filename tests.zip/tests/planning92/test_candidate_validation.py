"""
IndiDrive AI — Phase 9.2 | Candidate Validation Tests
======================================================
Tests CandidateValidator: per-candidate and set-level validation,
invalid inputs, duplicate detection, schema version checks.
"""
from __future__ import annotations

import sys
import os
import time
import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))

from core.planning import (
    CandidatePath,
    CandidatePathSet,
    CandidateMetadata,
    PathPoint,
    GenerationMethod,
    GeometricValidity,
    BoundaryValidity,
    DrivableSpaceValidity,
    CandidateGenerationStatus,
    CandidateValidator,
    CandidateValidationResult,
    CandidateSetValidationResult,
    CandidateGeneratorConfig,
    CANDIDATE_PATH_SCHEMA_VERSION,
)
from tests.planning92.helpers_92 import (
    make_generator,
    make_default_space,
    make_planning_input,
)


# ---------------------------------------------------------------------------
# Helper factories for crafting test candidates
# ---------------------------------------------------------------------------

def _make_valid_waypoints(n: int = 5) -> tuple:
    return tuple(
        PathPoint(
            x=float(i * 5),
            y=0.0,
            z=0.0,
            longitudinal_s=float(i * 5),
            lateral_offset_m=0.0,
        )
        for i in range(n)
    )


def _make_valid_candidate(cid: str = "CENTER", offset: float = 0.0) -> CandidatePath:
    wps = _make_valid_waypoints(6)
    return CandidatePath(
        candidate_id=cid,
        frame_id=1,
        timestamp=time.time(),
        coordinate_frame="VEHICLE",
        _waypoints=wps,
        longitudinal_extent_m=wps[-1].x,
        lateral_offset_m=offset,
        generation_method=GenerationMethod.CENTER,
        source_reference="test_space",
        geometric_validity=GeometricValidity.VALID,
        boundary_validity=BoundaryValidity.VALID,
        drivable_space_validity=DrivableSpaceValidity.VALID,
        metadata=CandidateMetadata(
            candidate_index=0,
            path_length_m=25.0,
            waypoint_count=6,
        ),
        schema_version=CANDIDATE_PATH_SCHEMA_VERSION,
    )


def _make_valid_set(candidates=None) -> CandidatePathSet:
    if candidates is None:
        candidates = (_make_valid_candidate("CENTER", 0.0),)
    return CandidatePathSet(
        set_id="test_set_001",
        frame_id=1,
        timestamp=time.time(),
        coordinate_frame="VEHICLE",
        planning_space_ref="test_space",
        safety_gate_state="CLEAR",
        planning_allowed=True,
        _candidates=candidates,
        generation_status=CandidateGenerationStatus.CANDIDATES_GENERATED,
        generation_reason="test",
        schema_version=CANDIDATE_PATH_SCHEMA_VERSION,
    )


# ===========================================================================
# 1. Valid candidate passes
# ===========================================================================

class TestValidCandidatePasses:

    def test_valid_candidate_is_valid(self):
        v = CandidateValidator()
        c = _make_valid_candidate()
        result = v.validate_candidate(c)
        assert result.is_valid, f"Valid candidate failed: {result.errors}"

    def test_valid_set_is_valid(self):
        v = CandidateValidator()
        path_set = _make_valid_set()
        result = v.validate_set(path_set)
        assert result.is_valid, f"Valid set failed: {result.errors}"

    def test_multiple_candidates_in_set(self):
        v = CandidateValidator()
        candidates = (
            _make_valid_candidate("CENTER", 0.0),
            _make_valid_candidate("LEFT_1", 0.75),
            _make_valid_candidate("RIGHT_1", -0.75),
        )
        path_set = _make_valid_set(candidates)
        result = v.validate_set(path_set)
        assert result.is_valid, f"Multi-candidate set failed: {result.errors}"


# ===========================================================================
# 2. Missing or invalid fields
# ===========================================================================

class TestInvalidCandidateFields:

    def test_missing_candidate_id_fails(self):
        v = CandidateValidator()
        c = _make_valid_candidate()
        c.candidate_id = "NOT_AVAILABLE"
        result = v.validate_candidate(c)
        assert not result.is_valid
        assert any("candidate_id" in e for e in result.errors)

    def test_empty_candidate_id_fails(self):
        v = CandidateValidator()
        c = _make_valid_candidate()
        c.candidate_id = ""
        result = v.validate_candidate(c)
        assert not result.is_valid

    def test_negative_frame_id_fails(self):
        v = CandidateValidator()
        c = _make_valid_candidate()
        c.frame_id = -1
        result = v.validate_candidate(c)
        assert not result.is_valid

    def test_nan_timestamp_fails(self):
        import math
        v = CandidateValidator()
        c = _make_valid_candidate()
        c.timestamp = float("nan")
        result = v.validate_candidate(c)
        assert not result.is_valid

    def test_too_few_waypoints_fails(self):
        v = CandidateValidator(CandidateGeneratorConfig(min_waypoints=3))
        wps = tuple(
            PathPoint(x=float(i), y=0.0, z=0.0, longitudinal_s=float(i))
            for i in range(2)  # only 2, below min_waypoints=3
        )
        c = _make_valid_candidate()
        c._waypoints = wps
        result = v.validate_candidate(c)
        assert not result.is_valid
        assert any("min_waypoints" in e for e in result.errors)

    def test_non_finite_waypoint_coordinate_fails(self):
        v = CandidateValidator()
        wps = list(_make_valid_waypoints(5))
        # Inject NaN
        bad = PathPoint(x=float("nan"), y=0.0, z=0.0, longitudinal_s=10.0)
        wps[2] = bad
        c = _make_valid_candidate()
        c._waypoints = tuple(wps)
        result = v.validate_candidate(c)
        assert not result.is_valid

    def test_non_monotone_longitudinal_s_fails(self):
        v = CandidateValidator()
        wps = (
            PathPoint(x=0.0, y=0.0, z=0.0, longitudinal_s=0.0),
            PathPoint(x=5.0, y=0.0, z=0.0, longitudinal_s=5.0),
            PathPoint(x=10.0, y=0.0, z=0.0, longitudinal_s=3.0),  # goes backward
            PathPoint(x=15.0, y=0.0, z=0.0, longitudinal_s=15.0),
        )
        c = _make_valid_candidate()
        c._waypoints = wps
        result = v.validate_candidate(c)
        assert not result.is_valid
        assert any("non-monotone" in e for e in result.errors)

    def test_none_candidate_fails(self):
        v = CandidateValidator()
        result = v.validate_candidate(None)
        assert not result.is_valid

    def test_wrong_schema_version_warns(self):
        v = CandidateValidator()
        c = _make_valid_candidate()
        c.schema_version = "9.0"  # wrong
        result = v.validate_candidate(c)
        assert any("schema_version" in w for w in result.warnings)


# ===========================================================================
# 3. Set-level validation
# ===========================================================================

class TestSetLevelValidation:

    def test_missing_set_id_fails(self):
        v = CandidateValidator()
        path_set = _make_valid_set()
        path_set.set_id = "NOT_AVAILABLE"
        result = v.validate_set(path_set)
        assert not result.is_valid

    def test_negative_set_frame_id_fails(self):
        v = CandidateValidator()
        path_set = _make_valid_set()
        path_set.frame_id = -1
        result = v.validate_set(path_set)
        assert not result.is_valid

    def test_duplicate_candidate_ids_fails(self):
        v = CandidateValidator()
        candidates = (
            _make_valid_candidate("CENTER", 0.0),
            _make_valid_candidate("CENTER", 0.5),  # duplicate ID
        )
        path_set = _make_valid_set(candidates)
        result = v.validate_set(path_set)
        assert not result.is_valid
        assert any("duplicate" in e for e in result.errors)

    def test_none_set_fails(self):
        v = CandidateValidator()
        result = v.validate_set(None)
        assert not result.is_valid

    def test_planning_restriction_status_with_candidates_fails(self):
        """generation_status=NO_CANDIDATES_DUE_TO_PLANNING_RESTRICTION with candidates is inconsistent."""
        v = CandidateValidator()
        c = _make_valid_candidate()
        path_set = _make_valid_set((c,))
        path_set.generation_status = (
            CandidateGenerationStatus.NO_CANDIDATES_DUE_TO_PLANNING_RESTRICTION
        )
        result = v.validate_set(path_set)
        assert not result.is_valid

    def test_candidate_count_above_max_fails(self):
        cfg = CandidateGeneratorConfig(max_candidates=2)
        v = CandidateValidator(cfg)
        candidates = tuple(
            _make_valid_candidate(f"C_{i}", float(i) * 0.5)
            for i in range(3)
        )
        path_set = _make_valid_set(candidates)
        result = v.validate_set(path_set)
        assert not result.is_valid


# ===========================================================================
# 4. Validation result contract
# ===========================================================================

class TestValidationResultContract:

    def test_validation_result_has_to_dict(self):
        v = CandidateValidator()
        c = _make_valid_candidate()
        result = v.validate_candidate(c)
        d = result.to_dict()
        assert "is_valid" in d
        assert "error_count" in d
        assert "errors" in d
        assert "warning_count" in d
        assert "warnings" in d

    def test_set_validation_result_has_to_dict(self):
        v = CandidateValidator()
        path_set = _make_valid_set()
        result = v.validate_set(path_set)
        d = result.to_dict()
        assert "is_valid" in d
        assert "error_count" in d

    def test_generated_candidates_pass_validation(self):
        """Candidates produced by the generator should all pass per-candidate validation."""
        gen = make_generator()
        v = CandidateValidator(gen._config)
        space = make_default_space()
        pi = make_planning_input()
        path_set = gen.generate(pi, space)
        for c in path_set.candidates:
            result = v.validate_candidate(c)
            assert result.is_valid, (
                f"Generator produced invalid candidate {c.candidate_id}: "
                f"{result.errors}"
            )

    def test_generated_set_passes_validation(self):
        """The CandidatePathSet produced by the generator should pass set validation."""
        gen = make_generator()
        v = CandidateValidator(gen._config)
        space = make_default_space()
        pi = make_planning_input()
        path_set = gen.generate(pi, space)
        result = v.validate_set(path_set)
        assert result.is_valid, (
            f"Generator produced invalid set: {result.errors}"
        )
