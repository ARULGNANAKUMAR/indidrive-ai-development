"""
IndiDrive AI — Phase 9.2 | Candidate Determinism Tests
=======================================================
Verifies that the same inputs always produce the same outputs:
same candidate count, same IDs, same waypoint values, same ordering.

No random sampling, no time-dependent values, no non-deterministic sources.
"""
from __future__ import annotations

import sys
import os
import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))

from core.planning import CandidatePathGenerator, CandidateGenerationStatus
from tests.planning92.helpers_92 import (
    make_generator,
    make_generator_config,
    make_default_space,
    make_narrow_space,
    make_curved_left_space,
    make_curved_right_space,
    make_unmarked_road_space,
    make_highway_space,
    make_restricted_space,
    make_planning_input,
    assert_candidates_deterministic,
)
from tests.planning.helpers_91 import make_planning_context_with_gate


# ===========================================================================
# Helpers
# ===========================================================================

def _run(gen, pi, space):
    return gen.generate(pi, space)


def _assert_same_count(a, b, label=""):
    assert a.candidate_count == b.candidate_count, (
        f"{label}: candidate_count {a.candidate_count} != {b.candidate_count}"
    )


def _assert_same_ids(a, b, label=""):
    ids_a = [c.candidate_id for c in a.candidates]
    ids_b = [c.candidate_id for c in b.candidates]
    assert ids_a == ids_b, f"{label}: IDs differ: {ids_a} vs {ids_b}"


def _assert_same_waypoints(a, b, label="", tol=1e-9):
    for i, (ca, cb) in enumerate(zip(a.candidates, b.candidates)):
        assert len(ca.waypoints) == len(cb.waypoints), (
            f"{label}: candidate[{i}] waypoint count differs"
        )
        for j, (wa, wb) in enumerate(zip(ca.waypoints, cb.waypoints)):
            for attr in ("x", "y", "z", "longitudinal_s", "lateral_offset_m"):
                va = getattr(wa, attr)
                vb = getattr(wb, attr)
                assert abs(va - vb) < tol, (
                    f"{label}: candidate[{i}] wp[{j}].{attr} "
                    f"differs: {va} vs {vb}"
                )


# ===========================================================================
# 1. Repeated calls with same inputs
# ===========================================================================

class TestRepeatedCalls:

    def test_default_space_deterministic_5_runs(self):
        gen = make_generator()
        pi = make_planning_input()
        space = make_default_space()
        assert_candidates_deterministic(gen, pi, space, runs=5)

    def test_narrow_space_deterministic(self):
        gen = make_generator(vehicle_half_width_m=0.5)
        pi = make_planning_input()
        space = make_narrow_space(road_width_m=4.0)
        assert_candidates_deterministic(gen, pi, space)

    def test_curved_left_deterministic(self):
        gen = make_generator()
        pi = make_planning_input()
        space = make_curved_left_space()
        assert_candidates_deterministic(gen, pi, space)

    def test_curved_right_deterministic(self):
        gen = make_generator()
        pi = make_planning_input()
        space = make_curved_right_space()
        assert_candidates_deterministic(gen, pi, space)

    def test_unmarked_road_deterministic(self):
        gen = make_generator()
        pi = make_planning_input()
        space = make_unmarked_road_space()
        assert_candidates_deterministic(gen, pi, space)

    def test_highway_deterministic(self):
        gen = make_generator()
        pi = make_planning_input()
        space = make_highway_space()
        assert_candidates_deterministic(gen, pi, space)

    def test_restricted_space_deterministic(self):
        gen = make_generator()
        pi = make_planning_input(
            planning_context=make_planning_context_with_gate("CRITICAL")
        )
        space = make_restricted_space("CRITICAL")
        assert_candidates_deterministic(gen, pi, space)


# ===========================================================================
# 2. Same input → same output (two independent builds)
# ===========================================================================

class TestSameInputSameOutput:

    def test_two_generators_same_config_same_output(self):
        cfg = make_generator_config(
            lateral_offsets_m=[0.0, 0.75, -0.75],
            sample_resolution_m=5.0,
        )
        gen1 = CandidatePathGenerator(cfg)
        gen2 = CandidatePathGenerator(cfg)
        pi = make_planning_input()
        space = make_default_space()
        r1 = gen1.generate(pi, space)
        r2 = gen2.generate(pi, space)
        _assert_same_count(r1, r2, "two_generators")
        _assert_same_ids(r1, r2, "two_generators")
        _assert_same_waypoints(r1, r2, "two_generators")

    def test_same_narrow_space_two_calls(self):
        gen = make_generator(vehicle_half_width_m=0.5)
        pi = make_planning_input()
        space = make_narrow_space(road_width_m=4.0)
        r1 = _run(gen, pi, space)
        r2 = _run(gen, pi, space)
        _assert_same_count(r1, r2, "narrow_space")
        _assert_same_ids(r1, r2, "narrow_space")
        _assert_same_waypoints(r1, r2, "narrow_space")

    def test_same_curved_space_two_calls(self):
        gen = make_generator()
        pi = make_planning_input()
        space = make_curved_left_space()
        r1 = _run(gen, pi, space)
        r2 = _run(gen, pi, space)
        _assert_same_count(r1, r2, "curved_left")
        _assert_same_ids(r1, r2, "curved_left")
        _assert_same_waypoints(r1, r2, "curved_left")


# ===========================================================================
# 3. Ordering is stable
# ===========================================================================

class TestCandidateOrdering:

    def test_candidate_order_stable_across_calls(self):
        gen = make_generator(lateral_offsets_m=[0.0, 0.75, -0.75, 1.5, -1.5])
        pi = make_planning_input()
        space = make_default_space()
        r1 = gen.generate(pi, space)
        r2 = gen.generate(pi, space)
        ids1 = [c.candidate_id for c in r1.candidates]
        ids2 = [c.candidate_id for c in r2.candidates]
        assert ids1 == ids2, f"Candidate order not stable: {ids1} vs {ids2}"

    def test_status_stable_across_calls(self):
        gen = make_generator()
        pi = make_planning_input()
        space = make_default_space()
        statuses = [gen.generate(pi, space).generation_status for _ in range(4)]
        assert len(set(statuses)) == 1, f"Status not stable: {statuses}"


# ===========================================================================
# 4. Configuration changes produce different (but deterministic) results
# ===========================================================================

class TestConfigVariations:

    def test_different_offsets_different_candidates(self):
        cfg_a = make_generator_config(lateral_offsets_m=[0.0, 0.75])
        cfg_b = make_generator_config(lateral_offsets_m=[0.0, 1.5])
        gen_a = CandidatePathGenerator(cfg_a)
        gen_b = CandidatePathGenerator(cfg_b)
        pi = make_planning_input()
        space = make_default_space()
        r_a = gen_a.generate(pi, space)
        r_b = gen_b.generate(pi, space)
        # Both deterministic within themselves
        r_a2 = gen_a.generate(pi, space)
        _assert_same_ids(r_a, r_a2, "config_a_repeat")
        r_b2 = gen_b.generate(pi, space)
        _assert_same_ids(r_b, r_b2, "config_b_repeat")

    def test_max_candidates_1_gives_exactly_1(self):
        cfg = make_generator_config(max_candidates=1)
        gen = CandidatePathGenerator(cfg)
        pi = make_planning_input()
        space = make_default_space()
        r1 = gen.generate(pi, space)
        r2 = gen.generate(pi, space)
        # Exactly 1 candidate, same on both runs
        assert r1.candidate_count <= 1
        assert r2.candidate_count <= 1
        if r1.candidate_count == 1 and r2.candidate_count == 1:
            assert r1.candidates[0].candidate_id == r2.candidates[0].candidate_id

    def test_resolution_affects_waypoint_count_deterministically(self):
        pi = make_planning_input()
        space = make_default_space()

        gen_coarse = make_generator(sample_resolution_m=10.0)
        gen_fine   = make_generator(sample_resolution_m=2.0)

        # Each is internally consistent
        rc1 = gen_coarse.generate(pi, space)
        rc2 = gen_coarse.generate(pi, space)
        rf1 = gen_fine.generate(pi, space)
        rf2 = gen_fine.generate(pi, space)

        if rc1.has_candidates and rc2.has_candidates:
            assert len(rc1.candidates[0].waypoints) == len(rc2.candidates[0].waypoints)
        if rf1.has_candidates and rf2.has_candidates:
            assert len(rf1.candidates[0].waypoints) == len(rf2.candidates[0].waypoints)
        # Fine resolution should give more waypoints than coarse
        if rc1.has_candidates and rf1.has_candidates:
            assert (
                len(rf1.candidates[0].waypoints)
                >= len(rc1.candidates[0].waypoints)
            )


# ===========================================================================
# 5. No time-dependent state leaks
# ===========================================================================

class TestNoTimeDependentState:

    def test_timestamps_may_differ_but_not_waypoints(self):
        """Timestamps are wall-clock and WILL differ, but geometry must not."""
        import time
        gen = make_generator()
        pi = make_planning_input()
        space = make_default_space()
        r1 = gen.generate(pi, space)
        time.sleep(0.01)
        r2 = gen.generate(pi, space)
        # Geometry must be identical
        _assert_same_waypoints(r1, r2, "time_gap")

    def test_candidate_ids_not_time_dependent(self):
        import time
        gen = make_generator()
        pi = make_planning_input()
        space = make_default_space()
        r1 = gen.generate(pi, space)
        time.sleep(0.01)
        r2 = gen.generate(pi, space)
        ids1 = [c.candidate_id for c in r1.candidates]
        ids2 = [c.candidate_id for c in r2.candidates]
        assert ids1 == ids2
