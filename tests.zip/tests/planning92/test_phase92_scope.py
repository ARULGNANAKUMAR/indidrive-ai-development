"""
IndiDrive AI — Phase 9.2 | Scope Enforcement Tests
====================================================
Explicitly verifies that Phase 9.2 does NOT implement anything
that belongs to Phase 9.3+.

Forbidden in Phase 9.2 output:
  - risk_score, collision_score, safety_score, utility_score, path_cost,
    obstacle_cost, ttc_score, best_score
  - steering, throttle, brake, acceleration_command, target_speed,
    vehicle_control, mpc
  - selected_path, best_path, optimal_path, winner
  - replanning_decision, replan, adaptive_replan, replan_trigger

Forbidden in Phase 9.2 module code:
  - A generator method called replan() / adaptive_replan()
  - Any attribute named best_path / selected_path / winner

These tests are structural and behavioural.
"""
from __future__ import annotations

import sys
import os
import inspect
import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))

from core.planning import (
    CandidatePathGenerator,
    CandidateGeneratorConfig,
    CandidatePath,
    CandidatePathSet,
    CandidateMetadata,
    PathPoint,
    CandidateGenerationStatus,
    GeometricValidity,
    BoundaryValidity,
    DrivableSpaceValidity,
    GenerationMethod,
)

import core.planning.candidate_generator as cg_module
import core.planning.candidate_path_types as cp_module

from tests.planning92.helpers_92 import (
    make_generator,
    make_default_space,
    make_highway_space,
    make_unmarked_road_space,
    make_planning_input,
    assert_no_forbidden_fields,
)


# ===========================================================================
# Forbidden field name sets
# ===========================================================================

FORBIDDEN_SCORING = {
    "risk_score", "collision_score", "safety_score", "utility_score",
    "path_cost", "obstacle_cost", "ttc_score", "best_score",
    "collision_probability", "hazard_score", "obstacle_rank",
    "severity_score",
}

FORBIDDEN_CONTROL = {
    "steering", "steering_angle", "steering_command",
    "throttle", "throttle_command",
    "brake", "brake_command",
    "acceleration_command", "acceleration_cmd",
    "target_speed",
    "vehicle_control", "mpc", "control_output",
}

FORBIDDEN_SELECTION = {
    "selected_path", "best_path", "optimal_path", "winner",
    "path_winner", "selected_candidate", "best_candidate",
}

FORBIDDEN_REPLANNING = {
    "replanning_decision", "replan", "adaptive_replan",
    "replan_trigger", "path_recovery", "trigger_replan",
}

ALL_FORBIDDEN = (
    FORBIDDEN_SCORING
    | FORBIDDEN_CONTROL
    | FORBIDDEN_SELECTION
    | FORBIDDEN_REPLANNING
)


# ===========================================================================
# 1. Output field tests
# ===========================================================================

class TestForbiddenOutputFields:

    def _get_result(self):
        gen = make_generator()
        pi = make_planning_input()
        space = make_default_space()
        return gen.generate(pi, space)

    def test_no_risk_score_in_output(self):
        result = self._get_result()
        assert_no_forbidden_fields(result)

    def test_no_collision_score_in_set_dict(self):
        result = self._get_result()
        d = result.to_dict()
        for forbidden in FORBIDDEN_SCORING:
            assert forbidden not in d, f"Forbidden scoring field '{forbidden}' in set dict"

    def test_no_control_fields_in_set_dict(self):
        result = self._get_result()
        d = result.to_dict()
        for forbidden in FORBIDDEN_CONTROL:
            assert forbidden not in d, f"Forbidden control field '{forbidden}' in set dict"

    def test_no_selection_fields_in_set_dict(self):
        result = self._get_result()
        d = result.to_dict()
        for forbidden in FORBIDDEN_SELECTION:
            assert forbidden not in d, f"Forbidden selection field '{forbidden}' in set dict"

    def test_no_replanning_fields_in_set_dict(self):
        result = self._get_result()
        d = result.to_dict()
        for forbidden in FORBIDDEN_REPLANNING:
            assert forbidden not in d, f"Forbidden replanning field '{forbidden}' in set dict"

    def test_no_forbidden_in_candidate_dict(self):
        result = self._get_result()
        for c in result.candidates:
            d = c.to_dict()
            for forbidden in ALL_FORBIDDEN:
                assert forbidden not in d, (
                    f"Forbidden field '{forbidden}' in candidate {c.candidate_id} dict"
                )

    def test_no_forbidden_in_waypoint_dict(self):
        result = self._get_result()
        for c in result.candidates:
            for i, wp in enumerate(c.waypoints):
                d = wp.to_dict()
                for forbidden in ALL_FORBIDDEN:
                    assert forbidden not in d, (
                        f"Forbidden field '{forbidden}' in waypoint[{i}] dict"
                    )

    def test_no_forbidden_in_metadata_dict(self):
        result = self._get_result()
        for c in result.candidates:
            d = c.metadata.to_dict()
            for forbidden in ALL_FORBIDDEN:
                assert forbidden not in d, (
                    f"Forbidden field '{forbidden}' in metadata dict"
                )


# ===========================================================================
# 2. Structural attribute tests (classes themselves)
# ===========================================================================

class TestForbiddenAttributes:

    def test_candidate_path_has_no_risk_score_attr(self):
        c = CandidatePath()
        for f in FORBIDDEN_SCORING:
            assert not hasattr(c, f), f"CandidatePath should not have attribute '{f}'"

    def test_candidate_path_has_no_control_attrs(self):
        c = CandidatePath()
        for f in FORBIDDEN_CONTROL:
            assert not hasattr(c, f), f"CandidatePath should not have attribute '{f}'"

    def test_candidate_path_has_no_selection_attrs(self):
        c = CandidatePath()
        for f in FORBIDDEN_SELECTION:
            assert not hasattr(c, f), f"CandidatePath should not have attribute '{f}'"

    def test_candidate_path_has_no_replan_attrs(self):
        c = CandidatePath()
        for f in FORBIDDEN_REPLANNING:
            assert not hasattr(c, f), f"CandidatePath should not have attribute '{f}'"

    def test_candidate_path_set_has_no_selected_path(self):
        ps = CandidatePathSet()
        for f in FORBIDDEN_SELECTION:
            assert not hasattr(ps, f), f"CandidatePathSet should not have attribute '{f}'"

    def test_path_point_has_no_steering(self):
        wp = PathPoint()
        for f in FORBIDDEN_CONTROL:
            assert not hasattr(wp, f), f"PathPoint should not have attribute '{f}'"

    def test_candidate_metadata_has_no_risk_score(self):
        m = CandidateMetadata()
        for f in FORBIDDEN_SCORING:
            assert not hasattr(m, f), f"CandidateMetadata should not have attribute '{f}'"


# ===========================================================================
# 3. Generator method tests — no replanning methods
# ===========================================================================

class TestForbiddenGeneratorMethods:

    def test_generator_has_no_replan_method(self):
        gen = make_generator()
        assert not hasattr(gen, "replan"), (
            "CandidatePathGenerator must not have a replan() method"
        )

    def test_generator_has_no_adaptive_replan_method(self):
        gen = make_generator()
        assert not hasattr(gen, "adaptive_replan"), (
            "CandidatePathGenerator must not have an adaptive_replan() method"
        )

    def test_generator_has_no_path_recovery_method(self):
        gen = make_generator()
        assert not hasattr(gen, "path_recovery"), (
            "CandidatePathGenerator must not have a path_recovery() method"
        )

    def test_generator_has_no_select_best_method(self):
        gen = make_generator()
        for method in ("select_best", "get_best_path", "get_winner", "get_selected"):
            assert not hasattr(gen, method), (
                f"CandidatePathGenerator must not have a {method}() method"
            )

    def test_candidate_path_set_has_no_winner_property(self):
        ps = CandidatePathSet()
        assert not hasattr(ps, "winner")
        assert not hasattr(ps, "best_path")
        assert not hasattr(ps, "selected_path")
        assert not hasattr(ps, "optimal_path")


# ===========================================================================
# 4. Scope boundary: validity vs quality
# ===========================================================================

class TestValidityVsQuality:

    def test_geometric_validity_is_present(self):
        gen = make_generator()
        pi = make_planning_input()
        space = make_default_space()
        result = gen.generate(pi, space)
        for c in result.candidates:
            # geometric_validity IS allowed in Phase 9.2
            assert hasattr(c, "geometric_validity")
            assert c.geometric_validity in set(GeometricValidity)

    def test_boundary_validity_is_present(self):
        gen = make_generator()
        pi = make_planning_input()
        space = make_default_space()
        result = gen.generate(pi, space)
        for c in result.candidates:
            assert hasattr(c, "boundary_validity")
            assert c.boundary_validity in set(BoundaryValidity)

    def test_drivable_space_validity_is_present(self):
        gen = make_generator()
        pi = make_planning_input()
        space = make_default_space()
        result = gen.generate(pi, space)
        for c in result.candidates:
            assert hasattr(c, "drivable_space_validity")
            assert c.drivable_space_validity in set(DrivableSpaceValidity)

    def test_validity_states_are_not_safety_scores(self):
        """Validity (VALID/INVALID/PARTIALLY_VALID/UNKNOWN) ≠ risk score."""
        from core.planning.candidate_path_types import GeometricValidity
        # Validity states should have no numeric score
        for v in GeometricValidity:
            assert isinstance(v.value, str), (
                f"GeometricValidity.{v.name} has non-string value (should not be numeric)"
            )


# ===========================================================================
# 5. Scope: no steering/throttle in PathPoint
# ===========================================================================

class TestPathPointScope:

    def test_path_point_has_heading_not_steering(self):
        """heading (geometric) is OK; steering_angle (control) is not."""
        wp = PathPoint(x=10.0, y=0.5, heading=0.1)
        assert hasattr(wp, "heading"), "PathPoint must have 'heading' (geometric)"
        assert not hasattr(wp, "steering_angle"), (
            "PathPoint must NOT have 'steering_angle' (control)"
        )

    def test_path_point_has_curvature_not_mpc(self):
        """curvature (geometric) is OK; mpc (control) is not."""
        wp = PathPoint(x=10.0, y=0.5, curvature=0.01)
        assert hasattr(wp, "curvature"), "PathPoint must have 'curvature' (geometric)"
        assert not hasattr(wp, "mpc"), "PathPoint must NOT have 'mpc'"

    def test_path_point_no_longitudinal_speed(self):
        wp = PathPoint()
        assert not hasattr(wp, "target_speed")
        assert not hasattr(wp, "longitudinal_speed")
        assert not hasattr(wp, "velocity")


# ===========================================================================
# 6. Multi-scenario scope enforcement
# ===========================================================================

class TestMultiScenarioScope:

    @pytest.mark.parametrize("space_fn", [
        make_default_space,
        make_highway_space,
        make_unmarked_road_space,
    ])
    def test_no_forbidden_fields_across_scenarios(self, space_fn):
        gen = make_generator()
        pi = make_planning_input()
        space = space_fn()
        result = gen.generate(pi, space)
        assert_no_forbidden_fields(result)


# ===========================================================================
# 7. Configuration: no forbidden keys
# ===========================================================================

class TestConfigScope:

    def test_config_dict_has_no_risk_settings(self):
        cfg = CandidateGeneratorConfig()
        d = cfg.to_dict()
        for forbidden in FORBIDDEN_SCORING | FORBIDDEN_SELECTION | FORBIDDEN_REPLANNING:
            assert forbidden not in d, (
                f"Forbidden key '{forbidden}' found in CandidateGeneratorConfig.to_dict()"
            )

    def test_config_has_no_risk_score_field(self):
        cfg = CandidateGeneratorConfig()
        for f in FORBIDDEN_SCORING:
            assert not hasattr(cfg, f), (
                f"CandidateGeneratorConfig must not have attribute '{f}'"
            )
