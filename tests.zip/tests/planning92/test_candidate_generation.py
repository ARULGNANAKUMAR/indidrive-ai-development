"""
IndiDrive AI — Phase 9.2 | Core Candidate Generation Tests
===========================================================
Tests basic candidate generation, planning-space consumption,
safety gate handling, and API contract.
"""
from __future__ import annotations

import sys
import os
import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))

from core.planning import (
    CandidatePathGenerator,
    CandidateGeneratorConfig,
    CandidatePathSet,
    CandidatePath,
    CandidateGenerationStatus,
    GeometricValidity,
    BoundaryValidity,
    DrivableSpaceValidity,
    GenerationMethod,
    PathPoint,
    CANDIDATE_PATH_SCHEMA_VERSION,
)
from tests.planning92.helpers_92 import (
    make_generator,
    make_generator_config,
    make_default_space,
    make_narrow_space,
    make_restricted_space,
    make_empty_geometry_space,
    make_highway_space,
    make_unmarked_road_space,
    make_planning_input,
    MockPlanningContext,
    make_planning_context_with_gate,
    _build_space,
    assert_no_forbidden_fields,
)
from tests.planning.helpers_91 import MockWorldModelSnapshot


# ===========================================================================
# 1. Basic generation
# ===========================================================================

class TestBasicGeneration:

    def test_generate_returns_candidate_path_set(self):
        gen = make_generator()
        space = make_default_space()
        pi = make_planning_input()
        result = gen.generate(pi, space)
        assert isinstance(result, CandidatePathSet)

    def test_generate_has_candidates_on_normal_space(self):
        gen = make_generator()
        space = make_default_space()
        pi = make_planning_input()
        result = gen.generate(pi, space)
        assert result.has_candidates, "Expected candidates on a normal planning space"

    def test_generate_candidate_count_within_max(self):
        cfg = make_generator_config(max_candidates=3)
        gen = CandidatePathGenerator(cfg)
        space = make_default_space()
        pi = make_planning_input()
        result = gen.generate(pi, space)
        assert result.candidate_count <= 3

    def test_generate_respects_max_candidates_config(self):
        for limit in (1, 2, 5):
            cfg = make_generator_config(max_candidates=limit)
            gen = CandidatePathGenerator(cfg)
            space = make_default_space()
            pi = make_planning_input()
            result = gen.generate(pi, space)
            assert result.candidate_count <= limit

    def test_generate_status_candidates_generated(self):
        gen = make_generator()
        space = make_default_space()
        pi = make_planning_input()
        result = gen.generate(pi, space)
        assert result.generation_status == CandidateGenerationStatus.CANDIDATES_GENERATED

    def test_generate_set_has_schema_version(self):
        gen = make_generator()
        space = make_default_space()
        pi = make_planning_input()
        result = gen.generate(pi, space)
        assert result.schema_version == CANDIDATE_PATH_SCHEMA_VERSION

    def test_generate_set_coordinate_frame_is_vehicle(self):
        gen = make_generator()
        space = make_default_space()
        pi = make_planning_input()
        result = gen.generate(pi, space)
        assert result.coordinate_frame == "VEHICLE"

    def test_generate_set_planning_allowed_preserved(self):
        gen = make_generator()
        space = make_default_space()
        pi = make_planning_input()
        result = gen.generate(pi, space)
        assert result.planning_allowed == space.planning_allowed

    def test_generate_set_safety_gate_state_preserved(self):
        gen = make_generator()
        space = make_default_space()
        pi = make_planning_input()
        result = gen.generate(pi, space)
        assert result.safety_gate_state == space.safety_gate_state


# ===========================================================================
# 2. Candidate structure
# ===========================================================================

class TestCandidateStructure:

    def test_each_candidate_has_id(self):
        gen = make_generator()
        space = make_default_space()
        pi = make_planning_input()
        result = gen.generate(pi, space)
        for c in result.candidates:
            assert c.candidate_id and c.candidate_id != "NOT_AVAILABLE"

    def test_each_candidate_has_waypoints(self):
        gen = make_generator()
        space = make_default_space()
        pi = make_planning_input()
        result = gen.generate(pi, space)
        for c in result.candidates:
            assert c.waypoint_count >= 2, (
                f"Candidate {c.candidate_id} has too few waypoints"
            )

    def test_candidate_coordinate_frame_is_vehicle(self):
        gen = make_generator()
        space = make_default_space()
        pi = make_planning_input()
        result = gen.generate(pi, space)
        for c in result.candidates:
            assert c.coordinate_frame == "VEHICLE"

    def test_candidate_schema_version(self):
        gen = make_generator()
        space = make_default_space()
        pi = make_planning_input()
        result = gen.generate(pi, space)
        for c in result.candidates:
            assert c.schema_version == CANDIDATE_PATH_SCHEMA_VERSION

    def test_candidate_geometric_validity_is_enum_value(self):
        gen = make_generator()
        space = make_default_space()
        pi = make_planning_input()
        result = gen.generate(pi, space)
        valid_values = {v.value for v in GeometricValidity}
        for c in result.candidates:
            assert c.geometric_validity.value in valid_values

    def test_candidate_boundary_validity_is_enum_value(self):
        gen = make_generator()
        space = make_default_space()
        pi = make_planning_input()
        result = gen.generate(pi, space)
        valid_values = {v.value for v in BoundaryValidity}
        for c in result.candidates:
            assert c.boundary_validity.value in valid_values

    def test_candidate_drivable_space_validity_is_enum_value(self):
        gen = make_generator()
        space = make_default_space()
        pi = make_planning_input()
        result = gen.generate(pi, space)
        valid_values = {v.value for v in DrivableSpaceValidity}
        for c in result.candidates:
            assert c.drivable_space_validity.value in valid_values

    def test_candidate_generation_method_is_enum_value(self):
        gen = make_generator()
        space = make_default_space()
        pi = make_planning_input()
        result = gen.generate(pi, space)
        valid_values = {v.value for v in GenerationMethod}
        for c in result.candidates:
            assert c.generation_method.value in valid_values

    def test_candidate_waypoints_are_immutable(self):
        gen = make_generator()
        space = make_default_space()
        pi = make_planning_input()
        result = gen.generate(pi, space)
        for c in result.candidates:
            assert isinstance(c.waypoints, tuple), "waypoints must be a tuple (immutable)"

    def test_candidate_set_candidates_are_immutable(self):
        gen = make_generator()
        space = make_default_space()
        pi = make_planning_input()
        result = gen.generate(pi, space)
        assert isinstance(result.candidates, tuple), "candidates must be a tuple (immutable)"

    def test_candidate_has_longitudinal_extent(self):
        gen = make_generator()
        space = make_default_space()
        pi = make_planning_input()
        result = gen.generate(pi, space)
        for c in result.candidates:
            assert c.longitudinal_extent_m > 0


# ===========================================================================
# 3. Waypoint geometry
# ===========================================================================

class TestWaypointGeometry:

    def test_waypoint_x_monotone_increasing(self):
        gen = make_generator(sample_resolution_m=5.0)
        space = make_default_space()
        pi = make_planning_input()
        result = gen.generate(pi, space)
        for c in result.candidates:
            xs = [wp.x for wp in c.waypoints]
            for i in range(1, len(xs)):
                assert xs[i] >= xs[i - 1] - 1e-6, (
                    f"Candidate {c.candidate_id}: x not monotone at index {i}"
                )

    def test_waypoint_longitudinal_s_monotone(self):
        gen = make_generator(sample_resolution_m=5.0)
        space = make_default_space()
        pi = make_planning_input()
        result = gen.generate(pi, space)
        for c in result.candidates:
            ss = [wp.longitudinal_s for wp in c.waypoints]
            for i in range(1, len(ss)):
                assert ss[i] >= ss[i - 1] - 1e-6, (
                    f"Candidate {c.candidate_id}: longitudinal_s not monotone at {i}"
                )

    def test_waypoints_all_finite(self):
        import math
        gen = make_generator()
        space = make_default_space()
        pi = make_planning_input()
        result = gen.generate(pi, space)
        for c in result.candidates:
            for j, wp in enumerate(c.waypoints):
                for attr in ("x", "y", "z", "longitudinal_s", "lateral_offset_m"):
                    val = getattr(wp, attr)
                    assert math.isfinite(val), (
                        f"Candidate {c.candidate_id} waypoint[{j}].{attr} "
                        f"is not finite: {val}"
                    )

    def test_waypoint_starts_at_or_near_origin(self):
        gen = make_generator()
        space = make_default_space()
        pi = make_planning_input()
        result = gen.generate(pi, space)
        for c in result.candidates:
            assert c.waypoints[0].x >= 0.0

    def test_waypoint_heading_finite_when_set(self):
        import math
        gen = make_generator()
        space = make_default_space()
        pi = make_planning_input()
        result = gen.generate(pi, space)
        for c in result.candidates:
            for j, wp in enumerate(c.waypoints):
                if wp.heading is not None:
                    assert math.isfinite(wp.heading), (
                        f"Candidate {c.candidate_id} wp[{j}].heading is non-finite"
                    )

    def test_waypoint_curvature_finite_when_set(self):
        import math
        gen = make_generator()
        space = make_default_space()
        pi = make_planning_input()
        result = gen.generate(pi, space)
        for c in result.candidates:
            for j, wp in enumerate(c.waypoints):
                if wp.curvature is not None:
                    assert math.isfinite(wp.curvature), (
                        f"Candidate {c.candidate_id} wp[{j}].curvature is non-finite"
                    )


# ===========================================================================
# 4. Safety gate handling
# ===========================================================================

class TestSafetyGateHandling:

    @pytest.mark.parametrize("gate_state", [
        "RESTRICTED", "CRITICAL", "HIGH_ALERT", "DEGRADED", "UNKNOWN",
    ])
    def test_no_candidates_when_planning_not_allowed(self, gate_state):
        gen = make_generator()
        space = make_restricted_space(gate_state)
        pi = make_planning_input(planning_context=make_planning_context_with_gate(gate_state))
        result = gen.generate(pi, space)
        # If planning_allowed is False, no candidates must be generated
        if not space.planning_allowed:
            assert result.candidate_count == 0
            assert result.generation_status == (
                CandidateGenerationStatus.NO_CANDIDATES_DUE_TO_PLANNING_RESTRICTION
            )

    def test_clear_gate_allows_candidates(self):
        from tests.planning92.helpers_92 import MockPlanningContext
        pc = MockPlanningContext()
        pc.safety_gate_state = MockPlanningContext.__dataclass_fields__[
            "safety_gate_state"
        ].default_factory()
        gen = make_generator()
        space = make_default_space()
        pi = make_planning_input()
        result = gen.generate(pi, space)
        assert result.has_candidates

    def test_safety_gate_state_preserved_in_output(self):
        gen = make_generator()
        space = make_default_space()
        pi = make_planning_input()
        result = gen.generate(pi, space)
        assert result.safety_gate_state == space.safety_gate_state

    def test_planning_allowed_preserved_in_output(self):
        gen = make_generator()
        space = make_default_space()
        pi = make_planning_input()
        result = gen.generate(pi, space)
        assert result.planning_allowed == space.planning_allowed


# ===========================================================================
# 5. Empty / degraded input handling
# ===========================================================================

class TestDegradedInput:

    def test_no_geometry_space_returns_structured_result(self):
        gen = make_generator()
        space = make_empty_geometry_space()
        pi = make_planning_input()
        result = gen.generate(pi, space)
        # Must return a structured CandidatePathSet (not raise)
        assert isinstance(result, CandidatePathSet)

    def test_empty_geometry_status_not_candidates_generated_arbitrarily(self):
        gen = make_generator()
        space = make_empty_geometry_space()
        pi = make_planning_input()
        result = gen.generate(pi, space)
        # Should not invent candidates from nothing
        # (may return 0 or fall back to straight-line center)
        if result.candidate_count == 0:
            assert result.generation_status in (
                CandidateGenerationStatus.NO_CANDIDATES_INSUFFICIENT_SPACE,
                CandidateGenerationStatus.EMPTY_NO_VALID_GEOMETRY,
            )

    def test_none_planning_input_handled_gracefully(self):
        gen = make_generator()
        space = make_default_space()
        # Should not raise
        try:
            result = gen.generate(None, space)
            assert isinstance(result, CandidatePathSet)
        except Exception:
            pass  # acceptable to raise on None input

    def test_partial_space_status_reported(self):
        gen = make_generator()
        space = make_empty_geometry_space()
        pi = make_planning_input()
        result = gen.generate(pi, space)
        assert isinstance(result.generation_status, CandidateGenerationStatus)


# ===========================================================================
# 6. to_dict() contract
# ===========================================================================

class TestToDictContract:

    def test_set_to_dict_has_required_keys(self):
        gen = make_generator()
        space = make_default_space()
        pi = make_planning_input()
        result = gen.generate(pi, space)
        d = result.to_dict()
        for key in (
            "set_id", "frame_id", "timestamp", "coordinate_frame",
            "planning_space_ref", "safety_gate_state", "planning_allowed",
            "candidate_count", "candidates", "generation_status",
            "generation_reason", "schema_version",
        ):
            assert key in d, f"Missing key '{key}' in CandidatePathSet.to_dict()"

    def test_candidate_to_dict_has_required_keys(self):
        gen = make_generator()
        space = make_default_space()
        pi = make_planning_input()
        result = gen.generate(pi, space)
        if not result.has_candidates:
            pytest.skip("No candidates generated")
        d = result.candidates[0].to_dict()
        for key in (
            "candidate_id", "frame_id", "timestamp", "coordinate_frame",
            "waypoint_count", "waypoints", "longitudinal_extent_m",
            "lateral_offset_m", "generation_method", "source_reference",
            "geometric_validity", "boundary_validity", "drivable_space_validity",
            "metadata", "schema_version",
        ):
            assert key in d, f"Missing key '{key}' in CandidatePath.to_dict()"

    def test_waypoint_to_dict_has_required_keys(self):
        gen = make_generator()
        space = make_default_space()
        pi = make_planning_input()
        result = gen.generate(pi, space)
        if not result.has_candidates:
            pytest.skip("No candidates generated")
        wp_dict = result.candidates[0].waypoints[0].to_dict()
        for key in ("x", "y", "z", "longitudinal_s", "lateral_offset_m"):
            assert key in wp_dict, f"Missing key '{key}' in PathPoint.to_dict()"
