"""
Phase 9.5 Test Helpers — Shared fixtures and builders.

All fixtures are synthetic and deterministic.  No real-world accuracy
percentages are claimed.
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Optional


# ---------------------------------------------------------------------------
# Minimal stub classes that mirror the real interfaces
# ---------------------------------------------------------------------------

@dataclass
class StubTrafficMix:
    pedestrians_present: bool = False
    motorcycles_present: bool = False
    non_motorised_present: bool = False


@dataclass
class StubRoadsideActivity:
    level: str = "UNKNOWN"


@dataclass
class StubSensorStatus:
    pass


@dataclass
class StubIndianRoadContextSummary:
    """Mirrors PlanningSpace.indian_road_context (IndianRoadContextSummary)."""
    available: bool = True
    road_type: str = "URBAN_ROAD"
    traffic_density: str = "MEDIUM"
    vulnerable_road_users: bool = False
    cattle_present: bool = False
    roadside_activity: str = "LOW"
    market_like_activity: bool = False
    intersection_context: str = "NO_INTERSECTION"
    road_complexity: str = "LOW"
    context_confidence: float = 0.7
    context_uncertainty: float = 0.3
    is_degraded: bool = False
    road_width_m: Optional[float] = None
    traffic_mix: StubTrafficMix = field(default_factory=StubTrafficMix)
    context_flags: list = field(default_factory=list)


@dataclass
class StubSpatialExtent:
    """Mirrors PlanningSpace.spatial_extent."""
    left_boundary_y_m: float = 2.5
    right_boundary_y_m: float = -2.5


@dataclass
class StubPlanningSpaceQuality:
    overall_confidence: float = 0.7
    overall_uncertainty: float = 0.3
    is_degraded: bool = False


@dataclass
class StubStaticHazard:
    hazard_type: str = "POTHOLE"
    lateral_offset_y_m: float = 0.5
    longitudinal_offset_x_m: float = 10.0
    width_m: float = 0.5
    confidence: float = 0.8
    passable: bool = False


@dataclass
class StubPlanningSpace:
    """Minimal PlanningSpace stub."""
    planning_allowed: bool = True
    indian_road_context: Optional[StubIndianRoadContextSummary] = field(
        default_factory=StubIndianRoadContextSummary
    )
    spatial_extent: StubSpatialExtent = field(default_factory=StubSpatialExtent)
    quality: StubPlanningSpaceQuality = field(default_factory=StubPlanningSpaceQuality)
    static_hazards: tuple = field(default_factory=tuple)


@dataclass
class StubPlanningInput:
    frame_id: int = 1
    timestamp: float = field(default_factory=time.time)


# ---------------------------------------------------------------------------
# Scenario builders
# ---------------------------------------------------------------------------

def make_highway_space(lane_confidence: float = 0.85) -> StubPlanningSpace:
    ctx = StubIndianRoadContextSummary(
        road_type="HIGHWAY",
        traffic_density="MEDIUM",
        context_confidence=lane_confidence,
        context_uncertainty=1 - lane_confidence,
        intersection_context="NO_INTERSECTION",
    )
    space = StubPlanningSpace(
        indian_road_context=ctx,
        quality=StubPlanningSpaceQuality(overall_confidence=lane_confidence),
        spatial_extent=StubSpatialExtent(left_boundary_y_m=3.5, right_boundary_y_m=-3.5),
    )
    return space


def make_village_unmarked_space() -> StubPlanningSpace:
    ctx = StubIndianRoadContextSummary(
        road_type="VILLAGE_ROAD",
        traffic_density="LOW",
        context_confidence=0.2,
        context_uncertainty=0.8,
        vulnerable_road_users=True,
        cattle_present=True,
        is_degraded=False,
        road_width_m=4.5,
    )
    space = StubPlanningSpace(
        indian_road_context=ctx,
        quality=StubPlanningSpaceQuality(overall_confidence=0.2),
        spatial_extent=StubSpatialExtent(left_boundary_y_m=2.25, right_boundary_y_m=-2.25),
    )
    return space


def make_narrow_village_space(width_m: float = 3.0) -> StubPlanningSpace:
    ctx = StubIndianRoadContextSummary(
        road_type="VILLAGE_ROAD",
        traffic_density="LOW",
        context_confidence=0.25,
        context_uncertainty=0.75,
        road_width_m=width_m,
    )
    half = width_m / 2.0
    space = StubPlanningSpace(
        indian_road_context=ctx,
        quality=StubPlanningSpaceQuality(overall_confidence=0.25),
        spatial_extent=StubSpatialExtent(left_boundary_y_m=half, right_boundary_y_m=-half),
    )
    return space


def make_busy_market_space() -> StubPlanningSpace:
    mix = StubTrafficMix(pedestrians_present=True, motorcycles_present=True,
                         non_motorised_present=True)
    ctx = StubIndianRoadContextSummary(
        road_type="MARKET_ROAD",
        traffic_density="HIGH",
        context_confidence=0.6,
        vulnerable_road_users=True,
        market_like_activity=True,
        roadside_activity="HIGH",
        traffic_mix=mix,
    )
    space = StubPlanningSpace(
        indian_road_context=ctx,
        quality=StubPlanningSpaceQuality(overall_confidence=0.6),
        spatial_extent=StubSpatialExtent(left_boundary_y_m=2.0, right_boundary_y_m=-2.0),
    )
    return space


def make_cattle_crossing_space() -> StubPlanningSpace:
    ctx = StubIndianRoadContextSummary(
        road_type="VILLAGE_ROAD",
        traffic_density="LOW",
        context_confidence=0.5,
        cattle_present=True,
        road_width_m=5.5,
    )
    space = StubPlanningSpace(
        indian_road_context=ctx,
        quality=StubPlanningSpaceQuality(overall_confidence=0.5),
    )
    return space


def make_wrong_side_traffic_space() -> StubPlanningSpace:
    ctx = StubIndianRoadContextSummary(
        road_type="URBAN_ROAD",
        traffic_density="MEDIUM",
        context_confidence=0.65,
        context_flags=["WRONG_SIDE_TRAFFIC"],
    )
    space = StubPlanningSpace(
        indian_road_context=ctx,
        quality=StubPlanningSpaceQuality(overall_confidence=0.65),
    )
    return space


def make_road_damage_space() -> StubPlanningSpace:
    ctx = StubIndianRoadContextSummary(
        road_type="URBAN_ROAD",
        context_confidence=0.6,
    )
    hazard = StubStaticHazard(
        hazard_type="POTHOLE",
        lateral_offset_y_m=0.3,
        longitudinal_offset_x_m=8.0,
        width_m=0.6,
        confidence=0.85,
    )
    space = StubPlanningSpace(
        indian_road_context=ctx,
        quality=StubPlanningSpaceQuality(overall_confidence=0.6),
        static_hazards=(hazard,),
    )
    return space


def make_weak_lane_space(lane_conf: float = 0.38) -> StubPlanningSpace:
    ctx = StubIndianRoadContextSummary(
        road_type="URBAN_ROAD",
        traffic_density="MEDIUM",
        context_confidence=lane_conf,
    )
    space = StubPlanningSpace(
        indian_road_context=ctx,
        quality=StubPlanningSpaceQuality(overall_confidence=lane_conf),
    )
    return space


def make_intersection_space() -> StubPlanningSpace:
    ctx = StubIndianRoadContextSummary(
        road_type="INTERSECTION_AREA",
        traffic_density="HIGH",
        intersection_context="INTERSECTION",
        context_confidence=0.55,
    )
    space = StubPlanningSpace(
        indian_road_context=ctx,
        quality=StubPlanningSpaceQuality(overall_confidence=0.55),
    )
    return space


def make_missing_context_space() -> StubPlanningSpace:
    """PlanningSpace with no Indian road context."""
    space = StubPlanningSpace(indian_road_context=None)
    return space


def make_unavailable_context_space() -> StubPlanningSpace:
    """Context present but available=False."""
    ctx = StubIndianRoadContextSummary(available=False)
    space = StubPlanningSpace(indian_road_context=ctx)
    return space


def make_dense_mixed_traffic_space() -> StubPlanningSpace:
    mix = StubTrafficMix(pedestrians_present=True, motorcycles_present=True)
    ctx = StubIndianRoadContextSummary(
        road_type="URBAN_ROAD",
        traffic_density="VERY_HIGH",
        context_confidence=0.6,
        vulnerable_road_users=True,
        traffic_mix=mix,
    )
    space = StubPlanningSpace(
        indian_road_context=ctx,
        quality=StubPlanningSpaceQuality(overall_confidence=0.6),
    )
    return space


def make_construction_zone_space() -> StubPlanningSpace:
    ctx = StubIndianRoadContextSummary(
        road_type="CONSTRUCTION_AREA",
        traffic_density="LOW",
        context_confidence=0.5,
    )
    hazard = StubStaticHazard(
        hazard_type="CONSTRUCTION",
        lateral_offset_y_m=-1.0,
        longitudinal_offset_x_m=12.0,
        width_m=1.5,
        confidence=0.9,
        passable=False,
    )
    space = StubPlanningSpace(
        indian_road_context=ctx,
        quality=StubPlanningSpaceQuality(overall_confidence=0.5),
        static_hazards=(hazard,),
    )
    return space


def make_input(frame_id: int = 1) -> StubPlanningInput:
    return StubPlanningInput(frame_id=frame_id)


# Stub ReplanningRequest (Phase 9.4)
@dataclass
class StubReplanningRequest:
    frame_id: int = 1
    urgency: str = "NORMAL"
    decision: str = "REPLAN_REQUESTED"
