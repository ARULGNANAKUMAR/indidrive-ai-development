"""
IndiDrive AI — Phase 9.5 | Indian Road Scenario Suite
Synthetic deterministic fixtures for functional correctness.
No real-world accuracy percentages are claimed.
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))

import pytest
from core.planning.indian_road_planning_adapter import IndianRoadPlanningAdapter
from core.planning.indian_road_planning_types import PlanningMode, NarrowRoadState

from tests.planning95.helpers_95 import (
    StubIndianRoadContextSummary,
    StubPlanningSpace,
    StubPlanningSpaceQuality,
    StubSpatialExtent,
    StubStaticHazard,
    StubTrafficMix,
    make_input,
    make_village_unmarked_space,
    make_narrow_village_space,
    make_busy_market_space,
    make_highway_space,
    make_intersection_space,
    make_cattle_crossing_space,
    make_wrong_side_traffic_space,
    make_road_damage_space,
    make_construction_zone_space,
)


def fresh_build(space, frame_id=1):
    adapter = IndianRoadPlanningAdapter()
    return adapter.build_constraints(make_input(frame_id), space)


# ---------------------------------------------------------------------------
# village_unmarked_road
# ---------------------------------------------------------------------------
class TestVillageUnmarkedRoad:
    def test_drivable_space_or_narrow(self):
        r = fresh_build(make_village_unmarked_space())
        assert r.constraints.planning_mode in (
            PlanningMode.DRIVABLE_SPACE, PlanningMode.NARROW_ROAD,
            PlanningMode.MIXED_TRAFFIC,
        )

    def test_drivable_region_required(self):
        r = fresh_build(make_village_unmarked_space())
        assert r.constraints.drivable_region_required

    def test_cattle_context(self):
        r = fresh_build(make_village_unmarked_space())
        assert r.constraints.traffic_context.has_cattle is True


# ---------------------------------------------------------------------------
# narrow_village_road
# ---------------------------------------------------------------------------
class TestNarrowVillageRoad:
    def test_narrow_road_mode(self):
        r = fresh_build(make_narrow_village_space(width_m=3.0))
        assert r.constraints.planning_mode in (
            PlanningMode.NARROW_ROAD, PlanningMode.DRIVABLE_SPACE
        )

    def test_lateral_range_constrained(self):
        from core.planning.indian_road_planning_config import IndianRoadPlanningConfig
        cfg = IndianRoadPlanningConfig()
        r = fresh_build(make_narrow_village_space(width_m=3.0))
        assert r.constraints.max_lateral_offset_m < cfg.default_max_lateral_offset_m

    def test_narrow_state(self):
        r = fresh_build(make_narrow_village_space(width_m=3.0))
        assert r.constraints.narrow_road_state in (
            NarrowRoadState.NARROW, NarrowRoadState.VERY_NARROW
        )


# ---------------------------------------------------------------------------
# busy_market
# ---------------------------------------------------------------------------
class TestBusyMarket:
    def test_mixed_traffic_mode(self):
        r = fresh_build(make_busy_market_space())
        assert r.constraints.planning_mode == PlanningMode.MIXED_TRAFFIC

    def test_high_density(self):
        r = fresh_build(make_busy_market_space())
        assert r.constraints.traffic_context.high_density

    def test_vru_margin_nonzero(self):
        r = fresh_build(make_busy_market_space())
        assert r.constraints.vulnerable_user_margin_m > 0


# ---------------------------------------------------------------------------
# highway_merge
# ---------------------------------------------------------------------------
class TestHighwayMerge:
    def test_highway_mode(self):
        ctx = StubIndianRoadContextSummary(
            road_type="HIGHWAY_MERGE_AREA",
            context_confidence=0.80,
            traffic_density="MEDIUM",
        )
        space = StubPlanningSpace(indian_road_context=ctx,
                                  quality=StubPlanningSpaceQuality(0.80))
        r = fresh_build(space)
        assert r.constraints.planning_mode == PlanningMode.HIGHWAY

    def test_highway_road_type_in_constraints(self):
        ctx = StubIndianRoadContextSummary(road_type="HIGHWAY", context_confidence=0.82)
        space = StubPlanningSpace(indian_road_context=ctx,
                                  quality=StubPlanningSpaceQuality(0.82))
        r = fresh_build(space)
        assert "HIGHWAY" in r.constraints.road_type


# ---------------------------------------------------------------------------
# unsignalized_intersection
# ---------------------------------------------------------------------------
class TestUnsignalizedIntersection:
    def test_intersection_mode(self):
        r = fresh_build(make_intersection_space())
        assert r.constraints.planning_mode == PlanningMode.INTERSECTION

    def test_schema_version(self):
        r = fresh_build(make_intersection_space())
        assert r.constraints.schema_version == "9.5"


# ---------------------------------------------------------------------------
# cattle_crossing
# ---------------------------------------------------------------------------
class TestCattleCrossing:
    def test_cattle_clearance_nonzero(self):
        r = fresh_build(make_cattle_crossing_space())
        assert r.constraints.cattle_clearance_margin_m > 0

    def test_cattle_flag_true(self):
        r = fresh_build(make_cattle_crossing_space())
        assert r.constraints.traffic_context.has_cattle is True

    def test_no_control_outputs(self):
        r = fresh_build(make_cattle_crossing_space())
        for forbidden in ("steering", "throttle", "brake", "target_speed",
                          "vehicle_control", "selected_path", "best_path", "optimal_path"):
            assert not hasattr(r.constraints, forbidden), f"Found forbidden field: {forbidden}"


# ---------------------------------------------------------------------------
# wrong_side_traffic
# ---------------------------------------------------------------------------
class TestWrongSideTraffic:
    def test_wrong_side_flag(self):
        r = fresh_build(make_wrong_side_traffic_space())
        assert r.constraints.traffic_context.has_wrong_side_traffic is True

    def test_wrong_side_margin(self):
        r = fresh_build(make_wrong_side_traffic_space())
        assert r.constraints.wrong_side_margin_m > 0


# ---------------------------------------------------------------------------
# damaged_narrow_road
# ---------------------------------------------------------------------------
class TestDamagedNarrowRoad:
    def test_anomaly_constraints_present(self):
        r = fresh_build(make_road_damage_space())
        assert len(r.constraints.road_anomaly_constraints) > 0

    def test_avoidance_margin_positive(self):
        r = fresh_build(make_road_damage_space())
        for ac in r.constraints.road_anomaly_constraints:
            assert ac.avoidance_margin_m > 0


# ---------------------------------------------------------------------------
# pedestrian_market
# ---------------------------------------------------------------------------
class TestPedestrianMarket:
    def test_pedestrian_flag(self):
        mix = StubTrafficMix(pedestrians_present=True)
        ctx = StubIndianRoadContextSummary(
            road_type="MARKET_ROAD",
            traffic_density="HIGH",
            context_confidence=0.6,
            vulnerable_road_users=True,
            market_like_activity=True,
            traffic_mix=mix,
        )
        space = StubPlanningSpace(indian_road_context=ctx,
                                  quality=StubPlanningSpaceQuality(0.6))
        r = fresh_build(space)
        assert r.constraints.traffic_context.has_pedestrians is True
        assert r.constraints.traffic_context.has_vulnerable_road_users is True


# ---------------------------------------------------------------------------
# mixed_motorcycle_traffic
# ---------------------------------------------------------------------------
class TestMixedMotorcycleTraffic:
    def test_motorcycle_flag(self):
        mix = StubTrafficMix(motorcycles_present=True)
        ctx = StubIndianRoadContextSummary(
            road_type="URBAN_ROAD",
            traffic_density="HIGH",
            context_confidence=0.65,
            traffic_mix=mix,
        )
        space = StubPlanningSpace(indian_road_context=ctx,
                                  quality=StubPlanningSpaceQuality(0.65))
        r = fresh_build(space)
        assert r.constraints.traffic_context.has_motorcycles is True
        assert r.constraints.planning_mode == PlanningMode.MIXED_TRAFFIC


# ---------------------------------------------------------------------------
# construction_zone
# ---------------------------------------------------------------------------
class TestConstructionZone:
    def test_construction_anomaly(self):
        r = fresh_build(make_construction_zone_space())
        assert len(r.constraints.road_anomaly_constraints) > 0

    def test_construction_type_in_anomaly(self):
        r = fresh_build(make_construction_zone_space())
        types = [ac.anomaly_type for ac in r.constraints.road_anomaly_constraints]
        assert any("CONSTRUCTION" in t for t in types)
