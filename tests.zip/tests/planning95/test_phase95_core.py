"""
IndiDrive AI — Phase 9.5 | Core Tests
Tests 1–16: required scenarios from the spec + determinism + validation.
"""
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))

import pytest
from core.planning.indian_road_planning_adapter import IndianRoadPlanningAdapter
from core.planning.indian_road_planning_config import IndianRoadPlanningConfig
from core.planning.indian_road_planning_types import (
    PlanningMode,
    LaneUsageMode,
    NarrowRoadState,
    IndianRoadPlanningConstraints,
    IndianRoadPlanningResult,
)

from tests.planning95.helpers_95 import (
    make_highway_space,
    make_village_unmarked_space,
    make_narrow_village_space,
    make_busy_market_space,
    make_cattle_crossing_space,
    make_wrong_side_traffic_space,
    make_road_damage_space,
    make_weak_lane_space,
    make_missing_context_space,
    make_unavailable_context_space,
    make_dense_mixed_traffic_space,
    make_intersection_space,
    make_construction_zone_space,
    make_input,
    StubReplanningRequest,
)


# ---------------------------------------------------------------------------
# Helper
# ---------------------------------------------------------------------------

def build(space, planning_input=None, replanning=None, cfg=None):
    """Build constraints with a fresh (no-hysteresis) adapter."""
    adapter = IndianRoadPlanningAdapter(config=cfg)
    inp = planning_input or make_input()
    return adapter.build_constraints(inp, space, replanning)


# ---------------------------------------------------------------------------
# Test 1 — Marked highway → LANE_GUIDED
# ---------------------------------------------------------------------------

class TestMarkedHighway:
    def test_mode_is_lane_guided_or_highway(self):
        result = build(make_highway_space(lane_confidence=0.85))
        assert result.constraints.planning_mode in (
            PlanningMode.HIGHWAY, PlanningMode.LANE_GUIDED
        ), f"Unexpected mode: {result.constraints.planning_mode}"

    def test_status_ok(self):
        result = build(make_highway_space())
        assert result.status in ("OK", "DEGRADED")

    def test_lane_usage_strict(self):
        result = build(make_highway_space(lane_confidence=0.85))
        assert result.constraints.lane_usage_mode in (
            LaneUsageMode.STRICT, LaneUsageMode.ADVISORY
        )

    def test_no_vehicle_control_fields(self):
        result = build(make_highway_space())
        c = result.constraints
        assert not hasattr(c, "steering")
        assert not hasattr(c, "throttle")
        assert not hasattr(c, "brake")
        assert not hasattr(c, "target_speed")
        assert not hasattr(c, "selected_path")
        assert not hasattr(c, "best_path")
        assert not hasattr(c, "optimal_path")


# ---------------------------------------------------------------------------
# Test 2 — Unmarked village road → DRIVABLE_SPACE
# ---------------------------------------------------------------------------

class TestUnmarkedVillageRoad:
    def test_mode_is_drivable_space(self):
        result = build(make_village_unmarked_space())
        assert result.constraints.planning_mode in (
            PlanningMode.DRIVABLE_SPACE, PlanningMode.NARROW_ROAD,
            PlanningMode.MIXED_TRAFFIC,
        ), f"Unexpected mode: {result.constraints.planning_mode}"

    def test_drivable_region_required(self):
        result = build(make_village_unmarked_space())
        assert result.constraints.drivable_region_required is True

    def test_lane_usage_not_strict(self):
        result = build(make_village_unmarked_space())
        assert result.constraints.lane_usage_mode != LaneUsageMode.STRICT

    def test_cattle_margin_positive(self):
        result = build(make_village_unmarked_space())
        assert result.constraints.cattle_clearance_margin_m > 0


# ---------------------------------------------------------------------------
# Test 3 — Narrow village road → NARROW_ROAD with reduced lateral freedom
# ---------------------------------------------------------------------------

class TestNarrowVillageRoad:
    def test_mode_narrow_road(self):
        result = build(make_narrow_village_space(width_m=3.0))
        assert result.constraints.planning_mode in (
            PlanningMode.NARROW_ROAD, PlanningMode.DRIVABLE_SPACE
        ), f"Unexpected mode: {result.constraints.planning_mode}"

    def test_reduced_lateral_offset(self):
        cfg = IndianRoadPlanningConfig()
        result = build(make_narrow_village_space(width_m=3.0), cfg=cfg)
        assert result.constraints.max_lateral_offset_m <= cfg.default_max_lateral_offset_m

    def test_narrow_road_state(self):
        result = build(make_narrow_village_space(width_m=3.0))
        assert result.constraints.narrow_road_state in (
            NarrowRoadState.NARROW, NarrowRoadState.VERY_NARROW
        )


# ---------------------------------------------------------------------------
# Test 4 — Busy market → MIXED_TRAFFIC + clearance constraints
# ---------------------------------------------------------------------------

class TestBusyMarket:
    def test_mode_mixed_traffic(self):
        result = build(make_busy_market_space())
        assert result.constraints.planning_mode == PlanningMode.MIXED_TRAFFIC

    def test_vru_margin_positive(self):
        result = build(make_busy_market_space())
        assert result.constraints.vulnerable_user_margin_m > 0

    def test_drivable_region_required(self):
        result = build(make_busy_market_space())
        assert result.constraints.drivable_region_required is True

    def test_traffic_context_market_like(self):
        result = build(make_busy_market_space())
        assert result.constraints.traffic_context.market_like is True


# ---------------------------------------------------------------------------
# Test 5 — Cattle crossing → cattle-aware planning constraint
# ---------------------------------------------------------------------------

class TestCattleCrossing:
    def test_cattle_flag_in_traffic_context(self):
        result = build(make_cattle_crossing_space())
        assert result.constraints.traffic_context.has_cattle is True

    def test_cattle_clearance_margin_positive(self):
        result = build(make_cattle_crossing_space())
        assert result.constraints.cattle_clearance_margin_m > 0

    def test_no_selected_path_field(self):
        result = build(make_cattle_crossing_space())
        assert not hasattr(result.constraints, "selected_path")


# ---------------------------------------------------------------------------
# Test 6 — Wrong-side traffic → dynamic conflict not suppressed
# ---------------------------------------------------------------------------

class TestWrongSideTraffic:
    def test_wrong_side_flag_propagated(self):
        result = build(make_wrong_side_traffic_space())
        assert result.constraints.traffic_context.has_wrong_side_traffic is True

    def test_wrong_side_margin_positive(self):
        result = build(make_wrong_side_traffic_space())
        assert result.constraints.wrong_side_margin_m > 0

    def test_mode_not_lane_guided_strictly(self):
        # wrong-side traffic should not blindly assume lane-consistent motion
        result = build(make_wrong_side_traffic_space())
        # Mode could be LANE_GUIDED but wrong_side flag must be present
        # (Phase 9.3 handles the actual risk — 9.5 just flags it)
        assert result.constraints.traffic_context.has_wrong_side_traffic is True


# ---------------------------------------------------------------------------
# Test 7 — Road damage → anomaly constraint present
# ---------------------------------------------------------------------------

class TestRoadDamage:
    def test_anomaly_constraints_not_empty(self):
        result = build(make_road_damage_space())
        assert len(result.constraints.road_anomaly_constraints) > 0

    def test_anomaly_type_present(self):
        result = build(make_road_damage_space())
        types = [c.anomaly_type for c in result.constraints.road_anomaly_constraints]
        assert any("POTHOLE" in t or "ROAD" in t or t != "UNKNOWN" for t in types)

    def test_avoidance_margin_positive(self):
        result = build(make_road_damage_space())
        for ac in result.constraints.road_anomaly_constraints:
            assert ac.avoidance_margin_m >= 0


# ---------------------------------------------------------------------------
# Test 8 — Weak lane markings → fallback toward drivable-space + uncertainty preserved
# ---------------------------------------------------------------------------

class TestWeakLaneMarkings:
    def test_mode_not_lane_guided(self):
        result = build(make_weak_lane_space(lane_conf=0.38))
        assert result.constraints.planning_mode != PlanningMode.LANE_GUIDED

    def test_uncertainty_above_zero(self):
        result = build(make_weak_lane_space(lane_conf=0.38))
        assert result.constraints.uncertainty > 0

    def test_lane_usage_advisory_or_ignore(self):
        result = build(make_weak_lane_space(lane_conf=0.38))
        assert result.constraints.lane_usage_mode in (
            LaneUsageMode.ADVISORY, LaneUsageMode.IGNORE
        )


# ---------------------------------------------------------------------------
# Test 9 — Missing lane data → no crash, drivable-space fallback
# ---------------------------------------------------------------------------

class TestMissingLaneData:
    def test_no_crash_missing_context(self):
        result = build(make_missing_context_space())
        assert isinstance(result, IndianRoadPlanningResult)

    def test_degraded_or_fallback_status(self):
        result = build(make_missing_context_space())
        assert result.status in ("DEGRADED", "FALLBACK", "OK")

    def test_drivable_region_required(self):
        result = build(make_missing_context_space())
        assert result.constraints.drivable_region_required is True

    def test_planning_mode_safe(self):
        result = build(make_missing_context_space())
        assert result.constraints.planning_mode in (
            PlanningMode.DEGRADED, PlanningMode.DRIVABLE_SPACE,
            PlanningMode.UNKNOWN, PlanningMode.NARROW_ROAD,
        )


# ---------------------------------------------------------------------------
# Test 10 — Missing road context → generic fallback, degraded/uncertain state
# ---------------------------------------------------------------------------

class TestMissingRoadContext:
    def test_no_crash_unavailable_context(self):
        result = build(make_unavailable_context_space())
        assert isinstance(result, IndianRoadPlanningResult)

    def test_degraded_true_when_context_unavailable(self):
        result = build(make_unavailable_context_space())
        assert result.constraints.degraded is True

    def test_uncertainty_high(self):
        result = build(make_unavailable_context_space())
        assert result.constraints.uncertainty >= 0.5

    def test_no_crash_none_planning_space(self):
        adapter = IndianRoadPlanningAdapter()
        result = adapter.build_constraints(make_input(), None)
        assert isinstance(result, IndianRoadPlanningResult)
        assert result.constraints.degraded is True


# ---------------------------------------------------------------------------
# Test 11 — Dense mixed traffic → MIXED_TRAFFIC mode
# ---------------------------------------------------------------------------

class TestDenseMixedTraffic:
    def test_mode_is_mixed_traffic(self):
        result = build(make_dense_mixed_traffic_space())
        assert result.constraints.planning_mode == PlanningMode.MIXED_TRAFFIC

    def test_lateral_offset_reduced(self):
        cfg = IndianRoadPlanningConfig()
        result = build(make_dense_mixed_traffic_space(), cfg=cfg)
        assert result.constraints.max_lateral_offset_m <= cfg.default_max_lateral_offset_m

    def test_traffic_context_high_density(self):
        result = build(make_dense_mixed_traffic_space())
        assert result.constraints.traffic_context.high_density is True


# ---------------------------------------------------------------------------
# Test 12 — Unsignalized intersection → intersection-aware context
# ---------------------------------------------------------------------------

class TestUnsignalizedIntersection:
    def test_mode_is_intersection(self):
        result = build(make_intersection_space())
        assert result.constraints.planning_mode == PlanningMode.INTERSECTION

    def test_schema_version_correct(self):
        result = build(make_intersection_space())
        assert result.constraints.schema_version == "9.5"


# ---------------------------------------------------------------------------
# Test 13 — Highway merge → highway-aware constraints
# ---------------------------------------------------------------------------

class TestHighwayMerge:
    def test_mode_is_highway(self):
        from tests.planning95.helpers_95 import StubIndianRoadContextSummary, StubPlanningSpace, StubPlanningSpaceQuality
        ctx = StubIndianRoadContextSummary(
            road_type="HIGHWAY_MERGE_AREA",
            context_confidence=0.75,
        )
        space = StubPlanningSpace(
            indian_road_context=ctx,
            quality=StubPlanningSpaceQuality(overall_confidence=0.75),
        )
        result = build(space)
        assert result.constraints.planning_mode == PlanningMode.HIGHWAY

    def test_road_type_field(self):
        from tests.planning95.helpers_95 import StubIndianRoadContextSummary, StubPlanningSpace, StubPlanningSpaceQuality
        ctx = StubIndianRoadContextSummary(road_type="HIGHWAY_MERGE_AREA", context_confidence=0.75)
        space = StubPlanningSpace(indian_road_context=ctx, quality=StubPlanningSpaceQuality(0.75))
        result = build(space)
        assert "HIGHWAY" in result.constraints.road_type


# ---------------------------------------------------------------------------
# Test 14 — Mode hysteresis — small confidence changes do not flip mode
# ---------------------------------------------------------------------------

class TestModeHysteresis:
    def test_mode_does_not_flip_on_small_change(self):
        cfg = IndianRoadPlanningConfig(
            mode_persistence_frames=3,
            lane_confidence_threshold=0.60,
            unmarked_road_threshold=0.30,
        )
        adapter = IndianRoadPlanningAdapter(config=cfg)

        # Start with highway (HIGHWAY mode)
        hw = make_highway_space(lane_confidence=0.85)
        r0 = adapter.build_constraints(make_input(1), hw)
        initial_mode = r0.constraints.planning_mode

        # Small dip — should stay in same mode for 2 frames
        weak = make_weak_lane_space(lane_conf=0.38)
        r1 = adapter.build_constraints(make_input(2), weak)
        r2 = adapter.build_constraints(make_input(3), weak)

        # Mode should NOT have flipped after just 1 frame of weakness
        # (first frame — counter hasn't reached persistence_frames)
        # At minimum, mode should not crash
        assert r1.constraints.planning_mode in list(PlanningMode)
        assert r2.constraints.planning_mode in list(PlanningMode)

    def test_mode_switches_after_persistence(self):
        """After enough frames, mode should eventually settle on new value."""
        cfg = IndianRoadPlanningConfig(mode_persistence_frames=2)
        adapter = IndianRoadPlanningAdapter(config=cfg)

        weak = make_weak_lane_space(lane_conf=0.20)
        for i in range(5):
            result = adapter.build_constraints(make_input(i), weak)

        # After 5 frames below threshold, mode should have settled
        assert result.constraints.planning_mode != PlanningMode.LANE_GUIDED


# ---------------------------------------------------------------------------
# Test 15 — Determinism — same input twice → identical output
# ---------------------------------------------------------------------------

class TestDeterminism:
    def test_same_input_same_mode(self):
        space = make_busy_market_space()
        inp = make_input(42)

        r1 = build(space, inp)
        r2 = build(space, inp)
        assert r1.constraints.planning_mode == r2.constraints.planning_mode

    def test_same_input_same_lateral_offset(self):
        space = make_narrow_village_space()
        inp = make_input(7)

        r1 = build(space, inp)
        r2 = build(space, inp)
        assert r1.constraints.max_lateral_offset_m == r2.constraints.max_lateral_offset_m

    def test_same_input_same_anomaly_constraints(self):
        space = make_road_damage_space()
        inp = make_input(3)

        r1 = build(space, inp)
        r2 = build(space, inp)
        assert len(r1.constraints.road_anomaly_constraints) == \
               len(r2.constraints.road_anomaly_constraints)


# ---------------------------------------------------------------------------
# Test 16 — Invalid input → validation error or safe degraded state
# ---------------------------------------------------------------------------

class TestInvalidInput:
    def test_none_planning_space_no_crash(self):
        adapter = IndianRoadPlanningAdapter()
        result = adapter.build_constraints(None, None)
        assert isinstance(result, IndianRoadPlanningResult)

    def test_none_planning_space_degraded(self):
        adapter = IndianRoadPlanningAdapter()
        result = adapter.build_constraints(make_input(), None)
        assert result.constraints.degraded is True
        assert result.constraints.planning_mode in (
            PlanningMode.DEGRADED, PlanningMode.UNKNOWN
        )

    def test_disabled_config_returns_fallback(self):
        cfg = IndianRoadPlanningConfig(enabled=False)
        adapter = IndianRoadPlanningAdapter(config=cfg)
        result = adapter.build_constraints(make_input(), make_highway_space())
        assert result.status == "FALLBACK"
        assert result.constraints.degraded is True
