"""
IndiDrive AI — Phase 9.5 | Integration + Scope Tests

Tests:
  - Phase 9.2 integration: constraints reach candidate generator
  - Phase 9.3 integration: candidate paths still evaluated by risk engine
  - Phase 9.4 integration: ReplanningRequest can trigger 9.5 context refresh
  - Scope tests: forbidden outputs never present in 9.5 output
  - Config round-trip
  - Validation tests
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))

import pytest
import math

from core.planning.indian_road_planning_adapter import IndianRoadPlanningAdapter
from core.planning.indian_road_planning_config import (
    IndianRoadPlanningConfig, load_indian_road_planning_config
)
from core.planning.indian_road_planning_types import (
    PlanningMode, LaneUsageMode, NarrowRoadState,
    IndianRoadPlanningConstraints, IndianRoadPlanningResult,
    INDIAN_ROAD_PLANNING_SCHEMA_VERSION,
)
from core.planning import (
    CandidatePathGenerator, CandidateGeneratorConfig,
    PlanningInput, PlanningSpace, PlanningSpaceBuilder,
    PlanningSpaceConfig,
    # Phase 9.3
    PathRiskEngine, PathRiskConfig,
    # Phase 9.4
    ReplanningEngine, ReplanningConfig,
    ActivePath, ReplanningContext,
)

from tests.planning95.helpers_95 import (
    make_highway_space, make_village_unmarked_space, make_narrow_village_space,
    make_busy_market_space, make_cattle_crossing_space,
    make_wrong_side_traffic_space, make_road_damage_space,
    make_missing_context_space, make_dense_mixed_traffic_space,
    make_intersection_space, make_input, StubReplanningRequest,
    make_construction_zone_space,
)
from tests.planning95.helpers_95 import (
    StubIndianRoadContextSummary, StubPlanningSpace, StubPlanningSpaceQuality,
)


def build(space, inp=None, replanning=None, cfg=None):
    adapter = IndianRoadPlanningAdapter(config=cfg)
    return adapter.build_constraints(inp or make_input(), space, replanning)


# ---------------------------------------------------------------------------
# Phase 9.2 Integration
# ---------------------------------------------------------------------------

class TestPhase92Integration:
    """
    Verify IndianRoadPlanningConstraints reach Phase 9.2 candidate generator.
    9.5 builds constraints → those constrain how 9.2 is called.
    We verify the constraint values are within expected ranges for each
    road type, rather than requiring a specific candidate count.
    """

    def test_narrow_road_constraints_reduce_lateral_freedom(self):
        """Narrow road: 9.5 constraints should reduce lateral offset range."""
        result_narrow = build(make_narrow_village_space(width_m=3.0))
        result_wide = build(make_highway_space())
        # Narrow road must have <= lateral offset than highway
        assert (
            result_narrow.constraints.max_lateral_offset_m
            <= result_wide.constraints.max_lateral_offset_m
        )

    def test_drivable_space_mode_constrains_lane_usage(self):
        """Unmarked road: drivable-space mode sets lane usage to IGNORE."""
        result = build(make_village_unmarked_space())
        assert result.constraints.lane_usage_mode in (
            LaneUsageMode.IGNORE, LaneUsageMode.ADVISORY
        )

    def test_candidate_generator_accepts_default_config(self):
        """CandidatePathGenerator is importable and can be constructed."""
        gen = CandidatePathGenerator()
        assert gen is not None

    def test_constraints_reach_candidate_generator_via_config(self):
        """
        Build 9.5 constraints for narrow road and verify max_lateral_offset_m
        is within valid range to pass to CandidateGeneratorConfig.
        """
        result = build(make_narrow_village_space(width_m=3.0))
        c = result.constraints
        # max_lateral_offset_m from 9.5 should be finite and non-negative
        assert math.isfinite(c.max_lateral_offset_m)
        assert c.max_lateral_offset_m >= 0.0

    def test_unmarked_road_drivable_region_flag(self):
        """Unmarked road: drivable_region_required=True informs candidate gen."""
        result = build(make_village_unmarked_space())
        assert result.constraints.drivable_region_required is True

    def test_construction_anomaly_constraints_for_92(self):
        """Construction zone: anomaly constraints available for phase 9.2."""
        result = build(make_construction_zone_space())
        # Constraints must be serialisable (to_dict check)
        d = result.constraints.to_dict()
        assert "road_anomaly_constraints" in d


# ---------------------------------------------------------------------------
# Phase 9.3 Integration
# ---------------------------------------------------------------------------

class TestPhase93Integration:
    """
    Verify Phase 9.5 does NOT replace Phase 9.3 risk scoring.
    9.5 provides constraints; 9.3 must still evaluate path risk independently.
    """

    def test_constraints_have_no_risk_score(self):
        """IndianRoadPlanningConstraints must not contain a risk score."""
        result = build(make_busy_market_space())
        c = result.constraints
        for forbidden in ("risk", "risk_score", "collision_probability", "ttc"):
            assert not hasattr(c, forbidden), f"Forbidden field found: {forbidden}"

    def test_path_risk_engine_importable(self):
        """PathRiskEngine (Phase 9.3) must still be importable."""
        engine = PathRiskEngine()
        assert engine is not None

    def test_no_risk_scoring_in_result(self):
        """IndianRoadPlanningResult must not contain risk assessments."""
        result = build(make_cattle_crossing_space())
        for forbidden in ("risk", "path_risk", "path_risk_set", "collision"):
            assert not hasattr(result, forbidden), f"Forbidden field in result: {forbidden}"

    def test_phase93_not_duplicated_in_95(self):
        """
        9.5 constraints contain clearance margins (inputs to 9.2),
        NOT path risk scores (9.3's output).
        """
        result = build(make_busy_market_space())
        c = result.constraints
        # clearance margins are present (9.5's job)
        assert hasattr(c, "obstacle_clearance_margin_m")
        assert hasattr(c, "cattle_clearance_margin_m")
        # path risk score is NOT present (9.3's job)
        assert not hasattr(c, "path_risk_score")
        assert not hasattr(c, "collision_probability")


# ---------------------------------------------------------------------------
# Phase 9.4 Integration
# ---------------------------------------------------------------------------

class TestPhase94Integration:
    """
    Verify 9.4 ReplanningRequest can trigger 9.5 context re-evaluation.
    """

    def test_build_with_replanning_request_no_crash(self):
        replan = StubReplanningRequest(frame_id=5, urgency="URGENT")
        adapter = IndianRoadPlanningAdapter()
        result = adapter.build_constraints(make_input(5), make_busy_market_space(), replan)
        assert isinstance(result, IndianRoadPlanningResult)

    def test_replanning_triggers_context_refresh(self):
        """9.5 re-evaluates context for each call (including from 9.4 triggers)."""
        adapter = IndianRoadPlanningAdapter()

        replan = StubReplanningRequest(frame_id=10, urgency="CRITICAL")
        result = adapter.build_constraints(make_input(10), make_village_unmarked_space(), replan)

        assert isinstance(result, IndianRoadPlanningResult)
        assert result.constraints.frame_id == 10

    def test_frame_id_matches_planning_input(self):
        adapter = IndianRoadPlanningAdapter()
        result = adapter.build_constraints(make_input(42), make_highway_space())
        assert result.constraints.frame_id == 42

    def test_replanning_engine_importable(self):
        """ReplanningEngine (Phase 9.4) is still importable."""
        engine = ReplanningEngine()
        assert engine is not None

    def test_95_does_not_bypass_94(self):
        """
        9.5 does NOT make replanning decisions.
        It produces planning constraints, not a ReplanningDecision.
        """
        result = build(make_busy_market_space())
        for forbidden in ("replan", "replanning_decision", "replanning_urgency",
                          "should_replan", "replan_required"):
            assert not hasattr(result, forbidden), f"Forbidden field in result: {forbidden}"
        assert not hasattr(result.constraints, "replanning_decision")


# ---------------------------------------------------------------------------
# Scope — Forbidden output tests (spec §49)
# ---------------------------------------------------------------------------

class TestPhase95Scope:
    """
    Explicit negative tests: Phase 9.5 must NOT output any of these.
    """

    FORBIDDEN_CONSTRAINT_FIELDS = [
        "steering",
        "throttle",
        "brake",
        "vehicle_control",
        "target_speed",
        "controller_command",
        "CARLA_command",
        "selected_path",
        "best_path",
        "optimal_path",
        "mpc",
        "MPC",
    ]

    FORBIDDEN_RESULT_FIELDS = [
        "vehicle_control",
        "controller_command",
        "steering",
        "throttle",
        "brake",
        "target_speed",
    ]

    @pytest.mark.parametrize("field_name", FORBIDDEN_CONSTRAINT_FIELDS)
    def test_constraint_has_no_forbidden_field(self, field_name):
        result = build(make_busy_market_space())
        assert not hasattr(result.constraints, field_name), (
            f"IndianRoadPlanningConstraints must not have field: {field_name}"
        )

    @pytest.mark.parametrize("field_name", FORBIDDEN_RESULT_FIELDS)
    def test_result_has_no_forbidden_field(self, field_name):
        result = build(make_highway_space())
        assert not hasattr(result, field_name), (
            f"IndianRoadPlanningResult must not have field: {field_name}"
        )

    def test_output_contains_planning_mode(self):
        """9.5 IS allowed to output planning constraints."""
        result = build(make_highway_space())
        assert hasattr(result.constraints, "planning_mode")

    def test_output_contains_lateral_offset(self):
        result = build(make_narrow_village_space())
        assert hasattr(result.constraints, "max_lateral_offset_m")

    def test_output_contains_clearance_margins(self):
        result = build(make_cattle_crossing_space())
        assert hasattr(result.constraints, "cattle_clearance_margin_m")
        assert hasattr(result.constraints, "obstacle_clearance_margin_m")

    def test_output_contains_traffic_context(self):
        result = build(make_busy_market_space())
        assert hasattr(result.constraints, "traffic_context")

    def test_output_contains_anomaly_constraints(self):
        result = build(make_road_damage_space())
        assert hasattr(result.constraints, "road_anomaly_constraints")


# ---------------------------------------------------------------------------
# Config round-trip + YAML loading
# ---------------------------------------------------------------------------

class TestConfig:
    def test_default_config_valid(self):
        cfg = IndianRoadPlanningConfig()
        assert cfg.lane_confidence_threshold > 0
        assert cfg.narrow_road_width_m > 0
        assert cfg.cattle_clearance_margin_m > 0

    def test_config_to_dict(self):
        cfg = IndianRoadPlanningConfig()
        d = cfg.to_dict()
        assert "lane_confidence_threshold" in d
        assert "cattle_clearance_margin_m" in d

    def test_config_from_dict_round_trip(self):
        cfg = IndianRoadPlanningConfig(cattle_clearance_margin_m=2.0)
        d = cfg.to_dict()
        d.pop("config_version", None)
        cfg2 = IndianRoadPlanningConfig.from_dict(d)
        assert cfg2.cattle_clearance_margin_m == 2.0

    def test_load_config_from_yaml(self):
        """load_indian_road_planning_config should return a valid config."""
        cfg = load_indian_road_planning_config()
        assert isinstance(cfg, IndianRoadPlanningConfig)
        assert cfg.enabled is True

    def test_load_missing_yaml_returns_defaults(self):
        from pathlib import Path
        cfg = load_indian_road_planning_config(Path("/nonexistent/path.yaml"))
        assert isinstance(cfg, IndianRoadPlanningConfig)
        assert cfg.lane_confidence_threshold > 0


# ---------------------------------------------------------------------------
# Validation tests
# ---------------------------------------------------------------------------

class TestValidation:
    def test_schema_version_correct(self):
        result = build(make_highway_space())
        assert result.constraints.schema_version == INDIAN_ROAD_PLANNING_SCHEMA_VERSION
        assert result.schema_version == INDIAN_ROAD_PLANNING_SCHEMA_VERSION

    def test_confidence_in_valid_range(self):
        result = build(make_highway_space())
        assert 0.0 <= result.constraints.confidence <= 1.0

    def test_uncertainty_non_negative(self):
        result = build(make_village_unmarked_space())
        assert result.constraints.uncertainty >= 0.0

    def test_lateral_offset_finite(self):
        result = build(make_narrow_village_space())
        assert math.isfinite(result.constraints.max_lateral_offset_m)

    def test_clearance_margins_finite(self):
        result = build(make_cattle_crossing_space())
        for field in ("road_edge_margin_m", "obstacle_clearance_margin_m",
                      "vulnerable_user_margin_m", "cattle_clearance_margin_m"):
            val = getattr(result.constraints, field)
            assert math.isfinite(val), f"{field} is not finite: {val}"

    def test_planning_mode_is_valid_enum(self):
        result = build(make_busy_market_space())
        assert isinstance(result.constraints.planning_mode, PlanningMode)

    def test_lane_usage_mode_is_valid_enum(self):
        result = build(make_highway_space())
        assert isinstance(result.constraints.lane_usage_mode, LaneUsageMode)

    def test_narrow_road_state_is_valid_enum(self):
        result = build(make_narrow_village_space())
        assert isinstance(result.constraints.narrow_road_state, NarrowRoadState)

    def test_to_dict_complete(self):
        result = build(make_busy_market_space())
        d = result.constraints.to_dict()
        for key in ("planning_mode", "lane_usage_mode", "max_lateral_offset_m",
                    "drivable_region_required", "confidence", "uncertainty",
                    "schema_version", "frame_id", "road_type"):
            assert key in d, f"Missing key in to_dict: {key}"

    def test_result_to_dict(self):
        result = build(make_highway_space())
        d = result.to_dict()
        assert "constraints" in d
        assert "status" in d
        assert "warnings" in d

    def test_anomaly_constraint_to_dict(self):
        result = build(make_road_damage_space())
        for ac in result.constraints.road_anomaly_constraints:
            d = ac.to_dict()
            assert "anomaly_type" in d
            assert "avoidance_margin_m" in d

    def test_traffic_context_to_dict(self):
        result = build(make_busy_market_space())
        d = result.constraints.traffic_context.to_dict()
        assert "has_cattle" in d
        assert "market_like" in d


# ---------------------------------------------------------------------------
# Snapshot semantics — frame identity
# ---------------------------------------------------------------------------

class TestSnapshotSemantics:
    def test_frame_id_in_constraints(self):
        """Constraints carry the correct frame_id from planning input."""
        result = build(make_highway_space(), inp=make_input(frame_id=99))
        assert result.constraints.frame_id == 99

    def test_timestamp_is_recent(self):
        import time
        result = build(make_highway_space())
        assert result.constraints.timestamp > 0
        assert result.constraints.timestamp <= time.time() + 1.0

    def test_degraded_constraints_still_have_frame_id(self):
        adapter = IndianRoadPlanningAdapter()
        result = adapter.build_constraints(make_input(77), None)
        assert result.constraints.frame_id == 77
