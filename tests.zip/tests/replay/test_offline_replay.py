"""REPLAY TEST — record then read back via OfflineSensorReplay, and stream
through OfflineCameraReplay using the same SensorInterface as a live sensor."""
import sys
import tempfile
import time
from pathlib import Path

import numpy as np
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))

from core.carla_integration.sensor_recorder import SensorRecorder
from core.carla_integration.sensor_replay import OfflineSensorReplay
from core.carla_integration.sensor_interface import OfflineCameraReplay
from core.carla_integration.sensor_types import CameraFrame, Timestamp


def _cam_frame(fid):
    img = np.full((4, 4, 3), fill_value=fid % 255, dtype=np.uint8)
    return CameraFrame(sensor_id="cam", frame_id=fid, timestamp=Timestamp(sensor_time=float(fid)),
                        sequence_number=fid, payload=None, width=4, height=4, channels=3, image=img)


def test_record_then_replay_roundtrip():
    with tempfile.TemporaryDirectory() as tmp:
        rec = SensorRecorder(base_dir=Path(tmp), map_name="Town01")
        rec.start()
        for i in range(5):
            rec.write_frame(_cam_frame(i))
        rec.stop()

        replay = OfflineSensorReplay(rec.session_dir)
        assert replay.available_sensors() == {"cam": "camera"}
        frames = replay.load_frames("cam")
        assert len(frames) == 5
        assert [f.frame_id for f in frames] == [0, 1, 2, 3, 4]
        assert frames[0].image.shape == (4, 4, 3)
        assert frames[0].sensor_id == "cam"


def test_offline_replay_uses_same_sensor_interface_as_live():
    with tempfile.TemporaryDirectory() as tmp:
        rec = SensorRecorder(base_dir=Path(tmp))
        rec.start()
        for i in range(3):
            rec.write_frame(_cam_frame(i))
        rec.stop()

        replay = OfflineSensorReplay(rec.session_dir)
        frames = replay.load_frames("cam")

        received = []
        source = OfflineCameraReplay("cam", frames, playback_rate=1000.0)  # fast for the test
        source.start(lambda f: received.append(f))
        time.sleep(0.3)
        source.stop()

        assert len(received) == 3
        assert [f.frame_id for f in received] == [0, 1, 2]


def test_missing_manifest_raises_clear_error():
    with tempfile.TemporaryDirectory() as tmp:
        with pytest.raises(FileNotFoundError):
            OfflineSensorReplay(Path(tmp) / "nonexistent_session")
