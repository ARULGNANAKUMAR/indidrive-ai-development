"""
Phase 10.2 — Tests: Cross-Track Error (CTE)
Sign convention: +CTE → ego is LEFT of path, -CTE → ego is RIGHT of path
"""
import math

from core.tracking.trajectory_matcher import TrajectoryMatcher
from core.tracking.reference_trajectory import ReferenceTrajectory
from core.tracking.tracking_types import MatchingMethod
from core.vehicle.vehicle_state import VehicleState


def _ego(x=0.0, y=0.0, yaw=0.0, v=10.0):
    return VehicleState(x=x, y=y, yaw=yaw, velocity=v)


def _straight_traj(length=20.0, n=10):
    """Straight trajectory along +X."""
    step = length / (n - 1)
    return ReferenceTrajectory.from_xy_list([(i * step, 0.0) for i in range(n)])


class TestCrossTrackError:
    def setup_method(self):
        self.m = TrajectoryMatcher(MatchingMethod.NEAREST_SEGMENT)

    def test_on_path_cte_zero(self):
        """Ego exactly on path → CTE ≈ 0."""
        traj = _straight_traj()
        ego  = _ego(x=5.0, y=0.0, yaw=0.0)
        _, _, err = self.m.match(ego, traj)
        assert abs(err.cross_track_error_m) < 1e-9

    def test_ego_left_positive_cte(self):
        """Ego displaced to +Y (left) → positive CTE."""
        traj = _straight_traj()
        ego  = _ego(x=5.0, y=1.0, yaw=0.0)
        _, _, err = self.m.match(ego, traj)
        assert err.cross_track_error_m > 0

    def test_ego_right_negative_cte(self):
        """Ego displaced to -Y (right) → negative CTE."""
        traj = _straight_traj()
        ego  = _ego(x=5.0, y=-1.0, yaw=0.0)
        _, _, err = self.m.match(ego, traj)
        assert err.cross_track_error_m < 0

    def test_cte_magnitude(self):
        """CTE magnitude equals lateral displacement for a straight path."""
        traj = _straight_traj()
        lat  = 0.75
        ego  = _ego(x=5.0, y=lat, yaw=0.0)
        _, _, err = self.m.match(ego, traj)
        assert abs(abs(err.cross_track_error_m) - lat) < 1e-6

    def test_both_sides_symmetry(self):
        """Mirrored lateral offsets → equal magnitude, opposite sign."""
        traj = _straight_traj()
        _, _, err_l = self.m.match(_ego(x=5.0, y=0.5), traj)
        _, _, err_r = self.m.match(_ego(x=5.0, y=-0.5), traj)
        assert abs(err_l.cross_track_error_m + err_r.cross_track_error_m) < 1e-9
        assert abs(abs(err_l.cross_track_error_m) - abs(err_r.cross_track_error_m)) < 1e-9

    def test_cte_on_angled_path(self):
        """CTE on a 45° path."""
        # Path along y=x (heading = π/4)
        pts = [(i * 1.0, i * 1.0) for i in range(5)]
        traj = ReferenceTrajectory.from_xy_list(pts)
        # Ego at (2, 2) = on path → CTE ≈ 0
        ego = _ego(x=2.0, y=2.0, yaw=math.pi/4)
        _, _, err = self.m.match(ego, traj)
        assert abs(err.cross_track_error_m) < 1e-6
