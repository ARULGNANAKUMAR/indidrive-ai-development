"""Phase 10.2 — Tests: Reference interpolation between trajectory points."""
import math

from core.tracking.trajectory_matcher import TrajectoryMatcher
from core.tracking.reference_trajectory import ReferenceTrajectory, ReferencePoint
from core.tracking.tracking_types import MatchingMethod
from core.vehicle.vehicle_state import VehicleState
from core.vehicle.vehicle_types import CoordinateFrame


def _ego(x=0.0, y=0.0, yaw=0.0, v=10.0):
    return VehicleState(x=x, y=y, yaw=yaw, velocity=v)


class TestInterpolation:
    def setup_method(self):
        self.m = TrajectoryMatcher(MatchingMethod.NEAREST_SEGMENT)

    def test_velocity_interpolated_midpoint(self):
        """Velocity at midpoint of segment interpolated correctly."""
        pts = [
            ReferencePoint(x=0.0, y=0.0, yaw=0.0, velocity=10.0),
            ReferencePoint(x=2.0, y=0.0, yaw=0.0, velocity=20.0),
        ]
        traj = ReferenceTrajectory(points=pts, coordinate_frame=CoordinateFrame.VEHICLE)
        ego  = _ego(x=1.0, y=0.0)
        _, ref, _ = self.m.match(ego, traj)
        # Midpoint → t=0.5 → velocity ≈ 15 m/s
        assert ref.reference_velocity is not None
        assert abs(ref.reference_velocity - 15.0) < 0.1

    def test_yaw_interpolated_midpoint(self):
        """Yaw at midpoint interpolated with angle-awareness."""
        pts = [
            ReferencePoint(x=0.0, y=0.0, yaw=0.0),
            ReferencePoint(x=2.0, y=0.0, yaw=0.4),
        ]
        traj = ReferenceTrajectory(points=pts, coordinate_frame=CoordinateFrame.VEHICLE)
        ego  = _ego(x=1.0, y=0.0)
        _, ref, _ = self.m.match(ego, traj)
        assert ref.reference_yaw is not None
        assert 0.0 < ref.reference_yaw < 0.4

    def test_yaw_wrap_interpolation(self):
        """Yaw interpolation handles wrap around ±π correctly."""
        pts = [
            ReferencePoint(x=0.0, y=0.0, yaw=math.pi * 0.9),
            ReferencePoint(x=2.0, y=0.0, yaw=-math.pi * 0.9),
        ]
        traj = ReferenceTrajectory(points=pts, coordinate_frame=CoordinateFrame.VEHICLE)
        ego  = _ego(x=1.0, y=0.0)
        _, ref, _ = self.m.match(ego, traj)
        assert ref.reference_yaw is not None
        assert -math.pi <= ref.reference_yaw < math.pi

    def test_no_interpolation_at_first_point(self):
        """At t=0 (start of segment), no interpolation bias."""
        pts = [
            ReferencePoint(x=0.0, y=0.0, yaw=0.0, velocity=10.0),
            ReferencePoint(x=4.0, y=0.0, yaw=0.0, velocity=20.0),
        ]
        traj = ReferenceTrajectory(points=pts, coordinate_frame=CoordinateFrame.VEHICLE)
        ego  = _ego(x=0.0, y=0.0)
        _, ref, _ = self.m.match(ego, traj)
        assert ref.reference_velocity is not None
        assert abs(ref.reference_velocity - 10.0) < 0.5  # near start

    def test_position_interpolated(self):
        """Projected position on segment is between the two endpoints."""
        pts = [
            ReferencePoint(x=0.0, y=0.0, yaw=0.0),
            ReferencePoint(x=4.0, y=0.0, yaw=0.0),
        ]
        traj = ReferenceTrajectory(points=pts, coordinate_frame=CoordinateFrame.VEHICLE)
        ego  = _ego(x=2.0, y=1.0)  # above midpoint
        _, ref, _ = self.m.match(ego, traj)
        assert 0.0 <= ref.reference_x <= 4.0
        assert abs(ref.reference_y) < 1e-9
