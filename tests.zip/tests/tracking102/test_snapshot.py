"""Phase 10.2 — Tests: TrackingSnapshot immutability and content."""
import math

from core.tracking.tracking_engine import TrackingEngine
from core.tracking.tracking_config import TrackingConfig
from core.tracking.tracking_types import TrackingQuality, TRACKING_SCHEMA_VERSION
from core.tracking.reference_trajectory import ReferenceTrajectory, ReferencePoint
from core.vehicle.vehicle_state import VehicleState
from core.vehicle.vehicle_types import CoordinateFrame


def _cfg():
    return TrackingConfig(max_reference_age_s=60.0)


def _ego(x=5.0, y=0.0, yaw=0.0, v=10.0, ts=1.0, fid=10):
    return VehicleState(x=x, y=y, yaw=yaw, velocity=v, timestamp=ts, frame_id=fid)


def _traj():
    pts = [ReferencePoint(x=i*2.0, y=0.0, yaw=0.0) for i in range(10)]
    return ReferenceTrajectory(points=pts, coordinate_frame=CoordinateFrame.VEHICLE,
                               source_id="test-path-001")


class TestSnapshot:
    def setup_method(self):
        self.engine = TrackingEngine(_cfg())

    def test_schema_version(self):
        snap = self.engine.update(_ego(), _traj())
        assert snap.schema_version == TRACKING_SCHEMA_VERSION

    def test_frame_id_preserved(self):
        ego  = _ego(fid=42)
        snap = self.engine.update(ego, _traj())
        assert snap.frame_id == 42

    def test_timestamp_preserved(self):
        ego  = _ego(ts=7.5)
        snap = self.engine.update(ego, _traj())
        assert abs(snap.sim_timestamp - 7.5) < 1e-9

    def test_source_id_preserved(self):
        snap = self.engine.update(_ego(), _traj())
        assert snap.source_id == "test-path-001"

    def test_is_immutable(self):
        """frozen=True — any attribute write must raise."""
        snap = self.engine.update(_ego(), _traj())
        try:
            snap.cross_track_error_m = 99.0
            assert False, "Should have raised"
        except (AttributeError, TypeError):
            pass

    def test_source_mutation_does_not_affect_snapshot(self):
        """Mutating the ego state after snap creation must not change snap."""
        ego  = _ego(x=5.0)
        snap = self.engine.update(ego, _traj())
        cte_before = snap.cross_track_error_m
        ego.x = 9999.0  # mutate source
        assert snap.cross_track_error_m == cte_before

    def test_nan_unavailable_fields(self):
        """Fields without reference data must be NaN (not 0 or fabricated)."""
        traj = ReferenceTrajectory(
            points=[ReferencePoint(x=5.0, y=0.0, yaw=0.0)],  # no velocity/curvature
            coordinate_frame=CoordinateFrame.VEHICLE,
        )
        snap = self.engine.update(_ego(), traj)
        assert math.isnan(snap.speed_error_mps)
        assert math.isnan(snap.curvature_error_1pm)
        assert math.isnan(snap.yaw_rate_error_radps)

    def test_snap_timestamp_wall_clock(self):
        """snap_timestamp should be a recent wall-clock time (> 0)."""
        snap = self.engine.update(_ego(), _traj())
        assert snap.snap_timestamp > 0

    def test_reason_codes_on_on_track(self):
        """ON_TRACK → empty reason codes."""
        snap = self.engine.update(_ego(y=0.0), _traj())
        if snap.tracking_quality == TrackingQuality.ON_TRACK:
            assert len(snap.reason_codes) == 0

    def test_reason_codes_on_deviation(self):
        """Large deviation → at least one reason code."""
        snap = self.engine.update(_ego(y=4.0), _traj())
        assert len(snap.reason_codes) > 0
