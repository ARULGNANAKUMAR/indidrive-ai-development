"""Phase 10.2 — Tests: Trajectory Matching (nearest-point and nearest-segment)"""
import math

from core.tracking.trajectory_matcher import TrajectoryMatcher, _project_point_onto_segment
from core.tracking.reference_trajectory import ReferenceTrajectory, ReferencePoint
from core.tracking.tracking_types import MatchingMethod
from core.vehicle.vehicle_state import VehicleState
from core.vehicle.vehicle_types import CoordinateFrame


def _ego(x=0.0, y=0.0, yaw=0.0, v=10.0):
    return VehicleState(x=x, y=y, yaw=yaw, velocity=v)


def _pts(xy_list):
    return ReferenceTrajectory(
        points=[ReferencePoint(x=x, y=y, yaw=0.0) for x, y in xy_list],
        coordinate_frame=CoordinateFrame.VEHICLE,
    )


class TestSegmentProjection:
    """Unit tests for the internal projection helper."""

    def test_midpoint(self):
        qx, qy, t = _project_point_onto_segment(0.5, 0.0, 0.0, 0.0, 1.0, 0.0)
        assert abs(qx - 0.5) < 1e-9
        assert abs(qy) < 1e-9
        assert abs(t - 0.5) < 1e-9

    def test_before_segment(self):
        qx, qy, t = _project_point_onto_segment(-1.0, 0.0, 0.0, 0.0, 1.0, 0.0)
        assert abs(qx) < 1e-9
        assert t == 0.0

    def test_after_segment(self):
        qx, qy, t = _project_point_onto_segment(2.0, 0.0, 0.0, 0.0, 1.0, 0.0)
        assert abs(qx - 1.0) < 1e-9
        assert t == 1.0

    def test_degenerate_segment(self):
        qx, qy, t = _project_point_onto_segment(5.0, 5.0, 2.0, 2.0, 2.0, 2.0)
        assert abs(qx - 2.0) < 1e-9
        assert abs(qy - 2.0) < 1e-9
        assert t == 0.0


class TestNearestSegmentMatcher:
    def setup_method(self):
        self.m = TrajectoryMatcher(MatchingMethod.NEAREST_SEGMENT)

    def test_single_point(self):
        traj = _pts([(3.0, 0.0)])
        ego  = _ego(x=0.0, y=0.0)
        match, ref, _ = self.m.match(ego, traj)
        assert match.nearest_index == 0

    def test_first_segment_match(self):
        traj = _pts([(0.0, 0.0), (5.0, 0.0), (10.0, 0.0)])
        ego  = _ego(x=2.0, y=0.5)
        match, _, _ = self.m.match(ego, traj)
        assert match.segment_index == 0

    def test_second_segment_match(self):
        traj = _pts([(0.0, 0.0), (5.0, 0.0), (10.0, 0.0)])
        ego  = _ego(x=7.0, y=0.5)
        match, _, _ = self.m.match(ego, traj)
        assert match.segment_index == 1

    def test_distance_non_negative(self):
        traj = ReferenceTrajectory.from_xy_list(
            [(i * 2.0, 0.0) for i in range(10)]
        )
        ego  = _ego(x=5.0, y=1.5)
        match, _, err = self.m.match(ego, traj)
        assert match.distance_m >= 0.0
        assert err.nearest_distance_m >= 0.0


class TestNearestPointMatcher:
    def setup_method(self):
        self.m = TrajectoryMatcher(MatchingMethod.NEAREST_POINT)

    def test_selects_nearest(self):
        traj = _pts([(0.0, 0.0), (1.0, 0.0), (2.0, 0.0), (3.0, 0.0)])
        ego  = _ego(x=1.9, y=0.0)
        match, _, _ = self.m.match(ego, traj)
        assert match.nearest_index == 2  # closest to (2,0)

    def test_empty_raises(self):
        traj = ReferenceTrajectory(points=[], coordinate_frame=CoordinateFrame.VEHICLE)
        ego  = _ego()
        try:
            self.m.match(ego, traj)
            assert False, "Should raise"
        except ValueError:
            pass

    def test_on_path_distance_near_zero(self):
        traj = _pts([(0.0, 0.0), (5.0, 0.0)])
        ego  = _ego(x=5.0, y=0.0)
        match, _, err = self.m.match(ego, traj)
        assert err.nearest_distance_m < 1e-9


class TestCurvedPathMatching:
    """Section 51 — curved path test."""

    def test_left_curve_matching(self):
        # Circular arc turning left
        pts = [(math.cos(a) * 5.0, math.sin(a) * 5.0)
               for a in [math.radians(d) for d in range(0, 91, 10)]]
        traj = ReferenceTrajectory.from_xy_list(pts)
        ego  = _ego(x=5.0, y=0.0, yaw=0.0)
        m    = TrajectoryMatcher(MatchingMethod.NEAREST_SEGMENT)
        match, ref, err = m.match(ego, traj)
        assert math.isfinite(err.cross_track_error_m)
        assert math.isfinite(err.heading_error_rad)
        assert -math.pi <= err.heading_error_rad < math.pi

    def test_right_curve_matching(self):
        # Curve turning right (y < 0)
        pts = [(i * 1.0, -(i * 0.1)) for i in range(10)]
        traj = ReferenceTrajectory.from_xy_list(pts)
        ego  = _ego(x=5.0, y=0.5)
        m    = TrajectoryMatcher(MatchingMethod.NEAREST_SEGMENT)
        _, _, err = m.match(ego, traj)
        assert math.isfinite(err.cross_track_error_m)
