"""Phase 10.2 — Tests: Determinism — same inputs → same outputs."""
import math

from core.tracking.tracking_engine import TrackingEngine
from core.tracking.tracking_config import TrackingConfig
from core.tracking.reference_trajectory import ReferenceTrajectory, ReferencePoint
from core.vehicle.vehicle_state import VehicleState
from core.vehicle.vehicle_types import CoordinateFrame


def _cfg():
    return TrackingConfig(max_reference_age_s=60.0)


def _ego():
    return VehicleState(x=5.0, y=0.3, yaw=0.1, velocity=10.0, timestamp=0.0)


def _traj():
    pts = [ReferencePoint(x=i*2.0, y=0.0, yaw=0.0, velocity=10.0)
           for i in range(10)]
    return ReferenceTrajectory(points=pts, coordinate_frame=CoordinateFrame.VEHICLE)


class TestDeterminism:
    def test_identical_snap_values(self):
        engine = TrackingEngine(_cfg())
        ego    = _ego()
        traj   = _traj()
        s1 = engine.update(ego, traj)
        s2 = engine.update(ego, traj)
        assert s1.tracking_quality   == s2.tracking_quality
        assert s1.cross_track_error_m == s2.cross_track_error_m
        assert s1.along_track_error_m == s2.along_track_error_m
        assert s1.heading_error_rad   == s2.heading_error_rad
        assert s1.matched_index       == s2.matched_index
        assert s1.ref_x               == s2.ref_x
        assert s1.ref_y               == s2.ref_y
        assert s1.confidence          == s2.confidence

    def test_two_engine_instances(self):
        e1 = TrackingEngine(TrackingConfig(max_reference_age_s=60.0))
        e2 = TrackingEngine(TrackingConfig(max_reference_age_s=60.0))
        ego  = _ego()
        traj = _traj()
        s1 = e1.update(ego, traj)
        s2 = e2.update(ego, traj)
        assert s1.cross_track_error_m == s2.cross_track_error_m
        assert s1.tracking_quality    == s2.tracking_quality

    def test_matcher_deterministic(self):
        from core.tracking.trajectory_matcher import TrajectoryMatcher
        from core.tracking.tracking_types import MatchingMethod
        m   = TrajectoryMatcher(MatchingMethod.NEAREST_SEGMENT)
        ego = _ego()
        traj= _traj()
        r1, ref1, err1 = m.match(ego, traj)
        r2, ref2, err2 = m.match(ego, traj)
        assert r1.nearest_index       == r2.nearest_index
        assert r1.distance_m          == r2.distance_m
        assert err1.cross_track_error_m == err2.cross_track_error_m
        assert err1.heading_error_rad   == err2.heading_error_rad
