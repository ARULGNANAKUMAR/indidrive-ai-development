"""
Phase 10.2 — Negative Scope Tests

Confirm Phase 10.2 does NOT implement:
    MPC, PID, Pure Pursuit, Stanley, LQR, steering controller,
    speed controller, throttle controller, brake controller,
    actuator command, CARLA apply_control, path generation,
    path selection, replanning.

A "steering_angle" may exist in a reference trajectory.
That does NOT mean Phase 10.2 generates steering control.
"""
import core.tracking as ct


class TestNoController:
    def test_no_mpc_in_package(self):
        names = dir(ct)
        mpc = [n for n in names if "mpc" in n.lower() or "model_predictive" in n.lower()]
        assert mpc == [], f"Unexpected MPC exports: {mpc}"

    def test_no_pid_in_package(self):
        names = dir(ct)
        pid = [n for n in names if "pid" in n.lower()]
        assert pid == [], f"Unexpected PID exports: {pid}"

    def test_tracking_engine_has_no_steer_method(self):
        eng = ct.TrackingEngine()
        for attr in ["apply_steering", "steer", "pid_step", "mpc_solve",
                     "pure_pursuit", "stanley", "lqr_step"]:
            assert not hasattr(eng, attr), f"Unexpected method: {attr}"

    def test_snapshot_has_no_actuator_commands(self):
        from core.tracking.tracking_types import TrackingQuality
        from core.tracking.tracking_error import ReferenceState, TrackingError
        from core.tracking.tracking_snapshot import TrackingSnapshot
        snap = TrackingSnapshot.from_result(
            ref_state=ReferenceState(),
            error=TrackingError(),
            quality=TrackingQuality.UNKNOWN,
            sim_timestamp=0.0,
            frame_id=0,
            source_id="test",
            degraded=True,
            confidence=0.0,
            reason_codes=(),
        )
        for attr in ["throttle", "brake", "steering_command",
                     "actuator", "carla_control", "apply_control"]:
            assert not hasattr(snap, attr), f"Snapshot must not have field: {attr}"

    def test_no_path_generation(self):
        for attr in ["generate_path", "generate_trajectory", "plan_path",
                     "create_candidate"]:
            assert not hasattr(ct.TrackingEngine(), attr), \
                f"TrackingEngine must not have method: {attr}"

    def test_no_replanning(self):
        eng = ct.TrackingEngine()
        for attr in ["replan", "trigger_replan", "select_candidate"]:
            assert not hasattr(eng, attr), \
                f"TrackingEngine must not have method: {attr}"


class TestReferenceSteeringIsNotControl:
    """
    A reference trajectory may carry steering_angle data.
    That is a reference field, NOT a Phase 10.2 control output.
    Phase 10.2 reads it for error computation only.
    """

    def test_tracking_error_has_no_steering_command(self):
        from core.tracking.tracking_error import TrackingError
        err = TrackingError()
        for attr in ["steering_command", "throttle_command", "brake_command"]:
            assert not hasattr(err, attr), \
                f"TrackingError must not have field: {attr}"

    def test_engine_update_returns_snapshot_not_command(self):
        from core.tracking.tracking_snapshot import TrackingSnapshot
        from core.tracking.reference_trajectory import ReferenceTrajectory, ReferencePoint
        from core.vehicle.vehicle_state import VehicleState
        from core.vehicle.vehicle_types import CoordinateFrame

        eng  = ct.TrackingEngine(ct.TrackingConfig(max_reference_age_s=60.0))
        traj = ReferenceTrajectory(
            points=[ReferencePoint(x=i*2.0, y=0.0, yaw=0.0) for i in range(5)],
            coordinate_frame=CoordinateFrame.VEHICLE,
        )
        ego  = VehicleState(x=5.0, y=0.0, velocity=10.0)
        snap = eng.update(ego, traj)
        assert isinstance(snap, TrackingSnapshot)
        # The snapshot contains tracking errors, NOT actuator values
        assert hasattr(snap, "cross_track_error_m")
        assert not hasattr(snap, "steering_command")
        assert not hasattr(snap, "throttle")
        assert not hasattr(snap, "brake")


class TestNoCarlaControl:
    def test_no_carla_import(self):
        """Phase 10.2 must not depend on CARLA at import time."""
        import core.tracking  # must not raise CarlaImportError
