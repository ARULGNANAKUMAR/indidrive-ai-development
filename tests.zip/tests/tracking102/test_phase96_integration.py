"""
Phase 10.2 — Integration Test with Phase 9.6 and Phase 10.1

Flow:
    Phase 9.6 planner output (CandidatePath / PathPoint)
        → ReferenceTrajectory adapter
        → Phase 10.1 VehicleState (ego)
        → TrackingEngine.update()
        → TrackingSnapshot

This test does NOT:
    * invoke MPC
    * send any CARLA command
    * implement a controller
"""
import math

from core.planning.candidate_path_types import PathPoint
from core.tracking.reference_trajectory import ReferenceTrajectory
from core.tracking.tracking_engine import TrackingEngine
from core.tracking.tracking_config import TrackingConfig
from core.tracking.tracking_types import TrackingQuality, TRACKING_SCHEMA_VERSION
from core.tracking.tracking_snapshot import TrackingSnapshot
from core.vehicle.vehicle_state import VehicleState
from core.vehicle.vehicle_types import CoordinateFrame, StateKind


def _make_planner_path_points(n=10, step=2.0):
    """Simulate PathPoint output from Phase 9.6 planner."""
    return [
        PathPoint(
            x=i * step,
            y=0.0,
            heading=0.0,
            curvature=0.0,
            longitudinal_s=i * step,
        )
        for i in range(n)
    ]


def _make_ego_from_localisation(x=5.0, y=0.2, yaw=0.05, v=8.33):
    """Simulate ego state from Phase 10.1 / localisation."""
    return VehicleState(
        x=x, y=y, yaw=yaw, velocity=v,
        timestamp=0.0, frame_id=1,
        coordinate_frame=CoordinateFrame.VEHICLE,
        state_kind=StateKind.ESTIMATED,
    )


class TestPhase96Integration:
    def setup_method(self):
        self.engine = TrackingEngine(TrackingConfig(max_reference_age_s=60.0))

    def test_full_pipeline(self):
        """Full Phase 9.6 → 10.1 → 10.2 pipeline."""
        path_points = _make_planner_path_points()
        traj = ReferenceTrajectory.from_path_points(
            path_points,
            frame_id=1,
            timestamp=0.0,
            source_id="candidate_001",
            reference_velocity=10.0,
        )
        ego  = _make_ego_from_localisation()

        snap = self.engine.update(ego_state=ego, reference=traj)

        assert isinstance(snap, TrackingSnapshot)
        assert snap.schema_version == TRACKING_SCHEMA_VERSION
        assert snap.tracking_quality not in (
            TrackingQuality.INVALID_INPUT,
            TrackingQuality.REFERENCE_LOST,
        )
        assert snap.source_id == "candidate_001"

    def test_tracking_errors_are_finite(self):
        path_points = _make_planner_path_points()
        traj = ReferenceTrajectory.from_path_points(
            path_points, reference_velocity=10.0, timestamp=0.0
        )
        ego  = _make_ego_from_localisation()
        snap = self.engine.update(ego, traj)

        assert math.isfinite(snap.cross_track_error_m)
        assert math.isfinite(snap.along_track_error_m)
        assert math.isfinite(snap.heading_error_rad)
        assert math.isfinite(snap.nearest_distance_m)

    def test_ego_on_path_small_errors(self):
        """Ego exactly on a straight path → small CTE and heading error."""
        path_points = _make_planner_path_points()
        traj = ReferenceTrajectory.from_path_points(
            path_points, reference_velocity=10.0, timestamp=0.0
        )
        ego  = _make_ego_from_localisation(x=5.0, y=0.0, yaw=0.0)
        snap = self.engine.update(ego, traj)

        assert abs(snap.cross_track_error_m) < 1e-6
        assert abs(snap.heading_error_rad) < 1e-6

    def test_no_planner_modules_required_at_runtime(self):
        """
        Phase 10.2 must not REQUIRE planner imports to function.
        The adapter converts PathPoint → ReferencePoint; after that,
        the tracker is fully independent of Phase 9.
        """
        from core.tracking.reference_trajectory import ReferencePoint
        from core.vehicle.vehicle_types import CoordinateFrame

        pts  = [ReferencePoint(x=i*2.0, y=0.0, yaw=0.0) for i in range(5)]
        traj = ReferenceTrajectory(
            points=pts, coordinate_frame=CoordinateFrame.VEHICLE, timestamp=0.0
        )
        ego  = VehicleState(x=5.0, y=0.0, velocity=10.0)
        snap = self.engine.update(ego, traj)
        assert isinstance(snap, TrackingSnapshot)

    def test_tracking_snapshot_has_no_actuator_fields(self):
        path_points = _make_planner_path_points()
        traj = ReferenceTrajectory.from_path_points(
            path_points, reference_velocity=10.0, timestamp=0.0
        )
        snap = self.engine.update(_make_ego_from_localisation(), traj)

        for forbidden in ["throttle", "brake", "steering_command",
                          "apply_control", "carla_control"]:
            assert not hasattr(snap, forbidden), \
                f"Snapshot must not have field: {forbidden}"

    def test_trajectory_coordinate_frame(self):
        """Converted trajectory must remain in VEHICLE frame."""
        path_points = _make_planner_path_points()
        traj = ReferenceTrajectory.from_path_points(path_points, timestamp=0.0)
        assert traj.coordinate_frame == CoordinateFrame.VEHICLE
