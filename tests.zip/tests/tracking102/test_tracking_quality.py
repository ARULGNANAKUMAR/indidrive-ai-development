"""Phase 10.2 — Tests: Tracking Quality Assessment"""
import math

from core.tracking.tracking_engine import TrackingEngine
from core.tracking.tracking_config import TrackingConfig
from core.tracking.tracking_types import TrackingQuality
from core.tracking.reference_trajectory import ReferenceTrajectory, ReferencePoint
from core.vehicle.vehicle_state import VehicleState
from core.vehicle.vehicle_types import CoordinateFrame


def _make_traj(n=10, step=2.0):
    pts = [ReferencePoint(x=i*step, y=0.0, yaw=0.0) for i in range(n)]
    return ReferenceTrajectory(points=pts, coordinate_frame=CoordinateFrame.VEHICLE)


def _ego(x=5.0, y=0.0, yaw=0.0, v=10.0, ts=0.0):
    return VehicleState(x=x, y=y, yaw=yaw, velocity=v, timestamp=ts)


def _cfg(**kwargs):
    d = dict(
        cte_minor_m=0.30, cte_major_m=1.0, cte_large_m=3.0,
        heading_minor_rad=0.30, heading_major_rad=0.785,
        speed_minor_mps=2.0, speed_major_mps=5.0,
        max_reference_age_s=60.0,
    )
    d.update(kwargs)
    return TrackingConfig(**d)


class TestTrackingQuality:
    def test_on_track(self):
        engine = TrackingEngine(_cfg())
        traj   = _make_traj()
        ego    = _ego(y=0.0)
        snap   = engine.update(ego, traj)
        assert snap.tracking_quality == TrackingQuality.ON_TRACK

    def test_minor_lateral_deviation(self):
        engine = TrackingEngine(_cfg())
        traj   = _make_traj()
        ego    = _ego(y=0.5)  # > 0.30 minor threshold
        snap   = engine.update(ego, traj)
        assert snap.tracking_quality in (
            TrackingQuality.MINOR_DEVIATION, TrackingQuality.DEVIATING
        )

    def test_major_lateral_deviation(self):
        engine = TrackingEngine(_cfg())
        traj   = _make_traj()
        ego    = _ego(y=1.5)  # > 1.0 major threshold
        snap   = engine.update(ego, traj)
        assert snap.tracking_quality in (
            TrackingQuality.DEVIATING, TrackingQuality.LARGE_DEVIATION
        )

    def test_large_deviation(self):
        engine = TrackingEngine(_cfg())
        traj   = _make_traj()
        ego    = _ego(y=4.0)  # > 3.0 large threshold
        snap   = engine.update(ego, traj)
        assert snap.tracking_quality == TrackingQuality.LARGE_DEVIATION

    def test_reference_lost_empty_traj(self):
        engine = TrackingEngine(_cfg())
        traj   = ReferenceTrajectory(points=[], coordinate_frame=CoordinateFrame.VEHICLE)
        ego    = _ego()
        snap   = engine.update(ego, traj)
        assert snap.tracking_quality == TrackingQuality.REFERENCE_LOST

    def test_stale_reference(self):
        engine = TrackingEngine(_cfg(max_reference_age_s=1.0))
        traj   = _make_traj()
        traj.timestamp = 0.0
        ego    = _ego(ts=5.0)  # 5 s > 1 s threshold
        snap   = engine.update(ego, traj)
        assert snap.tracking_quality == TrackingQuality.STALE_REFERENCE

    def test_invalid_ego_state(self):
        engine = TrackingEngine(_cfg())
        traj   = _make_traj()
        ego    = VehicleState(x=float("nan"))
        snap   = engine.update(ego, traj)
        assert snap.tracking_quality == TrackingQuality.INVALID_INPUT

    def test_disabled_engine_returns_unknown(self):
        engine = TrackingEngine(TrackingConfig(enabled=False,
                                               max_reference_age_s=60.0))
        traj   = _make_traj()
        ego    = _ego()
        snap   = engine.update(ego, traj)
        assert snap.tracking_quality == TrackingQuality.UNKNOWN

    def test_on_track_has_high_confidence(self):
        engine = TrackingEngine(_cfg())
        traj   = _make_traj()
        ego    = _ego(y=0.0)
        snap   = engine.update(ego, traj)
        assert snap.confidence >= 0.9

    def test_reference_lost_zero_confidence(self):
        engine = TrackingEngine(_cfg())
        traj   = ReferenceTrajectory(points=[], coordinate_frame=CoordinateFrame.VEHICLE)
        ego    = _ego()
        snap   = engine.update(ego, traj)
        assert snap.confidence == 0.0
