"""Phase 10.2 — Tests: Speed Error and Curvature Error"""
import math

from core.tracking.trajectory_matcher import TrajectoryMatcher
from core.tracking.reference_trajectory import ReferenceTrajectory, ReferencePoint
from core.tracking.tracking_types import MatchingMethod
from core.vehicle.vehicle_state import VehicleState


def _ego(x=5.0, y=0.0, yaw=0.0, v=10.0):
    return VehicleState(x=x, y=y, yaw=yaw, velocity=v)


def _traj_with_velocity(ref_v, n=6, step=2.0):
    pts = [ReferencePoint(x=i*step, y=0.0, yaw=0.0, velocity=ref_v) for i in range(n)]
    from core.vehicle.vehicle_types import CoordinateFrame
    return ReferenceTrajectory(points=pts, coordinate_frame=CoordinateFrame.VEHICLE)


def _traj_with_curvature(kappa, n=6, step=2.0):
    pts = [ReferencePoint(x=i*step, y=0.0, yaw=0.0, curvature=kappa) for i in range(n)]
    from core.vehicle.vehicle_types import CoordinateFrame
    return ReferenceTrajectory(points=pts, coordinate_frame=CoordinateFrame.VEHICLE)


def _traj_no_velocity(n=6, step=2.0):
    pts = [ReferencePoint(x=i*step, y=0.0, yaw=0.0) for i in range(n)]
    from core.vehicle.vehicle_types import CoordinateFrame
    return ReferenceTrajectory(points=pts, coordinate_frame=CoordinateFrame.VEHICLE)


class TestSpeedError:
    def setup_method(self):
        self.m = TrajectoryMatcher(MatchingMethod.NEAREST_SEGMENT)

    def test_speed_error_zero(self):
        """ego velocity == reference → speed error = 0."""
        traj = _traj_with_velocity(10.0)
        ego  = _ego(v=10.0)
        _, _, err = self.m.match(ego, traj)
        assert err.speed_error_mps is not None
        assert abs(err.speed_error_mps) < 1e-9

    def test_ego_faster_positive_error(self):
        traj = _traj_with_velocity(8.0)
        ego  = _ego(v=10.0)
        _, _, err = self.m.match(ego, traj)
        assert err.speed_error_mps is not None
        assert err.speed_error_mps > 0

    def test_ego_slower_negative_error(self):
        traj = _traj_with_velocity(12.0)
        ego  = _ego(v=10.0)
        _, _, err = self.m.match(ego, traj)
        assert err.speed_error_mps is not None
        assert err.speed_error_mps < 0

    def test_speed_error_magnitude(self):
        ref_v = 8.0
        ego_v = 10.0
        traj = _traj_with_velocity(ref_v)
        ego  = _ego(v=ego_v)
        _, _, err = self.m.match(ego, traj)
        assert abs(err.speed_error_mps - (ego_v - ref_v)) < 1e-9

    def test_no_speed_error_when_ref_unavailable(self):
        """If reference has no velocity, speed_error must be None."""
        traj = _traj_no_velocity()
        ego  = _ego(v=10.0)
        _, _, err = self.m.match(ego, traj)
        assert err.speed_error_mps is None


class TestCurvatureError:
    def setup_method(self):
        self.m = TrajectoryMatcher(MatchingMethod.NEAREST_SEGMENT)

    def test_curvature_error_unavailable_when_no_ref_kappa(self):
        """No reference curvature → curvature_error must be None."""
        traj = _traj_no_velocity()
        ego  = _ego()
        _, _, err = self.m.match(ego, traj)
        # traj_no_velocity has no curvature field set
        assert err.curvature_error_1pm is None

    def test_curvature_error_computed_when_ref_kappa_available(self):
        """Reference curvature available → curvature error is finite."""
        traj = _traj_with_curvature(kappa=0.1)
        ego  = _ego()
        _, _, err = self.m.match(ego, traj)
        assert err.curvature_error_1pm is not None
        assert math.isfinite(err.curvature_error_1pm)
