"""Phase 10.2 — Tests: Edge Cases, Invalid Inputs, Numerical Safety"""
import math

from core.tracking.tracking_engine import TrackingEngine
from core.tracking.tracking_config import TrackingConfig
from core.tracking.tracking_types import TrackingQuality
from core.tracking.reference_trajectory import ReferenceTrajectory, ReferencePoint
from core.tracking.trajectory_matcher import TrajectoryMatcher
from core.tracking.tracking_types import MatchingMethod
from core.vehicle.vehicle_state import VehicleState
from core.vehicle.vehicle_types import CoordinateFrame


def _cfg():
    return TrackingConfig(max_reference_age_s=60.0)


def _ego(**kw):
    defaults = dict(x=5.0, y=0.0, yaw=0.0, velocity=10.0, timestamp=0.0)
    defaults.update(kw)
    return VehicleState(**defaults)


def _pts(n=5, step=2.0):
    pts = [ReferencePoint(x=i*step, y=0.0, yaw=0.0) for i in range(n)]
    return ReferenceTrajectory(points=pts, coordinate_frame=CoordinateFrame.VEHICLE)


class TestEmptyTrajectory:
    def test_engine_returns_reference_lost(self):
        engine = TrackingEngine(_cfg())
        traj   = ReferenceTrajectory(points=[], coordinate_frame=CoordinateFrame.VEHICLE)
        snap   = engine.update(_ego(), traj)
        assert snap.tracking_quality == TrackingQuality.REFERENCE_LOST
        assert snap.confidence == 0.0

    def test_matcher_raises_on_empty(self):
        m    = TrajectoryMatcher(MatchingMethod.NEAREST_SEGMENT)
        traj = ReferenceTrajectory(points=[], coordinate_frame=CoordinateFrame.VEHICLE)
        ego  = _ego()
        try:
            m.match(ego, traj)
            assert False
        except ValueError:
            pass


class TestSinglePointTrajectory:
    def test_single_point_does_not_crash(self):
        engine = TrackingEngine(_cfg())
        traj   = ReferenceTrajectory(
            points=[ReferencePoint(x=5.0, y=0.0, yaw=0.0)],
            coordinate_frame=CoordinateFrame.VEHICLE,
        )
        snap = engine.update(_ego(), traj)
        assert snap.tracking_quality not in (
            TrackingQuality.INVALID_INPUT,
            TrackingQuality.REFERENCE_LOST,
        )

    def test_single_point_no_speed_error_without_ref_velocity(self):
        engine = TrackingEngine(_cfg())
        traj   = ReferenceTrajectory(
            points=[ReferencePoint(x=5.0, y=0.0, yaw=0.0)],
            coordinate_frame=CoordinateFrame.VEHICLE,
        )
        snap = engine.update(_ego(), traj)
        assert math.isnan(snap.speed_error_mps)


class TestNaNInfinityInputs:
    def test_nan_ego_x(self):
        engine = TrackingEngine(_cfg())
        ego    = VehicleState(x=float("nan"), velocity=10.0)
        snap   = engine.update(ego, _pts())
        assert snap.tracking_quality == TrackingQuality.INVALID_INPUT

    def test_nan_trajectory_x(self):
        engine = TrackingEngine(_cfg())
        traj   = ReferenceTrajectory(
            points=[ReferencePoint(x=float("nan"), y=0.0)],
            coordinate_frame=CoordinateFrame.VEHICLE,
        )
        snap = engine.update(_ego(), traj)
        assert snap.tracking_quality == TrackingQuality.INVALID_INPUT

    def test_inf_ego_velocity(self):
        engine = TrackingEngine(_cfg())
        ego    = VehicleState(x=5.0, velocity=float("inf"))
        snap   = engine.update(ego, _pts())
        assert snap.tracking_quality == TrackingQuality.INVALID_INPUT


class TestDuplicatePoints:
    def test_duplicate_points_no_crash(self):
        """Duplicate points (zero-length segment) must not divide by zero."""
        pts = [
            ReferencePoint(x=2.0, y=0.0, yaw=0.0),
            ReferencePoint(x=2.0, y=0.0, yaw=0.0),  # duplicate
            ReferencePoint(x=4.0, y=0.0, yaw=0.0),
        ]
        traj = ReferenceTrajectory(points=pts, coordinate_frame=CoordinateFrame.VEHICLE)
        engine = TrackingEngine(_cfg())
        snap   = engine.update(_ego(x=2.0, y=0.0), traj)
        assert snap.tracking_quality not in (
            TrackingQuality.INVALID_INPUT,
        )

    def test_all_duplicate_points_no_crash(self):
        pts = [ReferencePoint(x=1.0, y=0.0, yaw=0.0)] * 5
        traj = ReferenceTrajectory(points=pts, coordinate_frame=CoordinateFrame.VEHICLE)
        engine = TrackingEngine(_cfg())
        snap   = engine.update(_ego(), traj)
        assert snap is not None


class TestCoordinateFrameMismatch:
    def test_world_frame_traj_rejected(self):
        from core.vehicle.vehicle_types import CoordinateFrame
        engine = TrackingEngine(_cfg())
        traj   = ReferenceTrajectory(
            points=[ReferencePoint(x=5.0, y=0.0, yaw=0.0)],
            coordinate_frame=CoordinateFrame.WORLD,
        )
        snap = engine.update(_ego(), traj)
        assert snap.tracking_quality == TrackingQuality.INVALID_INPUT


class TestStaleReference:
    def test_stale_reference_detected(self):
        engine = TrackingEngine(TrackingConfig(
            max_reference_age_s=0.5,
            cte_minor_m=0.3, cte_major_m=1.0, cte_large_m=3.0,
            heading_minor_rad=0.3, heading_major_rad=0.785,
            speed_minor_mps=2.0, speed_major_mps=5.0,
        ))
        traj = _pts()
        traj.timestamp = 0.0
        ego  = _ego(timestamp=2.0)  # 2 s > 0.5 s threshold
        snap = engine.update(ego, traj)
        assert snap.tracking_quality == TrackingQuality.STALE_REFERENCE
