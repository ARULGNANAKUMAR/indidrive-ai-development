"""Phase 10.2 — Tests: ReferenceTrajectory and ReferencePoint."""
import math

from core.tracking.reference_trajectory import ReferencePoint, ReferenceTrajectory
from core.tracking.tracking_types import NOT_AVAILABLE
from core.vehicle.vehicle_types import CoordinateFrame


def _straight(n=5, step=1.0):
    """n-point straight trajectory along +X."""
    return ReferenceTrajectory.from_xy_list(
        [(i * step, 0.0) for i in range(n)]
    )


class TestReferencePoint:
    def test_default(self):
        p = ReferencePoint()
        assert p.x == 0.0
        assert p.y == 0.0
        assert p.yaw is None

    def test_yaw_normalised(self):
        p = ReferencePoint(x=0.0, y=0.0, yaw=math.pi)
        assert abs(p.yaw - (-math.pi)) < 1e-9

    def test_is_position_finite_ok(self):
        p = ReferencePoint(x=1.0, y=2.0)
        assert p.is_position_finite()

    def test_is_position_finite_nan(self):
        p = ReferencePoint(x=float("nan"), y=0.0)
        assert not p.is_position_finite()

    def test_yaw_availability_none(self):
        from core.tracking.tracking_types import ReferenceAvailability
        p = ReferencePoint()
        assert p.yaw_availability() == ReferenceAvailability.UNAVAILABLE

    def test_yaw_availability_finite(self):
        from core.tracking.tracking_types import ReferenceAvailability
        p = ReferencePoint(yaw=0.3)
        assert p.yaw_availability() == ReferenceAvailability.AVAILABLE


class TestReferenceTrajectoryFromXY:
    def test_empty(self):
        traj = ReferenceTrajectory.from_xy_list([])
        assert traj.is_empty
        assert traj.length == 0

    def test_single_point(self):
        traj = ReferenceTrajectory.from_xy_list([(1.0, 2.0)])
        assert traj.length == 1
        assert traj.points[0].yaw == 0.0

    def test_straight_heading(self):
        traj = _straight(5)
        for pt in traj.points[:-1]:
            assert abs(pt.yaw) < 1e-9  # heading along +X = 0

    def test_coordinate_frame_default(self):
        traj = _straight()
        assert traj.coordinate_frame == CoordinateFrame.VEHICLE

    def test_not_empty(self):
        traj = _straight(3)
        assert not traj.is_empty

    def test_has_yaw(self):
        traj = _straight(3)
        assert traj.has_yaw  # derived during construction

    def test_no_velocity_by_default(self):
        traj = _straight(3)
        assert not traj.has_velocity

    def test_left_curve_heading(self):
        # Path turning left: (0,0)→(1,0)→(1,1)
        traj = ReferenceTrajectory.from_xy_list([(0.0,0.0),(1.0,0.0),(1.0,1.0)])
        # First segment: heading = 0 (+X)
        assert abs(traj.points[0].yaw) < 1e-9
        # Second segment: heading = π/2 (+Y = left)
        assert abs(traj.points[1].yaw - math.pi/2) < 1e-9


class TestReferenceTrajectoryFromPathPoints:
    def test_from_path_points(self):
        from core.planning.candidate_path_types import PathPoint
        pps = [PathPoint(x=i*1.0, y=0.0, heading=0.0) for i in range(5)]
        traj = ReferenceTrajectory.from_path_points(pps, reference_velocity=10.0)
        assert traj.length == 5
        assert traj.has_velocity
        for pt in traj.points:
            assert abs(pt.velocity - 10.0) < 1e-9

    def test_from_path_points_with_curvature(self):
        from core.planning.candidate_path_types import PathPoint
        pps = [PathPoint(x=i*1.0, y=0.0, heading=0.0, curvature=0.1) for i in range(3)]
        traj = ReferenceTrajectory.from_path_points(pps)
        for pt in traj.points:
            assert pt.curvature is not None
            assert abs(pt.curvature - 0.1) < 1e-9
