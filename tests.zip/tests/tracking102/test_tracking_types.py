"""Phase 10.2 — Tests: Types, constants, enums."""
from core.tracking.tracking_types import (
    TRACKING_SCHEMA_VERSION,
    NOT_AVAILABLE,
    MatchingMethod,
    TrackingQuality,
    ReferenceAvailability,
)


class TestTrackingTypes:
    def test_schema_version(self):
        assert TRACKING_SCHEMA_VERSION == "10.2"

    def test_not_available_sentinel(self):
        assert isinstance(NOT_AVAILABLE, str)
        assert len(NOT_AVAILABLE) > 0

    def test_matching_method_values(self):
        assert MatchingMethod.NEAREST_POINT.value == "NEAREST_POINT"
        assert MatchingMethod.NEAREST_SEGMENT.value == "NEAREST_SEGMENT"

    def test_tracking_quality_members(self):
        members = {q.value for q in TrackingQuality}
        for expected in [
            "ON_TRACK", "MINOR_DEVIATION", "DEVIATING",
            "LARGE_DEVIATION", "REFERENCE_LOST", "STALE_REFERENCE",
            "INVALID_INPUT", "DEGRADED", "UNKNOWN",
        ]:
            assert expected in members

    def test_reference_availability_members(self):
        members = {r.value for r in ReferenceAvailability}
        assert "AVAILABLE"   in members
        assert "UNAVAILABLE" in members
        assert "DERIVED"     in members
        assert "INVALID"     in members
