"""Phase 10.2 — Tests: Heading Error"""
import math

from core.tracking.trajectory_matcher import TrajectoryMatcher
from core.tracking.reference_trajectory import ReferenceTrajectory
from core.tracking.tracking_types import MatchingMethod
from core.vehicle.vehicle_state import VehicleState, normalise_angle


def _ego(x=5.0, y=0.0, yaw=0.0, v=10.0):
    return VehicleState(x=x, y=y, yaw=yaw, velocity=v)


def _straight():
    return ReferenceTrajectory.from_xy_list([(i*2.0, 0.0) for i in range(6)])


class TestHeadingError:
    def setup_method(self):
        self.m = TrajectoryMatcher(MatchingMethod.NEAREST_SEGMENT)

    def test_same_heading_zero_error(self):
        traj = _straight()
        ego  = _ego(yaw=0.0)
        _, _, err = self.m.match(ego, traj)
        assert abs(err.heading_error_rad) < 1e-9

    def test_positive_heading_error(self):
        """Ego turned left relative to reference."""
        traj = _straight()
        ego  = _ego(yaw=0.3)
        _, _, err = self.m.match(ego, traj)
        assert abs(err.heading_error_rad - 0.3) < 1e-9

    def test_negative_heading_error(self):
        """Ego turned right relative to reference."""
        traj = _straight()
        ego  = _ego(yaw=-0.3)
        _, _, err = self.m.match(ego, traj)
        assert abs(err.heading_error_rad - (-0.3)) < 1e-9

    def test_heading_normalised_pi(self):
        """Heading error must stay in [-π, π)."""
        traj = _straight()
        ego  = _ego(yaw=math.pi * 0.95)
        _, _, err = self.m.match(ego, traj)
        assert -math.pi <= err.heading_error_rad < math.pi

    def test_heading_normalised_neg_pi(self):
        traj = _straight()
        ego  = _ego(yaw=-math.pi * 0.95)
        _, _, err = self.m.match(ego, traj)
        assert -math.pi <= err.heading_error_rad < math.pi

    def test_opposite_heading(self):
        """180° heading difference → normalised to ±π."""
        traj = _straight()
        ego  = _ego(yaw=math.pi)
        _, _, err = self.m.match(ego, traj)
        assert abs(abs(err.heading_error_rad) - math.pi) < 1e-9
