"""
IndiDrive AI — Phase 11.4 | Fail-Safe Tests
=============================================
Covers:
  Sensor failures (camera, lidar, radar, vehicle state)
  Synchronisation failures
  Subsystem failures (perception → safety supervisor)
  Degradation (single, multiple, partial)
  Critical failure (sensor loss, subsystem loss, multiple critical)
  Redundancy (camera+lidar)
  Recovery (confirmation cycles, blocking by emergency/supervisor)
  Hysteresis (debounce, hold)
  Multiple simultaneous failures
  Capability propagation (only affected caps degraded)
  Snapshot immutability
  Validator (malformed states rejected)
  Determinism (same input → same output)
  Thread safety
  Negative scope (engine does NOT produce actuator commands / hardware ops)
  Phase 11.3 integration (FailSafeDecision feeds Safety Supervisor)
"""
from __future__ import annotations

import threading
from typing import Optional

# pytest not available in this environment — use contextlib for raises check
from contextlib import contextmanager

class _RaisesCtx:
    def __init__(self, exc_types):
        self._exc_types = exc_types if isinstance(exc_types, tuple) else (exc_types,)
    def __enter__(self): return self
    def __exit__(self, exc_type, exc_val, tb):
        if exc_type is None:
            raise AssertionError(f"Expected {self._exc_types} but no exception raised")
        return issubclass(exc_type, self._exc_types)

class _Pytest:
    @staticmethod
    def raises(exc):
        return _RaisesCtx(exc)

pytest = _Pytest()

from core.failsafe import (
    FailSafeConfig,
    FailSafeEngine,
    FailSafeDecision,
    FailSafeSnapshot,
    FailSafeState,
    FailSafeSensorType,
    FailSafeSubsystemType,
    FailSafeValidator,
    FailureSeverity,
    FailureUrgency,
    RecoveryManager,
    RecoveryStatus,
    SensorFailureType,
    SensorHealthSummary,
    SubsystemFailureType,
    SystemCapability,
    build_snapshot,
)
from core.failsafe.sensor_failure import (
    translate_sensor_health,
    classify_sensor_failure,
    classify_sync_failure,
)

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

TS = 100.0  # reference timestamp


def default_engine() -> FailSafeEngine:
    """Engine with 1-cycle confirmation for faster tests."""
    cfg = FailSafeConfig(
        failure_confirmation_cycles=1,
        recovery_confirmation_cycles=2,
    )
    return FailSafeEngine(config=cfg)


def healthy_subsystems(ts: float = TS) -> dict:
    """Return kwargs for all subsystems in a healthy state."""
    return dict(
        perception_status="OK", perception_confidence=0.9, perception_timestamp=ts - 0.1,
        fusion_status="OK", fusion_confidence=0.9, fusion_timestamp=ts - 0.1,
        prediction_status="OK", prediction_confidence=0.9, prediction_timestamp=ts - 0.1,
        road_understanding_status="OK", road_understanding_timestamp=ts - 0.1,
        world_model_valid=True, world_model_timestamp=ts - 0.1, world_model_confidence=0.9,
        planning_status="OK", planning_timestamp=ts - 0.1,
        tracking_status="OK", tracking_timestamp=ts - 0.1,
        mpc_status="OK", mpc_timestamp=ts - 0.1,
        control_status="OK", control_timestamp=ts - 0.1,
        safety_monitor_state="SAFE", safety_monitor_timestamp=ts - 0.1,
        safety_monitor_confidence=0.95,
        emergency_detection_state="NO_EMERGENCY", emergency_detection_timestamp=ts - 0.1,
        safety_supervisor_state="NORMAL_CONTROL", safety_supervisor_timestamp=ts - 0.1,
    )


def healthy_sensors(ts: float = TS) -> dict:
    """Return kwargs for all sensors in a healthy state."""
    return dict(
        camera_health_state="ONLINE", camera_frame_age_s=0.05, camera_confidence=0.95,
        lidar_health_state="ONLINE", lidar_frame_age_s=0.05, lidar_confidence=0.95,
        vehicle_state_health_state="ONLINE", vehicle_state_frame_age_s=0.05,
        vehicle_state_confidence=0.99, vehicle_state_is_valid=True,
    )


def healthy_eval(engine: FailSafeEngine, ts: float = TS) -> FailSafeDecision:
    """Evaluate with ALL sensors and subsystems healthy."""
    return engine.evaluate(
        timestamp=ts,
        # Sensors
        camera_health_state="ONLINE",
        camera_frame_age_s=0.05,
        camera_confidence=0.95,
        lidar_health_state="ONLINE",
        lidar_frame_age_s=0.05,
        lidar_confidence=0.95,
        vehicle_state_health_state="ONLINE",
        vehicle_state_frame_age_s=0.05,
        vehicle_state_confidence=0.99,
        vehicle_state_is_valid=True,
        # Subsystems
        perception_status="OK",
        perception_confidence=0.9,
        perception_timestamp=ts - 0.1,
        fusion_status="OK",
        fusion_confidence=0.9,
        fusion_timestamp=ts - 0.1,
        prediction_status="OK",
        prediction_confidence=0.9,
        prediction_timestamp=ts - 0.1,
        road_understanding_status="OK",
        road_understanding_timestamp=ts - 0.1,
        world_model_valid=True,
        world_model_timestamp=ts - 0.1,
        world_model_confidence=0.9,
        planning_status="OK",
        planning_timestamp=ts - 0.1,
        tracking_status="OK",
        tracking_timestamp=ts - 0.1,
        mpc_status="OK",
        mpc_timestamp=ts - 0.1,
        control_status="OK",
        control_timestamp=ts - 0.1,
        safety_monitor_state="SAFE",
        safety_monitor_timestamp=ts - 0.1,
        safety_monitor_confidence=0.95,
        emergency_detection_state="NO_EMERGENCY",
        emergency_detection_timestamp=ts - 0.1,
        safety_supervisor_state="NORMAL_CONTROL",
        safety_supervisor_timestamp=ts - 0.1,
    )


# ===========================================================================
# 1. Healthy system
# ===========================================================================

class TestHealthySystem:
    def test_healthy_system_is_normal_operation(self):
        engine = default_engine()
        d = healthy_eval(engine)
        assert d.fail_safe_state == FailSafeState.NORMAL_OPERATION

    def test_healthy_no_control_withheld(self):
        engine = default_engine()
        d = healthy_eval(engine)
        assert not d.control_withheld

    def test_healthy_no_control_restriction(self):
        engine = default_engine()
        d = healthy_eval(engine)
        assert not d.control_restriction

    def test_healthy_no_sensor_failures(self):
        engine = default_engine()
        d = healthy_eval(engine)
        assert len(d.active_sensor_failures) == 0

    def test_healthy_no_subsystem_failures(self):
        engine = default_engine()
        d = healthy_eval(engine)
        assert len(d.active_subsystem_failures) == 0

    def test_healthy_no_affected_capabilities(self):
        engine = default_engine()
        d = healthy_eval(engine)
        assert len(d.affected_capabilities) == 0

    def test_healthy_confidence_high(self):
        engine = default_engine()
        d = healthy_eval(engine)
        assert d.confidence >= 0.8

    def test_healthy_not_stale(self):
        engine = default_engine()
        d = healthy_eval(engine)
        assert not d.stale


# ===========================================================================
# 2. Camera failures
# ===========================================================================

class TestCameraFailures:
    def _eval_camera_state(self, state: str, age: Optional[float] = 1.0) -> FailSafeDecision:
        engine = default_engine()
        return engine.evaluate(
            timestamp=TS,
            camera_health_state=state,
            camera_frame_age_s=age,
            camera_confidence=0.5 if state == "DEGRADED" else 1.0,
            lidar_health_state="ONLINE",
            lidar_frame_age_s=0.05,
            lidar_confidence=0.99,
            **healthy_subsystems(),
        )

    def test_camera_offline_produces_sensor_failure(self):
        d = self._eval_camera_state("OFFLINE")
        assert any(
            e.sensor_type == FailSafeSensorType.CAMERA
            for e in d.active_sensor_failures
        )

    def test_camera_not_configured_unavailable(self):
        engine = default_engine()
        d = engine.evaluate(timestamp=TS,
            camera_health_state="NOT_CONFIGURED",
            lidar_health_state="ONLINE", lidar_frame_age_s=0.05, lidar_confidence=0.99,
            vehicle_state_health_state="ONLINE", vehicle_state_frame_age_s=0.05, vehicle_state_is_valid=True,
            **healthy_subsystems())
        assert any(
            e.sensor_type == FailSafeSensorType.CAMERA
            and e.failure_type in (
                SensorFailureType.SENSOR_MISSING,
                SensorFailureType.SENSOR_TIMEOUT,
            )
            for e in d.active_sensor_failures
        )

    def test_camera_timeout_type(self):
        engine = default_engine()
        d = engine.evaluate(
            timestamp=TS,
            camera_health_state="OFFLINE",
            camera_frame_age_s=10.0,
            lidar_health_state="ONLINE", lidar_frame_age_s=0.05, lidar_confidence=0.99,
            vehicle_state_health_state="ONLINE", vehicle_state_frame_age_s=0.05, vehicle_state_is_valid=True,
            **healthy_subsystems(),
        )
        cam_evts = [
            e for e in d.active_sensor_failures
            if e.sensor_type == FailSafeSensorType.CAMERA
        ]
        assert cam_evts
        assert cam_evts[0].failure_type in (
            SensorFailureType.SENSOR_TIMEOUT,
            SensorFailureType.SENSOR_MISSING,
        )

    def test_camera_stale_propagates_stale(self):
        engine = default_engine()
        d = engine.evaluate(
            timestamp=TS,
            camera_health_state="OFFLINE",
            camera_frame_age_s=5.0,
            lidar_health_state="ONLINE", lidar_frame_age_s=0.05, lidar_confidence=0.99,
            vehicle_state_health_state="ONLINE", vehicle_state_frame_age_s=0.05, vehicle_state_is_valid=True,
            **healthy_subsystems(),
        )
        cam_evts = [e for e in d.active_sensor_failures if e.sensor_type == FailSafeSensorType.CAMERA]
        assert cam_evts
        assert cam_evts[0].stale

    def test_camera_degraded_type(self):
        d = self._eval_camera_state("DEGRADED", age=0.05)
        cam_evts = [e for e in d.active_sensor_failures if e.sensor_type == FailSafeSensorType.CAMERA]
        assert cam_evts
        assert cam_evts[0].failure_type in (
            SensorFailureType.SENSOR_RATE_DEGRADATION,
            SensorFailureType.SENSOR_LOW_CONFIDENCE,
        )
        assert cam_evts[0].degraded

    def test_camera_invalid_data(self):
        engine = default_engine()
        d = engine.evaluate(
            timestamp=TS,
            camera_health_state="ONLINE",
            camera_frame_age_s=0.05,
            camera_is_valid_data=False,
            lidar_health_state="ONLINE", lidar_frame_age_s=0.05, lidar_confidence=0.99,
            vehicle_state_health_state="ONLINE", vehicle_state_frame_age_s=0.05, vehicle_state_is_valid=True,
            **healthy_subsystems(),
        )
        cam_evts = [e for e in d.active_sensor_failures if e.sensor_type == FailSafeSensorType.CAMERA]
        assert cam_evts
        assert cam_evts[0].failure_type == SensorFailureType.SENSOR_INVALID_DATA

    def test_camera_corrupted_data(self):
        engine = default_engine()
        d = engine.evaluate(
            timestamp=TS,
            camera_health_state="ONLINE",
            camera_frame_age_s=0.05,
            camera_is_corrupted=True,
            lidar_health_state="ONLINE", lidar_frame_age_s=0.05, lidar_confidence=0.99,
            vehicle_state_health_state="ONLINE", vehicle_state_frame_age_s=0.05, vehicle_state_is_valid=True,
            **healthy_subsystems(),
        )
        cam_evts = [e for e in d.active_sensor_failures if e.sensor_type == FailSafeSensorType.CAMERA]
        assert cam_evts
        assert cam_evts[0].failure_type == SensorFailureType.SENSOR_CORRUPTED_DATA

    def test_camera_failure_affects_lane_estimation(self):
        engine = default_engine()
        d = engine.evaluate(timestamp=TS,
            camera_health_state="OFFLINE", lidar_health_state="OFFLINE",
            vehicle_state_health_state="ONLINE", vehicle_state_frame_age_s=0.05, vehicle_state_is_valid=True,
            **healthy_subsystems())
        assert SystemCapability.LANE_ESTIMATION in d.affected_capabilities

    def test_camera_failure_does_not_affect_vehicle_state(self):
        engine = default_engine()
        d = engine.evaluate(
            timestamp=TS,
            camera_health_state="OFFLINE",
            lidar_health_state="ONLINE",
            lidar_frame_age_s=0.05,
            lidar_confidence=0.99,
            vehicle_state_health_state="ONLINE",
            vehicle_state_frame_age_s=0.05,
            vehicle_state_is_valid=True,
            **healthy_subsystems(),
        )
        # Camera failure alone should NOT affect VEHICLE_STATE_ESTIMATION
        assert SystemCapability.VEHICLE_STATE_ESTIMATION not in d.affected_capabilities

    def test_camera_timestamp_failure(self):
        engine = default_engine()
        d = engine.evaluate(
            timestamp=TS,
            camera_health_state="ONLINE",
            camera_frame_age_s=0.05,
            camera_ts_invalid=True,
            lidar_health_state="ONLINE", lidar_frame_age_s=0.05, lidar_confidence=0.99,
            vehicle_state_health_state="ONLINE", vehicle_state_frame_age_s=0.05, vehicle_state_is_valid=True,
            **healthy_subsystems(),
        )
        cam_evts = [e for e in d.active_sensor_failures if e.sensor_type == FailSafeSensorType.CAMERA]
        assert cam_evts
        assert cam_evts[0].failure_type == SensorFailureType.SENSOR_TIMESTAMP_FAILURE


# ===========================================================================
# 3. LiDAR failures
# ===========================================================================

class TestLiDARFailures:
    def test_lidar_offline(self):
        engine = default_engine()
        d = engine.evaluate(
            timestamp=TS,
            camera_health_state="ONLINE",
            camera_frame_age_s=0.05,
            camera_confidence=0.95,
            lidar_health_state="OFFLINE",
            vehicle_state_health_state="ONLINE", vehicle_state_frame_age_s=0.05, vehicle_state_is_valid=True,
            **healthy_subsystems(),
        )
        assert any(e.sensor_type == FailSafeSensorType.LIDAR for e in d.active_sensor_failures)

    def test_lidar_timeout(self):
        engine = default_engine()
        d = engine.evaluate(
            timestamp=TS,
            camera_health_state="ONLINE", camera_frame_age_s=0.05, camera_confidence=0.95,
            lidar_health_state="OFFLINE",
            lidar_frame_age_s=5.0,
            vehicle_state_health_state="ONLINE", vehicle_state_frame_age_s=0.05, vehicle_state_is_valid=True,
            **healthy_subsystems(),
        )
        lid_evts = [e for e in d.active_sensor_failures if e.sensor_type == FailSafeSensorType.LIDAR]
        assert lid_evts
        assert lid_evts[0].failure_type in (
            SensorFailureType.SENSOR_TIMEOUT,
            SensorFailureType.SENSOR_MISSING,
        )

    def test_lidar_failure_affects_depth_estimation(self):
        engine = default_engine()
        d = engine.evaluate(timestamp=TS,
            camera_health_state="ONLINE", camera_frame_age_s=0.05, camera_confidence=0.95,
            lidar_health_state="OFFLINE",
            vehicle_state_health_state="ONLINE", vehicle_state_frame_age_s=0.05, vehicle_state_is_valid=True,
            **healthy_subsystems())
        assert SystemCapability.DEPTH_ESTIMATION in d.affected_capabilities

    def test_lidar_failure_not_affect_lane_estimation(self):
        engine = default_engine()
        d = engine.evaluate(
            timestamp=TS,
            camera_health_state="ONLINE",
            camera_frame_age_s=0.05,
            camera_confidence=0.95,
            lidar_health_state="OFFLINE",
            vehicle_state_health_state="ONLINE", vehicle_state_frame_age_s=0.05, vehicle_state_is_valid=True,
            **healthy_subsystems(),
        )
        # LiDAR alone does not affect LANE_ESTIMATION (camera handles that)
        assert SystemCapability.LANE_ESTIMATION not in d.affected_capabilities

    def test_lidar_invalid_data(self):
        engine = default_engine()
        d = engine.evaluate(
            timestamp=TS,
            camera_health_state="ONLINE", camera_frame_age_s=0.05, camera_confidence=0.95,
            lidar_health_state="ONLINE",
            lidar_frame_age_s=0.05,
            lidar_is_valid_data=False,
            vehicle_state_health_state="ONLINE", vehicle_state_frame_age_s=0.05, vehicle_state_is_valid=True,
            **healthy_subsystems(),
        )
        lid_evts = [e for e in d.active_sensor_failures if e.sensor_type == FailSafeSensorType.LIDAR]
        assert lid_evts
        assert lid_evts[0].failure_type == SensorFailureType.SENSOR_INVALID_DATA


# ===========================================================================
# 4. Radar failure (optional sensor)
# ===========================================================================

class TestRadarFailures:
    def test_radar_failure_when_configured(self):
        engine = default_engine()
        d = engine.evaluate(
            timestamp=TS,
            radar_health_state="OFFLINE",
            radar_frame_age_s=5.0,
            **healthy_sensors(),
            **healthy_subsystems(),
        )
        assert any(e.sensor_type == FailSafeSensorType.RADAR for e in d.active_sensor_failures)

    def test_radar_not_present_no_radar_event(self):
        engine = default_engine()
        d = engine.evaluate(timestamp=TS, radar_health_state=None, **healthy_sensors(), **healthy_subsystems())
        # No radar_health_state passed → no radar event
        assert not any(e.sensor_type == FailSafeSensorType.RADAR for e in d.active_sensor_failures)


# ===========================================================================
# 5. Vehicle state failure
# ===========================================================================

class TestVehicleStateFailures:
    def test_vehicle_state_offline_withheld(self):
        engine = default_engine()
        d = engine.evaluate(
            timestamp=TS,
            camera_health_state="ONLINE", camera_frame_age_s=0.05, camera_confidence=0.95,
            lidar_health_state="ONLINE", lidar_frame_age_s=0.05, lidar_confidence=0.95,
            vehicle_state_health_state="OFFLINE",
            vehicle_state_frame_age_s=2.0,
            **healthy_subsystems(),
        )
        assert d.control_withheld
        assert SystemCapability.VEHICLE_STATE_ESTIMATION in d.affected_capabilities

    def test_vehicle_state_invalid_withheld(self):
        engine = default_engine()
        d = engine.evaluate(
            timestamp=TS,
            camera_health_state="ONLINE", camera_frame_age_s=0.05, camera_confidence=0.95,
            lidar_health_state="ONLINE", lidar_frame_age_s=0.05, lidar_confidence=0.95,
            vehicle_state_health_state="ONLINE",
            vehicle_state_frame_age_s=0.05,
            vehicle_state_is_valid=False,
            **healthy_subsystems(),
        )
        assert d.control_withheld

    def test_vehicle_state_failure_affects_mpc_control(self):
        engine = default_engine()
        d = engine.evaluate(
            timestamp=TS,
            camera_health_state="ONLINE", camera_frame_age_s=0.05, camera_confidence=0.95,
            lidar_health_state="ONLINE", lidar_frame_age_s=0.05, lidar_confidence=0.95,
            vehicle_state_health_state="OFFLINE",
            vehicle_state_frame_age_s=2.0,
            **healthy_subsystems(),
        )
        assert SystemCapability.MPC_CONTROL in d.affected_capabilities


# ===========================================================================
# 6. Synchronisation failures
# ===========================================================================

class TestSynchronisationFailures:
    def test_camera_lidar_sync_failure_detected(self):
        engine = default_engine()
        d = engine.evaluate(
            timestamp=TS,
            camera_health_state="ONLINE",
            camera_frame_age_s=0.05,
            camera_confidence=0.95,
            lidar_health_state="ONLINE",
            lidar_frame_age_s=0.05,
            lidar_confidence=0.95,
            vehicle_state_health_state="ONLINE", vehicle_state_frame_age_s=0.05, vehicle_state_is_valid=True,
            check_camera_lidar_sync=True,
            camera_data_timestamp=TS - 0.05,
            lidar_data_timestamp=TS - 0.8,
            **healthy_subsystems(),
        )
        sync_evts = [
            e for e in d.active_sensor_failures
            if e.failure_type == SensorFailureType.SENSOR_SYNCHRONIZATION_FAILURE
        ]
        assert sync_evts

    def test_camera_lidar_within_tolerance_no_sync_failure(self):
        engine = default_engine()
        d = engine.evaluate(
            timestamp=TS,
            camera_health_state="ONLINE",
            camera_frame_age_s=0.05,
            camera_confidence=0.95,
            lidar_health_state="ONLINE",
            lidar_frame_age_s=0.05,
            lidar_confidence=0.95,
            vehicle_state_health_state="ONLINE", vehicle_state_frame_age_s=0.05, vehicle_state_is_valid=True,
            check_camera_lidar_sync=True,
            camera_data_timestamp=TS - 0.05,
            lidar_data_timestamp=TS - 0.06,
            **healthy_subsystems(),
        )
        sync_evts = [
            e for e in d.active_sensor_failures
            if e.failure_type == SensorFailureType.SENSOR_SYNCHRONIZATION_FAILURE
        ]
        assert not sync_evts

    def test_invalid_timestamp_sync_failure(self):
        from core.failsafe.sensor_failure import classify_sync_failure
        cfg = FailSafeConfig()
        evt = classify_sync_failure(
            FailSafeSensorType.CAMERA,
            FailSafeSensorType.LIDAR,
            float("nan"),  # invalid
            TS - 0.05,
            TS,
            cfg,
        )
        assert evt is not None
        assert evt.failure_type == SensorFailureType.SENSOR_SYNCHRONIZATION_FAILURE


# ===========================================================================
# 7. Subsystem failures
# ===========================================================================

class TestSubsystemFailures:
    def _sub_fail(self, sub_key: str, **kwargs) -> FailSafeDecision:
        engine = default_engine()
        return engine.evaluate(timestamp=TS, **{sub_key: None}, **kwargs)

    def test_perception_failure(self):
        engine = default_engine()
        d = engine.evaluate(timestamp=TS, perception_status=None, perception_timestamp=0.0,
            **healthy_sensors(),
            fusion_status="OK", fusion_confidence=0.9, fusion_timestamp=TS-0.1,
            prediction_status="OK", prediction_confidence=0.9, prediction_timestamp=TS-0.1,
            road_understanding_status="OK", road_understanding_timestamp=TS-0.1,
            world_model_valid=True, world_model_timestamp=TS-0.1, world_model_confidence=0.9,
            planning_status="OK", planning_timestamp=TS-0.1,
            tracking_status="OK", tracking_timestamp=TS-0.1,
            mpc_status="OK", mpc_timestamp=TS-0.1,
            control_status="OK", control_timestamp=TS-0.1,
            safety_monitor_state="SAFE", safety_monitor_timestamp=TS-0.1, safety_monitor_confidence=0.95,
            emergency_detection_state="NO_EMERGENCY", emergency_detection_timestamp=TS-0.1,
            safety_supervisor_state="NORMAL_CONTROL", safety_supervisor_timestamp=TS-0.1)
        assert any(
            e.subsystem == FailSafeSubsystemType.PERCEPTION for e in d.active_subsystem_failures
        )

    def test_perception_affects_object_detection(self):
        engine = default_engine()
        d = engine.evaluate(timestamp=TS, perception_status=None, perception_timestamp=0.0,
            **healthy_sensors(),
            fusion_status="OK", fusion_confidence=0.9, fusion_timestamp=TS-0.1,
            prediction_status="OK", prediction_confidence=0.9, prediction_timestamp=TS-0.1,
            road_understanding_status="OK", road_understanding_timestamp=TS-0.1,
            world_model_valid=True, world_model_timestamp=TS-0.1, world_model_confidence=0.9,
            planning_status="OK", planning_timestamp=TS-0.1,
            tracking_status="OK", tracking_timestamp=TS-0.1,
            mpc_status="OK", mpc_timestamp=TS-0.1,
            control_status="OK", control_timestamp=TS-0.1,
            safety_monitor_state="SAFE", safety_monitor_timestamp=TS-0.1, safety_monitor_confidence=0.95,
            emergency_detection_state="NO_EMERGENCY", emergency_detection_timestamp=TS-0.1,
            safety_supervisor_state="NORMAL_CONTROL", safety_supervisor_timestamp=TS-0.1)
        assert SystemCapability.OBJECT_DETECTION in d.affected_capabilities

    def test_fusion_failure(self):
        engine = default_engine()
        d = engine.evaluate(timestamp=TS, fusion_status="INVALID", fusion_timestamp=TS - 0.1,
            **healthy_sensors(),
            perception_status="OK", perception_confidence=0.9, perception_timestamp=TS-0.1,
            prediction_status="OK", prediction_confidence=0.9, prediction_timestamp=TS-0.1,
            road_understanding_status="OK", road_understanding_timestamp=TS-0.1,
            world_model_valid=True, world_model_timestamp=TS-0.1, world_model_confidence=0.9,
            planning_status="OK", planning_timestamp=TS-0.1,
            tracking_status="OK", tracking_timestamp=TS-0.1,
            mpc_status="OK", mpc_timestamp=TS-0.1,
            control_status="OK", control_timestamp=TS-0.1,
            safety_monitor_state="SAFE", safety_monitor_timestamp=TS-0.1, safety_monitor_confidence=0.95,
            emergency_detection_state="NO_EMERGENCY", emergency_detection_timestamp=TS-0.1,
            safety_supervisor_state="NORMAL_CONTROL", safety_supervisor_timestamp=TS-0.1)
        assert any(
            e.subsystem == FailSafeSubsystemType.FUSION for e in d.active_subsystem_failures
        )

    def test_fusion_failure_affects_world_model(self):
        engine = default_engine()
        d = engine.evaluate(timestamp=TS, fusion_status="INVALID", fusion_timestamp=TS - 0.1,
            **healthy_sensors(),
            perception_status="OK", perception_confidence=0.9, perception_timestamp=TS-0.1,
            prediction_status="OK", prediction_confidence=0.9, prediction_timestamp=TS-0.1,
            road_understanding_status="OK", road_understanding_timestamp=TS-0.1,
            world_model_valid=True, world_model_timestamp=TS-0.1, world_model_confidence=0.9,
            planning_status="OK", planning_timestamp=TS-0.1,
            tracking_status="OK", tracking_timestamp=TS-0.1,
            mpc_status="OK", mpc_timestamp=TS-0.1,
            control_status="OK", control_timestamp=TS-0.1,
            safety_monitor_state="SAFE", safety_monitor_timestamp=TS-0.1, safety_monitor_confidence=0.95,
            emergency_detection_state="NO_EMERGENCY", emergency_detection_timestamp=TS-0.1,
            safety_supervisor_state="NORMAL_CONTROL", safety_supervisor_timestamp=TS-0.1)
        assert SystemCapability.WORLD_MODEL_VALIDITY in d.affected_capabilities

    def test_prediction_failure(self):
        engine = default_engine()
        d = engine.evaluate(timestamp=TS, prediction_status=None, prediction_timestamp=0.0,
            **healthy_sensors(),
            perception_status="OK", perception_confidence=0.9, perception_timestamp=TS-0.1,
            fusion_status="OK", fusion_confidence=0.9, fusion_timestamp=TS-0.1,
            road_understanding_status="OK", road_understanding_timestamp=TS-0.1,
            world_model_valid=True, world_model_timestamp=TS-0.1, world_model_confidence=0.9,
            planning_status="OK", planning_timestamp=TS-0.1,
            tracking_status="OK", tracking_timestamp=TS-0.1,
            mpc_status="OK", mpc_timestamp=TS-0.1,
            control_status="OK", control_timestamp=TS-0.1,
            safety_monitor_state="SAFE", safety_monitor_timestamp=TS-0.1, safety_monitor_confidence=0.95,
            emergency_detection_state="NO_EMERGENCY", emergency_detection_timestamp=TS-0.1,
            safety_supervisor_state="NORMAL_CONTROL", safety_supervisor_timestamp=TS-0.1)
        assert any(
            e.subsystem == FailSafeSubsystemType.PREDICTION for e in d.active_subsystem_failures
        )

    def test_prediction_affects_collision_risk(self):
        engine = default_engine()
        d = engine.evaluate(timestamp=TS, prediction_status=None, prediction_timestamp=0.0,
            **healthy_sensors(),
            perception_status="OK", perception_confidence=0.9, perception_timestamp=TS-0.1,
            fusion_status="OK", fusion_confidence=0.9, fusion_timestamp=TS-0.1,
            road_understanding_status="OK", road_understanding_timestamp=TS-0.1,
            world_model_valid=True, world_model_timestamp=TS-0.1, world_model_confidence=0.9,
            planning_status="OK", planning_timestamp=TS-0.1,
            tracking_status="OK", tracking_timestamp=TS-0.1,
            mpc_status="OK", mpc_timestamp=TS-0.1,
            control_status="OK", control_timestamp=TS-0.1,
            safety_monitor_state="SAFE", safety_monitor_timestamp=TS-0.1, safety_monitor_confidence=0.95,
            emergency_detection_state="NO_EMERGENCY", emergency_detection_timestamp=TS-0.1,
            safety_supervisor_state="NORMAL_CONTROL", safety_supervisor_timestamp=TS-0.1)
        assert SystemCapability.COLLISION_RISK_ESTIMATION in d.affected_capabilities

    def test_road_understanding_failure(self):
        engine = default_engine()
        d = engine.evaluate(timestamp=TS, road_understanding_status=None, road_understanding_timestamp=0.0,
            **healthy_sensors(),
            perception_status="OK", perception_confidence=0.9, perception_timestamp=TS-0.1,
            fusion_status="OK", fusion_confidence=0.9, fusion_timestamp=TS-0.1,
            prediction_status="OK", prediction_confidence=0.9, prediction_timestamp=TS-0.1,
            world_model_valid=True, world_model_timestamp=TS-0.1, world_model_confidence=0.9,
            planning_status="OK", planning_timestamp=TS-0.1,
            tracking_status="OK", tracking_timestamp=TS-0.1,
            mpc_status="OK", mpc_timestamp=TS-0.1,
            control_status="OK", control_timestamp=TS-0.1,
            safety_monitor_state="SAFE", safety_monitor_timestamp=TS-0.1, safety_monitor_confidence=0.95,
            emergency_detection_state="NO_EMERGENCY", emergency_detection_timestamp=TS-0.1,
            safety_supervisor_state="NORMAL_CONTROL", safety_supervisor_timestamp=TS-0.1)
        assert any(
            e.subsystem == FailSafeSubsystemType.ROAD_UNDERSTANDING for e in d.active_subsystem_failures
        )

    def test_world_model_invalid(self):
        engine = default_engine()
        d = engine.evaluate(
            timestamp=TS,
            world_model_valid=False,
            world_model_timestamp=TS - 0.1,
            world_model_confidence=0.0,
            **healthy_sensors(),
            perception_status="OK", perception_confidence=0.9, perception_timestamp=TS-0.1,
            fusion_status="OK", fusion_confidence=0.9, fusion_timestamp=TS-0.1,
            prediction_status="OK", prediction_confidence=0.9, prediction_timestamp=TS-0.1,
            road_understanding_status="OK", road_understanding_timestamp=TS-0.1,
            planning_status="OK", planning_timestamp=TS-0.1,
            tracking_status="OK", tracking_timestamp=TS-0.1,
            mpc_status="OK", mpc_timestamp=TS-0.1,
            control_status="OK", control_timestamp=TS-0.1,
            safety_monitor_state="SAFE", safety_monitor_timestamp=TS-0.1, safety_monitor_confidence=0.95,
            emergency_detection_state="NO_EMERGENCY", emergency_detection_timestamp=TS-0.1,
            safety_supervisor_state="NORMAL_CONTROL", safety_supervisor_timestamp=TS-0.1,
        )
        assert any(
            e.subsystem == FailSafeSubsystemType.WORLD_MODEL for e in d.active_subsystem_failures
        )

    def test_world_model_invalid_restricts_planning(self):
        engine = default_engine()
        d = engine.evaluate(
            timestamp=TS,
            world_model_valid=False,
            world_model_timestamp=TS - 0.1,
            **healthy_sensors(),
            perception_status="OK", perception_confidence=0.9, perception_timestamp=TS-0.1,
            fusion_status="OK", fusion_confidence=0.9, fusion_timestamp=TS-0.1,
            prediction_status="OK", prediction_confidence=0.9, prediction_timestamp=TS-0.1,
            road_understanding_status="OK", road_understanding_timestamp=TS-0.1,
            planning_status="OK", planning_timestamp=TS-0.1,
            tracking_status="OK", tracking_timestamp=TS-0.1,
            mpc_status="OK", mpc_timestamp=TS-0.1,
            control_status="OK", control_timestamp=TS-0.1,
            safety_monitor_state="SAFE", safety_monitor_timestamp=TS-0.1, safety_monitor_confidence=0.95,
            emergency_detection_state="NO_EMERGENCY", emergency_detection_timestamp=TS-0.1,
            safety_supervisor_state="NORMAL_CONTROL", safety_supervisor_timestamp=TS-0.1,
        )
        assert SystemCapability.PLANNING in d.affected_capabilities

    def test_planner_failure(self):
        engine = default_engine()
        d = engine.evaluate(timestamp=TS, planning_status="FAILED", planning_timestamp=TS - 0.1,
            **healthy_sensors(), **{k:v for k,v in healthy_subsystems().items() if 'planning' not in k})
        assert any(
            e.subsystem == FailSafeSubsystemType.PLANNING for e in d.active_subsystem_failures
        )

    def test_tracking_failure(self):
        engine = default_engine()
        d = engine.evaluate(timestamp=TS, tracking_status="INVALID", tracking_timestamp=TS - 0.1,
            **healthy_sensors(), **{k:v for k,v in healthy_subsystems().items() if 'tracking' not in k})
        assert any(
            e.subsystem == FailSafeSubsystemType.TRACKING for e in d.active_subsystem_failures
        )
        assert SystemCapability.TRAJECTORY_TRACKING in d.affected_capabilities

    def test_mpc_failure(self):
        engine = default_engine()
        d = engine.evaluate(timestamp=TS, mpc_status="FAILED", mpc_timestamp=TS - 0.1,
            **healthy_sensors(), **{k:v for k,v in healthy_subsystems().items() if 'mpc' not in k})
        assert any(
            e.subsystem == FailSafeSubsystemType.MPC for e in d.active_subsystem_failures
        )
        assert SystemCapability.MPC_CONTROL in d.affected_capabilities

    def test_control_failure_withheld(self):
        engine = default_engine()
        d = engine.evaluate(timestamp=TS, control_status="FAILED", control_timestamp=TS - 0.1,
            **healthy_sensors(), **{k:v for k,v in healthy_subsystems().items() if 'control' not in k})
        assert any(
            e.subsystem == FailSafeSubsystemType.CONTROL for e in d.active_subsystem_failures
        )
        assert d.control_withheld

    def test_safety_monitor_failure(self):
        engine = default_engine()
        d = engine.evaluate(
            timestamp=TS,
            safety_monitor_state="UNAVAILABLE",
            safety_monitor_timestamp=TS - 5.0,
            **healthy_sensors(),
            perception_status="OK", perception_confidence=0.9, perception_timestamp=TS-0.1,
            fusion_status="OK", fusion_confidence=0.9, fusion_timestamp=TS-0.1,
            prediction_status="OK", prediction_confidence=0.9, prediction_timestamp=TS-0.1,
            road_understanding_status="OK", road_understanding_timestamp=TS-0.1,
            world_model_valid=True, world_model_timestamp=TS-0.1, world_model_confidence=0.9,
            planning_status="OK", planning_timestamp=TS-0.1,
            tracking_status="OK", tracking_timestamp=TS-0.1,
            mpc_status="OK", mpc_timestamp=TS-0.1,
            control_status="OK", control_timestamp=TS-0.1,
            emergency_detection_state="NO_EMERGENCY", emergency_detection_timestamp=TS-0.1,
            safety_supervisor_state="NORMAL_CONTROL", safety_supervisor_timestamp=TS-0.1,
        )
        assert any(
            e.subsystem == FailSafeSubsystemType.SAFETY_MONITOR for e in d.active_subsystem_failures
        )

    def test_emergency_detection_failure(self):
        engine = default_engine()
        d = engine.evaluate(
            timestamp=TS,
            emergency_detection_state=None,
            emergency_detection_timestamp=0.0,
            **healthy_sensors(),
            perception_status="OK", perception_confidence=0.9, perception_timestamp=TS-0.1,
            fusion_status="OK", fusion_confidence=0.9, fusion_timestamp=TS-0.1,
            prediction_status="OK", prediction_confidence=0.9, prediction_timestamp=TS-0.1,
            road_understanding_status="OK", road_understanding_timestamp=TS-0.1,
            world_model_valid=True, world_model_timestamp=TS-0.1, world_model_confidence=0.9,
            planning_status="OK", planning_timestamp=TS-0.1,
            tracking_status="OK", tracking_timestamp=TS-0.1,
            mpc_status="OK", mpc_timestamp=TS-0.1,
            control_status="OK", control_timestamp=TS-0.1,
            safety_monitor_state="SAFE", safety_monitor_timestamp=TS-0.1, safety_monitor_confidence=0.95,
            safety_supervisor_state="NORMAL_CONTROL", safety_supervisor_timestamp=TS-0.1,
        )
        assert any(
            e.subsystem == FailSafeSubsystemType.EMERGENCY_DETECTION for e in d.active_subsystem_failures
        )

    def test_safety_supervisor_failure_withheld(self):
        engine = default_engine()
        d = engine.evaluate(
            timestamp=TS,
            safety_supervisor_state="UNAVAILABLE",
            safety_supervisor_timestamp=TS - 5.0,
            **healthy_sensors(),
            perception_status="OK", perception_confidence=0.9, perception_timestamp=TS-0.1,
            fusion_status="OK", fusion_confidence=0.9, fusion_timestamp=TS-0.1,
            prediction_status="OK", prediction_confidence=0.9, prediction_timestamp=TS-0.1,
            road_understanding_status="OK", road_understanding_timestamp=TS-0.1,
            world_model_valid=True, world_model_timestamp=TS-0.1, world_model_confidence=0.9,
            planning_status="OK", planning_timestamp=TS-0.1,
            tracking_status="OK", tracking_timestamp=TS-0.1,
            mpc_status="OK", mpc_timestamp=TS-0.1,
            control_status="OK", control_timestamp=TS-0.1,
            safety_monitor_state="SAFE", safety_monitor_timestamp=TS-0.1, safety_monitor_confidence=0.95,
            emergency_detection_state="NO_EMERGENCY", emergency_detection_timestamp=TS-0.1,
        )
        assert d.control_withheld

    def test_subsystem_stale_detected(self):
        engine = default_engine()
        # perception timestamp far in the past
        d = engine.evaluate(
            timestamp=TS,
            perception_status="OK",
            perception_confidence=0.9,
            perception_timestamp=TS - 10.0,  # stale
            **healthy_sensors(),
            fusion_status="OK", fusion_confidence=0.9, fusion_timestamp=TS-0.1,
            prediction_status="OK", prediction_confidence=0.9, prediction_timestamp=TS-0.1,
            road_understanding_status="OK", road_understanding_timestamp=TS-0.1,
            world_model_valid=True, world_model_timestamp=TS-0.1, world_model_confidence=0.9,
            planning_status="OK", planning_timestamp=TS-0.1,
            tracking_status="OK", tracking_timestamp=TS-0.1,
            mpc_status="OK", mpc_timestamp=TS-0.1,
            control_status="OK", control_timestamp=TS-0.1,
            safety_monitor_state="SAFE", safety_monitor_timestamp=TS-0.1, safety_monitor_confidence=0.95,
            emergency_detection_state="NO_EMERGENCY", emergency_detection_timestamp=TS-0.1,
            safety_supervisor_state="NORMAL_CONTROL", safety_supervisor_timestamp=TS-0.1,
        )
        assert any(
            e.subsystem == FailSafeSubsystemType.PERCEPTION
            and e.failure_type == SubsystemFailureType.OUTPUT_STALE
            for e in d.active_subsystem_failures
        )


# ===========================================================================
# 8. Degradation
# ===========================================================================

class TestDegradation:
    def test_single_sensor_degraded_is_degraded_state(self):
        engine = default_engine()
        d = engine.evaluate(
            timestamp=TS,
            camera_health_state="DEGRADED",
            camera_frame_age_s=0.05,
            camera_confidence=0.15,
            lidar_health_state="ONLINE",
            lidar_frame_age_s=0.05,
            lidar_confidence=0.99,
            vehicle_state_health_state="ONLINE", vehicle_state_frame_age_s=0.05, vehicle_state_is_valid=True,
            **healthy_subsystems(),
        )
        # Should be SENSOR_DEGRADED or DEGRADED_OPERATION, not CONTROL_WITHHELD
        assert d.fail_safe_state in (
            FailSafeState.SENSOR_DEGRADED,
            FailSafeState.DEGRADED_OPERATION,
            FailSafeState.CONTROL_RESTRICTED,
        )
        assert not d.control_withheld

    def test_multiple_sensor_degraded(self):
        engine = default_engine()
        d = engine.evaluate(
            timestamp=TS,
            camera_health_state="DEGRADED",
            camera_frame_age_s=0.05,
            camera_confidence=0.15,
            lidar_health_state="DEGRADED",
            lidar_frame_age_s=0.05,
            lidar_confidence=0.15,
            vehicle_state_health_state="ONLINE", vehicle_state_frame_age_s=0.05, vehicle_state_is_valid=True,
            **healthy_subsystems(),
        )
        # Both degraded → still should not automatically withhold control
        # unless capabilities are critical
        assert d.fail_safe_state != FailSafeState.NORMAL_OPERATION
        sensor_evts = [e for e in d.active_sensor_failures if e.degraded]
        assert len(sensor_evts) >= 2

    def test_partial_subsystem_degraded(self):
        engine = default_engine()
        d = engine.evaluate(
            timestamp=TS,
            perception_status="DEGRADED",
            perception_confidence=0.4,
            perception_timestamp=TS - 0.1,
            camera_health_state="ONLINE",
            camera_frame_age_s=0.05,
            camera_confidence=0.95,
            lidar_health_state="ONLINE", lidar_frame_age_s=0.05, lidar_confidence=0.95,
            vehicle_state_health_state="ONLINE", vehicle_state_frame_age_s=0.05, vehicle_state_is_valid=True,
            fusion_status="OK", fusion_confidence=0.9, fusion_timestamp=TS-0.1,
            prediction_status="OK", prediction_confidence=0.9, prediction_timestamp=TS-0.1,
            road_understanding_status="OK", road_understanding_timestamp=TS-0.1,
            world_model_valid=True, world_model_timestamp=TS-0.1, world_model_confidence=0.9,
            planning_status="OK", planning_timestamp=TS-0.1,
            tracking_status="OK", tracking_timestamp=TS-0.1,
            mpc_status="OK", mpc_timestamp=TS-0.1,
            control_status="OK", control_timestamp=TS-0.1,
            safety_monitor_state="SAFE", safety_monitor_timestamp=TS-0.1, safety_monitor_confidence=0.95,
            emergency_detection_state="NO_EMERGENCY", emergency_detection_timestamp=TS-0.1,
            safety_supervisor_state="NORMAL_CONTROL", safety_supervisor_timestamp=TS-0.1,
        )
        assert any(
            e.subsystem == FailSafeSubsystemType.PERCEPTION
            for e in d.active_subsystem_failures
        )


# ===========================================================================
# 9. Critical failures
# ===========================================================================

class TestCriticalFailures:
    def test_camera_and_lidar_both_lost_fail_safe_active(self):
        engine = default_engine()
        d = engine.evaluate(
            timestamp=TS,
            camera_health_state="OFFLINE",
            camera_frame_age_s=5.0,
            lidar_health_state="OFFLINE",
            lidar_frame_age_s=5.0,
            vehicle_state_health_state="ONLINE", vehicle_state_frame_age_s=0.05, vehicle_state_is_valid=True,
            **healthy_subsystems(),
        )
        assert d.fail_safe_state in (
            FailSafeState.FAIL_SAFE_ACTIVE,
            FailSafeState.CONTROL_WITHHELD,
            FailSafeState.CONTROL_RESTRICTED,
        )

    def test_multiple_critical_failures_all_preserved(self):
        engine = default_engine()
        d = engine.evaluate(
            timestamp=TS,
            camera_health_state="OFFLINE",
            lidar_health_state="OFFLINE",
            vehicle_state_health_state="OFFLINE",
            vehicle_state_frame_age_s=5.0,
            **healthy_subsystems(),
        )
        # All three should be present in active failures
        sensor_types = {e.sensor_type for e in d.active_sensor_failures}
        assert FailSafeSensorType.CAMERA in sensor_types
        assert FailSafeSensorType.LIDAR in sensor_types
        assert FailSafeSensorType.VEHICLE_STATE in sensor_types

    def test_safety_critical_capability_lost_withheld(self):
        engine = default_engine()
        d = engine.evaluate(
            timestamp=TS,
            camera_health_state="ONLINE", camera_frame_age_s=0.05, camera_confidence=0.95,
            lidar_health_state="ONLINE", lidar_frame_age_s=0.05, lidar_confidence=0.95,
            vehicle_state_health_state="OFFLINE",
            vehicle_state_frame_age_s=5.0,
            **healthy_subsystems(),
        )
        assert d.control_withheld
        assert SystemCapability.CONTROL_AUTHORITY in d.affected_capabilities

    def test_unknown_fail_safe_state_withheld(self):
        engine = default_engine()
        # Invalid timestamp → UNKNOWN_FAIL_SAFE_STATE
        d = engine.evaluate(timestamp=float("nan"))
        assert d.fail_safe_state == FailSafeState.UNKNOWN_FAIL_SAFE_STATE
        assert d.control_withheld


# ===========================================================================
# 10. Redundancy
# ===========================================================================

class TestRedundancy:
    def test_camera_unavailable_lidar_healthy_not_withheld(self):
        engine = default_engine()
        d = engine.evaluate(
            timestamp=TS,
            camera_health_state="OFFLINE",
            camera_frame_age_s=5.0,
            lidar_health_state="ONLINE",
            lidar_frame_age_s=0.05,
            lidar_confidence=0.99,
            vehicle_state_health_state="ONLINE",
            vehicle_state_frame_age_s=0.05,
            vehicle_state_is_valid=True,
            **healthy_subsystems(),
        )
        # LiDAR healthy: should not withhold control solely due to camera
        assert not d.control_withheld

    def test_lidar_unavailable_camera_healthy_not_withheld(self):
        engine = default_engine()
        d = engine.evaluate(
            timestamp=TS,
            camera_health_state="ONLINE",
            camera_frame_age_s=0.05,
            camera_confidence=0.95,
            lidar_health_state="OFFLINE",
            lidar_frame_age_s=5.0,
            vehicle_state_health_state="ONLINE",
            vehicle_state_frame_age_s=0.05,
            vehicle_state_is_valid=True,
            **healthy_subsystems(),
        )
        assert not d.control_withheld

    def test_camera_and_lidar_both_unavailable_more_restrictive(self):
        engine_a = default_engine()
        engine_b = default_engine()

        # Only camera down
        d_one = engine_a.evaluate(
            timestamp=TS,
            camera_health_state="OFFLINE",
            lidar_health_state="ONLINE",
            lidar_frame_age_s=0.05,
            lidar_confidence=0.99,
            vehicle_state_health_state="ONLINE", vehicle_state_frame_age_s=0.05, vehicle_state_is_valid=True,
            **healthy_subsystems(),
        )
        # Both down
        d_both = engine_b.evaluate(
            timestamp=TS,
            camera_health_state="OFFLINE",
            lidar_health_state="OFFLINE",
            vehicle_state_health_state="ONLINE", vehicle_state_frame_age_s=0.05, vehicle_state_is_valid=True,
            **healthy_subsystems(),
        )
        # "both down" must be at least as restrictive
        state_priority = {s: i for i, s in enumerate(
            [FailSafeState.UNKNOWN_FAIL_SAFE_STATE, FailSafeState.CONTROL_WITHHELD,
             FailSafeState.FAIL_SAFE_ACTIVE, FailSafeState.SUBSYSTEM_FAILURE,
             FailSafeState.CONTROL_RESTRICTED, FailSafeState.SENSOR_UNAVAILABLE,
             FailSafeState.SUBSYSTEM_DEGRADED, FailSafeState.SENSOR_DEGRADED,
             FailSafeState.RECOVERY_PENDING, FailSafeState.RECOVERY_VALIDATING,
             FailSafeState.DEGRADED_OPERATION, FailSafeState.RECOVERED,
             FailSafeState.NORMAL_OPERATION]
        )}
        assert state_priority.get(d_both.fail_safe_state, 99) <= state_priority.get(d_one.fail_safe_state, 99)

    def test_redundancy_disabled_camera_failure_more_restrictive(self):
        cfg = FailSafeConfig(
            failure_confirmation_cycles=1,
            camera_lidar_redundancy=False,
        )
        engine = FailSafeEngine(config=cfg)
        d = engine.evaluate(
            timestamp=TS,
            camera_health_state="OFFLINE",
            lidar_health_state="ONLINE",
            lidar_frame_age_s=0.05,
            lidar_confidence=0.99,
            vehicle_state_health_state="ONLINE", vehicle_state_frame_age_s=0.05, vehicle_state_is_valid=True,
            **healthy_subsystems(),
        )
        # With redundancy disabled, camera failure still marks OBJECT_DETECTION
        assert SystemCapability.OBJECT_DETECTION in d.affected_capabilities


# ===========================================================================
# 11. Recovery
# ===========================================================================

class TestRecovery:
    def test_recovery_requires_multiple_healthy_cycles(self):
        cfg = FailSafeConfig(
            failure_confirmation_cycles=1,
            recovery_confirmation_cycles=3,
        )
        engine = FailSafeEngine(config=cfg)

        # Cause failure
        for _ in range(2):
            engine.evaluate(
                timestamp=TS,
                camera_health_state="OFFLINE",
                camera_frame_age_s=5.0,
                lidar_health_state="ONLINE", lidar_frame_age_s=0.05, lidar_confidence=0.99,
                vehicle_state_health_state="ONLINE", vehicle_state_frame_age_s=0.05, vehicle_state_is_valid=True,
                **healthy_subsystems(),
            )

        # One healthy cycle — still in recovery
        d1 = engine.evaluate(
            timestamp=TS + 1.0,
            camera_health_state="ONLINE",
            camera_frame_age_s=0.05,
            camera_confidence=0.95,
            lidar_health_state="ONLINE", lidar_frame_age_s=0.05, lidar_confidence=0.99,
            vehicle_state_health_state="ONLINE", vehicle_state_frame_age_s=0.05, vehicle_state_is_valid=True,
            **healthy_subsystems(TS + 1.0),
        )
        cam_evts = [e for e in d1.active_sensor_failures if e.sensor_type == FailSafeSensorType.CAMERA]
        if cam_evts:
            assert cam_evts[0].recovery_status in (
                RecoveryStatus.RECOVERY_PENDING,
                RecoveryStatus.RECOVERY_VALIDATING,
            )

    def test_recovery_blocked_by_emergency(self):
        cfg = FailSafeConfig(failure_confirmation_cycles=1, recovery_confirmation_cycles=2)
        engine = FailSafeEngine(config=cfg)

        # Cause failure
        engine.evaluate(timestamp=TS, camera_health_state="OFFLINE", camera_frame_age_s=5.0,
            lidar_health_state="ONLINE", lidar_frame_age_s=0.05, lidar_confidence=0.99,
            vehicle_state_health_state="ONLINE", vehicle_state_frame_age_s=0.05, vehicle_state_is_valid=True,
            **healthy_subsystems())

        # Try to recover with emergency active
        d = engine.evaluate(
            timestamp=TS + 1.0,
            camera_health_state="ONLINE",
            camera_frame_age_s=0.05,
            camera_confidence=0.95,
            lidar_health_state="ONLINE", lidar_frame_age_s=0.05, lidar_confidence=0.99,
            vehicle_state_health_state="ONLINE", vehicle_state_frame_age_s=0.05, vehicle_state_is_valid=True,
            emergency_active=True,
            **healthy_subsystems(TS + 1.0),
        )
        cam_evts = [e for e in d.active_sensor_failures if e.sensor_type == FailSafeSensorType.CAMERA]
        if cam_evts:
            assert cam_evts[0].recovery_status == RecoveryStatus.RECOVERY_BLOCKED

    def test_recovery_blocked_by_supervisor(self):
        cfg = FailSafeConfig(failure_confirmation_cycles=1, recovery_confirmation_cycles=2)
        engine = FailSafeEngine(config=cfg)

        engine.evaluate(timestamp=TS, camera_health_state="OFFLINE", camera_frame_age_s=5.0,
            lidar_health_state="ONLINE", lidar_frame_age_s=0.05, lidar_confidence=0.99,
            vehicle_state_health_state="ONLINE", vehicle_state_frame_age_s=0.05, vehicle_state_is_valid=True,
            **healthy_subsystems())
        d = engine.evaluate(
            timestamp=TS + 1.0,
            camera_health_state="ONLINE",
            camera_frame_age_s=0.05,
            camera_confidence=0.95,
            lidar_health_state="ONLINE", lidar_frame_age_s=0.05, lidar_confidence=0.99,
            vehicle_state_health_state="ONLINE", vehicle_state_frame_age_s=0.05, vehicle_state_is_valid=True,
            supervisor_permits_recovery=False,
            **healthy_subsystems(TS + 1.0),
        )
        cam_evts = [e for e in d.active_sensor_failures if e.sensor_type == FailSafeSensorType.CAMERA]
        if cam_evts:
            assert cam_evts[0].recovery_status == RecoveryStatus.RECOVERY_BLOCKED

    def test_successful_recovery_clears_failure(self):
        cfg = FailSafeConfig(failure_confirmation_cycles=1, recovery_confirmation_cycles=2)
        engine = FailSafeEngine(config=cfg)

        # Cause failure
        ctx = dict(lidar_health_state="ONLINE", lidar_frame_age_s=0.05, lidar_confidence=0.99,
            vehicle_state_health_state="ONLINE", vehicle_state_frame_age_s=0.05, vehicle_state_is_valid=True)
        engine.evaluate(timestamp=TS, camera_health_state="OFFLINE", camera_frame_age_s=5.0,
            **ctx, **healthy_subsystems())
        engine.evaluate(timestamp=TS + 0.1, camera_health_state="OFFLINE", camera_frame_age_s=4.9,
            **ctx, **healthy_subsystems(TS + 0.1))

        # Two clean cycles
        engine.evaluate(
            timestamp=TS + 1.0,
            camera_health_state="ONLINE",
            camera_frame_age_s=0.05,
            camera_confidence=0.95,
            **ctx, **healthy_subsystems(TS + 1.0),
        )
        d = engine.evaluate(
            timestamp=TS + 2.0,
            camera_health_state="ONLINE",
            camera_frame_age_s=0.05,
            camera_confidence=0.95,
            **ctx, **healthy_subsystems(TS + 2.0),
        )
        # After recovery, camera should have RECOVERY_CONFIRMED or no event
        cam_evts = [e for e in d.active_sensor_failures if e.sensor_type == FailSafeSensorType.CAMERA]
        if cam_evts:
            assert cam_evts[0].recovery_status == RecoveryStatus.RECOVERY_CONFIRMED
        else:
            # Fully cleared — no event at all is also valid
            pass


# ===========================================================================
# 12. Hysteresis
# ===========================================================================

class TestHysteresis:
    def test_failure_requires_confirmation_cycles(self):
        cfg = FailSafeConfig(failure_confirmation_cycles=3, recovery_confirmation_cycles=2)
        engine = FailSafeEngine(config=cfg)

        # First "bad" cycle — should not yet be confirmed failure
        d = engine.evaluate(
            timestamp=TS,
            camera_health_state="OFFLINE",
            camera_frame_age_s=5.0,
        )
        cam_evts = [e for e in d.active_sensor_failures if e.sensor_type == FailSafeSensorType.CAMERA]
        # May produce an event but it shouldn't be fully confirmed yet
        # (recovery manager requires 3 cycles)
        if cam_evts:
            assert cam_evts[0].recovery_status in (
                RecoveryStatus.NOT_REQUIRED,
                RecoveryStatus.RECOVERY_PENDING,
            )

    def test_noisy_health_signal_debounced(self):
        cfg = FailSafeConfig(failure_confirmation_cycles=3, recovery_confirmation_cycles=3)
        rm = RecoveryManager(cfg)

        # Oscillating signal
        for i in range(6):
            if i % 2 == 0:
                rm.record_failure("camera", float(i))
            else:
                rm.record_healthy("camera", float(i))

        # Should not have confirmed recovery (never got 3 consecutive healthy)
        assert not (rm.get_status("camera") == RecoveryStatus.RECOVERY_CONFIRMED)

    def test_recovery_requires_consecutive_cycles(self):
        cfg = FailSafeConfig(failure_confirmation_cycles=1, recovery_confirmation_cycles=4)
        rm = RecoveryManager(cfg)

        rm.record_failure("cam", 1.0)
        rm.record_failure("cam", 2.0)
        rm.record_healthy("cam", 3.0)
        rm.record_healthy("cam", 4.0)
        rm.record_failure("cam", 5.0)  # interruption
        rm.record_healthy("cam", 6.0)

        # Reset by failure — should still be active
        assert rm.is_active_failure("cam")
        # Not yet confirmed recovered
        assert rm.get_status("cam") != RecoveryStatus.RECOVERY_CONFIRMED


# ===========================================================================
# 13. Multiple simultaneous failures
# ===========================================================================

class TestMultipleFailures:
    def test_all_active_failures_preserved(self):
        engine = default_engine()
        d = engine.evaluate(
            timestamp=TS,
            camera_health_state="OFFLINE",
            lidar_health_state="OFFLINE",
            vehicle_state_health_state="OFFLINE",
            vehicle_state_frame_age_s=5.0,
            perception_status=None,
            perception_timestamp=0.0,
            fusion_status="INVALID",
            fusion_timestamp=TS - 0.1,
            prediction_status="OK", prediction_confidence=0.9, prediction_timestamp=TS-0.1,
            road_understanding_status="OK", road_understanding_timestamp=TS-0.1,
            world_model_valid=True, world_model_timestamp=TS-0.1, world_model_confidence=0.9,
            planning_status="OK", planning_timestamp=TS-0.1,
            tracking_status="OK", tracking_timestamp=TS-0.1,
            mpc_status="OK", mpc_timestamp=TS-0.1,
            control_status="OK", control_timestamp=TS-0.1,
            safety_monitor_state="SAFE", safety_monitor_timestamp=TS-0.1, safety_monitor_confidence=0.95,
            emergency_detection_state="NO_EMERGENCY", emergency_detection_timestamp=TS-0.1,
            safety_supervisor_state="NORMAL_CONTROL", safety_supervisor_timestamp=TS-0.1,
        )
        sensor_types = {e.sensor_type for e in d.active_sensor_failures}
        sub_types = {e.subsystem for e in d.active_subsystem_failures}

        assert FailSafeSensorType.CAMERA in sensor_types
        assert FailSafeSensorType.LIDAR in sensor_types
        assert FailSafeSensorType.VEHICLE_STATE in sensor_types
        assert FailSafeSubsystemType.PERCEPTION in sub_types
        assert FailSafeSubsystemType.FUSION in sub_types

    def test_dominant_failure_is_most_severe(self):
        engine = default_engine()
        d = engine.evaluate(
            timestamp=TS,
            camera_health_state="DEGRADED",
            camera_confidence=0.2,
            camera_frame_age_s=0.05,
            lidar_health_state="ONLINE", lidar_frame_age_s=0.05, lidar_confidence=0.95,
            vehicle_state_health_state="OFFLINE",
            vehicle_state_frame_age_s=5.0,
            **healthy_subsystems(),
        )
        # CRITICAL vehicle state should dominate
        assert d.severity == FailureSeverity.CRITICAL.value


# ===========================================================================
# 14. Capability propagation
# ===========================================================================

class TestCapabilityPropagation:
    def test_only_affected_caps_degraded(self):
        engine = default_engine()
        d = engine.evaluate(
            timestamp=TS,
            camera_health_state="OFFLINE",
            camera_frame_age_s=5.0,
            lidar_health_state="ONLINE",
            lidar_frame_age_s=0.05,
            lidar_confidence=0.99,
            vehicle_state_health_state="ONLINE", vehicle_state_frame_age_s=0.05, vehicle_state_is_valid=True,
            **healthy_subsystems(),
        )
        # LANE_ESTIMATION affected (camera)
        assert SystemCapability.LANE_ESTIMATION in d.affected_capabilities
        # DEPTH_ESTIMATION NOT affected (lidar is healthy)
        assert SystemCapability.DEPTH_ESTIMATION not in d.affected_capabilities

    def test_lidar_failure_not_affect_lane_estimation(self):
        engine = default_engine()
        d = engine.evaluate(
            timestamp=TS,
            camera_health_state="ONLINE",
            camera_frame_age_s=0.05,
            camera_confidence=0.95,
            lidar_health_state="OFFLINE",
            lidar_frame_age_s=5.0,
            vehicle_state_health_state="ONLINE", vehicle_state_frame_age_s=0.05, vehicle_state_is_valid=True,
            **healthy_subsystems(),
        )
        assert SystemCapability.LANE_ESTIMATION not in d.affected_capabilities

    def test_correlated_failure_propagates_correctly(self):
        engine = default_engine()
        d = engine.evaluate(
            timestamp=TS,
            fusion_status="INVALID",
            fusion_timestamp=TS - 0.1,
            **healthy_sensors(),
            perception_status="OK", perception_confidence=0.9, perception_timestamp=TS-0.1,
            prediction_status="OK", prediction_confidence=0.9, prediction_timestamp=TS-0.1,
            road_understanding_status="OK", road_understanding_timestamp=TS-0.1,
            world_model_valid=True, world_model_timestamp=TS-0.1, world_model_confidence=0.9,
            planning_status="OK", planning_timestamp=TS-0.1,
            tracking_status="OK", tracking_timestamp=TS-0.1,
            mpc_status="OK", mpc_timestamp=TS-0.1,
            control_status="OK", control_timestamp=TS-0.1,
            safety_monitor_state="SAFE", safety_monitor_timestamp=TS-0.1, safety_monitor_confidence=0.95,
            emergency_detection_state="NO_EMERGENCY", emergency_detection_timestamp=TS-0.1,
            safety_supervisor_state="NORMAL_CONTROL", safety_supervisor_timestamp=TS-0.1,
        )
        assert SystemCapability.WORLD_MODEL_VALIDITY in d.affected_capabilities
        assert SystemCapability.COLLISION_RISK_ESTIMATION in d.affected_capabilities
        assert SystemCapability.LANE_ESTIMATION not in d.affected_capabilities


# ===========================================================================
# 15. Snapshot
# ===========================================================================

class TestSnapshot:
    def test_snapshot_is_immutable(self):
        engine = default_engine()
        healthy_eval(engine)
        snap = engine.last_snapshot()
        assert snap is not None
        # Frozen dataclass — cannot assign attributes
        with pytest.raises((AttributeError, TypeError)):
            snap.fail_safe_state = FailSafeState.CONTROL_WITHHELD  # type: ignore[misc]

    def test_snapshot_state_mirrors_decision(self):
        engine = default_engine()
        d = healthy_eval(engine)
        snap = engine.last_snapshot()
        assert snap is not None
        assert snap.fail_safe_state == d.fail_safe_state
        assert snap.control_withheld == d.control_withheld

    def test_snapshot_affected_caps_sorted(self):
        engine = default_engine()
        engine.evaluate(
            timestamp=TS,
            camera_health_state="OFFLINE",
            lidar_health_state="OFFLINE",
            vehicle_state_health_state="ONLINE", vehicle_state_frame_age_s=0.05, vehicle_state_is_valid=True,
            **healthy_subsystems(),
        )
        snap = engine.last_snapshot()
        assert snap is not None
        caps = list(snap.affected_capabilities)
        assert caps == sorted(caps, key=lambda c: c.value)


# ===========================================================================
# 16. Validator
# ===========================================================================

class TestValidator:
    def test_valid_healthy_decision_passes(self):
        engine = default_engine()
        d = healthy_eval(engine)
        v = FailSafeValidator()
        ok, reason = v.validate_decision(d)
        assert ok, reason

    def test_none_decision_fails(self):
        v = FailSafeValidator()
        ok, _ = v.validate_decision(None)
        assert not ok

    def test_wrong_schema_version_fails(self):
        from core.failsafe.failsafe_types import FailSafeDecision as FSDecision
        bad = FSDecision(schema_version="0.0", timestamp=1.0)
        v = FailSafeValidator()
        ok, _ = v.validate_decision(bad)
        assert not ok

    def test_negative_timestamp_fails(self):
        from core.failsafe.failsafe_types import FailSafeDecision as FSDecision, FAILSAFE_SCHEMA_VERSION
        bad = FSDecision(schema_version=FAILSAFE_SCHEMA_VERSION, timestamp=-1.0)
        v = FailSafeValidator()
        ok, _ = v.validate_decision(bad)
        assert not ok

    def test_control_withheld_inconsistency_fails(self):
        from core.failsafe.failsafe_types import FailSafeDecision as FSDecision, FAILSAFE_SCHEMA_VERSION
        bad = FSDecision(
            schema_version=FAILSAFE_SCHEMA_VERSION,
            timestamp=1.0,
            fail_safe_state=FailSafeState.CONTROL_WITHHELD,
            control_withheld=False,  # inconsistent
        )
        v = FailSafeValidator()
        ok, _ = v.validate_decision(bad)
        assert not ok

    def test_normal_with_stale_fails(self):
        from core.failsafe.failsafe_types import FailSafeDecision as FSDecision, FAILSAFE_SCHEMA_VERSION
        bad = FSDecision(
            schema_version=FAILSAFE_SCHEMA_VERSION,
            timestamp=1.0,
            fail_safe_state=FailSafeState.NORMAL_OPERATION,
            control_withheld=False,
            control_restriction=False,
            stale=True,  # inconsistent
        )
        v = FailSafeValidator()
        ok, _ = v.validate_decision(bad)
        assert not ok

    def test_confidence_out_of_range_fails(self):
        from core.failsafe.failsafe_types import FailSafeDecision as FSDecision, FAILSAFE_SCHEMA_VERSION
        bad = FSDecision(
            schema_version=FAILSAFE_SCHEMA_VERSION,
            timestamp=1.0,
            fail_safe_state=FailSafeState.NORMAL_OPERATION,
            confidence=1.5,  # out of range
        )
        v = FailSafeValidator()
        ok, _ = v.validate_decision(bad)
        assert not ok


# ===========================================================================
# 17. Determinism
# ===========================================================================

class TestDeterminism:
    def test_same_input_same_decision(self):
        """Identical inputs must produce identical decisions."""
        def make_decision():
            engine = default_engine()
            return engine.evaluate(
                timestamp=TS,
                camera_health_state="OFFLINE",
                lidar_health_state="ONLINE",
                lidar_frame_age_s=0.05,
                lidar_confidence=0.9,
                vehicle_state_health_state="ONLINE",
                vehicle_state_frame_age_s=0.05,
                vehicle_state_is_valid=True,
                **healthy_subsystems(),
            )

        d1 = make_decision()
        d2 = make_decision()
        assert d1.fail_safe_state == d2.fail_safe_state
        assert d1.control_withheld == d2.control_withheld
        assert d1.severity == d2.severity
        assert d1.decision_id == d2.decision_id


# ===========================================================================
# 18. Thread safety
# ===========================================================================

class TestThreadSafety:
    def test_concurrent_evaluations_no_crash(self):
        engine = default_engine()
        errors = []

        def worker():
            try:
                for i in range(20):
                    ts_i = TS + i * 0.1
                    engine.evaluate(
                        timestamp=ts_i,
                        camera_health_state="ONLINE" if i % 3 != 0 else "OFFLINE",
                        camera_frame_age_s=0.05,
                        lidar_health_state="ONLINE",
                        lidar_frame_age_s=0.05,
                        lidar_confidence=0.99,
                        vehicle_state_health_state="ONLINE",
                        vehicle_state_frame_age_s=0.05,
                        vehicle_state_is_valid=True,
                        **healthy_subsystems(ts_i),
                    )
            except Exception as e:
                errors.append(e)

        threads = [threading.Thread(target=worker) for _ in range(4)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        assert not errors, f"Thread safety error: {errors[0]}"

    def test_recovery_manager_concurrent_access(self):
        cfg = FailSafeConfig(failure_confirmation_cycles=1, recovery_confirmation_cycles=2)
        rm = RecoveryManager(cfg)
        errors = []

        def worker():
            try:
                for i in range(50):
                    rm.record_failure("cam", float(i))
                    rm.record_healthy("cam", float(i) + 0.5)
                    rm.get_status("cam")
            except Exception as e:
                errors.append(e)

        threads = [threading.Thread(target=worker) for _ in range(4)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()
        assert not errors


# ===========================================================================
# 19. Negative scope
# ===========================================================================

class TestNegativeScope:
    """Phase 11.4 must NOT implement any of these."""

    def test_no_actuator_commands_in_decision(self):
        engine = default_engine()
        d = healthy_eval(engine)
        assert not hasattr(d, "steering_command")
        assert not hasattr(d, "brake_command")
        assert not hasattr(d, "throttle_command")

    def test_no_can_access(self):
        import core.failsafe.failsafe_engine as fe
        src = open(fe.__file__).read()
        assert "CAN" not in src or "# CAN" in src or "\"CAN\"" not in src.replace("# CAN", "")
        # More specific: no CAN bus library imports
        assert "can.Bus" not in src
        assert "canlib" not in src

    def test_no_planner_implementation(self):
        import core.failsafe.failsafe_engine as fe
        src = open(fe.__file__).read()
        # Should not implement path generation
        assert "generate_path" not in src
        assert "A_star" not in src
        assert "RRT" not in src

    def test_no_mpc_implementation(self):
        import core.failsafe.failsafe_engine as fe
        src = open(fe.__file__).read()
        assert "scipy.optimize" not in src
        assert "casadi" not in src

    def test_no_llm_or_cloud_calls(self):
        import core.failsafe.failsafe_engine as fe
        src = open(fe.__file__).read()
        assert "openai" not in src
        assert "anthropic" not in src
        assert "requests.get" not in src
        assert "urllib.request" not in src

    def test_engine_does_not_restart_sensors(self):
        """Ensure engine has no hardware restart logic."""
        import core.failsafe.failsafe_engine as fe
        src = open(fe.__file__).read()
        assert "subprocess" not in src
        assert "os.system" not in src
        assert "systemctl" not in src

    def test_no_perception_implementation(self):
        import core.failsafe.failsafe_engine as fe
        src = open(fe.__file__).read()
        assert "object_detection" not in src.lower().replace("object_detection", "MARKER")
        # Check the engine does not call YOLO or any detector
        assert "yolo" not in src.lower()
        assert "detectron" not in src.lower()


# ===========================================================================
# 20. Phase 11.3 integration
# ===========================================================================

class TestPhase113Integration:
    """
    Verify that FailSafeDecision carries the information the Safety Supervisor
    (Phase 11.3) needs, and that the fail-safe state correctly informs
    downstream control authority decisions.
    """

    def test_healthy_supplies_normal_to_supervisor(self):
        engine = default_engine()
        d = healthy_eval(engine)
        assert d.fail_safe_state == FailSafeState.NORMAL_OPERATION
        assert not d.control_withheld
        assert not d.control_restriction

    def test_camera_degraded_supplies_degraded_info(self):
        engine = default_engine()
        d = engine.evaluate(
            timestamp=TS,
            camera_health_state="DEGRADED",
            camera_confidence=0.15,
            camera_frame_age_s=0.05,
            lidar_health_state="ONLINE",
            lidar_frame_age_s=0.05,
            lidar_confidence=0.99,
            vehicle_state_health_state="ONLINE", vehicle_state_frame_age_s=0.05, vehicle_state_is_valid=True,
            **healthy_subsystems(),
        )
        # Degraded but not withheld
        assert d.fail_safe_state not in (FailSafeState.NORMAL_OPERATION,)
        assert not d.control_withheld

    def test_critical_sensor_loss_withheld_for_supervisor(self):
        engine = default_engine()
        d = engine.evaluate(
            timestamp=TS,
            camera_health_state="ONLINE", camera_frame_age_s=0.05, camera_confidence=0.95,
            lidar_health_state="ONLINE", lidar_frame_age_s=0.05, lidar_confidence=0.95,
            vehicle_state_health_state="OFFLINE",
            vehicle_state_frame_age_s=5.0,
            **healthy_subsystems(),
        )
        assert d.control_withheld
        assert d.fail_safe_state in (
            FailSafeState.CONTROL_WITHHELD,
            FailSafeState.FAIL_SAFE_ACTIVE,
        )

    def test_multiple_critical_withheld_for_supervisor(self):
        engine = default_engine()
        d = engine.evaluate(
            timestamp=TS,
            camera_health_state="OFFLINE",
            lidar_health_state="OFFLINE",
            vehicle_state_health_state="OFFLINE",
            vehicle_state_frame_age_s=5.0,
            **healthy_subsystems(),
        )
        assert d.control_withheld

    def test_recovery_pending_communicated_to_supervisor(self):
        cfg = FailSafeConfig(failure_confirmation_cycles=1, recovery_confirmation_cycles=3)
        engine = FailSafeEngine(config=cfg)

        engine.evaluate(timestamp=TS, camera_health_state="OFFLINE", camera_frame_age_s=5.0,
            lidar_health_state="ONLINE", lidar_frame_age_s=0.05, lidar_confidence=0.99,
            vehicle_state_health_state="ONLINE", vehicle_state_frame_age_s=0.05, vehicle_state_is_valid=True,
            **healthy_subsystems())
        d = engine.evaluate(
            timestamp=TS + 1.0,
            camera_health_state="ONLINE",
            camera_frame_age_s=0.05,
            camera_confidence=0.95,
            lidar_health_state="ONLINE", lidar_frame_age_s=0.05, lidar_confidence=0.99,
            vehicle_state_health_state="ONLINE", vehicle_state_frame_age_s=0.05, vehicle_state_is_valid=True,
            **healthy_subsystems(TS + 1.0),
        )
        # Decision should communicate recovery is in progress
        cam_evts = [e for e in d.active_sensor_failures if e.sensor_type == FailSafeSensorType.CAMERA]
        if cam_evts:
            assert cam_evts[0].recovery_status in (
                RecoveryStatus.RECOVERY_PENDING,
                RecoveryStatus.RECOVERY_VALIDATING,
            )

    def test_failsafe_decision_has_schema_version(self):
        engine = default_engine()
        d = healthy_eval(engine)
        assert d.schema_version == "11.4"


    def test_failsafe_decision_not_directly_actuating(self):
        engine = default_engine()
        d = engine.evaluate(
            timestamp=TS,
            camera_health_state="OFFLINE",
            lidar_health_state="ONLINE", lidar_frame_age_s=0.05, lidar_confidence=0.95,
            vehicle_state_health_state="OFFLINE",
            vehicle_state_frame_age_s=5.0,
            **healthy_subsystems(),
        )
        # Decision must not contain actuator-facing fields
        assert not hasattr(d, "steering")
        assert not hasattr(d, "throttle")
        assert not hasattr(d, "brake")
        assert not hasattr(d, "can_message")
        assert not hasattr(d, "ecu_command")


# ===========================================================================
# 21. translate_sensor_health unit tests
# ===========================================================================

class TestTranslateSensorHealth:
    def test_online_young_healthy(self):
        cfg = FailSafeConfig()
        result = translate_sensor_health("ONLINE", 0.05, 0.95, cfg)
        assert result == SensorHealthSummary.HEALTHY

    def test_offline_unavailable(self):
        cfg = FailSafeConfig()
        result = translate_sensor_health("OFFLINE", 5.0, 1.0, cfg)
        assert result == SensorHealthSummary.UNAVAILABLE

    def test_not_configured_unavailable(self):
        cfg = FailSafeConfig()
        result = translate_sensor_health("NOT_CONFIGURED", None, 1.0, cfg)
        assert result == SensorHealthSummary.UNAVAILABLE

    def test_degraded_returns_degraded(self):
        cfg = FailSafeConfig()
        result = translate_sensor_health("DEGRADED", 0.05, 0.5, cfg)
        assert result == SensorHealthSummary.DEGRADED

    def test_online_low_confidence_degraded(self):
        cfg = FailSafeConfig(low_confidence_threshold=0.3)
        result = translate_sensor_health("ONLINE", 0.05, 0.1, cfg)
        assert result == SensorHealthSummary.DEGRADED

    def test_none_frame_age_unavailable(self):
        cfg = FailSafeConfig()
        result = translate_sensor_health("ONLINE", None, 1.0, cfg)
        assert result == SensorHealthSummary.UNAVAILABLE
