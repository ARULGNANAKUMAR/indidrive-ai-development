"""
IndiDrive AI — Phase 11.4 | Fail-Safe ↔ Safety Supervisor Integration Tests
=============================================================================
Verifies that Phase 11.4 (FailSafeEngine) correctly feeds structured
fail-safe information into Phase 11.3 (SafetySupervisor), and that the
combined decision is never less restrictive than either component alone.

Covers:
  - Healthy: fail-safe does not restrict supervisor unnecessarily
  - Fail-safe withheld → supervisor CONTROL_WITHHELD regardless of 11.1/11.2
  - Fail-safe restricted → supervisor at least as restrictive
  - Fail-safe degraded → supervisor reflects degraded state
  - Fail-safe recovery → communicated via reason codes
  - Multiple simultaneous fail-safe failures
  - evaluate_with_failsafe(None) == evaluate_with_snapshot()
  - Decision is never LESS restrictive after fail-safe injection
  - Supervisor existing methods are not broken
  - Bridge translation correctness
  - Determinism of merged decisions
  - fail-safe withheld always propagates (never relaxed by supervisor)
"""
from __future__ import annotations

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..'))

from core.failsafe import FailSafeEngine, FailSafeConfig, FailSafeState
from core.failsafe.failsafe_supervisor_bridge import (
    FailSafeBridgeResult,
    translate_failsafe_to_supervisor,
)
from core.safety_supervisor.supervisor_engine import SafetySupervisor
from core.safety_supervisor.supervisor_types import ControlAuthority

TS = 100.0

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

AUTHORITY_RESTRICTIVENESS_ORDER = [
    ControlAuthority.CONTROL_WITHHELD,
    ControlAuthority.OVERRIDE_REQUIRED,
    ControlAuthority.SAFETY_CONTROL_REQUIRED,
    ControlAuthority.RESTRICTED_CONTROL,
    ControlAuthority.DEGRADED_CONTROL,
    ControlAuthority.LIMITED_CONTROL,
    ControlAuthority.NORMAL_CONTROL,
    ControlAuthority.UNKNOWN_CONTROL_AUTHORITY,
]


def restrictiveness_rank(auth: ControlAuthority) -> int:
    """Lower = more restrictive."""
    try:
        return AUTHORITY_RESTRICTIVENESS_ORDER.index(auth)
    except ValueError:
        return len(AUTHORITY_RESTRICTIVENESS_ORDER)


def default_fs_engine() -> FailSafeEngine:
    return FailSafeEngine(config=FailSafeConfig(failure_confirmation_cycles=1))


def default_supervisor() -> SafetySupervisor:
    return SafetySupervisor()


def healthy_subsystems(ts: float = TS) -> dict:
    return dict(
        perception_status="OK", perception_confidence=0.9, perception_timestamp=ts - 0.1,
        fusion_status="OK", fusion_confidence=0.9, fusion_timestamp=ts - 0.1,
        prediction_status="OK", prediction_confidence=0.9, prediction_timestamp=ts - 0.1,
        road_understanding_status="OK", road_understanding_timestamp=ts - 0.1,
        world_model_valid=True, world_model_timestamp=ts - 0.1, world_model_confidence=0.9,
        planning_status="OK", planning_timestamp=ts - 0.1,
        tracking_status="OK", tracking_timestamp=ts - 0.1,
        mpc_status="OK", mpc_timestamp=ts - 0.1,
        control_status="OK", control_timestamp=ts - 0.1,
        safety_monitor_state="SAFE", safety_monitor_timestamp=ts - 0.1,
        safety_monitor_confidence=0.95,
        emergency_detection_state="NO_EMERGENCY", emergency_detection_timestamp=ts - 0.1,
        safety_supervisor_state="NORMAL_CONTROL", safety_supervisor_timestamp=ts - 0.1,
    )


def healthy_sensors(ts: float = TS) -> dict:
    return dict(
        camera_health_state="ONLINE", camera_frame_age_s=0.05, camera_confidence=0.95,
        lidar_health_state="ONLINE", lidar_frame_age_s=0.05, lidar_confidence=0.95,
        vehicle_state_health_state="ONLINE", vehicle_state_frame_age_s=0.05,
        vehicle_state_confidence=0.99, vehicle_state_is_valid=True,
    )


def healthy_fs_decision(ts: float = TS):
    e = default_fs_engine()
    return e.evaluate(timestamp=ts, **healthy_sensors(ts), **healthy_subsystems(ts))


def vs_failed_fs_decision(ts: float = TS):
    """Vehicle-state failure → fail-safe withheld."""
    e = default_fs_engine()
    return e.evaluate(
        timestamp=ts,
        camera_health_state="ONLINE", camera_frame_age_s=0.05, camera_confidence=0.95,
        lidar_health_state="ONLINE", lidar_frame_age_s=0.05, lidar_confidence=0.95,
        vehicle_state_health_state="OFFLINE", vehicle_state_frame_age_s=5.0,
        **healthy_subsystems(ts),
    )


def camera_failed_fs_decision(ts: float = TS):
    """Camera failure + lidar healthy → fail-safe restricted (not withheld)."""
    e = default_fs_engine()
    return e.evaluate(
        timestamp=ts,
        camera_health_state="OFFLINE", camera_frame_age_s=5.0,
        lidar_health_state="ONLINE", lidar_frame_age_s=0.05, lidar_confidence=0.99,
        vehicle_state_health_state="ONLINE", vehicle_state_frame_age_s=0.05,
        vehicle_state_is_valid=True,
        **healthy_subsystems(ts),
    )


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

class TestBridgeTranslation:
    """Unit tests for translate_failsafe_to_supervisor()."""

    def test_healthy_maps_to_normal_control(self):
        d = healthy_fs_decision()
        b = translate_failsafe_to_supervisor(d)
        assert b.authority == ControlAuthority.NORMAL_CONTROL

    def test_healthy_has_no_reasons(self):
        d = healthy_fs_decision()
        b = translate_failsafe_to_supervisor(d)
        assert len(b.reasons) == 0

    def test_withheld_maps_to_control_withheld(self):
        d = vs_failed_fs_decision()
        assert d.control_withheld
        b = translate_failsafe_to_supervisor(d)
        assert b.authority == ControlAuthority.CONTROL_WITHHELD

    def test_withheld_has_critical_reason(self):
        d = vs_failed_fs_decision()
        b = translate_failsafe_to_supervisor(d)
        from core.safety_supervisor.supervisor_types import OverrideReason
        assert OverrideReason.SYSTEM_CRITICAL_FAILURE in b.reasons

    def test_restricted_maps_to_restricted_control(self):
        d = camera_failed_fs_decision()
        assert not d.control_withheld
        b = translate_failsafe_to_supervisor(d)
        assert b.authority in (
            ControlAuthority.RESTRICTED_CONTROL,
            ControlAuthority.LIMITED_CONTROL,
            ControlAuthority.DEGRADED_CONTROL,
        )

    def test_unknown_state_maps_to_restrictive_authority(self):
        # UNKNOWN_FAIL_SAFE_STATE + control_withheld=True -> CONTROL_WITHHELD
        # (more conservative than UNKNOWN_CONTROL_AUTHORITY)
        e = default_fs_engine()
        d = e.evaluate(timestamp=float("nan"))
        b = translate_failsafe_to_supervisor(d)
        assert b.authority in (
            ControlAuthority.UNKNOWN_CONTROL_AUTHORITY,
            ControlAuthority.CONTROL_WITHHELD,
        ), f"Expected restrictive authority, got {b.authority}"

    def test_bridge_result_is_frozen(self):
        d = healthy_fs_decision()
        b = translate_failsafe_to_supervisor(d)
        try:
            b.authority = ControlAuthority.CONTROL_WITHHELD  # type: ignore[misc]
            assert False, "Should have raised"
        except (AttributeError, TypeError):
            pass

    def test_stale_propagated_from_decision(self):
        e = default_fs_engine()
        d = e.evaluate(timestamp=float("nan"))
        b = translate_failsafe_to_supervisor(d)
        assert b.stale

    def test_degraded_propagated(self):
        e = default_fs_engine()
        d = e.evaluate(
            timestamp=TS,
            camera_health_state="DEGRADED", camera_confidence=0.15,
            camera_frame_age_s=0.05,
            lidar_health_state="ONLINE", lidar_frame_age_s=0.05, lidar_confidence=0.99,
            vehicle_state_health_state="ONLINE", vehicle_state_frame_age_s=0.05,
            vehicle_state_is_valid=True,
            **healthy_subsystems(),
        )
        b = translate_failsafe_to_supervisor(d)
        if d.degraded:
            assert b.degraded

    def test_recovery_reason_included(self):
        from core.failsafe.failsafe_types import RecoveryStatus
        from core.safety_supervisor.supervisor_types import OverrideReason
        # Force a recovery_status in the decision via the recovery manager path
        cfg = FailSafeConfig(failure_confirmation_cycles=1, recovery_confirmation_cycles=3)
        e = FailSafeEngine(config=cfg)
        # Cause failure then one healthy cycle
        e.evaluate(timestamp=TS,
            camera_health_state="OFFLINE", camera_frame_age_s=5.0,
            lidar_health_state="ONLINE", lidar_frame_age_s=0.05, lidar_confidence=0.99,
            vehicle_state_health_state="ONLINE", vehicle_state_frame_age_s=0.05,
            vehicle_state_is_valid=True, **healthy_subsystems())
        d = e.evaluate(timestamp=TS + 1.0,
            camera_health_state="ONLINE", camera_frame_age_s=0.05, camera_confidence=0.95,
            lidar_health_state="ONLINE", lidar_frame_age_s=0.05, lidar_confidence=0.99,
            vehicle_state_health_state="ONLINE", vehicle_state_frame_age_s=0.05,
            vehicle_state_is_valid=True, **healthy_subsystems(TS + 1.0))
        b = translate_failsafe_to_supervisor(d)
        cam_evts = [e2 for e2 in d.active_sensor_failures]
        if cam_evts:
            # Recovery in progress → bridge should include recovery reason
            assert OverrideReason.RECOVERY_IN_PROGRESS in b.reasons


class TestEvaluateWithFailsafe:
    """Integration tests for SafetySupervisor.evaluate_with_failsafe()."""

    def test_none_failsafe_equals_evaluate_with_snapshot(self):
        sup = default_supervisor()
        snap_none = sup.evaluate_with_failsafe(
            failsafe_decision=None, reference_timestamp=TS
        )
        snap_direct = sup.evaluate_with_snapshot(reference_timestamp=TS)
        assert snap_none.decision.control_authority == snap_direct.decision.control_authority

    def test_healthy_failsafe_does_not_restrict(self):
        sup = default_supervisor()
        d = healthy_fs_decision()
        snap = sup.evaluate_with_failsafe(failsafe_decision=d, reference_timestamp=TS)
        # With no Phase 11.1/11.2 input AND healthy fail-safe, authority should
        # not be MORE restrictive than with no fail-safe at all
        snap_base = sup.evaluate_with_snapshot(reference_timestamp=TS)
        assert restrictiveness_rank(snap.decision.control_authority) >= \
               restrictiveness_rank(snap_base.decision.control_authority)

    def test_withheld_failsafe_forces_control_withheld(self):
        sup = default_supervisor()
        d = vs_failed_fs_decision()
        assert d.control_withheld
        snap = sup.evaluate_with_failsafe(failsafe_decision=d, reference_timestamp=TS)
        assert snap.decision.control_authority == ControlAuthority.CONTROL_WITHHELD
        assert snap.decision.control_withheld

    def test_restricted_failsafe_at_least_as_restrictive(self):
        sup = default_supervisor()
        d = camera_failed_fs_decision()
        assert not d.control_withheld
        snap = sup.evaluate_with_failsafe(failsafe_decision=d, reference_timestamp=TS)
        snap_base = sup.evaluate_with_snapshot(reference_timestamp=TS)
        # merged must be at least as restrictive as base
        assert restrictiveness_rank(snap.decision.control_authority) <= \
               restrictiveness_rank(snap_base.decision.control_authority) + 1

    def test_failsafe_never_relaxes_supervisor(self):
        """
        Whatever the supervisor decides without fail-safe, adding a
        fail-safe decision must never produce a LESS restrictive result.
        """
        sup = default_supervisor()
        d = healthy_fs_decision()
        snap_base = sup.evaluate_with_snapshot(reference_timestamp=TS)
        snap_with = sup.evaluate_with_failsafe(failsafe_decision=d, reference_timestamp=TS)
        # merged authority must be >= (more or equally restrictive) than base
        assert restrictiveness_rank(snap_with.decision.control_authority) <= \
               restrictiveness_rank(snap_base.decision.control_authority) + 1

    def test_control_withheld_cannot_be_relaxed(self):
        """
        If fail-safe withholds, the final decision must have
        CONTROL_WITHHELD regardless of what 11.1/11.2 say.
        """
        sup = default_supervisor()
        d = vs_failed_fs_decision()
        assert d.control_withheld
        snap = sup.evaluate_with_failsafe(failsafe_decision=d, reference_timestamp=TS)
        assert snap.decision.control_authority == ControlAuthority.CONTROL_WITHHELD

    def test_reason_codes_include_failsafe_reasons(self):
        from core.safety_supervisor.supervisor_types import OverrideReason
        sup = default_supervisor()
        d = vs_failed_fs_decision()
        snap = sup.evaluate_with_failsafe(failsafe_decision=d, reference_timestamp=TS)
        assert OverrideReason.SYSTEM_CRITICAL_FAILURE.value in snap.decision.reason_codes

    def test_schema_version_preserved(self):
        sup = default_supervisor()
        d = healthy_fs_decision()
        snap = sup.evaluate_with_failsafe(failsafe_decision=d, reference_timestamp=TS)
        assert snap.schema_version == "11.3"
        assert snap.decision.schema_version == "11.3"

    def test_snapshot_is_frozen(self):
        sup = default_supervisor()
        d = healthy_fs_decision()
        snap = sup.evaluate_with_failsafe(failsafe_decision=d, reference_timestamp=TS)
        try:
            snap.decision = None  # type: ignore[misc]
            assert False, "Should have raised"
        except (AttributeError, TypeError):
            pass

    def test_multiple_failsafe_failures_withheld(self):
        """Multiple critical sensor failures → withheld at supervisor level."""
        sup = default_supervisor()
        e = default_fs_engine()
        d = e.evaluate(
            timestamp=TS,
            camera_health_state="OFFLINE", camera_frame_age_s=5.0,
            lidar_health_state="OFFLINE", lidar_frame_age_s=5.0,
            vehicle_state_health_state="OFFLINE", vehicle_state_frame_age_s=5.0,
            **healthy_subsystems(),
        )
        snap = sup.evaluate_with_failsafe(failsafe_decision=d, reference_timestamp=TS)
        assert snap.decision.control_authority == ControlAuthority.CONTROL_WITHHELD

    def test_failsafe_degraded_not_withheld(self):
        """Single sensor degraded but not unavailable → not withheld."""
        sup = default_supervisor()
        e = default_fs_engine()
        d = e.evaluate(
            timestamp=TS,
            camera_health_state="DEGRADED", camera_confidence=0.15,
            camera_frame_age_s=0.05,
            lidar_health_state="ONLINE", lidar_frame_age_s=0.05, lidar_confidence=0.99,
            vehicle_state_health_state="ONLINE", vehicle_state_frame_age_s=0.05,
            vehicle_state_is_valid=True,
            **healthy_subsystems(),
        )
        snap = sup.evaluate_with_failsafe(failsafe_decision=d, reference_timestamp=TS)
        assert snap.decision.control_authority != ControlAuthority.CONTROL_WITHHELD
        assert not snap.decision.control_withheld

    def test_existing_evaluate_unchanged(self):
        """evaluate() still works after adding evaluate_with_failsafe()."""
        sup = default_supervisor()
        decision = sup.evaluate(reference_timestamp=TS)
        assert decision is not None
        assert hasattr(decision, "control_authority")

    def test_existing_evaluate_with_snapshot_unchanged(self):
        """evaluate_with_snapshot() still works."""
        sup = default_supervisor()
        snap = sup.evaluate_with_snapshot(reference_timestamp=TS)
        assert snap is not None
        assert hasattr(snap.decision, "control_authority")

    def test_decision_id_includes_fs_marker(self):
        """When fail-safe modifies the decision, decision_id ends with ':fs'."""
        sup = default_supervisor()
        d = vs_failed_fs_decision()
        snap = sup.evaluate_with_failsafe(failsafe_decision=d, reference_timestamp=TS)
        assert snap.decision.decision_id.endswith(":fs")

    def test_determinism_merged_decision(self):
        """Same inputs → same merged decision ID and authority."""
        def run():
            sup = default_supervisor()
            e = default_fs_engine()
            d = e.evaluate(
                timestamp=TS,
                camera_health_state="OFFLINE", camera_frame_age_s=5.0,
                lidar_health_state="ONLINE", lidar_frame_age_s=0.05, lidar_confidence=0.99,
                vehicle_state_health_state="ONLINE", vehicle_state_frame_age_s=0.05,
                vehicle_state_is_valid=True,
                **healthy_subsystems(),
            )
            return sup.evaluate_with_failsafe(failsafe_decision=d, reference_timestamp=TS)

        s1, s2 = run(), run()
        assert s1.decision.control_authority == s2.decision.control_authority
        assert s1.decision.decision_id == s2.decision.decision_id

    def test_unknown_failsafe_maps_to_not_normal(self):
        """UNKNOWN_FAIL_SAFE_STATE from fail-safe → authority is not NORMAL_CONTROL."""
        sup = default_supervisor()
        e = default_fs_engine()
        d = e.evaluate(timestamp=float("nan"))
        snap = sup.evaluate_with_failsafe(failsafe_decision=d, reference_timestamp=TS)
        assert snap.decision.control_authority != ControlAuthority.NORMAL_CONTROL


class TestEndToEndPipeline:
    """
    End-to-end pipeline tests: FailSafeEngine → bridge → SafetySupervisor.
    Models the actual call sequence used in the integration pipeline.
    """

    def test_e2e_healthy(self):
        fs_engine = default_fs_engine()
        supervisor = default_supervisor()

        fs_decision = fs_engine.evaluate(timestamp=TS, **healthy_sensors(), **healthy_subsystems())
        snap = supervisor.evaluate_with_failsafe(
            failsafe_decision=fs_decision,
            reference_timestamp=TS,
        )
        # Both components healthy → supervisor is not withheld
        assert not snap.decision.control_withheld
        assert snap.decision.schema_version == "11.3"

    def test_e2e_vehicle_state_failure(self):
        fs_engine = default_fs_engine()
        supervisor = default_supervisor()

        fs_decision = fs_engine.evaluate(
            timestamp=TS,
            camera_health_state="ONLINE", camera_frame_age_s=0.05, camera_confidence=0.95,
            lidar_health_state="ONLINE", lidar_frame_age_s=0.05, lidar_confidence=0.95,
            vehicle_state_health_state="OFFLINE", vehicle_state_frame_age_s=5.0,
            **healthy_subsystems(),
        )
        assert fs_decision.control_withheld

        snap = supervisor.evaluate_with_failsafe(
            failsafe_decision=fs_decision,
            reference_timestamp=TS,
        )
        assert snap.decision.control_authority == ControlAuthority.CONTROL_WITHHELD
        assert snap.decision.control_withheld

    def test_e2e_perception_loss_restricted(self):
        """Full perception loss → at least RESTRICTED at supervisor."""
        fs_engine = default_fs_engine()
        supervisor = default_supervisor()

        fs_decision = fs_engine.evaluate(
            timestamp=TS,
            camera_health_state="OFFLINE", camera_frame_age_s=5.0,
            lidar_health_state="OFFLINE", lidar_frame_age_s=5.0,
            vehicle_state_health_state="ONLINE", vehicle_state_frame_age_s=0.05,
            vehicle_state_is_valid=True,
            **healthy_subsystems(),
        )
        snap = supervisor.evaluate_with_failsafe(
            failsafe_decision=fs_decision,
            reference_timestamp=TS,
        )
        restricted_or_worse = restrictiveness_rank(snap.decision.control_authority) <= \
                              restrictiveness_rank(ControlAuthority.RESTRICTED_CONTROL)
        assert restricted_or_worse, \
            f"Expected >= RESTRICTED, got {snap.decision.control_authority}"

    def test_e2e_subsystem_failure_restricted(self):
        """Critical subsystem failure → at least RESTRICTED."""
        fs_engine = default_fs_engine()
        supervisor = default_supervisor()
        rest = {k: v for k, v in healthy_subsystems().items() if "control" not in k}

        fs_decision = fs_engine.evaluate(
            timestamp=TS,
            **healthy_sensors(),
            control_status="FAILED", control_timestamp=TS - 0.1,
            **rest,
        )
        snap = supervisor.evaluate_with_failsafe(
            failsafe_decision=fs_decision,
            reference_timestamp=TS,
        )
        assert snap.decision.control_withheld, \
            f"Control subsystem failure should withheld, got {snap.decision.control_authority}"

    def test_e2e_snapshot_immutable(self):
        fs_engine = default_fs_engine()
        supervisor = default_supervisor()
        fs_decision = fs_engine.evaluate(timestamp=TS, **healthy_sensors(), **healthy_subsystems())
        snap = supervisor.evaluate_with_failsafe(
            failsafe_decision=fs_decision, reference_timestamp=TS
        )
        try:
            snap.decision = None  # type: ignore[misc]
            assert False
        except (AttributeError, TypeError):
            pass

    def test_e2e_failsafe_does_not_issue_actuator_commands(self):
        """The merged decision must NOT contain any actuator-facing field."""
        fs_engine = default_fs_engine()
        supervisor = default_supervisor()
        fs_decision = fs_engine.evaluate(timestamp=TS, **healthy_sensors(), **healthy_subsystems())
        snap = supervisor.evaluate_with_failsafe(
            failsafe_decision=fs_decision, reference_timestamp=TS
        )
        d = snap.decision
        assert not hasattr(d, "steering_command")
        assert not hasattr(d, "brake_command")
        assert not hasattr(d, "throttle_command")
        assert not hasattr(d, "can_message")
        assert not hasattr(d, "ecu_command")


# ---------------------------------------------------------------------------
# Runner (no pytest required)
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    import traceback
    import inspect

    test_classes = [
        TestBridgeTranslation,
        TestEvaluateWithFailsafe,
        TestEndToEndPipeline,
    ]

    passed, failed = [], []
    for cls in test_classes:
        instance = cls()
        methods = sorted(m for m in dir(cls) if m.startswith("test_"))
        for meth in methods:
            label = f"{cls.__name__}.{meth}"
            try:
                getattr(instance, meth)()
                passed.append(label)
                print(f"  PASS  {label}")
            except Exception:
                tb = traceback.format_exc()
                failed.append((label, tb))
                last = [l for l in tb.strip().split("\n") if l.strip()][-1]
                print(f"  FAIL  {label}: {last}")

    print(f"\nPASSED: {len(passed)}  FAILED: {len(failed)}")
    if failed:
        sys.exit(1)
