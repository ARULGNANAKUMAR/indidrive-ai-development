"""
IndiDrive AI — Phase 6.3 Test Suite: Road Anomaly / Road Damage Understanding.

All tests use synthetic deterministic data only — no CARLA, no network, no
real sensor required.  Follows the style of:
  - tests/road_understanding/test_road_understanding.py
  - tests/lane_structure/test_lane_structure.py

Coverage
--------
  Basic anomaly taxonomy (pothole, crack, gravel, mud, debris, rock,
    construction material, uneven surface, road-edge damage, unknown)
  Geometry (point, region, polygon, line, size estimation, depth)
  Severity (none, low, medium, high, critical, unknown, thresholds)
  Confidence (high-quality, weak, missing sensor, partial, fused)
  Uncertainty (missing depth, partial geometry, occlusion, water-covered,
    degraded sensor)
  Temporal consistency (new, observed, persistent, stale, expired)
  Drivable-area relationship (outside, touching, inside, unknown)
  Lane relationship (inside, near boundary, outside, unknown)
  Corridor relationship (clear, near, overlap, unknown)
  Indian-road scenario tests (10 synthetic scenarios)
  Determinism (same input → identical output, multiple runs)
  Edge cases (empty input, None, NaN, Inf, negative dims, zero dims,
    huge values, missing coords, duplicate observations, conflicting
    sensors, no Phase 6.1/6.2 info, fully degraded mode)
  False-positive resistance (impossible geometry, zero-confidence, duplicates)
  Output ordering (deterministic sort)
  Sensor degradation (camera-only, lidar-only, both missing)
  Phase 6.1 / 6.2 integration (read-only, no mutation)
  Error handling (graceful on bad input)
"""
from __future__ import annotations

import math
import sys
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))

from core.perception.road_anomaly import (
    RoadAnomalyEngine,
    RoadAnomalyConfig,
    RoadSurfaceObservation,
    road_anomaly_to_observation,
    _point_in_polygon,
)
from core.perception.road_anomaly_types import (
    AnomalyType, AnomalySeverity, AnomalyStatus,
    AnomalyGeometryKind, DepthKind, VisibilityState,
    DrivableAreaRelation, LaneRelation, CorridorRelation,
    TemporalState, RoadSurfaceQuality, AnomalyEngineStatus,
    AnomalyGeometry, AnomalyPoint2D, AnomalyPolygon,
    RoadAnomalyObservation, RoadAnomalyState,
    NOT_AVAILABLE,
)

# ---------------------------------------------------------------------------
# Minimal Phase 6.1 / 6.2 stubs (read-only; engine must not mutate these)
# ---------------------------------------------------------------------------

@dataclass
class _BoundaryPoint:
    x: float
    y: float
    confidence: float = 0.9


@dataclass
class _RoadBoundary:
    side: str
    available: bool
    points: list = field(default_factory=list)


@dataclass
class _RoadWidthSample:
    distance_m: float
    width_m: Optional[float]


@dataclass
class _RoadUnderstanding:
    """Minimal Phase 6.1 stub."""
    timestamp: float = 0.0
    frame_id: int = 0
    drivable_area_available: bool = False
    drivable_polygon: Optional[list] = None   # [(x, y), ...]
    road_width_profile: list = field(default_factory=list)
    left_boundary: Optional[_RoadBoundary] = None
    right_boundary: Optional[_RoadBoundary] = None
    confidence: float = 0.8


@dataclass
class _LaneBoundaryPoint:
    x: float
    y: float
    confidence: float = 0.8


@dataclass
class _LaneBoundary:
    available: bool
    points: list = field(default_factory=list)


@dataclass
class _LaneDescriptor:
    left_boundary: Optional[_LaneBoundary] = None
    right_boundary: Optional[_LaneBoundary] = None


@dataclass
class _LaneStructure:
    """Minimal Phase 6.2 stub."""
    timestamp: float = 0.0
    frame_id: int = 0
    lanes: list = field(default_factory=list)
    confidence: float = 0.7


# ---------------------------------------------------------------------------
# Helper builders
# ---------------------------------------------------------------------------

def _obs(
    atype: AnomalyType = AnomalyType.POTHOLE,
    cx: float = 10.0,
    cy: float = 0.0,
    cz: Optional[float] = None,
    length: Optional[float] = 0.6,
    width: Optional[float] = 0.4,
    depth: Optional[float] = None,
    depth_kind: DepthKind = DepthKind.UNKNOWN,
    conf: float = 0.8,
    source: str = "camera",
    vis: VisibilityState = VisibilityState.CLEAR,
    vis_score: float = 1.0,
    obs_id: Optional[str] = None,
    orientation: Optional[float] = None,
    contour_points: Optional[list] = None,
) -> RoadSurfaceObservation:
    return RoadSurfaceObservation(
        anomaly_type=atype,
        center_x=cx,
        center_y=cy,
        center_z=cz,
        length_m=length,
        width_m=width,
        depth_m=depth,
        depth_kind=depth_kind,
        orientation_rad=orientation,
        contour_points=contour_points,
        confidence=conf,
        source=source,
        timestamp=time.time(),
        visibility_state=vis,
        visibility_score=vis_score,
        observation_id=obs_id,
    )


def _drivable_square(cx: float = 0.0, cy: float = 0.0, half: float = 5.0) -> list:
    """Simple square drivable polygon centred at (cx, cy)."""
    return [
        (cx - half, cy - half),
        (cx + half, cy - half),
        (cx + half, cy + half),
        (cx - half, cy + half),
    ]


def _road_und(
    drivable_poly=None,
    drivable_available: bool = True,
    left_y: float = 3.0,
    right_y: float = -3.0,
    width: float = 6.0,
) -> _RoadUnderstanding:
    lb = _RoadBoundary(
        side="left", available=True,
        points=[_BoundaryPoint(x=0.0, y=left_y), _BoundaryPoint(x=40.0, y=left_y)],
    )
    rb = _RoadBoundary(
        side="right", available=True,
        points=[_BoundaryPoint(x=0.0, y=right_y), _BoundaryPoint(x=40.0, y=right_y)],
    )
    return _RoadUnderstanding(
        drivable_area_available=drivable_available,
        drivable_polygon=drivable_poly or _drivable_square(),
        road_width_profile=[_RoadWidthSample(distance_m=0.0, width_m=width)],
        left_boundary=lb,
        right_boundary=rb,
    )


def _lane_struct(left_y: float = 2.0, right_y: float = -2.0) -> _LaneStructure:
    lb = _LaneBoundary(
        available=True,
        points=[_LaneBoundaryPoint(x=0.0, y=left_y), _LaneBoundaryPoint(x=40.0, y=left_y)],
    )
    rb = _LaneBoundary(
        available=True,
        points=[_LaneBoundaryPoint(x=0.0, y=right_y), _LaneBoundaryPoint(x=40.0, y=right_y)],
    )
    lane = _LaneDescriptor(left_boundary=lb, right_boundary=rb)
    return _LaneStructure(lanes=[lane])


def _engine(cfg_overrides: Optional[dict] = None) -> RoadAnomalyEngine:
    cfg = RoadAnomalyConfig()
    if cfg_overrides:
        for k, v in cfg_overrides.items():
            setattr(cfg, k, v)
    return RoadAnomalyEngine(config=cfg)


# ===========================================================================
# 1. Basic anomaly taxonomy
# ===========================================================================

class TestBasicTaxonomy:

    @pytest.mark.parametrize("atype", list(AnomalyType))
    def test_each_anomaly_type_passes_through(self, atype):
        eng = _engine()
        state = eng.process(
            observations=[_obs(atype=atype, cx=5.0, cy=0.0)],
            frame_id=1, timestamp=1.0,
        )
        assert any(a.anomaly_type == atype for a in state.anomalies), \
            f"{atype} not found in output"

    def test_pothole_reported(self):
        eng = _engine()
        state = eng.process([_obs(AnomalyType.POTHOLE)], timestamp=1.0, frame_id=1)
        assert len(state.anomalies) >= 1
        assert state.anomalies[0].anomaly_type == AnomalyType.POTHOLE

    def test_crack_reported(self):
        eng = _engine()
        obs = _obs(AnomalyType.CRACK, length=0.8, width=None)
        state = eng.process([obs], timestamp=1.0, frame_id=1)
        assert any(a.anomaly_type == AnomalyType.CRACK for a in state.anomalies)

    def test_gravel_reported(self):
        eng = _engine()
        state = eng.process([_obs(AnomalyType.GRAVEL)], timestamp=1.0, frame_id=1)
        assert any(a.anomaly_type == AnomalyType.GRAVEL for a in state.anomalies)

    def test_mud_reported(self):
        eng = _engine()
        state = eng.process([_obs(AnomalyType.MUD)], timestamp=1.0, frame_id=1)
        assert any(a.anomaly_type == AnomalyType.MUD for a in state.anomalies)

    def test_debris_reported(self):
        eng = _engine()
        state = eng.process([_obs(AnomalyType.DEBRIS)], timestamp=1.0, frame_id=1)
        assert any(a.anomaly_type == AnomalyType.DEBRIS for a in state.anomalies)

    def test_rock_reported(self):
        eng = _engine()
        state = eng.process([_obs(AnomalyType.ROCK)], timestamp=1.0, frame_id=1)
        assert any(a.anomaly_type == AnomalyType.ROCK for a in state.anomalies)

    def test_construction_material_reported(self):
        eng = _engine()
        state = eng.process([_obs(AnomalyType.CONSTRUCTION_MATERIAL)], timestamp=1.0, frame_id=1)
        assert any(a.anomaly_type == AnomalyType.CONSTRUCTION_MATERIAL for a in state.anomalies)

    def test_uneven_surface_reported(self):
        eng = _engine()
        state = eng.process([_obs(AnomalyType.UNEVEN_SURFACE)], timestamp=1.0, frame_id=1)
        assert any(a.anomaly_type == AnomalyType.UNEVEN_SURFACE for a in state.anomalies)

    def test_road_edge_damage_reported(self):
        eng = _engine()
        state = eng.process([_obs(AnomalyType.ROAD_EDGE_DAMAGE)], timestamp=1.0, frame_id=1)
        assert any(a.anomaly_type == AnomalyType.ROAD_EDGE_DAMAGE for a in state.anomalies)

    def test_unknown_anomaly_reported(self):
        eng = _engine()
        state = eng.process([_obs(AnomalyType.UNKNOWN)], timestamp=1.0, frame_id=1)
        # UNKNOWN type has low confidence — but engine should not crash
        assert isinstance(state, RoadAnomalyState)


# ===========================================================================
# 2. Geometry tests
# ===========================================================================

class TestGeometry:

    def test_point_geometry_when_no_extent(self):
        eng = _engine()
        obs = _obs(length=None, width=None)
        state = eng.process([obs], timestamp=1.0, frame_id=1)
        a = state.anomalies[0]
        assert a.geometry.kind == AnomalyGeometryKind.POINT
        assert a.geometry.center_x is not None
        assert a.geometry.center_y is not None

    def test_region_geometry_when_length_and_width_given(self):
        eng = _engine()
        obs = _obs(length=1.2, width=0.8)
        state = eng.process([obs], timestamp=1.0, frame_id=1)
        a = state.anomalies[0]
        assert a.geometry.kind == AnomalyGeometryKind.REGION
        assert abs(a.geometry.length_m - 1.2) < 1e-6
        assert abs(a.geometry.width_m - 0.8) < 1e-6
        assert a.geometry.area_estimate_m2 is not None
        assert abs(a.geometry.area_estimate_m2 - 1.2 * 0.8) < 1e-6

    def test_line_geometry_for_crack(self):
        eng = _engine()
        obs = _obs(AnomalyType.CRACK, length=1.5, width=None)
        state = eng.process([obs], timestamp=1.0, frame_id=1)
        a = next((x for x in state.anomalies if x.anomaly_type == AnomalyType.CRACK), None)
        if a:
            assert a.geometry.kind == AnomalyGeometryKind.LINE

    def test_polygon_geometry_from_contour(self):
        eng = _engine()
        contour = [(9.0, 0.5), (11.0, 0.5), (11.0, -0.5), (9.0, -0.5)]
        obs = _obs(cx=10.0, cy=0.0, contour_points=contour)
        state = eng.process([obs], timestamp=1.0, frame_id=1)
        a = state.anomalies[0]
        assert a.geometry.kind == AnomalyGeometryKind.POLYGON
        assert a.geometry.contour is not None
        assert len(a.geometry.contour.points) == 4

    def test_polygon_area_from_contour(self):
        eng = _engine()
        # 2m x 1m rectangle → area = 2.0
        contour = [(9.0, 0.5), (11.0, 0.5), (11.0, -0.5), (9.0, -0.5)]
        obs = _obs(cx=10.0, cy=0.0, contour_points=contour, length=None, width=None)
        state = eng.process([obs], timestamp=1.0, frame_id=1)
        a = state.anomalies[0]
        assert a.geometry.area_estimate_m2 is not None
        assert abs(a.geometry.area_estimate_m2 - 2.0) < 0.01

    def test_depth_known(self):
        eng = _engine()
        obs = _obs(depth=0.12, depth_kind=DepthKind.KNOWN)
        state = eng.process([obs], timestamp=1.0, frame_id=1)
        a = state.anomalies[0]
        assert a.geometry.depth_kind == DepthKind.KNOWN
        assert a.geometry.depth_estimate_m is not None
        assert abs(a.geometry.depth_estimate_m - 0.12) < 1e-6

    def test_depth_unknown_not_fabricated(self):
        eng = _engine()
        obs = _obs(depth=None, depth_kind=DepthKind.UNKNOWN)
        state = eng.process([obs], timestamp=1.0, frame_id=1)
        a = state.anomalies[0]
        assert a.geometry.depth_estimate_m is None
        assert a.geometry.depth_kind == DepthKind.UNKNOWN

    def test_distance_is_euclidean(self):
        eng = _engine()
        obs = _obs(cx=3.0, cy=4.0)
        state = eng.process([obs], timestamp=1.0, frame_id=1)
        a = state.anomalies[0]
        assert a.distance_m is not None
        assert abs(a.distance_m - 5.0) < 0.01   # sqrt(9+16)=5

    def test_longitudinal_lateral_derived(self):
        eng = _engine()
        obs = _obs(cx=8.0, cy=-1.5)
        state = eng.process([obs], timestamp=1.0, frame_id=1)
        a = state.anomalies[0]
        assert abs(a.longitudinal_m - 8.0) < 1e-6
        assert abs(a.lateral_m - (-1.5)) < 1e-6

    def test_orientation_preserved(self):
        eng = _engine()
        obs = _obs(orientation=0.785)  # ~45 degrees
        state = eng.process([obs], timestamp=1.0, frame_id=1)
        a = state.anomalies[0]
        assert a.geometry.orientation_rad is not None
        assert abs(a.geometry.orientation_rad - 0.785) < 1e-6

    def test_invalid_geometry_negative_dimension_cleared(self):
        eng = _engine()
        obs = _obs(length=-1.0, width=0.4)
        state = eng.process([obs], timestamp=1.0, frame_id=1)
        # Should not crash; negative length cleared → POINT geometry
        assert isinstance(state, RoadAnomalyState)
        if state.anomalies:
            a = state.anomalies[0]
            assert a.geometry.length_m is None or a.geometry.kind == AnomalyGeometryKind.POINT

    def test_invalid_geometry_zero_dimension_treated_as_invalid(self):
        eng = _engine({"min_dimension_m": 0.01})
        obs = _obs(length=0.0, width=0.0)
        state = eng.process([obs], timestamp=1.0, frame_id=1)
        assert isinstance(state, RoadAnomalyState)

    def test_huge_dimension_cleared(self):
        eng = _engine({"max_dimension_m": 50.0})
        obs = _obs(length=200.0, width=0.5)
        state = eng.process([obs], timestamp=1.0, frame_id=1)
        assert isinstance(state, RoadAnomalyState)
        if state.anomalies:
            a = state.anomalies[0]
            assert a.geometry.length_m is None or a.geometry.length_m <= 50.0

    def test_reach_fields_populated_for_region(self):
        eng = _engine()
        obs = _obs(length=2.0, width=1.0)
        state = eng.process([obs], timestamp=1.0, frame_id=1)
        a = state.anomalies[0]
        assert a.geometry.longitudinal_reach_m is not None
        assert abs(a.geometry.longitudinal_reach_m - 1.0) < 1e-6
        assert a.geometry.lateral_reach_m is not None
        assert abs(a.geometry.lateral_reach_m - 0.5) < 1e-6


# ===========================================================================
# 3. Severity tests
# ===========================================================================

class TestSeverity:

    def test_low_severity_small_area(self):
        """A tiny GRAVEL patch (not a pothole) with sub-threshold area gets LOW severity.
        Note: POTHOLE uses a type-based fallback of MEDIUM even for small sizes because
        even a small pothole is a meaningful hazard on Indian roads.
        """
        eng = _engine()
        obs = _obs(AnomalyType.GRAVEL, length=0.2, width=0.2, conf=0.9)   # area = 0.04 < 0.10
        state = eng.process([obs], timestamp=1.0, frame_id=1)
        a = state.anomalies[0]
        assert a.severity in (AnomalySeverity.LOW, AnomalySeverity.NONE, AnomalySeverity.UNKNOWN)

    def test_medium_severity_medium_area(self):
        eng = _engine()
        obs = _obs(length=0.8, width=0.5, conf=0.9)   # area = 0.4 between 0.10 and 0.50
        state = eng.process([obs], timestamp=1.0, frame_id=1)
        a = state.anomalies[0]
        assert a.severity in (AnomalySeverity.MEDIUM, AnomalySeverity.LOW)

    def test_high_severity_large_area(self):
        eng = _engine()
        obs = _obs(length=2.0, width=1.5, conf=0.9)   # area = 3.0 ≥ 2.0 → HIGH
        state = eng.process([obs], timestamp=1.0, frame_id=1)
        a = state.anomalies[0]
        assert a.severity == AnomalySeverity.HIGH

    def test_critical_severity_deep_pothole(self):
        eng = _engine()
        obs = _obs(
            AnomalyType.POTHOLE,
            depth=0.35,
            depth_kind=DepthKind.KNOWN,
            length=1.0, width=0.8,
            conf=0.9,
        )
        state = eng.process([obs], timestamp=1.0, frame_id=1)
        a = state.anomalies[0]
        assert a.severity == AnomalySeverity.CRITICAL

    def test_high_severity_deep_pothole(self):
        eng = _engine()
        obs = _obs(
            AnomalyType.POTHOLE,
            depth=0.18,
            depth_kind=DepthKind.KNOWN,
            conf=0.9,
        )
        state = eng.process([obs], timestamp=1.0, frame_id=1)
        a = state.anomalies[0]
        assert a.severity in (AnomalySeverity.HIGH, AnomalySeverity.CRITICAL)

    def test_unknown_severity_zero_confidence(self):
        eng = _engine({"minimum_anomaly_confidence": 0.0})
        obs = _obs(conf=0.05)
        state = eng.process([obs], timestamp=1.0, frame_id=1)
        if state.anomalies:
            a = state.anomalies[0]
            assert a.severity == AnomalySeverity.UNKNOWN

    def test_rock_default_high_severity(self):
        eng = _engine()
        obs = _obs(AnomalyType.ROCK, length=None, width=None, conf=0.85)
        state = eng.process([obs], timestamp=1.0, frame_id=1)
        a = next((x for x in state.anomalies if x.anomaly_type == AnomalyType.ROCK), None)
        if a:
            assert a.severity in (AnomalySeverity.HIGH, AnomalySeverity.MEDIUM)

    def test_severity_threshold_boundaries(self):
        cfg = RoadAnomalyConfig()
        eng = RoadAnomalyEngine(config=cfg)
        # Exactly at medium threshold
        obs = _obs(
            length=math.sqrt(cfg.severity_medium_area_m2),
            width=math.sqrt(cfg.severity_medium_area_m2),
            conf=0.9,
        )
        state = eng.process([obs], timestamp=1.0, frame_id=1)
        if state.anomalies:
            assert state.anomalies[0].severity in (AnomalySeverity.MEDIUM, AnomalySeverity.HIGH)

    def test_surface_quality_good_no_anomalies(self):
        eng = _engine()
        state = eng.process([], timestamp=1.0, frame_id=1)
        assert state.road_surface_quality == RoadSurfaceQuality.UNKNOWN

    def test_surface_quality_severely_damaged_critical(self):
        eng = _engine()
        obs = _obs(
            AnomalyType.POTHOLE,
            depth=0.35, depth_kind=DepthKind.KNOWN,
            length=2.0, width=1.5, conf=0.95,
        )
        state = eng.process([obs], timestamp=1.0, frame_id=1)
        if state.anomalies:
            assert state.road_surface_quality in (
                RoadSurfaceQuality.SEVERELY_DAMAGED, RoadSurfaceQuality.DAMAGED
            )

    def test_surface_quality_minor_damage_low_severity(self):
        eng = _engine()
        obs = _obs(length=0.3, width=0.3, conf=0.9)  # small → LOW
        state = eng.process([obs], timestamp=1.0, frame_id=1)
        if state.anomalies:
            assert state.road_surface_quality in (
                RoadSurfaceQuality.MINOR_DAMAGE,
                RoadSurfaceQuality.DAMAGED,
                RoadSurfaceQuality.UNKNOWN,
            )


# ===========================================================================
# 4. Confidence tests
# ===========================================================================

class TestConfidence:

    def test_high_quality_observation_high_confidence(self):
        eng = _engine()
        obs = _obs(conf=0.95, vis=VisibilityState.CLEAR, source="fused")
        state = eng.process([obs], timestamp=1.0, frame_id=1)
        a = state.anomalies[0]
        assert a.confidence > 0.7

    def test_weak_observation_low_confidence(self):
        eng = _engine({"minimum_anomaly_confidence": 0.0})
        obs = _obs(conf=0.15, vis=VisibilityState.PARTIAL)
        state = eng.process([obs], timestamp=1.0, frame_id=1)
        if state.anomalies:
            a = state.anomalies[0]
            assert a.confidence < 0.5

    def test_missing_sensor_reduces_confidence(self):
        eng = _engine({"minimum_anomaly_confidence": 0.0})
        obs = _obs(conf=0.30, vis=VisibilityState.OBSCURED, source="camera")
        state = eng.process([obs], timestamp=1.0, frame_id=1)
        if state.anomalies:
            assert state.anomalies[0].confidence < 0.30

    def test_fused_source_boosts_confidence(self):
        eng = _engine()
        obs_cam = _obs(conf=0.70, source="camera")
        obs_fused = _obs(conf=0.70, source="fused")
        s1 = eng.process([obs_cam], timestamp=1.0, frame_id=1)
        eng2 = _engine()
        s2 = eng2.process([obs_fused], timestamp=1.0, frame_id=1)
        if s1.anomalies and s2.anomalies:
            assert s2.anomalies[0].confidence >= s1.anomalies[0].confidence

    def test_confidence_clamped_to_0_1(self):
        eng = _engine()
        obs = _obs(conf=0.99, source="fused")
        state = eng.process([obs], timestamp=1.0, frame_id=1)
        for a in state.anomalies:
            assert 0.0 <= a.confidence <= 1.0

    def test_partial_observation_reduced_confidence(self):
        eng = _engine()
        obs = _obs(conf=0.85, vis=VisibilityState.PARTIAL)
        state = eng.process([obs], timestamp=1.0, frame_id=1)
        if state.anomalies:
            assert state.anomalies[0].confidence < 0.85

    def test_point_geometry_reduced_confidence(self):
        eng = _engine()
        obs_region = _obs(conf=0.8, length=0.5, width=0.3)
        obs_point = _obs(conf=0.8, length=None, width=None)
        s1 = eng.process([obs_region], timestamp=1.0, frame_id=1)
        eng2 = _engine()
        s2 = eng2.process([obs_point], timestamp=2.0, frame_id=2)
        if s1.anomalies and s2.anomalies:
            assert s2.anomalies[0].confidence <= s1.anomalies[0].confidence


# ===========================================================================
# 5. Uncertainty tests
# ===========================================================================

class TestUncertainty:

    def test_missing_depth_increases_uncertainty(self):
        eng = _engine()
        obs = _obs(depth=None, depth_kind=DepthKind.UNKNOWN)
        state = eng.process([obs], timestamp=1.0, frame_id=1)
        a = state.anomalies[0]
        assert a.geometry_uncertain or a.uncertainty > 0.0

    def test_partial_geometry_uncertainty_flag(self):
        eng = _engine()
        obs = _obs(length=None, width=None)
        state = eng.process([obs], timestamp=1.0, frame_id=1)
        a = state.anomalies[0]
        assert a.geometry_uncertain

    def test_occlusion_increases_uncertainty(self):
        eng = _engine()
        obs_clear = _obs(conf=0.8, vis=VisibilityState.CLEAR)
        obs_occluded = _obs(conf=0.8, vis=VisibilityState.PARTIAL)
        s1 = eng.process([obs_clear], timestamp=1.0, frame_id=1)
        eng2 = _engine()
        s2 = eng2.process([obs_occluded], timestamp=2.0, frame_id=2)
        if s1.anomalies and s2.anomalies:
            assert s2.anomalies[0].uncertainty >= s1.anomalies[0].uncertainty

    def test_water_covered_surface_high_uncertainty(self):
        eng = _engine()
        obs = _obs(
            AnomalyType.WATER_DAMAGE,
            vis=VisibilityState.OBSCURED,
            vis_score=0.1,
            conf=0.60,
        )
        state = eng.process([obs], timestamp=1.0, frame_id=1)
        if state.anomalies:
            a = state.anomalies[0]
            assert a.uncertainty > 0.3
            assert a.position_uncertain

    def test_degraded_sensor_uncertainty_not_crash(self):
        eng = _engine()
        obs = _obs(conf=0.40, vis=VisibilityState.UNKNOWN, source="camera")
        state = eng.process([obs], timestamp=1.0, frame_id=1)
        assert isinstance(state, RoadAnomalyState)

    def test_unknown_type_uncertainty_flag(self):
        eng = _engine()
        obs = _obs(AnomalyType.UNKNOWN, conf=0.75)
        state = eng.process([obs], timestamp=1.0, frame_id=1)
        if state.anomalies:
            a = state.anomalies[0]
            assert a.classification_uncertain

    def test_uncertainty_not_simply_1_minus_confidence(self):
        """Uncertainty has independent contributors; should differ from 1-confidence."""
        eng = _engine()
        obs = _obs(conf=0.8, vis=VisibilityState.OBSCURED, depth=None)
        state = eng.process([obs], timestamp=1.0, frame_id=1)
        if state.anomalies:
            a = state.anomalies[0]
            naive = 1.0 - a.confidence
            # uncertainty should be >= naive due to water/occlusion contribution
            assert a.uncertainty >= naive - 0.01  # allow floating point


# ===========================================================================
# 6. Temporal consistency tests
# ===========================================================================

class TestTemporalConsistency:

    def test_first_observation_is_new(self):
        eng = _engine()
        state = eng.process(
            [_obs(obs_id="ph1")], timestamp=1.0, frame_id=1
        )
        a = state.anomalies[0]
        assert a.temporal_state == TemporalState.NEW
        assert a.observation_count == 1

    def test_repeated_observation_becomes_observed(self):
        eng = _engine()
        for ts in [1.0, 1.1]:
            state = eng.process(
                [_obs(cx=10.0, cy=0.0, atype=AnomalyType.POTHOLE)],
                timestamp=ts, frame_id=int(ts * 10),
            )
        a = state.anomalies[0]
        assert a.temporal_state in (TemporalState.OBSERVED, TemporalState.PERSISTENT)
        assert a.observation_count >= 2

    def test_persistent_after_threshold_count(self):
        cfg = RoadAnomalyConfig()
        n = cfg.persistence_threshold_count
        eng = RoadAnomalyEngine(config=cfg)
        for i in range(n):
            state = eng.process(
                [_obs(cx=10.0, cy=0.0, atype=AnomalyType.POTHOLE)],
                timestamp=float(i) * 0.1 + 1.0,
                frame_id=i,
            )
        a = state.anomalies[0]
        assert a.temporal_state == TemporalState.PERSISTENT
        assert a.observation_count >= n

    def test_stale_anomaly_not_returned_as_new(self):
        cfg = RoadAnomalyConfig()
        cfg.stale_timeout_s = 0.5
        eng = RoadAnomalyEngine(config=cfg)
        eng.process([_obs(cx=10.0, cy=0.0)], timestamp=1.0, frame_id=1)
        # 2 seconds later — no new observation; temporal record marked stale
        state = eng.process([], timestamp=3.0, frame_id=2)
        assert len(state.anomalies) == 0

    def test_expired_anomaly_removed(self):
        cfg = RoadAnomalyConfig()
        cfg.max_anomaly_age_s = 1.0
        eng = RoadAnomalyEngine(config=cfg)
        eng.process([_obs(cx=10.0, cy=0.0)], timestamp=1.0, frame_id=1)
        eng.process([], timestamp=5.0, frame_id=2)   # age-out
        assert eng.get_tracked_anomaly_count() == 0

    def test_persistence_seconds_calculated(self):
        eng = _engine()
        eng.process([_obs(cx=10.0, cy=0.0)], timestamp=1.0, frame_id=1)
        state = eng.process([_obs(cx=10.0, cy=0.0)], timestamp=2.0, frame_id=2)
        a = state.anomalies[0]
        assert a.persistence_s >= 0.0

    def test_temporal_consistency_score_increases_with_observations(self):
        eng = _engine()
        scores = []
        for i in range(4):
            state = eng.process(
                [_obs(cx=10.0, cy=0.0)],
                timestamp=float(i) * 0.1 + 1.0,
                frame_id=i,
            )
            if state.anomalies:
                scores.append(state.anomalies[0].temporal_consistency)
        assert len(scores) >= 2

    def test_persistent_confidence_slightly_boosted(self):
        cfg = RoadAnomalyConfig()
        cfg.persistence_threshold_count = 2
        eng = RoadAnomalyEngine(config=cfg)
        first_conf = None
        for i in range(3):
            state = eng.process(
                [_obs(cx=10.0, cy=0.0, conf=0.70)],
                timestamp=float(i) * 0.1 + 1.0, frame_id=i,
            )
            if state.anomalies and first_conf is None:
                first_conf = state.anomalies[0].confidence
        last = state.anomalies[0]
        assert last.temporal_state == TemporalState.PERSISTENT
        assert last.confidence >= first_conf


# ===========================================================================
# 7. Drivable-area relationship tests
# ===========================================================================

class TestDrivableAreaRelation:

    def test_anomaly_inside_drivable_area(self):
        eng = _engine()
        # Drivable square: x in [-5,5], y in [-5,5]; anomaly at (2, 1) → inside
        ru = _road_und(drivable_poly=_drivable_square(0, 0, 5))
        obs = _obs(cx=2.0, cy=1.0)
        state = eng.process([obs], road_understanding=ru, timestamp=1.0, frame_id=1)
        a = state.anomalies[0]
        assert a.drivable_area_relation == DrivableAreaRelation.INSIDE_DRIVABLE_AREA
        assert a.affects_drivable_area

    def test_anomaly_outside_drivable_area(self):
        eng = _engine()
        # Drivable square: x in [-5,5], y in [-5,5]; anomaly at (20, 0) → outside
        ru = _road_und(drivable_poly=_drivable_square(0, 0, 5))
        obs = _obs(cx=20.0, cy=0.0)
        state = eng.process([obs], road_understanding=ru, timestamp=1.0, frame_id=1)
        a = state.anomalies[0]
        assert a.drivable_area_relation == DrivableAreaRelation.OUTSIDE_DRIVABLE_AREA
        assert not a.affects_drivable_area

    def test_anomaly_partially_overlapping_drivable_area(self):
        eng = _engine()
        # Centre just outside polygon but extent crosses boundary
        ru = _road_und(drivable_poly=_drivable_square(0, 0, 5))
        # centre at (6, 0) — just outside; with length=4 → corners at x=4..8 → overlaps
        obs = _obs(cx=6.0, cy=0.0, length=4.0, width=1.0)
        state = eng.process([obs], road_understanding=ru, timestamp=1.0, frame_id=1)
        a = state.anomalies[0]
        assert a.drivable_area_relation in (
            DrivableAreaRelation.PARTIALLY_OVERLAPPING_DRIVABLE_AREA,
            DrivableAreaRelation.OUTSIDE_DRIVABLE_AREA,   # acceptable if reach not large enough
        )

    def test_unknown_when_no_road_understanding(self):
        eng = _engine()
        obs = _obs(cx=5.0, cy=0.0)
        state = eng.process([obs], road_understanding=None, timestamp=1.0, frame_id=1)
        a = state.anomalies[0]
        assert a.drivable_area_relation == DrivableAreaRelation.UNKNOWN

    def test_unknown_when_drivable_area_not_available(self):
        eng = _engine()
        ru = _road_und()
        ru.drivable_area_available = False
        obs = _obs(cx=2.0, cy=0.0)
        state = eng.process([obs], road_understanding=ru, timestamp=1.0, frame_id=1)
        a = state.anomalies[0]
        assert a.drivable_area_relation == DrivableAreaRelation.UNKNOWN


# ===========================================================================
# 8. Lane relationship tests
# ===========================================================================

class TestLaneRelation:

    def test_anomaly_inside_lane(self):
        eng = _engine()
        # Lane boundaries: left y=2.0, right y=-2.0; anomaly at y=0.5 → inside
        ls = _lane_struct(left_y=2.0, right_y=-2.0)
        obs = _obs(cx=10.0, cy=0.5)
        state = eng.process([obs], lane_structure=ls, timestamp=1.0, frame_id=1)
        a = state.anomalies[0]
        assert a.lane_relation == LaneRelation.INSIDE_LANE
        assert a.affects_lane_area

    def test_anomaly_near_lane_boundary(self):
        eng = _engine({"lane_boundary_proximity_m": 0.5})
        ls = _lane_struct(left_y=2.0, right_y=-2.0)
        # cy=1.7 → within 0.5 of left boundary at y=2.0
        obs = _obs(cx=10.0, cy=1.7)
        state = eng.process([obs], lane_structure=ls, timestamp=1.0, frame_id=1)
        a = state.anomalies[0]
        assert a.lane_relation in (LaneRelation.NEAR_LANE_BOUNDARY, LaneRelation.INSIDE_LANE)

    def test_anomaly_outside_lane_structure(self):
        eng = _engine()
        ls = _lane_struct(left_y=2.0, right_y=-2.0)
        # cy=5.0 → well outside any lane
        obs = _obs(cx=10.0, cy=5.0)
        state = eng.process([obs], lane_structure=ls, timestamp=1.0, frame_id=1)
        a = state.anomalies[0]
        assert a.lane_relation in (LaneRelation.OUTSIDE_LANE_STRUCTURE, LaneRelation.NEAR_LANE_BOUNDARY)

    def test_unknown_when_no_lane_structure(self):
        eng = _engine()
        obs = _obs(cx=10.0, cy=0.0)
        state = eng.process([obs], lane_structure=None, timestamp=1.0, frame_id=1)
        a = state.anomalies[0]
        assert a.lane_relation == LaneRelation.UNKNOWN


# ===========================================================================
# 9. Corridor relationship tests
# ===========================================================================

class TestCorridorRelation:

    def test_anomaly_overlapping_corridor(self):
        cfg = RoadAnomalyConfig()
        cfg.corridor_lateral_half_width_m = 2.0
        cfg.corridor_longitudinal_reach_m = 40.0
        eng = RoadAnomalyEngine(config=cfg)
        obs = _obs(cx=10.0, cy=0.5, length=1.0, width=0.5)  # well inside corridor
        state = eng.process([obs], timestamp=1.0, frame_id=1)
        a = state.anomalies[0]
        assert a.corridor_relation == CorridorRelation.OVERLAPPING_CURRENT_CORRIDOR
        assert a.affects_vehicle_path

    def test_anomaly_clear_of_corridor(self):
        cfg = RoadAnomalyConfig()
        cfg.corridor_lateral_half_width_m = 1.5
        eng = RoadAnomalyEngine(config=cfg)
        obs = _obs(cx=10.0, cy=8.0, length=0.5, width=0.3)  # far left
        state = eng.process([obs], timestamp=1.0, frame_id=1)
        a = state.anomalies[0]
        assert a.corridor_relation in (
            CorridorRelation.CLEAR_OF_CURRENT_CORRIDOR,
            CorridorRelation.NEAR_CURRENT_CORRIDOR,
        )
        assert not a.affects_vehicle_path

    def test_anomaly_near_corridor(self):
        cfg = RoadAnomalyConfig()
        cfg.corridor_lateral_half_width_m = 1.5
        eng = RoadAnomalyEngine(config=cfg)
        obs = _obs(cx=10.0, cy=2.0, length=0.5, width=0.3)  # just outside but near
        state = eng.process([obs], timestamp=1.0, frame_id=1)
        a = state.anomalies[0]
        assert a.corridor_relation in (
            CorridorRelation.NEAR_CURRENT_CORRIDOR,
            CorridorRelation.OVERLAPPING_CURRENT_CORRIDOR,
            CorridorRelation.CLEAR_OF_CURRENT_CORRIDOR,
        )

    def test_anomaly_behind_vehicle_clear(self):
        cfg = RoadAnomalyConfig()
        cfg.corridor_longitudinal_reach_m = 40.0
        eng = RoadAnomalyEngine(config=cfg)
        obs = _obs(cx=-5.0, cy=0.0)  # behind vehicle (negative x)
        state = eng.process([obs], timestamp=1.0, frame_id=1)
        if state.anomalies:
            a = state.anomalies[0]
            assert a.corridor_relation == CorridorRelation.CLEAR_OF_CURRENT_CORRIDOR


# ===========================================================================
# 10. Indian-road scenario tests
# ===========================================================================

class TestIndianRoadScenarios:
    """Ten synthetic deterministic scenarios for Indian road conditions."""

    def _run(self, obs_list, road_und=None, lane_struct=None, ts=1.0):
        eng = _engine()
        return eng.process(
            obs_list, road_understanding=road_und,
            lane_structure=lane_struct, timestamp=ts, frame_id=1,
        )

    def test_scenario_1_village_pothole(self):
        """Single pothole on a narrow unmarked village road."""
        obs = _obs(
            AnomalyType.POTHOLE, cx=8.0, cy=0.2,
            length=0.5, width=0.4, depth=0.10, depth_kind=DepthKind.ESTIMATED,
            conf=0.75,
        )
        state = self._run([obs])
        assert any(a.anomaly_type == AnomalyType.POTHOLE for a in state.anomalies)

    def test_scenario_2_damaged_unmarked_road(self):
        """Multiple small anomalies on a road with no markings."""
        obs_list = [
            _obs(AnomalyType.DAMAGED_SURFACE, cx=5.0, cy=-0.5, length=1.5, width=0.8, conf=0.70),
            _obs(AnomalyType.CRACK, cx=12.0, cy=0.3, length=0.6, width=None, conf=0.65),
        ]
        state = self._run(obs_list)
        types = {a.anomaly_type for a in state.anomalies}
        assert len(types) >= 1

    def test_scenario_3_gravel_on_narrow_road(self):
        """Gravel patch across most of a narrow road."""
        obs = _obs(
            AnomalyType.GRAVEL, cx=7.0, cy=0.0,
            length=3.0, width=2.5, conf=0.80,
        )
        state = self._run([obs])
        assert any(a.anomaly_type == AnomalyType.GRAVEL for a in state.anomalies)

    def test_scenario_4_muddy_road(self):
        """Mud patch extending across the travel corridor."""
        obs = _obs(
            AnomalyType.MUD, cx=6.0, cy=0.0,
            length=4.0, width=3.0, conf=0.72,
        )
        ru = _road_und(drivable_poly=_drivable_square(5, 0, 5))
        state = self._run([obs], road_und=ru)
        assert any(a.anomaly_type == AnomalyType.MUD for a in state.anomalies)

    def test_scenario_5_water_covered_pothole(self):
        """Pothole hidden under water — high uncertainty, obscured visibility."""
        obs = _obs(
            AnomalyType.WATER_DAMAGE, cx=9.0, cy=0.1,
            length=0.7, width=0.5,
            vis=VisibilityState.OBSCURED, vis_score=0.1,
            conf=0.55,
        )
        state = self._run([obs])
        if state.anomalies:
            a = state.anomalies[0]
            assert a.visibility_state == VisibilityState.OBSCURED
            assert a.uncertainty > 0.3

    def test_scenario_6_market_area_debris(self):
        """Multiple debris objects scattered in a busy market lane."""
        obs_list = [
            _obs(AnomalyType.DEBRIS, cx=4.0, cy=1.0, length=0.3, width=0.2, conf=0.80),
            _obs(AnomalyType.DEBRIS, cx=7.0, cy=-0.8, length=0.4, width=0.3, conf=0.75),
            _obs(AnomalyType.DEBRIS, cx=10.0, cy=0.5, length=0.25, width=0.2, conf=0.70),
        ]
        state = self._run(obs_list)
        debris = [a for a in state.anomalies if a.anomaly_type == AnomalyType.DEBRIS]
        assert len(debris) >= 1

    def test_scenario_7_construction_zone(self):
        """Construction material + rock blocking part of road."""
        obs_list = [
            _obs(AnomalyType.CONSTRUCTION_MATERIAL, cx=6.0, cy=0.0, length=2.0, width=1.5, conf=0.85),
            _obs(AnomalyType.ROCK, cx=8.5, cy=-0.3, length=0.5, width=0.4, conf=0.90),
        ]
        state = self._run(obs_list)
        types = {a.anomaly_type for a in state.anomalies}
        assert AnomalyType.ROCK in types or AnomalyType.CONSTRUCTION_MATERIAL in types

    def test_scenario_8_broken_road_edge(self):
        """Road-edge damage near left boundary — near_road_edge should be set."""
        ru = _road_und(left_y=3.0, right_y=-3.0)
        obs = _obs(
            AnomalyType.ROAD_EDGE_DAMAGE, cx=10.0, cy=2.8,  # close to left y=3.0
            length=1.0, width=0.4, conf=0.80,
        )
        state = self._run([obs], road_und=ru)
        if state.anomalies:
            a = state.anomalies[0]
            assert a.near_road_edge or a.road_edge_side != NOT_AVAILABLE

    def test_scenario_9_multiple_potholes(self):
        """Three potholes at different distances; sorted closest-first."""
        obs_list = [
            _obs(AnomalyType.POTHOLE, cx=20.0, cy=0.0, conf=0.80, obs_id="ph3"),
            _obs(AnomalyType.POTHOLE, cx=5.0, cy=0.0, conf=0.85, obs_id="ph1"),
            _obs(AnomalyType.POTHOLE, cx=12.0, cy=0.0, conf=0.75, obs_id="ph2"),
        ]
        state = self._run(obs_list)
        potholes = [a for a in state.anomalies if a.anomaly_type == AnomalyType.POTHOLE]
        assert len(potholes) >= 2
        # Closest should come first
        dists = [a.distance_m for a in potholes if a.distance_m is not None]
        assert dists == sorted(dists)

    def test_scenario_10_mixed_road_damage(self):
        """Pothole + crack + mud + gravel — mixed damage state."""
        obs_list = [
            _obs(AnomalyType.POTHOLE, cx=8.0, cy=0.2, length=0.6, width=0.4, conf=0.80),
            _obs(AnomalyType.CRACK, cx=14.0, cy=-0.3, length=0.9, width=None, conf=0.70),
            _obs(AnomalyType.MUD, cx=18.0, cy=0.5, length=2.0, width=1.5, conf=0.65),
            _obs(AnomalyType.GRAVEL, cx=22.0, cy=0.0, length=3.0, width=2.0, conf=0.75),
        ]
        state = self._run(obs_list)
        assert len(state.anomalies) >= 2
        assert state.road_surface_quality != RoadSurfaceQuality.GOOD


# ===========================================================================
# 11. Determinism tests
# ===========================================================================

class TestDeterminism:

    def test_same_input_same_output_multiple_runs(self):
        """Identical input must produce identical output on every run."""
        obs_list = [
            _obs(AnomalyType.POTHOLE, cx=10.0, cy=0.1, length=0.6, width=0.4, conf=0.80, obs_id="p1"),
            _obs(AnomalyType.GRAVEL, cx=18.0, cy=-0.5, length=2.5, width=1.8, conf=0.70, obs_id="g1"),
        ]
        ts = 42.0
        results = []
        for _ in range(5):
            eng = _engine()
            state = eng.process(obs_list[:], timestamp=ts, frame_id=7)
            results.append([
                (a.anomaly_type.value, a.anomaly_id,
                 round(a.confidence, 4), a.severity.value,
                 round(a.uncertainty, 4))
                for a in state.anomalies
            ])
        for r in results[1:]:
            assert r == results[0], "non-deterministic output detected"

    def test_same_input_same_road_surface_quality(self):
        obs_list = [_obs(cx=5.0, cy=0.0, length=2.5, width=1.5, conf=0.90, obs_id="d1")]
        ts = 99.0
        qualities = []
        for _ in range(3):
            eng = _engine()
            state = eng.process(obs_list[:], timestamp=ts, frame_id=1)
            qualities.append(state.road_surface_quality)
        assert len(set(q.value for q in qualities)) == 1

    def test_no_random_values_in_output(self):
        """Run twice, check every numeric field is identical."""
        obs = _obs(cx=7.0, cy=1.0, length=1.0, width=0.6, depth=0.08, depth_kind=DepthKind.ESTIMATED, conf=0.75)
        results = []
        for _ in range(2):
            eng = _engine()
            state = eng.process([obs], timestamp=5.0, frame_id=3)
            if state.anomalies:
                a = state.anomalies[0]
                results.append((
                    round(a.confidence, 6),
                    round(a.uncertainty, 6),
                    a.severity.value,
                    a.anomaly_type.value,
                ))
        if len(results) == 2:
            assert results[0] == results[1]


# ===========================================================================
# 12. Edge cases
# ===========================================================================

class TestEdgeCases:

    def test_empty_observations_list(self):
        eng = _engine()
        state = eng.process([], timestamp=1.0, frame_id=1)
        assert isinstance(state, RoadAnomalyState)
        assert len(state.anomalies) == 0
        assert state.status in (AnomalyEngineStatus.UNAVAILABLE, AnomalyEngineStatus.OK)

    def test_none_observations(self):
        eng = _engine()
        state = eng.process(None, timestamp=1.0, frame_id=1)
        assert isinstance(state, RoadAnomalyState)
        assert len(state.anomalies) == 0

    def test_none_observation_in_list(self):
        eng = _engine()
        state = eng.process([None], timestamp=1.0, frame_id=1)
        assert isinstance(state, RoadAnomalyState)

    def test_nan_position_skipped(self):
        eng = _engine()
        obs = _obs(cx=float("nan"), cy=0.0)
        state = eng.process([obs], timestamp=1.0, frame_id=1)
        assert isinstance(state, RoadAnomalyState)
        assert len(state.anomalies) == 0

    def test_inf_position_skipped(self):
        eng = _engine()
        obs = _obs(cx=float("inf"), cy=0.0)
        state = eng.process([obs], timestamp=1.0, frame_id=1)
        assert len(state.anomalies) == 0

    def test_nan_dimension_cleared(self):
        eng = _engine()
        obs = _obs(length=float("nan"), width=0.4)
        state = eng.process([obs], timestamp=1.0, frame_id=1)
        assert isinstance(state, RoadAnomalyState)

    def test_inf_dimension_cleared(self):
        eng = _engine()
        obs = _obs(length=float("inf"), width=0.4)
        state = eng.process([obs], timestamp=1.0, frame_id=1)
        assert isinstance(state, RoadAnomalyState)

    def test_zero_confidence_observation_filtered(self):
        eng = _engine()
        obs = _obs(conf=0.0)
        state = eng.process([obs], timestamp=1.0, frame_id=1)
        assert isinstance(state, RoadAnomalyState)

    def test_negative_confidence_clamped(self):
        eng = _engine({"minimum_anomaly_confidence": 0.0})
        obs = _obs(conf=-0.5)
        state = eng.process([obs], timestamp=1.0, frame_id=1)
        assert isinstance(state, RoadAnomalyState)

    def test_beyond_max_distance_skipped(self):
        eng = _engine({"max_distance_m": 50.0})
        obs = _obs(cx=100.0, cy=0.0)
        state = eng.process([obs], timestamp=1.0, frame_id=1)
        assert len(state.anomalies) == 0

    def test_duplicate_identical_observations_merged(self):
        eng = _engine()
        obs_list = [
            _obs(AnomalyType.POTHOLE, cx=10.0, cy=0.0, conf=0.80),
            _obs(AnomalyType.POTHOLE, cx=10.0, cy=0.0, conf=0.78),  # essentially same
        ]
        state = eng.process(obs_list, timestamp=1.0, frame_id=1)
        potholes = [a for a in state.anomalies if a.anomaly_type == AnomalyType.POTHOLE]
        assert len(potholes) <= 2  # ideally 1 after merge; but 2 is acceptable if IDs differ

    def test_conflicting_sensor_sources_handled(self):
        eng = _engine()
        obs_list = [
            _obs(AnomalyType.POTHOLE, cx=10.0, cy=0.0, conf=0.80, source="camera"),
            _obs(AnomalyType.POTHOLE, cx=10.1, cy=0.0, conf=0.75, source="lidar"),
        ]
        state = eng.process(obs_list, timestamp=1.0, frame_id=1)
        assert isinstance(state, RoadAnomalyState)

    def test_no_drivable_area_info_gives_unknown(self):
        eng = _engine()
        obs = _obs(cx=5.0, cy=0.0)
        state = eng.process([obs], road_understanding=None, timestamp=1.0, frame_id=1)
        a = state.anomalies[0]
        assert a.drivable_area_relation == DrivableAreaRelation.UNKNOWN

    def test_no_lane_info_gives_unknown(self):
        eng = _engine()
        obs = _obs(cx=5.0, cy=0.0)
        state = eng.process([obs], lane_structure=None, timestamp=1.0, frame_id=1)
        a = state.anomalies[0]
        assert a.lane_relation == LaneRelation.UNKNOWN

    def test_fully_degraded_mode_empty_observations(self):
        eng = _engine()
        state = eng.process([], timestamp=1.0, frame_id=1)
        assert isinstance(state, RoadAnomalyState)
        assert state.status in (AnomalyEngineStatus.UNAVAILABLE, AnomalyEngineStatus.OK)

    def test_malformed_observation_type_skipped(self):
        eng = _engine()
        obs_list = [_obs(), "not_an_observation", 42, None]
        state = eng.process(obs_list, timestamp=1.0, frame_id=1)
        assert isinstance(state, RoadAnomalyState)

    def test_missing_center_coordinates_skipped(self):
        eng = _engine()
        obs = RoadSurfaceObservation(
            anomaly_type=AnomalyType.POTHOLE,
            center_x=None,
            center_y=None,
            confidence=0.8,
            source="camera",
            timestamp=1.0,
        )
        state = eng.process([obs], timestamp=1.0, frame_id=1)
        assert len(state.anomalies) == 0

    def test_engine_disabled_returns_unavailable(self):
        eng = _engine({"enabled": False})
        state = eng.process([_obs()], timestamp=1.0, frame_id=1)
        assert state.status == AnomalyEngineStatus.UNAVAILABLE

    def test_reset_clears_temporal_state(self):
        eng = _engine()
        eng.process([_obs(cx=10.0)], timestamp=1.0, frame_id=1)
        assert eng.get_tracked_anomaly_count() > 0
        eng.reset()
        assert eng.get_tracked_anomaly_count() == 0


# ===========================================================================
# 13. Output ordering
# ===========================================================================

class TestOutputOrdering:

    def test_anomalies_sorted_by_distance_ascending(self):
        eng = _engine()
        obs_list = [
            _obs(cx=30.0, cy=0.0, obs_id="far"),
            _obs(cx=5.0, cy=0.0, obs_id="near"),
            _obs(cx=15.0, cy=0.0, obs_id="mid"),
        ]
        state = eng.process(obs_list, timestamp=1.0, frame_id=1)
        dists = [a.distance_m for a in state.anomalies if a.distance_m is not None]
        assert dists == sorted(dists)

    def test_ordering_stable_across_calls(self):
        eng = _engine()
        obs_list = [
            _obs(AnomalyType.POTHOLE, cx=10.0, cy=0.0, conf=0.80),
            _obs(AnomalyType.GRAVEL, cx=15.0, cy=0.0, conf=0.75),
            _obs(AnomalyType.DEBRIS, cx=7.0, cy=0.0, conf=0.70),
        ]
        s1 = _engine().process(obs_list[:], timestamp=5.0, frame_id=1)
        s2 = _engine().process(obs_list[:], timestamp=5.0, frame_id=1)
        types1 = [a.anomaly_type for a in s1.anomalies]
        types2 = [a.anomaly_type for a in s2.anomalies]
        assert types1 == types2


# ===========================================================================
# 14. Sensor degradation
# ===========================================================================

class TestSensorDegradation:

    def test_camera_only_mode(self):
        eng = _engine()
        obs = _obs(source="camera", conf=0.70)
        state = eng.process([obs], timestamp=1.0, frame_id=1)
        assert isinstance(state, RoadAnomalyState)
        assert state.sensor_status.get("lidar") == "UNAVAILABLE"

    def test_lidar_only_mode(self):
        eng = _engine()
        obs = _obs(source="lidar", conf=0.75)
        state = eng.process([obs], timestamp=1.0, frame_id=1)
        assert state.sensor_status.get("camera") == "UNAVAILABLE"
        assert state.sensor_status.get("lidar") == "OK"

    def test_both_sensors_missing_returns_unavailable(self):
        eng = _engine()
        state = eng.process([], timestamp=1.0, frame_id=1)
        assert state.status in (AnomalyEngineStatus.UNAVAILABLE, AnomalyEngineStatus.OK)
        assert len(state.anomalies) == 0

    def test_no_crash_when_road_understanding_has_no_boundaries(self):
        eng = _engine()
        ru = _RoadUnderstanding(drivable_area_available=False)
        obs = _obs(cx=5.0, cy=0.0)
        state = eng.process([obs], road_understanding=ru, timestamp=1.0, frame_id=1)
        assert isinstance(state, RoadAnomalyState)

    def test_degraded_flag_set_when_sensors_missing(self):
        eng = _engine()
        obs = _obs(source="camera")
        state = eng.process([obs], timestamp=1.0, frame_id=1)
        # lidar is unavailable → degraded
        assert state.degraded


# ===========================================================================
# 15. Phase 6.1 / 6.2 immutability
# ===========================================================================

class TestUpstreamImmutability:

    def test_road_understanding_not_mutated(self):
        eng = _engine()
        ru = _road_und()
        orig_confidence = ru.confidence
        orig_poly_len = len(ru.drivable_polygon or [])
        eng.process([_obs()], road_understanding=ru, timestamp=1.0, frame_id=1)
        assert ru.confidence == orig_confidence
        if ru.drivable_polygon is not None:
            assert len(ru.drivable_polygon) == orig_poly_len

    def test_lane_structure_not_mutated(self):
        eng = _engine()
        ls = _lane_struct()
        orig_lane_count = len(ls.lanes)
        orig_conf = ls.confidence
        eng.process([_obs()], lane_structure=ls, timestamp=1.0, frame_id=1)
        assert ls.confidence == orig_conf
        assert len(ls.lanes) == orig_lane_count


# ===========================================================================
# 16. False-positive resistance
# ===========================================================================

class TestFalsePositiveResistance:

    def test_zero_confidence_not_reported_by_default(self):
        eng = _engine()
        obs = _obs(conf=0.0)
        state = eng.process([obs], timestamp=1.0, frame_id=1)
        # zero-confidence should be filtered by minimum_anomaly_confidence
        assert all(a.confidence >= eng.config.minimum_anomaly_confidence for a in state.anomalies)

    def test_impossible_depth_cleared(self):
        eng = _engine()
        obs = _obs(depth=999.0, depth_kind=DepthKind.KNOWN)
        state = eng.process([obs], timestamp=1.0, frame_id=1)
        for a in state.anomalies:
            if a.geometry.depth_estimate_m is not None:
                assert a.geometry.depth_estimate_m <= eng.config.max_depth_m

    def test_very_small_crack_below_min_crack_length(self):
        """A crack shorter than min_crack_length_m should still be processed (not crashed)."""
        eng = _engine({"min_crack_length_m": 0.05})
        obs = _obs(AnomalyType.CRACK, length=0.02, width=None, conf=0.60)
        state = eng.process([obs], timestamp=1.0, frame_id=1)
        assert isinstance(state, RoadAnomalyState)

    def test_highly_uncertain_anomaly_not_elevated(self):
        eng = _engine({"minimum_anomaly_confidence": 0.0})
        obs = _obs(conf=0.10, vis=VisibilityState.OBSCURED)
        state = eng.process([obs], timestamp=1.0, frame_id=1)
        if state.anomalies:
            a = state.anomalies[0]
            assert a.severity not in (AnomalySeverity.HIGH, AnomalySeverity.CRITICAL)


# ===========================================================================
# 17. Adapter test
# ===========================================================================

class TestPhase2Adapter:

    def test_road_anomaly_to_observation_basic(self):
        """Convert a Phase 2 RoadAnomaly stub to a RoadSurfaceObservation."""
        from core.perception.perception_types import (
            RoadAnomaly, BoundingBox2D, Dimensions3D, SourceSensor,
        )
        phase2 = RoadAnomaly(
            anomaly_type="pothole",
            confidence=0.78,
            location=BoundingBox2D(x=100, y=200, width=50, height=40),
            size_estimate=Dimensions3D(length=0.6, width=0.4, height=0.1),
            severity="MEDIUM",
            source=SourceSensor.CAMERA,
            timestamp=5.0,
        )
        obs = road_anomaly_to_observation(phase2, vehicle_frame_cx=8.0, vehicle_frame_cy=0.3)
        assert obs.anomaly_type == AnomalyType.POTHOLE
        assert abs(obs.confidence - 0.78) < 1e-6
        assert obs.center_x == 8.0
        assert obs.center_y == 0.3

    def test_road_anomaly_to_observation_none_safe(self):
        obs = road_anomaly_to_observation(None)
        assert isinstance(obs, RoadSurfaceObservation)
        assert obs.confidence == 0.0

    def test_road_anomaly_to_observation_water_patch_sets_obscured(self):
        from core.perception.perception_types import RoadAnomaly, SourceSensor
        phase2 = RoadAnomaly(
            anomaly_type="water_patch",
            confidence=0.60,
            location=None,
            size_estimate=None,
            severity="MEDIUM",
            source=SourceSensor.CAMERA,
            timestamp=1.0,
        )
        obs = road_anomaly_to_observation(phase2, vehicle_frame_cx=5.0, vehicle_frame_cy=0.0)
        assert obs.visibility_state == VisibilityState.OBSCURED


# ===========================================================================
# 18. Point-in-polygon utility
# ===========================================================================

class TestPointInPolygon:

    def test_point_inside_square(self):
        poly = [(0.0, 0.0), (10.0, 0.0), (10.0, 10.0), (0.0, 10.0)]
        assert _point_in_polygon(5.0, 5.0, poly)

    def test_point_outside_square(self):
        poly = [(0.0, 0.0), (10.0, 0.0), (10.0, 10.0), (0.0, 10.0)]
        assert not _point_in_polygon(15.0, 5.0, poly)

    def test_point_on_edge_consistent(self):
        poly = [(0.0, 0.0), (10.0, 0.0), (10.0, 10.0), (0.0, 10.0)]
        # Edge cases are implementation-defined; just shouldn't crash
        result = _point_in_polygon(5.0, 0.0, poly)
        assert isinstance(result, bool)


# ===========================================================================
# 19. RoadAnomalyState.to_dict completeness
# ===========================================================================

class TestToDictCompleteness:

    def test_state_to_dict_has_required_keys(self):
        eng = _engine()
        state = eng.process(
            [_obs(cx=10.0, cy=0.0, conf=0.80)],
            timestamp=1.0, frame_id=5,
        )
        d = state.to_dict()
        required = [
            "timestamp", "frame_id", "status", "road_surface_quality",
            "overall_confidence", "overall_uncertainty", "sensor_status",
            "degraded", "source_summary", "anomaly_count", "anomalies",
            "stats", "warnings",
        ]
        for key in required:
            assert key in d, f"Missing key: {key}"

    def test_anomaly_to_dict_has_required_keys(self):
        eng = _engine()
        state = eng.process([_obs(cx=10.0, cy=0.0, conf=0.80)], timestamp=1.0, frame_id=1)
        if state.anomalies:
            d = state.anomalies[0].to_dict()
            required = [
                "anomaly_id", "anomaly_type", "timestamp", "status", "geometry",
                "distance_m", "severity", "confidence", "uncertainty",
                "source", "observation_count", "temporal_state",
                "drivable_area_relation", "lane_relation", "corridor_relation",
                "affects_drivable_area", "affects_vehicle_path",
            ]
            for key in required:
                assert key in d, f"Missing anomaly key: {key}"

    def test_geometry_to_dict_no_nan_or_inf(self):
        eng = _engine()
        obs = _obs(cx=5.0, cy=1.0, length=1.0, width=0.5, depth=0.08, depth_kind=DepthKind.ESTIMATED)
        state = eng.process([obs], timestamp=1.0, frame_id=1)
        if state.anomalies:
            gd = state.anomalies[0].geometry.to_dict()
            for k, v in gd.items():
                if isinstance(v, float):
                    assert math.isfinite(v), f"geometry.{k} is non-finite: {v}"


# ===========================================================================
# 20. Config via from_dict
# ===========================================================================

class TestConfigFromDict:

    def test_from_dict_overrides_threshold(self):
        cfg = RoadAnomalyConfig.from_dict({"minimum_anomaly_confidence": 0.50})
        assert cfg.minimum_anomaly_confidence == 0.50

    def test_from_dict_none_returns_defaults(self):
        cfg = RoadAnomalyConfig.from_dict(None)
        default = RoadAnomalyConfig()
        assert cfg.minimum_anomaly_confidence == default.minimum_anomaly_confidence

    def test_from_dict_empty_returns_defaults(self):
        cfg = RoadAnomalyConfig.from_dict({})
        assert cfg.enabled == RoadAnomalyConfig().enabled
