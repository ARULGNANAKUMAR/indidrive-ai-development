"""
IndiDrive AI — Phase 0 | Health check tests
Run with: PYTHONPATH=. pytest tests/health/ -v
Covers spec Test 3 (health check runs) and Test 4 (directories detected/created).
"""
import shutil
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent.parent
sys.path.insert(0, str(ROOT))

from core.health.health_check import run_health_check
from core.health.component_status import ComponentStatus, overall_status, PASS, WARN, FAIL
from core.logging_system import ensure_log_directories, CATEGORIES, LOGS_DIR


# --- Test 3: Health check runs ---

def test_health_check_runs_and_returns_expected_shape():
    result = run_health_check()
    assert "components" in result
    assert "overall" in result
    assert result["overall"] in ("READY", "DEGRADED", "NOT READY")
    assert len(result["components"]) >= 10


def test_health_check_python_component_passes_in_this_environment():
    result = run_health_check()
    py = next(c for c in result["components"] if c["name"] == "Python")
    assert py["status"] == PASS


def test_overall_status_logic():
    all_pass = [ComponentStatus("a", PASS), ComponentStatus("b", PASS)]
    assert overall_status(all_pass) == "READY"

    with_warn = [ComponentStatus("a", PASS), ComponentStatus("b", WARN)]
    assert overall_status(with_warn) == "DEGRADED"

    with_fail = [ComponentStatus("a", WARN), ComponentStatus("b", FAIL)]
    assert overall_status(with_fail) == "NOT READY"


def test_component_status_rejects_invalid_status():
    try:
        ComponentStatus("bad", "MAYBE")
        assert False, "expected ValueError"
    except ValueError:
        pass


# --- Test 4: Required directories are detected/created ---

def test_ensure_log_directories_creates_all_categories():
    # Simulate a fresh checkout by removing the logs tree, then verify
    # ensure_log_directories() recreates every required category.
    if LOGS_DIR.exists():
        shutil.rmtree(LOGS_DIR)
    created = ensure_log_directories()
    for cat in CATEGORIES:
        assert (LOGS_DIR / cat).is_dir(), f"logs/{cat}/ was not created"
    assert isinstance(created, list)


def test_project_structure_check_reports_missing_dirs_accurately():
    from core.health.health_check import check_project_structure
    status = check_project_structure()
    assert status.status in (PASS, WARN)
    if status.status == WARN:
        assert "missing" in status.details


if __name__ == "__main__":
    import traceback
    tests = [v for k, v in list(globals().items()) if k.startswith("test_") and callable(v)]
    passed = failed = 0
    for t in tests:
        try:
            t()
            print(f"PASS {t.__name__}")
            passed += 1
        except Exception:
            print(f"FAIL {t.__name__}")
            traceback.print_exc()
            failed += 1
    print(f"\n{passed} passed, {failed} failed")
