"""
Phase 10.3 — Tests: Numerical Safety

Tests:
    * NaN input to controller
    * Infinity input
    * Zero / invalid dt
    * Zero speed
    * Invalid control bounds
    * Division by zero protection
    * Non-finite reference points
"""
import math

from core.control import (
    MPCController,
    MPCConfig,
    MPCStatus,
    MPCPredictor,
    MPCControlInput,
    MPCCostCalculator,
    MPCConstraintChecker,
)
from core.tracking.reference_trajectory import ReferenceTrajectory, ReferencePoint
from core.vehicle.vehicle_state import VehicleState
from core.vehicle.vehicle_parameters import VehicleParameters


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _ego(x=0.0, y=0.0, yaw=0.0, v=10.0):
    return VehicleState(x=x, y=y, yaw=yaw, velocity=v)


def _ref(n=15):
    return ReferenceTrajectory(points=[
        ReferencePoint(x=float(i), y=0.0, yaw=0.0) for i in range(n)
    ])


def _ctrl():
    return MPCController(MPCConfig(
        prediction_horizon=5, dt=0.1, steering_samples=3, acceleration_samples=2
    ))


# ---------------------------------------------------------------------------
# NaN inputs to controller
# ---------------------------------------------------------------------------

class TestNaNInputs:
    def test_nan_x_returns_invalid(self):
        snap = _ctrl().solve(VehicleState(x=float("nan"), y=0.0, yaw=0.0, velocity=5.0), _ref())
        assert snap.status == MPCStatus.INVALID_INPUT
        assert not snap.feasible

    def test_nan_y_returns_invalid(self):
        snap = _ctrl().solve(VehicleState(x=0.0, y=float("nan"), yaw=0.0, velocity=5.0), _ref())
        assert snap.status == MPCStatus.INVALID_INPUT

    def test_nan_yaw_returns_invalid(self):
        snap = _ctrl().solve(VehicleState(x=0.0, y=0.0, yaw=float("nan"), velocity=5.0), _ref())
        assert snap.status == MPCStatus.INVALID_INPUT

    def test_nan_velocity_returns_invalid(self):
        snap = _ctrl().solve(VehicleState(x=0.0, y=0.0, yaw=0.0, velocity=float("nan")), _ref())
        assert snap.status == MPCStatus.INVALID_INPUT

    def test_nan_prev_steering_returns_invalid(self):
        snap = _ctrl().solve(_ego(), _ref(), prev_steering=float("nan"))
        assert snap.status == MPCStatus.INVALID_INPUT

    def test_nan_prev_acceleration_returns_invalid(self):
        snap = _ctrl().solve(_ego(), _ref(), prev_acceleration=float("nan"))
        assert snap.status == MPCStatus.INVALID_INPUT


# ---------------------------------------------------------------------------
# Infinity inputs
# ---------------------------------------------------------------------------

class TestInfinityInputs:
    def test_inf_velocity_returns_invalid(self):
        snap = _ctrl().solve(VehicleState(x=0.0, y=0.0, yaw=0.0, velocity=float("inf")), _ref())
        assert snap.status == MPCStatus.INVALID_INPUT

    def test_inf_prev_steering_returns_invalid(self):
        snap = _ctrl().solve(_ego(), _ref(), prev_steering=float("inf"))
        assert snap.status == MPCStatus.INVALID_INPUT


# ---------------------------------------------------------------------------
# Predictor numerical safety
# ---------------------------------------------------------------------------

class TestPredictorNumericalSafety:
    def setup_method(self):
        self.pred = MPCPredictor(VehicleParameters.default())

    def test_nan_dt(self):
        r = self.pred.predict(_ego(), [MPCControlInput(0.0, 0.0)], dt=float("nan"))
        assert not r.valid

    def test_inf_dt(self):
        r = self.pred.predict(_ego(), [MPCControlInput(0.0, 0.0)], dt=float("inf"))
        assert not r.valid

    def test_zero_dt(self):
        r = self.pred.predict(_ego(), [MPCControlInput(0.0, 0.0)], dt=0.0)
        assert not r.valid

    def test_negative_dt(self):
        r = self.pred.predict(_ego(), [MPCControlInput(0.0, 0.0)], dt=-0.1)
        assert not r.valid

    def test_nan_steering_control(self):
        r = self.pred.predict(
            _ego(), [MPCControlInput(float("nan"), 0.0)], dt=0.1
        )
        assert not r.valid

    def test_inf_acceleration_control(self):
        r = self.pred.predict(
            _ego(), [MPCControlInput(0.0, float("inf"))], dt=0.1
        )
        assert not r.valid


# ---------------------------------------------------------------------------
# Zero speed
# ---------------------------------------------------------------------------

class TestZeroSpeed:
    def test_zero_speed_no_crash(self):
        """Solving at v=0 must not raise or produce NaN."""
        snap = _ctrl().solve(_ego(v=0.0), _ref())
        # Either feasible or infeasible — both OK; must not crash
        for s in snap.predicted_states:
            assert s.is_finite()

    def test_predictor_zero_speed_finite(self):
        pred = MPCPredictor(VehicleParameters.default())
        r    = pred.predict_constant(_ego(v=0.0), 0.0, 0.0, horizon=10, dt=0.1)
        assert r.valid
        for s in r.states:
            assert s.is_finite()


# ---------------------------------------------------------------------------
# Cost function numerical safety
# ---------------------------------------------------------------------------

class TestCostNumericalSafety:
    def test_invalid_prediction_inf_cost(self):
        from core.control import PredictionResult
        bad  = PredictionResult(valid=False, error_message="bad")
        calc = MPCCostCalculator(MPCConfig.default())
        cost = calc.compute(bad, _ref())
        assert not cost.valid
        assert math.isinf(cost.total_cost)

    def test_empty_ref_inf_cost(self):
        pred = MPCPredictor(VehicleParameters.default()).predict_constant(
            _ego(), 0.0, 0.0, horizon=5, dt=0.1
        )
        calc = MPCCostCalculator(MPCConfig.default())
        cost = calc.compute(pred, ReferenceTrajectory(points=[]))
        assert not cost.valid
        assert math.isinf(cost.total_cost)


# ---------------------------------------------------------------------------
# Constraint checker numerical safety
# ---------------------------------------------------------------------------

class TestConstraintNumericalSafety:
    def test_nan_prev_steering_constraint(self):
        """NaN prev_steering should be handled gracefully."""
        pred = MPCPredictor(VehicleParameters.default()).predict_constant(
            _ego(), 0.0, 0.0, horizon=5, dt=0.1
        )
        checker = MPCConstraintChecker(MPCConfig.default())
        # NaN prev_steering → steering rate will be NaN → violation
        result = checker.check(pred, prev_steering=float("nan"))
        # Either violation detected or check passes with NaN (model-dependent)
        # Most importantly: no exception raised
        assert result is not None

    def test_check_control_nan_returns_false(self):
        checker = MPCConstraintChecker(MPCConfig.default())
        assert checker.check_control(float("nan"), 0.0) is False
        assert checker.check_control(0.0, float("nan")) is False


# ---------------------------------------------------------------------------
# Snapshot on failure — always safe to read
# ---------------------------------------------------------------------------

class TestFailureSnapshotSafe:
    def test_failure_predicted_states_finite_when_ego_valid(self):
        """
        When failure is due to invalid reference (not ego), the snapshot
        predicted_states (which contain a copy of the valid ego) are finite.
        """
        snap = _ctrl().solve(_ego(v=10.0), None)  # invalid ref, valid ego
        # The only state in predicted_states is a copy of the (valid) ego
        for s in snap.predicted_states:
            assert s.is_finite()

    def test_failure_snapshot_has_no_control_sequence(self):
        """Failure snapshot control_sequence is empty."""
        snap = _ctrl().solve(_ego(), None)
        assert len(snap.control_sequence) == 0

    def test_solution_id_always_present(self):
        """solution_id is always a non-empty string, even on failure."""
        snap = _ctrl().solve(VehicleState(x=float("nan"), y=0.0, yaw=0.0, velocity=5.0), _ref())
        assert isinstance(snap.solution_id, str) and len(snap.solution_id) > 0
