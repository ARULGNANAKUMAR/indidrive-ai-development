"""
Phase 10.3 — Tests: Prediction (MPCPredictor / bicycle model propagation)

Tests:
    * straight-line prediction
    * constant velocity
    * acceleration
    * steering-induced yaw change
    * curved motion
    * low-speed propagation
    * numerical safety
"""
import math

from core.control import MPCControlInput, MPCPredictor, PredictionResult
from core.vehicle.vehicle_state import VehicleState
from core.vehicle.vehicle_parameters import VehicleParameters


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _ego(x=0.0, y=0.0, yaw=0.0, v=10.0):
    return VehicleState(x=x, y=y, yaw=yaw, velocity=v)


def _predictor():
    return MPCPredictor(VehicleParameters.default())


def _ctrl(steer=0.0, accel=0.0, step=0):
    return MPCControlInput(steering_input=steer, acceleration_input=accel, step_index=step)


def _controls(steer=0.0, accel=0.0, n=10):
    return [_ctrl(steer, accel, i) for i in range(n)]


# ---------------------------------------------------------------------------
# Straight-line prediction
# ---------------------------------------------------------------------------

class TestStraightLinePrediction:
    def setup_method(self):
        self.pred = _predictor()

    def test_straight_states_count(self):
        """Result has horizon+1 states."""
        r = self.pred.predict(_ego(), _controls(n=10), dt=0.1)
        assert r.valid
        assert len(r.states) == 11

    def test_straight_y_unchanged(self):
        """Zero steering → y stays near zero."""
        r = self.pred.predict(_ego(v=10.0), _controls(steer=0.0, n=10), dt=0.1)
        assert r.valid
        for s in r.states:
            assert abs(s.y) < 1e-6

    def test_straight_yaw_unchanged(self):
        """Zero steering → yaw stays near zero."""
        r = self.pred.predict(_ego(yaw=0.0, v=10.0), _controls(steer=0.0, n=10), dt=0.1)
        assert r.valid
        for s in r.states:
            assert abs(s.yaw) < 1e-6

    def test_straight_x_increases(self):
        """Forward velocity → x increases monotonically."""
        r = self.pred.predict(_ego(v=10.0), _controls(steer=0.0, n=5), dt=0.1)
        assert r.valid
        xs = [s.x for s in r.states]
        for i in range(1, len(xs)):
            assert xs[i] > xs[i - 1]

    def test_straight_x_increment_correct(self):
        """At constant v=10 m/s, dt=0.1: Δx ≈ 1.0 m per step."""
        r = self.pred.predict(_ego(v=10.0), _controls(steer=0.0, accel=0.0, n=1), dt=0.1)
        assert r.valid
        dx = r.states[1].x - r.states[0].x
        assert abs(dx - 1.0) < 0.05  # forward Euler tolerance

    def test_initial_state_preserved(self):
        """states[0] is a copy of the initial state."""
        ego = _ego(x=5.0, y=3.0, yaw=0.2, v=8.0)
        r = self.pred.predict(ego, _controls(n=5), dt=0.1)
        assert r.valid
        assert abs(r.states[0].x - 5.0) < 1e-9
        assert abs(r.states[0].y - 3.0) < 1e-9


# ---------------------------------------------------------------------------
# Constant velocity
# ---------------------------------------------------------------------------

class TestConstantVelocity:
    def setup_method(self):
        self.pred = _predictor()

    def test_constant_velocity_no_accel(self):
        """Zero acceleration → velocity unchanged throughout."""
        r = self.pred.predict(_ego(v=12.0), _controls(steer=0.0, accel=0.0, n=10), dt=0.1)
        assert r.valid
        for s in r.states:
            assert abs(s.velocity - 12.0) < 1e-6


# ---------------------------------------------------------------------------
# Acceleration
# ---------------------------------------------------------------------------

class TestAccelerationPrediction:
    def setup_method(self):
        self.pred = _predictor()

    def test_positive_accel_increases_velocity(self):
        """Positive acceleration → velocity increases."""
        r = self.pred.predict(_ego(v=5.0), _controls(steer=0.0, accel=2.0, n=10), dt=0.1)
        assert r.valid
        assert r.states[-1].velocity > r.states[0].velocity

    def test_negative_accel_decreases_velocity(self):
        """Negative acceleration (braking) → velocity decreases."""
        r = self.pred.predict(_ego(v=10.0), _controls(steer=0.0, accel=-3.0, n=5), dt=0.1)
        assert r.valid
        # velocity should not have gone below the model's minimum (clamped to 0)
        for s in r.states:
            assert s.velocity >= 0.0

    def test_velocity_does_not_go_below_zero(self):
        """Hard braking → velocity clamped at ≥ 0."""
        r = self.pred.predict(
            _ego(v=2.0), _controls(steer=0.0, accel=-10.0, n=10), dt=0.1
        )
        assert r.valid
        for s in r.states:
            assert s.velocity >= -1e-6  # allow tiny floating-point slack


# ---------------------------------------------------------------------------
# Steering / yaw
# ---------------------------------------------------------------------------

class TestSteeringYaw:
    def setup_method(self):
        self.pred = _predictor()

    def test_positive_steering_yaw_increases(self):
        """Positive steering → yaw increases (CCW / left turn)."""
        r = self.pred.predict(_ego(v=10.0), _controls(steer=0.1, accel=0.0, n=5), dt=0.1)
        assert r.valid
        assert r.states[-1].yaw > r.states[0].yaw

    def test_negative_steering_yaw_decreases(self):
        """Negative steering → yaw decreases (CW / right turn)."""
        r = self.pred.predict(_ego(v=10.0), _controls(steer=-0.1, accel=0.0, n=5), dt=0.1)
        assert r.valid
        assert r.states[-1].yaw < r.states[0].yaw

    def test_symmetry_positive_negative(self):
        """Symmetric steering → symmetric yaw change magnitude."""
        rp = self.pred.predict(_ego(v=10.0), _controls(steer=+0.2, accel=0.0, n=5), dt=0.1)
        rn = self.pred.predict(_ego(v=10.0), _controls(steer=-0.2, accel=0.0, n=5), dt=0.1)
        assert rp.valid and rn.valid
        dyaw_pos = rp.states[-1].yaw - rp.states[0].yaw
        dyaw_neg = rn.states[-1].yaw - rn.states[0].yaw
        assert abs(abs(dyaw_pos) - abs(dyaw_neg)) < 1e-6

    def test_larger_steering_larger_yaw_change(self):
        """Larger steering magnitude → larger yaw rate."""
        r1 = self.pred.predict(_ego(v=10.0), _controls(steer=0.1, n=5), dt=0.1)
        r2 = self.pred.predict(_ego(v=10.0), _controls(steer=0.3, n=5), dt=0.1)
        assert r1.valid and r2.valid
        dy1 = r2.states[-1].yaw - r2.states[0].yaw
        dy0 = r1.states[-1].yaw - r1.states[0].yaw
        assert dy1 > dy0


# ---------------------------------------------------------------------------
# Curved motion
# ---------------------------------------------------------------------------

class TestCurvedMotion:
    def setup_method(self):
        self.pred = _predictor()

    def test_curved_x_and_y_both_change(self):
        """Constant steering → both x and y change over time."""
        r = self.pred.predict(_ego(v=10.0), _controls(steer=0.15, n=10), dt=0.1)
        assert r.valid
        dx = abs(r.states[-1].x - r.states[0].x)
        dy = abs(r.states[-1].y - r.states[0].y)
        assert dx > 0.1
        assert dy > 0.01  # slight lateral displacement

    def test_curved_all_states_finite(self):
        """All predicted states are finite during curved motion."""
        r = self.pred.predict(_ego(v=8.0), _controls(steer=0.3, n=15), dt=0.1)
        assert r.valid
        for s in r.states:
            assert s.is_finite()


# ---------------------------------------------------------------------------
# Low-speed / zero-speed
# ---------------------------------------------------------------------------

class TestLowSpeedPrediction:
    def setup_method(self):
        self.pred = _predictor()

    def test_zero_speed_valid(self):
        """Prediction at v=0 does not raise or produce NaN."""
        r = self.pred.predict(
            _ego(v=0.0), _controls(steer=0.0, accel=0.0, n=5), dt=0.1
        )
        assert r.valid
        for s in r.states:
            assert s.is_finite()

    def test_zero_speed_x_unchanged(self):
        """At v=0 with no acceleration, position stays the same."""
        r = self.pred.predict(_ego(v=0.0), _controls(steer=0.0, accel=0.0, n=5), dt=0.1)
        assert r.valid
        for s in r.states:
            assert abs(s.x) < 1e-6

    def test_low_speed_0_1(self):
        """Prediction at v=0.1 m/s produces finite states."""
        r = self.pred.predict(_ego(v=0.1), _controls(n=5), dt=0.1)
        assert r.valid
        for s in r.states:
            assert s.is_finite()


# ---------------------------------------------------------------------------
# Numerical safety
# ---------------------------------------------------------------------------

class TestPredictionNumericalSafety:
    def setup_method(self):
        self.pred = _predictor()

    def test_nan_dt_invalid(self):
        r = self.pred.predict(_ego(), _controls(n=5), dt=float("nan"))
        assert not r.valid

    def test_zero_dt_invalid(self):
        r = self.pred.predict(_ego(), _controls(n=5), dt=0.0)
        assert not r.valid

    def test_negative_dt_invalid(self):
        r = self.pred.predict(_ego(), _controls(n=5), dt=-0.1)
        assert not r.valid

    def test_nan_steering_input_invalid(self):
        ctrls = [MPCControlInput(steering_input=float("nan"), acceleration_input=0.0, step_index=0)]
        r = self.pred.predict(_ego(), ctrls, dt=0.1)
        assert not r.valid

    def test_inf_steering_input_invalid(self):
        ctrls = [MPCControlInput(steering_input=float("inf"), acceleration_input=0.0, step_index=0)]
        r = self.pred.predict(_ego(), ctrls, dt=0.1)
        assert not r.valid

    def test_empty_controls_returns_initial_state(self):
        """Empty control list → single-state result with just initial state."""
        r = self.pred.predict(_ego(x=3.0), [], dt=0.1)
        assert r.valid
        assert len(r.states) == 1
        assert abs(r.states[0].x - 3.0) < 1e-9

    def test_predict_constant_convenience(self):
        """predict_constant helper returns valid result."""
        r = self.pred.predict_constant(
            _ego(v=10.0), steering=0.05, acceleration=0.0, horizon=8, dt=0.1
        )
        assert r.valid
        assert len(r.states) == 9

    def test_mpc_control_input_is_finite(self):
        c = MPCControlInput(steering_input=0.1, acceleration_input=2.0)
        assert c.is_finite()

    def test_mpc_control_input_nan_not_finite(self):
        c = MPCControlInput(steering_input=float("nan"), acceleration_input=0.0)
        assert not c.is_finite()
