"""
Phase 10.3 — Tests: Basic (Controller Creation, Config, State)

Tests:
    * controller creation with default config
    * controller creation with explicit config
    * valid configuration accepted
    * invalid configuration rejected
    * valid state accepted
    * invalid state rejected
"""
import math

from core.control import (
    MPCController,
    MPCConfig,
    MPCSnapshot,
    MPCStatus,
    MPCValidator,
    SolverStrategy,
)
from core.vehicle.vehicle_state import VehicleState
from core.tracking.reference_trajectory import ReferenceTrajectory


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _straight_ref(n=15, step=1.0):
    return ReferenceTrajectory.from_xy_list(
        [(i * step, 0.0) for i in range(n)]
    )


def _ego(x=0.0, y=0.0, yaw=0.0, v=10.0):
    return VehicleState(x=x, y=y, yaw=yaw, velocity=v)


# ---------------------------------------------------------------------------
# Controller creation
# ---------------------------------------------------------------------------

class TestControllerCreation:
    def test_default_creation(self):
        """Controller creates successfully with default config."""
        ctrl = MPCController()
        assert ctrl is not None

    def test_explicit_config(self):
        """Controller accepts explicit MPCConfig."""
        cfg  = MPCConfig(prediction_horizon=5, dt=0.2)
        ctrl = MPCController(cfg)
        assert ctrl.config.prediction_horizon == 5
        assert ctrl.config.dt == 0.2

    def test_config_exposed(self):
        """Controller exposes its configuration."""
        cfg  = MPCConfig.default()
        ctrl = MPCController(cfg)
        assert ctrl.config is cfg

    def test_vehicle_params_exposed(self):
        """Controller exposes vehicle parameters."""
        ctrl = MPCController()
        assert ctrl.vehicle_params is not None

    def test_schema_version_in_snapshot(self):
        """Snapshot carries schema version 10.3."""
        ctrl = MPCController()
        snap = ctrl.solve(_ego(), _straight_ref())
        assert snap.schema_version == "10.3"

    def test_solution_id_is_string(self):
        """Every snapshot has a non-empty solution_id string."""
        ctrl = MPCController()
        snap = ctrl.solve(_ego(), _straight_ref())
        assert isinstance(snap.solution_id, str)
        assert len(snap.solution_id) > 0

    def test_two_solves_have_different_ids(self):
        """Each call to solve() produces a unique solution_id."""
        ctrl = MPCController()
        s1 = ctrl.solve(_ego(), _straight_ref())
        s2 = ctrl.solve(_ego(), _straight_ref())
        assert s1.solution_id != s2.solution_id


# ---------------------------------------------------------------------------
# Config validation
# ---------------------------------------------------------------------------

class TestConfigValidation:
    def test_default_config_valid(self):
        """Default config passes validator."""
        r = MPCValidator.validate_config(MPCConfig.default())
        assert r.valid

    def test_negative_weight_rejected(self):
        """Negative cost weight raises ValueError in constructor."""
        try:
            MPCConfig(w_cross_track=-1.0)
            assert False, "Expected ValueError"
        except ValueError:
            pass

    def test_zero_dt_rejected(self):
        """dt=0 raises ValueError."""
        try:
            MPCConfig(dt=0.0)
            assert False, "Expected ValueError"
        except ValueError:
            pass

    def test_negative_dt_rejected(self):
        """dt<0 raises ValueError."""
        try:
            MPCConfig(dt=-0.1)
            assert False, "Expected ValueError"
        except ValueError:
            pass

    def test_horizon_zero_rejected(self):
        """prediction_horizon=0 raises ValueError."""
        try:
            MPCConfig(prediction_horizon=0)
            assert False, "Expected ValueError"
        except ValueError:
            pass

    def test_invalid_steering_min_rejected(self):
        """min_steering_rad > 0 raises ValueError."""
        try:
            MPCConfig(min_steering_rad=0.1)
            assert False, "Expected ValueError"
        except ValueError:
            pass

    def test_invalid_accel_min_rejected(self):
        """min_acceleration_mps2 >= 0 raises ValueError."""
        try:
            MPCConfig(min_acceleration_mps2=0.0)
            assert False, "Expected ValueError"
        except ValueError:
            pass

    def test_invalid_accel_max_rejected(self):
        """max_acceleration_mps2 <= 0 raises ValueError."""
        try:
            MPCConfig(max_acceleration_mps2=0.0)
            assert False, "Expected ValueError"
        except ValueError:
            pass

    def test_velocity_min_negative_rejected(self):
        """min_velocity_mps < 0 raises ValueError."""
        try:
            MPCConfig(min_velocity_mps=-1.0)
            assert False, "Expected ValueError"
        except ValueError:
            pass

    def test_velocity_max_le_min_rejected(self):
        """max_velocity_mps <= min_velocity_mps raises ValueError."""
        try:
            MPCConfig(min_velocity_mps=5.0, max_velocity_mps=5.0)
            assert False, "Expected ValueError"
        except ValueError:
            pass

    def test_steering_samples_lt_2_rejected(self):
        """steering_samples < 2 raises ValueError."""
        try:
            MPCConfig(steering_samples=1)
            assert False, "Expected ValueError"
        except ValueError:
            pass

    def test_acceleration_samples_lt_2_rejected(self):
        """acceleration_samples < 2 raises ValueError."""
        try:
            MPCConfig(acceleration_samples=1)
            assert False, "Expected ValueError"
        except ValueError:
            pass

    def test_from_dict_defaults(self):
        """from_dict with empty dict returns defaults."""
        cfg = MPCConfig.from_dict({})
        assert cfg.prediction_horizon == MPCConfig.default().prediction_horizon
        assert cfg.dt == MPCConfig.default().dt

    def test_from_dict_nested(self):
        """from_dict with nested 'mpc' key works."""
        d = {
            "mpc": {
                "prediction_horizon": 8,
                "dt": 0.15,
                "weights": {"cross_track": 3.0},
            }
        }
        cfg = MPCConfig.from_dict(d)
        assert cfg.prediction_horizon == 8
        assert cfg.dt == 0.15
        assert cfg.w_cross_track == 3.0

    def test_zero_weight_allowed(self):
        """A weight of 0.0 is valid (disables that cost component)."""
        cfg = MPCConfig(w_terminal=0.0)
        assert cfg.w_terminal == 0.0

    def test_horizon_duration(self):
        """horizon_duration_s = prediction_horizon * dt."""
        cfg = MPCConfig(prediction_horizon=10, dt=0.1)
        assert abs(cfg.horizon_duration_s - 1.0) < 1e-9


# ---------------------------------------------------------------------------
# State validation
# ---------------------------------------------------------------------------

class TestStateValidation:
    def test_valid_state_passes(self):
        r = MPCValidator.validate_state(_ego())
        assert r.valid

    def test_none_state_fails(self):
        r = MPCValidator.validate_state(None)
        assert not r.valid

    def test_nan_x_fails(self):
        s = VehicleState(x=float("nan"), y=0.0, yaw=0.0, velocity=5.0)
        r = MPCValidator.validate_state(s)
        assert not r.valid

    def test_inf_velocity_fails(self):
        s = VehicleState(x=0.0, y=0.0, yaw=0.0, velocity=float("inf"))
        r = MPCValidator.validate_state(s)
        assert not r.valid

    def test_negative_velocity_fails(self):
        """VehicleState with velocity < 0 should fail Phase 10.1 validate()."""
        s = VehicleState(x=0.0, y=0.0, yaw=0.0, velocity=-1.0)
        r = MPCValidator.validate_state(s)
        assert not r.valid

    def test_zero_velocity_valid(self):
        """velocity = 0 is a valid state (vehicle stopped)."""
        s = VehicleState(x=0.0, y=0.0, yaw=0.0, velocity=0.0)
        r = MPCValidator.validate_state(s)
        assert r.valid

    def test_invalid_state_returns_invalid_input_status(self):
        """solve() returns INVALID_INPUT for bad state."""
        ctrl = MPCController()
        bad  = VehicleState(x=float("nan"), y=0.0, yaw=0.0, velocity=5.0)
        snap = ctrl.solve(bad, _straight_ref())
        assert snap.status == MPCStatus.INVALID_INPUT
        assert not snap.feasible
