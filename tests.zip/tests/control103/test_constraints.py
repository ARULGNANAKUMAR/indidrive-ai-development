"""
Phase 10.3 — Tests: Constraints (MPCConstraintChecker)

Tests:
    * steering limits enforced
    * steering-rate limits enforced
    * acceleration limits enforced
    * velocity limits enforced
    * infeasible sequence rejected
    * feasible sequence accepted
"""
import math

from core.control import (
    MPCConfig,
    MPCConstraintChecker,
    MPCControlInput,
    MPCPredictor,
    ConstraintStatus,
    ConstraintCheckResult,
)
from core.vehicle.vehicle_state import VehicleState
from core.vehicle.vehicle_parameters import VehicleParameters


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _ego(x=0.0, y=0.0, yaw=0.0, v=10.0):
    return VehicleState(x=x, y=y, yaw=yaw, velocity=v)


def _predict(steer=0.0, accel=0.0, v=10.0, n=5, dt=0.1, cfg=None):
    params = VehicleParameters.default()
    if cfg is not None:
        # Override params from config if needed (no direct mapping, use defaults)
        pass
    pred = MPCPredictor(params)
    ctrls = [
        MPCControlInput(steering_input=steer, acceleration_input=accel, step_index=i)
        for i in range(n)
    ]
    return pred.predict(_ego(v=v), ctrls, dt=dt)


def _checker(cfg=None):
    return MPCConstraintChecker(cfg or MPCConfig.default())


# ---------------------------------------------------------------------------
# Steering angle constraints
# ---------------------------------------------------------------------------

class TestSteeringConstraints:
    def test_zero_steering_satisfied(self):
        """Zero steering is always within bounds."""
        pred = _predict(steer=0.0)
        result = _checker().check(pred)
        assert result.status == ConstraintStatus.SATISFIED
        assert result.feasible

    def test_max_steering_satisfied(self):
        """Steering at exactly max is satisfied (within tolerance)."""
        cfg  = MPCConfig(max_steering_rad=0.6, min_steering_rad=-0.6,
                         max_steering_rate_rad_s=10.0)  # large rate so only angle checked
        pred = _predict(steer=0.6)
        result = _checker(cfg).check(pred)
        # Should be satisfied
        assert result.status == ConstraintStatus.SATISFIED

    def test_steering_exceeds_max_violated(self):
        """Steering above max is VIOLATED."""
        cfg  = MPCConfig(max_steering_rad=0.3, min_steering_rad=-0.3,
                         max_steering_rate_rad_s=10.0)
        pred = _predict(steer=0.5)  # 0.5 > 0.3 max
        result = _checker(cfg).check(pred)
        assert result.status == ConstraintStatus.VIOLATED
        assert not result.feasible
        fields = [v.field for v in result.violations]
        assert "steering_input" in fields

    def test_steering_below_min_violated(self):
        """Steering below min is VIOLATED."""
        cfg  = MPCConfig(max_steering_rad=0.3, min_steering_rad=-0.3,
                         max_steering_rate_rad_s=10.0)
        pred = _predict(steer=-0.5)
        result = _checker(cfg).check(pred)
        assert result.status == ConstraintStatus.VIOLATED
        fields = [v.field for v in result.violations]
        assert "steering_input" in fields


# ---------------------------------------------------------------------------
# Steering rate constraints
# ---------------------------------------------------------------------------

class TestSteeringRateConstraints:
    def test_small_steering_change_ok(self):
        """Small Δsteering within rate limit → SATISFIED."""
        cfg = MPCConfig(
            max_steering_rate_rad_s=0.5,
            max_steering_rad=0.6, min_steering_rad=-0.6,
            dt=0.1,  # Δsteering limit = 0.5 * 0.1 = 0.05 rad
        )
        # steer=0.02 from prev=0.0 → rate = 0.02/0.1 = 0.2 rad/s ≤ 0.5
        pred   = _predict(steer=0.02, dt=0.1)
        result = MPCConstraintChecker(cfg).check(pred, prev_steering=0.0)
        assert result.status == ConstraintStatus.SATISFIED

    def test_large_steering_jump_violated(self):
        """Large Δsteering exceeds rate limit → VIOLATED."""
        cfg = MPCConfig(
            max_steering_rate_rad_s=0.5,
            max_steering_rad=0.6, min_steering_rad=-0.6,
            dt=0.1,  # max Δsteering = 0.05 rad
        )
        # steer=0.2, prev=0.0 → rate = 0.2/0.1 = 2.0 > 0.5
        pred   = _predict(steer=0.2, dt=0.1)
        result = MPCConstraintChecker(cfg).check(pred, prev_steering=0.0)
        assert result.status == ConstraintStatus.VIOLATED
        fields = [v.field for v in result.violations]
        assert "steering_rate" in fields


# ---------------------------------------------------------------------------
# Acceleration constraints
# ---------------------------------------------------------------------------

class TestAccelerationConstraints:
    def test_zero_accel_satisfied(self):
        """Zero acceleration always within bounds."""
        pred   = _predict(accel=0.0)
        result = _checker().check(pred)
        assert result.status == ConstraintStatus.SATISFIED

    def test_accel_exceeds_max_violated(self):
        """Acceleration above max → VIOLATED."""
        cfg    = MPCConfig(max_acceleration_mps2=3.0, min_acceleration_mps2=-5.0)
        pred   = _predict(accel=5.0)  # > 3.0
        result = MPCConstraintChecker(cfg).check(pred)
        assert result.status == ConstraintStatus.VIOLATED
        fields = [v.field for v in result.violations]
        assert "acceleration_input" in fields

    def test_accel_below_min_violated(self):
        """Braking harder than min → VIOLATED."""
        cfg    = MPCConfig(max_acceleration_mps2=3.0, min_acceleration_mps2=-5.0)
        pred   = _predict(accel=-7.0, v=20.0)
        result = MPCConstraintChecker(cfg).check(pred)
        assert result.status == ConstraintStatus.VIOLATED
        fields = [v.field for v in result.violations]
        assert "acceleration_input" in fields


# ---------------------------------------------------------------------------
# Velocity constraints
# ---------------------------------------------------------------------------

class TestVelocityConstraints:
    def test_normal_velocity_satisfied(self):
        """Normal velocity within bounds → SATISFIED."""
        cfg    = MPCConfig(min_velocity_mps=0.0, max_velocity_mps=30.0)
        pred   = _predict(v=10.0, accel=0.0)
        result = MPCConstraintChecker(cfg).check(pred)
        assert result.status == ConstraintStatus.SATISFIED

    def test_velocity_above_max_violated(self):
        """Predicted velocity above max → VIOLATED."""
        cfg    = MPCConfig(min_velocity_mps=0.0, max_velocity_mps=5.0)
        pred   = _predict(v=10.0, accel=0.0)  # v=10 > max 5
        result = MPCConstraintChecker(cfg).check(pred)
        assert result.status == ConstraintStatus.VIOLATED
        fields = [v.field for v in result.violations]
        assert "velocity" in fields


# ---------------------------------------------------------------------------
# Infeasible sequence rejection
# ---------------------------------------------------------------------------

class TestInfeasibleRejection:
    def test_invalid_prediction_infeasible(self):
        """An invalid PredictionResult is infeasible."""
        from core.control import PredictionResult
        bad    = PredictionResult(states=[], controls=[], valid=False, error_message="bad")
        result = _checker().check(bad)
        assert not result.feasible

    def test_violations_list_populated(self):
        """Violations list is non-empty when infeasible."""
        cfg    = MPCConfig(max_acceleration_mps2=2.0, min_acceleration_mps2=-2.0)
        pred   = _predict(accel=5.0)  # exceeds max
        result = MPCConstraintChecker(cfg).check(pred)
        assert not result.feasible
        assert len(result.violations) > 0

    def test_violation_description_non_empty(self):
        """Each violation has a non-empty description."""
        cfg    = MPCConfig(max_steering_rad=0.2, min_steering_rad=-0.2,
                           max_steering_rate_rad_s=10.0)
        pred   = _predict(steer=0.5)
        result = MPCConstraintChecker(cfg).check(pred)
        for v in result.violations:
            assert len(v.description) > 0


# ---------------------------------------------------------------------------
# check_control convenience method
# ---------------------------------------------------------------------------

class TestCheckControlConvenience:
    def test_valid_control_returns_true(self):
        result = _checker().check_control(steering=0.0, acceleration=0.0)
        assert result is True

    def test_excessive_steering_returns_false(self):
        cfg    = MPCConfig(max_steering_rad=0.3, min_steering_rad=-0.3,
                           max_steering_rate_rad_s=10.0)
        result = MPCConstraintChecker(cfg).check_control(steering=0.5, acceleration=0.0)
        assert result is False

    def test_nan_steering_returns_false(self):
        result = _checker().check_control(steering=float("nan"), acceleration=0.0)
        assert result is False

    def test_inf_accel_returns_false(self):
        result = _checker().check_control(steering=0.0, acceleration=float("inf"))
        assert result is False
