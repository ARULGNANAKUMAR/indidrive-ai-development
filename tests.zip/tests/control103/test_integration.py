"""
Phase 10.3 — Integration Tests

Flow 1: Phase 9.6 planner output → Phase 10.2 tracking → Phase 10.3 MPC
Flow 2: Phase 10.1 vehicle state → MPC prediction

Verifies that Phase 10.3 consumes existing project representations
without rewriting them.
"""
import math

from core.control import (
    MPCController,
    MPCConfig,
    MPCSnapshot,
    MPCStatus,
    MPCPredictor,
)
from core.planning.candidate_path_types import PathPoint
from core.tracking.reference_trajectory import ReferenceTrajectory, ReferencePoint
from core.tracking.tracking_engine import TrackingEngine
from core.tracking.tracking_config import TrackingConfig
from core.vehicle.vehicle_state import VehicleState
from core.vehicle.vehicle_parameters import VehicleParameters
from core.vehicle.vehicle_types import CoordinateFrame, StateKind


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_path_points(n=15, step=2.0, heading=0.0, curvature=0.0):
    """Simulate PathPoint output from Phase 9.6 planner."""
    return [
        PathPoint(
            x=i * step,
            y=0.0,
            heading=heading,
            curvature=curvature,
            longitudinal_s=i * step,
        )
        for i in range(n)
    ]


def _ego_from_localisation(x=2.0, y=0.1, yaw=0.02, v=8.33):
    return VehicleState(
        x=x, y=y, yaw=yaw, velocity=v,
        timestamp=0.0, frame_id=1,
        coordinate_frame=CoordinateFrame.VEHICLE,
        state_kind=StateKind.ESTIMATED,
    )


def _default_ctrl():
    return MPCController(MPCConfig(
        prediction_horizon=8,
        dt=0.1,
        steering_samples=5,
        acceleration_samples=3,
        max_iterations=3,
        w_cross_track=2.0,
        w_heading=1.5,
        w_speed=0.0,
    ))


# ---------------------------------------------------------------------------
# Phase 9.6 → Phase 10.2 → Phase 10.3 integration
# ---------------------------------------------------------------------------

class TestPhase96To103Integration:
    def test_phase96_path_to_mpc_success(self):
        """
        Phase 9.6 planner output → ReferenceTrajectory (10.2) → MPC (10.3)
        Full pipeline without rewriting any representations.
        """
        path_pts = _make_path_points(n=15, step=2.0)
        ref      = ReferenceTrajectory.from_path_points(
            path_pts,
            frame_id=1,
            timestamp=0.0,
            reference_velocity=10.0,
        )
        ego  = _ego_from_localisation()
        ctrl = _default_ctrl()
        snap = ctrl.solve(ego, ref)

        assert snap.status == MPCStatus.SUCCESS
        assert snap.feasible
        assert math.isfinite(snap.total_cost)
        assert len(snap.predicted_states) == 9  # horizon+1

    def test_tracking_engine_then_mpc(self):
        """
        Phase 9.6 → TrackingEngine.update() → extract reference → MPC solve.
        Demonstrates the intended data flow.
        """
        path_pts = _make_path_points(n=15, step=2.0)
        ref      = ReferenceTrajectory.from_path_points(
            path_pts, reference_velocity=10.0
        )

        engine = TrackingEngine(TrackingConfig(max_reference_age_s=60.0))
        ego    = _ego_from_localisation()
        snap96 = engine.update(ego, ref)

        # Phase 10.3 MPC consumes the same reference directly
        ctrl = _default_ctrl()
        mpc_snap = ctrl.solve(ego, ref)

        assert snap96 is not None
        assert mpc_snap.feasible

    def test_mpc_output_does_not_modify_reference(self):
        """solve() must not mutate the input ReferenceTrajectory."""
        path_pts = _make_path_points(n=12)
        ref      = ReferenceTrajectory.from_path_points(path_pts)
        n_before = ref.length
        ctrl     = _default_ctrl()
        ctrl.solve(_ego_from_localisation(), ref)
        assert ref.length == n_before  # unchanged

    def test_mpc_first_control_within_bounds(self):
        """
        first_steering_input and first_acceleration_input must respect
        the configured MPC limits.
        """
        cfg  = MPCConfig(
            min_steering_rad=-0.4, max_steering_rad=0.4,
            min_acceleration_mps2=-5.0, max_acceleration_mps2=3.0,
            prediction_horizon=6, dt=0.1,
            steering_samples=7, acceleration_samples=5,
        )
        ctrl = MPCController(cfg)
        path_pts = _make_path_points(n=12)
        ref      = ReferenceTrajectory.from_path_points(path_pts)
        snap     = ctrl.solve(_ego_from_localisation(), ref)

        if snap.feasible:
            assert cfg.min_steering_rad - 1e-6 <= snap.first_steering_input <= cfg.max_steering_rad + 1e-6
            assert cfg.min_acceleration_mps2 - 1e-6 <= snap.first_acceleration_input <= cfg.max_acceleration_mps2 + 1e-6

    def test_curved_path_pipeline(self):
        """Curved Phase 9.6 path → ReferenceTrajectory → MPC."""
        n = 15
        radius = 20.0
        arc_total = math.pi / 4
        pts = []
        for i in range(n):
            theta = (i / (n - 1)) * arc_total
            pts.append(PathPoint(
                x=radius * math.sin(theta),
                y=radius * (1.0 - math.cos(theta)),
                heading=theta,
                curvature=1.0 / radius,
                longitudinal_s=radius * theta,
            ))
        ref  = ReferenceTrajectory.from_path_points(pts, reference_velocity=8.0)
        ctrl = _default_ctrl()
        snap = ctrl.solve(_ego_from_localisation(v=8.0), ref)

        # Should not raise; predicted states should be finite
        for s in snap.predicted_states:
            assert s.is_finite()


# ---------------------------------------------------------------------------
# Phase 10.1 vehicle state → MPC prediction integration
# ---------------------------------------------------------------------------

class TestPhase101To103Integration:
    def test_vehicle_state_to_prediction(self):
        """
        Phase 10.1 VehicleState → MPCPredictor uses bicycle model.
        """
        params = VehicleParameters.default()
        pred   = MPCPredictor(params)
        ego    = VehicleState(x=0.0, y=0.0, yaw=0.0, velocity=10.0)

        result = pred.predict_constant(ego, 0.0, 0.0, horizon=10, dt=0.1)
        assert result.valid
        assert len(result.states) == 11

    def test_vehicle_params_from_phase101(self):
        """MPCController uses Phase 10.1 VehicleParameters."""
        params = VehicleParameters.default()
        ctrl   = MPCController(vehicle_params=params)
        assert ctrl.vehicle_params is params

    def test_prediction_uses_phase101_bicycle_model(self):
        """
        Prediction output at v=10, dt=0.1, zero controls:
        Δx ≈ 1.0 m (forward Euler, Phase 10.1 bicycle model).
        """
        pred = MPCPredictor(VehicleParameters.default())
        ego  = VehicleState(x=0.0, y=0.0, yaw=0.0, velocity=10.0)
        r    = pred.predict_constant(ego, 0.0, 0.0, horizon=1, dt=0.1)
        assert r.valid
        dx = r.states[1].x - r.states[0].x
        assert abs(dx - 1.0) < 0.05  # Euler step: v*dt


# ---------------------------------------------------------------------------
# Receding horizon usage pattern
# ---------------------------------------------------------------------------

class TestRecedingHorizonPattern:
    def test_multi_step_receding_horizon(self):
        """
        Simulate multiple receding-horizon cycles.
        Each cycle uses the previous control output as prev_steering input.
        """
        ctrl  = _default_ctrl()
        ref   = ReferenceTrajectory.from_path_points(
            _make_path_points(n=30, step=1.0), reference_velocity=10.0
        )
        ego   = _ego_from_localisation(x=0.0, y=0.3, yaw=0.0, v=10.0)
        prev_s = 0.0
        prev_a = 0.0

        for cycle in range(5):
            snap = ctrl.solve(ego, ref, prev_steering=prev_s, prev_acceleration=prev_a)

            if snap.feasible:
                # Use first control for next cycle
                prev_s = snap.first_steering_input
                prev_a = snap.first_acceleration_input
                # Advance ego state manually (simplified — just update position)
                new_x = ego.x + ego.velocity * 0.1 * math.cos(ego.yaw)
                new_y = ego.y + ego.velocity * 0.1 * math.sin(ego.yaw)
                ego   = VehicleState(
                    x=new_x, y=new_y, yaw=ego.yaw,
                    velocity=ego.velocity, frame_id=cycle + 1,
                )
            # All snapshots must be structurally sound
            assert snap.schema_version == "10.3"
            for s in snap.predicted_states:
                assert s.is_finite()

    def test_solution_id_changes_every_cycle(self):
        """Every solve cycle has a unique solution_id."""
        ctrl = _default_ctrl()
        ref  = ReferenceTrajectory.from_path_points(_make_path_points())
        ids  = [ctrl.solve(_ego_from_localisation(), ref).solution_id for _ in range(4)]
        assert len(set(ids)) == 4  # all distinct
