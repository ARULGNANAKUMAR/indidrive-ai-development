"""
Phase 10.3 — Tests: Reference Trajectory handling

Tests:
    * valid trajectory
    * stale trajectory
    * invalid/empty trajectory
    * single-point trajectory
    * insufficient horizon points
    * curved trajectory
    * non-finite trajectory points
"""
import math
import time

from core.control import MPCController, MPCConfig, MPCStatus, MPCValidator
from core.tracking.reference_trajectory import ReferenceTrajectory, ReferencePoint
from core.vehicle.vehicle_state import VehicleState


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _ego(x=0.0, y=0.0, yaw=0.0, v=10.0):
    return VehicleState(x=x, y=y, yaw=yaw, velocity=v)


def _ctrl(horizon=8):
    return MPCController(
        MPCConfig(
            prediction_horizon=horizon,
            dt=0.1,
            steering_samples=5,
            acceleration_samples=3,
            max_iterations=2,
        )
    )


def _pts(n=15, step=1.0):
    return [ReferencePoint(x=float(i) * step, y=0.0, yaw=0.0) for i in range(n)]


# ---------------------------------------------------------------------------
# Valid trajectory
# ---------------------------------------------------------------------------

class TestValidTrajectory:
    def test_many_points_success(self):
        """Long trajectory → SUCCESS."""
        ref  = ReferenceTrajectory(points=_pts(30))
        snap = _ctrl().solve(_ego(), ref)
        assert snap.feasible

    def test_trajectory_with_velocity(self):
        """Trajectory with reference velocity → SUCCESS."""
        pts  = [ReferencePoint(x=float(i), y=0.0, yaw=0.0, velocity=10.0) for i in range(20)]
        ref  = ReferenceTrajectory(points=pts)
        snap = _ctrl().solve(_ego(v=10.0), ref)
        assert snap.feasible

    def test_trajectory_with_yaw(self):
        """Trajectory with yaw info → SUCCESS."""
        pts  = [ReferencePoint(x=float(i), y=0.0, yaw=0.0) for i in range(20)]
        ref  = ReferenceTrajectory(points=pts)
        snap = _ctrl().solve(_ego(), ref)
        assert snap.feasible


# ---------------------------------------------------------------------------
# Stale trajectory
# ---------------------------------------------------------------------------

class TestStaleTrajectory:
    def test_stale_reference_detected(self):
        """Trajectory with old timestamp → STALE_REFERENCE."""
        cfg = MPCConfig(max_reference_age_s=1.0)
        ctrl = MPCController(cfg)

        # Build a trajectory with a very old timestamp
        old_time = 0.001  # near-zero timestamp
        pts      = _pts(15)
        ref      = ReferenceTrajectory(points=pts, timestamp=old_time)

        # Ego has a recent timestamp
        ego = VehicleState(
            x=0.0, y=0.0, yaw=0.0, velocity=10.0,
            timestamp=1000.0,  # far in the future relative to ref
        )
        snap = ctrl.solve(ego, ref)
        assert snap.status == MPCStatus.STALE_REFERENCE
        assert not snap.feasible

    def test_fresh_reference_ok(self):
        """Trajectory with matching timestamp → NOT stale."""
        cfg = MPCConfig(max_reference_age_s=5.0)
        ctrl = MPCController(cfg)

        now = 100.0
        pts = _pts(15)
        ref = ReferenceTrajectory(points=pts, timestamp=now)
        ego = VehicleState(x=0.0, y=0.0, yaw=0.0, velocity=10.0, timestamp=now + 0.1)
        snap = ctrl.solve(ego, ref)
        assert snap.status != MPCStatus.STALE_REFERENCE

    def test_zero_timestamp_reference_not_stale(self):
        """Reference with timestamp=0 is not flagged stale by validator."""
        cfg = MPCConfig(max_reference_age_s=2.0)
        # timestamp=0.0 means "unknown" — validator skips staleness check
        result = MPCValidator.validate_reference(
            ReferenceTrajectory(points=_pts(5), timestamp=0.0),
            current_time=9999.0,
            max_age_s=2.0,
        )
        assert result.valid  # 0.0 timestamp treated as unknown, no stale flag


# ---------------------------------------------------------------------------
# Empty / None trajectory
# ---------------------------------------------------------------------------

class TestEmptyTrajectory:
    def test_empty_trajectory_invalid_reference(self):
        ref  = ReferenceTrajectory(points=[])
        snap = _ctrl().solve(_ego(), ref)
        assert snap.status == MPCStatus.INVALID_REFERENCE

    def test_none_trajectory_invalid_reference(self):
        snap = _ctrl().solve(_ego(), None)
        assert snap.status == MPCStatus.INVALID_REFERENCE

    def test_validator_rejects_none(self):
        r = MPCValidator.validate_reference(None)
        assert not r.valid

    def test_validator_rejects_empty(self):
        r = MPCValidator.validate_reference(ReferenceTrajectory(points=[]))
        assert not r.valid


# ---------------------------------------------------------------------------
# Single-point trajectory
# ---------------------------------------------------------------------------

class TestSinglePointTrajectory:
    def test_single_point_does_not_raise(self):
        """Single reference point should not crash the solver."""
        ref  = ReferenceTrajectory(points=[ReferencePoint(x=5.0, y=0.0, yaw=0.0)])
        snap = _ctrl().solve(_ego(), ref)
        # May succeed or not depending on constraints, but must not raise
        assert snap.status in (
            MPCStatus.SUCCESS,
            MPCStatus.NO_FEASIBLE_SOLUTION,
            MPCStatus.SOLVER_LIMIT_REACHED,
            MPCStatus.DEGRADED,
        )
        for s in snap.predicted_states:
            assert s.is_finite()

    def test_single_point_validator_passes(self):
        """Validator accepts single-point trajectory (≥1 point required)."""
        r = MPCValidator.validate_reference(
            ReferenceTrajectory(points=[ReferencePoint(x=0.0, y=0.0)]),
            min_points=1,
        )
        assert r.valid

    def test_single_point_validator_fails_min_2(self):
        """Validator rejects single-point when min_points=2."""
        r = MPCValidator.validate_reference(
            ReferenceTrajectory(points=[ReferencePoint(x=0.0, y=0.0)]),
            min_points=2,
        )
        assert not r.valid


# ---------------------------------------------------------------------------
# Insufficient horizon
# ---------------------------------------------------------------------------

class TestInsufficientHorizon:
    def test_short_trajectory_still_works(self):
        """Trajectory shorter than horizon still produces a result."""
        # Horizon=10, trajectory only 4 points
        ref  = ReferenceTrajectory(points=_pts(4))
        snap = _ctrl(horizon=10).solve(_ego(), ref)
        # Should not raise; cost/prediction still computed via repeated last point
        assert snap.status in (
            MPCStatus.SUCCESS,
            MPCStatus.NO_FEASIBLE_SOLUTION,
            MPCStatus.SOLVER_LIMIT_REACHED,
        )


# ---------------------------------------------------------------------------
# Curved trajectory
# ---------------------------------------------------------------------------

class TestCurvedTrajectory:
    def test_curved_left_arc(self):
        """Curved (arc) trajectory processed without errors."""
        n = 20
        radius = 15.0
        arc_total = math.pi / 4  # 45° arc
        pts = []
        for i in range(n):
            theta = (i / (n - 1)) * arc_total
            pts.append(ReferencePoint(
                x=radius * math.sin(theta),
                y=radius * (1.0 - math.cos(theta)),
                yaw=theta,
                velocity=8.0,
            ))
        ref  = ReferenceTrajectory(points=pts)
        snap = _ctrl().solve(_ego(v=8.0), ref)
        assert snap.status in (
            MPCStatus.SUCCESS,
            MPCStatus.NO_FEASIBLE_SOLUTION,
            MPCStatus.SOLVER_LIMIT_REACHED,
        )

    def test_sharp_curve_all_states_finite(self):
        """Sharp curve → all predicted states remain finite."""
        n = 15
        radius = 8.0
        arc_total = math.pi / 3
        pts = []
        for i in range(n):
            theta = (i / (n - 1)) * arc_total
            pts.append(ReferencePoint(
                x=radius * math.sin(theta),
                y=radius * (1.0 - math.cos(theta)),
                yaw=theta,
            ))
        ref  = ReferenceTrajectory(points=pts)
        snap = _ctrl().solve(_ego(v=5.0), ref)
        for s in snap.predicted_states:
            assert s.is_finite()


# ---------------------------------------------------------------------------
# Non-finite reference points
# ---------------------------------------------------------------------------

class TestNonFiniteReferencePoints:
    def test_validator_detects_nan_position(self):
        """Validator flags trajectory with NaN reference point position."""
        pts = [
            ReferencePoint(x=0.0, y=0.0),
            ReferencePoint(x=float("nan"), y=0.0),
            ReferencePoint(x=2.0, y=0.0),
        ]
        ref = ReferenceTrajectory(points=pts)
        r   = MPCValidator.validate_reference(ref)
        assert not r.valid
