"""
Phase 10.3 — Negative Scope Tests

Explicitly confirms that Phase 10.3 does NOT implement Phase 10.4+ concepts.

The Phase 10.3 public result (MPCSnapshot) must NOT contain:
    * throttle actuator command
    * brake actuator command
    * CAN command
    * CARLA vehicle control
    * hardware actuator command
    * PID controller
    * Pure Pursuit controller
    * Stanley controller
    * LQR controller
    * final actuator execution loop
    * planner generation / replanning

MPC may expose mathematical steering/acceleration optimisation variables.
These are NOT actuator commands.
"""
import math

from core.control import (
    MPCController,
    MPCConfig,
    MPCSnapshot,
    MPCControlInput,
)
from core.tracking.reference_trajectory import ReferenceTrajectory, ReferencePoint
from core.vehicle.vehicle_state import VehicleState


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _ego(v=10.0):
    return VehicleState(x=0.0, y=0.0, yaw=0.0, velocity=v)


def _ref():
    return ReferenceTrajectory(points=[
        ReferencePoint(x=float(i), y=0.0, yaw=0.0) for i in range(20)
    ])


def _snap():
    return MPCController(MPCConfig(prediction_horizon=5, dt=0.1,
                                    steering_samples=3, acceleration_samples=2)).solve(_ego(), _ref())


# ---------------------------------------------------------------------------
# MPCSnapshot has NO actuator-level fields
# ---------------------------------------------------------------------------

class TestNoActuatorFields:
    def test_no_throttle_attribute(self):
        """MPCSnapshot must NOT have a throttle attribute."""
        snap = _snap()
        assert not hasattr(snap, "throttle"), \
            "throttle is a Phase 10.4 actuator field, not an MPC output"

    def test_no_brake_attribute(self):
        """MPCSnapshot must NOT have a brake attribute."""
        snap = _snap()
        assert not hasattr(snap, "brake"), \
            "brake is a Phase 10.4 actuator field, not an MPC output"

    def test_no_throttle_percent_attribute(self):
        snap = _snap()
        assert not hasattr(snap, "throttle_percent")
        assert not hasattr(snap, "throttle_pct")
        assert not hasattr(snap, "throttle_percentage")

    def test_no_brake_percent_attribute(self):
        snap = _snap()
        assert not hasattr(snap, "brake_percent")
        assert not hasattr(snap, "brake_pct")
        assert not hasattr(snap, "brake_percentage")

    def test_no_can_command_attribute(self):
        """MPCSnapshot must NOT have CAN bus command fields."""
        snap = _snap()
        assert not hasattr(snap, "can_command")
        assert not hasattr(snap, "can_frame")
        assert not hasattr(snap, "can_msg")

    def test_no_carla_control_attribute(self):
        """MPCSnapshot must NOT embed a CARLA VehicleControl object."""
        snap = _snap()
        assert not hasattr(snap, "carla_control")
        assert not hasattr(snap, "vehicle_control")
        assert not hasattr(snap, "carla_vehicle_control")

    def test_no_hardware_command_attribute(self):
        snap = _snap()
        assert not hasattr(snap, "hardware_command")
        assert not hasattr(snap, "actuator_command")

    def test_no_steer_actuator_command(self):
        """steering_actuator_command is a Phase 10.4+ concept."""
        snap = _snap()
        assert not hasattr(snap, "steering_actuator_command")
        assert not hasattr(snap, "steer_cmd")


# ---------------------------------------------------------------------------
# MPCControlInput has NO actuator-level fields
# ---------------------------------------------------------------------------

class TestControlInputNoActuators:
    def test_control_input_no_throttle(self):
        c = MPCControlInput(steering_input=0.1, acceleration_input=1.0)
        assert not hasattr(c, "throttle")

    def test_control_input_no_brake(self):
        c = MPCControlInput(steering_input=0.1, acceleration_input=-1.0)
        assert not hasattr(c, "brake")

    def test_control_input_no_can(self):
        c = MPCControlInput()
        assert not hasattr(c, "can_command")

    def test_control_input_steering_is_angle_rad(self):
        """steering_input is a steering ANGLE (rad), not an actuator command."""
        c = MPCControlInput(steering_input=0.1)
        # Must be a float (angle), not a dict or object
        assert isinstance(c.steering_input, float)

    def test_control_input_acceleration_is_mps2(self):
        """acceleration_input is in m/s², not a throttle percentage."""
        c = MPCControlInput(acceleration_input=2.0)
        assert isinstance(c.acceleration_input, float)


# ---------------------------------------------------------------------------
# No legacy controllers in the MPC module
# ---------------------------------------------------------------------------

class TestNoLegacyControllers:
    def test_no_pid_in_control_module(self):
        """core.control must NOT contain a PID controller class."""
        import core.control as cm
        names = dir(cm)
        pid_names = [n for n in names if "PID" in n or "pid" in n.lower()]
        # Allow 'pid' to appear in strings but not as a class
        pid_classes = [n for n in pid_names if isinstance(getattr(cm, n, None), type)]
        assert len(pid_classes) == 0, \
            f"Found PID class(es) in core.control: {pid_classes}"

    def test_no_pure_pursuit_in_control_module(self):
        import core.control as cm
        pp_names = [n for n in dir(cm)
                    if "pure_pursuit" in n.lower() or "purepursuit" in n.lower()]
        assert len(pp_names) == 0

    def test_no_stanley_in_control_module(self):
        import core.control as cm
        st_names = [n for n in dir(cm) if "stanley" in n.lower()]
        assert len(st_names) == 0

    def test_no_lqr_in_control_module(self):
        import core.control as cm
        lq_names = [n for n in dir(cm) if "LQR" in n or "lqr" in n.lower()]
        assert len(lq_names) == 0


# ---------------------------------------------------------------------------
# No planner logic in the MPC module
# ---------------------------------------------------------------------------

class TestNoPlannerInMPC:
    def test_mpc_controller_has_no_replan_method(self):
        ctrl = MPCController()
        assert not hasattr(ctrl, "replan")
        assert not hasattr(ctrl, "generate_path")
        assert not hasattr(ctrl, "select_path")

    def test_mpc_controller_has_no_world_model(self):
        ctrl = MPCController()
        assert not hasattr(ctrl, "world_model")
        assert not hasattr(ctrl, "perception")
        assert not hasattr(ctrl, "prediction")


# ---------------------------------------------------------------------------
# No CARLA integration in Phase 10.3
# ---------------------------------------------------------------------------

class TestNoCARLAInPhase103:
    def test_no_carla_import_in_control_module(self):
        """core.control must not import CARLA."""
        import ast, os, glob

        control_dir = os.path.join(
            os.path.dirname(__file__),
            "../../core/control"
        )
        py_files = glob.glob(os.path.join(control_dir, "*.py"))
        for fpath in py_files:
            with open(fpath) as f:
                source = f.read()
            tree = ast.parse(source, filename=fpath)
            for node in ast.walk(tree):
                if isinstance(node, (ast.Import, ast.ImportFrom)):
                    mod = ""
                    if isinstance(node, ast.Import):
                        mod = " ".join(a.name for a in node.names)
                    else:
                        mod = node.module or ""
                    assert "carla" not in mod.lower(), \
                        f"CARLA import found in {fpath}: {mod}"


# ---------------------------------------------------------------------------
# Snapshot first_control naming is unambiguous
# ---------------------------------------------------------------------------

class TestFirstControlNaming:
    def test_first_control_named_steering_input_not_command(self):
        """The field is named 'first_steering_INPUT', not 'first_steering_COMMAND'."""
        snap = _snap()
        assert hasattr(snap, "first_steering_input")
        assert not hasattr(snap, "first_steering_command")

    def test_first_control_named_acceleration_input_not_command(self):
        snap = _snap()
        assert hasattr(snap, "first_acceleration_input")
        assert not hasattr(snap, "first_acceleration_command")

    def test_first_steering_input_is_angle_not_percentage(self):
        """first_steering_input must be a finite float in radians range."""
        snap = _snap()
        if snap.feasible:
            # Must be in rad range (not 0-100%)
            assert abs(snap.first_steering_input) <= math.pi
            assert isinstance(snap.first_steering_input, float)

    def test_first_acceleration_in_mps2_range(self):
        """first_acceleration_input is in m/s², not a throttle %."""
        snap = _snap()
        if snap.feasible:
            # Reasonable m/s² range (not 0-100)
            assert abs(snap.first_acceleration_input) < 50.0
            assert isinstance(snap.first_acceleration_input, float)
