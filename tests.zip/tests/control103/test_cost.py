"""
Phase 10.3 — Tests: Cost Function (MPCCostCalculator)

Tests:
    * zero tracking error → near-zero tracking cost
    * non-zero cross-track error
    * heading error
    * speed error (when reference velocity available)
    * control effort
    * control rate
    * total cost composition
    * terminal cost
    * numerical safety
"""
import math

from core.control import (
    MPCConfig,
    MPCCostCalculator,
    MPCControlInput,
    MPCPredictor,
    CostResult,
)
from core.tracking.reference_trajectory import ReferenceTrajectory, ReferencePoint
from core.vehicle.vehicle_state import VehicleState
from core.vehicle.vehicle_parameters import VehicleParameters


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _ego(x=0.0, y=0.0, yaw=0.0, v=10.0):
    return VehicleState(x=x, y=y, yaw=yaw, velocity=v)


def _straight_ref(n=20, step=1.0, velocity=10.0):
    pts = [
        ReferencePoint(x=float(i) * step, y=0.0, yaw=0.0, velocity=velocity)
        for i in range(n)
    ]
    return ReferenceTrajectory(points=pts)


def _predict_straight(v=10.0, steer=0.0, accel=0.0, n=10):
    pred = MPCPredictor(VehicleParameters.default())
    ego  = _ego(v=v)
    ctrls = [
        MPCControlInput(steering_input=steer, acceleration_input=accel, step_index=i)
        for i in range(n)
    ]
    return pred.predict(ego, ctrls, dt=0.1)


def _cfg(**kwargs):
    return MPCConfig(**kwargs) if kwargs else MPCConfig.default()


def _calc(cfg=None):
    return MPCCostCalculator(cfg or _cfg())


# ---------------------------------------------------------------------------
# Zero tracking error
# ---------------------------------------------------------------------------

class TestZeroTrackingError:
    def test_on_path_tracking_cost_near_zero(self):
        """Ego exactly on path, no speed error → tracking cost ≈ 0."""
        cfg  = MPCConfig(
            w_cross_track=2.0, w_along_track=0.5, w_heading=1.0,
            w_speed=1.0, w_steering=0.0, w_acceleration=0.0,
            w_steering_rate=0.0, w_acceleration_rate=0.0, w_terminal=0.0,
        )
        ref  = _straight_ref(velocity=10.0)
        pred = _predict_straight(v=10.0, steer=0.0, accel=0.0, n=10)
        cost = MPCCostCalculator(cfg).compute(pred, ref)
        assert cost.valid
        # Tracking cost should be very small (near-zero CTE/ATE/heading/speed)
        assert cost.tracking_cost < 0.5

    def test_total_cost_finite_and_positive(self):
        """Total cost is finite and ≥ 0."""
        ref  = _straight_ref(velocity=10.0)
        pred = _predict_straight(v=10.0, steer=0.0, accel=0.0, n=10)
        cost = _calc().compute(pred, ref)
        assert cost.valid
        assert math.isfinite(cost.total_cost)
        assert cost.total_cost >= 0.0


# ---------------------------------------------------------------------------
# Cross-track error
# ---------------------------------------------------------------------------

class TestCrossTrackError:
    def test_lateral_offset_increases_cost(self):
        """Ego offset laterally from path → tracking cost increases."""
        cfg = MPCConfig(w_cross_track=2.0, w_terminal=0.0,
                        w_along_track=0.0, w_heading=0.0, w_speed=0.0,
                        w_steering=0.0, w_acceleration=0.0,
                        w_steering_rate=0.0, w_acceleration_rate=0.0)
        ref  = _straight_ref(velocity=None)

        # Ego ON path
        pred_on = MPCPredictor(VehicleParameters.default()).predict(
            _ego(x=0.0, y=0.0, v=10.0),
            [MPCControlInput(0.0, 0.0, i) for i in range(10)], dt=0.1
        )
        cost_on = MPCCostCalculator(cfg).compute(pred_on, ref)

        # Ego OFF path (lateral offset y=0.5 m)
        pred_off = MPCPredictor(VehicleParameters.default()).predict(
            _ego(x=0.0, y=0.5, v=10.0),
            [MPCControlInput(0.0, 0.0, i) for i in range(10)], dt=0.1
        )
        cost_off = MPCCostCalculator(cfg).compute(pred_off, ref)

        assert cost_on.valid and cost_off.valid
        assert cost_off.tracking_cost > cost_on.tracking_cost


# ---------------------------------------------------------------------------
# Heading error
# ---------------------------------------------------------------------------

class TestHeadingError:
    def test_heading_error_increases_cost(self):
        """Ego misaligned with path → higher heading cost."""
        cfg = MPCConfig(w_cross_track=0.0, w_along_track=0.0,
                        w_heading=2.0, w_speed=0.0, w_terminal=0.0,
                        w_steering=0.0, w_acceleration=0.0,
                        w_steering_rate=0.0, w_acceleration_rate=0.0)
        ref = _straight_ref(velocity=None)

        # Aligned
        pred_aligned = MPCPredictor(VehicleParameters.default()).predict(
            _ego(yaw=0.0, v=10.0),
            [MPCControlInput(0.0, 0.0, i) for i in range(10)], dt=0.1
        )
        cost_aligned = MPCCostCalculator(cfg).compute(pred_aligned, ref)

        # Misaligned (heading error ~0.2 rad)
        pred_mis = MPCPredictor(VehicleParameters.default()).predict(
            _ego(yaw=0.2, v=10.0),
            [MPCControlInput(0.0, 0.0, i) for i in range(10)], dt=0.1
        )
        cost_mis = MPCCostCalculator(cfg).compute(pred_mis, ref)

        assert cost_aligned.valid and cost_mis.valid
        assert cost_mis.tracking_cost > cost_aligned.tracking_cost


# ---------------------------------------------------------------------------
# Speed error
# ---------------------------------------------------------------------------

class TestSpeedError:
    def test_speed_error_increases_cost(self):
        """Ego speed ≠ reference velocity → speed error cost."""
        cfg = MPCConfig(w_cross_track=0.0, w_along_track=0.0,
                        w_heading=0.0, w_speed=2.0, w_terminal=0.0,
                        w_steering=0.0, w_acceleration=0.0,
                        w_steering_rate=0.0, w_acceleration_rate=0.0)

        # Match: ego v=10, ref v=10
        ref_10 = _straight_ref(velocity=10.0)
        pred   = MPCPredictor(VehicleParameters.default()).predict(
            _ego(v=10.0), [MPCControlInput(0.0, 0.0, i) for i in range(10)], dt=0.1
        )
        cost_match = MPCCostCalculator(cfg).compute(pred, ref_10)

        # Mismatch: ego v=10, ref v=15
        ref_15 = _straight_ref(velocity=15.0)
        cost_mismatch = MPCCostCalculator(cfg).compute(pred, ref_15)

        assert cost_match.valid and cost_mismatch.valid
        assert cost_mismatch.tracking_cost > cost_match.tracking_cost

    def test_no_speed_error_when_ref_velocity_none(self):
        """No speed cost when reference point has velocity=None."""
        cfg = MPCConfig(w_speed=5.0, w_cross_track=0.0, w_along_track=0.0,
                        w_heading=0.0, w_terminal=0.0,
                        w_steering=0.0, w_acceleration=0.0,
                        w_steering_rate=0.0, w_acceleration_rate=0.0)

        ref_no_v = ReferenceTrajectory(points=[
            ReferencePoint(x=float(i), y=0.0, yaw=0.0, velocity=None)
            for i in range(20)
        ])
        pred = MPCPredictor(VehicleParameters.default()).predict(
            _ego(v=10.0), [MPCControlInput(0.0, 0.0, i) for i in range(10)], dt=0.1
        )
        cost = MPCCostCalculator(cfg).compute(pred, ref_no_v)
        assert cost.valid
        # tracking_cost should be ~0 (no CTE/heading, no speed term)
        assert cost.tracking_cost < 0.1


# ---------------------------------------------------------------------------
# Control effort
# ---------------------------------------------------------------------------

class TestControlEffortCost:
    def test_zero_controls_zero_effort(self):
        """Zero steering + zero acceleration → control effort cost = 0."""
        cfg = MPCConfig(w_cross_track=0.0, w_along_track=0.0,
                        w_heading=0.0, w_speed=0.0, w_terminal=0.0,
                        w_steering=2.0, w_acceleration=2.0,
                        w_steering_rate=0.0, w_acceleration_rate=0.0)
        pred = _predict_straight(steer=0.0, accel=0.0)
        ref  = _straight_ref()
        cost = MPCCostCalculator(cfg).compute(pred, ref)
        assert cost.valid
        assert cost.control_cost < 1e-9

    def test_nonzero_steering_nonzero_effort(self):
        """Non-zero steering → positive control effort cost."""
        cfg = MPCConfig(w_cross_track=0.0, w_along_track=0.0,
                        w_heading=0.0, w_speed=0.0, w_terminal=0.0,
                        w_steering=2.0, w_acceleration=0.0,
                        w_steering_rate=0.0, w_acceleration_rate=0.0)
        pred = _predict_straight(steer=0.1)
        ref  = _straight_ref()
        cost = MPCCostCalculator(cfg).compute(pred, ref)
        assert cost.valid
        assert cost.control_cost > 0.0

    def test_larger_steering_higher_effort(self):
        """Larger steering magnitude → higher control effort."""
        cfg = MPCConfig(w_cross_track=0.0, w_along_track=0.0,
                        w_heading=0.0, w_speed=0.0, w_terminal=0.0,
                        w_steering=1.0, w_acceleration=0.0,
                        w_steering_rate=0.0, w_acceleration_rate=0.0)
        ref  = _straight_ref()
        p1   = _predict_straight(steer=0.1)
        p2   = _predict_straight(steer=0.3)
        c1   = MPCCostCalculator(cfg).compute(p1, ref)
        c2   = MPCCostCalculator(cfg).compute(p2, ref)
        assert c1.valid and c2.valid
        assert c2.control_cost > c1.control_cost


# ---------------------------------------------------------------------------
# Control rate cost
# ---------------------------------------------------------------------------

class TestControlRateCost:
    def test_large_steering_change_higher_rate_cost(self):
        """Large Δsteering → higher rate cost."""
        cfg = MPCConfig(w_cross_track=0.0, w_along_track=0.0,
                        w_heading=0.0, w_speed=0.0, w_terminal=0.0,
                        w_steering=0.0, w_acceleration=0.0,
                        w_steering_rate=2.0, w_acceleration_rate=0.0)
        ref = _straight_ref()
        pred = _predict_straight(steer=0.1)

        cost_small_change = MPCCostCalculator(cfg).compute(
            pred, ref, prev_steering=0.09, prev_acceleration=0.0
        )
        cost_large_change = MPCCostCalculator(cfg).compute(
            pred, ref, prev_steering=0.0, prev_acceleration=0.0
        )
        assert cost_small_change.valid and cost_large_change.valid
        assert cost_large_change.rate_cost > cost_small_change.rate_cost

    def test_same_controls_zero_rate_cost(self):
        """No change from prev → rate cost near zero."""
        cfg = MPCConfig(w_cross_track=0.0, w_along_track=0.0,
                        w_heading=0.0, w_speed=0.0, w_terminal=0.0,
                        w_steering=0.0, w_acceleration=0.0,
                        w_steering_rate=2.0, w_acceleration_rate=2.0)
        pred = _predict_straight(steer=0.1, accel=1.0)
        ref  = _straight_ref()
        cost = MPCCostCalculator(cfg).compute(
            pred, ref, prev_steering=0.1, prev_acceleration=1.0
        )
        assert cost.valid
        assert cost.rate_cost < 1e-9


# ---------------------------------------------------------------------------
# Total cost composition
# ---------------------------------------------------------------------------

class TestTotalCostComposition:
    def test_total_equals_sum_of_components(self):
        """total_cost = tracking + control + rate."""
        pred = _predict_straight(steer=0.1, accel=0.5)
        ref  = _straight_ref(velocity=10.0)
        cost = MPCCostCalculator(MPCConfig.default()).compute(pred, ref)
        assert cost.valid
        expected = cost.tracking_cost + cost.control_cost + cost.rate_cost
        assert abs(cost.total_cost - expected) < 1e-9

    def test_all_weights_zero_zero_cost(self):
        """All weights = 0 → total cost = 0."""
        cfg = MPCConfig(
            w_cross_track=0.0, w_along_track=0.0, w_heading=0.0,
            w_speed=0.0, w_terminal=0.0,
            w_steering=0.0, w_acceleration=0.0,
            w_steering_rate=0.0, w_acceleration_rate=0.0,
        )
        pred = _predict_straight()
        ref  = _straight_ref()
        cost = MPCCostCalculator(cfg).compute(pred, ref)
        assert cost.valid
        assert abs(cost.total_cost) < 1e-12

    def test_step_costs_available(self):
        """step_costs list has correct length."""
        pred = _predict_straight(n=8)
        ref  = _straight_ref()
        cost = MPCCostCalculator(MPCConfig.default()).compute(pred, ref)
        assert cost.valid
        assert len(cost.step_costs) == 8


# ---------------------------------------------------------------------------
# Terminal cost
# ---------------------------------------------------------------------------

class TestTerminalCost:
    def test_terminal_cost_enabled(self):
        """With w_terminal > 0, terminal_cost > 0 when ego not on path."""
        cfg = MPCConfig(
            w_cross_track=1.0, w_along_track=0.0, w_heading=0.0,
            w_speed=0.0, w_terminal=5.0,
            w_steering=0.0, w_acceleration=0.0,
            w_steering_rate=0.0, w_acceleration_rate=0.0,
        )
        # Ego offset from path
        pred = MPCPredictor(VehicleParameters.default()).predict(
            _ego(y=1.0, v=10.0),
            [MPCControlInput(0.0, 0.0, i) for i in range(10)], dt=0.1
        )
        ref  = _straight_ref()
        cost = MPCCostCalculator(cfg).compute(pred, ref)
        assert cost.valid
        assert cost.terminal_cost > 0.0

    def test_terminal_cost_disabled(self):
        """With w_terminal = 0, terminal_cost = 0."""
        cfg = MPCConfig(
            w_cross_track=1.0, w_along_track=0.0, w_heading=0.0,
            w_speed=0.0, w_terminal=0.0,
            w_steering=0.0, w_acceleration=0.0,
            w_steering_rate=0.0, w_acceleration_rate=0.0,
        )
        pred = MPCPredictor(VehicleParameters.default()).predict(
            _ego(y=1.0, v=10.0),
            [MPCControlInput(0.0, 0.0, i) for i in range(10)], dt=0.1
        )
        ref  = _straight_ref()
        cost = MPCCostCalculator(cfg).compute(pred, ref)
        assert cost.valid
        assert abs(cost.terminal_cost) < 1e-12


# ---------------------------------------------------------------------------
# Cost numerical safety
# ---------------------------------------------------------------------------

class TestCostNumericalSafety:
    def test_invalid_prediction_returns_inf(self):
        from core.control import PredictionResult
        bad = PredictionResult(states=[], controls=[], valid=False, error_message="bad")
        ref  = _straight_ref()
        cost = _calc().compute(bad, ref)
        assert not cost.valid
        assert math.isinf(cost.total_cost)

    def test_empty_reference_returns_inf(self):
        pred = _predict_straight()
        ref  = ReferenceTrajectory(points=[])
        cost = _calc().compute(pred, ref)
        assert not cost.valid
        assert math.isinf(cost.total_cost)

    def test_single_point_reference_ok(self):
        """Single reference point should still produce a valid cost."""
        pred = _predict_straight()
        ref  = ReferenceTrajectory(points=[ReferencePoint(x=5.0, y=0.0, yaw=0.0)])
        cost = _calc().compute(pred, ref)
        assert cost.valid
        assert math.isfinite(cost.total_cost)
