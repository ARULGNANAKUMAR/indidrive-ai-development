"""
Phase 10.3 — Tests: Solver (MPCSolver / MPSController end-to-end)

Tests:
    * valid feasible solution returned
    * no feasible solution case
    * deterministic solution (same inputs → same output)
    * iteration limit
    * malformed input
    * empty trajectory
    * snapshot structure
"""
import math

from core.control import (
    MPCController,
    MPCConfig,
    MPCSolver,
    MPCSnapshot,
    MPCStatus,
    ConstraintStatus,
    SolverStrategy,
)
from core.tracking.reference_trajectory import ReferenceTrajectory, ReferencePoint
from core.vehicle.vehicle_state import VehicleState
from core.vehicle.vehicle_parameters import VehicleParameters


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _ego(x=0.0, y=0.0, yaw=0.0, v=10.0):
    return VehicleState(x=x, y=y, yaw=yaw, velocity=v)


def _straight_ref(n=20, step=1.0, velocity=10.0):
    pts = [
        ReferencePoint(x=float(i) * step, y=0.0, yaw=0.0, velocity=velocity)
        for i in range(n)
    ]
    return ReferenceTrajectory(points=pts)


def _curved_ref(radius=20.0, n=20, velocity=8.0):
    """Arc of given radius turning left."""
    pts = []
    arc_total = math.pi / 3  # 60° arc
    for i in range(n):
        theta = (i / max(1, n - 1)) * arc_total
        x = radius * math.sin(theta)
        y = radius * (1.0 - math.cos(theta))
        yaw = theta
        pts.append(ReferencePoint(x=x, y=y, yaw=yaw, velocity=velocity))
    return ReferenceTrajectory(points=pts)


def _ctrl(horizon=10):
    return MPCController(
        MPCConfig(
            prediction_horizon=horizon,
            dt=0.1,
            steering_samples=5,
            acceleration_samples=3,
            max_iterations=3,
        )
    )


# ---------------------------------------------------------------------------
# Feasible solution
# ---------------------------------------------------------------------------

class TestFeasibleSolution:
    def test_straight_line_success(self):
        """Ego on straight path → SUCCESS."""
        snap = _ctrl().solve(_ego(), _straight_ref())
        assert snap.status == MPCStatus.SUCCESS
        assert snap.feasible

    def test_snapshot_has_predicted_states(self):
        """Success snapshot has N+1 predicted states."""
        cfg  = MPCConfig(prediction_horizon=8, dt=0.1,
                         steering_samples=5, acceleration_samples=3)
        ctrl = MPCController(cfg)
        snap = ctrl.solve(_ego(), _straight_ref())
        assert snap.feasible
        assert len(snap.predicted_states) == 9  # horizon+1

    def test_snapshot_has_control_sequence(self):
        """Success snapshot has N control inputs."""
        cfg  = MPCConfig(prediction_horizon=8, dt=0.1,
                         steering_samples=5, acceleration_samples=3)
        ctrl = MPCController(cfg)
        snap = ctrl.solve(_ego(), _straight_ref())
        assert snap.feasible
        assert len(snap.control_sequence) == 8

    def test_first_control_is_finite(self):
        """first_steering_input and first_acceleration_input are finite."""
        snap = _ctrl().solve(_ego(), _straight_ref())
        assert snap.feasible
        assert math.isfinite(snap.first_steering_input)
        assert math.isfinite(snap.first_acceleration_input)

    def test_total_cost_finite_on_success(self):
        snap = _ctrl().solve(_ego(), _straight_ref())
        assert snap.feasible
        assert math.isfinite(snap.total_cost)

    def test_cost_breakdown_sums_to_total(self):
        """tracking + control + rate = total (within floating-point tolerance)."""
        snap = _ctrl().solve(_ego(), _straight_ref())
        assert snap.feasible
        expected = snap.tracking_cost + snap.control_cost + snap.rate_cost
        assert abs(snap.total_cost - expected) < 1e-6

    def test_frame_id_matches_ego(self):
        """Snapshot frame_id matches ego state frame_id."""
        ego  = VehicleState(x=0.0, y=0.0, yaw=0.0, velocity=10.0, frame_id=42)
        snap = _ctrl().solve(ego, _straight_ref())
        assert snap.frame_id == 42

    def test_iterations_positive_on_success(self):
        snap = _ctrl().solve(_ego(), _straight_ref())
        assert snap.feasible
        assert snap.iterations >= 1

    def test_candidates_evaluated_positive(self):
        snap = _ctrl().solve(_ego(), _straight_ref())
        assert snap.feasible
        assert snap.candidates_evaluated > 0

    def test_constraint_status_satisfied_on_success(self):
        snap = _ctrl().solve(_ego(), _straight_ref())
        assert snap.feasible
        assert snap.constraint_status == ConstraintStatus.SATISFIED


# ---------------------------------------------------------------------------
# No feasible solution
# ---------------------------------------------------------------------------

class TestNoFeasibleSolution:
    def test_impossible_velocity_constraint_infeasible(self):
        """
        Config with max_velocity = 0.0001 m/s and ego at v=10 m/s.
        All predicted states will exceed max_velocity → no feasible candidate.
        """
        cfg = MPCConfig(
            max_velocity_mps=0.0001,
            min_velocity_mps=0.0,
            min_acceleration_mps2=-0.0001,
            max_acceleration_mps2=0.0001,
            prediction_horizon=5,
            dt=0.1,
            steering_samples=3,
            acceleration_samples=2,
            max_iterations=2,
        )
        ctrl = MPCController(cfg)
        snap = ctrl.solve(_ego(v=10.0), _straight_ref())
        assert not snap.feasible
        assert snap.status in (
            MPCStatus.NO_FEASIBLE_SOLUTION,
            MPCStatus.SOLVER_LIMIT_REACHED,
        )
        assert math.isinf(snap.total_cost)


# ---------------------------------------------------------------------------
# Determinism
# ---------------------------------------------------------------------------

class TestDeterminism:
    def test_same_inputs_same_steering(self):
        """Same (state, reference, config) → same first_steering_input."""
        ctrl = _ctrl()
        ref  = _straight_ref()
        ego  = _ego(x=0.5, y=0.2, yaw=0.05, v=9.0)
        s1   = ctrl.solve(ego, ref)
        s2   = ctrl.solve(ego, ref)
        assert s1.first_steering_input == s2.first_steering_input

    def test_same_inputs_same_acceleration(self):
        """Same inputs → same first_acceleration_input."""
        ctrl = _ctrl()
        ref  = _straight_ref()
        ego  = _ego(x=0.5, y=0.2, yaw=0.05, v=9.0)
        s1   = ctrl.solve(ego, ref)
        s2   = ctrl.solve(ego, ref)
        assert s1.first_acceleration_input == s2.first_acceleration_input

    def test_same_inputs_same_cost(self):
        """Same inputs → same total_cost."""
        ctrl = _ctrl()
        ref  = _straight_ref()
        ego  = _ego(x=0.5, y=0.2, yaw=0.05, v=9.0)
        s1   = ctrl.solve(ego, ref)
        s2   = ctrl.solve(ego, ref)
        assert s1.total_cost == s2.total_cost

    def test_different_states_different_controls(self):
        """Different ego positions produce different optimal controls (typically)."""
        ctrl = _ctrl()
        ref  = _straight_ref()
        s_left  = ctrl.solve(_ego(y=1.0, v=10.0), ref)   # ego left of path
        s_right = ctrl.solve(_ego(y=-1.0, v=10.0), ref)  # ego right of path
        # Both should be feasible
        assert s_left.feasible and s_right.feasible
        # Controls should steer in opposite directions
        # (left offset → negative steering to correct; right → positive)
        # Not guaranteed by every config, but for default weights should differ
        assert s_left.first_steering_input != s_right.first_steering_input


# ---------------------------------------------------------------------------
# Invalid inputs
# ---------------------------------------------------------------------------

class TestInvalidInputs:
    def test_none_reference_invalid(self):
        ctrl = _ctrl()
        snap = ctrl.solve(_ego(), None)
        assert snap.status == MPCStatus.INVALID_REFERENCE
        assert not snap.feasible

    def test_empty_reference_invalid(self):
        ctrl = _ctrl()
        empty = ReferenceTrajectory(points=[])
        snap = ctrl.solve(_ego(), empty)
        assert snap.status == MPCStatus.INVALID_REFERENCE
        assert not snap.feasible

    def test_nan_state_invalid_input(self):
        ctrl = _ctrl()
        bad  = VehicleState(x=float("nan"), y=0.0, yaw=0.0, velocity=10.0)
        snap = ctrl.solve(bad, _straight_ref())
        assert snap.status == MPCStatus.INVALID_INPUT
        assert not snap.feasible

    def test_nan_prev_steering_invalid_input(self):
        ctrl = _ctrl()
        snap = ctrl.solve(_ego(), _straight_ref(), prev_steering=float("nan"))
        assert snap.status == MPCStatus.INVALID_INPUT
        assert not snap.feasible

    def test_inf_prev_acceleration_invalid_input(self):
        ctrl = _ctrl()
        snap = ctrl.solve(_ego(), _straight_ref(), prev_acceleration=float("inf"))
        assert snap.status == MPCStatus.INVALID_INPUT
        assert not snap.feasible


# ---------------------------------------------------------------------------
# Snapshot structure
# ---------------------------------------------------------------------------

class TestSnapshotStructure:
    def test_snapshot_is_frozen(self):
        """MPCSnapshot is immutable (frozen dataclass)."""
        snap = _ctrl().solve(_ego(), _straight_ref())
        try:
            snap.feasible = not snap.feasible
            assert False, "Expected AttributeError (frozen)"
        except (AttributeError, TypeError):
            pass  # expected

    def test_failure_snapshot_has_solution_id(self):
        """Even a failure snapshot has a solution_id."""
        ctrl = _ctrl()
        snap = ctrl.solve(_ego(), None)
        assert isinstance(snap.solution_id, str)
        assert len(snap.solution_id) > 0

    def test_failure_total_cost_is_inf(self):
        snap = _ctrl().solve(_ego(), None)
        assert math.isinf(snap.total_cost)

    def test_success_snap_timestamp_positive(self):
        snap = _ctrl().solve(_ego(), _straight_ref())
        assert snap.snap_timestamp > 0.0

    def test_solver_message_non_empty_on_success(self):
        snap = _ctrl().solve(_ego(), _straight_ref())
        assert isinstance(snap.solver_message, str)
        assert len(snap.solver_message) > 0


# ---------------------------------------------------------------------------
# Curved path
# ---------------------------------------------------------------------------

class TestCurvedPath:
    def test_curved_path_feasible(self):
        """Curved reference trajectory → solver still finds a solution."""
        snap = _ctrl().solve(_ego(v=8.0), _curved_ref())
        assert snap.feasible or snap.status == MPCStatus.NO_FEASIBLE_SOLUTION
        # We don't assert SUCCESS because tight constraints may limit options;
        # but we do assert no exception is raised and status is meaningful.

    def test_curved_path_all_predicted_states_finite(self):
        """All predicted states after solve are finite (no NaN)."""
        snap = _ctrl().solve(_ego(v=8.0), _curved_ref())
        if snap.feasible:
            for s in snap.predicted_states:
                assert s.is_finite()
