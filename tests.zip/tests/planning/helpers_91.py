"""
IndiDrive AI — Phase 9.1 | Test Helpers
=========================================
Minimal mock factories for Phase 9.1 tests.
These use simple objects with the attributes the builder needs —
no deep coupling to actual Phase 7/8 internals.
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import List, Optional


# ---------------------------------------------------------------------------
# Minimal mock structures (mirror the attributes the builder reads)
# ---------------------------------------------------------------------------

@dataclass
class MockBoundaryPoint:
    x: float = 0.0
    y: float = 0.0
    confidence: float = 0.8
    point_support: int = 5


@dataclass
class MockBoundarySummary:
    available: bool = False
    points: list = field(default_factory=list)
    confidence: float = 0.0
    source: str = "test"


@dataclass
class MockDrivableSpaceInfo:
    available: bool = True
    road_width_m: Optional[float] = 8.0
    free_space_confidence: float = 0.8
    drivable_space_uncertainty: float = 0.2
    left_boundary: MockBoundarySummary = field(default_factory=lambda: MockBoundarySummary(
        available=True,
        points=[MockBoundaryPoint(x=5.0, y=4.0), MockBoundaryPoint(x=20.0, y=4.0)],
        confidence=0.8,
    ))
    right_boundary: MockBoundarySummary = field(default_factory=lambda: MockBoundarySummary(
        available=True,
        points=[MockBoundaryPoint(x=5.0, y=-4.0), MockBoundaryPoint(x=20.0, y=-4.0)],
        confidence=0.8,
    ))
    coordinate_frame: str = "VEHICLE"
    is_degraded: bool = False
    source: str = "test"


@dataclass
class MockLaneInfo:
    available: bool = True
    marking_state: str = "MARKED"
    lane_count: Optional[int] = 2
    lane_width_m: Optional[float] = 3.5
    road_direction: str = "FORWARD"
    curvature_summary: str = "STRAIGHT"
    intersection_state: str = "NORMAL_ROAD"
    observed_vs_inferred: str = "OBSERVED"
    lane_confidence: float = 0.85
    lane_uncertainty: float = 0.15
    is_degraded: bool = False


@dataclass
class MockAnomalySummary:
    anomaly_id: str = "anom_001"
    anomaly_type: str = "POTHOLE"
    position_x: Optional[float] = 15.0
    position_y: Optional[float] = 0.5
    approximate_width_m: Optional[float] = 0.5
    approximate_length_m: Optional[float] = 0.5
    severity: str = "MODERATE"
    drivability_impact: str = "MEDIUM"
    confidence: float = 0.7
    uncertainty: float = 0.3
    temporal_stability: str = "STABLE"
    in_drivable_area: bool = True
    in_lane_corridor: bool = True


class MockRoadRepStatus:
    def __init__(self, v="FULL"):
        self.value = v


@dataclass
class MockRoadRepresentation:
    status: object = field(default_factory=lambda: MockRoadRepStatus("FULL"))
    drivable_space: MockDrivableSpaceInfo = field(default_factory=MockDrivableSpaceInfo)
    lane_info: MockLaneInfo = field(default_factory=MockLaneInfo)
    anomalies: list = field(default_factory=list)
    road_confidence: float = 0.8
    road_uncertainty: float = 0.2
    timestamp: float = field(default_factory=time.time)
    is_degraded: bool = False

    @property
    def anomaly_count(self):
        return len(self.anomalies)

    @property
    def has_critical_anomaly(self):
        return any(getattr(a, "severity", "") == "CRITICAL" for a in self.anomalies)


@dataclass
class MockIndianContext:
    available: bool = True
    road_type: str = "URBAN"
    urban_rural_class: str = "URBAN"
    traffic_density: str = "MEDIUM"
    traffic_mix: str = "mixed"
    vulnerable_road_users: bool = False
    cattle_present: bool = False
    roadside_activity: str = "NONE"
    market_like_activity: bool = False
    intersection_context: str = "NORMAL"
    unusual_road_indicators: list = field(default_factory=list)
    road_complexity: str = "MEDIUM"
    context_stability: str = "STABLE"
    context_confidence: float = 0.75
    context_uncertainty: float = 0.25
    is_degraded: bool = False


class MockWMStatus:
    def __init__(self, v="OK"):
        self.value = v


@dataclass
class MockDataQuality:
    overall_confidence: float = 0.8
    overall_uncertainty: float = 0.2
    completeness: float = 0.9
    freshness: float = 0.95
    is_partial: bool = False
    warnings: list = field(default_factory=list)


@dataclass
class MockObjectPosition:
    x: float = 10.0
    y: float = 2.0
    z: float = 0.0


@dataclass
class MockObjectVelocity:
    vx: float = 5.0
    vy: float = 0.0


@dataclass
class MockObjectDimensions:
    length_m: float = 4.5
    width_m: float = 1.8
    height_m: float = 1.5


class MockPredAvail:
    def __init__(self, v="FULL"):
        self.value = v


@dataclass
class MockPredictionSummary:
    availability: MockPredAvail = field(default_factory=lambda: MockPredAvail("FULL"))
    most_likely_endpoint_x: Optional[float] = 25.0
    most_likely_endpoint_y: Optional[float] = 2.0
    prediction_horizon_s: float = 3.0


@dataclass
class MockObjectQuality:
    confidence: float = 0.85
    uncertainty: float = 0.15


class MockObsState:
    def __init__(self, v="OBSERVED"):
        self.value = v


class MockObjType:
    def __init__(self, v="VEHICLE"):
        self.value = v


@dataclass
class MockWorldObject:
    object_id: str = "obj_001"
    object_type: str = "VEHICLE"
    observation_state: str = "OBSERVED"
    position: MockObjectPosition = field(default_factory=MockObjectPosition)
    motion: MockObjectVelocity = field(default_factory=MockObjectVelocity)
    dimensions: MockObjectDimensions = field(default_factory=MockObjectDimensions)
    prediction: MockPredictionSummary = field(default_factory=MockPredictionSummary)
    quality: MockObjectQuality = field(default_factory=MockObjectQuality)

    def is_high_risk(self):
        return False


@dataclass
class MockWorldModelSnapshot:
    schema_version: str = "7.0"
    timestamp: float = field(default_factory=time.time)
    frame_id: int = 1
    _objects: tuple = field(default_factory=tuple)
    road: MockRoadRepresentation = field(default_factory=MockRoadRepresentation)
    indian_context: MockIndianContext = field(default_factory=MockIndianContext)
    data_quality: MockDataQuality = field(default_factory=MockDataQuality)
    status: MockWMStatus = field(default_factory=MockWMStatus)
    coordinate_frame: str = "VEHICLE"

    @property
    def objects(self):
        return self._objects

    @property
    def object_count(self):
        return len(self._objects)


# ---------------------------------------------------------------------------
# Phase 8.4 mocks
# ---------------------------------------------------------------------------

class MockSafetyGateState:
    def __init__(self, v="CLEAR"):
        self.value = v


class MockPlanningMode:
    def __init__(self, v="NORMAL"):
        self.value = v


@dataclass
class MockConstraint:
    constraint_id: str = "c_001"
    constraint_type: str = "COLLISION_RISK"
    hardness: str = "HARD"
    description: str = "Test constraint"
    confidence: float = 0.9


@dataclass
class MockPlanningContext:
    context_id: str = "ctx_001"
    timestamp: float = field(default_factory=time.time)
    frame_id: int = 1
    safety_gate_state: MockSafetyGateState = field(
        default_factory=lambda: MockSafetyGateState("CLEAR")
    )
    dominant_requirement: object = None
    _active_requirements: tuple = field(default_factory=tuple)
    _hard_constraints: tuple = field(default_factory=tuple)
    _soft_constraints: tuple = field(default_factory=tuple)
    affected_entity_ids: tuple = field(default_factory=tuple)
    uncertainty_level: str = "LOW"
    world_model_completeness: float = 0.9
    planning_allowed: bool = True
    planning_mode: MockPlanningMode = field(
        default_factory=lambda: MockPlanningMode("NORMAL")
    )
    safety_override_required: bool = False
    reason_codes: tuple = field(default_factory=tuple)
    confidence: float = 0.85

    @property
    def hard_constraints(self):
        return self._hard_constraints

    @property
    def soft_constraints(self):
        return self._soft_constraints

    @property
    def active_requirements(self):
        return self._active_requirements


# ---------------------------------------------------------------------------
# Factory functions
# ---------------------------------------------------------------------------

def make_planning_input(
    frame_id: int = 1,
    world_model: Optional[object] = None,
    planning_context: Optional[object] = None,
    timestamp: Optional[float] = None,
):
    """Create a PlanningInput for testing."""
    from core.planning import PlanningInput
    ts = timestamp or time.time()
    wm = world_model if world_model is not None else MockWorldModelSnapshot(
        frame_id=frame_id, timestamp=ts
    )
    pc = planning_context if planning_context is not None else MockPlanningContext(
        frame_id=frame_id, timestamp=ts
    )
    return PlanningInput(
        input_id=f"inp_{frame_id}",
        timestamp=ts,
        frame_id=frame_id,
        world_model_snapshot=wm,
        planning_context=pc,
        world_model_available=True,
        planning_context_available=True,
    )


def make_empty_input(frame_id: int = 1) -> object:
    """PlanningInput with no upstream data."""
    from core.planning import PlanningInput
    return PlanningInput(
        input_id=f"inp_empty_{frame_id}",
        timestamp=time.time(),
        frame_id=frame_id,
        world_model_snapshot=None,
        planning_context=None,
        world_model_available=False,
        planning_context_available=False,
    )


def make_world_model_with_objects(objects: list) -> MockWorldModelSnapshot:
    wm = MockWorldModelSnapshot()
    wm._objects = tuple(objects)
    return wm


def make_world_model_with_anomalies(anomalies: list) -> MockWorldModelSnapshot:
    wm = MockWorldModelSnapshot()
    wm.road.anomalies = anomalies
    return wm


def make_degraded_world_model() -> MockWorldModelSnapshot:
    wm = MockWorldModelSnapshot()
    wm.status = MockWMStatus("DEGRADED")
    wm.road.is_degraded = True
    wm.data_quality.overall_confidence = 0.2
    wm.data_quality.completeness = 0.3
    return wm


def make_planning_context_with_gate(gate: str) -> MockPlanningContext:
    pc = MockPlanningContext()
    pc.safety_gate_state = MockSafetyGateState(gate)
    if gate in ("RESTRICTED", "HIGH_ALERT", "CRITICAL"):
        pc.planning_allowed = False
        pc._hard_constraints = (MockConstraint(
            constraint_id="hc_gate",
            constraint_type="SAFETY_GATE",
            description=f"Gate state: {gate}",
        ),)
    elif gate in ("DEGRADED", "UNKNOWN"):
        pc.planning_allowed = False
    return pc


def make_village_road_world_model() -> MockWorldModelSnapshot:
    """Village road: unmarked, narrow, irregular boundaries."""
    wm = MockWorldModelSnapshot()
    wm.road.lane_info.marking_state = "UNMARKED"
    wm.road.lane_info.lane_count = None
    wm.road.lane_info.lane_width_m = None
    wm.road.lane_info.road_complexity = "HIGH"
    wm.road.drivable_space.road_width_m = 4.0
    wm.road.drivable_space.free_space_confidence = 0.5
    wm.indian_context.road_type = "VILLAGE_ROAD"
    wm.indian_context.road_complexity = "HIGH"
    wm.indian_context.traffic_density = "LOW"
    return wm


def make_market_road_world_model() -> MockWorldModelSnapshot:
    """Dense market road: pedestrians, cattle, weak lane structure."""
    wm = MockWorldModelSnapshot()
    wm.road.lane_info.marking_state = "WEAKLY_MARKED"
    wm.road.lane_info.lane_count = 1
    wm.indian_context.road_type = "URBAN_MARKET"
    wm.indian_context.traffic_density = "VERY_HIGH"
    wm.indian_context.vulnerable_road_users = True
    wm.indian_context.cattle_present = True
    wm.indian_context.market_like_activity = True
    pedestrian = MockWorldObject(
        object_id="ped_001", object_type="PEDESTRIAN",
        position=MockObjectPosition(x=8.0, y=1.5),
    )
    wm._objects = (pedestrian,)
    return wm


def make_cattle_crossing_world_model() -> MockWorldModelSnapshot:
    """Cattle crossing: dynamic animal objects."""
    wm = MockWorldModelSnapshot()
    wm.indian_context.cattle_present = True
    cattle = MockWorldObject(
        object_id="cattle_001", object_type="CATTLE",
        position=MockObjectPosition(x=12.0, y=0.0),
        motion=MockObjectVelocity(vx=0.5, vy=0.3),
    )
    wm._objects = (cattle,)
    return wm


def make_highway_world_model() -> MockWorldModelSnapshot:
    """Highway: multiple lanes, clearer boundaries."""
    wm = MockWorldModelSnapshot()
    wm.road.lane_info.marking_state = "MARKED"
    wm.road.lane_info.lane_count = 4
    wm.road.lane_info.lane_width_m = 3.75
    wm.road.drivable_space.road_width_m = 15.0
    wm.road.drivable_space.free_space_confidence = 0.95
    wm.indian_context.road_type = "HIGHWAY"
    wm.indian_context.traffic_density = "MEDIUM"
    return wm


def make_pothole_world_model() -> MockWorldModelSnapshot:
    """Pothole / damaged road: anomaly in drivable area."""
    wm = MockWorldModelSnapshot()
    pothole = MockAnomalySummary(
        anomaly_id="ph_001",
        anomaly_type="POTHOLE",
        position_x=10.0, position_y=0.0,
        severity="SEVERE",
        drivability_impact="HIGH",
        in_drivable_area=True,
    )
    wm.road.anomalies = [pothole]
    return wm


def make_unsignalized_intersection_world_model() -> MockWorldModelSnapshot:
    """Unsignalized intersection with multiple dynamic objects."""
    wm = MockWorldModelSnapshot()
    wm.road.lane_info.intersection_state = "INTERSECTION"
    v1 = MockWorldObject(object_id="v_001", object_type="VEHICLE",
                         position=MockObjectPosition(x=30.0, y=3.0))
    v2 = MockWorldObject(object_id="v_002", object_type="VEHICLE",
                         position=MockObjectPosition(x=28.0, y=-3.0))
    ped = MockWorldObject(object_id="ped_001", object_type="PEDESTRIAN",
                          position=MockObjectPosition(x=20.0, y=0.5))
    wm._objects = (v1, v2, ped)
    return wm
