"""
IndiDrive AI — Phase 9.1 | Core Tests
=======================================
Comprehensive test suite for Phase 9.1 Planning Space Foundation.

Covers all 24+ required test cases from the spec plus:
  - Indian-road scenarios
  - negative tests (no planning outputs)
  - Phase 8.4 gate state regression
  - Phase 7 world model regression
  - Phase 6 road data regression
"""
from __future__ import annotations

import sys
import os
import time

import pytest

# Make sure the project root is on sys.path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))

from core.planning import (
    PlanningInput,
    PlanningSpace,
    PlanningSnapshot,
    PlanningSpaceBuilder,
    PlanningSpaceConfig,
    PlanningSpaceStatus,
    DrivableState,
    EvidenceClass,
    OccupancyState,
    NOT_AVAILABLE,
    PLANNING_SPACE_SCHEMA_VERSION,
    PlanningSpaceValidator,
)

from tests.planning.helpers_91 import (
    MockWorldModelSnapshot,
    MockPlanningContext,
    MockSafetyGateState,
    MockPlanningMode,
    MockAnomalySummary,
    MockWorldObject,
    MockObjectPosition,
    MockConstraint,
    make_planning_input,
    make_empty_input,
    make_world_model_with_objects,
    make_world_model_with_anomalies,
    make_degraded_world_model,
    make_planning_context_with_gate,
    make_village_road_world_model,
    make_market_road_world_model,
    make_cattle_crossing_world_model,
    make_highway_world_model,
    make_pothole_world_model,
    make_unsignalized_intersection_world_model,
)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def builder():
    return PlanningSpaceBuilder()


@pytest.fixture
def default_input():
    return make_planning_input()


# ===========================================================================
# 1. Planning input creation
# ===========================================================================

def test_planning_input_creation():
    """Test 1: PlanningInput can be created with valid fields."""
    inp = PlanningInput(
        input_id="inp_test",
        timestamp=time.time(),
        frame_id=42,
        world_model_snapshot=MockWorldModelSnapshot(),
        planning_context=MockPlanningContext(),
        world_model_available=True,
        planning_context_available=True,
    )
    assert inp.frame_id == 42
    assert inp.world_model_available is True
    assert inp.planning_context_available is True
    assert inp.schema_version == "9.1"


# ===========================================================================
# 2. Empty input
# ===========================================================================

def test_empty_input_produces_partial_or_empty_space(builder):
    """Test 2: Empty input (no WM, no PC) produces EMPTY or PARTIAL space."""
    inp = make_empty_input()
    snap = builder.build(inp)
    assert snap is not None
    assert snap.space.status in (PlanningSpaceStatus.EMPTY, PlanningSpaceStatus.PARTIAL)
    assert snap.space.planning_allowed is False


# ===========================================================================
# 3. Valid WorldModel
# ===========================================================================

def test_valid_world_model_produces_ok_space(builder):
    """Test 3: Full valid WorldModelSnapshot produces OK or PARTIAL space."""
    inp = make_planning_input()
    snap = builder.build(inp)
    assert snap is not None
    assert snap.space.status in (
        PlanningSpaceStatus.OK,
        PlanningSpaceStatus.PARTIAL,
        PlanningSpaceStatus.RESTRICTED,
    )
    assert snap.space.quality.world_model_available is True


# ===========================================================================
# 4. Valid PlanningContext
# ===========================================================================

def test_valid_planning_context_propagates(builder):
    """Test 4: PlanningContext fields propagate into PlanningSpace."""
    pc = MockPlanningContext()
    pc.planning_allowed = True
    pc.safety_gate_state = MockSafetyGateState("CLEAR")
    inp = make_planning_input(planning_context=pc)
    snap = builder.build(inp)
    assert snap.space.planning_allowed is True
    assert snap.space.safety_gate_state == "CLEAR"
    assert snap.space.quality.planning_context_available is True


# ===========================================================================
# 5. Drivable region conversion
# ===========================================================================

def test_drivable_region_conversion(builder):
    """Test 5: Drivable space from WM is converted into drivable regions."""
    inp = make_planning_input()
    snap = builder.build(inp)
    assert snap.space.drivable_region_count >= 1
    for r in snap.space.drivable_regions:
        assert r.drivable_state in (
            DrivableState.DRIVABLE,
            DrivableState.UNCERTAIN,
            DrivableState.UNKNOWN,
        )


# ===========================================================================
# 6. Non-drivable region conversion
# ===========================================================================

def test_non_drivable_region_from_boundaries(builder):
    """Test 6: Road boundaries produce non-drivable regions."""
    inp = make_planning_input()
    snap = builder.build(inp)
    # With left+right boundaries available, expect non-drivable boundary regions
    assert snap.space is not None
    # May have non-drivable regions from boundaries
    nd = snap.space.non_drivable_regions
    assert isinstance(nd, tuple)


# ===========================================================================
# 7. Road boundary conversion
# ===========================================================================

def test_road_boundary_conversion(builder):
    """Test 7: Road boundary points appear in spatial extent."""
    inp = make_planning_input()
    snap = builder.build(inp)
    se = snap.space.spatial_extent
    assert se.left_boundary_available is True
    assert se.right_boundary_available is True
    assert len(se.left_boundary) >= 1
    assert len(se.right_boundary) >= 1
    for pt in se.left_boundary:
        assert isinstance(pt.x, float)
        assert isinstance(pt.y, float)


# ===========================================================================
# 8. Lane information propagation
# ===========================================================================

def test_lane_info_propagation(builder):
    """Test 8: Lane info propagates into road_structure."""
    inp = make_planning_input()
    snap = builder.build(inp)
    rs = snap.space.road_structure
    assert rs.lane_info_available is True
    assert rs.marking_state == "MARKED"
    assert rs.lane_count == 2
    assert abs(rs.lane_width_m - 3.5) < 0.01


# ===========================================================================
# 9. Unknown lane information
# ===========================================================================

def test_unknown_lane_info_not_fabricated(builder):
    """Test 9: Unknown lane info is represented as UNKNOWN, not invented."""
    wm = MockWorldModelSnapshot()
    wm.road.lane_info.available = False
    inp = make_planning_input(world_model=wm)
    snap = builder.build(inp)
    rs = snap.space.road_structure
    assert rs.lane_info_available is False
    assert rs.lane_count is None   # must not be fabricated


# ===========================================================================
# 10. Static hazard propagation
# ===========================================================================

def test_static_hazard_propagation(builder):
    """Test 10: Phase 6 anomalies appear as static hazards."""
    wm = make_pothole_world_model()
    inp = make_planning_input(world_model=wm)
    snap = builder.build(inp)
    assert snap.space.static_hazard_count >= 1
    hz = snap.space.static_hazards[0]
    assert hz.hazard_type == "POTHOLE"
    assert hz.position_x == pytest.approx(10.0)
    assert hz.in_drivable_area is True


# ===========================================================================
# 11. Dynamic object propagation
# ===========================================================================

def test_dynamic_object_propagation(builder):
    """Test 11: WorldObjects appear as dynamic object entries."""
    obj = MockWorldObject(object_id="v_test", object_type="VEHICLE",
                          position=MockObjectPosition(x=15.0, y=0.5))
    wm = make_world_model_with_objects([obj])
    inp = make_planning_input(world_model=wm)
    snap = builder.build(inp)
    assert snap.space.dynamic_object_count >= 1
    dyn = snap.space.dynamic_objects[0]
    assert dyn.object_type == "VEHICLE"
    assert dyn.object_id == "v_test"
    assert dyn.position_x == pytest.approx(15.0)


# ===========================================================================
# 12. Safety constraint propagation
# ===========================================================================

def test_safety_constraint_propagation(builder):
    """Test 12: Phase 8.4 constraints appear in planning space."""
    pc = MockPlanningContext()
    pc._hard_constraints = (
        MockConstraint(constraint_id="hc_001", constraint_type="COLLISION_RISK"),
    )
    pc._soft_constraints = (
        MockConstraint(constraint_id="sc_001", constraint_type="COMFORT", hardness="SOFT"),
    )
    inp = make_planning_input(planning_context=pc)
    snap = builder.build(inp)
    assert snap.space.hard_constraint_count >= 1
    assert snap.space.hard_constraints[0].constraint_id == "hc_001"
    assert snap.space.hard_constraints[0].hardness == "HARD"


# ===========================================================================
# 13. Confidence propagation
# ===========================================================================

def test_confidence_propagation(builder):
    """Test 13: Confidence propagates from WM data quality."""
    wm = MockWorldModelSnapshot()
    wm.data_quality.overall_confidence = 0.9
    inp = make_planning_input(world_model=wm)
    snap = builder.build(inp)
    assert snap.space.quality.overall_confidence > 0.0
    assert snap.space.quality.overall_confidence <= 1.0


# ===========================================================================
# 14. Uncertainty propagation
# ===========================================================================

def test_uncertainty_propagation(builder):
    """Test 14: Uncertainty is kept separate from confidence."""
    wm = MockWorldModelSnapshot()
    wm.data_quality.overall_uncertainty = 0.6
    inp = make_planning_input(world_model=wm)
    snap = builder.build(inp)
    # Uncertainty must be present and non-negative; it's NOT 1 - confidence
    assert snap.space.quality.overall_uncertainty >= 0.0
    assert snap.space.quality.overall_confidence != 1.0 - snap.space.quality.overall_uncertainty


# ===========================================================================
# 15. Degraded state propagation
# ===========================================================================

def test_degraded_state_propagation(builder):
    """Test 15: Degraded WM produces DEGRADED planning space."""
    wm = make_degraded_world_model()
    inp = make_planning_input(world_model=wm)
    snap = builder.build(inp)
    assert snap.space.status == PlanningSpaceStatus.DEGRADED
    assert snap.space.quality.is_degraded is True


# ===========================================================================
# 16. Coordinate frame validation
# ===========================================================================

def test_coordinate_frame_validation(builder):
    """Test 16: PlanningSpace always declares VEHICLE frame."""
    inp = make_planning_input()
    snap = builder.build(inp)
    cf = snap.space.coordinate_frame
    assert cf.frame_id == "VEHICLE"
    assert "+X" in cf.convention
    assert cf.unit == "metres"


# ===========================================================================
# 17. Geometry validation
# ===========================================================================

def test_geometry_validation(builder):
    """Test 17: Validator catches non-finite geometry."""
    from core.planning import PlanningSpaceValidator
    from core.planning.planning_space_types import PlanningRegion, RegionKind

    inp = make_planning_input()
    snap = builder.build(inp)
    # Nominal case: geometry should be valid
    val = PlanningSpaceValidator.validate(snap.space)
    assert val.is_valid


# ===========================================================================
# 18. Timestamp validation
# ===========================================================================

def test_timestamp_validation():
    """Test 18: Validator rejects zero/negative/non-finite timestamps."""
    from core.planning import PlanningInput
    val = PlanningSpaceValidator()

    bad_inp = PlanningInput(timestamp=-1.0, frame_id=0)
    result = val.validate_input(bad_inp)
    assert not result.is_valid
    assert any("timestamp" in e for e in result.errors)


# ===========================================================================
# 19. Planning horizon validation
# ===========================================================================

def test_planning_horizon_validity(builder):
    """Test 19: Horizon values are > 0 and finite."""
    inp = make_planning_input()
    snap = builder.build(inp)
    h = snap.space.horizon
    assert h.longitudinal_m > 0
    assert h.lateral_extent_m > 0
    assert h.validity.value in ("VALID", "DEGRADED")


# ===========================================================================
# 20. Deterministic output
# ===========================================================================

def test_deterministic_output(builder):
    """Test 20: Same input produces identical PlanningSpace."""
    ts = time.time()
    wm = MockWorldModelSnapshot(timestamp=ts)
    pc = MockPlanningContext(timestamp=ts)
    inp_a = PlanningInput(
        input_id="det_test", timestamp=ts, frame_id=99,
        world_model_snapshot=wm, planning_context=pc,
        world_model_available=True, planning_context_available=True,
    )
    inp_b = PlanningInput(
        input_id="det_test", timestamp=ts, frame_id=99,
        world_model_snapshot=wm, planning_context=pc,
        world_model_available=True, planning_context_available=True,
    )
    snap_a = builder.build(inp_a)
    snap_b = builder.build(inp_b)
    assert snap_a.space.to_dict() == snap_b.space.to_dict()


# ===========================================================================
# 21. Snapshot immutability
# ===========================================================================

def test_snapshot_immutability(builder):
    """Test 21: PlanningSpace tuples cannot be mutated externally."""
    inp = make_planning_input()
    snap = builder.build(inp)
    ps = snap.space
    # drivable_regions is a tuple — appending should fail
    with pytest.raises((AttributeError, TypeError)):
        ps.drivable_regions.append("hacked")  # type: ignore[attr-defined]
    with pytest.raises((AttributeError, TypeError)):
        ps.dynamic_objects.append("hacked")  # type: ignore[attr-defined]


# ===========================================================================
# 22. Partial input handling
# ===========================================================================

def test_partial_input_world_model_only(builder):
    """Test 22a: PlanningInput with only WM (no PC) is handled gracefully."""
    from core.planning import PlanningInput
    inp = PlanningInput(
        input_id="partial",
        timestamp=time.time(),
        frame_id=5,
        world_model_snapshot=MockWorldModelSnapshot(),
        planning_context=None,
        world_model_available=True,
        planning_context_available=False,
    )
    snap = builder.build(inp)
    assert snap is not None
    assert snap.space.status in (
        PlanningSpaceStatus.PARTIAL,
        PlanningSpaceStatus.OK,
        PlanningSpaceStatus.DEGRADED,
    )
    assert snap.space.safety_gate_state == NOT_AVAILABLE


def test_partial_input_pc_only(builder):
    """Test 22b: PlanningInput with only PC (no WM) is handled gracefully."""
    from core.planning import PlanningInput
    inp = PlanningInput(
        input_id="partial_pc",
        timestamp=time.time(),
        frame_id=6,
        world_model_snapshot=None,
        planning_context=MockPlanningContext(),
        world_model_available=False,
        planning_context_available=True,
    )
    snap = builder.build(inp)
    assert snap is not None
    assert snap.space.quality.world_model_available is False
    assert snap.space.quality.planning_context_available is True


# ===========================================================================
# 23. Missing optional input handling
# ===========================================================================

def test_missing_lane_info_handled(builder):
    """Test 23a: Missing lane info does not crash and returns UNKNOWN."""
    wm = MockWorldModelSnapshot()
    wm.road.lane_info = None
    inp = make_planning_input(world_model=wm)
    snap = builder.build(inp)
    assert snap is not None
    assert snap.space.road_structure.lane_info_available is False


def test_missing_anomalies_handled(builder):
    """Test 23b: No anomalies → zero static hazards."""
    wm = MockWorldModelSnapshot()
    wm.road.anomalies = []
    inp = make_planning_input(world_model=wm)
    snap = builder.build(inp)
    assert snap.space.static_hazard_count == 0


def test_missing_prediction_handled(builder):
    """Test 23c: Objects with no prediction — prediction_available=False."""
    obj = MockWorldObject(object_id="nopred", object_type="PEDESTRIAN")
    obj.prediction = None
    wm = make_world_model_with_objects([obj])
    inp = make_planning_input(world_model=wm)
    snap = builder.build(inp)
    assert snap.space.dynamic_object_count >= 1
    dyn = next(d for d in snap.space.dynamic_objects if d.object_id == "nopred")
    assert dyn.prediction_available is False


# ===========================================================================
# 24. Invalid input handling
# ===========================================================================

def test_invalid_timestamp_produces_invalid_snapshot(builder):
    """Test 24a: Non-finite timestamp → invalid snapshot."""
    from core.planning import PlanningInput
    import math
    inp = PlanningInput(
        input_id="bad", timestamp=math.nan, frame_id=0,
    )
    snap = builder.build(inp)
    assert not snap.is_valid
    assert snap.space.status == PlanningSpaceStatus.INVALID


def test_none_input_handled(builder):
    """Test 24b: None PlanningInput is handled without crash."""
    # Validator handles None
    result = PlanningSpaceValidator.validate_input(None)
    assert not result.is_valid


# ===========================================================================
# Negative tests — Phase 9.1 must NOT produce planning outputs
# ===========================================================================

FORBIDDEN_KEYS = (
    "path", "candidate_paths", "waypoints", "trajectory",
    "steering_angle", "throttle", "brake", "target_speed",
    "acceleration_cmd", "lane_change_command", "overtake_command",
    "steer_cmd", "select_best_path", "generate_path",
    "avoid_obstacle", "change_lane", "overtake",
    "hybrid_astar", "rrt", "mpc",
)


def test_no_forbidden_fields_in_serialised_space(builder):
    """Negative: PlanningSpace serialisation must not contain forbidden planning fields."""
    inp = make_planning_input()
    snap = builder.build(inp)
    d = snap.space.to_dict()
    for key in FORBIDDEN_KEYS:
        assert key not in d, f"Forbidden field '{key}' found in PlanningSpace dict"


def test_planning_space_has_no_path_attribute(builder):
    """Negative: PlanningSpace has no path-related attributes."""
    inp = make_planning_input()
    snap = builder.build(inp)
    ps = snap.space
    for forbidden in ("path", "trajectory", "waypoints", "candidate_paths",
                      "steering_angle", "throttle", "brake"):
        assert not hasattr(ps, forbidden), f"PlanningSpace has forbidden attribute '{forbidden}'"


def test_builder_has_no_path_generation_methods(builder):
    """Negative: PlanningSpaceBuilder has no path generation methods."""
    for method in ("select_best_path", "generate_path", "avoid_obstacle",
                   "change_lane", "overtake", "follow_lane"):
        assert not hasattr(builder, method), (
            f"PlanningSpaceBuilder has forbidden method '{method}'"
        )


# ===========================================================================
# Phase 8.4 gate state regression
# ===========================================================================

@pytest.mark.parametrize("gate", [
    "CLEAR", "CAUTION", "RESTRICTED", "HIGH_ALERT", "CRITICAL", "DEGRADED", "UNKNOWN"
])
def test_gate_state_preserved(builder, gate):
    """Phase 8.4 regression: All gate states are preserved in planning space."""
    pc = make_planning_context_with_gate(gate)
    inp = make_planning_input(planning_context=pc)
    snap = builder.build(inp)
    assert snap.space.safety_gate_state == gate, (
        f"Expected gate={gate!r}, got {snap.space.safety_gate_state!r}"
    )


def test_gate_critical_produces_restricted_status(builder):
    """Phase 8.4 regression: CRITICAL gate → RESTRICTED planning space."""
    pc = make_planning_context_with_gate("CRITICAL")
    inp = make_planning_input(planning_context=pc)
    snap = builder.build(inp)
    assert snap.space.status == PlanningSpaceStatus.RESTRICTED


def test_gate_clear_planning_allowed(builder):
    """Phase 8.4 regression: CLEAR gate → planning_allowed=True."""
    pc = make_planning_context_with_gate("CLEAR")
    inp = make_planning_input(planning_context=pc)
    snap = builder.build(inp)
    assert snap.space.planning_allowed is True


# ===========================================================================
# Phase 7 world model regression
# ===========================================================================

def test_complete_world_model(builder):
    """Phase 7 regression: Complete WM → fully populated planning space."""
    inp = make_planning_input()
    snap = builder.build(inp)
    assert snap.space.quality.world_model_available is True
    assert not snap.space.quality.is_partial or snap.space.quality.completeness > 0.4


def test_partial_world_model(builder):
    """Phase 7 regression: Partial WM handled gracefully."""
    wm = MockWorldModelSnapshot()
    wm.status = type("S", (), {"value": "PARTIAL"})()
    inp = make_planning_input(world_model=wm)
    snap = builder.build(inp)
    assert snap is not None


def test_degraded_world_model_marks_degraded(builder):
    """Phase 7 regression: DEGRADED WM → DEGRADED status."""
    wm = make_degraded_world_model()
    inp = make_planning_input(world_model=wm)
    snap = builder.build(inp)
    assert snap.space.status == PlanningSpaceStatus.DEGRADED


def test_empty_world_model(builder):
    """Phase 7 regression: EMPTY WM → EMPTY or PARTIAL planning space."""
    wm = MockWorldModelSnapshot()
    wm.status = type("S", (), {"value": "EMPTY"})()
    wm.road.status = type("S", (), {"value": "NONE"})()
    wm.road.drivable_space.available = False
    wm.road.lane_info.available = False
    inp = make_planning_input(world_model=wm)
    snap = builder.build(inp)
    assert snap.space.status in (
        PlanningSpaceStatus.EMPTY,
        PlanningSpaceStatus.PARTIAL,
        PlanningSpaceStatus.DEGRADED,
    )


# ===========================================================================
# Phase 6 regression
# ===========================================================================

def test_drivable_area_from_phase6(builder):
    """Phase 6 regression: drivable area from Phase 6 populates planning space."""
    inp = make_planning_input()
    snap = builder.build(inp)
    se = snap.space.spatial_extent
    # road_width from Phase 6 drivable space
    assert se.road_width_m == pytest.approx(8.0)


def test_road_anomaly_from_phase6(builder):
    """Phase 6 regression: road anomaly from Phase 6 appears as static hazard."""
    wm = make_pothole_world_model()
    inp = make_planning_input(world_model=wm)
    snap = builder.build(inp)
    assert snap.space.static_hazard_count >= 1
    hazard_types = {h.hazard_type for h in snap.space.static_hazards}
    assert "POTHOLE" in hazard_types


def test_lane_structure_from_phase6(builder):
    """Phase 6 regression: lane structure from Phase 6 populates road_structure."""
    inp = make_planning_input()
    snap = builder.build(inp)
    assert snap.space.road_structure.lane_info_available is True
    assert snap.space.road_structure.lane_count == 2


# ===========================================================================
# Indian road scenario tests
# ===========================================================================

def test_village_road_planning_space(builder):
    """Indian road: Village road — unmarked, narrow."""
    wm = make_village_road_world_model()
    inp = make_planning_input(world_model=wm)
    snap = builder.build(inp)
    assert snap is not None
    rs = snap.space.road_structure
    assert rs.marking_state == "UNMARKED"
    assert rs.lane_count is None  # Not fabricated
    ic = snap.space.indian_road_context
    assert ic.road_type == "VILLAGE_ROAD"
    assert ic.road_complexity == "HIGH"


def test_market_road_planning_space(builder):
    """Indian road: Dense market road with VRUs."""
    wm = make_market_road_world_model()
    inp = make_planning_input(world_model=wm)
    snap = builder.build(inp)
    assert snap is not None
    ic = snap.space.indian_road_context
    assert ic.vulnerable_road_users is True
    assert ic.cattle_present is True
    assert ic.market_like_activity is True
    assert snap.space.dynamic_object_count >= 1


def test_cattle_crossing_planning_space(builder):
    """Indian road: Cattle crossing — dynamic animal objects."""
    wm = make_cattle_crossing_world_model()
    inp = make_planning_input(world_model=wm)
    snap = builder.build(inp)
    assert snap.space.dynamic_object_count >= 1
    cattle_entries = [
        d for d in snap.space.dynamic_objects if d.object_type == "CATTLE"
    ]
    assert len(cattle_entries) >= 1


def test_highway_planning_space(builder):
    """Indian road: Highway with multiple lanes."""
    wm = make_highway_world_model()
    inp = make_planning_input(world_model=wm)
    snap = builder.build(inp)
    rs = snap.space.road_structure
    assert rs.lane_count == 4
    assert rs.marking_state == "MARKED"
    se = snap.space.spatial_extent
    assert se.road_width_m == pytest.approx(15.0)


def test_unsignalized_intersection_planning_space(builder):
    """Indian road: Unsignalized intersection with multiple objects."""
    wm = make_unsignalized_intersection_world_model()
    inp = make_planning_input(world_model=wm)
    snap = builder.build(inp)
    assert snap.space.dynamic_object_count == 3
    rs = snap.space.road_structure
    assert rs.intersection_state == "INTERSECTION"


def test_pothole_damaged_road_planning_space(builder):
    """Indian road: Pothole / damaged road."""
    wm = make_pothole_world_model()
    inp = make_planning_input(world_model=wm)
    snap = builder.build(inp)
    assert snap.space.static_hazard_count >= 1
    hz = snap.space.static_hazards[0]
    assert hz.severity == "SEVERE"
    assert hz.in_drivable_area is True
    # Pothole should generate a restricted region
    rz_ids = {r.region_id for r in snap.space.restricted_regions}
    assert any("hazard" in rid for rid in rz_ids)


# ===========================================================================
# Additional quality / validation tests
# ===========================================================================

def test_schema_version_correct(builder):
    """Schema version matches Phase 9.1."""
    inp = make_planning_input()
    snap = builder.build(inp)
    assert snap.space.schema_version == PLANNING_SPACE_SCHEMA_VERSION
    assert snap.space.schema_version == "9.1"


def test_validator_detects_duplicate_region_ids(builder):
    """Validator catches duplicate region IDs."""
    from core.planning.planning_space_types import (
        PlanningRegion, RegionKind
    )
    inp = make_planning_input()
    snap = builder.build(inp)
    # Manually inject a duplicate (not through builder)
    r = PlanningRegion(region_id="dup", kind=RegionKind.DRIVABLE_CORRIDOR,
                       drivable_state=DrivableState.DRIVABLE)
    # Build a space with duplicate IDs by direct construction
    from core.planning import PlanningSpace
    bad_space = PlanningSpace(
        timestamp=time.time(),
        frame_id=1,
        _drivable_regions=(r, r),  # duplicate
    )
    val = PlanningSpaceValidator.validate(bad_space)
    assert not val.is_valid
    assert any("duplicate" in e.lower() for e in val.errors)


def test_full_to_dict_serialisation(builder):
    """PlanningSpace.to_dict() produces a complete, JSON-compatible dict."""
    import json
    inp = make_planning_input()
    snap = builder.build(inp)
    d = snap.space.to_dict()
    # Must be JSON-serialisable
    serialised = json.dumps(d)
    assert "schema_version" in d
    assert d["schema_version"] == "9.1"
    assert "coordinate_frame" in d
    assert "status" in d
    assert "horizon" in d
    assert "safety_gate_state" in d


def test_evidence_class_not_fabricated(builder):
    """Evidence class must not be silently upgraded."""
    wm = MockWorldModelSnapshot()
    wm.road.lane_info.observed_vs_inferred = "INFERRED"
    inp = make_planning_input(world_model=wm)
    snap = builder.build(inp)
    rs = snap.space.road_structure
    assert rs.observed_vs_inferred == EvidenceClass.INFERRED


def test_quality_completeness_reflects_inputs(builder):
    """Quality completeness is higher with both WM+PC than with neither."""
    full_inp = make_planning_input()
    empty_inp = make_empty_input()

    full_snap = builder.build(full_inp)
    empty_snap = builder.build(empty_inp)

    assert full_snap.space.quality.completeness > empty_snap.space.quality.completeness


def test_config_horizon_is_used(builder):
    """PlanningSpaceConfig values appear in horizon."""
    cfg = PlanningSpaceConfig(
        planning_horizon_m=30.0,
        lateral_extent_m=6.0,
    )
    b = PlanningSpaceBuilder(config=cfg)
    inp = make_planning_input()
    snap = b.build(inp)
    assert snap.space.horizon.longitudinal_m == pytest.approx(30.0)
    assert snap.space.horizon.lateral_extent_m == pytest.approx(6.0)


def test_max_dynamic_objects_capped(builder):
    """Dynamic objects are capped by config.max_dynamic_objects."""
    cfg = PlanningSpaceConfig(max_dynamic_objects=3)
    b = PlanningSpaceBuilder(config=cfg)
    objects = [
        MockWorldObject(object_id=f"v_{i}", object_type="VEHICLE",
                        position=MockObjectPosition(x=float(i + 5), y=0.0))
        for i in range(10)
    ]
    wm = make_world_model_with_objects(objects)
    inp = make_planning_input(world_model=wm)
    snap = b.build(inp)
    assert snap.space.dynamic_object_count <= 3


def test_max_static_hazards_capped():
    """Static hazards are capped by config.max_static_hazards."""
    cfg = PlanningSpaceConfig(max_static_hazards=2)
    b = PlanningSpaceBuilder(config=cfg)
    anomalies = [
        MockAnomalySummary(
            anomaly_id=f"anom_{i}", anomaly_type="POTHOLE",
            position_x=float(i + 5), position_y=0.0,
        )
        for i in range(6)
    ]
    wm = make_world_model_with_anomalies(anomalies)
    inp = make_planning_input(world_model=wm)
    snap = b.build(inp)
    assert snap.space.static_hazard_count <= 2


def test_indian_context_available_propagates(builder):
    """Indian context availability propagates correctly."""
    wm = MockWorldModelSnapshot()
    wm.indian_context.available = True
    inp = make_planning_input(world_model=wm)
    snap = builder.build(inp)
    assert snap.space.indian_road_context.available is True


def test_indian_context_unavailable_safe(builder):
    """Absent Indian context → unavailable, not fabricated."""
    wm = MockWorldModelSnapshot()
    wm.indian_context.available = False
    inp = make_planning_input(world_model=wm)
    snap = builder.build(inp)
    assert snap.space.indian_road_context.available is False


def test_safety_gate_unknown_produces_unknown_in_space(builder):
    """UNKNOWN gate state propagates as-is."""
    pc = make_planning_context_with_gate("UNKNOWN")
    inp = make_planning_input(planning_context=pc)
    snap = builder.build(inp)
    assert snap.space.safety_gate_state == "UNKNOWN"
    assert snap.space.planning_allowed is False


def test_soft_constraints_propagate(builder):
    """Phase 8.4 soft constraints appear in planning space."""
    pc = MockPlanningContext()
    pc._soft_constraints = (
        MockConstraint(constraint_id="sc_comfort", constraint_type="COMFORT", hardness="SOFT"),
        MockConstraint(constraint_id="sc_eff", constraint_type="EFFICIENCY", hardness="SOFT"),
    )
    inp = make_planning_input(planning_context=pc)
    snap = builder.build(inp)
    assert snap.space.soft_constraint_count == 2
    types = {c.constraint_type for c in snap.space.soft_constraints}
    assert "COMFORT" in types


def test_snapshot_build_duration_present(builder):
    """Build duration is present and non-negative."""
    inp = make_planning_input()
    snap = builder.build(inp)
    assert snap.build_duration_s >= 0.0


def test_snapshot_to_dict_complete(builder):
    """Snapshot to_dict includes all expected top-level keys."""
    inp = make_planning_input()
    snap = builder.build(inp)
    d = snap.to_dict()
    assert "snapshot_id" in d
    assert "space" in d
    assert "validation" in d
    assert "is_valid" in d


def test_planning_mode_propagates(builder):
    """Planning mode from Phase 8.4 propagates into planning space."""
    pc = MockPlanningContext()
    pc.planning_mode = MockPlanningMode("RESTRICTED")
    inp = make_planning_input(planning_context=pc)
    snap = builder.build(inp)
    assert snap.space.planning_mode == "RESTRICTED"
