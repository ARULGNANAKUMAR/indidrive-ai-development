"""
IndiDrive AI — Phase 8.4 | Negative Tests & Edge Cases
========================================================
Tests that verify Phase 8.4 does NOT produce vehicle-control output,
and that it handles all edge cases safely and deterministically.

Covers:
  - No forbidden fields (steering, throttle, brake, path, waypoints, etc.)
  - Empty inputs, None inputs, duplicate requirements
  - Stale / expired requirements
  - Invalid confidence / priority / uncertainty values
  - Oversized requirement list
  - Duplicate IDs
  - All-same requirements
  - Missing world model
  - Degraded world model
"""
import sys
import os
import time
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..'))

from core.reasoning import (
    DecisionArbitrationEngine,
    ArbitrationConfig,
    SafetyGateState,
    RequirementStatus,
    TemporalValidity,
)
from core.reasoning.arbitration_validator import ArbitrationValidator
from core.reasoning.action_abstraction_types import (
    RequirementType, AbstractUrgency, AbstractSeverity, ResponseFamily,
    ACTION_ABSTRACTION_SCHEMA_VERSION, ActionAbstractionSnapshot,
)
from core.world_model.world_model_types import WorldModelStatus

from tests.reasoning84.test_helpers_84 import (
    make_requirement, make_abstraction_snapshot, make_world_model,
    make_collision_requirement, make_vru_requirement,
    make_degraded_requirement,
)

FORBIDDEN_KEYS = {
    "steering", "throttle", "brake", "path_points", "waypoints",
    "trajectory", "steering_angle", "target_speed", "lane_change_command",
    "throttle_cmd", "brake_cmd", "acceleration_cmd", "steer_cmd",
    "path", "waypoint", "mpc_cmd",
}


def _has_forbidden(d: dict) -> list:
    found = []
    for k, v in d.items():
        if k in FORBIDDEN_KEYS:
            found.append(k)
        if isinstance(v, dict):
            found.extend(_has_forbidden(v))
        elif isinstance(v, list):
            for item in v:
                if isinstance(item, dict):
                    found.extend(_has_forbidden(item))
    return found


class TestNegativeForbiddenFields(unittest.TestCase):
    """Phase 8.4 must never output vehicle-control fields."""

    def setUp(self):
        self.engine = DecisionArbitrationEngine()

    def _assert_no_forbidden(self, result):
        forbidden = _has_forbidden(result.to_dict())
        self.assertEqual(forbidden, [],
                         f"Forbidden vehicle-control fields found: {forbidden}")

    def test_no_forbidden_empty_input(self):
        result = self.engine.arbitrate()
        self._assert_no_forbidden(result)

    def test_no_forbidden_normal_progress(self):
        req = make_requirement(req_type=RequirementType.NORMAL_PROGRESS)
        snap_in = make_abstraction_snapshot(requirements=[req])
        result = self.engine.arbitrate(action_abstraction=snap_in)
        self._assert_no_forbidden(result)

    def test_no_forbidden_collision(self):
        req = make_collision_requirement()
        snap_in = make_abstraction_snapshot(requirements=[req], any_safety_critical=True)
        result = self.engine.arbitrate(
            world_model=make_world_model(), action_abstraction=snap_in
        )
        self._assert_no_forbidden(result)

    def test_no_forbidden_vru(self):
        req = make_vru_requirement()
        snap_in = make_abstraction_snapshot(requirements=[req], any_safety_critical=True)
        result = self.engine.arbitrate(
            world_model=make_world_model(), action_abstraction=snap_in
        )
        self._assert_no_forbidden(result)

    def test_no_forbidden_degraded(self):
        req = make_degraded_requirement()
        snap_in = make_abstraction_snapshot(
            requirements=[req], degraded=True, any_safety_critical=True
        )
        result = self.engine.arbitrate(
            world_model=make_world_model(
                status=WorldModelStatus.DEGRADED,
                completeness=0.15, uncertainty=0.90,
            ),
            action_abstraction=snap_in,
        )
        self._assert_no_forbidden(result)

    def test_no_forbidden_multi_hazard(self):
        reqs = [
            make_requirement(req_id="n", req_type=RequirementType.NORMAL_PROGRESS),
            make_collision_requirement(req_id="c"),
            make_vru_requirement(req_id="v"),
        ]
        snap_in = make_abstraction_snapshot(requirements=reqs, any_safety_critical=True)
        result = self.engine.arbitrate(
            world_model=make_world_model(), action_abstraction=snap_in
        )
        self._assert_no_forbidden(result)

    def test_no_steering_in_constraints(self):
        """Constraint fields must not contain steering keywords."""
        reqs = [make_collision_requirement()]
        snap_in = make_abstraction_snapshot(requirements=reqs, any_safety_critical=True)
        result = self.engine.arbitrate(
            world_model=make_world_model(), action_abstraction=snap_in
        )
        for hc in result.snapshot.planning_context.hard_constraints:
            hc_dict = hc.to_dict()
            forbidden = _has_forbidden(hc_dict)
            self.assertEqual(forbidden, [],
                             f"Constraint {hc.constraint_id} has forbidden: {forbidden}")

    def test_no_forbidden_in_planning_context(self):
        """PlanningContext serialisation must not contain forbidden keys."""
        req = make_collision_requirement()
        snap_in = make_abstraction_snapshot(requirements=[req], any_safety_critical=True)
        result = self.engine.arbitrate(
            world_model=make_world_model(), action_abstraction=snap_in
        )
        ctx_dict = result.snapshot.planning_context.to_dict()
        forbidden = _has_forbidden(ctx_dict)
        self.assertEqual(forbidden, [],
                         f"PlanningContext has forbidden: {forbidden}")


class TestEdgeCases(unittest.TestCase):

    def setUp(self):
        self.engine = DecisionArbitrationEngine()
        self.validator = ArbitrationValidator()

    def test_empty_requirements_list(self):
        """Empty requirements → no dominant, valid result."""
        snap_in = make_abstraction_snapshot(requirements=[])
        result = self.engine.arbitrate(action_abstraction=snap_in)
        self.assertTrue(result.is_valid)
        self.assertIsNone(result.snapshot.dominant_requirement)

    def test_none_action_abstraction(self):
        """None abstraction → UNKNOWN, always valid."""
        result = self.engine.arbitrate(
            world_model=make_world_model(), action_abstraction=None
        )
        self.assertEqual(result.snapshot.safety_gate_state, SafetyGateState.UNKNOWN)
        self.assertTrue(result.is_valid)

    def test_none_world_model(self):
        """None world model → treated as degraded, still valid."""
        req = make_requirement(req_type=RequirementType.NORMAL_PROGRESS)
        snap_in = make_abstraction_snapshot(requirements=[req])
        result = self.engine.arbitrate(world_model=None, action_abstraction=snap_in)
        self.assertTrue(result.is_valid)

    def test_duplicate_requirement_ids(self):
        """Duplicate requirement IDs must not cause crash or corrupt output."""
        req1 = make_requirement(req_id="dup_id",
                                req_type=RequirementType.NORMAL_PROGRESS)
        req2 = make_requirement(req_id="dup_id",
                                req_type=RequirementType.HANDLE_ROAD_HAZARD,
                                is_safety_critical=True, priority=0.70)
        snap_in = make_abstraction_snapshot(requirements=[req1, req2],
                                            any_safety_critical=True)
        result = self.engine.arbitrate(
            world_model=make_world_model(), action_abstraction=snap_in
        )
        self.assertTrue(result.is_valid)
        self.assertIsNotNone(result.snapshot)

    def test_stale_requirements_handled_conservatively(self):
        """Stale requirements don't silently become dominant."""
        old_ts = time.time() - 10.0
        req = make_collision_requirement(req_id="stale_col", timestamp=old_ts)
        snap_in = make_abstraction_snapshot(
            requirements=[req], any_safety_critical=True, timestamp=old_ts
        )
        result = self.engine.arbitrate(
            world_model=make_world_model(), action_abstraction=snap_in,
            timestamp=time.time(),
        )
        stale_or_expired = [
            ar for ar in result.snapshot.arbitrated_requirements
            if ar.temporal_validity in (TemporalValidity.STALE,
                                        TemporalValidity.EXPIRED)
        ]
        # Stale/expired must not be DOMINANT
        for ar in stale_or_expired:
            self.assertNotEqual(ar.status, RequirementStatus.DOMINANT,
                                f"Stale requirement {ar.requirement.requirement_id} is DOMINANT")

    def test_high_uncertainty_alone(self):
        """Very high uncertainty alone → not CLEAR."""
        req = make_requirement(
            req_type=RequirementType.HANDLE_UNCERTAINTY,
            priority=0.55,
            uncertainty=0.92,
            confidence=0.08,
        )
        snap_in = make_abstraction_snapshot(
            requirements=[req],
            uncertainty=0.92,
            confidence=0.08,
        )
        wm = make_world_model(uncertainty=0.92, completeness=0.40)
        result = self.engine.arbitrate(world_model=wm, action_abstraction=snap_in)
        snap = result.snapshot
        self.assertNotEqual(snap.safety_gate_state, SafetyGateState.CLEAR,
                            "High uncertainty should not produce CLEAR gate")

    def test_oversized_requirement_list_bounded(self):
        """Oversized requirement list is silently bounded."""
        cfg = ArbitrationConfig()
        engine = DecisionArbitrationEngine(config=cfg)
        reqs = [
            make_requirement(
                req_id=f"req_{i}",
                req_type=RequirementType.MONITOR_DYNAMIC_OBJECT,
                priority=0.3,
            )
            for i in range(50)
        ]
        snap_in = make_abstraction_snapshot(requirements=reqs)
        result = engine.arbitrate(
            world_model=make_world_model(), action_abstraction=snap_in
        )
        # Must not exceed max_active_requirements
        self.assertLessEqual(
            result.snapshot.requirement_count,
            cfg.max_active_requirements,
        )

    def test_invalid_confidence_handled(self):
        """Requirements with out-of-range confidence don't crash engine."""
        # The engine should not crash even if it receives unusual values.
        req = make_requirement(
            req_id="bad_conf",
            req_type=RequirementType.NORMAL_PROGRESS,
            confidence=2.0,  # invalid — engine should handle gracefully
            uncertainty=-0.5,  # invalid
        )
        snap_in = make_abstraction_snapshot(requirements=[req])
        # Should not raise
        result = self.engine.arbitrate(action_abstraction=snap_in)
        self.assertIsNotNone(result)

    def test_unknown_timestamp_requirement(self):
        """Requirement with timestamp=0 is handled as unknown validity."""
        req = make_requirement(
            req_id="ts_zero",
            req_type=RequirementType.NORMAL_PROGRESS,
            timestamp=0.0,
        )
        snap_in = make_abstraction_snapshot(requirements=[req])
        result = self.engine.arbitrate(
            action_abstraction=snap_in, timestamp=time.time()
        )
        self.assertIsNotNone(result)
        self.assertTrue(result.is_valid)

    def test_only_degraded_operation(self):
        """Only DEGRADED_OPERATION requirement → degraded gate."""
        req = make_degraded_requirement()
        snap_in = make_abstraction_snapshot(
            requirements=[req],
            degraded=True,
            any_safety_critical=True,
            uncertainty=0.90,
        )
        wm = make_world_model(completeness=0.15, uncertainty=0.90,
                               status=WorldModelStatus.DEGRADED)
        result = self.engine.arbitrate(world_model=wm, action_abstraction=snap_in)
        snap = result.snapshot
        self.assertIn(
            snap.safety_gate_state,
            (SafetyGateState.DEGRADED, SafetyGateState.RESTRICTED,
             SafetyGateState.UNKNOWN),
        )

    def test_only_normal_progress_clear_or_caution(self):
        """Only NORMAL_PROGRESS with clean inputs → CLEAR or CAUTION."""
        req = make_requirement(
            req_type=RequirementType.NORMAL_PROGRESS,
            priority=0.25,
            urgency=AbstractUrgency.NONE,
            severity=AbstractSeverity.NONE,
            confidence=0.95,
            uncertainty=0.05,
            is_safety_critical=False,
        )
        snap_in = make_abstraction_snapshot(
            requirements=[req],
            response_family=ResponseFamily.NORMAL,
            any_safety_critical=False,
            confidence=0.95,
            uncertainty=0.05,
            input_completeness=0.95,
        )
        wm = make_world_model(completeness=0.95, uncertainty=0.05)
        result = self.engine.arbitrate(world_model=wm, action_abstraction=snap_in)
        self.assertIn(
            result.snapshot.safety_gate_state,
            (SafetyGateState.CLEAR, SafetyGateState.CAUTION),
        )

    def test_multiple_equal_priority_requirements_stable(self):
        """Multiple equal-priority requirements give stable ordering."""
        reqs = [
            make_requirement(
                req_id=f"eq_{i}",
                req_type=RequirementType.HANDLE_ROAD_HAZARD,
                priority=0.55,
                urgency=AbstractUrgency.MEDIUM,
                severity=AbstractSeverity.MEDIUM,
                is_safety_critical=True,
                timestamp=1000.0,
            )
            for i in range(5)
        ]
        snap_in = make_abstraction_snapshot(
            requirements=reqs, any_safety_critical=True, timestamp=1000.0
        )
        wm = make_world_model()
        results = [
            self.engine.arbitrate(world_model=wm, action_abstraction=snap_in,
                                  timestamp=1000.5)
            for _ in range(5)
        ]
        dom_ids = [
            r.snapshot.dominant_requirement.requirement.requirement_id
            for r in results
            if r.snapshot.dominant_requirement is not None
        ]
        unique = set(dom_ids)
        self.assertEqual(len(unique), 1,
                         f"Unstable tie-break: dominant IDs vary: {dom_ids}")

    def test_degraded_world_model_not_clear(self):
        """A degraded world model must not produce CLEAR gate."""
        req = make_requirement(
            req_type=RequirementType.NORMAL_PROGRESS,
            is_safety_critical=False,
        )
        snap_in = make_abstraction_snapshot(requirements=[req])
        wm = make_world_model(
            status=WorldModelStatus.DEGRADED,
            completeness=0.10, uncertainty=0.95,
        )
        result = self.engine.arbitrate(world_model=wm, action_abstraction=snap_in)
        self.assertNotEqual(
            result.snapshot.safety_gate_state,
            SafetyGateState.CLEAR,
        )

    def test_result_schema_version_correct(self):
        """ArbitrationSnapshot always carries correct schema version."""
        from core.reasoning.arbitration_types import ARBITRATION_SCHEMA_VERSION
        result = self.engine.arbitrate()
        self.assertEqual(
            result.snapshot.schema_version, ARBITRATION_SCHEMA_VERSION
        )

    def test_arbitration_result_is_valid_on_empty(self):
        """is_valid returns True even on empty input."""
        result = self.engine.arbitrate()
        self.assertTrue(result.is_valid)

    def test_confidence_never_exceeds_1(self):
        """Output confidence is always [0, 1]."""
        reqs = [make_collision_requirement()]
        snap_in = make_abstraction_snapshot(
            requirements=reqs, confidence=0.99, uncertainty=0.01,
            any_safety_critical=True,
        )
        result = self.engine.arbitrate(
            world_model=make_world_model(confidence=0.99, uncertainty=0.01),
            action_abstraction=snap_in,
        )
        snap = result.snapshot
        self.assertLessEqual(snap.confidence, 1.0)
        self.assertGreaterEqual(snap.confidence, 0.0)
        self.assertLessEqual(snap.uncertainty, 1.0)
        self.assertGreaterEqual(snap.uncertainty, 0.0)


if __name__ == "__main__":
    unittest.main()
