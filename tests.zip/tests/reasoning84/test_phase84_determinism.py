"""
IndiDrive AI — Phase 8.4 | Determinism Tests
=============================================
Verify that Phase 8.4 produces identical output for identical input,
across multiple runs, without any ordering dependence.

Same input → same gate state, same dominant requirement,
same active requirement ordering, same constraints, same reason codes.
"""
import sys
import os
import time
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..'))

from core.reasoning import (
    DecisionArbitrationEngine,
    SafetyGateState,
    RequirementStatus,
)
from core.reasoning.action_abstraction_types import (
    RequirementType, AbstractUrgency, AbstractSeverity, ResponseFamily,
)

from tests.reasoning84.test_helpers_84 import (
    make_requirement, make_abstraction_snapshot, make_world_model,
    make_collision_requirement, make_vru_requirement,
    make_road_hazard_requirement, make_uncertainty_requirement,
    make_degraded_requirement,
)

RUNS = 7  # Run each scenario this many times


class TestDeterminism(unittest.TestCase):

    def setUp(self):
        self.engine = DecisionArbitrationEngine()

    def _run_n(self, world_model, abstraction_snapshot, timestamp, n=RUNS):
        """Run arbitration n times with fixed inputs and return all results."""
        return [
            self.engine.arbitrate(
                world_model=world_model,
                action_abstraction=abstraction_snapshot,
                timestamp=timestamp,
            )
            for _ in range(n)
        ]

    def _assert_all_equal(self, values, label):
        unique = set(str(v) for v in values)
        self.assertEqual(
            len(unique), 1,
            f"Non-deterministic {label}: {values}"
        )

    # -----------------------------------------------------------------------
    # Scenario: normal progress
    # -----------------------------------------------------------------------
    def test_determinism_normal_progress(self):
        """Normal progress scenario: all outputs identical across runs."""
        req = make_requirement(
            req_id="det_normal",
            req_type=RequirementType.NORMAL_PROGRESS,
            priority=0.30,
            urgency=AbstractUrgency.LOW,
            severity=AbstractSeverity.LOW,
            confidence=0.85,
            uncertainty=0.15,
            timestamp=1000.0,
        )
        snap_in = make_abstraction_snapshot(
            requirements=[req],
            response_family=ResponseFamily.NORMAL,
            confidence=0.85,
            uncertainty=0.15,
            input_completeness=0.90,
            timestamp=1000.0,
        )
        wm = make_world_model(completeness=0.90, uncertainty=0.15)
        results = self._run_n(wm, snap_in, timestamp=1000.5)

        gate_states = [r.snapshot.safety_gate_state.value for r in results]
        self._assert_all_equal(gate_states, "gate_state")

        dom_types = [
            (r.snapshot.dominant_requirement.requirement.requirement_type.value
             if r.snapshot.dominant_requirement else "NONE")
            for r in results
        ]
        self._assert_all_equal(dom_types, "dominant_requirement_type")

        planning_modes = [
            r.snapshot.planning_context.planning_mode.value for r in results
        ]
        self._assert_all_equal(planning_modes, "planning_mode")

        req_orderings = [
            tuple(ar.requirement.requirement_id
                  for ar in r.snapshot.arbitrated_requirements)
            for r in results
        ]
        self._assert_all_equal(req_orderings, "requirement_ordering")

    # -----------------------------------------------------------------------
    # Scenario: collision avoidance
    # -----------------------------------------------------------------------
    def test_determinism_collision(self):
        """Collision scenario: all outputs identical across runs."""
        col = make_collision_requirement(req_id="det_col", timestamp=1000.0)
        normal = make_requirement(
            req_id="det_normal_col",
            req_type=RequirementType.NORMAL_PROGRESS,
            priority=0.30,
            timestamp=1000.0,
        )
        snap_in = make_abstraction_snapshot(
            requirements=[col, normal],
            any_safety_critical=True,
            timestamp=1000.0,
        )
        wm = make_world_model()
        results = self._run_n(wm, snap_in, timestamp=1000.5)

        gate_states = [r.snapshot.safety_gate_state.value for r in results]
        self._assert_all_equal(gate_states, "gate_state")

        dom_types = [
            r.snapshot.dominant_requirement.requirement.requirement_type.value
            for r in results
        ]
        self._assert_all_equal(dom_types, "dominant_type")

        conflict_counts = [r.snapshot.conflict_count for r in results]
        self._assert_all_equal(conflict_counts, "conflict_count")

        reason_codes = [
            tuple(sorted(r.snapshot.reason_codes)) for r in results
        ]
        self._assert_all_equal(reason_codes, "reason_codes")

    # -----------------------------------------------------------------------
    # Scenario: multi-hazard compound
    # -----------------------------------------------------------------------
    def test_determinism_multi_hazard(self):
        """Multi-hazard compound: same ordering each run."""
        reqs = [
            make_requirement(
                req_id="det_n",
                req_type=RequirementType.NORMAL_PROGRESS,
                priority=0.28,
                timestamp=1000.0,
            ),
            make_collision_requirement(req_id="det_c", timestamp=1000.0),
            make_vru_requirement(req_id="det_v", timestamp=1000.0),
            make_road_hazard_requirement(req_id="det_h", timestamp=1000.0),
            make_uncertainty_requirement(req_id="det_u", timestamp=1000.0),
        ]
        snap_in = make_abstraction_snapshot(
            requirements=reqs,
            any_safety_critical=True,
            timestamp=1000.0,
        )
        wm = make_world_model()
        results = self._run_n(wm, snap_in, timestamp=1000.5)

        gate_states = [r.snapshot.safety_gate_state.value for r in results]
        self._assert_all_equal(gate_states, "gate_state")

        req_orderings = [
            tuple(ar.requirement.requirement_id
                  for ar in r.snapshot.arbitrated_requirements)
            for r in results
        ]
        self._assert_all_equal(req_orderings, "requirement_ordering")

        constraint_orderings = [
            tuple(c.constraint_id
                  for c in r.snapshot.planning_context.hard_constraints)
            for r in results
        ]
        self._assert_all_equal(constraint_orderings, "hard_constraint_ordering")

    # -----------------------------------------------------------------------
    # Scenario: degraded
    # -----------------------------------------------------------------------
    def test_determinism_degraded(self):
        """Degraded scenario: same gate state across runs."""
        req = make_degraded_requirement(req_id="det_deg", timestamp=1000.0)
        snap_in = make_abstraction_snapshot(
            requirements=[req],
            degraded=True,
            confidence=0.25,
            uncertainty=0.90,
            any_safety_critical=True,
            timestamp=1000.0,
        )
        wm = make_world_model(completeness=0.15, uncertainty=0.90)
        results = self._run_n(wm, snap_in, timestamp=1000.5)

        gate_states = [r.snapshot.safety_gate_state.value for r in results]
        self._assert_all_equal(gate_states, "gate_state")

    # -----------------------------------------------------------------------
    # Scenario: empty inputs
    # -----------------------------------------------------------------------
    def test_determinism_empty_inputs(self):
        """Empty inputs: always UNKNOWN, planning not allowed."""
        results = [self.engine.arbitrate(timestamp=1000.0) for _ in range(RUNS)]
        gate_states = [r.snapshot.safety_gate_state.value for r in results]
        self._assert_all_equal(gate_states, "gate_state")
        planning = [r.snapshot.planning_context.planning_allowed for r in results]
        self._assert_all_equal(planning, "planning_allowed")

    # -----------------------------------------------------------------------
    # Tie-breaking: equal-priority requirements
    # -----------------------------------------------------------------------
    def test_determinism_equal_priority(self):
        """Equal-priority requirements resolve the same dominant every time."""
        reqs = [
            make_requirement(
                req_id="eq_a",
                req_type=RequirementType.HANDLE_ROAD_HAZARD,
                priority=0.60,
                urgency=AbstractUrgency.MEDIUM,
                severity=AbstractSeverity.MEDIUM,
                is_safety_critical=True,
                timestamp=1000.0,
            ),
            make_requirement(
                req_id="eq_b",
                req_type=RequirementType.HANDLE_ROAD_HAZARD,
                priority=0.60,
                urgency=AbstractUrgency.MEDIUM,
                severity=AbstractSeverity.MEDIUM,
                is_safety_critical=True,
                timestamp=1000.0,
            ),
        ]
        snap_in = make_abstraction_snapshot(
            requirements=reqs,
            any_safety_critical=True,
            timestamp=1000.0,
        )
        wm = make_world_model()
        results = self._run_n(wm, snap_in, timestamp=1000.5)
        dom_ids = [
            r.snapshot.dominant_requirement.requirement.requirement_id
            for r in results
        ]
        self._assert_all_equal(dom_ids, "dominant_requirement_id (tie-break)")

    # -----------------------------------------------------------------------
    # Config independence: same output regardless of config instance
    # -----------------------------------------------------------------------
    def test_determinism_across_engine_instances(self):
        """Multiple engine instances with default config produce same output."""
        col = make_collision_requirement(req_id="inst_col", timestamp=1000.0)
        snap_in = make_abstraction_snapshot(
            requirements=[col], any_safety_critical=True, timestamp=1000.0
        )
        wm = make_world_model()
        engines = [DecisionArbitrationEngine() for _ in range(4)]
        results = [
            e.arbitrate(world_model=wm, action_abstraction=snap_in, timestamp=1000.5)
            for e in engines
        ]
        gate_states = [r.snapshot.safety_gate_state.value for r in results]
        self._assert_all_equal(gate_states, "gate_state across engine instances")
        dom_types = [
            r.snapshot.dominant_requirement.requirement.requirement_type.value
            for r in results
        ]
        self._assert_all_equal(dom_types, "dominant_type across engine instances")


if __name__ == "__main__":
    unittest.main()
