"""
IndiDrive AI — Phase 8.4 | Indian Road Scenario Tests
=======================================================
Deterministic tests for realistic Indian-road conditions.

Covers the 10 mandatory scenarios from the spec plus multi-hazard compounds.
"""
import sys
import os
import time
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..'))

from core.reasoning import (
    DecisionArbitrationEngine,
    SafetyGateState,
    RequirementStatus,
    ConstraintHardness,
    PlanningMode,
)
from core.reasoning.action_abstraction_types import (
    RequirementType, AbstractUrgency, AbstractSeverity, ResponseFamily,
)
from core.world_model.world_model_types import (
    WorldModelStatus, InputModuleStatus, WorldAnomalySummary,
)

from tests.reasoning84.test_helpers_84 import (
    make_requirement, make_abstraction_snapshot, make_world_model,
    make_collision_requirement, make_vru_requirement,
    make_road_hazard_requirement, make_uncertainty_requirement,
    make_degraded_requirement,
)

FORBIDDEN_KEYS = {
    "steering", "throttle", "brake", "path_points", "waypoints",
    "trajectory", "steering_angle", "target_speed", "lane_change_command",
    "throttle_cmd", "brake_cmd", "acceleration_cmd", "steer_cmd",
    "path", "waypoint", "mpc_cmd",
}


def _has_forbidden(d: dict) -> list:
    found = []
    for k, v in d.items():
        if k in FORBIDDEN_KEYS:
            found.append(k)
        if isinstance(v, dict):
            found.extend(_has_forbidden(v))
        elif isinstance(v, list):
            for item in v:
                if isinstance(item, dict):
                    found.extend(_has_forbidden(item))
    return found


class TestIndianRoadScenarios(unittest.TestCase):

    def setUp(self):
        self.engine = DecisionArbitrationEngine()

    # -----------------------------------------------------------------------
    # 1. Normal unmarked village road
    # -----------------------------------------------------------------------
    def test_01_normal_village_road(self):
        """Scenario 1: Normal unmarked village road → CLEAR or CAUTION."""
        req = make_requirement(
            req_id="village_normal",
            req_type=RequirementType.NORMAL_PROGRESS,
            priority=0.28,
            urgency=AbstractUrgency.LOW,
            severity=AbstractSeverity.LOW,
            is_safety_critical=False,
            confidence=0.80,
            uncertainty=0.22,
        )
        snap_in = make_abstraction_snapshot(
            requirements=[req],
            response_family=ResponseFamily.NORMAL,
            any_safety_critical=False,
            confidence=0.80,
            uncertainty=0.22,
            input_completeness=0.85,
        )
        wm = make_world_model(
            completeness=0.85, uncertainty=0.22,
            road_type="RURAL", traffic_density="LOW",
        )
        result = self.engine.arbitrate(world_model=wm, action_abstraction=snap_in)
        snap = result.snapshot
        self.assertIn(
            snap.safety_gate_state,
            (SafetyGateState.CLEAR, SafetyGateState.CAUTION),
            f"Village road should be CLEAR or CAUTION, got {snap.safety_gate_state}"
        )
        self.assertTrue(result.is_valid)
        self.assertEqual(_has_forbidden(result.to_dict()), [])

    # -----------------------------------------------------------------------
    # 2. Dense market road with pedestrians
    # -----------------------------------------------------------------------
    def test_02_dense_market_pedestrians(self):
        """Scenario 2: Dense market road with VRUs → RESTRICTED or HIGH_ALERT."""
        vru = make_vru_requirement(
            req_id="market_vru",
            priority=0.75,
            urgency=AbstractUrgency.HIGH,
            severity=AbstractSeverity.HIGH,
        )
        monitor = make_requirement(
            req_id="market_monitor",
            req_type=RequirementType.MONITOR_DYNAMIC_OBJECT,
            priority=0.35,
            urgency=AbstractUrgency.MEDIUM,
            severity=AbstractSeverity.MEDIUM,
            is_safety_critical=False,
        )
        snap_in = make_abstraction_snapshot(
            requirements=[vru, monitor],
            response_family=ResponseFamily.SAFETY_CRITICAL,
            any_safety_critical=True,
            confidence=0.70,
            uncertainty=0.35,
            input_completeness=0.78,
        )
        wm = make_world_model(
            completeness=0.78, uncertainty=0.35,
            road_type="URBAN", traffic_density="HIGH",
            vru_present=True, market_like=True,
        )
        result = self.engine.arbitrate(world_model=wm, action_abstraction=snap_in)
        snap = result.snapshot
        self.assertIn(
            snap.safety_gate_state,
            (SafetyGateState.RESTRICTED, SafetyGateState.HIGH_ALERT,
             SafetyGateState.CRITICAL, SafetyGateState.CAUTION),
        )
        # VRU requirement preserved
        all_types = {
            ar.requirement.requirement_type
            for ar in snap.arbitrated_requirements
        }
        self.assertIn(RequirementType.HANDLE_VULNERABLE_USER, all_types)
        self.assertEqual(_has_forbidden(result.to_dict()), [])

    # -----------------------------------------------------------------------
    # 3. Sudden cattle crossing
    # -----------------------------------------------------------------------
    def test_03_cattle_crossing(self):
        """Scenario 3: Sudden cattle crossing → safety-critical requirement."""
        cattle_vru = make_requirement(
            req_id="cattle_crossing",
            req_type=RequirementType.HANDLE_VULNERABLE_USER,
            priority=0.88,
            urgency=AbstractUrgency.IMMEDIATE,
            severity=AbstractSeverity.CRITICAL,
            confidence=0.80,
            uncertainty=0.25,
            is_safety_critical=True,
            reason_codes=("VRU_CONFLICT", "IMMEDIATE_COLLISION_THREAT"),
        )
        snap_in = make_abstraction_snapshot(
            requirements=[cattle_vru],
            response_family=ResponseFamily.SAFETY_CRITICAL,
            any_safety_critical=True,
            confidence=0.80,
            uncertainty=0.25,
            input_completeness=0.80,
        )
        wm = make_world_model(
            completeness=0.80, uncertainty=0.25,
            cattle_present=True,
        )
        result = self.engine.arbitrate(world_model=wm, action_abstraction=snap_in)
        snap = result.snapshot
        # Must be CRITICAL or HIGH_ALERT — immediate cattle crossing is serious
        self.assertIn(
            snap.safety_gate_state,
            (SafetyGateState.CRITICAL, SafetyGateState.HIGH_ALERT),
            f"Cattle crossing should be CRITICAL/HIGH_ALERT, got {snap.safety_gate_state}"
        )
        # VRU is dominant
        dom = snap.dominant_requirement
        self.assertIsNotNone(dom)
        self.assertEqual(
            dom.requirement.requirement_type,
            RequirementType.HANDLE_VULNERABLE_USER,
        )
        self.assertEqual(_has_forbidden(result.to_dict()), [])

    # -----------------------------------------------------------------------
    # 4. Unsignalized busy intersection
    # -----------------------------------------------------------------------
    def test_04_unsignalized_intersection(self):
        """Scenario 4: Unsignalized busy intersection → intersection + monitor."""
        intersection = make_requirement(
            req_id="intersection_1",
            req_type=RequirementType.HANDLE_INTERSECTION,
            priority=0.60,
            urgency=AbstractUrgency.MEDIUM,
            severity=AbstractSeverity.MEDIUM,
            is_safety_critical=False,
        )
        monitor = make_requirement(
            req_id="monitor_dyn",
            req_type=RequirementType.MONITOR_DYNAMIC_OBJECT,
            priority=0.40,
            urgency=AbstractUrgency.MEDIUM,
            severity=AbstractSeverity.MEDIUM,
            is_safety_critical=False,
        )
        snap_in = make_abstraction_snapshot(
            requirements=[intersection, monitor],
            response_family=ResponseFamily.CAUTION,
            any_safety_critical=False,
            confidence=0.70,
            uncertainty=0.38,
            input_completeness=0.75,
        )
        wm = make_world_model(
            completeness=0.75, uncertainty=0.38,
            intersection_state="INTERSECTION",
            traffic_density="HIGH",
        )
        result = self.engine.arbitrate(world_model=wm, action_abstraction=snap_in)
        snap = result.snapshot
        # Should be RESTRICTED or CAUTION due to uncertainty + intersection
        self.assertIn(
            snap.safety_gate_state,
            (SafetyGateState.CAUTION, SafetyGateState.RESTRICTED,
             SafetyGateState.HIGH_ALERT),
        )
        # HANDLE_INTERSECTION is preserved
        all_types = {
            ar.requirement.requirement_type
            for ar in snap.arbitrated_requirements
        }
        self.assertIn(RequirementType.HANDLE_INTERSECTION, all_types)
        self.assertEqual(_has_forbidden(result.to_dict()), [])

    # -----------------------------------------------------------------------
    # 5. Highway merge
    # -----------------------------------------------------------------------
    def test_05_highway_merge(self):
        """Scenario 5: Highway merge → HANDLE_MERGE preserved."""
        merge = make_requirement(
            req_id="merge_1",
            req_type=RequirementType.HANDLE_MERGE,
            priority=0.55,
            urgency=AbstractUrgency.MEDIUM,
            severity=AbstractSeverity.MEDIUM,
            is_safety_critical=False,
        )
        snap_in = make_abstraction_snapshot(
            requirements=[merge],
            response_family=ResponseFamily.CAUTION,
            any_safety_critical=False,
            confidence=0.72,
            uncertainty=0.32,
            input_completeness=0.80,
        )
        wm = make_world_model(
            completeness=0.80, uncertainty=0.32,
            road_type="HIGHWAY", traffic_density="MEDIUM",
        )
        result = self.engine.arbitrate(world_model=wm, action_abstraction=snap_in)
        snap = result.snapshot
        all_types = {
            ar.requirement.requirement_type
            for ar in snap.arbitrated_requirements
        }
        self.assertIn(RequirementType.HANDLE_MERGE, all_types)
        dom = snap.dominant_requirement
        self.assertIsNotNone(dom)
        self.assertEqual(_has_forbidden(result.to_dict()), [])

    # -----------------------------------------------------------------------
    # 6. Pothole / damaged narrow road
    # -----------------------------------------------------------------------
    def test_06_pothole_narrow_road(self):
        """Scenario 6: Pothole on narrow road → road hazard + drivable restriction."""
        hazard = make_road_hazard_requirement(req_id="pothole_1")
        drivable = make_requirement(
            req_id="drivable_1",
            req_type=RequirementType.MAINTAIN_DRIVABLE_REGION,
            priority=0.58,
            urgency=AbstractUrgency.MEDIUM,
            severity=AbstractSeverity.MEDIUM,
            is_safety_critical=True,
        )
        narrow = make_requirement(
            req_id="narrow_1",
            req_type=RequirementType.HANDLE_NARROW_ROAD,
            priority=0.45,
            urgency=AbstractUrgency.MEDIUM,
            severity=AbstractSeverity.MEDIUM,
            is_safety_critical=False,
        )
        anomaly = WorldAnomalySummary(
            anomaly_id="pot_1", anomaly_type="POTHOLE",
            severity="HIGH", in_drivable_area=True,
        )
        snap_in = make_abstraction_snapshot(
            requirements=[hazard, drivable, narrow],
            response_family=ResponseFamily.HAZARD_HANDLING,
            any_safety_critical=True,
            confidence=0.70,
            uncertainty=0.35,
            input_completeness=0.80,
        )
        wm = make_world_model(
            completeness=0.80, uncertainty=0.35,
            available_width_m=3.5,
            anomalies=[anomaly],
        )
        result = self.engine.arbitrate(world_model=wm, action_abstraction=snap_in)
        snap = result.snapshot
        self.assertIn(
            snap.safety_gate_state,
            (SafetyGateState.RESTRICTED, SafetyGateState.HIGH_ALERT,
             SafetyGateState.CAUTION),
        )
        all_types = {ar.requirement.requirement_type
                     for ar in snap.arbitrated_requirements}
        self.assertIn(RequirementType.HANDLE_ROAD_HAZARD, all_types)
        self.assertIn(RequirementType.MAINTAIN_DRIVABLE_REGION, all_types)
        self.assertEqual(_has_forbidden(result.to_dict()), [])

    # -----------------------------------------------------------------------
    # 7. Wrong-side vehicle
    # -----------------------------------------------------------------------
    def test_07_wrong_side_vehicle(self):
        """Scenario 7: Wrong-side vehicle → trajectory conflict / collision avoidance."""
        traj_conflict = make_requirement(
            req_id="wrong_side_1",
            req_type=RequirementType.HANDLE_TRAJECTORY_CONFLICT,
            priority=0.85,
            urgency=AbstractUrgency.HIGH,
            severity=AbstractSeverity.HIGH,
            confidence=0.80,
            uncertainty=0.25,
            is_safety_critical=True,
            reason_codes=("TRAJECTORY_CONFLICT",),
        )
        snap_in = make_abstraction_snapshot(
            requirements=[traj_conflict],
            response_family=ResponseFamily.CONFLICT_HANDLING,
            any_safety_critical=True,
            confidence=0.80,
            uncertainty=0.25,
            input_completeness=0.82,
        )
        wm = make_world_model(completeness=0.82, uncertainty=0.25)
        result = self.engine.arbitrate(world_model=wm, action_abstraction=snap_in)
        snap = result.snapshot
        self.assertIn(
            snap.safety_gate_state,
            (SafetyGateState.HIGH_ALERT, SafetyGateState.CRITICAL,
             SafetyGateState.RESTRICTED),
        )
        dom = snap.dominant_requirement
        self.assertIsNotNone(dom)
        self.assertEqual(
            dom.requirement.requirement_type,
            RequirementType.HANDLE_TRAJECTORY_CONFLICT,
        )
        self.assertEqual(_has_forbidden(result.to_dict()), [])

    # -----------------------------------------------------------------------
    # 8. Construction zone
    # -----------------------------------------------------------------------
    def test_08_construction_zone(self):
        """Scenario 8: Construction zone → road hazard + uncertainty."""
        hazard = make_road_hazard_requirement(req_id="const_hazard")
        uncertainty_req = make_uncertainty_requirement(req_id="const_uncertainty")
        snap_in = make_abstraction_snapshot(
            requirements=[hazard, uncertainty_req],
            response_family=ResponseFamily.HAZARD_HANDLING,
            any_safety_critical=True,
            confidence=0.60,
            uncertainty=0.55,
            input_completeness=0.70,
        )
        wm = make_world_model(
            completeness=0.70, uncertainty=0.55,
            road_type="URBAN", traffic_density="MEDIUM",
        )
        result = self.engine.arbitrate(world_model=wm, action_abstraction=snap_in)
        snap = result.snapshot
        self.assertIn(
            snap.safety_gate_state,
            (SafetyGateState.RESTRICTED, SafetyGateState.HIGH_ALERT,
             SafetyGateState.CAUTION),
        )
        self.assertEqual(_has_forbidden(result.to_dict()), [])

    # -----------------------------------------------------------------------
    # 9. Degraded camera / LiDAR / fusion
    # -----------------------------------------------------------------------
    def test_09_degraded_sensors(self):
        """Scenario 9: Sensor degradation → DEGRADED or RESTRICTED gate."""
        degraded_req = make_degraded_requirement(req_id="sensor_deg")
        snap_in = make_abstraction_snapshot(
            requirements=[degraded_req],
            response_family=ResponseFamily.DEGRADED,
            any_safety_critical=True,
            degraded=True,
            confidence=0.30,
            uncertainty=0.88,
            input_completeness=0.20,
        )
        wm = make_world_model(
            status=WorldModelStatus.DEGRADED,
            completeness=0.20,
            uncertainty=0.88,
            prediction_status=InputModuleStatus.UNAVAILABLE,
        )
        result = self.engine.arbitrate(world_model=wm, action_abstraction=snap_in)
        snap = result.snapshot
        self.assertIn(
            snap.safety_gate_state,
            (SafetyGateState.DEGRADED, SafetyGateState.RESTRICTED,
             SafetyGateState.UNKNOWN),
        )
        self.assertTrue(snap.degraded)
        self.assertEqual(_has_forbidden(result.to_dict()), [])

    # -----------------------------------------------------------------------
    # 10. Missing / invalid World Model
    # -----------------------------------------------------------------------
    def test_10_missing_world_model(self):
        """Scenario 10: No world model → UNKNOWN or DEGRADED state."""
        req = make_requirement(req_type=RequirementType.NORMAL_PROGRESS)
        snap_in = make_abstraction_snapshot(requirements=[req])
        # No world model passed
        result = self.engine.arbitrate(action_abstraction=snap_in)
        snap = result.snapshot
        self.assertIn(
            snap.safety_gate_state,
            (SafetyGateState.UNKNOWN, SafetyGateState.DEGRADED,
             SafetyGateState.RESTRICTED),
        )
        self.assertEqual(_has_forbidden(result.to_dict()), [])


# ===========================================================================
# Multi-hazard compound scenarios
# ===========================================================================

class TestMultiHazardScenarios(unittest.TestCase):

    def setUp(self):
        self.engine = DecisionArbitrationEngine()

    def test_pedestrian_cattle_narrow_road(self):
        """Pedestrian + cattle + narrow road: all requirements preserved."""
        vru_ped = make_vru_requirement(req_id="ped_1")
        vru_cattle = make_requirement(
            req_id="cattle_1",
            req_type=RequirementType.HANDLE_VULNERABLE_USER,
            priority=0.82,
            urgency=AbstractUrgency.IMMEDIATE,
            severity=AbstractSeverity.CRITICAL,
            is_safety_critical=True,
            reason_codes=("VRU_CONFLICT",),
        )
        narrow = make_requirement(
            req_id="narrow_2",
            req_type=RequirementType.HANDLE_NARROW_ROAD,
            priority=0.45,
            urgency=AbstractUrgency.MEDIUM,
            severity=AbstractSeverity.MEDIUM,
            is_safety_critical=False,
        )
        snap_in = make_abstraction_snapshot(
            requirements=[vru_ped, vru_cattle, narrow],
            any_safety_critical=True,
        )
        result = self.engine.arbitrate(
            world_model=make_world_model(cattle_present=True, vru_present=True,
                                         available_width_m=3.2),
            action_abstraction=snap_in,
        )
        snap = result.snapshot
        all_types = {ar.requirement.requirement_type
                     for ar in snap.arbitrated_requirements}
        # All three requirements preserved
        self.assertIn(RequirementType.HANDLE_VULNERABLE_USER, all_types)
        self.assertIn(RequirementType.HANDLE_NARROW_ROAD, all_types)
        # Dominant is a VRU requirement (safety-critical)
        dom = snap.dominant_requirement
        self.assertIsNotNone(dom)
        self.assertEqual(
            dom.requirement.requirement_type,
            RequirementType.HANDLE_VULNERABLE_USER,
        )
        self.assertEqual(_has_forbidden(result.to_dict()), [])

    def test_highway_merge_fast_approach_uncertain(self):
        """Highway merge + fast approach + uncertain prediction."""
        merge = make_requirement(
            req_id="hwy_merge",
            req_type=RequirementType.HANDLE_MERGE,
            priority=0.58,
            urgency=AbstractUrgency.MEDIUM,
            severity=AbstractSeverity.MEDIUM,
            is_safety_critical=False,
        )
        collision = make_collision_requirement(
            req_id="hwy_col",
            urgency=AbstractUrgency.HIGH,
            severity=AbstractSeverity.HIGH,
        )
        uncertainty_req = make_uncertainty_requirement(req_id="hwy_unc")
        snap_in = make_abstraction_snapshot(
            requirements=[merge, collision, uncertainty_req],
            any_safety_critical=True,
            confidence=0.65,
            uncertainty=0.50,
        )
        result = self.engine.arbitrate(
            world_model=make_world_model(
                completeness=0.75, uncertainty=0.50, road_type="HIGHWAY"
            ),
            action_abstraction=snap_in,
        )
        snap = result.snapshot
        # Collision avoidance must dominate
        dom = snap.dominant_requirement
        self.assertIsNotNone(dom)
        self.assertEqual(
            dom.requirement.requirement_type,
            RequirementType.COLLISION_AVOIDANCE_REQUIRED,
        )
        # All three are preserved
        all_types = {ar.requirement.requirement_type
                     for ar in snap.arbitrated_requirements}
        self.assertIn(RequirementType.HANDLE_MERGE, all_types)
        self.assertIn(RequirementType.HANDLE_UNCERTAINTY, all_types)
        self.assertEqual(_has_forbidden(result.to_dict()), [])

    def test_market_area_vru_weak_lane_structure(self):
        """Market area + VRU + weak lane structure: RESTRICTED or higher."""
        vru = make_vru_requirement(req_id="market_vru2", priority=0.78)
        drivable = make_requirement(
            req_id="market_drivable",
            req_type=RequirementType.MAINTAIN_DRIVABLE_REGION,
            priority=0.55,
            urgency=AbstractUrgency.MEDIUM,
            severity=AbstractSeverity.MEDIUM,
            is_safety_critical=True,
        )
        monitor = make_requirement(
            req_id="market_mon",
            req_type=RequirementType.MONITOR_UNPREDICTABLE_OBJECT,
            priority=0.40,
            urgency=AbstractUrgency.MEDIUM,
            severity=AbstractSeverity.LOW,
            is_safety_critical=False,
        )
        snap_in = make_abstraction_snapshot(
            requirements=[vru, drivable, monitor],
            any_safety_critical=True,
            uncertainty=0.45,
        )
        result = self.engine.arbitrate(
            world_model=make_world_model(
                market_like=True, vru_present=True, uncertainty=0.45
            ),
            action_abstraction=snap_in,
        )
        snap = result.snapshot
        self.assertIn(
            snap.safety_gate_state,
            (SafetyGateState.RESTRICTED, SafetyGateState.HIGH_ALERT,
             SafetyGateState.CRITICAL, SafetyGateState.CAUTION),
        )
        # VRU dominates over drivable-region
        dom = snap.dominant_requirement
        self.assertIsNotNone(dom)
        self.assertEqual(
            dom.requirement.requirement_type,
            RequirementType.HANDLE_VULNERABLE_USER,
        )
        self.assertEqual(_has_forbidden(result.to_dict()), [])

    def test_all_requirements_represented_multi_hazard(self):
        """In any multi-hazard case, no safety-critical requirement is silently lost."""
        reqs = [
            make_requirement(req_id="n", req_type=RequirementType.NORMAL_PROGRESS),
            make_collision_requirement(req_id="c"),
            make_vru_requirement(req_id="v"),
            make_road_hazard_requirement(req_id="h"),
            make_uncertainty_requirement(req_id="u"),
        ]
        snap_in = make_abstraction_snapshot(requirements=reqs, any_safety_critical=True)
        result = self.engine.arbitrate(
            world_model=make_world_model(), action_abstraction=snap_in
        )
        all_types = {ar.requirement.requirement_type
                     for ar in result.snapshot.arbitrated_requirements}
        for req in reqs:
            self.assertIn(req.requirement_type, all_types,
                          f"Requirement {req.requirement_type} lost in multi-hazard")

    def test_dominant_is_deterministic_multi_hazard(self):
        """Same compound input always yields same dominant requirement."""
        reqs = [
            make_requirement(req_id="n", req_type=RequirementType.NORMAL_PROGRESS,
                             timestamp=1000.0),
            make_collision_requirement(req_id="c", timestamp=1000.0),
            make_vru_requirement(req_id="v", timestamp=1000.0),
        ]
        snap_in = make_abstraction_snapshot(
            requirements=reqs, any_safety_critical=True, timestamp=1000.0
        )
        wm = make_world_model()
        results = [
            self.engine.arbitrate(
                world_model=wm, action_abstraction=snap_in, timestamp=1000.5
            )
            for _ in range(5)
        ]
        dom_types = [
            r.snapshot.dominant_requirement.requirement.requirement_type
            for r in results
        ]
        self.assertEqual(len(set(str(t) for t in dom_types)), 1,
                         f"Non-deterministic dominant: {dom_types}")


if __name__ == "__main__":
    unittest.main()
