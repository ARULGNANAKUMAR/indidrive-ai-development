"""
IndiDrive AI — Phase 8.4 | Core Tests
======================================
Tests for Decision Arbitration & Safety Gate.

Covers:
  - Basic: empty, normal, single hazard, partial/degraded inputs
  - Safety gate states: all 7 states
  - Dominant requirement selection
  - Constraint classification (hard / soft)
  - Requirement statuses
  - Conflict detection
  - Temporal validity
  - Uncertainty handling
  - Negative: no forbidden vehicle-control fields
  - Planning context integrity
"""
import sys
import os
import time
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..'))

from core.reasoning import (
    DecisionArbitrationEngine,
    ArbitrationConfig,
    SafetyGateState,
    PlanningMode,
    RequirementStatus,
    TemporalValidity,
    ConstraintHardness,
    ArbitratedRequirement,
    SafetyConstraint,
)
from core.reasoning.arbitration_validator import ArbitrationValidator
from core.reasoning.arbitration_snapshot import (
    arbitration_snapshot_summary,
    arbitration_snapshot_to_json,
    find_arbitrated_by_type,
    is_arbitration_snapshot_stale,
)
from core.reasoning.action_abstraction_types import (
    RequirementType, AbstractUrgency, AbstractSeverity,
    ResponseFamily,
)

from tests.reasoning84.test_helpers_84 import (
    make_requirement, make_abstraction_snapshot, make_world_model,
    make_collision_requirement, make_vru_requirement,
    make_road_hazard_requirement, make_uncertainty_requirement,
    make_degraded_requirement,
)

# ---------------------------------------------------------------------------
# Forbidden fields that must NEVER appear in Phase 8.4 output
# ---------------------------------------------------------------------------
FORBIDDEN_KEYS = {
    "steering", "throttle", "brake", "path_points", "waypoints",
    "trajectory", "steering_angle", "target_speed", "lane_change_command",
    "throttle_cmd", "brake_cmd", "acceleration_cmd", "steer_cmd",
    "path", "waypoint", "mpc_cmd",
}


def _has_forbidden(d: dict) -> list:
    """Recursively check for forbidden keys in a dict."""
    found = []
    for k, v in d.items():
        if k in FORBIDDEN_KEYS:
            found.append(k)
        if isinstance(v, dict):
            found.extend(_has_forbidden(v))
        elif isinstance(v, list):
            for item in v:
                if isinstance(item, dict):
                    found.extend(_has_forbidden(item))
    return found


# ===========================================================================
# Basic inputs
# ===========================================================================

class TestBasicInputs(unittest.TestCase):

    def setUp(self):
        self.engine = DecisionArbitrationEngine()

    def test_none_inputs(self):
        """All None → empty/unknown state, planning not allowed."""
        result = self.engine.arbitrate()
        self.assertEqual(result.status, "empty")
        snap = result.snapshot
        self.assertEqual(snap.safety_gate_state, SafetyGateState.UNKNOWN)
        self.assertFalse(snap.planning_context.planning_allowed)

    def test_none_abstraction_with_world_model(self):
        """World model present but no abstraction → unknown state."""
        wm = make_world_model()
        result = self.engine.arbitrate(world_model=wm)
        self.assertEqual(result.status, "empty")
        snap = result.snapshot
        self.assertEqual(snap.safety_gate_state, SafetyGateState.UNKNOWN)
        self.assertFalse(snap.planning_context.planning_allowed)

    def test_normal_progress_only(self):
        """Single NORMAL_PROGRESS requirement → CLEAR or CAUTION gate."""
        req = make_requirement(
            req_type=RequirementType.NORMAL_PROGRESS,
            priority=0.3,
            urgency=AbstractUrgency.LOW,
            severity=AbstractSeverity.LOW,
            is_safety_critical=False,
        )
        snap_in = make_abstraction_snapshot(
            requirements=[req],
            response_family=ResponseFamily.NORMAL,
            any_safety_critical=False,
            confidence=0.85,
            uncertainty=0.15,
            input_completeness=0.90,
        )
        wm = make_world_model(completeness=0.90, uncertainty=0.15)
        result = self.engine.arbitrate(
            world_model=wm, action_abstraction=snap_in
        )
        self.assertTrue(result.is_valid)
        snap = result.snapshot
        self.assertIn(snap.safety_gate_state,
                      (SafetyGateState.CLEAR, SafetyGateState.CAUTION))
        self.assertTrue(snap.planning_context.planning_allowed)
        # Dominant requirement is NORMAL_PROGRESS
        dom = snap.dominant_requirement
        self.assertIsNotNone(dom)
        self.assertEqual(
            dom.requirement.requirement_type,
            RequirementType.NORMAL_PROGRESS,
        )

    def test_empty_requirements(self):
        """Empty requirement list → degraded/unknown."""
        snap_in = make_abstraction_snapshot(requirements=[])
        result = self.engine.arbitrate(action_abstraction=snap_in)
        snap = result.snapshot
        # No dominant requirement
        self.assertIsNone(snap.dominant_requirement)

    def test_result_always_present(self):
        """ArbitrationResult is always returned, never raises."""
        for _ in range(5):
            result = self.engine.arbitrate(
                world_model=None,
                situation_state=None,
                behavior_state=None,
                action_abstraction=None,
            )
            self.assertIsNotNone(result)
            self.assertIsNotNone(result.snapshot)


# ===========================================================================
# Safety gate states
# ===========================================================================

class TestSafetyGateStates(unittest.TestCase):

    def setUp(self):
        self.engine = DecisionArbitrationEngine()

    def _arbitrate(self, reqs, completeness=0.85, uncertainty=0.20,
                   any_safety_critical=None, response_family=ResponseFamily.SAFETY_CRITICAL,
                   degraded=False):
        if any_safety_critical is None:
            any_safety_critical = any(r.is_safety_critical for r in reqs)
        snap_in = make_abstraction_snapshot(
            requirements=reqs,
            response_family=response_family,
            any_safety_critical=any_safety_critical,
            confidence=1.0 - uncertainty,
            uncertainty=uncertainty,
            input_completeness=completeness,
            degraded=degraded,
        )
        wm = make_world_model(completeness=completeness, uncertainty=uncertainty)
        return self.engine.arbitrate(world_model=wm, action_abstraction=snap_in)

    def test_critical_gate(self):
        """IMMEDIATE urgency + CRITICAL severity + collision → CRITICAL gate."""
        req = make_collision_requirement(
            urgency=AbstractUrgency.IMMEDIATE,
            severity=AbstractSeverity.CRITICAL,
        )
        result = self._arbitrate([req])
        self.assertEqual(
            result.snapshot.safety_gate_state,
            SafetyGateState.CRITICAL,
        )

    def test_high_alert_gate(self):
        """High priority VRU requirement → HIGH_ALERT gate."""
        req = make_vru_requirement(
            priority=0.85,
            urgency=AbstractUrgency.HIGH,
            severity=AbstractSeverity.HIGH,
        )
        result = self._arbitrate([req])
        self.assertIn(
            result.snapshot.safety_gate_state,
            (SafetyGateState.HIGH_ALERT, SafetyGateState.CRITICAL),
        )

    def test_restricted_gate_uncertainty(self):
        """High uncertainty → RESTRICTED gate."""
        req = make_uncertainty_requirement(priority=0.55)
        result = self._arbitrate(
            [req], uncertainty=0.70,
            response_family=ResponseFamily.UNCERTAINTY_MANAGEMENT,
        )
        self.assertIn(
            result.snapshot.safety_gate_state,
            (SafetyGateState.RESTRICTED, SafetyGateState.DEGRADED),
        )

    def test_degraded_gate(self):
        """Degraded abstraction snapshot → DEGRADED gate."""
        req = make_degraded_requirement()
        snap_in = make_abstraction_snapshot(
            requirements=[req],
            degraded=True,
            uncertainty=0.90,
            confidence=0.10,
            input_completeness=0.20,
            any_safety_critical=True,
        )
        wm = make_world_model(completeness=0.20, uncertainty=0.90)
        result = self.engine.arbitrate(
            world_model=wm, action_abstraction=snap_in
        )
        self.assertIn(
            result.snapshot.safety_gate_state,
            (SafetyGateState.DEGRADED, SafetyGateState.UNKNOWN),
        )

    def test_clear_gate(self):
        """Clean normal-progress situation → CLEAR gate."""
        req = make_requirement(
            req_type=RequirementType.NORMAL_PROGRESS,
            priority=0.25,
            urgency=AbstractUrgency.NONE,
            severity=AbstractSeverity.NONE,
            is_safety_critical=False,
            confidence=0.95,
            uncertainty=0.05,
        )
        snap_in = make_abstraction_snapshot(
            requirements=[req],
            response_family=ResponseFamily.NORMAL,
            any_safety_critical=False,
            confidence=0.95,
            uncertainty=0.05,
            input_completeness=0.95,
        )
        wm = make_world_model(completeness=0.95, uncertainty=0.05)
        result = self.engine.arbitrate(
            world_model=wm, action_abstraction=snap_in
        )
        self.assertIn(
            result.snapshot.safety_gate_state,
            (SafetyGateState.CLEAR, SafetyGateState.CAUTION),
        )

    def test_unknown_gate_no_abstraction(self):
        """No abstraction → UNKNOWN gate."""
        result = self.engine.arbitrate()
        self.assertEqual(
            result.snapshot.safety_gate_state,
            SafetyGateState.UNKNOWN,
        )


# ===========================================================================
# Dominant requirement
# ===========================================================================

class TestDominantRequirement(unittest.TestCase):

    def setUp(self):
        self.engine = DecisionArbitrationEngine()

    def test_collision_dominates_normal_progress(self):
        """COLLISION_AVOIDANCE_REQUIRED must dominate NORMAL_PROGRESS."""
        normal = make_requirement(
            req_id="req_normal",
            req_type=RequirementType.NORMAL_PROGRESS,
            priority=0.3,
        )
        collision = make_collision_requirement(req_id="req_col")
        snap_in = make_abstraction_snapshot(
            requirements=[normal, collision],
            any_safety_critical=True,
        )
        wm = make_world_model()
        result = self.engine.arbitrate(world_model=wm, action_abstraction=snap_in)
        dom = result.snapshot.dominant_requirement
        self.assertIsNotNone(dom)
        self.assertEqual(
            dom.requirement.requirement_type,
            RequirementType.COLLISION_AVOIDANCE_REQUIRED,
        )

    def test_vru_dominates_normal_progress(self):
        """HANDLE_VULNERABLE_USER must dominate NORMAL_PROGRESS."""
        normal = make_requirement(req_id="req_normal",
                                  req_type=RequirementType.NORMAL_PROGRESS)
        vru = make_vru_requirement(req_id="req_vru")
        snap_in = make_abstraction_snapshot(
            requirements=[normal, vru], any_safety_critical=True
        )
        result = self.engine.arbitrate(
            world_model=make_world_model(), action_abstraction=snap_in
        )
        dom = result.snapshot.dominant_requirement
        self.assertIsNotNone(dom)
        self.assertEqual(
            dom.requirement.requirement_type,
            RequirementType.HANDLE_VULNERABLE_USER,
        )

    def test_only_one_dominant(self):
        """Exactly one DOMINANT requirement per snapshot."""
        reqs = [
            make_collision_requirement(req_id="r1"),
            make_vru_requirement(req_id="r2"),
            make_road_hazard_requirement(req_id="r3"),
        ]
        snap_in = make_abstraction_snapshot(requirements=reqs, any_safety_critical=True)
        result = self.engine.arbitrate(
            world_model=make_world_model(), action_abstraction=snap_in
        )
        dominant_count = sum(
            1 for ar in result.snapshot.arbitrated_requirements
            if ar.status == RequirementStatus.DOMINANT
        )
        self.assertEqual(dominant_count, 1)

    def test_dominant_is_in_active_requirements(self):
        """Dominant requirement appears in planning_context.active_requirements."""
        req = make_collision_requirement()
        snap_in = make_abstraction_snapshot(requirements=[req], any_safety_critical=True)
        result = self.engine.arbitrate(
            world_model=make_world_model(), action_abstraction=snap_in
        )
        ctx = result.snapshot.planning_context
        active_types = [
            ar.requirement.requirement_type
            for ar in ctx.active_requirements
        ]
        self.assertIn(RequirementType.COLLISION_AVOIDANCE_REQUIRED, active_types)


# ===========================================================================
# Constraint classification
# ===========================================================================

class TestConstraintClassification(unittest.TestCase):

    def setUp(self):
        self.engine = DecisionArbitrationEngine()

    def test_collision_generates_hard_constraint(self):
        """COLLISION_AVOIDANCE_REQUIRED → HARD constraint."""
        req = make_collision_requirement()
        snap_in = make_abstraction_snapshot(requirements=[req], any_safety_critical=True)
        result = self.engine.arbitrate(
            world_model=make_world_model(), action_abstraction=snap_in
        )
        ctx = result.snapshot.planning_context
        self.assertGreater(ctx.hard_constraint_count, 0)
        for hc in ctx.hard_constraints:
            self.assertEqual(hc.hardness, ConstraintHardness.HARD)

    def test_vru_generates_hard_constraint(self):
        """HANDLE_VULNERABLE_USER → HARD constraint."""
        req = make_vru_requirement()
        snap_in = make_abstraction_snapshot(requirements=[req], any_safety_critical=True)
        result = self.engine.arbitrate(
            world_model=make_world_model(), action_abstraction=snap_in
        )
        ctx = result.snapshot.planning_context
        self.assertGreater(ctx.hard_constraint_count, 0)

    def test_normal_progress_soft_constraint(self):
        """NORMAL_PROGRESS → SOFT constraint."""
        req = make_requirement(
            req_type=RequirementType.NORMAL_PROGRESS,
            priority=0.3,
            is_safety_critical=False,
        )
        snap_in = make_abstraction_snapshot(
            requirements=[req],
            any_safety_critical=False,
            response_family=ResponseFamily.NORMAL,
        )
        wm = make_world_model(completeness=0.90, uncertainty=0.15)
        result = self.engine.arbitrate(world_model=wm, action_abstraction=snap_in)
        ctx = result.snapshot.planning_context
        self.assertGreater(ctx.soft_constraint_count, 0)

    def test_hard_constraints_have_hard_hardness(self):
        """Every hard constraint must have hardness=HARD."""
        req = make_collision_requirement()
        snap_in = make_abstraction_snapshot(requirements=[req], any_safety_critical=True)
        result = self.engine.arbitrate(
            world_model=make_world_model(), action_abstraction=snap_in
        )
        for hc in result.snapshot.planning_context.hard_constraints:
            self.assertEqual(hc.hardness, ConstraintHardness.HARD, hc.constraint_id)


# ===========================================================================
# Conflict detection
# ===========================================================================

class TestConflictDetection(unittest.TestCase):

    def setUp(self):
        self.engine = DecisionArbitrationEngine()

    def test_normal_progress_vs_collision(self):
        """NORMAL_PROGRESS conflicts with COLLISION_AVOIDANCE_REQUIRED."""
        normal = make_requirement(
            req_id="req_normal",
            req_type=RequirementType.NORMAL_PROGRESS,
            priority=0.3,
        )
        collision = make_collision_requirement(req_id="req_col")
        snap_in = make_abstraction_snapshot(
            requirements=[normal, collision],
            any_safety_critical=True,
        )
        result = self.engine.arbitrate(
            world_model=make_world_model(), action_abstraction=snap_in
        )
        snap = result.snapshot
        # Conflict should be recorded
        self.assertGreater(snap.conflict_count, 0)
        conflict = snap.conflicts[0]
        self.assertEqual(conflict.reason_code, "SAFETY_PRIORITY_OVERRIDE")

    def test_suppressed_requirement_preserved(self):
        """Suppressed requirement must remain in arbitrated list (not deleted)."""
        normal = make_requirement(req_id="req_normal",
                                  req_type=RequirementType.NORMAL_PROGRESS)
        collision = make_collision_requirement(req_id="req_col")
        snap_in = make_abstraction_snapshot(
            requirements=[normal, collision], any_safety_critical=True
        )
        result = self.engine.arbitrate(
            world_model=make_world_model(), action_abstraction=snap_in
        )
        all_types = {
            ar.requirement.requirement_type
            for ar in result.snapshot.arbitrated_requirements
        }
        self.assertIn(RequirementType.NORMAL_PROGRESS, all_types)
        self.assertIn(RequirementType.COLLISION_AVOIDANCE_REQUIRED, all_types)

    def test_suppressed_requirement_has_suppressed_status(self):
        """The lower-priority conflicting requirement is SUPPRESSED."""
        normal = make_requirement(req_id="req_normal",
                                  req_type=RequirementType.NORMAL_PROGRESS)
        collision = make_collision_requirement(req_id="req_col")
        snap_in = make_abstraction_snapshot(
            requirements=[normal, collision], any_safety_critical=True
        )
        result = self.engine.arbitrate(
            world_model=make_world_model(), action_abstraction=snap_in
        )
        normal_ar = next(
            (ar for ar in result.snapshot.arbitrated_requirements
             if ar.requirement.requirement_type == RequirementType.NORMAL_PROGRESS),
            None,
        )
        self.assertIsNotNone(normal_ar)
        self.assertEqual(normal_ar.status, RequirementStatus.SUPPRESSED)

    def test_safety_critical_not_lost_in_multi_hazard(self):
        """All safety-critical requirements are preserved even if suppressed."""
        reqs = [
            make_requirement(req_id="n1", req_type=RequirementType.NORMAL_PROGRESS),
            make_collision_requirement(req_id="c1"),
            make_vru_requirement(req_id="v1"),
            make_road_hazard_requirement(req_id="h1"),
        ]
        snap_in = make_abstraction_snapshot(requirements=reqs, any_safety_critical=True)
        result = self.engine.arbitrate(
            world_model=make_world_model(), action_abstraction=snap_in
        )
        all_types = {
            ar.requirement.requirement_type
            for ar in result.snapshot.arbitrated_requirements
        }
        self.assertIn(RequirementType.COLLISION_AVOIDANCE_REQUIRED, all_types)
        self.assertIn(RequirementType.HANDLE_VULNERABLE_USER, all_types)
        self.assertIn(RequirementType.HANDLE_ROAD_HAZARD, all_types)


# ===========================================================================
# Temporal validity
# ===========================================================================

class TestTemporalValidity(unittest.TestCase):

    def setUp(self):
        self.engine = DecisionArbitrationEngine()

    def test_fresh_requirement_is_valid(self):
        """A newly generated requirement should be VALID."""
        req = make_collision_requirement(timestamp=time.time())
        snap_in = make_abstraction_snapshot(requirements=[req], any_safety_critical=True)
        result = self.engine.arbitrate(
            world_model=make_world_model(), action_abstraction=snap_in
        )
        col_ar = next(
            (ar for ar in result.snapshot.arbitrated_requirements
             if ar.requirement.requirement_type
             == RequirementType.COLLISION_AVOIDANCE_REQUIRED),
            None,
        )
        self.assertIsNotNone(col_ar)
        self.assertIn(col_ar.temporal_validity,
                      (TemporalValidity.VALID, TemporalValidity.AGING))

    def test_old_requirement_is_stale_or_expired(self):
        """A very old requirement should be STALE or EXPIRED."""
        old_timestamp = time.time() - 10.0  # 10 seconds ago
        req = make_collision_requirement(timestamp=old_timestamp)
        snap_in = make_abstraction_snapshot(requirements=[req], any_safety_critical=True)
        result = self.engine.arbitrate(
            world_model=make_world_model(), action_abstraction=snap_in,
            timestamp=time.time(),
        )
        col_ar = next(
            (ar for ar in result.snapshot.arbitrated_requirements
             if ar.requirement.requirement_type
             == RequirementType.COLLISION_AVOIDANCE_REQUIRED),
            None,
        )
        self.assertIsNotNone(col_ar)
        self.assertIn(
            col_ar.temporal_validity,
            (TemporalValidity.STALE, TemporalValidity.EXPIRED),
        )

    def test_expired_requirement_not_dominant(self):
        """An EXPIRED requirement cannot be DOMINANT."""
        old_timestamp = time.time() - 10.0
        req = make_collision_requirement(timestamp=old_timestamp)
        snap_in = make_abstraction_snapshot(requirements=[req], any_safety_critical=True)
        result = self.engine.arbitrate(
            world_model=make_world_model(), action_abstraction=snap_in,
            timestamp=time.time(),
        )
        for ar in result.snapshot.arbitrated_requirements:
            if ar.temporal_validity == TemporalValidity.EXPIRED:
                self.assertNotEqual(ar.status, RequirementStatus.DOMINANT)


# ===========================================================================
# Planning context
# ===========================================================================

class TestPlanningContext(unittest.TestCase):

    def setUp(self):
        self.engine = DecisionArbitrationEngine()

    def test_planning_context_has_no_forbidden_fields(self):
        """PlanningContext must contain no vehicle-control fields."""
        req = make_collision_requirement()
        snap_in = make_abstraction_snapshot(requirements=[req], any_safety_critical=True)
        result = self.engine.arbitrate(
            world_model=make_world_model(), action_abstraction=snap_in
        )
        ctx_dict = result.snapshot.planning_context.to_dict()
        forbidden = _has_forbidden(ctx_dict)
        self.assertEqual(forbidden, [], f"Forbidden keys found: {forbidden}")

    def test_planning_allowed_false_when_unknown(self):
        """planning_allowed=False when gate is UNKNOWN."""
        result = self.engine.arbitrate()
        self.assertFalse(result.snapshot.planning_context.planning_allowed)

    def test_planning_mode_matches_gate_state(self):
        """CRITICAL gate → SAFETY_RESTRICTED planning mode."""
        req = make_collision_requirement()
        snap_in = make_abstraction_snapshot(requirements=[req], any_safety_critical=True)
        result = self.engine.arbitrate(
            world_model=make_world_model(), action_abstraction=snap_in
        )
        snap = result.snapshot
        if snap.safety_gate_state == SafetyGateState.CRITICAL:
            self.assertEqual(
                snap.planning_context.planning_mode,
                PlanningMode.SAFETY_RESTRICTED,
            )

    def test_safety_override_required_for_critical(self):
        """CRITICAL gate → safety_override_required=True."""
        req = make_collision_requirement()
        snap_in = make_abstraction_snapshot(requirements=[req], any_safety_critical=True)
        result = self.engine.arbitrate(
            world_model=make_world_model(), action_abstraction=snap_in
        )
        snap = result.snapshot
        if snap.safety_gate_state == SafetyGateState.CRITICAL:
            self.assertTrue(snap.planning_context.safety_override_required)

    def test_context_id_is_set(self):
        """PlanningContext has a non-empty context_id."""
        req = make_requirement(req_type=RequirementType.NORMAL_PROGRESS)
        snap_in = make_abstraction_snapshot(requirements=[req])
        result = self.engine.arbitrate(action_abstraction=snap_in)
        ctx_id = result.snapshot.planning_context.context_id
        self.assertNotEqual(ctx_id, "NOT_AVAILABLE")
        self.assertTrue(len(ctx_id) > 0)


# ===========================================================================
# Validation
# ===========================================================================

class TestValidation(unittest.TestCase):

    def setUp(self):
        self.engine = DecisionArbitrationEngine()
        self.validator = ArbitrationValidator()

    def test_normal_snapshot_is_valid(self):
        """Normal output passes validation."""
        req = make_requirement(
            req_type=RequirementType.NORMAL_PROGRESS,
            is_safety_critical=False,
        )
        snap_in = make_abstraction_snapshot(
            requirements=[req], any_safety_critical=False,
            confidence=0.85, uncertainty=0.15, input_completeness=0.90,
        )
        wm = make_world_model(completeness=0.90, uncertainty=0.15)
        result = self.engine.arbitrate(world_model=wm, action_abstraction=snap_in)
        vr = self.validator.validate(result.snapshot)
        self.assertTrue(vr.is_usable, f"Validation errors: {vr.errors}")

    def test_collision_snapshot_is_valid(self):
        """Collision scenario snapshot passes validation."""
        req = make_collision_requirement()
        snap_in = make_abstraction_snapshot(requirements=[req], any_safety_critical=True)
        result = self.engine.arbitrate(
            world_model=make_world_model(), action_abstraction=snap_in
        )
        vr = self.validator.validate(result.snapshot)
        self.assertTrue(vr.is_usable, f"Validation errors: {vr.errors}")

    def test_no_forbidden_in_full_output(self):
        """Full serialised output must not contain forbidden keys."""
        reqs = [
            make_collision_requirement(req_id="r1"),
            make_vru_requirement(req_id="r2"),
            make_requirement(req_id="r3",
                             req_type=RequirementType.NORMAL_PROGRESS),
        ]
        snap_in = make_abstraction_snapshot(requirements=reqs, any_safety_critical=True)
        result = self.engine.arbitrate(
            world_model=make_world_model(), action_abstraction=snap_in
        )
        serial = result.to_dict()
        forbidden = _has_forbidden(serial)
        self.assertEqual(forbidden, [], f"Forbidden keys found: {forbidden}")

    def test_hard_constraints_validated(self):
        """Validator catches hard constraint with wrong hardness."""
        from core.reasoning.arbitration_types import (
            ArbitrationSnapshot, PlanningContext, SafetyConstraint,
            ConstraintHardness,
        )
        bad_constraint = SafetyConstraint(
            constraint_id="bad_c",
            constraint_type="TEST",
            hardness=ConstraintHardness.SOFT,  # wrong — should be HARD
            timestamp=time.time(),
        )
        ctx = PlanningContext(
            context_id="ctx_test",
            timestamp=time.time(),
            safety_gate_state=SafetyGateState.CLEAR,
            planning_allowed=True,
            _hard_constraints=(bad_constraint,),  # bad
        )
        snap = ArbitrationSnapshot(
            timestamp=time.time(),
            confidence=0.5,
            uncertainty=0.5,
            world_model_completeness=0.5,
            planning_context=ctx,
        )
        vr = self.validator.validate(snap)
        # Should report error about non-HARD constraint in hard_constraints
        self.assertTrue(
            any("hardness" in e or "HARD" in e for e in vr.errors),
            f"Expected hardness error in: {vr.errors}"
        )


# ===========================================================================
# Snapshot utilities
# ===========================================================================

class TestSnapshotUtils(unittest.TestCase):

    def setUp(self):
        self.engine = DecisionArbitrationEngine()

    def test_snapshot_to_json_valid(self):
        """to_json produces valid JSON."""
        import json
        req = make_collision_requirement()
        snap_in = make_abstraction_snapshot(requirements=[req], any_safety_critical=True)
        result = self.engine.arbitrate(
            world_model=make_world_model(), action_abstraction=snap_in
        )
        j = arbitration_snapshot_to_json(result.snapshot)
        parsed = json.loads(j)
        self.assertIn("safety_gate_state", parsed)
        self.assertIn("planning_context", parsed)

    def test_summary_compact(self):
        """Summary dict has expected compact keys."""
        req = make_collision_requirement()
        snap_in = make_abstraction_snapshot(requirements=[req], any_safety_critical=True)
        result = self.engine.arbitrate(
            world_model=make_world_model(), action_abstraction=snap_in
        )
        summary = arbitration_snapshot_summary(result.snapshot)
        self.assertIn("safety_gate_state", summary)
        self.assertIn("dominant_requirement_type", summary)
        self.assertIn("planning_allowed", summary)

    def test_find_arbitrated_by_type(self):
        """find_arbitrated_by_type returns correct entry."""
        req = make_collision_requirement(req_id="r1")
        snap_in = make_abstraction_snapshot(requirements=[req], any_safety_critical=True)
        result = self.engine.arbitrate(
            world_model=make_world_model(), action_abstraction=snap_in
        )
        ar = find_arbitrated_by_type(
            result.snapshot, RequirementType.COLLISION_AVOIDANCE_REQUIRED
        )
        self.assertIsNotNone(ar)
        self.assertEqual(
            ar.requirement.requirement_type,
            RequirementType.COLLISION_AVOIDANCE_REQUIRED,
        )

    def test_stale_check(self):
        """is_arbitration_snapshot_stale works correctly."""
        req = make_requirement(req_type=RequirementType.NORMAL_PROGRESS)
        snap_in = make_abstraction_snapshot(requirements=[req])
        result = self.engine.arbitrate(action_abstraction=snap_in)
        # Not stale immediately
        self.assertFalse(
            is_arbitration_snapshot_stale(result.snapshot, threshold_s=10.0)
        )
        # Stale with threshold 0
        self.assertTrue(
            is_arbitration_snapshot_stale(result.snapshot, threshold_s=0.0)
        )


if __name__ == "__main__":
    unittest.main()
