"""
IndiDrive AI — Phase 8.4 | Safety Gate Unit Tests
==================================================
Direct unit tests for SafetyGateEvaluator covering all 7 gate states
and the key transitions between them.
"""
import sys
import os
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..'))

from core.reasoning.safety_gate import SafetyGateEvaluator
from core.reasoning.arbitration_config import ArbitrationConfig
from core.reasoning.arbitration_types import SafetyGateState
from core.reasoning.action_abstraction_types import (
    RequirementType, AbstractUrgency, AbstractSeverity, ResponseFamily,
)

from tests.reasoning84.test_helpers_84 import (
    make_requirement, make_abstraction_snapshot,
    make_collision_requirement, make_vru_requirement,
    make_road_hazard_requirement, make_uncertainty_requirement,
    make_degraded_requirement,
)


class TestSafetyGateEvaluator(unittest.TestCase):

    def setUp(self):
        self.cfg = ArbitrationConfig()
        self.gate = SafetyGateEvaluator(self.cfg)

    def _eval(self, snap, completeness=0.85, uncertainty=0.20, degraded=False):
        return self.gate.evaluate(snap, completeness, uncertainty, degraded)

    # -----------------------------------------------------------------------
    # UNKNOWN
    # -----------------------------------------------------------------------

    def test_none_snapshot_is_unknown(self):
        state, codes = self._eval(None)
        self.assertEqual(state, SafetyGateState.UNKNOWN)
        self.assertIn("UNKNOWN_WORLD_STATE", codes)

    def test_degraded_zero_completeness_is_unknown(self):
        snap = make_abstraction_snapshot(
            requirements=[], degraded=True, confidence=0.0, uncertainty=1.0
        )
        state, codes = self._eval(snap, completeness=0.0, degraded=True)
        self.assertEqual(state, SafetyGateState.UNKNOWN)

    # -----------------------------------------------------------------------
    # CRITICAL
    # -----------------------------------------------------------------------

    def test_immediate_collision_is_critical(self):
        req = make_collision_requirement(
            urgency=AbstractUrgency.IMMEDIATE,
            severity=AbstractSeverity.CRITICAL,
        )
        snap = make_abstraction_snapshot(
            requirements=[req], any_safety_critical=True
        )
        state, codes = self._eval(snap)
        self.assertEqual(state, SafetyGateState.CRITICAL)
        self.assertIn("IMMEDIATE_COLLISION_THREAT", codes)

    def test_immediate_vru_is_critical(self):
        req = make_requirement(
            req_type=RequirementType.HANDLE_VULNERABLE_USER,
            priority=0.90,
            urgency=AbstractUrgency.IMMEDIATE,
            severity=AbstractSeverity.CRITICAL,
            is_safety_critical=True,
        )
        snap = make_abstraction_snapshot(
            requirements=[req], any_safety_critical=True
        )
        state, codes = self._eval(snap)
        self.assertEqual(state, SafetyGateState.CRITICAL)

    def test_immediate_trajectory_conflict_is_critical(self):
        req = make_requirement(
            req_type=RequirementType.HANDLE_TRAJECTORY_CONFLICT,
            priority=0.88,
            urgency=AbstractUrgency.IMMEDIATE,
            severity=AbstractSeverity.CRITICAL,
            is_safety_critical=True,
        )
        snap = make_abstraction_snapshot(
            requirements=[req], any_safety_critical=True
        )
        state, codes = self._eval(snap)
        self.assertEqual(state, SafetyGateState.CRITICAL)

    # -----------------------------------------------------------------------
    # HIGH_ALERT
    # -----------------------------------------------------------------------

    def test_high_urgency_collision_is_high_alert_or_critical(self):
        req = make_collision_requirement(
            urgency=AbstractUrgency.HIGH,
            severity=AbstractSeverity.HIGH,
            priority=0.80,
        )
        snap = make_abstraction_snapshot(
            requirements=[req], any_safety_critical=True
        )
        state, codes = self._eval(snap)
        self.assertIn(state, (SafetyGateState.HIGH_ALERT, SafetyGateState.CRITICAL))

    def test_high_priority_road_hazard_high_alert(self):
        req = make_road_hazard_requirement(
            priority=0.80,
            urgency=AbstractUrgency.HIGH,
            severity=AbstractSeverity.HIGH,
        )
        snap = make_abstraction_snapshot(
            requirements=[req], any_safety_critical=True
        )
        state, codes = self._eval(snap)
        self.assertIn(
            state, (SafetyGateState.HIGH_ALERT, SafetyGateState.CRITICAL,
                    SafetyGateState.RESTRICTED),
        )

    # -----------------------------------------------------------------------
    # DEGRADED
    # -----------------------------------------------------------------------

    def test_degraded_snapshot_is_degraded(self):
        req = make_degraded_requirement()
        snap = make_abstraction_snapshot(
            requirements=[req], degraded=True, uncertainty=0.90,
            confidence=0.10, any_safety_critical=True,
        )
        state, codes = self._eval(snap, completeness=0.15, uncertainty=0.90,
                                   degraded=True)
        self.assertIn(state, (SafetyGateState.DEGRADED, SafetyGateState.UNKNOWN))
        self.assertTrue(any("DEGRADED" in c or "INCOMPLETE" in c or "UNCERTAINTY" in c
                            for c in codes))

    def test_low_completeness_is_not_clear(self):
        req = make_requirement(req_type=RequirementType.DEGRADED_OPERATION,
                               is_safety_critical=True)
        snap = make_abstraction_snapshot(
            requirements=[req], degraded=True, uncertainty=0.88
        )
        state, codes = self._eval(snap, completeness=0.10, uncertainty=0.88,
                                   degraded=True)
        self.assertNotEqual(state, SafetyGateState.CLEAR)

    # -----------------------------------------------------------------------
    # RESTRICTED
    # -----------------------------------------------------------------------

    def test_high_uncertainty_is_restricted(self):
        req = make_uncertainty_requirement(priority=0.55)
        snap = make_abstraction_snapshot(
            requirements=[req], uncertainty=0.72,
            response_family=ResponseFamily.UNCERTAINTY_MANAGEMENT,
        )
        state, codes = self._eval(snap, uncertainty=0.72)
        self.assertIn(state, (SafetyGateState.RESTRICTED, SafetyGateState.DEGRADED))

    def test_low_world_completeness_is_restricted(self):
        req = make_requirement(req_type=RequirementType.NORMAL_PROGRESS)
        snap = make_abstraction_snapshot(requirements=[req])
        state, codes = self._eval(snap, completeness=0.30, uncertainty=0.30)
        self.assertIn(state, (SafetyGateState.RESTRICTED, SafetyGateState.DEGRADED,
                              SafetyGateState.CAUTION))

    # -----------------------------------------------------------------------
    # CAUTION
    # -----------------------------------------------------------------------

    def test_moderate_hazard_is_caution(self):
        req = make_requirement(
            req_type=RequirementType.MONITOR_DYNAMIC_OBJECT,
            priority=0.35,
            urgency=AbstractUrgency.MEDIUM,
            severity=AbstractSeverity.LOW,
            is_safety_critical=False,
        )
        snap = make_abstraction_snapshot(
            requirements=[req], uncertainty=0.30, any_safety_critical=False
        )
        state, codes = self._eval(snap, completeness=0.85, uncertainty=0.30)
        self.assertIn(state, (SafetyGateState.CAUTION, SafetyGateState.CLEAR))

    # -----------------------------------------------------------------------
    # CLEAR
    # -----------------------------------------------------------------------

    def test_clean_normal_progress_is_clear(self):
        req = make_requirement(
            req_type=RequirementType.NORMAL_PROGRESS,
            priority=0.20,
            urgency=AbstractUrgency.NONE,
            severity=AbstractSeverity.NONE,
            confidence=0.95,
            uncertainty=0.05,
            is_safety_critical=False,
        )
        snap = make_abstraction_snapshot(
            requirements=[req],
            any_safety_critical=False,
            confidence=0.95,
            uncertainty=0.05,
            response_family=ResponseFamily.NORMAL,
        )
        state, codes = self._eval(snap, completeness=0.95, uncertainty=0.05)
        self.assertIn(state, (SafetyGateState.CLEAR, SafetyGateState.CAUTION))

    # -----------------------------------------------------------------------
    # Determinism
    # -----------------------------------------------------------------------

    def test_same_input_same_gate(self):
        """Safety gate evaluation is deterministic."""
        req = make_collision_requirement(timestamp=1000.0)
        snap = make_abstraction_snapshot(
            requirements=[req], any_safety_critical=True, timestamp=1000.0
        )
        results = [
            self._eval(snap, completeness=0.85, uncertainty=0.20)
            for _ in range(8)
        ]
        states = [r[0] for r in results]
        self.assertEqual(len(set(s.value for s in states)), 1,
                         f"Non-deterministic gate states: {states}")

    def test_reason_codes_not_empty(self):
        """Reason codes are always provided."""
        req = make_requirement(req_type=RequirementType.NORMAL_PROGRESS,
                               is_safety_critical=False)
        snap = make_abstraction_snapshot(requirements=[req], uncertainty=0.10)
        _, codes = self._eval(snap, completeness=0.90, uncertainty=0.10)
        self.assertGreater(len(codes), 0)


if __name__ == "__main__":
    unittest.main()
