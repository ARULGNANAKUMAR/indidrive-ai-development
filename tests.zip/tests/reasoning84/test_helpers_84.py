"""
IndiDrive AI — Phase 8.4 | Test Helpers & Fixture Builders
===========================================================
Shared helpers for constructing realistic Phase 8.4 test inputs
without relying on the full ingestion pipeline.

All fixtures use typed dataclasses — not raw dicts.
"""
from __future__ import annotations

import time
from typing import List, Optional, Tuple

from core.reasoning.action_abstraction_types import (
    ACTION_ABSTRACTION_SCHEMA_VERSION,
    ActionAbstractionSnapshot,
    DecisionRequirement,
    RequirementRelationshipEntry,
    RequirementType,
    AbstractUrgency,
    AbstractSeverity,
    EvidenceType,
    ResponseFamily,
    RequirementRelationship,
)
from core.world_model.world_model_types import (
    WorldModelSnapshot, WorldModelStatus, WorldDataQuality,
    WorldRoadRepresentation, WorldIndianContextSummary,
    WorldDrivableSpaceInfo, WorldLaneInfo, WorldAnomalySummary,
    InputModuleStatus, RoadRepresentationStatus,
)


# ---------------------------------------------------------------------------
# DecisionRequirement builders
# ---------------------------------------------------------------------------

def make_requirement(
    req_id: str = "req_1",
    req_type: RequirementType = RequirementType.NORMAL_PROGRESS,
    priority: float = 0.3,
    urgency: AbstractUrgency = AbstractUrgency.LOW,
    severity: AbstractSeverity = AbstractSeverity.LOW,
    confidence: float = 0.8,
    uncertainty: float = 0.2,
    evidence_type: EvidenceType = EvidenceType.OBSERVED,
    source: str = "phase_8_3",
    is_safety_critical: bool = False,
    affected_entity_ids: Tuple[str, ...] = (),
    reason_codes: Tuple[str, ...] = (),
    timestamp: Optional[float] = None,
    frame_id: int = 1,
) -> DecisionRequirement:
    return DecisionRequirement(
        requirement_id=req_id,
        requirement_type=req_type,
        priority=priority,
        urgency=urgency,
        severity=severity,
        confidence=confidence,
        uncertainty=uncertainty,
        evidence_type=evidence_type,
        source=source,
        affected_entity_ids=affected_entity_ids,
        reason_codes=reason_codes,
        is_safety_critical=is_safety_critical,
        timestamp=timestamp if timestamp is not None else time.time(),
        frame_id=frame_id,
    )


def make_collision_requirement(
    req_id: str = "req_collision",
    priority: float = 0.90,
    urgency: AbstractUrgency = AbstractUrgency.IMMEDIATE,
    severity: AbstractSeverity = AbstractSeverity.CRITICAL,
    confidence: float = 0.85,
    uncertainty: float = 0.15,
    timestamp: Optional[float] = None,
) -> DecisionRequirement:
    return make_requirement(
        req_id=req_id,
        req_type=RequirementType.COLLISION_AVOIDANCE_REQUIRED,
        priority=priority,
        urgency=urgency,
        severity=severity,
        confidence=confidence,
        uncertainty=uncertainty,
        is_safety_critical=True,
        reason_codes=("IMMEDIATE_COLLISION_THREAT",),
        timestamp=timestamp,
    )


def make_vru_requirement(
    req_id: str = "req_vru",
    priority: float = 0.80,
    urgency: AbstractUrgency = AbstractUrgency.HIGH,
    severity: AbstractSeverity = AbstractSeverity.HIGH,
    timestamp: Optional[float] = None,
) -> DecisionRequirement:
    return make_requirement(
        req_id=req_id,
        req_type=RequirementType.HANDLE_VULNERABLE_USER,
        priority=priority,
        urgency=urgency,
        severity=severity,
        confidence=0.80,
        uncertainty=0.20,
        is_safety_critical=True,
        reason_codes=("VRU_CONFLICT",),
        timestamp=timestamp,
    )


def make_road_hazard_requirement(
    req_id: str = "req_hazard",
    priority: float = 0.65,
    urgency: AbstractUrgency = AbstractUrgency.HIGH,
    severity: AbstractSeverity = AbstractSeverity.HIGH,
    timestamp: Optional[float] = None,
) -> DecisionRequirement:
    return make_requirement(
        req_id=req_id,
        req_type=RequirementType.HANDLE_ROAD_HAZARD,
        priority=priority,
        urgency=urgency,
        severity=severity,
        confidence=0.75,
        uncertainty=0.25,
        is_safety_critical=True,
        reason_codes=("ROAD_HAZARD_ACTIVE",),
        timestamp=timestamp,
    )


def make_uncertainty_requirement(
    req_id: str = "req_uncertainty",
    priority: float = 0.50,
    timestamp: Optional[float] = None,
) -> DecisionRequirement:
    return make_requirement(
        req_id=req_id,
        req_type=RequirementType.HANDLE_UNCERTAINTY,
        priority=priority,
        urgency=AbstractUrgency.MEDIUM,
        severity=AbstractSeverity.MEDIUM,
        confidence=0.50,
        uncertainty=0.65,
        is_safety_critical=False,
        reason_codes=("HIGH_UNCERTAINTY",),
        timestamp=timestamp,
    )


def make_degraded_requirement(
    req_id: str = "req_degraded",
    priority: float = 0.60,
    timestamp: Optional[float] = None,
) -> DecisionRequirement:
    return make_requirement(
        req_id=req_id,
        req_type=RequirementType.DEGRADED_OPERATION,
        priority=priority,
        urgency=AbstractUrgency.HIGH,
        severity=AbstractSeverity.HIGH,
        confidence=0.40,
        uncertainty=0.75,
        is_safety_critical=True,
        reason_codes=("DEGRADED_OPERATION", "SENSOR_DEGRADATION"),
        timestamp=timestamp,
    )


# ---------------------------------------------------------------------------
# ActionAbstractionSnapshot builder
# ---------------------------------------------------------------------------

def make_abstraction_snapshot(
    requirements: Optional[List[DecisionRequirement]] = None,
    response_family: ResponseFamily = ResponseFamily.NORMAL,
    overall_urgency: AbstractUrgency = AbstractUrgency.LOW,
    overall_severity: AbstractSeverity = AbstractSeverity.LOW,
    any_safety_critical: bool = False,
    confidence: float = 0.80,
    uncertainty: float = 0.20,
    input_completeness: float = 0.85,
    degraded: bool = False,
    reason_codes: Tuple[str, ...] = (),
    relationships: Optional[List[RequirementRelationshipEntry]] = None,
    frame_id: int = 1,
    timestamp: Optional[float] = None,
) -> ActionAbstractionSnapshot:
    reqs = tuple(requirements) if requirements else tuple()
    rels = tuple(relationships) if relationships else tuple()
    return ActionAbstractionSnapshot(
        schema_version=ACTION_ABSTRACTION_SCHEMA_VERSION,
        timestamp=timestamp if timestamp is not None else time.time(),
        frame_id=frame_id,
        _requirements=reqs,
        _relationships=rels,
        response_family=response_family,
        overall_urgency=overall_urgency,
        overall_severity=overall_severity,
        any_safety_critical=any_safety_critical,
        confidence=confidence,
        uncertainty=uncertainty,
        input_completeness=input_completeness,
        degraded=degraded,
        reason_codes=reason_codes,
    )


# ---------------------------------------------------------------------------
# World model builder (reused from Phase 8.3 helper pattern)
# ---------------------------------------------------------------------------

def make_world_model(
    status: WorldModelStatus = WorldModelStatus.OK,
    completeness: float = 0.85,
    confidence: float = 0.80,
    uncertainty: float = 0.20,
    prediction_status: InputModuleStatus = InputModuleStatus.OK,
    road_confidence: float = 0.80,
    road_uncertainty: float = 0.20,
    available_width_m: Optional[float] = None,
    anomalies: Optional[List[WorldAnomalySummary]] = None,
    intersection_state: str = "NORMAL_ROAD",
    road_type: str = "URBAN",
    traffic_density: str = "MEDIUM",
    cattle_present: bool = False,
    vru_present: bool = False,
    market_like: bool = False,
    frame_id: int = 1,
) -> WorldModelSnapshot:
    drivable = WorldDrivableSpaceInfo(
        road_width_m=available_width_m,
        drivable_space_uncertainty=road_uncertainty,
    )
    lane_info = WorldLaneInfo(intersection_state=intersection_state)
    road = WorldRoadRepresentation(
        status=RoadRepresentationStatus.FULL,
        drivable_space=drivable,
        lane_info=lane_info,
        anomalies=anomalies or [],
        road_confidence=road_confidence,
        road_uncertainty=road_uncertainty,
        is_degraded=False,
    )
    indian_ctx = WorldIndianContextSummary(
        available=True,
        road_type=road_type,
        traffic_density=traffic_density,
        cattle_present=cattle_present,
        vulnerable_road_users=vru_present,
        market_like_activity=market_like,
        context_confidence=confidence,
        context_uncertainty=uncertainty,
        is_degraded=False,
    )
    dq = WorldDataQuality(
        overall_confidence=confidence,
        overall_uncertainty=uncertainty,
        completeness=completeness,
        freshness=0.95,
        prediction_status=prediction_status,
        is_partial=completeness < 0.85,
    )
    return WorldModelSnapshot(
        frame_id=frame_id,
        _objects=tuple(),
        road=road,
        indian_context=indian_ctx,
        data_quality=dq,
        status=status,
    )
