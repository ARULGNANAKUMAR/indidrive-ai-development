"""
IndiDrive AI — Phase 8.2 | Test Helpers
=========================================
Shared fixtures for constructing World Model inputs for Phase 8.2 tests.
Uses the exact field names from WorldDrivableSpaceInfo / WorldDataQuality.
"""
import sys, os, time
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..'))
import logging; logging.disable(logging.CRITICAL)

from core.world_model.world_model_types import (
    WorldModelSnapshot, WorldModelStatus, WorldObject,
    WorldObjectPosition, WorldObjectVelocity, WorldObjectDimensions,
    WorldObjectMotionSummary, WorldObjectPredictionSummary,
    WorldObjectCollisionInfo, WorldObjectQuality,
    WorldObjectLifecycle, ObjectObservationState,
    PredictionAvailability, CoordinateFrame,
    WorldRoadRepresentation, RoadRepresentationStatus,
    WorldDrivableSpaceInfo, WorldLaneInfo, WorldAnomalySummary,
    WorldIndianContextSummary, WorldDataQuality,
    WorldBoundarySummary, InputModuleStatus,
    NOT_AVAILABLE,
)
from core.reasoning.reasoning_types import (
    ReasoningSnapshot, ReasoningState, SituationCategory,
    SituationInfo, EnvironmentInfo, HazardSummary, RiskSummary,
    ComplexityInfo, UncertaintyInfo, ReasoningExplanation,
    HazardEntry, HazardCategory, RiskLevel, TtcBand,
    InteractionEntry, InteractionType, ComplexityLevel, UncertaintyLevel,
    WorldCompletenessLevel,
)
from core.reasoning.behavior_reasoning_config import BehaviorReasoningConfig


# ---------------------------------------------------------------------------
# World object factory
# ---------------------------------------------------------------------------

def make_obj(
    obj_id="obj_001",
    object_type="VEHICLE",
    object_subtype="CAR",
    x=20.0, y=0.0, z=0.0, dist=20.0,
    vx=-5.0, vy=0.0, speed=5.0,
    ax=None, ay=None,
    yaw_rate=None,
    is_moving=True,
    ttc=4.0, closing_speed=5.0,
    collision_likelihood=0.3,
    risk_level="MEDIUM",
    predicted_conflict=False,
    confidence=0.8,
    is_stale=False,
    hypotheses=None,
    lifecycle=WorldObjectLifecycle.ACTIVE,
) -> WorldObject:
    return WorldObject(
        object_id=obj_id,
        track_id=obj_id,
        object_type=object_type,
        object_subtype=object_subtype,
        position=WorldObjectPosition(x=x, y=y, z=z, distance_m=dist),
        velocity=WorldObjectVelocity(vx=vx, vy=vy, speed_ms=speed, ax=ax, ay=ay),
        dimensions=WorldObjectDimensions(),
        motion=WorldObjectMotionSummary(
            is_moving=is_moving,
            speed_ms=speed,
            yaw_rate_rads=yaw_rate,
        ),
        prediction=WorldObjectPredictionSummary(
            availability=PredictionAvailability.FULL,
            prediction_confidence=confidence,
            hypotheses=hypotheses or [],
        ),
        collision=WorldObjectCollisionInfo(
            ttc_s=ttc,
            ttc_status="FINITE" if ttc is not None else NOT_AVAILABLE,
            closing_speed_ms=closing_speed,
            collision_likelihood=collision_likelihood,
            risk_level=risk_level,
            predicted_conflict=predicted_conflict,
        ),
        quality=WorldObjectQuality(
            object_confidence=confidence,
            position_confidence=confidence,
            velocity_confidence=confidence,
            existence_probability=confidence,
            data_age_s=0.0,
            observation_state=ObjectObservationState.OBSERVED,
            is_stale=is_stale,
        ),
        lifecycle=lifecycle,
        coordinate_frame=CoordinateFrame.VEHICLE,
    )


# ---------------------------------------------------------------------------
# World model snapshot factory
# ---------------------------------------------------------------------------

def make_snapshot(
    objects=None,
    status=WorldModelStatus.OK,
    drivable_width=6.0,      # stored as road_width_m in WorldDrivableSpaceInfo
    has_anomalies=False,
    anomaly_severity="LOW",
    road_status=RoadRepresentationStatus.FULL,
    indian_ctx_kwargs=None,
    overall_confidence=0.8,
    is_degraded=False,       # maps to is_partial in WorldDataQuality
    frame_id=1,
) -> WorldModelSnapshot:
    objects = objects or []
    anomalies = []
    if has_anomalies:
        anomalies = [WorldAnomalySummary(severity=anomaly_severity, anomaly_type="POTHOLE")]

    # WorldDrivableSpaceInfo uses road_width_m (not available_width_m)
    drivable = WorldDrivableSpaceInfo(
        road_width_m=drivable_width,
        free_space_confidence=overall_confidence,
    )

    indian_ctx = WorldIndianContextSummary()
    if indian_ctx_kwargs:
        for k, v in indian_ctx_kwargs.items():
            if hasattr(indian_ctx, k):
                setattr(indian_ctx, k, v)

    road = WorldRoadRepresentation(
        status=road_status,
        drivable_space=drivable,
        anomalies=anomalies,
        road_confidence=overall_confidence,
        road_uncertainty=1.0 - overall_confidence,
        is_degraded=is_degraded,
    )

    # WorldDataQuality uses is_partial (not is_degraded)
    dq = WorldDataQuality(
        overall_confidence=overall_confidence,
        overall_uncertainty=1.0 - overall_confidence,
        is_partial=is_degraded,
    )

    snap = WorldModelSnapshot(
        frame_id=frame_id,
        _objects=tuple(objects),
        road=road,
        indian_context=indian_ctx,
        data_quality=dq,
        status=status,
    )
    return snap


# ---------------------------------------------------------------------------
# Phase 8.1 snapshot factory
# ---------------------------------------------------------------------------

def make_phase81(
    hazards=None,
    state=ReasoningState.NORMAL,
    complexity=ComplexityLevel.LOW,
) -> ReasoningSnapshot:
    hazards = hazards or []
    snap = ReasoningSnapshot(
        reasoning_state=state,
        situation=SituationInfo(situation_category=SituationCategory.NORMAL_TRAFFIC),
        environment=EnvironmentInfo(),
        hazards=HazardSummary(
            total_hazards=len(hazards),
            top_hazards=hazards,
        ),
        risk=RiskSummary(overall_risk_level=RiskLevel.LOW),
        complexity=ComplexityInfo(complexity_level=complexity),
        uncertainty_info=UncertaintyInfo(
            overall_uncertainty=0.2,
            world_completeness=WorldCompletenessLevel.FULL,
        ),
        explanation=ReasoningExplanation(),
        reasoning_confidence=0.75,
    )
    return snap


# ---------------------------------------------------------------------------
# Hazard entry factory
# ---------------------------------------------------------------------------

def make_hazard(
    hazard_id="h001",
    category=HazardCategory.CAR,
    risk_level=RiskLevel.MEDIUM,
    ttc_band=TtcBand.MODERATE,
    ttc_s=4.0,
    dist=20.0,
    closing=5.0,
    likelihood=0.3,
    predicted_conflict=False,
    is_vulnerable=False,
    confidence=0.75,
) -> HazardEntry:
    return HazardEntry(
        hazard_id=hazard_id,
        hazard_category=category,
        risk_level=risk_level,
        ttc_band=ttc_band,
        ttc_s=ttc_s,
        distance_m=dist,
        closing_speed_ms=closing,
        collision_likelihood=likelihood,
        predicted_conflict=predicted_conflict,
        is_moving=True,
        is_vulnerable=is_vulnerable,
        priority_score=0.6,
        confidence=confidence,
        uncertainty=1.0 - confidence,
    )


# ---------------------------------------------------------------------------
# Default config
# ---------------------------------------------------------------------------

def default_config() -> BehaviorReasoningConfig:
    return BehaviorReasoningConfig()
