"""
IndiDrive AI — Phase 8.2 | Interaction & Graph Tests
======================================================
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..'))
import logging; logging.disable(logging.CRITICAL)

from helpers import make_obj, make_snapshot, make_phase81, make_hazard, default_config
from core.reasoning.interaction_graph_builder import InteractionGraphBuilder
from core.reasoning.behavior_classifier import BehaviorClassifier
from core.reasoning.behavior_types import (
    BehaviorInteractionType, InteractionSeverity, TimeRelevance, EvidenceClass,
)
from core.reasoning.reasoning_types import HazardCategory, RiskLevel, TtcBand


def _build(objects, hazards=None, drivable_width=6.0, has_anomalies=False,
           indian_ctx_kwargs=None):
    cfg = default_config()
    classifier = BehaviorClassifier(cfg)
    builder = InteractionGraphBuilder(cfg)
    snap = make_snapshot(
        objects=objects,
        drivable_width=drivable_width,
        has_anomalies=has_anomalies,
        indian_ctx_kwargs=indian_ctx_kwargs or {},
    )
    behaviors = classifier.classify_all(snap.objects, 0.0)
    hazards = hazards or []
    interactions, graph = builder.build(snap, behaviors, hazards)
    return interactions, graph, behaviors


# ----- Vehicle-Vehicle -----

def test_vehicle_vehicle_interaction():
    # vx=-6 means vehicle approaching from front (closing); vehicle frame
    obj = make_obj(obj_id="car_001", object_type="VEHICLE", object_subtype="CAR",
                   vx=-6.0, vy=0.0, speed=6.0, ttc=2.5, closing_speed=6.0,
                   risk_level="HIGH", predicted_conflict=True)
    ints, graph, _ = _build([obj])
    assert len(ints) > 0
    types = [i.interaction_type for i in ints]
    assert any(t in (BehaviorInteractionType.VEHICLE_VEHICLE,
                     BehaviorInteractionType.APPROACHING,
                     BehaviorInteractionType.LONGITUDINAL_CONFLICT,
                     BehaviorInteractionType.WRONG_SIDE_APPROACH) for t in types)


# ----- Pedestrian-Vehicle -----

def test_pedestrian_vehicle_interaction():
    obj = make_obj(obj_id="ped_001", object_type="PEDESTRIAN", object_subtype="PEDESTRIAN",
                   vx=0.0, vy=3.0, speed=3.0, ttc=5.0, closing_speed=0.5,
                   risk_level="MEDIUM", dist=12.0, x=12.0)
    ints, _, _ = _build([obj])
    assert any(i.interaction_type == BehaviorInteractionType.PEDESTRIAN_VEHICLE for i in ints)


# ----- Cattle-Vehicle -----

def test_cattle_vehicle_interaction():
    obj = make_obj(obj_id="cow_001", object_type="CATTLE", object_subtype="COW",
                   vx=0.5, vy=2.0, speed=2.1, ttc=6.0, closing_speed=0.5,
                   risk_level="MEDIUM", dist=15.0, x=15.0)
    ints, _, _ = _build([obj])
    assert any(i.interaction_type == BehaviorInteractionType.CATTLE_VEHICLE for i in ints)


# ----- Motorcycle lateral -----

def test_motorcycle_lateral_interaction():
    obj = make_obj(obj_id="moto_001", object_type="MOTORCYCLE", object_subtype="MOTORCYCLE",
                   vx=-3.0, vy=4.0, speed=5.0, ttc=4.0, closing_speed=3.0,
                   risk_level="MEDIUM", predicted_conflict=False)
    ints, _, _ = _build([obj])
    assert len(ints) > 0
    types = [i.interaction_type for i in ints]
    assert any(t in (
        BehaviorInteractionType.VEHICLE_VEHICLE,
        BehaviorInteractionType.CROSSING,
        BehaviorInteractionType.LATERAL_CONFLICT,
        BehaviorInteractionType.APPROACHING,
        BehaviorInteractionType.WRONG_SIDE_APPROACH,
    ) for t in types)


# ----- Road anomaly -----

def test_vehicle_road_anomaly_interaction():
    obj = make_obj(obj_id="car_002", dist=10.0, x=10.0, risk_level="MEDIUM")
    ints, _, _ = _build([obj], has_anomalies=True, drivable_width=5.0)
    anomaly_ints = [i for i in ints
                    if i.interaction_type == BehaviorInteractionType.ENTITY_ROAD_ANOMALY]
    assert len(anomaly_ints) > 0


# ----- Road boundary (narrow) -----

def test_vehicle_narrow_road_context():
    obj = make_obj(obj_id="car_003", dist=8.0, x=8.0,
                   vx=-4.0, vy=2.0, speed=4.5, risk_level="MEDIUM")
    ints, _, _ = _build([obj], drivable_width=3.0)
    assert len(ints) > 0


# ----- Multiple interactions -----

def test_multiple_interactions():
    objs = [
        make_obj(obj_id="o1", vx=-6.0, vy=0.0, speed=6.0, ttc=2.0,
                 risk_level="HIGH", predicted_conflict=True),
        make_obj(obj_id="o2", object_type="PEDESTRIAN",
                 vx=0.0, vy=3.0, speed=3.0, ttc=5.0, dist=10.0, x=10.0),
        make_obj(obj_id="o3", object_type="CATTLE",
                 vx=0.5, vy=1.5, speed=1.6, ttc=8.0, dist=20.0, x=20.0),
    ]
    ints, graph, _ = _build(objs)
    assert len(ints) >= 2
    assert graph.node_count > 1


# ----- Severity assignment -----

def test_interaction_severity_critical():
    obj = make_obj(vx=-8.0, speed=8.0, ttc=1.0, closing_speed=8.0,
                   risk_level="CRITICAL", predicted_conflict=True, collision_likelihood=0.9)
    ints, _, _ = _build([obj])
    assert any(i.severity == InteractionSeverity.CRITICAL for i in ints)


def test_interaction_severity_not_high_for_distant():
    obj = make_obj(dist=58.0, x=58.0, vx=-1.0, speed=1.0, ttc=50.0,
                   closing_speed=1.0, risk_level="LOW", collision_likelihood=0.05)
    # Should not be detected (beyond max distance by default in cfg if dist < 60)
    cfg = default_config()
    cfg.max_interaction_distance_m = 55.0
    from core.reasoning.interaction_graph_builder import InteractionGraphBuilder
    from core.reasoning.behavior_classifier import BehaviorClassifier
    builder = InteractionGraphBuilder(cfg)
    classifier = BehaviorClassifier(cfg)
    snap = make_snapshot([obj])
    behaviors = classifier.classify_all(snap.objects, 0.0)
    ints, _ = builder.build(snap, behaviors, [])
    # obj is beyond range so should not produce critical/high
    for i in ints:
        assert i.severity not in (InteractionSeverity.CRITICAL,)


# ----- Time relevance -----

def test_time_relevance_immediate():
    obj = make_obj(vx=-8.0, speed=8.0, ttc=0.8, closing_speed=8.0,
                   risk_level="CRITICAL", predicted_conflict=True)
    ints, _, _ = _build([obj])
    assert any(i.time_relevance == TimeRelevance.IMMEDIATE for i in ints)


def test_time_relevance_near_term():
    obj = make_obj(vx=-5.0, speed=5.0, ttc=2.5, closing_speed=5.0,
                   risk_level="HIGH")
    ints, _, _ = _build([obj])
    assert any(i.time_relevance in (
        TimeRelevance.NEAR_TERM, TimeRelevance.IMMEDIATE
    ) for i in ints)


def test_time_relevance_medium_term():
    obj = make_obj(vx=-4.0, speed=4.0, ttc=4.5, closing_speed=4.0,
                   risk_level="MEDIUM")
    ints, _, _ = _build([obj])
    assert any(i.time_relevance in (
        TimeRelevance.MEDIUM_TERM, TimeRelevance.NEAR_TERM, TimeRelevance.IMMEDIATE
    ) for i in ints)


def test_time_relevance_unknown_no_ttc():
    obj = make_obj(vx=0.5, vy=0.5, speed=0.7, ttc=None,
                   closing_speed=None, risk_level="LOW")
    ints, _, _ = _build([obj])
    for i in ints:
        if i.time_relevance == TimeRelevance.UNKNOWN:
            break  # fine


# ----- Graph structure -----

def test_graph_has_ego_node():
    obj = make_obj(vx=-5.0, speed=5.0, ttc=3.0)
    _, graph, _ = _build([obj])
    ego_nodes = [n for n in graph.nodes if n.node_id == "ego"]
    assert ego_nodes


def test_graph_edges_bounded():
    objs = [make_obj(obj_id=f"o{i}", vx=-5.0, speed=5.0, ttc=3.0,
                     risk_level="MEDIUM") for i in range(10)]
    _, graph, _ = _build(objs)
    cfg = default_config()
    assert graph.edge_count <= cfg.max_graph_edges
    assert graph.node_count <= cfg.max_graph_nodes


def test_graph_nodes_bounded():
    objs = [make_obj(obj_id=f"o{i:03d}", vx=-5.0, speed=5.0) for i in range(30)]
    _, graph, _ = _build(objs)
    cfg = default_config()
    assert graph.node_count <= cfg.max_graph_nodes


def test_wrong_side_interaction():
    obj = make_obj(object_type="VEHICLE", vx=8.0, vy=0.0, speed=8.0,
                   ttc=2.0, closing_speed=8.0, risk_level="HIGH",
                   predicted_conflict=True)
    ints, _, _ = _build([obj])
    types = [i.interaction_type for i in ints]
    assert any(t in (
        BehaviorInteractionType.WRONG_SIDE_APPROACH,
        BehaviorInteractionType.APPROACHING,
        BehaviorInteractionType.VEHICLE_VEHICLE,
    ) for t in types)


def test_interaction_evidence_present():
    obj = make_obj(vx=-5.0, speed=5.0, ttc=3.0, predicted_conflict=True)
    ints, _, _ = _build([obj])
    for i in ints:
        assert isinstance(i.evidence, list)


def test_interaction_ids_unique():
    objs = [make_obj(obj_id=f"o{i}", vx=-5.0, speed=5.0, ttc=3.0) for i in range(5)]
    ints, _, _ = _build(objs)
    ids = [i.interaction_id for i in ints]
    assert len(ids) == len(set(ids))


def test_interaction_confidence_range():
    obj = make_obj(vx=-5.0, speed=5.0, ttc=3.0, predicted_conflict=True)
    ints, _, _ = _build([obj])
    for i in ints:
        assert 0.0 <= i.confidence <= 1.0
        assert 0.0 <= i.uncertainty <= 1.0
