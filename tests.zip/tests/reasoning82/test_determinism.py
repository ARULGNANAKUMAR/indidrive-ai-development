"""
IndiDrive AI — Phase 8.2 | Determinism, Thread Safety & Bounded Performance
=============================================================================
"""
import sys, os, time
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..'))
import logging; logging.disable(logging.CRITICAL)

from helpers import make_obj, make_snapshot, make_phase81, make_hazard, default_config
from core.reasoning.behavior_reasoning_engine import BehaviorReasoningEngine
from core.reasoning.behavior_types import BehaviorState


def _engine():
    return BehaviorReasoningEngine(config=default_config())


def _run(objects, hazards=None, drivable_width=6.0):
    snap = make_snapshot(objects=objects, drivable_width=drivable_width)
    phase81 = make_phase81(hazards=hazards or [])
    return _engine().reason(snap, phase81)


def _state_fingerprint(state):
    """Deterministic fingerprint of a BehaviorReasoningState."""
    behaviors = tuple(
        (b.entity_id, b.behavior_state.value, round(b.behavior_confidence, 3))
        for b in state.entity_behaviors
    )
    interactions = tuple(
        (i.interaction_id, i.interaction_type.value, i.severity.value,
         round(i.confidence, 3))
        for i in state.interactions
    )
    compounds = tuple(
        (s.situation_id, s.situation_type.value)
        for s in state.compound_situations
    )
    return (
        state.schema_version,
        behaviors,
        interactions,
        compounds,
        state.overall_interaction_complexity,
        round(state.confidence, 3),
        round(state.uncertainty, 3),
        tuple(sorted(state.reason_codes)),
    )


# ==========================================================================
# Determinism
# ==========================================================================

def test_determinism_identical_input():
    """Identical inputs → identical outputs, run 5 times."""
    objs = [
        make_obj(obj_id="car1", vx=-5.0, speed=5.0, ttc=3.0,
                 risk_level="HIGH", predicted_conflict=True),
        make_obj(obj_id="ped1", object_type="PEDESTRIAN",
                 vx=0.0, vy=2.0, speed=2.0, dist=10.0, x=10.0),
    ]
    snap = make_snapshot(objects=objs, drivable_width=4.0, frame_id=99)
    phase81 = make_phase81()

    engine = BehaviorReasoningEngine(config=default_config())
    fingerprints = set()
    for _ in range(5):
        result = engine.reason(snap, phase81)
        fingerprints.add(_state_fingerprint(result.state))

    assert len(fingerprints) == 1, \
        f"Non-deterministic output: {len(fingerprints)} distinct fingerprints"


def test_determinism_behavior_states():
    """Same object → same behavior state across runs."""
    obj = make_obj(vx=-6.0, vy=0.0, speed=6.0, ttc=2.0, risk_level="HIGH",
                   predicted_conflict=True)
    snap = make_snapshot([obj], frame_id=42)
    phase81 = make_phase81()
    engine = BehaviorReasoningEngine(config=default_config())

    states = []
    for _ in range(5):
        r = engine.reason(snap, phase81)
        states.append(r.state.entity_behaviors[0].behavior_state if r.state.entity_behaviors else None)

    assert len(set(str(s) for s in states)) == 1, "Behavior state is not deterministic"


def test_determinism_interaction_order():
    """Interaction ordering must be deterministic."""
    objs = [
        make_obj(obj_id=f"o{i}", vx=-5.0, speed=5.0, ttc=3.0)
        for i in range(4)
    ]
    snap = make_snapshot(objs, frame_id=7)
    phase81 = make_phase81()
    engine = BehaviorReasoningEngine(config=default_config())

    orderings = []
    for _ in range(4):
        r = engine.reason(snap, phase81)
        orderings.append(tuple(i.interaction_id for i in r.state.interactions))

    assert len(set(orderings)) == 1, "Interaction ordering is not deterministic"


def test_determinism_reason_codes():
    """Reason codes must be identical across runs."""
    objs = [make_obj(obj_id="rc1", vx=-4.0, vy=2.0, speed=4.5, ttc=2.5,
                     risk_level="HIGH", predicted_conflict=True)]
    snap = make_snapshot(objs, drivable_width=3.0, frame_id=5,
                         indian_ctx_kwargs={"available": True, "cattle_present": True})
    phase81 = make_phase81()
    engine = BehaviorReasoningEngine(config=default_config())

    code_sets = []
    for _ in range(4):
        r = engine.reason(snap, phase81)
        code_sets.append(frozenset(r.state.reason_codes))

    assert len(set(frozenset(s) for s in code_sets)) == 1


def test_determinism_confidence_values():
    """Confidence and uncertainty values must be identical across runs."""
    obj = make_obj(vx=-5.0, speed=5.0, ttc=3.0, predicted_conflict=True)
    snap = make_snapshot([obj], frame_id=3)
    phase81 = make_phase81()
    engine = BehaviorReasoningEngine(config=default_config())

    values = [(round(r.state.confidence, 3), round(r.state.uncertainty, 3))
              for r in (engine.reason(snap, phase81) for _ in range(4))]
    assert len(set(values)) == 1


# ==========================================================================
# Bounded performance
# ==========================================================================

def test_small_scene_bounded():
    """Single object: verify all bounds are respected."""
    obj = make_obj(vx=-5.0, speed=5.0, ttc=3.0)
    result = _run([obj])
    cfg = default_config()
    s = result.state
    assert len(s.entity_behaviors) <= cfg.max_behavior_entities
    assert len(s.interactions) <= cfg.max_behavior_interactions
    assert len(s.intent_hypotheses) <= cfg.max_intent_hypotheses
    assert len(s.compound_situations) <= cfg.max_compound_situations
    assert s.interaction_graph.node_count <= cfg.max_graph_nodes
    assert s.interaction_graph.edge_count <= cfg.max_graph_edges


def test_medium_scene_bounded():
    """10 objects: all bounds respected."""
    objs = [make_obj(obj_id=f"o{i:02d}", vx=-4.0+i*0.1, vy=i*0.05,
                     speed=4.0, ttc=3.0+i*0.3) for i in range(10)]
    result = _run(objs)
    cfg = default_config()
    s = result.state
    assert len(s.entity_behaviors) <= cfg.max_behavior_entities
    assert len(s.interactions) <= cfg.max_behavior_interactions
    assert s.interaction_graph.node_count <= cfg.max_graph_nodes
    assert s.interaction_graph.edge_count <= cfg.max_graph_edges


def test_maximum_scene_bounded():
    """25 objects (above max_behavior_entities default): must still be bounded."""
    objs = [make_obj(obj_id=f"o{i:03d}", vx=-4.0, vy=float(i%3-1)*2.0,
                     speed=4.0, ttc=3.0, dist=10.0+i*0.5) for i in range(25)]
    result = _run(objs)
    cfg = default_config()
    s = result.state
    assert len(s.entity_behaviors) <= cfg.max_behavior_entities
    assert len(s.interactions) <= cfg.max_behavior_interactions
    assert s.interaction_graph.node_count <= cfg.max_graph_nodes
    assert s.interaction_graph.edge_count <= cfg.max_graph_edges
    assert len(s.compound_situations) <= cfg.max_compound_situations


def test_no_unbounded_loops():
    """Engine completes in reasonable time even with large inputs."""
    objs = [make_obj(obj_id=f"o{i:03d}", vx=-4.0, vy=1.0, speed=4.1,
                     ttc=3.0) for i in range(50)]
    t0 = time.monotonic()
    result = _run(objs)
    elapsed = time.monotonic() - t0
    assert result.is_valid
    # Should complete in under 5 seconds (very conservative)
    assert elapsed < 5.0, f"Engine took too long: {elapsed:.2f}s"


# ==========================================================================
# Thread safety
# ==========================================================================

def test_shared_config_not_mutated():
    """Running reason() on the same engine twice must not mutate config."""
    cfg = default_config()
    original_max_entities = cfg.max_behavior_entities
    engine = BehaviorReasoningEngine(config=cfg)

    obj = make_obj(vx=-5.0, speed=5.0, ttc=3.0)
    snap = make_snapshot([obj])
    phase81 = make_phase81()

    engine.reason(snap, phase81)
    engine.reason(snap, phase81)

    assert cfg.max_behavior_entities == original_max_entities


def test_world_model_not_mutated():
    """Engine must not mutate the WorldModelSnapshot."""
    obj = make_obj(vx=-5.0, speed=5.0, ttc=3.0)
    snap = make_snapshot([obj])
    original_object_count = len(snap.objects)
    original_ts = snap.timestamp

    phase81 = make_phase81()
    engine = BehaviorReasoningEngine(config=default_config())
    engine.reason(snap, phase81)

    assert len(snap.objects) == original_object_count
    assert snap.timestamp == original_ts


def test_phase81_not_mutated():
    """Engine must not mutate the Phase 8.1 ReasoningSnapshot."""
    snap = make_snapshot([])
    phase81 = make_phase81()
    original_state = phase81.reasoning_state
    original_conf = phase81.reasoning_confidence

    engine = BehaviorReasoningEngine(config=default_config())
    engine.reason(snap, phase81)

    assert phase81.reasoning_state == original_state
    assert phase81.reasoning_confidence == original_conf


def test_repeated_reads_safe():
    """Reading from a BehaviorReasoningState multiple times is safe."""
    obj = make_obj(vx=-5.0, speed=5.0, ttc=3.0)
    snap = make_snapshot([obj])
    phase81 = make_phase81()
    engine = BehaviorReasoningEngine(config=default_config())
    result = engine.reason(snap, phase81)
    state = result.state

    # Read multiple times — must be identical
    dict1 = state.to_dict()
    dict2 = state.to_dict()
    assert dict1 == dict2


def test_behavior_state_tuple_immutable():
    """entity_behaviors, interactions, intent_hypotheses are tuples."""
    obj = make_obj(vx=-5.0, speed=5.0, ttc=3.0)
    snap = make_snapshot([obj])
    result = _engine().reason(snap, make_phase81())
    state = result.state
    assert isinstance(state.entity_behaviors, tuple)
    assert isinstance(state.interactions, tuple)
    assert isinstance(state.intent_hypotheses, tuple)
    assert isinstance(state.compound_situations, tuple)
