"""
IndiDrive AI — Phase 8.2 | Behavior Classification Tests
=========================================================
Tests for BehaviorClassifier covering all behavior states.
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..'))
import logging; logging.disable(logging.CRITICAL)

from helpers import make_obj, make_snapshot, make_phase81, default_config
from core.reasoning.behavior_classifier import BehaviorClassifier
from core.reasoning.behavior_types import BehaviorState, EvidenceClass
from core.world_model.world_model_types import WorldObjectLifecycle


def _classifier():
    return BehaviorClassifier(default_config())


def test_stationary_object():
    obj = make_obj(vx=0.0, vy=0.0, speed=0.0, is_moving=False,
                   ttc=None, closing_speed=None, collision_likelihood=None)
    result = _classifier().classify_all((obj,), 0.0)
    assert result, "Expected classification"
    bc = result[0]
    assert bc.behavior_state == BehaviorState.STATIONARY
    assert bc.behavior_confidence > 0.5
    assert bc.evidence_class == EvidenceClass.OBSERVED


def test_moving_object():
    obj = make_obj(vx=-3.0, vy=0.0, speed=3.0, is_moving=True,
                   ttc=10.0, closing_speed=3.0, risk_level="LOW")
    result = _classifier().classify_all((obj,), 0.0)
    assert result
    bc = result[0]
    assert bc.behavior_state not in (BehaviorState.STATIONARY, BehaviorState.UNKNOWN)
    assert bc.behavior_confidence > 0.0


def test_approaching_object():
    obj = make_obj(vx=-6.0, vy=0.0, speed=6.0, is_moving=True,
                   ttc=2.0, closing_speed=6.0, collision_likelihood=0.5,
                   risk_level="HIGH", predicted_conflict=True)
    result = _classifier().classify_all((obj,), 0.0)
    assert result
    bc = result[0]
    assert bc.behavior_state in (
        BehaviorState.APPROACHING, BehaviorState.UNCERTAIN, BehaviorState.MOVING
    )
    assert bc.behavior_confidence > 0.0


def test_receding_object():
    obj = make_obj(vx=5.0, vy=0.0, speed=5.0, is_moving=True,
                   ttc=None, closing_speed=-5.0, risk_level="LOW")
    result = _classifier().classify_all((obj,), 0.0)
    assert result
    bc = result[0]
    assert bc.behavior_state in (BehaviorState.RECEDING, BehaviorState.MOVING,
                                  BehaviorState.UNCERTAIN)


def test_lateral_movement():
    obj = make_obj(vx=-2.0, vy=4.0, speed=4.5, is_moving=True,
                   ttc=5.0, closing_speed=2.0, risk_level="MEDIUM")
    result = _classifier().classify_all((obj,), 0.0)
    assert result
    bc = result[0]
    assert bc.behavior_state in (
        BehaviorState.CROSSING, BehaviorState.LATERAL_MOVEMENT,
        BehaviorState.UNCERTAIN, BehaviorState.MOVING
    )


def test_crossing_object():
    obj = make_obj(vx=0.0, vy=5.0, speed=5.0, is_moving=True,
                   ttc=3.0, closing_speed=0.5, risk_level="HIGH",
                   predicted_conflict=True)
    result = _classifier().classify_all((obj,), 0.0)
    assert result
    bc = result[0]
    assert bc.behavior_state in (
        BehaviorState.CROSSING, BehaviorState.LATERAL_MOVEMENT, BehaviorState.UNCERTAIN
    )
    assert bc.behavior_confidence > 0.0


def test_turning_object():
    obj = make_obj(vx=-3.0, vy=1.0, speed=3.2, is_moving=True,
                   yaw_rate=0.25, ttc=6.0, risk_level="LOW")
    result = _classifier().classify_all((obj,), 0.0)
    assert result
    bc = result[0]
    assert bc.behavior_state in (
        BehaviorState.TURNING, BehaviorState.UNCERTAIN, BehaviorState.MOVING,
        BehaviorState.CROSSING, BehaviorState.LATERAL_MOVEMENT
    )


def test_accelerating_object():
    obj = make_obj(vx=-5.0, vy=0.0, speed=5.0, ax=-1.5, is_moving=True,
                   ttc=8.0, risk_level="LOW", closing_speed=5.0)
    result = _classifier().classify_all((obj,), 0.0)
    assert result
    bc = result[0]
    # ax=-1.5 means decelerating in x (since x is forward), but
    # acceleration magnitude triggers ACCELERATING or DECELERATING
    assert bc.behavior_state != BehaviorState.UNKNOWN or bc.behavior_confidence >= 0.0


def test_decelerating_object():
    obj = make_obj(vx=-3.0, vy=0.0, speed=3.0, ax=1.0, is_moving=True,
                   ttc=6.0, risk_level="LOW", closing_speed=3.0)
    result = _classifier().classify_all((obj,), 0.0)
    assert result
    bc = result[0]
    assert bc.behavior_state in (
        BehaviorState.DECELERATING, BehaviorState.STOPPING,
        BehaviorState.MOVING, BehaviorState.APPROACHING, BehaviorState.UNCERTAIN
    )


def test_stopping_object():
    obj = make_obj(vx=-1.0, vy=0.0, speed=1.0, ax=1.2, is_moving=True,
                   ttc=2.0, risk_level="MEDIUM", closing_speed=1.0)
    result = _classifier().classify_all((obj,), 0.0)
    assert result
    bc = result[0]
    assert bc.behavior_state in (
        BehaviorState.STOPPING, BehaviorState.DECELERATING,
        BehaviorState.APPROACHING, BehaviorState.UNCERTAIN, BehaviorState.MOVING
    )


def test_unknown_behavior_missing_data():
    from core.world_model.world_model_types import WorldObject
    obj = WorldObject(object_id="unk_001", object_type="UNKNOWN")
    result = _classifier().classify_all((obj,), 0.0)
    assert result
    bc = result[0]
    assert bc.behavior_state in (BehaviorState.STATIONARY, BehaviorState.UNKNOWN)


def test_uncertain_behavior_conflicting_evidence():
    # Crossing + approaching simultaneously
    obj = make_obj(vx=-5.0, vy=5.0, speed=7.0, is_moving=True,
                   yaw_rate=0.2,
                   ttc=1.5, closing_speed=5.0, risk_level="HIGH",
                   predicted_conflict=True)
    result = _classifier().classify_all((obj,), 0.0)
    assert result
    bc = result[0]
    # With conflicting signals → UNCERTAIN or one dominant wins
    assert bc.behavior_confidence >= 0.0
    assert bc.behavior_uncertainty >= 0.0


def test_stale_object_handled():
    obj = make_obj(vx=-4.0, vy=0.0, speed=4.0, is_moving=True, is_stale=True)
    result = _classifier().classify_all((obj,), 0.0)
    assert result
    bc = result[0]
    # Stale objects get reduced confidence
    assert bc.behavior_confidence <= 0.6
    # Stale evidence present
    stale_ev = [e for e in bc.evidence if "STALE" in e.code]
    assert stale_ev


def test_beyond_max_distance_skipped():
    cfg = default_config()
    cfg.max_interaction_distance_m = 30.0
    c = BehaviorClassifier(cfg)
    obj = make_obj(dist=100.0, x=100.0)
    result = c.classify_all((obj,), 0.0)
    assert result == []  # beyond range → skipped


def test_evidence_items_bounded():
    obj = make_obj(vx=-5.0, vy=3.0, speed=5.8, yaw_rate=0.2,
                   ax=-0.8, is_moving=True, ttc=2.0, predicted_conflict=True)
    result = _classifier().classify_all((obj,), 0.0)
    assert result
    bc = result[0]
    cfg = default_config()
    assert len(bc.evidence) <= cfg.max_evidence_items


def test_competing_states_structure():
    obj = make_obj(vx=-5.0, vy=5.0, speed=7.1, yaw_rate=0.25,
                   is_moving=True, ttc=1.5, closing_speed=5.0, predicted_conflict=True)
    result = _classifier().classify_all((obj,), 0.0)
    assert result
    bc = result[0]
    for state, conf in bc.competing_states:
        assert 0.0 <= conf <= 1.0
        assert isinstance(state, BehaviorState)


def test_prediction_hypotheses_used():
    obj = make_obj(
        vx=-2.0, vy=2.0, speed=2.8, is_moving=True,
        hypotheses=[{"behaviour": "CROSSING", "probability": 0.7}],
    )
    result = _classifier().classify_all((obj,), 0.0)
    assert result
    bc = result[0]
    # Should have crossing-related evidence
    codes = [e.code for e in bc.evidence]
    has_crossing_evidence = any("CROSSING" in c or "LAT" in c or "TRAJ" in c for c in codes)
    assert has_crossing_evidence or bc.behavior_state in (
        BehaviorState.CROSSING, BehaviorState.LATERAL_MOVEMENT, BehaviorState.UNCERTAIN
    )
