"""
IndiDrive AI — Phase 8.2 | Validation & Engine Integration Tests
=================================================================
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..'))
import logging; logging.disable(logging.CRITICAL)

from helpers import make_obj, make_snapshot, make_phase81, make_hazard, default_config
from core.reasoning.behavior_reasoning_engine import BehaviorReasoningEngine
from core.reasoning.behavior_validator import BehaviorValidator, BehaviorValidationResult
from core.reasoning.behavior_types import (
    BehaviorReasoningState, BehaviorValidationStatus,
    BEHAVIOR_REASONING_SCHEMA_VERSION, InteractionGraph,
)
from core.reasoning.behavior_snapshot import (
    behavior_state_age_s, is_behavior_state_stale,
    behavior_state_to_json, behavior_state_summary, safe_copy_behavior_state,
)


def _engine():
    return BehaviorReasoningEngine(config=default_config())


def _validator():
    return BehaviorValidator(default_config())


# ==========================================================================
# Engine integration
# ==========================================================================

def test_engine_returns_valid_result():
    """Basic smoke test: engine runs and returns valid result."""
    obj = make_obj(vx=-5.0, speed=5.0, ttc=3.0, risk_level="MEDIUM")
    snap = make_snapshot([obj])
    result = _engine().reason(snap, make_phase81())
    assert result.is_valid
    assert result.status in ("ok", "degraded")
    assert result.state.schema_version == BEHAVIOR_REASONING_SCHEMA_VERSION


def test_engine_result_structure():
    """Verify result has expected structure."""
    obj = make_obj(vx=-5.0, speed=5.0, ttc=3.0)
    snap = make_snapshot([obj])
    result = _engine().reason(snap, make_phase81())
    state = result.state
    assert hasattr(state, "entity_behaviors")
    assert hasattr(state, "interactions")
    assert hasattr(state, "intent_hypotheses")
    assert hasattr(state, "compound_situations")
    assert hasattr(state, "interaction_graph")
    assert hasattr(state, "overall_interaction_complexity")
    assert hasattr(state, "confidence")
    assert hasattr(state, "uncertainty")
    assert hasattr(state, "completeness")
    assert hasattr(state, "degraded")
    assert hasattr(state, "reason_codes")
    assert hasattr(state, "memory_context")


def test_engine_empty_scene():
    """Engine with no objects produces valid empty result."""
    snap = make_snapshot([])
    result = _engine().reason(snap, make_phase81())
    assert result.status in ("ok", "degraded", "empty")
    assert result.state.entity_count == 0


def test_engine_to_dict():
    """to_dict() produces JSON-serializable structure."""
    import json
    obj = make_obj(vx=-5.0, speed=5.0, ttc=3.0)
    snap = make_snapshot([obj])
    result = _engine().reason(snap, make_phase81())
    d = result.to_dict()
    assert "state" in d
    # Must be JSON-serializable
    json.dumps(d, default=str)


def test_engine_dominant_interactions_populated():
    """Dominant interactions must be a subset of all interactions."""
    obj = make_obj(vx=-7.0, speed=7.0, ttc=1.5, risk_level="CRITICAL",
                   predicted_conflict=True)
    snap = make_snapshot([obj])
    result = _engine().reason(snap, make_phase81())
    state = result.state
    dom_ids = {i.interaction_id for i in state.dominant_interactions}
    all_ids = {i.interaction_id for i in state.interactions}
    assert dom_ids <= all_ids


def test_engine_complexity_valid():
    """overall_interaction_complexity must be a valid level."""
    obj = make_obj(vx=-5.0, speed=5.0, ttc=3.0)
    snap = make_snapshot([obj])
    result = _engine().reason(snap, make_phase81())
    assert result.state.overall_interaction_complexity in (
        "LOW", "MEDIUM", "HIGH", "VERY_HIGH", "NOT_AVAILABLE"
    )


def test_engine_memory_context_preserved():
    """Memory context string is preserved in output."""
    snap = make_snapshot([])
    result = _engine().reason(snap, make_phase81(), memory_context="similarity:0.82")
    assert result.state.memory_context == "similarity:0.82"


def test_engine_memory_unavailable_works():
    """Engine works when memory context is unavailable."""
    snap = make_snapshot([])
    result = _engine().reason(snap, make_phase81(), memory_context="unavailable")
    assert result.is_valid
    assert result.state.memory_context == "unavailable"


# ==========================================================================
# Validation
# ==========================================================================

def test_validator_valid_state():
    """A well-formed state produces VALID result."""
    obj = make_obj(vx=-5.0, speed=5.0, ttc=3.0)
    snap = make_snapshot([obj])
    result = _engine().reason(snap, make_phase81())
    vr = _validator().validate(result.state)
    assert vr.status in (
        BehaviorValidationStatus.VALID, BehaviorValidationStatus.PARTIAL
    )


def test_validator_confidence_range():
    """Validator catches out-of-range confidence."""
    state = BehaviorReasoningState(
        confidence=1.5,  # invalid
        uncertainty=0.3,
        interaction_graph=InteractionGraph(),
    )
    vr = _validator().validate(state)
    assert vr.status == BehaviorValidationStatus.INVALID
    assert any("confidence" in e for e in vr.errors)


def test_validator_schema_version_mismatch():
    """Validator warns on schema version mismatch."""
    state = BehaviorReasoningState(
        schema_version="0.0",  # wrong
        confidence=0.5,
        uncertainty=0.5,
        interaction_graph=InteractionGraph(),
    )
    vr = _validator().validate(state)
    assert any("schema_version" in w for w in vr.warnings)


def test_validator_entity_bounds():
    """Validator catches entity count exceeding max."""
    from core.reasoning.behavior_types import BehaviorClassification
    cfg = default_config()
    cfg.max_behavior_entities = 2
    v = BehaviorValidator(cfg)
    entities = tuple(
        BehaviorClassification(entity_id=f"e{i}") for i in range(5)
    )
    state = BehaviorReasoningState(
        _entity_behaviors=entities,
        confidence=0.5,
        uncertainty=0.5,
        interaction_graph=InteractionGraph(),
    )
    vr = v.validate(state)
    assert vr.status == BehaviorValidationStatus.INVALID
    assert any("entity" in e for e in vr.errors)


# ==========================================================================
# Snapshot utilities
# ==========================================================================

def test_behavior_state_age():
    """Snapshot age is correctly computed."""
    import time
    obj = make_obj()
    snap = make_snapshot([obj])
    result = _engine().reason(snap, make_phase81())
    state = result.state
    age = behavior_state_age_s(state)
    assert age >= 0.0
    assert age < 60.0  # Should be very fresh


def test_is_stale_false_for_fresh():
    """Fresh state must not be stale."""
    obj = make_obj()
    snap = make_snapshot([obj])
    result = _engine().reason(snap, make_phase81())
    # Use large threshold — state is definitely fresh
    assert not is_behavior_state_stale(result.state, threshold_s=100.0)


def test_behavior_state_to_json():
    """to_json must produce valid JSON string."""
    import json
    obj = make_obj(vx=-5.0, speed=5.0)
    snap = make_snapshot([obj])
    result = _engine().reason(snap, make_phase81())
    j = behavior_state_to_json(result.state)
    parsed = json.loads(j)
    assert "schema_version" in parsed


def test_behavior_state_summary():
    """Summary dict must have expected keys."""
    obj = make_obj(vx=-5.0, speed=5.0)
    snap = make_snapshot([obj])
    result = _engine().reason(snap, make_phase81())
    summary = behavior_state_summary(result.state)
    for key in ("entity_count", "interaction_count", "compound_count",
                "overall_complexity", "confidence", "degraded"):
        assert key in summary


def test_safe_copy_does_not_mutate():
    """safe_copy_behavior_state returns a plain dict, not the original."""
    obj = make_obj(vx=-5.0, speed=5.0)
    snap = make_snapshot([obj])
    result = _engine().reason(snap, make_phase81())
    state = result.state
    copy = safe_copy_behavior_state(state)
    assert isinstance(copy, dict)
    # Modify copy, original must not change
    copy["schema_version"] = "tampered"
    assert state.schema_version == BEHAVIOR_REASONING_SCHEMA_VERSION
