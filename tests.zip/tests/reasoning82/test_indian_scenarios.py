"""
IndiDrive AI — Phase 8.2 | Indian Road Scenario Tests
=======================================================
Tests for all 8 mandated Indian road scenarios, built using actual
World Model inputs — NOT scenario-name-only logic.
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..'))
import logging; logging.disable(logging.CRITICAL)

from helpers import make_obj, make_snapshot, make_phase81, make_hazard, default_config
from core.reasoning.behavior_reasoning_engine import BehaviorReasoningEngine
from core.reasoning.behavior_types import (
    BehaviorState, InteractionSeverity, CompoundSituationType, IntentType,
)
from core.reasoning.reasoning_types import HazardCategory, RiskLevel, TtcBand
from core.world_model.world_model_types import WorldModelStatus


def _engine():
    return BehaviorReasoningEngine(config=default_config())


def _run(snap, hazards=None, phase81=None):
    if phase81 is None:
        phase81 = make_phase81(hazards=hazards or [])
    return _engine().reason(snap, phase81)


# ==========================================================================
# Scenario 1 — Unmarked village road
# ==========================================================================

def test_scenario_unmarked_village_road():
    """
    Village road: pedestrian + cattle + narrow unmarked road.
    Constructs actual WM inputs — no hardcoded scenario logic.
    """
    objs = [
        make_obj(obj_id="ped_001", object_type="PEDESTRIAN",
                 vx=0.3, vy=1.8, speed=1.8,
                 dist=10.0, x=10.0, risk_level="MEDIUM", ttc=None),
        make_obj(obj_id="cow_001", object_type="CATTLE", object_subtype="COW",
                 vx=0.2, vy=0.8, speed=0.8,
                 dist=18.0, x=18.0, risk_level="MEDIUM", ttc=None),
    ]
    snap = make_snapshot(
        objects=objs,
        drivable_width=3.0,
        indian_ctx_kwargs={
            "available": True,
            "road_type": "VILLAGE_ROAD",
            "cattle_present": True,
            "vulnerable_road_users": True,
            "unusual_road_indicators": ["NO_MARKINGS"],
        },
    )
    hazards = [
        make_hazard("ped_001", HazardCategory.PEDESTRIAN, RiskLevel.MEDIUM, is_vulnerable=True),
        make_hazard("cow_001", HazardCategory.CATTLE, RiskLevel.MEDIUM, is_vulnerable=True),
    ]
    result = _run(snap, hazards)
    assert result.is_valid
    state = result.state
    assert state.entity_count > 0
    assert state.interaction_count > 0
    assert "NARROW_ROAD" in state.reason_codes or state.interaction_count > 0


# ==========================================================================
# Scenario 2 — Dense market area
# ==========================================================================

def test_scenario_dense_market():
    """
    Market area: multiple pedestrians, auto-rickshaws, pushcarts, dense traffic.
    """
    objs = [
        make_obj(obj_id="ped_001", object_type="PEDESTRIAN",
                 vx=0.0, vy=1.2, dist=6.0, x=6.0, risk_level="HIGH",
                 speed=1.2, ttc=None),
        make_obj(obj_id="ped_002", object_type="PEDESTRIAN",
                 vx=-0.3, vy=1.0, dist=8.0, x=7.0, y=1.0,
                 risk_level="MEDIUM", speed=1.0, ttc=None),
        make_obj(obj_id="auto_001", object_type="AUTO_RICKSHAW",
                 vx=-3.0, vy=0.5, speed=3.0,
                 dist=12.0, x=12.0, risk_level="MEDIUM", ttc=5.0),
        make_obj(obj_id="cart_001", object_type="PUSHCART",
                 vx=-0.5, vy=0.0, speed=0.5,
                 dist=5.0, x=5.0, risk_level="LOW", ttc=None),
    ]
    snap = make_snapshot(
        objects=objs,
        drivable_width=4.0,
        indian_ctx_kwargs={
            "available": True,
            "road_type": "URBAN",
            "market_like_activity": True,
            "vulnerable_road_users": True,
            "traffic_density": "VERY_HIGH",
        },
    )
    hazards = [
        make_hazard("ped_001", HazardCategory.PEDESTRIAN, RiskLevel.HIGH, is_vulnerable=True),
        make_hazard("ped_002", HazardCategory.PEDESTRIAN, RiskLevel.MEDIUM, is_vulnerable=True),
        make_hazard("auto_001", HazardCategory.AUTO_RICKSHAW, RiskLevel.MEDIUM),
        make_hazard("cart_001", HazardCategory.PUSHCART, RiskLevel.LOW, is_vulnerable=True),
    ]
    result = _run(snap, hazards)
    assert result.is_valid
    state = result.state
    assert state.entity_count >= 3
    assert "MARKET_ACTIVITY" in state.reason_codes or state.interaction_count > 0


# ==========================================================================
# Scenario 3 — Highway merge
# ==========================================================================

def test_scenario_highway_merge():
    """
    Highway merge: fast merging vehicle, predicting trajectory overlap.
    """
    objs = [
        make_obj(obj_id="merging_001", object_type="VEHICLE", object_subtype="CAR",
                 vx=-10.0, vy=3.5, speed=10.6,
                 ttc=2.5, closing_speed=10.0, risk_level="HIGH",
                 predicted_conflict=True,
                 hypotheses=[{"behaviour": "MERGING", "probability": 0.75}]),
    ]
    snap = make_snapshot(
        objects=objs,
        drivable_width=7.5,
        indian_ctx_kwargs={
            "available": True,
            "road_type": "HIGHWAY",
            "traffic_density": "HIGH",
        },
    )
    hazards = [
        make_hazard("merging_001", HazardCategory.CAR, RiskLevel.HIGH,
                    ttc_s=2.5, ttc_band=TtcBand.NEAR_TERM, predicted_conflict=True),
    ]
    result = _run(snap, hazards)
    assert result.is_valid
    state = result.state
    assert state.interaction_count > 0
    # Should detect lateral/merging behavior
    behaviors = [b for b in state.entity_behaviors if b.entity_id == "merging_001"]
    assert behaviors


# ==========================================================================
# Scenario 4 — Busy intersection
# ==========================================================================

def test_scenario_busy_intersection():
    """
    Busy intersection: crossing vehicles from left/right, pedestrians.
    """
    objs = [
        make_obj(obj_id="cross_l", object_type="VEHICLE",
                 vx=0.0, vy=-5.0, speed=5.0,  # coming from left
                 ttc=2.0, closing_speed=1.0, risk_level="HIGH",
                 predicted_conflict=True),
        make_obj(obj_id="cross_r", object_type="VEHICLE",
                 vx=0.0, vy=4.0, speed=4.0,   # coming from right
                 ttc=2.5, closing_speed=0.5, risk_level="MEDIUM"),
        make_obj(obj_id="ped_int", object_type="PEDESTRIAN",
                 vx=0.0, vy=1.5, speed=1.5, dist=7.0, x=7.0,
                 risk_level="MEDIUM"),
    ]
    snap = make_snapshot(
        objects=objs,
        drivable_width=6.0,
        indian_ctx_kwargs={
            "available": True,
            "intersection_context": "UNCONTROLLED",
            "traffic_density": "HIGH",
        },
    )
    hazards = [
        make_hazard("cross_l", HazardCategory.CAR, RiskLevel.HIGH,
                    ttc_s=2.0, ttc_band=TtcBand.NEAR_TERM, predicted_conflict=True),
        make_hazard("cross_r", HazardCategory.CAR, RiskLevel.MEDIUM, ttc_s=2.5),
        make_hazard("ped_int", HazardCategory.PEDESTRIAN, RiskLevel.MEDIUM,
                    is_vulnerable=True),
    ]
    result = _run(snap, hazards)
    assert result.is_valid
    assert result.state.interaction_count > 0


# ==========================================================================
# Scenario 5 — Sudden cattle crossing
# ==========================================================================

def test_scenario_sudden_cattle_crossing():
    """
    Cattle crossing into drivable area unexpectedly.
    High lateral velocity from stationary-to-moving.
    """
    objs = [
        make_obj(obj_id="cow_001", object_type="CATTLE", object_subtype="COW",
                 vx=0.0, vy=4.0, speed=4.0,  # crossing laterally
                 dist=8.0, x=8.0, y=0.0,
                 ttc=2.0, closing_speed=0.2, risk_level="HIGH",
                 predicted_conflict=True),
    ]
    snap = make_snapshot(
        objects=objs,
        drivable_width=4.0,
        indian_ctx_kwargs={
            "available": True,
            "road_type": "VILLAGE_ROAD",
            "cattle_present": True,
        },
    )
    hazards = [
        make_hazard("cow_001", HazardCategory.CATTLE, RiskLevel.HIGH,
                    ttc_s=2.0, ttc_band=TtcBand.NEAR_TERM,
                    predicted_conflict=True, is_vulnerable=True),
    ]
    result = _run(snap, hazards)
    assert result.is_valid
    state = result.state
    assert state.interaction_count > 0
    # Should identify cattle interaction
    cattle_ints = [i for i in state.interactions
                   if "CATTLE" in i.interaction_type.value]
    assert cattle_ints


# ==========================================================================
# Scenario 6 — Wrong-side traffic
# ==========================================================================

def test_scenario_wrong_side_traffic():
    """
    Vehicle approaching head-on in our lane (wrong side).
    """
    objs = [
        make_obj(obj_id="ws_001", object_type="VEHICLE", object_subtype="TRUCK",
                 vx=9.0, vy=0.0, speed=9.0,  # positive vx → wrong side
                 ttc=1.5, closing_speed=9.0, risk_level="CRITICAL",
                 predicted_conflict=True),
    ]
    snap = make_snapshot(
        objects=objs,
        drivable_width=5.0,
        indian_ctx_kwargs={
            "available": True,
            "road_type": "HIGHWAY",
            "unusual_road_indicators": ["WRONG_SIDE_TRAFFIC"],
        },
    )
    hazards = [
        make_hazard("ws_001", HazardCategory.WRONG_SIDE_TRAFFIC, RiskLevel.CRITICAL,
                    ttc_s=1.5, ttc_band=TtcBand.IMMEDIATE,
                    predicted_conflict=True),
    ]
    result = _run(snap, hazards)
    assert result.is_valid
    state = result.state
    assert state.interaction_count > 0
    # Should be flagged CRITICAL
    assert any(i.severity == InteractionSeverity.CRITICAL for i in state.interactions)


# ==========================================================================
# Scenario 7 — Narrow damaged road
# ==========================================================================

def test_scenario_narrow_damaged_road():
    """
    Narrow road with pothole/damage + oncoming vehicle.
    """
    objs = [
        make_obj(obj_id="oncoming", object_type="VEHICLE",
                 vx=4.0, vy=0.5, speed=4.0,  # wrong side or passing
                 ttc=3.0, closing_speed=5.0, risk_level="HIGH",
                 predicted_conflict=True),
    ]
    snap = make_snapshot(
        objects=objs,
        drivable_width=2.8,   # very narrow
        has_anomalies=True,
        anomaly_severity="HIGH",
        indian_ctx_kwargs={
            "available": True,
            "road_type": "VILLAGE_ROAD",
        },
    )
    hazards = [
        make_hazard("oncoming", HazardCategory.CAR, RiskLevel.HIGH,
                    ttc_s=3.0, predicted_conflict=True),
    ]
    result = _run(snap, hazards)
    assert result.is_valid
    state = result.state
    # Should detect road anomaly interaction
    anomaly_ints = [i for i in state.interactions
                    if "ROAD_ANOMALY" in i.interaction_type.value]
    assert anomaly_ints or "NARROW_ROAD" in state.reason_codes


# ==========================================================================
# Scenario 8 — Construction area
# ==========================================================================

def test_scenario_construction_area():
    """
    Construction area: workers (pedestrians), equipment, debris.
    """
    objs = [
        make_obj(obj_id="worker_01", object_type="PEDESTRIAN",
                 vx=-0.5, vy=0.8, speed=0.9,
                 dist=10.0, x=10.0, risk_level="HIGH"),
        make_obj(obj_id="worker_02", object_type="PEDESTRIAN",
                 vx=0.3, vy=-0.5, speed=0.6,
                 dist=7.0, x=7.0, y=1.5, risk_level="HIGH"),
        make_obj(obj_id="vehicle_01", object_type="VEHICLE", object_subtype="TRUCK",
                 vx=-2.0, vy=0.0, speed=2.0,
                 dist=25.0, x=25.0, ttc=12.0, risk_level="MEDIUM"),
    ]
    snap = make_snapshot(
        objects=objs,
        drivable_width=4.0,
        has_anomalies=True,
        anomaly_severity="HIGH",
        indian_ctx_kwargs={
            "available": True,
            "unusual_road_indicators": ["CONSTRUCTION"],
            "roadside_activity": "CONSTRUCTION_ACTIVITY",
        },
    )
    hazards = [
        make_hazard("worker_01", HazardCategory.PEDESTRIAN, RiskLevel.HIGH, is_vulnerable=True),
        make_hazard("worker_02", HazardCategory.PEDESTRIAN, RiskLevel.HIGH, is_vulnerable=True),
        make_hazard("vehicle_01", HazardCategory.TRUCK, RiskLevel.MEDIUM),
    ]
    result = _run(snap, hazards)
    assert result.is_valid
    state = result.state
    assert state.entity_count >= 2
    assert state.interaction_count > 0
