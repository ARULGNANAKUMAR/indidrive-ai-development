"""
IndiDrive AI — Phase 8.2 | Multi-Hazard Reasoning Tests
=========================================================
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..'))
import logging; logging.disable(logging.CRITICAL)

from helpers import make_obj, make_snapshot, make_phase81, make_hazard, default_config
from core.reasoning.behavior_reasoning_engine import BehaviorReasoningEngine
from core.reasoning.multi_hazard_reasoner import MultiHazardReasoner
from core.reasoning.interaction_graph_builder import InteractionGraphBuilder
from core.reasoning.behavior_classifier import BehaviorClassifier
from core.reasoning.behavior_types import (
    CompoundSituationType, InteractionSeverity,
)
from core.reasoning.reasoning_types import HazardCategory, RiskLevel, TtcBand


def _engine():
    return BehaviorReasoningEngine(config=default_config())


def _full_reason(objects, hazards=None, drivable_width=6.0, indian_ctx_kwargs=None,
                 has_anomalies=False):
    snap = make_snapshot(objects=objects, drivable_width=drivable_width,
                         has_anomalies=has_anomalies,
                         indian_ctx_kwargs=indian_ctx_kwargs or {})
    phase81 = make_phase81(hazards=hazards or [])
    return _engine().reason(snap, phase81)


# ----- Independent hazards -----

def test_independent_hazards():
    # Two distant vehicles
    objs = [
        make_obj(obj_id="car1", x=40.0, dist=40.0, vx=-3.0, speed=3.0,
                 ttc=13.0, risk_level="LOW", closing_speed=3.0),
        make_obj(obj_id="car2", x=50.0, dist=50.0, vx=-2.0, speed=2.0,
                 ttc=20.0, risk_level="LOW", closing_speed=2.0),
    ]
    h1 = make_hazard("car1", category=HazardCategory.CAR, risk_level=RiskLevel.HIGH)
    h2 = make_hazard("car2", category=HazardCategory.CAR, risk_level=RiskLevel.HIGH)
    result = _full_reason(objs, hazards=[h1, h2])
    assert result.is_valid
    state = result.state
    # With 2 high hazards → expect compound situations
    # Result is valid; compound situations may or may not fire depending on geometry


def test_related_hazards_narrow_road():
    objs = [
        make_obj(obj_id="car1", vx=-5.0, speed=5.0, ttc=3.0, risk_level="MEDIUM"),
        make_obj(obj_id="ped1", object_type="PEDESTRIAN", vx=0.5, vy=1.5,
                 speed=1.6, dist=8.0, x=8.0, risk_level="MEDIUM"),
    ]
    h1 = make_hazard("car1", category=HazardCategory.CAR, risk_level=RiskLevel.MEDIUM)
    h2 = make_hazard("ped1", category=HazardCategory.PEDESTRIAN,
                     risk_level=RiskLevel.MEDIUM, is_vulnerable=True)
    result = _full_reason(objs, hazards=[h1, h2], drivable_width=3.0)
    assert result.is_valid


def test_compound_hazard_narrow_road():
    objs = [
        make_obj(obj_id="moto1", object_type="MOTORCYCLE",
                 vx=-4.0, vy=2.0, speed=4.5, ttc=2.5, risk_level="HIGH",
                 predicted_conflict=True),
        make_obj(obj_id="ped1", object_type="PEDESTRIAN",
                 vx=0.0, vy=2.0, speed=2.0, dist=6.0, x=6.0, risk_level="HIGH"),
    ]
    h1 = make_hazard("moto1", category=HazardCategory.MOTORCYCLE,
                     risk_level=RiskLevel.HIGH, ttc_s=2.5, ttc_band=TtcBand.NEAR_TERM)
    h2 = make_hazard("ped1", category=HazardCategory.PEDESTRIAN,
                     risk_level=RiskLevel.HIGH, is_vulnerable=True)
    result = _full_reason(objs, hazards=[h1, h2], drivable_width=3.5)
    assert result.is_valid
    state = result.state
    compounds = state.compound_situations
    # Should have detected some compound situation
    assert len(compounds) > 0 or len(state.interactions) > 0


def test_cascading_interaction():
    # Two approaching objects with different TTCs
    objs = [
        make_obj(obj_id="near", vx=-8.0, speed=8.0, ttc=1.2,
                 closing_speed=8.0, risk_level="CRITICAL", predicted_conflict=True),
        make_obj(obj_id="far", x=30.0, dist=30.0, vx=-5.0, speed=5.0,
                 ttc=5.0, closing_speed=5.0, risk_level="HIGH"),
    ]
    h1 = make_hazard("near", risk_level=RiskLevel.CRITICAL, ttc_s=1.2,
                     ttc_band=TtcBand.IMMEDIATE)
    h2 = make_hazard("far", risk_level=RiskLevel.HIGH, ttc_s=5.0,
                     ttc_band=TtcBand.MODERATE)
    result = _full_reason(objs, hazards=[h1, h2])
    assert result.is_valid
    # Cascading check might fire given different TTCs
    state = result.state
    cascade = [s for s in state.compound_situations
               if s.situation_type == CompoundSituationType.CASCADING_INTERACTION]
    # We can't guarantee cascading fires in all configs, just assert valid
    assert isinstance(cascade, list)


def test_uncertain_interaction():
    objs = [
        make_obj(obj_id="u1", vx=-3.0, vy=2.0, speed=3.6, confidence=0.3,
                 ttc=5.0, risk_level="MEDIUM"),
    ]
    h1 = make_hazard("u1", risk_level=RiskLevel.MEDIUM, confidence=0.3)
    result = _full_reason(objs, hazards=[h1])
    assert result.is_valid


def test_cattle_compound():
    objs = [
        make_obj(obj_id="cow1", object_type="CATTLE", object_subtype="COW",
                 vx=0.5, vy=1.0, speed=1.1, dist=12.0, x=12.0,
                 ttc=7.0, risk_level="HIGH"),
        make_obj(obj_id="car1", vx=-5.0, speed=5.0, ttc=3.0,
                 risk_level="HIGH", predicted_conflict=True),
    ]
    h1 = make_hazard("cow1", category=HazardCategory.CATTLE,
                     risk_level=RiskLevel.HIGH, is_vulnerable=True)
    h2 = make_hazard("car1", category=HazardCategory.CAR, risk_level=RiskLevel.HIGH)
    result = _full_reason(objs, hazards=[h1, h2],
                          indian_ctx_kwargs={"available": True, "cattle_present": True,
                                             "road_type": "VILLAGE_ROAD"})
    assert result.is_valid
    state = result.state
    cattle_compounds = [s for s in state.compound_situations
                        if "CATTLE" in (s.reason_codes or [" "])[0] or
                        any("CATTLE" in r for r in s.reason_codes)]
    # At minimum the engine must not crash and produce valid output
    assert state.compound_count >= 0


def test_wrong_side_compound():
    obj = make_obj(object_type="VEHICLE",
                   vx=8.0, vy=0.0, speed=8.0, ttc=1.5,
                   closing_speed=10.0, risk_level="CRITICAL", predicted_conflict=True)
    h = make_hazard("obj_001", category=HazardCategory.CAR,
                    risk_level=RiskLevel.CRITICAL, ttc_s=1.5,
                    ttc_band=TtcBand.IMMEDIATE)
    result = _full_reason([obj], hazards=[h])
    assert result.is_valid
    state = result.state
    # Wrong-side should produce interactions
    assert state.interaction_count > 0


def test_compound_bounded():
    objs = [make_obj(obj_id=f"o{i}", vx=-5.0, speed=5.0, ttc=2.0,
                     risk_level="HIGH", predicted_conflict=True) for i in range(10)]
    hazards = [make_hazard(f"o{i}", risk_level=RiskLevel.HIGH) for i in range(10)]
    result = _full_reason(objs, hazards=hazards, drivable_width=3.0)
    assert result.is_valid
    cfg = default_config()
    assert result.state.compound_count <= cfg.max_compound_situations


def test_no_compound_for_empty_scene():
    result = _full_reason([], hazards=[])
    # empty status means no data — this is an acceptable degraded state
    assert result.status in ("ok", "degraded", "empty")
    assert result.state.compound_count == 0


def test_compound_reason_codes_present():
    objs = [
        make_obj(obj_id="c1", object_type="PEDESTRIAN", vx=0.0, vy=2.0,
                 speed=2.0, dist=8.0, x=8.0, risk_level="HIGH"),
        make_obj(obj_id="c2", vx=-5.0, speed=5.0, ttc=2.5, risk_level="HIGH",
                 predicted_conflict=True),
    ]
    h1 = make_hazard("c1", HazardCategory.PEDESTRIAN, RiskLevel.HIGH, is_vulnerable=True)
    h2 = make_hazard("c2", HazardCategory.CAR, RiskLevel.HIGH)
    result = _full_reason(objs, hazards=[h1, h2], drivable_width=3.0)
    for s in result.state.compound_situations:
        assert len(s.reason_codes) > 0
