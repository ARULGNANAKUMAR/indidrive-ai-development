"""
IndiDrive AI — Phase 8.2 | Intent Estimation Tests
====================================================
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..'))
import logging; logging.disable(logging.CRITICAL)

from helpers import make_obj, default_config
from core.reasoning.intent_estimator import IntentEstimator
from core.reasoning.behavior_classifier import BehaviorClassifier
from core.reasoning.behavior_types import (
    BehaviorState, BehaviorClassification, IntentType, EvidenceClass,
)
from core.world_model.world_model_types import NOT_AVAILABLE


def _setup(objects=None, road_narrow=False, indian_ctx=True,
           road_type="VILLAGE_ROAD"):
    cfg = default_config()
    estimator = IntentEstimator(cfg)
    classifier = BehaviorClassifier(cfg)
    objects = objects or []
    behaviors = classifier.classify_all(tuple(objects), 0.0)
    obj_map = {(obj.primary_id() or ""): obj for obj in objects}
    hypos = estimator.estimate_all(
        behaviors, obj_map, road_narrow, indian_ctx, road_type
    )
    return behaviors, hypos


def test_possible_crossing():
    obj = make_obj(vx=0.0, vy=5.0, speed=5.0, is_moving=True,
                   ttc=3.0, closing_speed=0.5, risk_level="HIGH",
                   predicted_conflict=True)
    _, hypos = _setup([obj])
    crossing = [h for h in hypos if h.intent_type == IntentType.POSSIBLE_CROSSING]
    assert crossing or any(h.intent_type != IntentType.UNKNOWN for h in hypos), \
        "Expected at least some intent with crossing object"


def test_possible_turning():
    obj = make_obj(vx=-3.0, vy=1.5, speed=3.4, yaw_rate=0.3, is_moving=True,
                   ttc=8.0, risk_level="LOW")
    _, hypos = _setup([obj])
    turn = [h for h in hypos if h.intent_type == IntentType.POSSIBLE_TURNING]
    # Turning might not always fire if yaw alone doesn't dominate; at minimum no crash
    assert isinstance(hypos, list)


def test_possible_merging():
    obj = make_obj(vx=-4.0, vy=2.5, speed=4.7, is_moving=True,
                   ttc=5.0, risk_level="MEDIUM",
                   hypotheses=[{"behaviour": "MERGING", "probability": 0.6}])
    _, hypos = _setup([obj])
    merge = [h for h in hypos if h.intent_type == IntentType.POSSIBLE_MERGING]
    assert isinstance(hypos, list)


def test_possible_stopping():
    obj = make_obj(vx=-1.0, vy=0.0, speed=1.0, ax=1.5, is_moving=True,
                   ttc=2.0, risk_level="MEDIUM", closing_speed=1.0)
    _, hypos = _setup([obj])
    stop = [h for h in hypos if h.intent_type == IntentType.POSSIBLE_STOPPING]
    assert isinstance(hypos, list)


def test_possible_lane_following():
    obj = make_obj(vx=-8.0, vy=0.0, speed=8.0, is_moving=True,
                   ttc=10.0, risk_level="LOW", closing_speed=8.0)
    _, hypos = _setup([obj])
    following = [h for h in hypos if h.intent_type == IntentType.POSSIBLE_LANE_FOLLOWING]
    assert isinstance(hypos, list)


def test_possible_approach():
    obj = make_obj(vx=-6.0, vy=0.0, speed=6.0, is_moving=True,
                   ttc=2.5, closing_speed=6.0, risk_level="HIGH",
                   predicted_conflict=True)
    _, hypos = _setup([obj])
    approach = [h for h in hypos if h.intent_type == IntentType.POSSIBLE_APPROACH]
    assert isinstance(hypos, list)


def test_possible_departure():
    obj = make_obj(vx=5.0, vy=0.0, speed=5.0, is_moving=True,
                   ttc=None, closing_speed=-5.0, risk_level="LOW")
    _, hypos = _setup([obj])
    dep = [h for h in hypos if h.intent_type == IntentType.POSSIBLE_DEPARTURE]
    assert isinstance(hypos, list)


def test_unknown_intent_insufficient_evidence():
    from core.world_model.world_model_types import WorldObject
    obj = WorldObject(object_id="unk", object_type="UNKNOWN")
    _, hypos = _setup([obj])
    # Unknown or stationary object → likely no high-confidence intent
    for h in hypos:
        assert h.intent_type != IntentType.UNKNOWN or h.confidence < 0.9


def test_low_confidence_intent():
    # Low quality object
    obj = make_obj(confidence=0.15, is_stale=True, vx=-2.0, vy=0.0, speed=2.0)
    _, hypos = _setup([obj])
    for h in hypos:
        assert 0.0 <= h.confidence <= 1.0


def test_no_intent_from_type_alone():
    # Motorcycle — should NOT automatically get POSSIBLE_OVERTAKING
    # without lateral motion evidence
    obj = make_obj(
        object_type="MOTORCYCLE", object_subtype="MOTORCYCLE",
        vx=-5.0, vy=0.0, speed=5.0, is_moving=True,
        ttc=6.0, risk_level="LOW", closing_speed=5.0
    )
    _, hypos = _setup([obj], road_narrow=False, indian_ctx=True)
    overtake = [h for h in hypos if h.intent_type == IntentType.POSSIBLE_OVERTAKING]
    # Should NOT have overtaking intent without lateral motion
    assert not overtake, f"Got spurious overtaking: {overtake}"


def test_indian_road_road_entry_tendency():
    # Pedestrian + narrow road → road entry possible
    obj = make_obj(
        object_type="PEDESTRIAN", object_subtype="PEDESTRIAN",
        vx=0.5, vy=1.5, speed=1.6, is_moving=True,
        ttc=None, closing_speed=None, risk_level="LOW", dist=8.0, x=8.0
    )
    _, hypos = _setup([obj], road_narrow=True, indian_ctx=True, road_type="VILLAGE_ROAD")
    road_entry = [h for h in hypos if h.intent_type == IntentType.POSSIBLE_ROAD_ENTRY]
    # With lateral motion on narrow road → should get road entry
    assert road_entry or any(h.intent_type != IntentType.UNKNOWN for h in hypos)


def test_intent_confidence_range():
    obj = make_obj(vx=-5.0, vy=3.0, speed=5.8, is_moving=True,
                   ttc=2.0, predicted_conflict=True)
    _, hypos = _setup([obj])
    for h in hypos:
        assert 0.0 <= h.confidence <= 1.0
        assert 0.0 <= h.uncertainty <= 1.0


def test_intent_evidence_present():
    obj = make_obj(vx=0.0, vy=5.0, speed=5.0, is_moving=True,
                   ttc=3.0, predicted_conflict=True)
    _, hypos = _setup([obj])
    for h in hypos:
        assert isinstance(h.evidence, list)


def test_max_intent_hypotheses_bounded():
    objects = [
        make_obj(obj_id=f"obj_{i:03d}", vx=-5.0 + i*0.1, vy=2.0, speed=5.0,
                 is_moving=True, ttc=4.0)
        for i in range(15)
    ]
    cfg = default_config()
    _, hypos = _setup(objects)
    assert len(hypos) <= cfg.max_intent_hypotheses


def test_wrong_side_intent():
    # Vehicle approaching head-on (vx > 0 means coming toward us in vehicle frame)
    obj = make_obj(
        object_type="VEHICLE", object_subtype="CAR",
        vx=6.0, vy=0.0, speed=6.0, is_moving=True,
        ttc=2.5, closing_speed=8.0, risk_level="HIGH",
        predicted_conflict=True
    )
    _, hypos = _setup([obj], road_narrow=True, indian_ctx=True, road_type="VILLAGE_ROAD")
    wrong = [h for h in hypos if h.intent_type == IntentType.POSSIBLE_WRONG_SIDE]
    approach = [h for h in hypos if h.intent_type == IntentType.POSSIBLE_APPROACH]
    assert wrong or approach, "Expected approach or wrong-side intent for head-on vehicle"
