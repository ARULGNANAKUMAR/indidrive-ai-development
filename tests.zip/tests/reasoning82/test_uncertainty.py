"""
IndiDrive AI — Phase 8.2 | Uncertainty & Degraded Input Tests
==============================================================
Ensures the engine never invents certainty and handles all degraded
or missing data gracefully.
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..'))
import logging; logging.disable(logging.CRITICAL)

from helpers import make_obj, make_snapshot, make_phase81, default_config
from core.reasoning.behavior_reasoning_engine import BehaviorReasoningEngine
from core.reasoning.behavior_types import BehaviorState, EvidenceClass
from core.world_model.world_model_types import (
    WorldModelSnapshot, WorldModelStatus, WorldObject,
    WorldDataQuality, WorldRoadRepresentation, WorldIndianContextSummary,
    RoadRepresentationStatus,
)


def _engine():
    return BehaviorReasoningEngine(config=default_config())


def _empty_snapshot(status=WorldModelStatus.EMPTY):
    dq = WorldDataQuality(overall_confidence=0.0, is_partial=True)
    snap = WorldModelSnapshot(
        _objects=tuple(),
        road=WorldRoadRepresentation(status=RoadRepresentationStatus.NONE),
        indian_context=WorldIndianContextSummary(),
        data_quality=dq,
        status=status,
    )
    return snap


# ----- Missing velocity -----

def test_missing_velocity():
    """Object with no velocity data — engine must not crash."""
    from core.world_model.world_model_types import WorldObject, WorldObjectPosition
    obj = WorldObject(object_id="no_vel",
                      object_type="VEHICLE",
                      position=WorldObjectPosition(x=10.0, y=0.0, distance_m=10.0))
    snap = make_snapshot([obj])
    phase81 = make_phase81()
    result = _engine().reason(snap, phase81)
    assert result.is_valid
    state = result.state
    for bc in state.entity_behaviors:
        assert bc.behavior_state in (BehaviorState.STATIONARY, BehaviorState.UNKNOWN,
                                     BehaviorState.MOVING, BehaviorState.UNCERTAIN)


# ----- Missing prediction -----

def test_missing_prediction():
    """Object with no prediction — reasoning must continue."""
    from core.world_model.world_model_types import PredictionAvailability
    obj = make_obj(vx=-3.0, speed=3.0, ttc=5.0)
    obj.prediction.availability = PredictionAvailability.NONE
    obj.prediction.trajectory.clear() if hasattr(obj.prediction.trajectory, 'clear') else None
    snap = make_snapshot([obj])
    result = _engine().reason(snap, make_phase81())
    assert result.is_valid


# ----- Missing TTC -----

def test_missing_ttc():
    """Object with no TTC — time_relevance must be UNKNOWN, no fabrication."""
    obj = make_obj(vx=-3.0, speed=3.0, ttc=None, closing_speed=None)
    snap = make_snapshot([obj])
    result = _engine().reason(snap, make_phase81())
    assert result.is_valid
    from core.reasoning.behavior_types import TimeRelevance
    for i in result.state.interactions:
        if i.time_relevance != TimeRelevance.UNKNOWN:
            # Only valid if TTC was actually computed somewhere
            assert i.time_relevance in (
                TimeRelevance.DISTANT, TimeRelevance.MEDIUM_TERM,
                TimeRelevance.NEAR_TERM, TimeRelevance.IMMEDIATE,
                TimeRelevance.UNKNOWN,
            )


# ----- Low confidence -----

def test_low_confidence_object():
    """Low-confidence objects → low reasoning confidence, no invented certainty."""
    obj = make_obj(confidence=0.1, vx=-3.0, speed=3.0, ttc=4.0)
    snap = make_snapshot([obj])
    result = _engine().reason(snap, make_phase81())
    assert result.is_valid
    state = result.state
    for bc in state.entity_behaviors:
        # Low confidence object should not get high behavior confidence
        # (may still classify, but with appropriate uncertainty)
        assert 0.0 <= bc.behavior_confidence <= 1.0
        assert 0.0 <= bc.behavior_uncertainty <= 1.0


# ----- Conflicting evidence -----

def test_conflicting_evidence():
    """Object with conflicting motion signals → UNCERTAIN or competing states."""
    obj = make_obj(
        vx=-5.0, vy=5.0, speed=7.0, yaw_rate=0.25,
        ax=-1.5,  # decelerating while crossing while approaching
        ttc=1.5, closing_speed=5.0, predicted_conflict=True,
        risk_level="CRITICAL"
    )
    snap = make_snapshot([obj])
    result = _engine().reason(snap, make_phase81())
    assert result.is_valid
    state = result.state
    if state.entity_behaviors:
        bc = state.entity_behaviors[0]
        # Either UNCERTAIN or competing states present
        is_uncertain = bc.behavior_state == BehaviorState.UNCERTAIN
        has_competing = len(bc.competing_states) > 0
        # One or the other is acceptable
        assert 0.0 <= bc.behavior_confidence <= 1.0


# ----- Stale data -----

def test_stale_data():
    """Stale data should produce stale evidence, not invented confidence."""
    obj = make_obj(is_stale=True, vx=-3.0, speed=3.0, confidence=0.5)
    snap = make_snapshot([obj])
    result = _engine().reason(snap, make_phase81())
    assert result.is_valid
    state = result.state
    for bc in state.entity_behaviors:
        stale = [e for e in bc.evidence if "STALE" in e.code]
        if stale:
            # Confidence should be reduced for stale data
            assert bc.behavior_confidence <= 0.6


# ----- Degraded World Model -----

def test_degraded_world_model():
    """Degraded WM → engine still returns valid (degraded) result."""
    snap = _empty_snapshot(WorldModelStatus.DEGRADED)
    phase81 = make_phase81()
    result = _engine().reason(snap, phase81)
    assert result.is_valid  # degraded is still valid (not error)
    assert result.state.degraded


# ----- Empty World Model -----

def test_empty_world_model():
    """Empty WM → engine returns 'empty' result, no crash."""
    snap = _empty_snapshot(WorldModelStatus.EMPTY)
    result = _engine().reason(snap, make_phase81())
    # Should not crash; status may be 'empty'
    assert result.status in ("empty", "degraded", "ok")
    assert result.state is not None


# ----- Partial road understanding -----

def test_partial_road_understanding():
    """No road information → road context gracefully omitted."""
    obj = make_obj(vx=-5.0, speed=5.0, ttc=3.0)
    snap = make_snapshot(
        [obj],
        road_status=RoadRepresentationStatus.NONE,
    )
    snap.road.drivable_space.available_width_m = None
    result = _engine().reason(snap, make_phase81())
    assert result.is_valid


# ----- Missing memory context -----

def test_missing_memory_context():
    """Absent memory context → reasoning still works."""
    obj = make_obj(vx=-5.0, speed=5.0, ttc=3.0)
    snap = make_snapshot([obj])
    result = _engine().reason(snap, make_phase81(), memory_context="unavailable")
    assert result.is_valid
    assert result.state.memory_context == "unavailable"


# ----- None world model -----

def test_none_world_model():
    """None WM → error result, no exception."""
    phase81 = make_phase81()
    result = _engine().reason(None, phase81)
    assert result.status == "error"
    assert result.state is not None


# ----- None phase 8.1 -----

def test_none_phase81():
    """None phase81 → error result, no exception."""
    snap = make_snapshot([])
    result = _engine().reason(snap, None)
    assert result.status == "error"
    assert result.state is not None


# ----- Unavailable interaction information -----

def test_unavailable_interaction_info():
    """Objects with no collision info → interactions still attempted."""
    from core.world_model.world_model_types import WorldObjectCollisionInfo
    obj = make_obj(vx=-3.0, speed=3.0, ttc=None)
    obj.collision.risk_level = "NOT_AVAILABLE"
    obj.collision.collision_likelihood = None
    snap = make_snapshot([obj])
    result = _engine().reason(snap, make_phase81())
    assert result.is_valid


# ----- Engine does not invent certainty -----

def test_no_invented_certainty():
    """Uncertain inputs should not produce near-certain outputs."""
    obj = make_obj(confidence=0.2, is_stale=True, vx=None, vy=None, speed=None)
    snap = make_snapshot([obj], overall_confidence=0.2, is_degraded=True)
    result = _engine().reason(snap, make_phase81())
    assert result.is_valid
    # Confidence should reflect degraded inputs
    assert result.state.confidence < 0.9  # Never claim very high confidence on bad data
