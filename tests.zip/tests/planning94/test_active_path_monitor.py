"""Tests for Phase 9.4 ActivePathMonitor."""
import sys
sys.path.insert(0, ".")

from tests.planning94.helpers_94 import (
    make_config, make_candidate, make_candidate_set,
    make_risk, make_risk_set, make_planning_space,
    make_dynamic_object, _T0,
)
from core.planning.active_path_monitor import ActivePathMonitor
from core.planning.replanning_types import ActivePathValidity, NOT_AVAILABLE
from core.planning.candidate_path_types import GeometricValidity, BoundaryValidity
from core.planning.path_risk_types import RiskLevel


class TestActivePathMonitorInit:
    def test_no_active_path_initially(self):
        m = ActivePathMonitor()
        assert m.active_candidate_id == NOT_AVAILABLE
        assert m.active_path is None
        assert m.last_snapshot is None

    def test_set_active_candidate(self):
        m = ActivePathMonitor()
        m.set_active_candidate("cand_A", frame_id=5)
        assert m.active_candidate_id == "cand_A"
        assert m.active_path is not None
        assert m.active_path.candidate_id == "cand_A"

    def test_empty_candidate_id_becomes_not_available(self):
        m = ActivePathMonitor()
        m.set_active_candidate("")
        assert m.active_candidate_id == NOT_AVAILABLE


class TestActivePathMonitorEvaluate:
    def test_not_set_when_no_candidate(self):
        m = ActivePathMonitor()
        rs = make_risk_set()
        ps = make_planning_space()
        cs = make_candidate_set()
        ap, snap = m.evaluate(1, rs, cs, ps, timestamp=_T0 + 1)
        assert ap.validity == ActivePathValidity.NOT_SET

    def test_valid_path_returns_valid(self):
        m = ActivePathMonitor()
        m.set_active_candidate("cand_0")
        cand = make_candidate("cand_0")
        cs = make_candidate_set([cand])
        risk = make_risk("cand_0", total_risk=0.15)
        rs = make_risk_set([risk])
        ps = make_planning_space()
        ap, snap = m.evaluate(1, rs, cs, ps, timestamp=_T0 + 1)
        assert ap.validity == ActivePathValidity.VALID

    def test_invalid_geom_returns_invalid(self):
        m = ActivePathMonitor()
        m.set_active_candidate("cand_0")
        bad = make_candidate("cand_0", geom=GeometricValidity.INVALID)
        cs = make_candidate_set([bad])
        risk = make_risk("cand_0", is_geom_invalid=True)
        rs = make_risk_set([risk])
        ps = make_planning_space()
        ap, snap = m.evaluate(1, rs, cs, ps, timestamp=_T0 + 1)
        assert ap.validity == ActivePathValidity.INVALID

    def test_stale_path_when_no_data_and_aged(self):
        m = ActivePathMonitor(config=make_config(max_active_path_age_s=1.0))
        m.set_active_candidate("cand_0")
        # First evaluate sets the path
        ap, _ = m.evaluate(1, None, None, None, timestamp=_T0 + 0.0)
        # Now evaluate 5 seconds later with no data
        ap2, _ = m.evaluate(2, None, None, None, timestamp=_T0 + 5.0)
        assert ap2.validity == ActivePathValidity.STALE

    def test_degraded_risk_returns_degraded(self):
        m = ActivePathMonitor()
        m.set_active_candidate("cand_0")
        risk = make_risk("cand_0", degraded=True, total_risk=0.2)
        rs = make_risk_set([risk])
        ps = make_planning_space()
        cs = make_candidate_set()
        ap, snap = m.evaluate(1, rs, cs, ps, timestamp=_T0 + 1)
        assert ap.validity == ActivePathValidity.DEGRADED

    def test_risk_score_extracted(self):
        m = ActivePathMonitor()
        m.set_active_candidate("cand_0")
        risk = make_risk("cand_0", total_risk=0.42)
        rs = make_risk_set([risk])
        ps = make_planning_space()
        cs = make_candidate_set()
        ap, _ = m.evaluate(1, rs, cs, ps, timestamp=_T0 + 1)
        assert abs(ap.risk_score - 0.42) < 0.001

    def test_ttc_extracted_from_object_contribution(self):
        m = ActivePathMonitor()
        m.set_active_candidate("cand_0")
        risk = make_risk("cand_0", total_risk=0.5, object_id="v1", ttc_s=3.5)
        rs = make_risk_set([risk])
        ps = make_planning_space()
        cs = make_candidate_set()
        ap, _ = m.evaluate(1, rs, cs, ps, timestamp=_T0 + 1)
        assert ap.ttc_s is not None
        assert abs(ap.ttc_s - 3.5) < 0.01

    def test_critical_object_ids_extracted(self):
        m = ActivePathMonitor()
        m.set_active_candidate("cand_0")
        risk = make_risk("cand_0", total_risk=0.75, object_id="cattle_1", is_critical=True)
        rs = make_risk_set([risk])
        ps = make_planning_space()
        cs = make_candidate_set()
        ap, _ = m.evaluate(1, rs, cs, ps, timestamp=_T0 + 1)
        assert "cattle_1" in ap.critical_object_ids

    def test_snapshot_contains_object_ids_from_space(self):
        m = ActivePathMonitor()
        m.set_active_candidate("cand_0")
        objs = [
            make_dynamic_object("v1", position_x=5.0, position_y=0.0),
            make_dynamic_object("v2", position_x=10.0, position_y=0.5),
        ]
        ps = make_planning_space(dynamic_objects=objs)
        rs = make_risk_set()
        cs = make_candidate_set()
        _, snap = m.evaluate(1, rs, cs, ps, timestamp=_T0 + 1)
        assert "v1" in snap.object_ids
        assert "v2" in snap.object_ids

    def test_snapshot_road_anomaly_detected(self):
        from core.planning.planning_space_types import StaticHazardEntry
        m = ActivePathMonitor()
        m.set_active_candidate("cand_0")
        hazard = StaticHazardEntry()
        ps = make_planning_space(static_hazards=[hazard])
        rs = make_risk_set()
        cs = make_candidate_set()
        _, snap = m.evaluate(1, rs, cs, ps, timestamp=_T0 + 1)
        assert snap.has_road_anomaly is True

    def test_planning_not_allowed_path_not_automatically_valid(self):
        """planning_allowed=False does not mark path geometry INVALID — gate is separate."""
        m = ActivePathMonitor()
        m.set_active_candidate("cand_0")
        ps = make_planning_space(planning_allowed=False)
        rs = make_risk_set()
        cs = make_candidate_set()
        ap, _ = m.evaluate(1, rs, cs, ps, timestamp=_T0 + 1)
        # Path may be VALID geometry-wise; the gate restriction shows in planning_allowed
        # It should NOT be INVALID (that's for geometry issues)
        assert ap.validity in (ActivePathValidity.VALID, ActivePathValidity.DEGRADED,
                                ActivePathValidity.UNKNOWN)

    def test_activation_timestamp_preserved(self):
        m = ActivePathMonitor()
        m.set_active_candidate("cand_0")
        t_set = m.active_path.activation_timestamp
        rs = make_risk_set()
        ps = make_planning_space()
        cs = make_candidate_set()
        ap, _ = m.evaluate(1, rs, cs, ps, timestamp=_T0 + 5)
        assert ap.activation_timestamp == t_set

    def test_candidate_id_change_resets_snapshot_on_set(self):
        m = ActivePathMonitor()
        m.set_active_candidate("cand_0")
        rs = make_risk_set()
        ps = make_planning_space()
        cs = make_candidate_set()
        m.evaluate(1, rs, cs, ps, timestamp=_T0 + 1)
        m.set_active_candidate("cand_1")
        assert m.last_snapshot is None

    def test_last_snapshot_updated_after_evaluate(self):
        m = ActivePathMonitor()
        m.set_active_candidate("cand_0")
        rs = make_risk_set()
        ps = make_planning_space()
        cs = make_candidate_set()
        m.evaluate(1, rs, cs, ps, timestamp=_T0 + 1)
        assert m.last_snapshot is not None
        assert m.last_snapshot.frame_id == 1
