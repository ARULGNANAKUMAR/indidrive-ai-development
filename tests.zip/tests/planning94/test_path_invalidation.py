"""Tests for path invalidation conditions in Phase 9.4."""
import sys
sys.path.insert(0, ".")

from tests.planning94.helpers_94 import (
    make_config, make_candidate, make_candidate_set,
    make_risk, make_risk_set, make_planning_space, _T0,
)
from core.planning.replanning_engine import ReplanningEngine
from core.planning.replanning_types import (
    ReplanningDecision, ReplanningUrgency, ReplanningReasonCode, ActivePathValidity,
)
from core.planning.candidate_path_types import (
    GeometricValidity, BoundaryValidity, DrivableSpaceValidity,
)
from core.planning.planning_space_types import PlanningSpaceStatus


class TestPathInvalidation:
    def _engine(self, **kw):
        return ReplanningEngine(config=make_config(**kw))

    def test_geometric_invalid_candidate_invalidates(self):
        e = self._engine()
        e.set_active_candidate("cand_0")
        bad = make_candidate("cand_0", geom=GeometricValidity.INVALID)
        cs = make_candidate_set([bad])
        r = make_risk("cand_0", is_geom_invalid=True)
        rs = make_risk_set([r])
        ps = make_planning_space()
        result = e.evaluate(1, rs, cs, ps, timestamp=_T0 + 1)
        assert ReplanningReasonCode.PATH_GEOMETRY_INVALID in result.request.reason_codes

    def test_boundary_invalid_candidate_invalidates(self):
        e = self._engine()
        e.set_active_candidate("cand_0")
        bad = make_candidate("cand_0", boundary=BoundaryValidity.INVALID)
        cs = make_candidate_set([bad])
        r = make_risk("cand_0")
        rs = make_risk_set([r])
        ps = make_planning_space()
        result = e.evaluate(1, rs, cs, ps, timestamp=_T0 + 1)
        assert ReplanningReasonCode.PATH_GEOMETRY_INVALID in result.request.reason_codes

    def test_drivable_invalid_candidate_invalidates(self):
        e = self._engine()
        e.set_active_candidate("cand_0")
        bad = make_candidate("cand_0", drivable=DrivableSpaceValidity.INVALID)
        cs = make_candidate_set([bad])
        rs = make_risk_set([make_risk("cand_0")])
        ps = make_planning_space()
        result = e.evaluate(1, rs, cs, ps, timestamp=_T0 + 1)
        assert ReplanningReasonCode.PATH_GEOMETRY_INVALID in result.request.reason_codes

    def test_risk_geom_invalid_invalidates_path(self):
        e = self._engine()
        e.set_active_candidate("cand_0")
        r = make_risk("cand_0", is_geom_invalid=True)
        rs = make_risk_set([r])
        ps = make_planning_space()
        cs = make_candidate_set()
        result = e.evaluate(1, rs, cs, ps, timestamp=_T0 + 1)
        assert result.active_path.validity == ActivePathValidity.INVALID

    def test_invalid_vs_high_risk_distinct(self):
        """INVALID and RISK=0.95 are different conditions."""
        e = self._engine()
        e.set_active_candidate("cand_0")

        # High risk but not invalid
        r_high = make_risk("cand_0", total_risk=0.95, is_geom_invalid=False)
        rs_high = make_risk_set([r_high])
        ps = make_planning_space()
        cs = make_candidate_set()
        result_risk = e.evaluate(1, rs_high, cs, ps, timestamp=_T0 + 1)
        assert ReplanningReasonCode.CRITICAL_PATH_RISK in result_risk.request.reason_codes

        # Now actual invalid (fresh engine)
        e2 = self._engine()
        e2.set_active_candidate("cand_0")
        bad = make_candidate("cand_0", geom=GeometricValidity.INVALID)
        cs_bad = make_candidate_set([bad])
        r_inv = make_risk("cand_0", is_geom_invalid=True, total_risk=0.0)
        rs_inv = make_risk_set([r_inv])
        result_inv = e2.evaluate(1, rs_inv, cs_bad, ps, timestamp=_T0 + 1)
        assert ReplanningReasonCode.PATH_GEOMETRY_INVALID in result_inv.request.reason_codes
        # Both trigger replan but different reasons
        assert result_risk.request.reason_codes != result_inv.request.reason_codes

    def test_no_active_path_returns_unknown(self):
        e = self._engine()
        # No set_active_candidate call
        rs = make_risk_set()
        ps = make_planning_space()
        cs = make_candidate_set()
        result = e.evaluate(1, rs, cs, ps, timestamp=_T0 + 1)
        assert result.request.decision == ReplanningDecision.UNKNOWN

    def test_planning_not_allowed_blocks_replan(self):
        e = self._engine()
        e.set_active_candidate("cand_0")
        r = make_risk("cand_0", total_risk=0.15)
        rs = make_risk_set([r])
        ps = make_planning_space(planning_allowed=False, gate_state="HIGH_ALERT")
        cs = make_candidate_set(planning_allowed=False, sg_state="HIGH_ALERT")
        # Safety gate not allowed → REPLAN_BLOCKED (gate must never be overridden)
        result = e.evaluate(1, rs, cs, ps, timestamp=_T0 + 1)
        assert result.request.decision == ReplanningDecision.REPLAN_BLOCKED

    def test_stale_path_triggers_stale_reason(self):
        e = self._engine(max_active_path_age_s=1.0)
        e.set_active_candidate("cand_0")
        # Evaluate once to set path
        e.evaluate(1, None, None, None, timestamp=_T0 + 0.0)
        # Far future — path is stale
        result = e.evaluate(2, None, None, None, timestamp=_T0 + 10.0)
        assert ReplanningReasonCode.STALE_PLANNING_STATE in result.request.reason_codes

    def test_invalid_urgency_always_critical(self):
        e = self._engine()
        e.set_active_candidate("cand_0")
        bad = make_candidate("cand_0", geom=GeometricValidity.INVALID)
        cs = make_candidate_set([bad])
        r = make_risk("cand_0", is_geom_invalid=True)
        rs = make_risk_set([r])
        ps = make_planning_space()
        result = e.evaluate(1, rs, cs, ps, timestamp=_T0 + 1)
        assert result.request.urgency == ReplanningUrgency.CRITICAL
