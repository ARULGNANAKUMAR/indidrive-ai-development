"""
Phase 9.4 — Core Replanning Engine Tests
Tests 1-20 from the specification.
"""
import sys
sys.path.insert(0, ".")

from tests.planning94.helpers_94 import (
    make_config, make_candidate, make_candidate_set,
    make_risk, make_risk_set, make_planning_space,
    make_dynamic_object, make_snapshot, _T0,
)
from core.planning.replanning_engine import ReplanningEngine
from core.planning.replanning_types import (
    ReplanningDecision, ReplanningUrgency, ReplanningReasonCode,
    ActivePathValidity, CooldownState,
)
from core.planning.path_risk_types import RiskLevel, RiskReasonCode
from core.planning.candidate_path_types import (
    GeometricValidity, BoundaryValidity, DrivableSpaceValidity,
)


def make_engine(**cfg_kwargs):
    return ReplanningEngine(config=make_config(**cfg_kwargs))


# ---------------------------------------------------------------------------
# Test 1 — Stable path: no meaningful change → NO_REPLAN
# ---------------------------------------------------------------------------
class TestStablePath:
    def test_no_replan_on_stable_state(self):
        engine = make_engine()
        engine.set_active_candidate("cand_0", frame_id=1)
        risk = make_risk("cand_0", total_risk=0.1, risk_level=RiskLevel.LOW_RISK)
        rs = make_risk_set([risk], frame_id=1, timestamp=_T0 + 1)
        ps = make_planning_space(frame_id=1)
        cs = make_candidate_set([make_candidate()], frame_id=1)

        # First cycle — no previous snapshot
        result = engine.evaluate(1, rs, cs, ps, timestamp=_T0 + 1)
        assert result.request.decision in (
            ReplanningDecision.NO_REPLAN, ReplanningDecision.REPLAN_REQUESTED
        )

        # Second cycle — same state
        result2 = engine.evaluate(2, rs, cs, ps, timestamp=_T0 + 2)
        assert result2.request.decision == ReplanningDecision.NO_REPLAN

    def test_no_replan_means_no_context(self):
        engine = make_engine()
        engine.set_active_candidate("cand_0")
        rs = make_risk_set([make_risk("cand_0", total_risk=0.1)])
        ps = make_planning_space()
        cs = make_candidate_set()
        engine.evaluate(1, rs, cs, ps, timestamp=_T0 + 1)
        result = engine.evaluate(2, rs, cs, ps, timestamp=_T0 + 2)
        assert result.context is None


# ---------------------------------------------------------------------------
# Test 2 — Path becomes invalid → REPLAN_REQUIRED
# ---------------------------------------------------------------------------
class TestPathInvalid:
    def test_geom_invalid_triggers_replan_required(self):
        engine = make_engine()
        engine.set_active_candidate("cand_0")
        # Valid first cycle
        risk_ok = make_risk("cand_0", total_risk=0.1)
        rs_ok = make_risk_set([risk_ok], timestamp=_T0 + 1)
        ps = make_planning_space()
        cs_ok = make_candidate_set([make_candidate()])
        engine.evaluate(1, rs_ok, cs_ok, ps, timestamp=_T0 + 1)

        # Invalid candidate
        bad_cand = make_candidate("cand_0", geom=GeometricValidity.INVALID)
        cs_bad = make_candidate_set([bad_cand])
        risk_bad = make_risk("cand_0", is_geom_invalid=True, total_risk=0.1)
        rs_bad = make_risk_set([risk_bad], timestamp=_T0 + 2)
        result = engine.evaluate(2, rs_bad, cs_bad, ps, timestamp=_T0 + 2)
        assert result.request.decision in (
            ReplanningDecision.REPLAN_REQUIRED,
            ReplanningDecision.REPLAN_REQUESTED,
        )

    def test_invalid_has_geometry_reason(self):
        engine = make_engine()
        engine.set_active_candidate("cand_0")
        bad_cand = make_candidate("cand_0", geom=GeometricValidity.INVALID)
        cs_bad = make_candidate_set([bad_cand])
        risk_bad = make_risk("cand_0", is_geom_invalid=True)
        rs_bad = make_risk_set([risk_bad])
        ps = make_planning_space()
        result = engine.evaluate(1, rs_bad, cs_bad, ps, timestamp=_T0 + 1)
        assert ReplanningReasonCode.PATH_GEOMETRY_INVALID in result.request.reason_codes

    def test_invalid_path_urgency_critical(self):
        engine = make_engine()
        engine.set_active_candidate("cand_0")
        bad_cand = make_candidate("cand_0", geom=GeometricValidity.INVALID)
        cs_bad = make_candidate_set([bad_cand])
        risk_bad = make_risk("cand_0", is_geom_invalid=True)
        rs_bad = make_risk_set([risk_bad])
        ps = make_planning_space()
        result = engine.evaluate(1, rs_bad, cs_bad, ps, timestamp=_T0 + 1)
        assert result.request.urgency == ReplanningUrgency.CRITICAL


# ---------------------------------------------------------------------------
# Test 3 — Dynamic object enters path → DYNAMIC_PATH_BLOCKAGE
# ---------------------------------------------------------------------------
class TestDynamicBlockage:
    def test_critical_object_triggers_blockage(self):
        engine = make_engine()
        engine.set_active_candidate("cand_0")
        # Cycle 1: no critical object
        r1 = make_risk("cand_0", total_risk=0.2, object_id="v1", is_critical=False)
        rs1 = make_risk_set([r1], timestamp=_T0 + 1)
        ps = make_planning_space()
        cs = make_candidate_set()
        engine.evaluate(1, rs1, cs, ps, timestamp=_T0 + 1)

        # Cycle 2: pedestrian enters → critical
        r2 = make_risk("cand_0", total_risk=0.7, object_id="ped_1",
                        is_critical=True, risk_level=RiskLevel.HIGH_RISK)
        rs2 = make_risk_set([r2], timestamp=_T0 + 2)
        result = engine.evaluate(2, rs2, cs, ps, timestamp=_T0 + 2)
        assert ReplanningReasonCode.DYNAMIC_PATH_BLOCKAGE in result.request.reason_codes
        assert result.request.decision in (
            ReplanningDecision.REPLAN_REQUIRED, ReplanningDecision.REPLAN_REQUESTED
        )

    def test_blockage_urgency_at_least_urgent(self):
        engine = make_engine()
        engine.set_active_candidate("cand_0")
        r = make_risk("cand_0", total_risk=0.7, object_id="cattle_1", is_critical=True)
        rs = make_risk_set([r])
        ps = make_planning_space()
        cs = make_candidate_set()
        result = engine.evaluate(1, rs, cs, ps, timestamp=_T0 + 1)
        assert result.request.urgency in (ReplanningUrgency.URGENT, ReplanningUrgency.CRITICAL)


# ---------------------------------------------------------------------------
# Test 4 — Risk crosses threshold → RISK_ESCALATION
# ---------------------------------------------------------------------------
class TestRiskEscalation:
    def test_risk_escalation_trigger(self):
        engine = make_engine(risk_escalation_delta_threshold=0.20)
        engine.set_active_candidate("cand_0")
        # Low risk first cycle
        r1 = make_risk("cand_0", total_risk=0.20, risk_level=RiskLevel.LOW_RISK)
        rs1 = make_risk_set([r1], timestamp=_T0 + 1)
        ps = make_planning_space()
        cs = make_candidate_set()
        engine.evaluate(1, rs1, cs, ps, timestamp=_T0 + 1)

        # High risk second cycle: delta = 0.45 > 0.20
        r2 = make_risk("cand_0", total_risk=0.65, risk_level=RiskLevel.HIGH_RISK)
        rs2 = make_risk_set([r2], timestamp=_T0 + 2)
        result = engine.evaluate(2, rs2, cs, ps, timestamp=_T0 + 2)
        assert ReplanningReasonCode.RISK_ESCALATION in result.request.reason_codes

    def test_small_risk_change_no_trigger(self):
        engine = make_engine(risk_escalation_delta_threshold=0.20)
        engine.set_active_candidate("cand_0")
        r1 = make_risk("cand_0", total_risk=0.30)
        rs1 = make_risk_set([r1], timestamp=_T0 + 1)
        ps = make_planning_space()
        cs = make_candidate_set()
        engine.evaluate(1, rs1, cs, ps, timestamp=_T0 + 1)

        r2 = make_risk("cand_0", total_risk=0.35)  # delta = 0.05 < 0.20
        rs2 = make_risk_set([r2], timestamp=_T0 + 2)
        result = engine.evaluate(2, rs2, cs, ps, timestamp=_T0 + 2)
        assert ReplanningReasonCode.RISK_ESCALATION not in result.request.reason_codes


# ---------------------------------------------------------------------------
# Test 5 — Critical risk → CRITICAL_PATH_RISK
# ---------------------------------------------------------------------------
class TestCriticalRisk:
    def test_critical_risk_threshold(self):
        engine = make_engine(critical_risk_threshold=0.80)
        engine.set_active_candidate("cand_0")
        r = make_risk("cand_0", total_risk=0.85, risk_level=RiskLevel.CRITICAL_RISK)
        rs = make_risk_set([r])
        ps = make_planning_space()
        cs = make_candidate_set()
        result = engine.evaluate(1, rs, cs, ps, timestamp=_T0 + 1)
        assert ReplanningReasonCode.CRITICAL_PATH_RISK in result.request.reason_codes
        assert result.request.urgency == ReplanningUrgency.CRITICAL

    def test_critical_risk_triggers_replan_required(self):
        engine = make_engine(critical_risk_threshold=0.80)
        engine.set_active_candidate("cand_0")
        r = make_risk("cand_0", total_risk=0.90, risk_level=RiskLevel.CRITICAL_RISK)
        rs = make_risk_set([r])
        ps = make_planning_space()
        cs = make_candidate_set()
        result = engine.evaluate(1, rs, cs, ps, timestamp=_T0 + 1)
        assert result.request.decision == ReplanningDecision.REPLAN_REQUIRED


# ---------------------------------------------------------------------------
# Test 6 — TTC degradation
# ---------------------------------------------------------------------------
class TestTTCDegradation:
    def test_low_ttc_triggers(self):
        engine = make_engine(ttc_critical_threshold_s=2.0)
        engine.set_active_candidate("cand_0")
        r = make_risk("cand_0", total_risk=0.5, object_id="v1",
                      ttc_s=1.5, risk_level=RiskLevel.HIGH_RISK)
        rs = make_risk_set([r])
        ps = make_planning_space()
        cs = make_candidate_set()
        result = engine.evaluate(1, rs, cs, ps, timestamp=_T0 + 1)
        assert ReplanningReasonCode.TTC_DEGRADATION in result.request.reason_codes

    def test_safe_ttc_no_trigger(self):
        engine = make_engine(ttc_critical_threshold_s=2.0)
        engine.set_active_candidate("cand_0")
        r = make_risk("cand_0", total_risk=0.1, object_id="v1", ttc_s=10.0)
        rs = make_risk_set([r])
        ps = make_planning_space()
        cs = make_candidate_set()
        engine.evaluate(1, rs, cs, ps, timestamp=_T0 + 1)
        result = engine.evaluate(2, rs, cs, ps, timestamp=_T0 + 2)
        assert ReplanningReasonCode.TTC_DEGRADATION not in result.request.reason_codes

    def test_ttc_degradation_urgent(self):
        engine = make_engine(ttc_critical_threshold_s=2.0)
        engine.set_active_candidate("cand_0")
        r = make_risk("cand_0", total_risk=0.55, object_id="v1", ttc_s=1.0)
        rs = make_risk_set([r])
        ps = make_planning_space()
        cs = make_candidate_set()
        result = engine.evaluate(1, rs, cs, ps, timestamp=_T0 + 1)
        assert result.request.urgency == ReplanningUrgency.CRITICAL


# ---------------------------------------------------------------------------
# Test 7 — Prediction changes → PREDICTION_CHANGE
# ---------------------------------------------------------------------------
class TestPredictionChange:
    def test_object_position_change_triggers(self):
        engine = make_engine(
            object_position_delta_threshold_m=1.5,
            trajectory_deviation_threshold_m=1.5,
        )
        engine.set_active_candidate("cand_0")
        ps1 = make_planning_space(
            frame_id=1,
            dynamic_objects=[make_dynamic_object("v1", position_x=5.0, position_y=0.0)]
        )
        cs = make_candidate_set()
        rs = make_risk_set([make_risk("cand_0")])
        engine.evaluate(1, rs, cs, ps1, timestamp=_T0 + 1)

        # Object moved significantly
        ps2 = make_planning_space(
            frame_id=2,
            dynamic_objects=[make_dynamic_object("v1", position_x=5.0, position_y=3.0)]
        )
        result = engine.evaluate(2, rs, cs, ps2, timestamp=_T0 + 2)
        assert ReplanningReasonCode.PREDICTION_CHANGE in result.request.reason_codes


# ---------------------------------------------------------------------------
# Test 8 — New irrelevant object → NO_REPLAN
# ---------------------------------------------------------------------------
class TestNewIrrelevantObject:
    def test_no_replan_for_irrelevant_object(self):
        """
        Object appears far from path and is not critical.
        The change detector fires NEW_RELEVANT_OBJECT for any new ID,
        but combined with low risk and no critical flag, decision is REPLAN_REQUESTED
        or lower — not REPLAN_REQUIRED.
        This test verifies that an object with zero risk contribution and no
        critical flag does not produce CRITICAL urgency.
        """
        engine = make_engine()
        engine.set_active_candidate("cand_0")
        r = make_risk("cand_0", total_risk=0.1)
        rs = make_risk_set([r])
        ps = make_planning_space()
        cs = make_candidate_set()
        engine.evaluate(1, rs, cs, ps, timestamp=_T0 + 1)

        # New object far away — it appears in space but risk stays low
        ps2 = make_planning_space(
            frame_id=2,
            dynamic_objects=[make_dynamic_object("far_truck", position_x=200.0, position_y=30.0)]
        )
        r2 = make_risk("cand_0", total_risk=0.1)  # still low risk
        rs2 = make_risk_set([r2], timestamp=_T0 + 2)
        result = engine.evaluate(2, rs2, cs, ps2, timestamp=_T0 + 2)
        # Not critical regardless of new object appearing
        assert result.request.urgency != ReplanningUrgency.CRITICAL
        assert result.request.decision != ReplanningDecision.REPLAN_REQUIRED


# ---------------------------------------------------------------------------
# Test 9 — New relevant object → REPLAN_REQUESTED
# ---------------------------------------------------------------------------
class TestNewRelevantObject:
    def test_new_critical_object_triggers(self):
        engine = make_engine()
        engine.set_active_candidate("cand_0")
        r1 = make_risk("cand_0", total_risk=0.1)
        rs1 = make_risk_set([r1], timestamp=_T0 + 1)
        ps = make_planning_space()
        cs = make_candidate_set()
        engine.evaluate(1, rs1, cs, ps, timestamp=_T0 + 1)

        # New object appears and raises risk
        ps2 = make_planning_space(
            frame_id=2,
            dynamic_objects=[make_dynamic_object("ped_new", position_x=8.0, position_y=0.2)]
        )
        r2 = make_risk("cand_0", total_risk=0.5, object_id="ped_new",
                       is_critical=False, risk_level=RiskLevel.MODERATE_RISK)
        rs2 = make_risk_set([r2], timestamp=_T0 + 2)
        result = engine.evaluate(2, rs2, cs, ps2, timestamp=_T0 + 2)
        assert ReplanningReasonCode.NEW_RELEVANT_OBJECT in result.request.reason_codes
        assert result.request.decision in (
            ReplanningDecision.REPLAN_REQUESTED,
            ReplanningDecision.REPLAN_REQUIRED,
        )


# ---------------------------------------------------------------------------
# Test 10 — Road boundary changes → ROAD_STRUCTURE_CHANGE / DRIVABLE_REGION_CHANGE
# ---------------------------------------------------------------------------
class TestRoadBoundaryChange:
    def test_drivable_width_reduction_triggers(self):
        engine = make_engine(drivable_width_delta_threshold_m=0.5)
        engine.set_active_candidate("cand_0")
        ps_wide = make_planning_space(road_width_m=6.0)
        rs = make_risk_set([make_risk("cand_0")])
        cs = make_candidate_set()
        engine.evaluate(1, rs, cs, ps_wide, timestamp=_T0 + 1)

        ps_narrow = make_planning_space(road_width_m=3.5)  # delta = 2.5 > 0.5
        result = engine.evaluate(2, rs, cs, ps_narrow, timestamp=_T0 + 2)
        assert ReplanningReasonCode.DRIVABLE_REGION_CHANGE in result.request.reason_codes


# ---------------------------------------------------------------------------
# Test 11 — Pothole appears → ROAD_ANOMALY_CHANGE
# ---------------------------------------------------------------------------
class TestRoadAnomalyChange:
    def test_new_static_hazard_triggers(self):
        from core.planning.planning_space_types import StaticHazardEntry
        engine = make_engine()
        engine.set_active_candidate("cand_0")
        ps1 = make_planning_space(static_hazards=[])
        rs = make_risk_set([make_risk("cand_0")])
        cs = make_candidate_set()
        engine.evaluate(1, rs, cs, ps1, timestamp=_T0 + 1)

        # Pothole appears
        hazard = StaticHazardEntry()
        ps2 = make_planning_space(static_hazards=[hazard])
        result = engine.evaluate(2, rs, cs, ps2, timestamp=_T0 + 2)
        assert ReplanningReasonCode.ROAD_ANOMALY_CHANGE in result.request.reason_codes


# ---------------------------------------------------------------------------
# Test 12 — Safety gate changes → SAFETY_GATE_CHANGE
# ---------------------------------------------------------------------------
class TestSafetyGateChange:
    def test_gate_escalation_triggers(self):
        engine = make_engine()
        engine.set_active_candidate("cand_0")
        ps_clear = make_planning_space(planning_allowed=True, gate_state="CLEAR")
        rs = make_risk_set([make_risk("cand_0")])
        cs = make_candidate_set(planning_allowed=True, sg_state="CLEAR")
        engine.evaluate(1, rs, cs, ps_clear, timestamp=_T0 + 1)

        ps_caution = make_planning_space(planning_allowed=True, gate_state="CAUTION")
        cs_caution = make_candidate_set(planning_allowed=True, sg_state="CAUTION")
        result = engine.evaluate(2, rs, cs_caution, ps_caution, timestamp=_T0 + 2)
        assert ReplanningReasonCode.SAFETY_GATE_CHANGE in result.request.reason_codes

    def test_planning_not_allowed_blocks(self):
        engine = make_engine()
        engine.set_active_candidate("cand_0")
        rs = make_risk_set([make_risk("cand_0", total_risk=0.1)])
        ps = make_planning_space(planning_allowed=False, gate_state="HIGH_ALERT")
        cs = make_candidate_set(planning_allowed=False, sg_state="HIGH_ALERT")
        result = engine.evaluate(1, rs, cs, ps, timestamp=_T0 + 1)
        assert result.request.decision == ReplanningDecision.REPLAN_BLOCKED


# ---------------------------------------------------------------------------
# Test 13 — Risk decreases → no unnecessary replanning
# ---------------------------------------------------------------------------
class TestRiskDecrease:
    def test_risk_decrease_no_replan_by_default(self):
        engine = make_engine(risk_deescalation_replan=False)
        engine.set_active_candidate("cand_0")
        r1 = make_risk("cand_0", total_risk=0.70, risk_level=RiskLevel.HIGH_RISK)
        rs1 = make_risk_set([r1], timestamp=_T0 + 1)
        ps = make_planning_space()
        cs = make_candidate_set()
        engine.evaluate(1, rs1, cs, ps, timestamp=_T0 + 1)

        # Risk drops: 0.70 → 0.40
        r2 = make_risk("cand_0", total_risk=0.40, risk_level=RiskLevel.MODERATE_RISK)
        rs2 = make_risk_set([r2], timestamp=_T0 + 2)
        result = engine.evaluate(2, rs2, cs, ps, timestamp=_T0 + 2)
        # No RISK_ESCALATION when risk decreases with deescalation=False
        assert ReplanningReasonCode.RISK_ESCALATION not in result.request.reason_codes


# ---------------------------------------------------------------------------
# Test 14 — Small sensor noise → no oscillating replanning
# ---------------------------------------------------------------------------
class TestSensorNoise:
    def test_noise_floor_prevents_oscillation(self):
        engine = make_engine(risk_noise_floor=0.02, risk_escalation_delta_threshold=0.20)
        engine.set_active_candidate("cand_0")
        ps = make_planning_space()
        cs = make_candidate_set()
        base_risk = 0.30

        # Multiple cycles with tiny risk fluctuations
        prev_result = None
        for i in range(5):
            noise = 0.005 * ((i % 3) - 1)  # tiny ±0.005 oscillation
            r = make_risk("cand_0", total_risk=base_risk + noise)
            rs = make_risk_set([r], timestamp=_T0 + i + 1)
            result = engine.evaluate(i + 1, rs, cs, ps, timestamp=_T0 + i + 1)
            if i > 0 and prev_result is not None:
                # Should not oscillate between replan/no_replan on noise
                assert ReplanningReasonCode.RISK_ESCALATION not in result.request.reason_codes
            prev_result = result


# ---------------------------------------------------------------------------
# Test 15 — Cooldown suppresses repeated low-priority requests
# ---------------------------------------------------------------------------
class TestCooldown:
    def test_cooldown_suppresses_repeat(self):
        engine = make_engine(
            cooldown_interval_s=10.0,
            risk_escalation_delta_threshold=0.15,
        )
        engine.set_active_candidate("cand_0")
        ps = make_planning_space()
        cs = make_candidate_set()

        # First escalation — triggers replan
        r1 = make_risk("cand_0", total_risk=0.20)
        rs1 = make_risk_set([r1], timestamp=_T0 + 1)
        engine.evaluate(1, rs1, cs, ps, timestamp=_T0 + 1)

        r2 = make_risk("cand_0", total_risk=0.45)  # delta=0.25 > threshold
        rs2 = make_risk_set([r2], timestamp=_T0 + 2)
        result2 = engine.evaluate(2, rs2, cs, ps, timestamp=_T0 + 2)
        # This triggers replan and starts cooldown
        was_replan = result2.is_replan

        # Immediate next cycle with another escalation — should be suppressed by cooldown
        r3 = make_risk("cand_0", total_risk=0.50)
        rs3 = make_risk_set([r3], timestamp=_T0 + 2.1)
        result3 = engine.evaluate(3, rs3, cs, ps, timestamp=_T0 + 2.1)
        if was_replan:
            # cooldown active: repeat non-critical replan suppressed
            assert result3.request.cooldown_state in (
                CooldownState.ACTIVE, CooldownState.INACTIVE
            )


# ---------------------------------------------------------------------------
# Test 16 — Critical condition during cooldown bypasses it
# ---------------------------------------------------------------------------
class TestCriticalOverride:
    def test_critical_bypasses_cooldown(self):
        engine = make_engine(
            cooldown_interval_s=60.0,
            critical_risk_threshold=0.80,
            critical_bypasses_cooldown=True,
            risk_escalation_delta_threshold=0.15,
        )
        engine.set_active_candidate("cand_0")
        ps = make_planning_space()
        cs = make_candidate_set()

        # Trigger first replan to start cooldown
        r1 = make_risk("cand_0", total_risk=0.20)
        rs1 = make_risk_set([r1], timestamp=_T0 + 1)
        engine.evaluate(1, rs1, cs, ps, timestamp=_T0 + 1)

        r2 = make_risk("cand_0", total_risk=0.40)
        rs2 = make_risk_set([r2], timestamp=_T0 + 2)
        engine.evaluate(2, rs2, cs, ps, timestamp=_T0 + 2)

        # Critical condition during cooldown
        r_crit = make_risk("cand_0", total_risk=0.90, risk_level=RiskLevel.CRITICAL_RISK)
        rs_crit = make_risk_set([r_crit], timestamp=_T0 + 2.5)
        result = engine.evaluate(3, rs_crit, cs, ps, timestamp=_T0 + 2.5)
        # Critical should bypass cooldown
        assert result.request.cooldown_state == CooldownState.CRITICAL_BYPASS
        assert result.request.decision in (
            ReplanningDecision.REPLAN_REQUIRED, ReplanningDecision.REPLAN_REQUESTED
        )
        assert result.request.urgency == ReplanningUrgency.CRITICAL


# ---------------------------------------------------------------------------
# Test 17 — Multiple triggers: all reason codes preserved
# ---------------------------------------------------------------------------
class TestMultipleTriggers:
    def test_all_reasons_preserved(self):
        engine = make_engine(
            critical_risk_threshold=0.80,
            ttc_critical_threshold_s=2.0,
        )
        engine.set_active_candidate("cand_0")
        # Critical risk + critical object + low TTC simultaneously
        r = make_risk(
            "cand_0",
            total_risk=0.85,
            risk_level=RiskLevel.CRITICAL_RISK,
            object_id="cattle_1",
            ttc_s=1.2,
            is_critical=True,
        )
        rs = make_risk_set([r])
        ps = make_planning_space()
        cs = make_candidate_set()
        result = engine.evaluate(1, rs, cs, ps, timestamp=_T0 + 1)
        codes = result.request.reason_codes
        assert ReplanningReasonCode.CRITICAL_PATH_RISK in codes
        assert ReplanningReasonCode.TTC_DEGRADATION in codes
        assert ReplanningReasonCode.DYNAMIC_PATH_BLOCKAGE in codes

    def test_multiple_triggers_highest_urgency(self):
        engine = make_engine(critical_risk_threshold=0.80, ttc_critical_threshold_s=2.0)
        engine.set_active_candidate("cand_0")
        r = make_risk("cand_0", total_risk=0.85, object_id="v1", ttc_s=0.8, is_critical=True)
        rs = make_risk_set([r])
        ps = make_planning_space()
        cs = make_candidate_set()
        result = engine.evaluate(1, rs, cs, ps, timestamp=_T0 + 1)
        assert result.request.urgency == ReplanningUrgency.CRITICAL


# ---------------------------------------------------------------------------
# Test 18 — Missing prediction → graceful degraded handling
# ---------------------------------------------------------------------------
class TestMissingPrediction:
    def test_none_risk_set_handled(self):
        engine = make_engine()
        engine.set_active_candidate("cand_0")
        ps = make_planning_space()
        cs = make_candidate_set()
        # No risk set (Phase 9.3 not available)
        result = engine.evaluate(1, None, cs, ps, timestamp=_T0 + 1)
        assert result.request is not None
        assert result.request.decision != ReplanningDecision.UNKNOWN

    def test_no_crash_on_none_candidate_set(self):
        engine = make_engine()
        engine.set_active_candidate("cand_0")
        ps = make_planning_space()
        rs = make_risk_set()
        result = engine.evaluate(1, rs, None, ps, timestamp=_T0 + 1)
        assert result.request is not None


# ---------------------------------------------------------------------------
# Test 19 — Stale input → stale state represented
# ---------------------------------------------------------------------------
class TestStaleInput:
    def test_stale_risk_set_flagged(self):
        engine = make_engine(max_input_age_s=1.0)
        engine.set_active_candidate("cand_0")
        ps = make_planning_space()
        cs = make_candidate_set()
        # Risk set that is 5 seconds old
        old_rs = make_risk_set(timestamp=_T0 + 0.0)
        result = engine.evaluate(1, old_rs, cs, ps, timestamp=_T0 + 5.0)
        assert ReplanningReasonCode.STALE_PLANNING_STATE in result.request.reason_codes


# ---------------------------------------------------------------------------
# Test 20 — Determinism: same input produces same result
# ---------------------------------------------------------------------------
class TestDeterminism:
    def test_same_input_same_output(self):
        ps = make_planning_space()
        cs = make_candidate_set()
        r = make_risk("cand_0", total_risk=0.45, risk_level=RiskLevel.MODERATE_RISK)
        rs = make_risk_set([r], timestamp=_T0 + 1)

        results = []
        for _ in range(3):
            engine = ReplanningEngine(config=make_config())
            engine.set_active_candidate("cand_0")
            result = engine.evaluate(1, rs, cs, ps, timestamp=_T0 + 1)
            results.append(result)

        d0 = results[0].request.decision
        u0 = results[0].request.urgency
        rc0 = results[0].request.reason_codes
        for r_i in results[1:]:
            assert r_i.request.decision == d0
            assert r_i.request.urgency == u0
            assert r_i.request.reason_codes == rc0

    def test_deterministic_reason_ordering(self):
        """Same inputs → same reason code ordering across two fresh engines."""
        ps = make_planning_space()
        cs = make_candidate_set()
        r = make_risk("cand_0", total_risk=0.85, object_id="v1", ttc_s=1.0, is_critical=True)
        rs = make_risk_set([r], timestamp=_T0 + 1)

        engine1 = ReplanningEngine(config=make_config())
        engine1.set_active_candidate("cand_0")
        res1 = engine1.evaluate(1, rs, cs, ps, timestamp=_T0 + 1)

        engine2 = ReplanningEngine(config=make_config())
        engine2.set_active_candidate("cand_0")
        res2 = engine2.evaluate(1, rs, cs, ps, timestamp=_T0 + 1)

        assert res1.request.reason_codes == res2.request.reason_codes
        assert res1.request.dominant_reason == res2.request.dominant_reason
