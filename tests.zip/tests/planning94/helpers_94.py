"""
Shared test helpers for Phase 9.4 tests.
Builds minimal stub objects for testing the replanning engine
without depending on the full pipeline.
"""
from __future__ import annotations

import time
from typing import List, Optional, Tuple

from core.planning.replanning_types import (
    NOT_AVAILABLE,
    ActivePath,
    ActivePathValidity,
    PlanningStateSnapshot,
    ReplanningReasonCode,
    ReplanningUrgency,
    ReplanningDecision,
    REPLANNING_SCHEMA_VERSION,
)
from core.planning.replanning_config import ReplanningConfig
from core.planning.path_risk_types import (
    CandidatePathRisk,
    PathRiskSet,
    PathRiskStatus,
    RiskLevel,
    RiskBreakdown,
    ObjectRiskContribution,
    RiskReasonCode,
)
from core.planning.candidate_path_types import (
    CandidatePath,
    CandidatePathSet,
    CandidateGenerationStatus,
    CandidateMetadata,
    GeometricValidity,
    BoundaryValidity,
    DrivableSpaceValidity,
    GenerationMethod,
    PathPoint,
)
from core.planning.planning_space_types import (
    PlanningSpace,
    PlanningSpaceStatus,
    SpatialExtent,
    DynamicObjectEntry,
    StaticHazardEntry,
    PlanningHorizon,
    PlanningSpaceQuality,
    PlanningHorizonValidity,
)


_T0 = 1_700_000_000.0  # Deterministic base timestamp


def make_config(**kwargs) -> ReplanningConfig:
    cfg = ReplanningConfig()
    for k, v in kwargs.items():
        setattr(cfg, k, v)
    return cfg


def make_candidate(
    candidate_id: str = "cand_0",
    frame_id: int = 1,
    geom: GeometricValidity = GeometricValidity.VALID,
    boundary: BoundaryValidity = BoundaryValidity.VALID,
    drivable: DrivableSpaceValidity = DrivableSpaceValidity.VALID,
    is_degraded: bool = False,
    lateral_offset_m: float = 0.0,
    length_m: float = 30.0,
) -> CandidatePath:
    n = max(3, int(length_m / 2))
    waypoints = tuple(
        PathPoint(
            x=float(i * 2),
            y=lateral_offset_m,
            z=0.0,
            longitudinal_s=float(i * 2),
            lateral_offset_m=lateral_offset_m,
        )
        for i in range(n)
    )
    meta = CandidateMetadata(
        candidate_index=0,
        generation_timestamp=_T0,
        path_length_m=length_m,
        waypoint_count=n,
        nominal_lateral_offset_m=lateral_offset_m,
        is_degraded=is_degraded,
    )
    return CandidatePath(
        candidate_id=candidate_id,
        frame_id=frame_id,
        timestamp=_T0,
        coordinate_frame="VEHICLE",
        _waypoints=waypoints,
        longitudinal_extent_m=length_m,
        lateral_offset_m=lateral_offset_m,
        generation_method=GenerationMethod.CENTER,
        source_reference="space_001",
        geometric_validity=geom,
        boundary_validity=boundary,
        drivable_space_validity=drivable,
        metadata=meta,
    )


def make_candidate_set(
    candidates: Optional[List[CandidatePath]] = None,
    frame_id: int = 1,
    planning_allowed: bool = True,
    sg_state: str = "CLEAR",
) -> CandidatePathSet:
    if candidates is None:
        candidates = [make_candidate()]
    return CandidatePathSet(
        set_id=f"cset_{frame_id:04d}",
        frame_id=frame_id,
        timestamp=_T0 + frame_id,
        coordinate_frame="VEHICLE",
        planning_space_ref="space_001",
        safety_gate_state=sg_state,
        planning_allowed=planning_allowed,
        _candidates=tuple(candidates),
        generation_status=CandidateGenerationStatus.CANDIDATES_GENERATED,
        generation_reason="",
    )


def make_risk(
    candidate_id: str = "cand_0",
    frame_id: int = 1,
    total_risk: float = 0.1,
    risk_level: RiskLevel = RiskLevel.LOW_RISK,
    is_geom_invalid: bool = False,
    degraded: bool = False,
    ttc_s: Optional[float] = None,
    is_critical: bool = False,
    object_id: Optional[str] = None,
    reason_codes: Tuple[RiskReasonCode, ...] = (),
) -> CandidatePathRisk:
    contributions: Tuple[ObjectRiskContribution, ...] = ()
    affected: Tuple[str, ...] = ()
    if object_id is not None:
        oc = ObjectRiskContribution(
            object_id=object_id,
            object_type="VEHICLE",
            combined_object_risk=total_risk,
            ttc_s=ttc_s,
            ttc_status="AVAILABLE" if ttc_s is not None else "UNAVAILABLE",
            is_critical=is_critical,
        )
        contributions = (oc,)
        affected = (object_id,)
    return CandidatePathRisk(
        candidate_id=candidate_id,
        frame_id=frame_id,
        timestamp=_T0 + frame_id,
        coordinate_frame="VEHICLE",
        total_risk=total_risk,
        risk_level=risk_level,
        breakdown=RiskBreakdown(),
        dynamic_object_count=1 if object_id else 0,
        critical_object_count=1 if is_critical else 0,
        object_contributions=contributions,
        affected_object_ids=affected,
        dominant_risk_reason=NOT_AVAILABLE,
        reason_codes=reason_codes,
        confidence=0.9,
        uncertainty=0.1,
        degraded=degraded,
        is_geometrically_invalid=is_geom_invalid,
    )


def make_risk_set(
    risks: Optional[List[CandidatePathRisk]] = None,
    frame_id: int = 1,
    timestamp: Optional[float] = None,
) -> PathRiskSet:
    if risks is None:
        risks = [make_risk()]
    ts = timestamp if timestamp is not None else (_T0 + frame_id)
    return PathRiskSet(
        set_id=f"rset_{frame_id:04d}",
        frame_id=frame_id,
        timestamp=ts,
        coordinate_frame="VEHICLE",
        status=PathRiskStatus.EVALUATED,
        status_reason="",
        _risks=tuple(risks),
    )


def make_dynamic_object(
    object_id: str = "obj_1",
    position_x: float = 10.0,
    position_y: float = 0.5,
    velocity_x: float = 5.0,
    velocity_y: float = 0.0,
) -> DynamicObjectEntry:
    """Create a minimal DynamicObjectEntry stub using actual field names."""
    obj = DynamicObjectEntry()
    obj.object_id = object_id
    obj.position_x = position_x
    obj.position_y = position_y
    obj.velocity_x = velocity_x
    obj.velocity_y = velocity_y
    return obj


def make_planning_space(
    frame_id: int = 1,
    planning_allowed: bool = True,
    gate_state: str = "CLEAR",
    road_width_m: float = 6.0,
    dynamic_objects: Optional[list] = None,
    static_hazards: Optional[list] = None,
) -> PlanningSpace:
    """Build a minimal PlanningSpace for testing.

    PlanningSpace carries safety_gate_state and planning_allowed directly.
    SpatialExtent uses road_width_m, not drivable_width_m.
    """
    se = SpatialExtent()
    se.road_width_m = road_width_m

    horizon = PlanningHorizon(
        longitudinal_m=40.0,
        lateral_extent_m=3.0,
        validity=PlanningHorizonValidity.VALID,
    )
    quality = PlanningSpaceQuality()
    ps = PlanningSpace(
        space_id=f"space_{frame_id:04d}",
        frame_id=frame_id,
        timestamp=_T0 + frame_id,
        coordinate_frame="VEHICLE",
        status=PlanningSpaceStatus.OK,
        horizon=horizon,
        spatial_extent=se,
        quality=quality,
        safety_gate_state=gate_state,
        planning_allowed=planning_allowed,
        _dynamic_objects=tuple(dynamic_objects or []),
        _static_hazards=tuple(static_hazards or []),
    )
    return ps


def make_snapshot(
    frame_id: int = 1,
    risk_score: float = 0.1,
    risk_level: str = "LOW_RISK",
    ttc_s: Optional[float] = None,
    object_ids: Tuple[str, ...] = (),
    object_positions: Tuple = (),
    object_velocities: Tuple = (),
    safety_gate_state: str = "CLEAR",
    planning_allowed: bool = True,
    drivable_width_m: float = 6.0,
    has_road_anomaly: bool = False,
    uncertainty: float = 0.1,
    candidate_id: str = "cand_0",
) -> PlanningStateSnapshot:
    return PlanningStateSnapshot(
        frame_id=frame_id,
        timestamp=_T0 + frame_id,
        active_candidate_id=candidate_id,
        risk_score=risk_score,
        risk_level=risk_level,
        ttc_s=ttc_s,
        object_ids=object_ids,
        object_positions=object_positions,
        object_velocities=object_velocities,
        safety_gate_state=safety_gate_state,
        planning_allowed=planning_allowed,
        drivable_width_m=drivable_width_m,
        has_road_anomaly=has_road_anomaly,
        uncertainty=uncertainty,
    )
