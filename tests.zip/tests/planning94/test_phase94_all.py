"""
Phase 9.4 — Remaining Test Modules
Covers:
  test_hysteresis.py
  test_cooldown.py
  test_critical_override.py
  test_replanning_context.py
  test_phase92_integration.py
  test_phase93_integration.py
  test_indian_road_replanning.py
  test_degraded_inputs.py
  test_stale_inputs.py
  test_determinism.py
  test_validation.py
  test_phase94_scope.py
  test_multi_trigger.py
  test_object_relevance.py
  test_dynamic_blockage.py
  test_prediction_change.py
  test_ttc_trigger.py
  test_road_change_trigger.py
  test_safety_gate_trigger.py
"""
import sys
sys.path.insert(0, ".")

from tests.planning94.helpers_94 import (
    make_config, make_candidate, make_candidate_set,
    make_risk, make_risk_set, make_planning_space,
    make_dynamic_object, make_snapshot, _T0,
)
from core.planning.replanning_engine import ReplanningEngine
from core.planning.replanning_change_detector import ChangeDetector
from core.planning.replanning_validator import ReplanningValidator
from core.planning.replanning_types import (
    NOT_AVAILABLE,
    ReplanningDecision, ReplanningUrgency, ReplanningReasonCode,
    ActivePathValidity, CooldownState, REPLANNING_SCHEMA_VERSION,
    ReplanningRequest, ReplanningContext, ReplanningDecisionResult,
)
from core.planning.path_risk_types import RiskLevel
from core.planning.candidate_path_types import GeometricValidity
from core.planning.planning_space_types import StaticHazardEntry


def eng(**kw):
    return ReplanningEngine(config=make_config(**kw))


# ===========================================================================
# Hysteresis
# ===========================================================================

class TestHysteresis:
    def test_no_oscillation_around_trigger_threshold(self):
        """Risk oscillates just around escalation threshold — should not flip every cycle."""
        e = eng(
            risk_escalation_delta_threshold=0.30,
            risk_noise_floor=0.02,
            cooldown_interval_s=0.0,
        )
        e.set_active_candidate("cand_0")
        ps = make_planning_space()
        cs = make_candidate_set()

        r_a = make_risk("cand_0", total_risk=0.40)
        rs_a = make_risk_set([r_a], timestamp=_T0 + 1)
        e.evaluate(1, rs_a, cs, ps, timestamp=_T0 + 1)

        escalation_count = 0
        risks = [0.42, 0.40, 0.41, 0.39, 0.43]  # tiny oscillation
        for i, rv in enumerate(risks):
            r = make_risk("cand_0", total_risk=rv)
            rs = make_risk_set([r], timestamp=_T0 + 2 + i)
            result = e.evaluate(2 + i, rs, cs, ps, timestamp=_T0 + 2 + i)
            if ReplanningReasonCode.RISK_ESCALATION in result.request.reason_codes:
                escalation_count += 1

        assert escalation_count == 0, "Tiny noise oscillation should not trigger escalation"

    def test_hysteresis_clear_threshold_prevents_re_trigger(self):
        """High risk drops into hysteresis clear zone — should not immediately re-trigger."""
        e = eng(
            risk_hysteresis_trigger_threshold=0.75,
            risk_hysteresis_clear_threshold=0.65,
            risk_escalation_delta_threshold=0.20,
        )
        e.set_active_candidate("cand_0")
        ps = make_planning_space()
        cs = make_candidate_set()

        # Enter high risk state
        r_high = make_risk("cand_0", total_risk=0.80, risk_level=RiskLevel.CRITICAL_RISK)
        rs_high = make_risk_set([r_high], timestamp=_T0 + 1)
        e.evaluate(1, rs_high, cs, ps, timestamp=_T0 + 1)
        # hysteresis state is now True

        # Risk drops to 0.70 — between clear (0.65) and trigger (0.75)
        r_mid = make_risk("cand_0", total_risk=0.70)
        rs_mid = make_risk_set([r_mid], timestamp=_T0 + 2)
        result = e.evaluate(2, rs_mid, cs, ps, timestamp=_T0 + 2)
        # Still in high_risk_state → URGENT
        assert result.request.urgency in (ReplanningUrgency.URGENT, ReplanningUrgency.CRITICAL)


# ===========================================================================
# Cooldown
# ===========================================================================

class TestCooldownBehaviour:
    def test_cooldown_active_after_replan(self):
        e = eng(
            cooldown_interval_s=10.0,
            risk_escalation_delta_threshold=0.20,
        )
        e.set_active_candidate("cand_0")
        ps = make_planning_space()
        cs = make_candidate_set()

        r1 = make_risk("cand_0", total_risk=0.10)
        rs1 = make_risk_set([r1], timestamp=_T0 + 1)
        e.evaluate(1, rs1, cs, ps, timestamp=_T0 + 1)

        r2 = make_risk("cand_0", total_risk=0.50)
        rs2 = make_risk_set([r2], timestamp=_T0 + 2)
        res_trigger = e.evaluate(2, rs2, cs, ps, timestamp=_T0 + 2)

        if res_trigger.is_replan:
            r3 = make_risk("cand_0", total_risk=0.55)
            rs3 = make_risk_set([r3], timestamp=_T0 + 2.5)
            res_suppressed = e.evaluate(3, rs3, cs, ps, timestamp=_T0 + 2.5)
            assert res_suppressed.request.cooldown_state in (
                CooldownState.ACTIVE, CooldownState.INACTIVE
            )

    def test_cooldown_expires_after_interval(self):
        e = eng(
            cooldown_interval_s=1.0,
            risk_escalation_delta_threshold=0.20,
        )
        e.set_active_candidate("cand_0")
        ps = make_planning_space()
        cs = make_candidate_set()

        r1 = make_risk("cand_0", total_risk=0.10)
        rs1 = make_risk_set([r1], timestamp=_T0 + 1)
        e.evaluate(1, rs1, cs, ps, timestamp=_T0 + 1)

        r2 = make_risk("cand_0", total_risk=0.50)
        rs2 = make_risk_set([r2], timestamp=_T0 + 2)
        e.evaluate(2, rs2, cs, ps, timestamp=_T0 + 2)

        # After cooldown expires (>1 second later)
        r4 = make_risk("cand_0", total_risk=0.50)
        rs4 = make_risk_set([r4], timestamp=_T0 + 5)
        res = e.evaluate(4, rs4, cs, ps, timestamp=_T0 + 5)
        # Cooldown should be inactive
        assert res.request.cooldown_state == CooldownState.INACTIVE


# ===========================================================================
# Critical override
# ===========================================================================

class TestCriticalOverride:
    def test_critical_bypasses_long_cooldown(self):
        e = eng(
            cooldown_interval_s=60.0,
            critical_risk_threshold=0.80,
            critical_bypasses_cooldown=True,
            risk_escalation_delta_threshold=0.15,
        )
        e.set_active_candidate("cand_0")
        ps = make_planning_space()
        cs = make_candidate_set()

        r1 = make_risk("cand_0", total_risk=0.20)
        e.evaluate(1, make_risk_set([r1], timestamp=_T0 + 1), cs, ps, timestamp=_T0 + 1)

        r2 = make_risk("cand_0", total_risk=0.40)
        e.evaluate(2, make_risk_set([r2], timestamp=_T0 + 2), cs, ps, timestamp=_T0 + 2)

        # Critical during cooldown
        r_crit = make_risk("cand_0", total_risk=0.95, risk_level=RiskLevel.CRITICAL_RISK)
        rs_crit = make_risk_set([r_crit], timestamp=_T0 + 2.5)
        result = e.evaluate(3, rs_crit, cs, ps, timestamp=_T0 + 2.5)
        assert result.request.cooldown_state == CooldownState.CRITICAL_BYPASS
        assert result.request.urgency == ReplanningUrgency.CRITICAL

    def test_non_critical_not_bypassed(self):
        e = eng(
            cooldown_interval_s=60.0,
            critical_risk_threshold=0.80,
            critical_bypasses_cooldown=True,
            risk_escalation_delta_threshold=0.15,
        )
        e.set_active_candidate("cand_0")
        ps = make_planning_space()
        cs = make_candidate_set()

        r1 = make_risk("cand_0", total_risk=0.20)
        e.evaluate(1, make_risk_set([r1], timestamp=_T0 + 1), cs, ps, timestamp=_T0 + 1)
        r2 = make_risk("cand_0", total_risk=0.40)
        e.evaluate(2, make_risk_set([r2], timestamp=_T0 + 2), cs, ps, timestamp=_T0 + 2)

        # Non-critical during cooldown
        r3 = make_risk("cand_0", total_risk=0.42)
        rs3 = make_risk_set([r3], timestamp=_T0 + 2.5)
        result = e.evaluate(3, rs3, cs, ps, timestamp=_T0 + 2.5)
        assert result.request.cooldown_state in (CooldownState.ACTIVE, CooldownState.INACTIVE)


# ===========================================================================
# Replanning context
# ===========================================================================

class TestReplanningContext:
    def test_context_present_when_replan(self):
        e = eng()
        e.set_active_candidate("cand_0")
        bad = make_candidate("cand_0", geom=GeometricValidity.INVALID)
        cs = make_candidate_set([bad])
        r = make_risk("cand_0", is_geom_invalid=True)
        rs = make_risk_set([r])
        ps = make_planning_space()
        result = e.evaluate(1, rs, cs, ps, timestamp=_T0 + 1)
        assert result.is_replan
        assert result.context is not None

    def test_context_absent_when_no_replan(self):
        e = eng()
        e.set_active_candidate("cand_0")
        r = make_risk("cand_0", total_risk=0.1)
        rs = make_risk_set([r], timestamp=_T0 + 1)
        ps = make_planning_space()
        cs = make_candidate_set()
        e.evaluate(1, rs, cs, ps, timestamp=_T0 + 1)
        result = e.evaluate(2, rs, cs, ps, timestamp=_T0 + 2)
        assert not result.is_replan
        assert result.context is None

    def test_context_links_to_request(self):
        e = eng()
        e.set_active_candidate("cand_0")
        bad = make_candidate("cand_0", geom=GeometricValidity.INVALID)
        cs = make_candidate_set([bad])
        r = make_risk("cand_0", is_geom_invalid=True)
        rs = make_risk_set([r])
        ps = make_planning_space()
        result = e.evaluate(1, rs, cs, ps, timestamp=_T0 + 1)
        assert result.context.request_id == result.request.request_id

    def test_context_contains_active_path_state(self):
        e = eng()
        e.set_active_candidate("cand_0")
        bad = make_candidate("cand_0", geom=GeometricValidity.INVALID)
        cs = make_candidate_set([bad])
        r = make_risk("cand_0", is_geom_invalid=True)
        rs = make_risk_set([r])
        ps = make_planning_space()
        result = e.evaluate(1, rs, cs, ps, timestamp=_T0 + 1)
        assert result.context.active_path_state is not None
        assert result.context.active_path_state.candidate_id == "cand_0"

    def test_context_schema_version(self):
        e = eng()
        e.set_active_candidate("cand_0")
        bad = make_candidate("cand_0", geom=GeometricValidity.INVALID)
        cs = make_candidate_set([bad])
        r = make_risk("cand_0", is_geom_invalid=True)
        rs = make_risk_set([r])
        ps = make_planning_space()
        result = e.evaluate(1, rs, cs, ps, timestamp=_T0 + 1)
        assert result.context.schema_version == REPLANNING_SCHEMA_VERSION

    def test_context_no_forbidden_fields(self):
        e = eng()
        e.set_active_candidate("cand_0")
        bad = make_candidate("cand_0", geom=GeometricValidity.INVALID)
        cs = make_candidate_set([bad])
        r = make_risk("cand_0", is_geom_invalid=True)
        rs = make_risk_set([r])
        ps = make_planning_space()
        result = e.evaluate(1, rs, cs, ps, timestamp=_T0 + 1)
        d = result.context.to_dict()
        forbidden = {"selected_path", "best_path", "steering_angle", "throttle", "brake"}
        assert not (forbidden & set(d.keys()))


# ===========================================================================
# Phase 9.2 integration
# ===========================================================================

class TestPhase92Integration:
    def test_request_candidate_regeneration_calls_generator(self):
        e = eng()
        e.set_active_candidate("cand_0")
        bad = make_candidate("cand_0", geom=GeometricValidity.INVALID)
        cs = make_candidate_set([bad])
        r = make_risk("cand_0", is_geom_invalid=True)
        rs = make_risk_set([r])
        ps = make_planning_space()
        result = e.evaluate(1, rs, cs, ps, timestamp=_T0 + 1)
        assert result.is_replan

        # Stub generator
        class StubGenerator:
            def __init__(self):
                self.called = False
            def generate(self, space):
                self.called = True
                return make_candidate_set()

        gen = StubGenerator()
        new_cs = e.request_candidate_regeneration(result.context, gen, ps)
        assert gen.called
        assert new_cs is not None

    def test_request_candidate_regeneration_none_generator(self):
        e = eng()
        e.set_active_candidate("cand_0")
        bad = make_candidate("cand_0", geom=GeometricValidity.INVALID)
        cs = make_candidate_set([bad])
        r = make_risk("cand_0", is_geom_invalid=True)
        rs = make_risk_set([r])
        ps = make_planning_space()
        result = e.evaluate(1, rs, cs, ps, timestamp=_T0 + 1)
        new_cs = e.request_candidate_regeneration(result.context, None, ps)
        assert new_cs is None

    def test_engine_does_not_generate_paths_itself(self):
        """Phase 9.4 must NOT contain path generation methods."""
        e = eng()
        assert not hasattr(e, "generate_candidate_paths")
        assert not hasattr(e, "generate_trajectories")
        assert not hasattr(e, "generate_path")


# ===========================================================================
# Phase 9.3 integration
# ===========================================================================

class TestPhase93Integration:
    def test_risk_set_consumed_for_risk_score(self):
        e = eng()
        e.set_active_candidate("cand_0")
        r = make_risk("cand_0", total_risk=0.55, risk_level=RiskLevel.HIGH_RISK)
        rs = make_risk_set([r])
        ps = make_planning_space()
        cs = make_candidate_set()
        result = e.evaluate(1, rs, cs, ps, timestamp=_T0 + 1)
        assert abs(result.request.current_risk - 0.55) < 0.005

    def test_critical_object_ids_from_phase93(self):
        e = eng()
        e.set_active_candidate("cand_0")
        r = make_risk("cand_0", total_risk=0.75, object_id="ped_1", is_critical=True)
        rs = make_risk_set([r])
        ps = make_planning_space()
        cs = make_candidate_set()
        result = e.evaluate(1, rs, cs, ps, timestamp=_T0 + 1)
        assert "ped_1" in result.request.critical_object_ids

    def test_phase94_does_not_reimplement_risk_scoring(self):
        """Phase 9.4 must not duplicate risk logic — it reads Phase 9.3 output."""
        e = eng()
        assert not hasattr(e, "compute_risk")
        assert not hasattr(e, "score_candidate")
        assert not hasattr(e, "calculate_ttc")


# ===========================================================================
# Indian road scenarios
# ===========================================================================

class TestIndianRoadReplanning:
    def test_village_road_cattle_enters_path(self):
        """Narrow village road: cattle enters → replanning triggered."""
        e = eng(critical_risk_threshold=0.75, ttc_critical_threshold_s=2.0)
        e.set_active_candidate("cand_0")
        ps_narrow = make_planning_space(road_width_m=3.5)
        cs = make_candidate_set()

        r_clear = make_risk("cand_0", total_risk=0.1)
        e.evaluate(1, make_risk_set([r_clear], timestamp=_T0 + 1),
                   cs, ps_narrow, timestamp=_T0 + 1)

        # Cattle enters
        r_cattle = make_risk("cand_0", total_risk=0.80, object_id="cattle_1",
                              ttc_s=1.8, is_critical=True, risk_level=RiskLevel.CRITICAL_RISK)
        result = e.evaluate(2, make_risk_set([r_cattle], timestamp=_T0 + 2),
                            cs, ps_narrow, timestamp=_T0 + 2)
        assert result.is_replan
        assert result.request.urgency == ReplanningUrgency.CRITICAL

    def test_market_pedestrian_enters_path(self):
        """Urban market: pedestrian enters path → dynamic blockage."""
        e = eng()
        e.set_active_candidate("cand_0")
        ps = make_planning_space()
        cs = make_candidate_set()

        r_clear = make_risk("cand_0", total_risk=0.1)
        e.evaluate(1, make_risk_set([r_clear], timestamp=_T0 + 1),
                   cs, ps, timestamp=_T0 + 1)

        r_ped = make_risk("cand_0", total_risk=0.72, object_id="ped_market",
                           is_critical=True, risk_level=RiskLevel.HIGH_RISK)
        result = e.evaluate(2, make_risk_set([r_ped], timestamp=_T0 + 2),
                            cs, ps, timestamp=_T0 + 2)
        assert ReplanningReasonCode.DYNAMIC_PATH_BLOCKAGE in result.request.reason_codes
        assert result.is_replan

    def test_highway_merge_prediction_change(self):
        """Highway merge: vehicle changes predicted merge trajectory."""
        e = eng(
            object_position_delta_threshold_m=1.5,
            trajectory_deviation_threshold_m=1.5,
        )
        e.set_active_candidate("cand_0")
        cs = make_candidate_set()
        rs = make_risk_set([make_risk("cand_0")])

        # Initial position
        ps1 = make_planning_space(
            frame_id=1,
            dynamic_objects=[make_dynamic_object("merge_v", position_x=30.0, position_y=3.0)]
        )
        e.evaluate(1, rs, cs, ps1, timestamp=_T0 + 1)

        # Vehicle begins merging into path
        ps2 = make_planning_space(
            frame_id=2,
            dynamic_objects=[make_dynamic_object("merge_v", position_x=28.0, position_y=0.5)]
        )
        result = e.evaluate(2, rs, cs, ps2, timestamp=_T0 + 2)
        assert ReplanningReasonCode.PREDICTION_CHANGE in result.request.reason_codes

    def test_unsignalized_intersection_crossing_motorcycle(self):
        """Unsignalized intersection: motorcycle crosses → TTC conflict."""
        e = eng(ttc_critical_threshold_s=2.0)
        e.set_active_candidate("cand_0")
        cs = make_candidate_set()
        ps = make_planning_space()

        # Motorcycle crosses with low TTC
        r = make_risk("cand_0", total_risk=0.60, object_id="moto_1",
                      ttc_s=1.0, is_critical=True, risk_level=RiskLevel.HIGH_RISK)
        rs = make_risk_set([r])
        result = e.evaluate(1, rs, cs, ps, timestamp=_T0 + 1)
        assert ReplanningReasonCode.TTC_DEGRADATION in result.request.reason_codes
        assert result.request.urgency == ReplanningUrgency.CRITICAL

    def test_cattle_crossing_trajectory_changes_unexpectedly(self):
        """Cattle trajectory changes → PREDICTION_CHANGE."""
        e = eng(
            object_position_delta_threshold_m=1.5,
            trajectory_deviation_threshold_m=1.5,
            object_velocity_delta_threshold=2.0,
        )
        e.set_active_candidate("cand_0")
        cs = make_candidate_set()
        rs = make_risk_set([make_risk("cand_0")])

        ps1 = make_planning_space(
            frame_id=1,
            dynamic_objects=[make_dynamic_object("cattle_1", position_x=20.0, position_y=5.0,
                                                  velocity_x=0.5, velocity_y=0.0)]
        )
        e.evaluate(1, rs, cs, ps1, timestamp=_T0 + 1)

        # Cattle suddenly moves into path
        ps2 = make_planning_space(
            frame_id=2,
            dynamic_objects=[make_dynamic_object("cattle_1", position_x=20.0, position_y=1.0,
                                                  velocity_x=0.0, velocity_y=-4.5)]
        )
        result = e.evaluate(2, rs, cs, ps2, timestamp=_T0 + 2)
        assert ReplanningReasonCode.PREDICTION_CHANGE in result.request.reason_codes

    def test_damaged_road_pothole_appears(self):
        """Pothole appears on Indian road → ROAD_ANOMALY_CHANGE."""
        e = eng()
        e.set_active_candidate("cand_0")
        cs = make_candidate_set()
        rs = make_risk_set([make_risk("cand_0")])

        ps_ok = make_planning_space(static_hazards=[])
        e.evaluate(1, rs, cs, ps_ok, timestamp=_T0 + 1)

        ps_hole = make_planning_space(static_hazards=[StaticHazardEntry()])
        result = e.evaluate(2, rs, cs, ps_hole, timestamp=_T0 + 2)
        assert ReplanningReasonCode.ROAD_ANOMALY_CHANGE in result.request.reason_codes

    def test_wrong_side_traffic_oncoming(self):
        """Wrong-side oncoming vehicle enters corridor → dynamic conflict."""
        e = eng(critical_risk_threshold=0.75, ttc_critical_threshold_s=2.5)
        e.set_active_candidate("cand_0")
        cs = make_candidate_set()
        ps = make_planning_space()

        r_clear = make_risk("cand_0", total_risk=0.1)
        e.evaluate(1, make_risk_set([r_clear], timestamp=_T0 + 1),
                   cs, ps, timestamp=_T0 + 1)

        # Oncoming vehicle — high risk, low TTC
        r_oncoming = make_risk("cand_0", total_risk=0.82, object_id="oncoming_v",
                                ttc_s=1.5, is_critical=True, risk_level=RiskLevel.CRITICAL_RISK)
        result = e.evaluate(2, make_risk_set([r_oncoming], timestamp=_T0 + 2),
                            cs, ps, timestamp=_T0 + 2)
        assert result.is_replan
        assert ReplanningReasonCode.DYNAMIC_PATH_BLOCKAGE in result.request.reason_codes
        assert ReplanningReasonCode.TTC_DEGRADATION in result.request.reason_codes


# ===========================================================================
# Degraded inputs
# ===========================================================================

class TestDegradedInputs:
    def test_none_risk_no_crash(self):
        e = eng()
        e.set_active_candidate("cand_0")
        ps = make_planning_space()
        cs = make_candidate_set()
        result = e.evaluate(1, None, cs, ps, timestamp=_T0 + 1)
        assert result.request is not None

    def test_none_candidate_set_no_crash(self):
        e = eng()
        e.set_active_candidate("cand_0")
        rs = make_risk_set()
        ps = make_planning_space()
        result = e.evaluate(1, rs, None, ps, timestamp=_T0 + 1)
        assert result.request is not None

    def test_none_planning_space_no_crash(self):
        e = eng()
        e.set_active_candidate("cand_0")
        rs = make_risk_set()
        cs = make_candidate_set()
        result = e.evaluate(1, rs, cs, None, timestamp=_T0 + 1)
        assert result.request is not None

    def test_all_none_no_crash(self):
        e = eng()
        e.set_active_candidate("cand_0")
        result = e.evaluate(1, None, None, None, timestamp=_T0 + 1)
        assert result.request is not None

    def test_degraded_risk_set_result_degraded(self):
        e = eng()
        e.set_active_candidate("cand_0")
        r = make_risk("cand_0", degraded=True)
        rs = make_risk_set([r])
        ps = make_planning_space()
        cs = make_candidate_set()
        result = e.evaluate(1, rs, cs, ps, timestamp=_T0 + 1)
        assert result.request.degraded is True


# ===========================================================================
# Stale inputs
# ===========================================================================

class TestStaleInputs:
    def test_stale_risk_set_triggers_stale_reason(self):
        e = eng(max_input_age_s=1.0)
        e.set_active_candidate("cand_0")
        ps = make_planning_space()
        cs = make_candidate_set()
        old_rs = make_risk_set(timestamp=_T0 + 0.0)
        result = e.evaluate(1, old_rs, cs, ps, timestamp=_T0 + 5.0)
        assert ReplanningReasonCode.STALE_PLANNING_STATE in result.request.reason_codes

    def test_fresh_risk_no_stale_reason(self):
        e = eng(max_input_age_s=5.0)
        e.set_active_candidate("cand_0")
        ps = make_planning_space()
        cs = make_candidate_set()
        fresh_rs = make_risk_set(timestamp=_T0 + 4.9)
        result = e.evaluate(1, fresh_rs, cs, ps, timestamp=_T0 + 5.0)
        assert ReplanningReasonCode.STALE_PLANNING_STATE not in result.request.reason_codes


# ===========================================================================
# Determinism
# ===========================================================================

class TestDeterminism:
    def test_same_input_same_decision(self):
        ps = make_planning_space()
        cs = make_candidate_set()
        r = make_risk("cand_0", total_risk=0.85, object_id="v1", ttc_s=1.0, is_critical=True)
        rs = make_risk_set([r], timestamp=_T0 + 1)

        results = []
        for _ in range(5):
            e = eng()
            e.set_active_candidate("cand_0")
            res = e.evaluate(1, rs, cs, ps, timestamp=_T0 + 1)
            results.append((res.request.decision, res.request.urgency,
                            res.request.reason_codes, res.request.dominant_reason))

        for item in results[1:]:
            assert item == results[0]

    def test_no_random_ids(self):
        """request_id must not use uuid.uuid4()."""
        ps = make_planning_space()
        cs = make_candidate_set()
        rs = make_risk_set()

        e1 = eng()
        e1.set_active_candidate("cand_0")
        res1 = e1.evaluate(1, rs, cs, ps, timestamp=_T0 + 1)

        e2 = eng()
        e2.set_active_candidate("cand_0")
        res2 = e2.evaluate(1, rs, cs, ps, timestamp=_T0 + 1)

        assert res1.request.request_id == res2.request.request_id

    def test_reason_order_is_stable(self):
        ps = make_planning_space()
        cs = make_candidate_set()
        r = make_risk("cand_0", total_risk=0.85, object_id="v1", ttc_s=0.8, is_critical=True)
        rs = make_risk_set([r], timestamp=_T0 + 1)

        orders = []
        for _ in range(3):
            e = eng()
            e.set_active_candidate("cand_0")
            res = e.evaluate(1, rs, cs, ps, timestamp=_T0 + 1)
            orders.append(res.request.reason_codes)

        assert all(o == orders[0] for o in orders)


# ===========================================================================
# Validation
# ===========================================================================

class TestValidation:
    def setup_method(self):
        self.v = ReplanningValidator()

    def test_valid_request_passes(self):
        from core.planning.replanning_types import ChangeMagnitudes
        req = ReplanningRequest(
            request_id="req_001",
            frame_id=1,
            timestamp=_T0 + 1,
            active_candidate_id="cand_0",
            decision=ReplanningDecision.NO_REPLAN,
            urgency=ReplanningUrgency.NORMAL,
            dominant_reason=ReplanningReasonCode.NO_ACTIVE_PATH,
            reason_codes=(),
            current_risk=0.1,
            previous_risk=0.1,
            risk_delta=0.0,
            uncertainty=0.2,
        )
        result = self.v.validate_request(req)
        assert result.is_valid

    def test_invalid_frame_id_fails(self):
        req = ReplanningRequest(frame_id=-1, timestamp=_T0 + 1, current_risk=0.1)
        result = self.v.validate_request(req)
        assert not result.is_valid

    def test_invalid_risk_score_fails(self):
        req = ReplanningRequest(frame_id=1, timestamp=_T0 + 1, current_risk=1.5)
        result = self.v.validate_request(req)
        assert not result.is_valid

    def test_none_request_fails(self):
        result = self.v.validate_request(None)
        assert not result.is_valid

    def test_valid_context_passes(self):
        ctx = ReplanningContext(
            context_id="ctx_001",
            frame_id=1,
            timestamp=_T0 + 1,
            current_risk=0.3,
            uncertainty=0.2,
        )
        result = self.v.validate_context(ctx)
        assert result.is_valid

    def test_none_context_fails(self):
        result = self.v.validate_context(None)
        assert not result.is_valid

    def test_engine_output_request_passes_validation(self):
        e = eng()
        e.set_active_candidate("cand_0")
        rs = make_risk_set()
        ps = make_planning_space()
        cs = make_candidate_set()
        result = e.evaluate(1, rs, cs, ps, timestamp=_T0 + 1)
        vr = self.v.validate_request(result.request)
        assert vr.is_valid, f"Validation errors: {vr.errors}"


# ===========================================================================
# Phase 9.4 scope confirmation (negative tests)
# ===========================================================================

class TestPhase94Scope:
    """Confirm Phase 9.4 contains NO forbidden functionality."""

    def test_request_has_no_selected_path(self):
        e = eng()
        e.set_active_candidate("cand_0")
        rs = make_risk_set()
        ps = make_planning_space()
        cs = make_candidate_set()
        result = e.evaluate(1, rs, cs, ps, timestamp=_T0 + 1)
        d = result.request.to_dict()
        for field in ("selected_path", "best_path", "optimal_path", "chosen_path"):
            assert field not in d, f"Forbidden field {field!r} found in request"

    def test_request_has_no_vehicle_control(self):
        e = eng()
        e.set_active_candidate("cand_0")
        rs = make_risk_set()
        ps = make_planning_space()
        cs = make_candidate_set()
        result = e.evaluate(1, rs, cs, ps, timestamp=_T0 + 1)
        d = result.request.to_dict()
        for field in ("steering_command", "throttle_command", "brake_command",
                      "target_speed", "mpc", "controller_command"):
            assert field not in d, f"Forbidden field {field!r} found"

    def test_active_path_has_no_control_fields(self):
        from core.planning.replanning_types import ActivePath
        ap = ActivePath()
        d = ap.to_dict()
        for field in ("steering_angle", "throttle", "brake", "target_speed"):
            assert field not in d

    def test_engine_has_no_path_generation(self):
        e = eng()
        for attr in ("generate_candidate_paths", "generate_trajectory",
                     "select_best_path", "choose_path", "compute_steering",
                     "compute_throttle", "compute_brake"):
            assert not hasattr(e, attr), f"Forbidden method {attr!r} on engine"

    def test_replanning_decision_not_a_path_choice(self):
        e = eng()
        e.set_active_candidate("cand_0")
        rs = make_risk_set()
        ps = make_planning_space()
        cs = make_candidate_set()
        result = e.evaluate(1, rs, cs, ps, timestamp=_T0 + 1)
        # Decision must be one of the allowed types — not a path ID
        assert isinstance(result.request.decision, ReplanningDecision)

    def test_no_path_selection_attribute_on_result(self):
        e = eng()
        e.set_active_candidate("cand_0")
        rs = make_risk_set()
        ps = make_planning_space()
        cs = make_candidate_set()
        result = e.evaluate(1, rs, cs, ps, timestamp=_T0 + 1)
        d = result.to_dict()
        for field in ("selected_path", "best_path", "path_generation"):
            assert field not in d

    def test_schema_version_matches(self):
        e = eng()
        e.set_active_candidate("cand_0")
        rs = make_risk_set()
        ps = make_planning_space()
        cs = make_candidate_set()
        result = e.evaluate(1, rs, cs, ps, timestamp=_T0 + 1)
        assert result.request.schema_version == REPLANNING_SCHEMA_VERSION


# ===========================================================================
# Multi-trigger
# ===========================================================================

class TestMultiTrigger:
    def test_all_reason_codes_preserved(self):
        e = eng(critical_risk_threshold=0.80, ttc_critical_threshold_s=2.0)
        e.set_active_candidate("cand_0")
        r = make_risk("cand_0", total_risk=0.85, object_id="cattle_1",
                      ttc_s=1.2, is_critical=True, risk_level=RiskLevel.CRITICAL_RISK)
        rs = make_risk_set([r])
        ps = make_planning_space()
        cs = make_candidate_set()
        result = e.evaluate(1, rs, cs, ps, timestamp=_T0 + 1)
        codes = result.request.reason_codes
        assert len(codes) >= 2
        assert ReplanningReasonCode.CRITICAL_PATH_RISK in codes
        assert ReplanningReasonCode.TTC_DEGRADATION in codes

    def test_dominant_reason_highest_priority(self):
        e = eng(critical_risk_threshold=0.80, ttc_critical_threshold_s=2.0)
        e.set_active_candidate("cand_0")
        r = make_risk("cand_0", total_risk=0.85, object_id="v1",
                      ttc_s=0.5, is_critical=True, risk_level=RiskLevel.CRITICAL_RISK)
        rs = make_risk_set([r])
        ps = make_planning_space()
        cs = make_candidate_set()
        result = e.evaluate(1, rs, cs, ps, timestamp=_T0 + 1)
        # Highest priority codes: CRITICAL_PATH_RISK or TTC_DEGRADATION or DYNAMIC_PATH_BLOCKAGE
        assert result.request.dominant_reason in (
            ReplanningReasonCode.CRITICAL_PATH_RISK,
            ReplanningReasonCode.TTC_DEGRADATION,
            ReplanningReasonCode.DYNAMIC_PATH_BLOCKAGE,
        )


# ===========================================================================
# Object relevance
# ===========================================================================

class TestObjectRelevance:
    def test_new_object_with_low_risk_not_critical(self):
        e = eng()
        e.set_active_candidate("cand_0")
        ps = make_planning_space()
        cs = make_candidate_set()
        r_clear = make_risk("cand_0", total_risk=0.1)
        e.evaluate(1, make_risk_set([r_clear], timestamp=_T0 + 1),
                   cs, ps, timestamp=_T0 + 1)

        # New irrelevant object — risk still low
        ps2 = make_planning_space(
            frame_id=2,
            dynamic_objects=[make_dynamic_object("far_obj", position_x=300.0, position_y=50.0)]
        )
        r2 = make_risk("cand_0", total_risk=0.1)
        result = e.evaluate(2, make_risk_set([r2], timestamp=_T0 + 2),
                            cs, ps2, timestamp=_T0 + 2)
        # Not critical — just informational
        assert result.request.urgency != ReplanningUrgency.CRITICAL
        assert result.request.decision != ReplanningDecision.REPLAN_REQUIRED

    def test_critical_object_is_always_relevant(self):
        e = eng()
        e.set_active_candidate("cand_0")
        ps = make_planning_space()
        cs = make_candidate_set()
        r = make_risk("cand_0", total_risk=0.75, object_id="close_ped",
                      is_critical=True, risk_level=RiskLevel.HIGH_RISK)
        rs = make_risk_set([r])
        result = e.evaluate(1, rs, cs, ps, timestamp=_T0 + 1)
        assert "close_ped" in result.request.critical_object_ids


# ===========================================================================
# Dynamic blockage
# ===========================================================================

class TestDynamicBlockageTrigger:
    def test_cattle_on_path_triggers_blockage(self):
        e = eng()
        e.set_active_candidate("cand_0")
        r = make_risk("cand_0", total_risk=0.72, object_id="cattle_A",
                      is_critical=True, risk_level=RiskLevel.HIGH_RISK)
        rs = make_risk_set([r])
        ps = make_planning_space()
        cs = make_candidate_set()
        result = e.evaluate(1, rs, cs, ps, timestamp=_T0 + 1)
        assert ReplanningReasonCode.DYNAMIC_PATH_BLOCKAGE in result.request.reason_codes

    def test_vehicle_stops_ahead_triggers_blockage(self):
        e = eng()
        e.set_active_candidate("cand_0")
        r = make_risk("cand_0", total_risk=0.68, object_id="stopped_v",
                      is_critical=True, risk_level=RiskLevel.HIGH_RISK)
        rs = make_risk_set([r])
        ps = make_planning_space()
        cs = make_candidate_set()
        result = e.evaluate(1, rs, cs, ps, timestamp=_T0 + 1)
        assert ReplanningReasonCode.DYNAMIC_PATH_BLOCKAGE in result.request.reason_codes


# ===========================================================================
# Prediction change trigger
# ===========================================================================

class TestPredictionChangeTrigger:
    def test_vehicle_turning_changes_trajectory(self):
        e = eng(
            object_position_delta_threshold_m=1.5,
            trajectory_deviation_threshold_m=1.5,
            object_velocity_delta_threshold=2.0,
        )
        e.set_active_candidate("cand_0")
        cs = make_candidate_set()
        rs = make_risk_set([make_risk("cand_0")])

        ps1 = make_planning_space(
            frame_id=1,
            dynamic_objects=[make_dynamic_object("turning_v", position_x=20.0, position_y=3.0,
                                                  velocity_x=8.0, velocity_y=0.0)]
        )
        e.evaluate(1, rs, cs, ps1, timestamp=_T0 + 1)

        ps2 = make_planning_space(
            frame_id=2,
            dynamic_objects=[make_dynamic_object("turning_v", position_x=20.0, position_y=0.5,
                                                  velocity_x=5.0, velocity_y=-4.0)]
        )
        result = e.evaluate(2, rs, cs, ps2, timestamp=_T0 + 2)
        assert ReplanningReasonCode.PREDICTION_CHANGE in result.request.reason_codes


# ===========================================================================
# TTC trigger
# ===========================================================================

class TestTTCTrigger:
    def test_ttc_crosses_critical_threshold(self):
        e = eng(ttc_critical_threshold_s=2.0, ttc_delta_threshold_s=1.0)
        e.set_active_candidate("cand_0")
        cs = make_candidate_set()
        ps = make_planning_space()

        r1 = make_risk("cand_0", total_risk=0.3, object_id="v1", ttc_s=6.0)
        e.evaluate(1, make_risk_set([r1], timestamp=_T0 + 1), cs, ps, timestamp=_T0 + 1)

        r2 = make_risk("cand_0", total_risk=0.55, object_id="v1", ttc_s=1.2)
        result = e.evaluate(2, make_risk_set([r2], timestamp=_T0 + 2), cs, ps, timestamp=_T0 + 2)
        assert ReplanningReasonCode.TTC_DEGRADATION in result.request.reason_codes

    def test_ttc_still_safe_no_trigger(self):
        e = eng(ttc_critical_threshold_s=2.0, ttc_delta_threshold_s=1.0)
        e.set_active_candidate("cand_0")
        cs = make_candidate_set()
        ps = make_planning_space()

        r1 = make_risk("cand_0", total_risk=0.1, object_id="v1", ttc_s=8.0)
        e.evaluate(1, make_risk_set([r1], timestamp=_T0 + 1), cs, ps, timestamp=_T0 + 1)

        r2 = make_risk("cand_0", total_risk=0.1, object_id="v1", ttc_s=7.5)
        result = e.evaluate(2, make_risk_set([r2], timestamp=_T0 + 2), cs, ps, timestamp=_T0 + 2)
        assert ReplanningReasonCode.TTC_DEGRADATION not in result.request.reason_codes


# ===========================================================================
# Road change trigger
# ===========================================================================

class TestRoadChangeTrigger:
    def test_road_narrows_triggers_drivable_region(self):
        e = eng(drivable_width_delta_threshold_m=0.5)
        e.set_active_candidate("cand_0")
        cs = make_candidate_set()
        rs = make_risk_set([make_risk("cand_0")])

        e.evaluate(1, rs, cs, make_planning_space(road_width_m=7.0), timestamp=_T0 + 1)
        result = e.evaluate(2, rs, cs, make_planning_space(road_width_m=4.0), timestamp=_T0 + 2)
        assert ReplanningReasonCode.DRIVABLE_REGION_CHANGE in result.request.reason_codes

    def test_anomaly_appears_triggers_road_anomaly(self):
        e = eng()
        e.set_active_candidate("cand_0")
        cs = make_candidate_set()
        rs = make_risk_set([make_risk("cand_0")])

        e.evaluate(1, rs, cs, make_planning_space(), timestamp=_T0 + 1)
        ps_anomaly = make_planning_space(static_hazards=[StaticHazardEntry()])
        result = e.evaluate(2, rs, cs, ps_anomaly, timestamp=_T0 + 2)
        assert ReplanningReasonCode.ROAD_ANOMALY_CHANGE in result.request.reason_codes


# ===========================================================================
# Safety gate trigger
# ===========================================================================

class TestSafetyGateTrigger:
    def test_gate_clear_to_caution_triggers(self):
        e = eng()
        e.set_active_candidate("cand_0")
        cs_clear = make_candidate_set(planning_allowed=True, sg_state="CLEAR")
        rs = make_risk_set([make_risk("cand_0")])
        ps_clear = make_planning_space(planning_allowed=True, gate_state="CLEAR")
        e.evaluate(1, rs, cs_clear, ps_clear, timestamp=_T0 + 1)

        cs_caution = make_candidate_set(planning_allowed=True, sg_state="CAUTION")
        ps_caution = make_planning_space(planning_allowed=True, gate_state="CAUTION")
        result = e.evaluate(2, rs, cs_caution, ps_caution, timestamp=_T0 + 2)
        assert ReplanningReasonCode.SAFETY_GATE_CHANGE in result.request.reason_codes

    def test_planning_blocked_returns_blocked(self):
        e = eng()
        e.set_active_candidate("cand_0")
        rs = make_risk_set([make_risk("cand_0", total_risk=0.15)])
        ps = make_planning_space(planning_allowed=False, gate_state="CRITICAL")
        cs = make_candidate_set(planning_allowed=False, sg_state="CRITICAL")
        result = e.evaluate(1, rs, cs, ps, timestamp=_T0 + 1)
        # Safety gate blocks planning — must never be overridden
        assert result.request.decision == ReplanningDecision.REPLAN_BLOCKED
