"""Tests for risk change detection in Phase 9.4."""
import sys
sys.path.insert(0, ".")

from tests.planning94.helpers_94 import (
    make_config, make_candidate, make_candidate_set,
    make_risk, make_risk_set, make_planning_space,
    make_snapshot, _T0,
)
from core.planning.replanning_engine import ReplanningEngine
from core.planning.replanning_change_detector import ChangeDetector
from core.planning.replanning_types import ReplanningReasonCode


def make_engine(**cfg_kw):
    return ReplanningEngine(config=make_config(**cfg_kw))


class TestRiskChangeDelta:
    def test_large_delta_triggers_escalation(self):
        e = make_engine(risk_escalation_delta_threshold=0.20, risk_noise_floor=0.02)
        e.set_active_candidate("cand_0")
        ps = make_planning_space()
        cs = make_candidate_set()

        r1 = make_risk("cand_0", total_risk=0.10)
        rs1 = make_risk_set([r1], timestamp=_T0 + 1)
        e.evaluate(1, rs1, cs, ps, timestamp=_T0 + 1)

        r2 = make_risk("cand_0", total_risk=0.55)  # delta=0.45 > 0.20
        rs2 = make_risk_set([r2], timestamp=_T0 + 2)
        result = e.evaluate(2, rs2, cs, ps, timestamp=_T0 + 2)
        assert ReplanningReasonCode.RISK_ESCALATION in result.request.reason_codes

    def test_below_threshold_no_escalation(self):
        e = make_engine(risk_escalation_delta_threshold=0.20, risk_noise_floor=0.01)
        e.set_active_candidate("cand_0")
        ps = make_planning_space()
        cs = make_candidate_set()

        r1 = make_risk("cand_0", total_risk=0.30)
        rs1 = make_risk_set([r1], timestamp=_T0 + 1)
        e.evaluate(1, rs1, cs, ps, timestamp=_T0 + 1)

        r2 = make_risk("cand_0", total_risk=0.40)  # delta=0.10 < 0.20
        rs2 = make_risk_set([r2], timestamp=_T0 + 2)
        result = e.evaluate(2, rs2, cs, ps, timestamp=_T0 + 2)
        assert ReplanningReasonCode.RISK_ESCALATION not in result.request.reason_codes

    def test_noise_floor_prevents_trigger(self):
        e = make_engine(risk_escalation_delta_threshold=0.20, risk_noise_floor=0.05)
        e.set_active_candidate("cand_0")
        ps = make_planning_space()
        cs = make_candidate_set()

        # Delta is 0.03 — below noise floor
        r1 = make_risk("cand_0", total_risk=0.30)
        rs1 = make_risk_set([r1], timestamp=_T0 + 1)
        e.evaluate(1, rs1, cs, ps, timestamp=_T0 + 1)

        r2 = make_risk("cand_0", total_risk=0.33)
        rs2 = make_risk_set([r2], timestamp=_T0 + 2)
        result = e.evaluate(2, rs2, cs, ps, timestamp=_T0 + 2)
        assert ReplanningReasonCode.RISK_ESCALATION not in result.request.reason_codes

    def test_risk_delta_reported_in_request(self):
        e = make_engine(risk_escalation_delta_threshold=0.20)
        e.set_active_candidate("cand_0")
        ps = make_planning_space()
        cs = make_candidate_set()

        r1 = make_risk("cand_0", total_risk=0.20)
        rs1 = make_risk_set([r1], timestamp=_T0 + 1)
        e.evaluate(1, rs1, cs, ps, timestamp=_T0 + 1)

        r2 = make_risk("cand_0", total_risk=0.50)
        rs2 = make_risk_set([r2], timestamp=_T0 + 2)
        result = e.evaluate(2, rs2, cs, ps, timestamp=_T0 + 2)
        assert abs(result.request.risk_delta - 0.30) < 0.005
        assert abs(result.request.current_risk - 0.50) < 0.005
        assert abs(result.request.previous_risk - 0.20) < 0.005

    def test_deescalation_no_replan_by_default(self):
        e = make_engine(risk_deescalation_replan=False, risk_escalation_delta_threshold=0.20)
        e.set_active_candidate("cand_0")
        ps = make_planning_space()
        cs = make_candidate_set()

        r1 = make_risk("cand_0", total_risk=0.70)
        rs1 = make_risk_set([r1], timestamp=_T0 + 1)
        e.evaluate(1, rs1, cs, ps, timestamp=_T0 + 1)

        # Risk drops significantly
        r2 = make_risk("cand_0", total_risk=0.30)
        rs2 = make_risk_set([r2], timestamp=_T0 + 2)
        result = e.evaluate(2, rs2, cs, ps, timestamp=_T0 + 2)
        assert ReplanningReasonCode.RISK_ESCALATION not in result.request.reason_codes

    def test_deescalation_replan_if_configured(self):
        e = make_engine(risk_deescalation_replan=True, risk_escalation_delta_threshold=0.20)
        e.set_active_candidate("cand_0")
        ps = make_planning_space()
        cs = make_candidate_set()

        r1 = make_risk("cand_0", total_risk=0.70)
        rs1 = make_risk_set([r1], timestamp=_T0 + 1)
        e.evaluate(1, rs1, cs, ps, timestamp=_T0 + 1)

        r2 = make_risk("cand_0", total_risk=0.30)  # drop of 0.40 > threshold
        rs2 = make_risk_set([r2], timestamp=_T0 + 2)
        result = e.evaluate(2, rs2, cs, ps, timestamp=_T0 + 2)
        assert ReplanningReasonCode.RISK_ESCALATION in result.request.reason_codes


class TestChangeDetectorDirect:
    def _det(self, **kw):
        return ChangeDetector(config=make_config(**kw))

    def test_none_previous_no_triggers(self):
        det = self._det()
        curr = make_snapshot(frame_id=1, risk_score=0.5)
        result = det.detect(None, curr)
        assert result.triggered_reasons == ()

    def test_risk_escalation_detected(self):
        det = self._det(risk_escalation_delta_threshold=0.20, risk_noise_floor=0.01)
        prev = make_snapshot(frame_id=1, risk_score=0.10)
        curr = make_snapshot(frame_id=2, risk_score=0.55)
        result = det.detect(prev, curr)
        assert ReplanningReasonCode.RISK_ESCALATION in result.triggered_reasons

    def test_new_object_detected(self):
        det = self._det()
        prev = make_snapshot(frame_id=1, object_ids=("v1",))
        curr = make_snapshot(frame_id=2, object_ids=("v1", "v2"))
        result = det.detect(prev, curr)
        assert ReplanningReasonCode.NEW_RELEVANT_OBJECT in result.triggered_reasons
        assert "v2" in result.new_object_ids

    def test_disappeared_object_detected(self):
        det = self._det(replan_on_hazard_cleared=True)
        prev = make_snapshot(frame_id=1, object_ids=("v1", "v2"))
        curr = make_snapshot(frame_id=2, object_ids=("v1",))
        result = det.detect(prev, curr)
        assert "v2" in result.disappeared_ids
        assert ReplanningReasonCode.HAZARD_CLEARED in result.triggered_reasons

    def test_road_anomaly_appears(self):
        det = self._det()
        prev = make_snapshot(frame_id=1, has_road_anomaly=False)
        curr = make_snapshot(frame_id=2, has_road_anomaly=True)
        result = det.detect(prev, curr)
        assert ReplanningReasonCode.ROAD_ANOMALY_CHANGE in result.triggered_reasons

    def test_safety_gate_change_detected(self):
        det = self._det()
        prev = make_snapshot(frame_id=1, safety_gate_state="CLEAR")
        curr = make_snapshot(frame_id=2, safety_gate_state="CAUTION")
        result = det.detect(prev, curr)
        assert ReplanningReasonCode.SAFETY_GATE_CHANGE in result.triggered_reasons

    def test_width_change_triggers_drivable_region(self):
        det = self._det(drivable_width_delta_threshold_m=0.5)
        prev = make_snapshot(frame_id=1, drivable_width_m=6.0)
        curr = make_snapshot(frame_id=2, drivable_width_m=3.5)
        result = det.detect(prev, curr)
        assert ReplanningReasonCode.DRIVABLE_REGION_CHANGE in result.triggered_reasons

    def test_uncertainty_escalation(self):
        det = self._det(uncertainty_escalation_threshold=0.75)
        prev = make_snapshot(frame_id=1, uncertainty=0.30)
        curr = make_snapshot(frame_id=2, uncertainty=0.80)
        result = det.detect(prev, curr)
        assert ReplanningReasonCode.UNCERTAINTY_ESCALATION in result.triggered_reasons

    def test_reason_codes_sorted_deterministically(self):
        det = self._det(risk_escalation_delta_threshold=0.05, risk_noise_floor=0.01)
        prev = make_snapshot(frame_id=1, risk_score=0.10, object_ids=("v1",))
        curr = make_snapshot(frame_id=2, risk_score=0.50, object_ids=("v1", "v2"),
                             has_road_anomaly=True)
        r1 = det.detect(prev, curr)
        r2 = det.detect(prev, curr)
        assert r1.triggered_reasons == r2.triggered_reasons

    def test_planning_allowed_change(self):
        det = self._det()
        prev = make_snapshot(frame_id=1, planning_allowed=True)
        curr = make_snapshot(frame_id=2, planning_allowed=False)
        result = det.detect(prev, curr)
        assert ReplanningReasonCode.SAFETY_GATE_CHANGE in result.triggered_reasons
