"""Tests for Phase 9.4 replanning data types."""
import sys
import time
sys.path.insert(0, ".")

from core.planning.replanning_types import (
    NOT_AVAILABLE,
    REPLANNING_SCHEMA_VERSION,
    ReplanningDecision,
    ReplanningUrgency,
    ReplanningReasonCode,
    ActivePathValidity,
    CooldownState,
    ActivePath,
    PlanningStateSnapshot,
    ChangeMagnitudes,
    ReplanningRequest,
    ReplanningContext,
    ReplanningDecisionResult,
)


class TestReplanningDecision:
    def test_all_values_exist(self):
        assert ReplanningDecision.NO_REPLAN
        assert ReplanningDecision.REPLAN_REQUESTED
        assert ReplanningDecision.REPLAN_REQUIRED
        assert ReplanningDecision.REPLAN_BLOCKED
        assert ReplanningDecision.DEGRADED_REPLAN
        assert ReplanningDecision.UNKNOWN

    def test_string_values(self):
        assert ReplanningDecision.NO_REPLAN.value == "NO_REPLAN"
        assert ReplanningDecision.REPLAN_REQUIRED.value == "REPLAN_REQUIRED"


class TestReplanningUrgency:
    def test_all_values(self):
        assert ReplanningUrgency.NORMAL
        assert ReplanningUrgency.ELEVATED
        assert ReplanningUrgency.URGENT
        assert ReplanningUrgency.CRITICAL


class TestReplanningReasonCode:
    def test_key_codes_exist(self):
        codes = [
            ReplanningReasonCode.PATH_GEOMETRY_INVALID,
            ReplanningReasonCode.DYNAMIC_PATH_BLOCKAGE,
            ReplanningReasonCode.RISK_ESCALATION,
            ReplanningReasonCode.CRITICAL_PATH_RISK,
            ReplanningReasonCode.TTC_DEGRADATION,
            ReplanningReasonCode.PREDICTION_CHANGE,
            ReplanningReasonCode.NEW_RELEVANT_OBJECT,
            ReplanningReasonCode.HAZARD_CLEARED,
            ReplanningReasonCode.ROAD_STRUCTURE_CHANGE,
            ReplanningReasonCode.ROAD_ANOMALY_CHANGE,
            ReplanningReasonCode.DRIVABLE_REGION_CHANGE,
            ReplanningReasonCode.SAFETY_GATE_CHANGE,
            ReplanningReasonCode.UNCERTAINTY_ESCALATION,
            ReplanningReasonCode.STALE_PLANNING_STATE,
            ReplanningReasonCode.PLANNING_CONTEXT_CHANGE,
            ReplanningReasonCode.NO_ACTIVE_PATH,
        ]
        assert len(codes) == 16


class TestActivePath:
    def test_defaults(self):
        ap = ActivePath()
        assert ap.candidate_id == NOT_AVAILABLE
        assert ap.validity == ActivePathValidity.NOT_SET
        assert ap.risk_score == 0.0
        assert ap.schema_version == REPLANNING_SCHEMA_VERSION

    def test_to_dict(self):
        ap = ActivePath(candidate_id="c1", validity=ActivePathValidity.VALID, risk_score=0.3)
        d = ap.to_dict()
        assert d["candidate_id"] == "c1"
        assert d["validity"] == "VALID"
        assert d["risk_score"] == 0.3

    def test_no_forbidden_fields(self):
        ap = ActivePath()
        d = ap.to_dict()
        forbidden = {"steering_angle", "throttle", "brake", "target_speed", "mpc"}
        assert not (forbidden & set(d.keys()))


class TestReplanningRequest:
    def test_defaults(self):
        req = ReplanningRequest()
        assert req.schema_version == REPLANNING_SCHEMA_VERSION
        assert req.decision == ReplanningDecision.UNKNOWN

    def test_to_dict_no_forbidden(self):
        req = ReplanningRequest(
            request_id="req_001",
            frame_id=1,
            decision=ReplanningDecision.REPLAN_REQUESTED,
            urgency=ReplanningUrgency.ELEVATED,
            dominant_reason=ReplanningReasonCode.RISK_ESCALATION,
        )
        d = req.to_dict()
        forbidden = {
            "selected_path", "best_path", "optimal_path", "steering_angle",
            "throttle", "brake", "target_speed", "mpc",
        }
        assert not (forbidden & set(d.keys()))
        assert d["decision"] == "REPLAN_REQUESTED"


class TestReplanningContext:
    def test_defaults(self):
        ctx = ReplanningContext()
        assert ctx.schema_version == REPLANNING_SCHEMA_VERSION
        assert ctx.planning_allowed is False

    def test_to_dict(self):
        ctx = ReplanningContext(context_id="ctx_001", frame_id=5)
        d = ctx.to_dict()
        assert d["context_id"] == "ctx_001"
        assert d["frame_id"] == 5


class TestReplanningDecisionResult:
    def test_is_replan_no_replan(self):
        req = ReplanningRequest(decision=ReplanningDecision.NO_REPLAN)
        result = ReplanningDecisionResult(request=req)
        assert not result.is_replan

    def test_is_replan_requested(self):
        req = ReplanningRequest(decision=ReplanningDecision.REPLAN_REQUESTED)
        result = ReplanningDecisionResult(request=req)
        assert result.is_replan

    def test_is_critical_false(self):
        req = ReplanningRequest(
            decision=ReplanningDecision.REPLAN_REQUESTED,
            urgency=ReplanningUrgency.ELEVATED,
        )
        result = ReplanningDecisionResult(request=req)
        assert not result.is_critical

    def test_is_critical_true(self):
        req = ReplanningRequest(
            decision=ReplanningDecision.REPLAN_REQUIRED,
            urgency=ReplanningUrgency.CRITICAL,
        )
        result = ReplanningDecisionResult(request=req)
        assert result.is_critical

    def test_to_dict(self):
        req = ReplanningRequest(decision=ReplanningDecision.NO_REPLAN)
        result = ReplanningDecisionResult(request=req)
        d = result.to_dict()
        assert d["is_replan"] is False
        assert d["is_critical"] is False
        assert "request" in d
