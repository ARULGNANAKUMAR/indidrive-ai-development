"""
IndiDrive AI — Phase 10.4 | Tests: Indian Road Control Scenarios
================================================================
Realistic control-oriented test cases for Indian road conditions.
All inputs are prepared explicitly — no scenario-name-based behavior.

These tests verify the control layer handles Indian road inputs correctly,
NOT that the layer changes behavior based on scenario names.
"""
from __future__ import annotations

import math
import sys
import os
import time

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))

from core.control.control_manager import ControlManager
from core.control.control_config import ControlConfig
from core.control.control_types import (
    ControlCommandStatus, FallbackPolicy, LongitudinalMode,
)
from core.control.steering_controller import SteeringController
from core.control.speed_controller import SpeedController

from tests.control104.helpers import default_config, make_valid_snapshot


def _manager(cfg=None) -> ControlManager:
    return ControlManager(cfg or default_config())


# ---------------------------------------------------------------------------
# Village road — low speed, curved reference
# ---------------------------------------------------------------------------

class TestVillageRoad:
    """
    Village road scenario: low speed (~25 km/h), moderate steering.
    Inputs are provided explicitly — no if/elif scenario logic.
    """
    def test_low_speed_curved_steering(self):
        # ~25 km/h = 6.94 m/s, moderate curve → steering ~0.15 rad
        snap = make_valid_snapshot(steering=0.15, acceleration=0.0)
        cmd = _manager().step(snap, 6.94, 6.94, 0.1)
        assert cmd.is_valid
        assert abs(cmd.steering_angle_rad - 0.15) < 1e-9

    def test_low_speed_target_speed_reasonable(self):
        snap = make_valid_snapshot(steering=0.1, acceleration=0.0)
        cmd = _manager().step(snap, 6.94, 6.94, 0.1)
        assert cmd.target_speed_mps <= 20.0
        assert cmd.target_speed_mps >= 0.0

    def test_steering_within_bounds(self):
        cfg = default_config()
        snap = make_valid_snapshot(steering=0.15, acceleration=0.3)
        cmd = ControlManager(cfg).step(snap, 5.0, 5.0, 0.1)
        assert cmd.steering_angle_rad >= cfg.min_steering_rad
        assert cmd.steering_angle_rad <= cfg.max_steering_rad


# ---------------------------------------------------------------------------
# Dense market — reduced speed, controlled braking
# ---------------------------------------------------------------------------

class TestDenseMarket:
    """
    Dense market area: ~15 km/h = 4.17 m/s, MPC requests controlled braking.
    """
    def test_moderate_braking_command(self):
        # MPC requests gentle deceleration (approaching parked vehicles)
        snap = make_valid_snapshot(steering=0.02, acceleration=-1.5)
        cmd = _manager().step(snap, 6.0, 4.0, 0.1)
        assert cmd.is_valid
        assert cmd.acceleration_mps2 < 0.0 or cmd.acceleration_mps2 == 0.0

    def test_reduced_target_speed(self):
        # Ref speed from planner = 4.17 m/s (15 km/h)
        snap = make_valid_snapshot(steering=0.0, acceleration=-0.5)
        cmd = _manager().step(snap, 8.0, 4.17, 0.1)
        assert cmd.target_speed_mps <= 10.0  # reasonable for market area

    def test_brake_is_bounded(self):
        cfg = default_config()
        snap = make_valid_snapshot(steering=0.0, acceleration=-3.0)
        cmd = ControlManager(cfg).step(snap, 5.0, 3.0, 0.1)
        assert cmd.brake_mps2 <= cfg.max_brake_mps2


# ---------------------------------------------------------------------------
# Highway merge — higher speed, steering limit test
# ---------------------------------------------------------------------------

class TestHighwayMerge:
    """
    Highway merge: ~80 km/h = 22.2 m/s, gentle steering, higher ref speed.
    """
    def test_highway_speed_within_limits(self):
        cfg = default_config()
        snap = make_valid_snapshot(steering=0.05, acceleration=1.0)
        cmd = ControlManager(cfg).step(snap, 20.0, 22.2, 0.1)
        assert cmd.is_valid
        assert cmd.target_speed_mps <= cfg.max_speed_mps

    def test_merge_steering_gentle(self):
        # Gentle lane change: ~3° = 0.052 rad
        snap = make_valid_snapshot(steering=0.052, acceleration=0.5)
        cmd = _manager().step(snap, 20.0, 22.0, 0.1)
        assert abs(cmd.steering_angle_rad - 0.052) < 1e-9

    def test_acceleration_within_limits(self):
        cfg = default_config()
        snap = make_valid_snapshot(steering=0.05, acceleration=3.0)
        cmd = ControlManager(cfg).step(snap, 18.0, 22.0, 0.1)
        assert cmd.acceleration_mps2 <= cfg.max_acceleration_mps2


# ---------------------------------------------------------------------------
# Cattle crossing — deceleration, bounded braking
# ---------------------------------------------------------------------------

class TestCattleCrossing:
    """
    Cattle crossing: MPC requests emergency deceleration.
    Inputs provided explicitly from upstream MPC solution.
    """
    def test_deceleration_command_from_mpc(self):
        # MPC outputs strong deceleration to stop for cattle
        snap = make_valid_snapshot(steering=0.0, acceleration=-5.0)
        cmd = _manager().step(snap, 12.0, 0.0, 0.1)
        assert cmd.is_valid
        assert cmd.acceleration_mps2 <= 0.0

    def test_brake_non_zero_on_strong_decel(self):
        cfg = default_config()
        snap = make_valid_snapshot(steering=0.0, acceleration=-5.0)
        cmd = ControlManager(cfg).step(snap, 12.0, 0.0, 0.1)
        assert cmd.brake_mps2 > 0.0

    def test_brake_bounded(self):
        cfg = default_config()
        # Even if MPC requests -10 m/s² (beyond limits), brake stays bounded
        snap = make_valid_snapshot(steering=0.0, acceleration=-12.0)
        cmd = ControlManager(cfg).step(snap, 12.0, 0.0, 0.1)
        assert cmd.brake_mps2 <= cfg.max_brake_mps2
        assert cmd.acceleration_mps2 >= cfg.min_acceleration_mps2

    def test_zero_steering_during_decel(self):
        snap = make_valid_snapshot(steering=0.0, acceleration=-4.0)
        cmd = _manager().step(snap, 10.0, 0.0, 0.1)
        assert abs(cmd.steering_angle_rad) < 1e-9


# ---------------------------------------------------------------------------
# Narrow road — strong steering rate limit
# ---------------------------------------------------------------------------

class TestNarrowRoad:
    """
    Narrow road: frequent but smooth steering corrections.
    Strong rate limiting ensures smooth commands.
    """
    def test_steering_rate_limits_rapid_input(self):
        from core.control.control_types import FallbackPolicy
        slow_cfg = ControlConfig(
            min_steering_rad=-0.610, max_steering_rad=0.610,
            max_steering_rate_rad_s=0.2,
            min_acceleration_mps2=-8.0, max_acceleration_mps2=4.0,
            min_speed_mps=0.0, max_speed_mps=33.33,
            brake_threshold_mps2=0.05, max_brake_mps2=8.0,
            stale_timeout_s=0.5, fallback_policy=FallbackPolicy.INVALID_COMMAND,
            safe_deceleration_mps2=-2.0,
        )
        m = ControlManager(slow_cfg)
        # Simulate a series of tight steering requests
        snap1 = make_valid_snapshot(steering=0.0, acceleration=0.5)
        m.step(snap1, 4.0, 4.0, 0.1)  # set prev=0.0

        # Now large jump
        snap2 = make_valid_snapshot(steering=0.4, acceleration=0.5)
        cmd2 = m.step(snap2, 4.0, 4.0, 0.1)
        # max_delta = 0.2 * 0.1 = 0.02 rad; 0.4 > 0.02 → rate limited
        assert cmd2.rate_limited
        assert abs(cmd2.steering_angle_rad) <= 0.02 + 1e-9

    def test_smooth_steering_sequence(self):
        """Incremental steering changes within rate limit pass through."""
        m = _manager()
        angles = [0.0, 0.02, 0.04, 0.06, 0.08, 0.10]
        prev_angle = 0.0
        for target in angles:
            snap = make_valid_snapshot(steering=target, acceleration=0.2)
            cmd = m.step(snap, 4.0, 4.0, 0.1)
            assert cmd.is_valid
            # Steering should track target closely within rate
            assert abs(cmd.steering_angle_rad - target) < 0.1


# ---------------------------------------------------------------------------
# Damaged road — speed reference reduction, stable steering
# ---------------------------------------------------------------------------

class TestDamagedRoad:
    """
    Damaged road: MPC requests low speed, stable steering.
    """
    def test_low_speed_reference(self):
        # Planner sets ref_speed = 3 m/s (slow over potholes)
        snap = make_valid_snapshot(steering=0.05, acceleration=-0.5)
        cmd = _manager().step(snap, 8.0, 3.0, 0.1)
        assert cmd.is_valid
        # Target speed should be at or near ref
        assert cmd.target_speed_mps <= 8.0  # shouldn't exceed current

    def test_stable_steering_small_correction(self):
        snap = make_valid_snapshot(steering=0.03, acceleration=-0.2)
        cmd = _manager().step(snap, 3.0, 3.0, 0.1)
        assert abs(cmd.steering_angle_rad - 0.03) < 1e-9

    def test_acceleration_modest(self):
        cfg = default_config()
        snap = make_valid_snapshot(steering=0.0, acceleration=-0.3)
        cmd = ControlManager(cfg).step(snap, 3.5, 3.0, 0.1)
        assert cmd.acceleration_mps2 >= cfg.min_acceleration_mps2
