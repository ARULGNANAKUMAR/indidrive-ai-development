"""
IndiDrive AI — Phase 10.4 | Tests: Integration
===============================================
Integration tests verifying Phase 10.1 → 10.2 → 10.3 → 10.4 data flow.

Verifies that existing Phase 10.1/10.2/10.3 data types flow correctly
into the Phase 10.4 control layer.

Does NOT implement the complete planner → control closed loop.
"""
from __future__ import annotations

import math
import sys
import os
import time

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))

from core.vehicle.vehicle_state import VehicleState
from core.vehicle.vehicle_parameters import VehicleParameters
from core.control.mpc_snapshot import MPCSnapshot
from core.control.mpc_types import MPCStatus, ConstraintStatus
from core.control.mpc_prediction import MPCControlInput
from core.control.control_config import ControlConfig
from core.control.control_manager import ControlManager
from core.control.control_snapshot import VehicleControlCommand
from core.control.control_types import ControlCommandStatus, CommandSource

from tests.control104.helpers import make_valid_snapshot, default_config


# ---------------------------------------------------------------------------
# Phase 10.1 Vehicle State → Phase 10.4 Control
# ---------------------------------------------------------------------------

class TestVehicleStateToPhaseTen4:
    def test_velocity_from_vehicle_state(self):
        """Phase 10.4 correctly handles velocity from VehicleState."""
        state = VehicleState(
            x=10.0, y=0.0, yaw=0.0, velocity=15.0,
            timestamp=time.monotonic(), frame_id=5,
        )
        snap = make_valid_snapshot(steering=0.05, acceleration=0.5,
                                   frame_id=state.frame_id)
        cfg = default_config()
        m = ControlManager(cfg)
        cmd = m.step(
            snapshot=snap,
            current_velocity_mps=state.velocity,
            ref_speed_mps=None,
            dt=0.1,
            frame_id=state.frame_id,
            current_time=snap.snap_timestamp + 0.05,
        )
        assert cmd.is_valid
        assert cmd.frame_id == state.frame_id

    def test_zero_velocity_vehicle_state(self):
        """Vehicle at rest — control should handle zero velocity."""
        state = VehicleState(
            x=0.0, y=0.0, yaw=0.0, velocity=0.0,
            timestamp=time.monotonic(), frame_id=1,
        )
        snap = make_valid_snapshot(steering=0.0, acceleration=1.0,
                                   frame_id=state.frame_id)
        m = ControlManager(default_config())
        cmd = m.step(
            snapshot=snap,
            current_velocity_mps=state.velocity,
            ref_speed_mps=None,
            dt=0.1,
            frame_id=state.frame_id,
            current_time=snap.snap_timestamp + 0.05,
        )
        assert cmd.is_valid
        assert cmd.target_speed_mps >= 0.0


# ---------------------------------------------------------------------------
# Phase 10.1 VehicleParameters → ControlConfig alignment
# ---------------------------------------------------------------------------

class TestVehicleParametersAlignment:
    def test_default_config_within_vehicle_limits(self):
        """ControlConfig defaults must not exceed VehicleParameters defaults."""
        vp  = VehicleParameters.default()
        cfg = ControlConfig.default()
        # Steering
        assert cfg.max_steering_rad <= vp.max_steering_angle_rad + 1e-9
        assert cfg.min_steering_rad >= -vp.max_steering_angle_rad - 1e-9
        # Acceleration
        assert cfg.max_acceleration_mps2 <= vp.max_acceleration_mps2 + 1e-9
        assert cfg.min_acceleration_mps2 >= vp.min_acceleration_mps2 - 1e-9
        # Speed
        assert cfg.max_speed_mps <= vp.max_velocity_mps + 1e-9


# ---------------------------------------------------------------------------
# Phase 10.3 MPCSnapshot → Phase 10.4 Command
# ---------------------------------------------------------------------------

class TestMPCSnapshotToPhaseTen4:
    def test_success_snapshot_produces_valid_command(self):
        snap = make_valid_snapshot(
            steering=0.1, acceleration=1.5, feasible=True,
            status=MPCStatus.SUCCESS,
        )
        m = ControlManager(default_config())
        cmd = m.step(
            snapshot=snap,
            current_velocity_mps=10.0,
            ref_speed_mps=12.0,
            dt=0.1,
            current_time=snap.snap_timestamp + 0.05,
        )
        assert cmd.is_valid
        assert cmd.source == CommandSource.MPC

    def test_failure_snapshot_produces_invalid_command(self):
        snap = make_valid_snapshot(
            feasible=False, status=MPCStatus.NO_FEASIBLE_SOLUTION,
        )
        m = ControlManager(default_config())
        cmd = m.step(
            snapshot=snap,
            current_velocity_mps=10.0,
            ref_speed_mps=None,
            dt=0.1,
            current_time=snap.snap_timestamp + 0.05,
        )
        assert not cmd.is_valid

    def test_mpc_steering_transferred_to_command(self):
        """first_steering_input → steering_angle_rad (within limits)."""
        steering = 0.2
        snap = make_valid_snapshot(steering=steering, acceleration=0.0)
        m = ControlManager(default_config())
        cmd = m.step(
            snapshot=snap,
            current_velocity_mps=10.0,
            ref_speed_mps=None,
            dt=0.1,
            current_time=snap.snap_timestamp + 0.05,
        )
        assert abs(cmd.steering_angle_rad - steering) < 1e-9

    def test_mpc_accel_transferred_to_command(self):
        """first_acceleration_input → acceleration_mps2 (within limits)."""
        accel = 2.0
        snap = make_valid_snapshot(steering=0.0, acceleration=accel)
        m = ControlManager(default_config())
        cmd = m.step(
            snapshot=snap,
            current_velocity_mps=10.0,
            ref_speed_mps=None,
            dt=0.1,
            current_time=snap.snap_timestamp + 0.05,
        )
        assert abs(cmd.acceleration_mps2 - accel) < 1e-9

    def test_command_schema_version(self):
        """Phase 10.4 command carries schema_version '10.4'."""
        snap = make_valid_snapshot()
        m = ControlManager(default_config())
        cmd = m.step(snap, 10.0, None, 0.1,
                     current_time=snap.snap_timestamp + 0.05)
        assert cmd.schema_version == "10.4"

    def test_command_is_frozen_snapshot(self):
        """VehicleControlCommand is immutable."""
        snap = make_valid_snapshot()
        m = ControlManager(default_config())
        cmd = m.step(snap, 10.0, None, 0.1,
                     current_time=snap.snap_timestamp + 0.05)
        try:
            object.__setattr__(cmd, "acceleration_mps2", 999.0)
            assert False, "Should be frozen"
        except Exception:
            pass


# ---------------------------------------------------------------------------
# Multi-step pipeline integration
# ---------------------------------------------------------------------------

class TestMultiStepPipeline:
    def test_three_step_pipeline(self):
        """Run 3 consecutive steps and verify progressive steering."""
        m = ControlManager(default_config())
        steerings = [0.0, 0.05, 0.10]
        commands = []
        for s in steerings:
            snap = make_valid_snapshot(steering=s, acceleration=0.5)
            cmd = m.step(snap, 10.0, 12.0, 0.1,
                         current_time=snap.snap_timestamp + 0.05)
            commands.append(cmd)

        # All commands should be valid
        for cmd in commands:
            assert cmd.is_valid

        # Steering should track MPC inputs (within rate limits)
        assert commands[0].steering_angle_rad <= commands[2].steering_angle_rad + 1e-6

    def test_pipeline_cycle_count(self):
        m = ControlManager(default_config())
        for i in range(5):
            snap = make_valid_snapshot()
            m.step(snap, 10.0, None, 0.1,
                   current_time=snap.snap_timestamp + 0.05)
        assert m.cycle == 5

    def test_phase104_does_not_call_phase103_solver(self):
        """ControlManager.step must not trigger an MPC solve."""
        m = ControlManager(default_config())
        snap = make_valid_snapshot()
        # If MPCController.solve() is accidentally called, it would need
        # a reference trajectory — which we don't provide.
        # This should complete without error.
        cmd = m.step(snap, 10.0, None, 0.1,
                     current_time=snap.snap_timestamp + 0.05)
        assert cmd is not None
