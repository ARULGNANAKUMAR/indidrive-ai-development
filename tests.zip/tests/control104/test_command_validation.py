"""
IndiDrive AI — Phase 10.4 | Tests: Command Snapshot and Validation
===================================================================
Tests for VehicleControlCommand and ControlValidator.validate_command().
"""
from __future__ import annotations

import math
import sys
import os
import time

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))

from core.control.control_snapshot import VehicleControlCommand
from core.control.control_validator import ControlValidator
from core.control.control_types import (
    CommandSource, ControlCommandStatus,
    LongitudinalMode, LongitudinalStatus, SteeringStatus,
    CONTROL_SCHEMA_VERSION,
)
from core.control.steering_controller import SteeringController, SteeringResult
from core.control.speed_controller import SpeedController, LongitudinalResult

from tests.control104.helpers import default_config


def _make_steering_result(
    angle: float = 0.0,
    rate: float = 0.0,
    limited: bool = False,
    rate_limited: bool = False,
    status: SteeringStatus = SteeringStatus.VALID,
) -> SteeringResult:
    return SteeringResult(
        steering_angle_rad  = angle,
        steering_rate_rad_s = rate,
        steering_limited    = limited,
        rate_limited        = rate_limited,
        status              = status,
        reason              = "",
    )


def _make_long_result(
    accel: float = 0.0,
    brake: float = 0.0,
    speed: float = 10.0,
    mode: LongitudinalMode = LongitudinalMode.COAST,
    accel_limited: bool = False,
    speed_limited: bool = False,
    status: LongitudinalStatus = LongitudinalStatus.VALID,
) -> LongitudinalResult:
    return LongitudinalResult(
        acceleration_mps2 = accel,
        brake_mps2        = brake,
        target_speed_mps  = speed,
        longitudinal_mode = mode,
        accel_limited     = accel_limited,
        speed_limited     = speed_limited,
        status            = status,
        reason            = "",
    )


class TestVehicleControlCommandFromResults:
    def test_basic_construction(self):
        s = _make_steering_result(0.1)
        l = _make_long_result(1.0)
        cmd = VehicleControlCommand.from_results(s, l)
        assert cmd.steering_angle_rad == 0.1
        assert cmd.acceleration_mps2 == 1.0
        assert cmd.schema_version == CONTROL_SCHEMA_VERSION

    def test_valid_overall_status(self):
        s = _make_steering_result(status=SteeringStatus.VALID)
        l = _make_long_result(status=LongitudinalStatus.VALID)
        cmd = VehicleControlCommand.from_results(s, l)
        assert cmd.status == ControlCommandStatus.VALID
        assert cmd.is_valid

    def test_limited_overall_status_from_steering(self):
        s = _make_steering_result(
            limited=True, status=SteeringStatus.LIMITED
        )
        l = _make_long_result(status=LongitudinalStatus.VALID)
        cmd = VehicleControlCommand.from_results(s, l)
        assert cmd.status == ControlCommandStatus.LIMITED
        assert cmd.is_valid  # LIMITED is still usable

    def test_no_solution_status(self):
        s = _make_steering_result(status=SteeringStatus.NO_MPC_SOLUTION)
        l = _make_long_result(status=LongitudinalStatus.VALID)
        cmd = VehicleControlCommand.from_results(s, l)
        assert cmd.status == ControlCommandStatus.NO_SOLUTION
        assert not cmd.is_valid

    def test_stale_status(self):
        s = _make_steering_result(status=SteeringStatus.STALE_MPC)
        l = _make_long_result(status=LongitudinalStatus.VALID)
        cmd = VehicleControlCommand.from_results(s, l)
        assert cmd.status == ControlCommandStatus.STALE

    def test_command_id_is_unique(self):
        s = _make_steering_result()
        l = _make_long_result()
        cmd1 = VehicleControlCommand.from_results(s, l)
        cmd2 = VehicleControlCommand.from_results(s, l)
        assert cmd1.command_id != cmd2.command_id

    def test_source_is_mpc(self):
        s = _make_steering_result()
        l = _make_long_result()
        cmd = VehicleControlCommand.from_results(s, l, source=CommandSource.MPC)
        assert cmd.source == CommandSource.MPC

    def test_has_braking_property(self):
        s = _make_steering_result()
        l = _make_long_result(accel=-3.0, brake=3.0,
                              mode=LongitudinalMode.BRAKE)
        cmd = VehicleControlCommand.from_results(s, l)
        assert cmd.has_braking

    def test_no_braking_on_accel(self):
        s = _make_steering_result()
        l = _make_long_result(accel=2.0, brake=0.0,
                              mode=LongitudinalMode.ACCELERATE)
        cmd = VehicleControlCommand.from_results(s, l)
        assert not cmd.has_braking

    def test_frozen(self):
        s = _make_steering_result()
        l = _make_long_result()
        cmd = VehicleControlCommand.from_results(s, l)
        try:
            object.__setattr__(cmd, "steering_angle_rad", 999.0)
            assert False, "Should have raised FrozenInstanceError"
        except Exception:
            pass  # frozen dataclass raises some error


class TestVehicleControlCommandFactories:
    def test_invalid_factory(self):
        cmd = VehicleControlCommand.invalid("test reason")
        assert cmd.status == ControlCommandStatus.NO_SOLUTION
        assert not cmd.is_valid
        assert len(cmd.reason_codes) > 0

    def test_stale_factory(self):
        cmd = VehicleControlCommand.stale("stale test")
        assert cmd.status == ControlCommandStatus.STALE
        assert not cmd.is_valid

    def test_zero_factory(self):
        cmd = VehicleControlCommand.zero()
        assert cmd.status == ControlCommandStatus.VALID
        assert cmd.steering_angle_rad == 0.0
        assert cmd.acceleration_mps2 == 0.0
        assert cmd.brake_mps2 == 0.0
        assert cmd.source == CommandSource.ZERO
        assert cmd.is_valid

    def test_repr(self):
        cmd = VehicleControlCommand.zero()
        s = repr(cmd)
        assert "VALID" in s or "status" in s.lower()


class TestCommandValidation:
    def _val(self):
        return ControlValidator(default_config())

    def test_valid_command_passes(self):
        s = _make_steering_result(0.1)
        l = _make_long_result(1.0, 0.0, 10.0)
        cmd = VehicleControlCommand.from_results(s, l)
        r = self._val().validate_command(cmd)
        assert r.valid

    def test_nan_steering_fails(self):
        cmd = VehicleControlCommand(
            steering_angle_rad=float("nan"),
            acceleration_mps2=0.0,
            brake_mps2=0.0,
            target_speed_mps=10.0,
            timestamp=time.monotonic(),
        )
        r = self._val().validate_command(cmd)
        assert not r.valid
        assert any("steering_angle_rad" in iss for iss in r.issues)

    def test_inf_acceleration_fails(self):
        cmd = VehicleControlCommand(
            steering_angle_rad=0.0,
            acceleration_mps2=float("inf"),
            brake_mps2=0.0,
            target_speed_mps=10.0,
            timestamp=time.monotonic(),
        )
        r = self._val().validate_command(cmd)
        assert not r.valid

    def test_nan_brake_fails(self):
        cmd = VehicleControlCommand(
            steering_angle_rad=0.0,
            acceleration_mps2=0.0,
            brake_mps2=float("nan"),
            target_speed_mps=10.0,
            timestamp=time.monotonic(),
        )
        r = self._val().validate_command(cmd)
        assert not r.valid

    def test_nan_target_speed_fails(self):
        cmd = VehicleControlCommand(
            steering_angle_rad=0.0,
            acceleration_mps2=0.0,
            brake_mps2=0.0,
            target_speed_mps=float("nan"),
            timestamp=time.monotonic(),
        )
        r = self._val().validate_command(cmd)
        assert not r.valid

    def test_steering_above_max_fails(self):
        cfg = default_config()
        cmd = VehicleControlCommand(
            steering_angle_rad=cfg.max_steering_rad + 0.1,
            acceleration_mps2=0.0,
            brake_mps2=0.0,
            target_speed_mps=10.0,
            timestamp=time.monotonic(),
        )
        r = ControlValidator(cfg).validate_command(cmd)
        assert not r.valid

    def test_steering_below_min_fails(self):
        cfg = default_config()
        cmd = VehicleControlCommand(
            steering_angle_rad=cfg.min_steering_rad - 0.1,
            acceleration_mps2=0.0,
            brake_mps2=0.0,
            target_speed_mps=10.0,
            timestamp=time.monotonic(),
        )
        r = ControlValidator(cfg).validate_command(cmd)
        assert not r.valid

    def test_negative_brake_fails(self):
        cmd = VehicleControlCommand(
            steering_angle_rad=0.0,
            acceleration_mps2=-2.0,
            brake_mps2=-1.0,
            target_speed_mps=5.0,
            timestamp=time.monotonic(),
        )
        r = self._val().validate_command(cmd)
        assert not r.valid

    def test_contradictory_accel_and_brake_fails(self):
        cfg = default_config()
        cmd = VehicleControlCommand(
            steering_angle_rad=0.0,
            acceleration_mps2=3.0,     # strong positive
            brake_mps2=3.0,             # strong braking
            target_speed_mps=10.0,
            timestamp=time.monotonic(),
        )
        r = ControlValidator(cfg).validate_command(cmd)
        assert not r.valid
        assert any("contradict" in iss.lower() for iss in r.issues)

    def test_negative_frame_id_fails(self):
        cmd = VehicleControlCommand(
            steering_angle_rad=0.0,
            acceleration_mps2=0.0,
            brake_mps2=0.0,
            target_speed_mps=10.0,
            timestamp=time.monotonic(),
            frame_id=-1,
        )
        r = self._val().validate_command(cmd)
        assert not r.valid

    def test_speed_above_max_fails(self):
        cfg = default_config()
        cmd = VehicleControlCommand(
            steering_angle_rad=0.0,
            acceleration_mps2=0.0,
            brake_mps2=0.0,
            target_speed_mps=cfg.max_speed_mps + 5.0,
            timestamp=time.monotonic(),
        )
        r = ControlValidator(cfg).validate_command(cmd)
        assert not r.valid
