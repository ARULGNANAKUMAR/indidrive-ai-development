"""
IndiDrive AI — Phase 10.4 | Tests: MPC Input Validation
=========================================================
Tests for ControlValidator.validate_mpc_snapshot().
"""
from __future__ import annotations

import math
import sys
import os
import time

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))

from core.control.control_validator import ControlValidator
from core.control.control_types import MPCFreshness
from core.control.mpc_types import MPCStatus

from tests.control104.helpers import (
    default_config,
    make_valid_snapshot,
    make_stale_snapshot,
    make_infeasible_snapshot,
    make_nan_steering_snapshot,
    make_inf_accel_snapshot,
)


def _val(cfg=None) -> ControlValidator:
    return ControlValidator(cfg or default_config())


class TestMPCInputNone:
    def test_none_snapshot_invalid(self):
        r = _val().validate_mpc_snapshot(None, time.monotonic())
        assert not r.valid
        assert r.freshness == MPCFreshness.UNKNOWN
        assert len(r.issues) > 0


class TestMPCInputValid:
    def test_valid_fresh_snapshot(self):
        snap = make_valid_snapshot()
        r = _val().validate_mpc_snapshot(snap, time.monotonic())
        assert r.valid
        assert r.freshness == MPCFreshness.FRESH
        assert len(r.issues) == 0

    def test_valid_is_repr_ok(self):
        snap = make_valid_snapshot()
        r = _val().validate_mpc_snapshot(snap, time.monotonic())
        assert "valid=True" in repr(r) or r.valid  # repr check


class TestMPCInputStale:
    def test_stale_snapshot_invalid(self):
        snap = make_stale_snapshot(age_s=2.0)
        r = _val().validate_mpc_snapshot(snap, time.monotonic())
        assert not r.valid
        assert r.freshness == MPCFreshness.STALE

    def test_just_stale_at_boundary(self):
        cfg = default_config()  # stale_timeout=0.5
        snap = make_stale_snapshot(age_s=0.51)
        r = ControlValidator(cfg).validate_mpc_snapshot(snap, time.monotonic())
        assert not r.valid
        assert r.freshness == MPCFreshness.STALE

    def test_within_timeout_fresh(self):
        cfg = default_config()
        snap = make_valid_snapshot(timestamp=time.monotonic() - 0.1)
        r = ControlValidator(cfg).validate_mpc_snapshot(snap, time.monotonic())
        assert r.valid
        assert r.freshness == MPCFreshness.FRESH


class TestMPCInputInfeasible:
    def test_infeasible_snapshot_invalid(self):
        snap = make_infeasible_snapshot()
        r = _val().validate_mpc_snapshot(snap, time.monotonic())
        assert not r.valid
        assert any("feasible" in issue.lower() or "infeasible" in issue.lower()
                   for issue in r.issues)

    def test_no_feasible_solution_status(self):
        snap = make_valid_snapshot(
            feasible=False,
            status=MPCStatus.NO_FEASIBLE_SOLUTION,
        )
        r = _val().validate_mpc_snapshot(snap, time.monotonic())
        assert not r.valid


class TestMPCInputNonFinite:
    def test_nan_steering_input_invalid(self):
        snap = make_nan_steering_snapshot()
        r = _val().validate_mpc_snapshot(snap, time.monotonic())
        assert not r.valid
        assert any("steering" in iss.lower() for iss in r.issues)

    def test_inf_accel_input_invalid(self):
        snap = make_inf_accel_snapshot()
        r = _val().validate_mpc_snapshot(snap, time.monotonic())
        assert not r.valid
        assert any("acceleration" in iss.lower() for iss in r.issues)


class TestMPCInputTimestamp:
    def test_non_finite_current_time(self):
        snap = make_valid_snapshot()
        r = _val().validate_mpc_snapshot(snap, float("nan"))
        assert not r.valid

    def test_backward_clock(self):
        """Snapshot timestamp in the future relative to current_time → stale."""
        snap = make_valid_snapshot(timestamp=time.monotonic() + 10.0)
        # current_time is now — snapshot is "from the future"
        r = _val().validate_mpc_snapshot(snap, time.monotonic())
        assert not r.valid
        assert r.freshness == MPCFreshness.STALE


class TestMPCInputStatus:
    def test_unknown_status_invalid(self):
        snap = make_valid_snapshot(status=MPCStatus.UNKNOWN)
        r = _val().validate_mpc_snapshot(snap, time.monotonic())
        assert not r.valid

    def test_degraded_status_may_be_usable(self):
        """DEGRADED with feasible=True should pass validation."""
        snap = make_valid_snapshot(status=MPCStatus.DEGRADED, feasible=True)
        r = _val().validate_mpc_snapshot(snap, time.monotonic())
        assert r.valid

    def test_solver_limit_reached_usable(self):
        snap = make_valid_snapshot(
            status=MPCStatus.SOLVER_LIMIT_REACHED, feasible=True
        )
        r = _val().validate_mpc_snapshot(snap, time.monotonic())
        assert r.valid


class TestControlValidatorInit:
    def test_wrong_config_raises(self):
        try:
            ControlValidator({"stale": 0.5})
            assert False, "Should have raised TypeError"
        except TypeError:
            pass
