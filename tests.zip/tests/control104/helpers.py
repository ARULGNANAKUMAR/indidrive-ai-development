"""
IndiDrive AI — Phase 10.4 | Test Helpers
=========================================
Shared test fixtures and snapshot builders for Phase 10.4 tests.
NOT a test file — imported by test_*.py files.
"""
from __future__ import annotations

import math
import time
import uuid
from typing import Optional, Tuple

from core.control.control_config import ControlConfig
from core.control.control_types import FallbackPolicy
from core.control.mpc_snapshot import MPCSnapshot
from core.control.mpc_types import MPCStatus, ConstraintStatus
from core.control.mpc_prediction import MPCControlInput, PredictionResult
from core.vehicle.vehicle_state import VehicleState
from core.vehicle.vehicle_types import CoordinateFrame, StateKind


# ---------------------------------------------------------------------------
# Default configs
# ---------------------------------------------------------------------------

def default_config() -> ControlConfig:
    return ControlConfig.default()


def tight_config() -> ControlConfig:
    """Config with narrow steering limits for saturation tests."""
    return ControlConfig(
        min_steering_rad        = -0.3,
        max_steering_rad        =  0.3,
        max_steering_rate_rad_s =  0.5,
        min_acceleration_mps2   = -5.0,
        max_acceleration_mps2   =  3.0,
        min_speed_mps           =  0.0,
        max_speed_mps           = 20.0,
        brake_threshold_mps2    =  0.1,
        max_brake_mps2          =  5.0,
        stale_timeout_s         =  0.5,
        fallback_policy         = FallbackPolicy.INVALID_COMMAND,
        safe_deceleration_mps2  = -2.0,
    )


# ---------------------------------------------------------------------------
# MPC snapshot builders
# ---------------------------------------------------------------------------

def make_ego_state(
    x: float = 0.0,
    y: float = 0.0,
    yaw: float = 0.0,
    velocity: float = 10.0,
    frame_id: int = 1,
    timestamp: float = 0.0,
) -> VehicleState:
    if timestamp == 0.0:
        timestamp = time.monotonic()
    return VehicleState(
        x=x, y=y, yaw=yaw, velocity=velocity,
        frame_id=frame_id, timestamp=timestamp,
    )


def make_control_input(
    steering: float = 0.0,
    acceleration: float = 0.0,
) -> MPCControlInput:
    return MPCControlInput(
        steering_input     = steering,
        acceleration_input = acceleration,
    )


def make_valid_snapshot(
    steering: float = 0.0,
    acceleration: float = 0.0,
    timestamp: Optional[float] = None,
    frame_id: int = 1,
    horizon: int = 5,
    feasible: bool = True,
    status: MPCStatus = MPCStatus.SUCCESS,
) -> MPCSnapshot:
    """Build a valid, fresh MPCSnapshot with given first-control inputs."""
    if timestamp is None:
        timestamp = time.monotonic()

    ego = make_ego_state(frame_id=frame_id)

    # Build minimal control sequence
    controls = tuple(
        make_control_input(steering, acceleration) for _ in range(horizon)
    )
    # Build minimal predicted states (ego replicated)
    states = tuple(ego for _ in range(horizon + 1))

    return MPCSnapshot(
        solution_id              = str(uuid.uuid4()),
        snap_timestamp           = timestamp,
        sim_timestamp            = ego.timestamp,
        frame_id                 = frame_id,
        schema_version           = "10.3",
        status                   = status,
        feasible                 = feasible,
        first_steering_input     = steering,
        first_acceleration_input = acceleration,
        horizon                  = horizon,
        dt                       = 0.1,
        predicted_states         = states,
        control_sequence         = controls,
        total_cost               = 1.0,
        tracking_cost            = 0.5,
        control_cost             = 0.3,
        rate_cost                = 0.1,
        terminal_cost            = 0.1,
        iterations               = 3,
        candidates_evaluated     = 27,
        constraint_status        = ConstraintStatus.SATISFIED,
        solver_message           = "OK",
    )


def make_stale_snapshot(
    age_s: float = 2.0,
    **kwargs,
) -> MPCSnapshot:
    """Build a snapshot with an old timestamp."""
    old_ts = time.monotonic() - age_s
    return make_valid_snapshot(timestamp=old_ts, **kwargs)


def make_infeasible_snapshot(**kwargs) -> MPCSnapshot:
    """Build an infeasible snapshot (no solution)."""
    return make_valid_snapshot(
        feasible=False,
        status=MPCStatus.NO_FEASIBLE_SOLUTION,
        **kwargs,
    )


def make_nan_steering_snapshot(**kwargs) -> MPCSnapshot:
    """Build a snapshot with NaN first_steering_input."""
    snap = make_valid_snapshot(steering=0.0, **kwargs)
    # Rebuild with NaN — frozen dataclass needs reconstruction
    return MPCSnapshot(
        solution_id              = snap.solution_id,
        snap_timestamp           = snap.snap_timestamp,
        sim_timestamp            = snap.sim_timestamp,
        frame_id                 = snap.frame_id,
        schema_version           = snap.schema_version,
        status                   = snap.status,
        feasible                 = snap.feasible,
        first_steering_input     = float("nan"),
        first_acceleration_input = snap.first_acceleration_input,
        horizon                  = snap.horizon,
        dt                       = snap.dt,
        predicted_states         = snap.predicted_states,
        control_sequence         = snap.control_sequence,
        total_cost               = snap.total_cost,
        tracking_cost            = snap.tracking_cost,
        control_cost             = snap.control_cost,
        rate_cost                = snap.rate_cost,
        terminal_cost            = snap.terminal_cost,
        iterations               = snap.iterations,
        candidates_evaluated     = snap.candidates_evaluated,
        constraint_status        = snap.constraint_status,
        solver_message           = snap.solver_message,
    )


def make_inf_accel_snapshot(**kwargs) -> MPCSnapshot:
    """Build a snapshot with inf first_acceleration_input."""
    snap = make_valid_snapshot(acceleration=0.0, **kwargs)
    return MPCSnapshot(
        solution_id              = snap.solution_id,
        snap_timestamp           = snap.snap_timestamp,
        sim_timestamp            = snap.sim_timestamp,
        frame_id                 = snap.frame_id,
        schema_version           = snap.schema_version,
        status                   = snap.status,
        feasible                 = snap.feasible,
        first_steering_input     = snap.first_steering_input,
        first_acceleration_input = float("inf"),
        horizon                  = snap.horizon,
        dt                       = snap.dt,
        predicted_states         = snap.predicted_states,
        control_sequence         = snap.control_sequence,
        total_cost               = snap.total_cost,
        tracking_cost            = snap.tracking_cost,
        control_cost             = snap.control_cost,
        rate_cost                = snap.rate_cost,
        terminal_cost            = snap.terminal_cost,
        iterations               = snap.iterations,
        candidates_evaluated     = snap.candidates_evaluated,
        constraint_status        = snap.constraint_status,
        solver_message           = snap.solver_message,
    )
