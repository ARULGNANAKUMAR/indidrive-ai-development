"""
IndiDrive AI — Phase 10.4 | Tests: Negative Scope
===================================================
Tests proving Phase 10.4 does NOT implement out-of-scope functionality.

These are structural assertions — they verify the absence of behaviour
that belongs to other phases or layers.
"""
from __future__ import annotations

import sys
import os
import types
import importlib

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))


class TestNoPathPlanning:
    def test_no_path_generation_in_control_package(self):
        """Control package must not contain path planning logic."""
        import core.control.control_manager as cm
        src = open(cm.__file__).read()
        forbidden = [
            "generate_path",
            "plan_path",
            "plan_trajectory",
            "A_star",
            "dijkstra",
        ]
        for word in forbidden:
            assert word not in src, (
                f"control_manager.py should not contain '{word}'"
            )

    def test_no_replanning_in_control_package(self):
        import core.control.control_manager as cm
        src = open(cm.__file__).read()
        assert "replan" not in src.lower() or "replanning" not in src.lower()


class TestNoObstacleDetection:
    def test_no_obstacle_detection_in_steering(self):
        import core.control.steering_controller as sc
        src = open(sc.__file__).read()
        forbidden = ["obstacle", "object_detect", "detect_object", "perception"]
        for word in forbidden:
            assert word not in src.lower(), (
                f"steering_controller.py should not contain '{word}'"
            )

    def test_no_obstacle_detection_in_speed(self):
        import core.control.speed_controller as sp
        src = open(sp.__file__).read()
        forbidden = ["obstacle", "object_detect", "detect_object", "perception"]
        for word in forbidden:
            assert word not in src.lower()


def _is_code_line(line: str) -> bool:
    """Return True if line is actual code (not a comment or docstring bullet)."""
    stripped = line.strip()
    return (
        stripped != ""
        and not stripped.startswith("#")
        and not stripped.startswith("*")
        and not stripped.startswith("\"\"\"")
        and not stripped.startswith("'")
        and not stripped.startswith(":")
    )


class TestNoAlternativeControllers:
    def test_no_pid_in_steering(self):
        import core.control.steering_controller as sc
        src = open(sc.__file__).read()
        # Only flag actual code lines — not docstring bullets or comments
        lines = [l for l in src.splitlines()
                 if "PID(" in l or "pid_controller" in l.lower()]
        assert len(lines) == 0, f"Found PID usage: {lines}"

    def test_no_pure_pursuit_in_steering(self):
        import core.control.steering_controller as sc
        src = open(sc.__file__).read()
        lines = [l for l in src.splitlines()
                 if "pure_pursuit(" in l.lower() or "PurePursuit(" in l]
        assert len(lines) == 0

    def test_no_stanley_in_manager(self):
        import core.control.control_manager as cm
        src = open(cm.__file__).read()
        lines = [l for l in src.splitlines()
                 if "stanley(" in l.lower() or "StanleyController(" in l]
        assert len(lines) == 0

    def test_no_lqr_in_speed(self):
        import core.control.speed_controller as sp
        src = open(sp.__file__).read()
        lines = [l for l in src.splitlines()
                 if "lqr(" in l.lower() or "LQRController(" in l]
        assert len(lines) == 0


class TestNoMPCOptimisation:
    def test_no_mpc_solver_in_manager(self):
        """ControlManager must not run MPC optimisation itself."""
        import core.control.control_manager as cm
        src = open(cm.__file__).read()
        forbidden = ["MPCSolver", "grid_search", "candidate_sequence"]
        for word in forbidden:
            assert word not in src, (
                f"control_manager.py should not contain '{word}'"
            )

    def test_no_mpc_solve_call_in_manager(self):
        import core.control.control_manager as cm
        src = open(cm.__file__).read()
        assert ".solve(" not in src


def _code_lines(src: str) -> list:
    """Return only actual code lines (skip comments and docstring content)."""
    in_docstring = False
    result = []
    for line in src.splitlines():
        stripped = line.strip()
        # Toggle docstring state
        if '"""' in stripped or "'''" in stripped:
            count = stripped.count('"""') + stripped.count("'''")
            if count % 2 != 0:
                in_docstring = not in_docstring
                continue  # the delimiter line itself is docstring
            elif in_docstring:
                continue
        if in_docstring:
            continue
        if stripped.startswith("#"):
            continue
        result.append(line)
    return result


class TestNoHardware:
    def test_no_can_bus(self):
        files = [
            "core/control/control_manager.py",
            "core/control/steering_controller.py",
            "core/control/speed_controller.py",
        ]
        for path in files:
            full = os.path.join(
                os.path.dirname(__file__), "..", "..", path
            )
            src = open(full).read()
            code = "\n".join(_code_lines(src)).lower()
            assert "can_bus" not in code, f"{path} references CAN bus in code"
            assert "can.send" not in code, f"{path} references CAN send"
            # "actuator" in docstrings is fine; flag only in actual code lines
            assert "actuator_command" not in code, f"{path} references actuator command"

    def test_no_carla_integration(self):
        files = [
            "core/control/control_manager.py",
            "core/control/steering_controller.py",
            "core/control/speed_controller.py",
            "core/control/control_snapshot.py",
        ]
        for path in files:
            full = os.path.join(
                os.path.dirname(__file__), "..", "..", path
            )
            src = open(full).read()
            code = "\n".join(_code_lines(src)).lower()
            # carla imports or direct API calls are not allowed
            assert "import carla" not in code, f"{path} imports CARLA"
            assert "carla.vehicle" not in code, f"{path} references CARLA vehicle"


class TestNoNetworkDependency:
    def test_no_network_calls_in_controllers(self):
        files = [
            "core/control/control_manager.py",
            "core/control/steering_controller.py",
            "core/control/speed_controller.py",
        ]
        forbidden = ["requests.get", "urllib.request", "http.client",
                     "socket.connect", "aiohttp"]
        for path in files:
            full = os.path.join(
                os.path.dirname(__file__), "..", "..", path
            )
            src = open(full).read()
            for word in forbidden:
                assert word not in src, f"{path} contains network call: {word}"


class TestNoScenarioHardcoding:
    def test_no_scenario_switch_in_manager(self):
        """No if/elif scenario-name-based logic in control pipeline."""
        import core.control.control_manager as cm
        src = open(cm.__file__).read()
        scenario_names = [
            "cattle", "market", "highway", "village",
            "narrow_road", "damaged_road", "merge",
        ]
        for name in scenario_names:
            # These words appearing as string comparisons would be bad
            # Acceptable in comments/docstrings; check for == comparisons
            lines = [l for l in src.splitlines()
                     if f'== "{name}"' in l or f"== '{name}'" in l]
            assert len(lines) == 0, (
                f"control_manager.py has hardcoded scenario: {name}"
            )

    def test_no_scenario_switch_in_speed_controller(self):
        import core.control.speed_controller as sp
        src = open(sp.__file__).read()
        scenario_names = ["cattle", "market", "highway", "village"]
        for name in scenario_names:
            lines = [l for l in src.splitlines()
                     if f'== "{name}"' in l or f"== '{name}'" in l]
            assert len(lines) == 0


class TestNoPlanner10_5Integration:
    def test_no_planner_integration_in_manager(self):
        """Phase 10.5 integration must not be in Phase 10.4."""
        import core.control.control_manager as cm
        src = open(cm.__file__).read()
        # Should not reference Phase 9.6 planner directly
        assert "FinalPlanner" not in src
        assert "Phase96" not in src

    def test_control_manager_does_not_call_mpc_controller(self):
        """ControlManager must not construct or call MPCController."""
        import core.control.control_manager as cm
        src = open(cm.__file__).read()
        assert "MPCController(" not in src
        assert "mpc_controller.solve" not in src


class TestNoNewAI:
    def test_no_llm_in_control(self):
        files = [
            "core/control/control_manager.py",
            "core/control/steering_controller.py",
            "core/control/speed_controller.py",
        ]
        forbidden = ["openai", "anthropic", "gpt", "llm", "neural_network",
                     "torch", "tensorflow", "keras"]
        for path in files:
            full = os.path.join(
                os.path.dirname(__file__), "..", "..", path
            )
            src = open(full).read().lower()
            for word in forbidden:
                assert word not in src, f"{path} references AI/ML: {word}"
