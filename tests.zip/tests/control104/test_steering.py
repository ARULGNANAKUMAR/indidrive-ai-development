"""
IndiDrive AI — Phase 10.4 | Tests: Steering Controller
========================================================
Tests for SteeringController and SteeringResult.
"""
from __future__ import annotations

import math
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))

from core.control.steering_controller import SteeringController, SteeringResult
from core.control.control_config import ControlConfig
from core.control.control_types import SteeringStatus

from tests.control104.helpers import default_config, tight_config


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _ctrl(cfg=None) -> SteeringController:
    return SteeringController(cfg or default_config())


def _deg(rad: float) -> float:
    return math.degrees(rad)


# ---------------------------------------------------------------------------
# Basic valid command
# ---------------------------------------------------------------------------

class TestSteeringValid:
    def test_zero_steering(self):
        result = _ctrl().compute(0.0, None, 0.1)
        assert result.steering_angle_rad == 0.0
        assert result.status == SteeringStatus.VALID
        assert result.is_valid

    def test_small_positive_steering(self):
        result = _ctrl().compute(0.2, None, 0.1)
        assert abs(result.steering_angle_rad - 0.2) < 1e-9
        assert result.status == SteeringStatus.VALID

    def test_small_negative_steering(self):
        result = _ctrl().compute(-0.2, None, 0.1)
        assert abs(result.steering_angle_rad + 0.2) < 1e-9
        assert result.status == SteeringStatus.VALID

    def test_result_is_valid_property(self):
        result = _ctrl().compute(0.1, None, 0.1)
        assert result.is_valid
        assert result.is_usable

    def test_no_saturation_flags_on_valid(self):
        result = _ctrl().compute(0.1, None, 0.1)
        assert not result.steering_limited
        assert not result.rate_limited


# ---------------------------------------------------------------------------
# Steering angle saturation — upper bound
# ---------------------------------------------------------------------------

class TestSteeringUpperBound:
    def test_exactly_at_max(self):
        cfg = default_config()
        result = _ctrl(cfg).compute(cfg.max_steering_rad, None, 0.1)
        assert abs(result.steering_angle_rad - cfg.max_steering_rad) < 1e-9
        assert result.status == SteeringStatus.VALID
        assert not result.steering_limited

    def test_above_max_is_clamped(self):
        cfg = default_config()
        excess = cfg.max_steering_rad + 0.5
        result = _ctrl(cfg).compute(excess, None, 0.1)
        assert abs(result.steering_angle_rad - cfg.max_steering_rad) < 1e-9
        assert result.steering_limited
        assert result.status == SteeringStatus.LIMITED

    def test_far_above_max(self):
        cfg = default_config()
        result = _ctrl(cfg).compute(math.pi, None, 0.1)
        assert abs(result.steering_angle_rad - cfg.max_steering_rad) < 1e-9
        assert result.steering_limited


# ---------------------------------------------------------------------------
# Steering angle saturation — lower bound
# ---------------------------------------------------------------------------

class TestSteeringLowerBound:
    def test_exactly_at_min(self):
        cfg = default_config()
        result = _ctrl(cfg).compute(cfg.min_steering_rad, None, 0.1)
        assert abs(result.steering_angle_rad - cfg.min_steering_rad) < 1e-9
        assert not result.steering_limited

    def test_below_min_is_clamped(self):
        cfg = default_config()
        excess = cfg.min_steering_rad - 0.5
        result = _ctrl(cfg).compute(excess, None, 0.1)
        assert abs(result.steering_angle_rad - cfg.min_steering_rad) < 1e-9
        assert result.steering_limited
        assert result.status == SteeringStatus.LIMITED

    def test_far_below_min(self):
        cfg = default_config()
        result = _ctrl(cfg).compute(-math.pi, None, 0.1)
        assert abs(result.steering_angle_rad - cfg.min_steering_rad) < 1e-9
        assert result.steering_limited


# ---------------------------------------------------------------------------
# Steering-rate limiting
# ---------------------------------------------------------------------------

class TestSteeringRateLimit:
    def _rate_cfg(self) -> ControlConfig:
        return ControlConfig(
            min_steering_rad        = -0.610,
            max_steering_rad        =  0.610,
            max_steering_rate_rad_s =  0.5,
            min_acceleration_mps2   = -8.0,
            max_acceleration_mps2   =  4.0,
            min_speed_mps           =  0.0,
            max_speed_mps           = 33.33,
            brake_threshold_mps2    =  0.05,
            max_brake_mps2          =  8.0,
            stale_timeout_s         =  0.5,
            fallback_policy         = __import__("core.control.control_types",
                                         fromlist=["FallbackPolicy"]).FallbackPolicy.INVALID_COMMAND,
            safe_deceleration_mps2  = -2.0,
        )

    def test_no_rate_limit_on_first_cycle(self):
        """No rate limiting when prev_steering is None."""
        cfg = self._rate_cfg()
        result = SteeringController(cfg).compute(0.5, None, 0.1)
        assert not result.rate_limited
        # Angle may still be limited by max_steering_rad if 0.5 > max
        # but rate should not be limited
        assert result.steering_rate_rad_s == 0.0

    def test_rate_limit_applied_positive(self):
        """Rapid positive steering change is rate-limited."""
        cfg = self._rate_cfg()
        # max_rate=0.5 rad/s, dt=0.1 s → max_delta=0.05 rad
        # request jump from 0.0 to 0.3 rad → 0.3 > 0.05 → rate limited
        result = SteeringController(cfg).compute(0.3, 0.0, 0.1)
        assert result.rate_limited
        assert abs(result.steering_angle_rad - 0.05) < 1e-9

    def test_rate_limit_applied_negative(self):
        """Rapid negative steering change is rate-limited."""
        cfg = self._rate_cfg()
        result = SteeringController(cfg).compute(-0.3, 0.0, 0.1)
        assert result.rate_limited
        assert abs(result.steering_angle_rad + 0.05) < 1e-9

    def test_no_rate_limit_when_within_rate(self):
        """Small change within rate limit passes through."""
        cfg = self._rate_cfg()
        # max_delta = 0.5 * 0.1 = 0.05; request 0.03 change → no limit
        result = SteeringController(cfg).compute(0.03, 0.0, 0.1)
        assert not result.rate_limited
        assert abs(result.steering_angle_rad - 0.03) < 1e-9

    def test_rate_limit_zero_dt(self):
        """Zero dt → no rate limiting applied (avoid divide-by-zero)."""
        cfg = self._rate_cfg()
        result = SteeringController(cfg).compute(0.3, 0.0, 0.0)
        assert not result.rate_limited
        assert result.steering_rate_rad_s == 0.0

    def test_rate_limit_negative_dt(self):
        """Negative dt → no rate limiting applied."""
        cfg = self._rate_cfg()
        result = SteeringController(cfg).compute(0.3, 0.0, -0.1)
        assert not result.rate_limited

    def test_steering_rate_computed_correctly(self):
        """steering_rate_rad_s = delta / dt when within rate limit."""
        cfg = self._rate_cfg()
        # within limit: delta=0.03 rad / dt=0.1 s → rate=0.3 rad/s
        result = SteeringController(cfg).compute(0.03, 0.0, 0.1)
        assert abs(result.steering_rate_rad_s - 0.3) < 1e-9

    def test_previous_steering_nan_no_rate_limit(self):
        """Non-finite prev_steering → no rate limiting."""
        cfg = self._rate_cfg()
        result = SteeringController(cfg).compute(0.3, float("nan"), 0.1)
        assert not result.rate_limited


# ---------------------------------------------------------------------------
# Invalid inputs
# ---------------------------------------------------------------------------

class TestSteeringInvalidInput:
    def test_nan_steering_rejected(self):
        result = _ctrl().compute(float("nan"), None, 0.1)
        assert result.status == SteeringStatus.INVALID_INPUT
        assert not result.is_valid
        assert result.steering_angle_rad == 0.0

    def test_inf_steering_rejected(self):
        result = _ctrl().compute(float("inf"), None, 0.1)
        assert result.status == SteeringStatus.INVALID_INPUT
        assert not result.is_valid

    def test_neg_inf_steering_rejected(self):
        result = _ctrl().compute(float("-inf"), None, 0.1)
        assert result.status == SteeringStatus.INVALID_INPUT
        assert not result.is_valid


# ---------------------------------------------------------------------------
# Wrong config type
# ---------------------------------------------------------------------------

class TestSteeringControllerInit:
    def test_wrong_config_type_raises(self):
        try:
            SteeringController({"min": -0.5})
            assert False, "Should have raised TypeError"
        except TypeError:
            pass


# ---------------------------------------------------------------------------
# Result properties
# ---------------------------------------------------------------------------

class TestSteeringResultProperties:
    def test_valid_result_is_usable(self):
        r = _ctrl().compute(0.1, None, 0.1)
        assert r.is_usable

    def test_invalid_result_not_usable(self):
        r = _ctrl().compute(float("nan"), None, 0.1)
        assert not r.is_usable

    def test_limited_result_is_valid(self):
        cfg = default_config()
        r = _ctrl(cfg).compute(cfg.max_steering_rad + 0.3, None, 0.1)
        assert r.is_valid
        assert r.status == SteeringStatus.LIMITED

    def test_rate_limited_result_is_valid(self):
        from core.control.control_types import FallbackPolicy
        cfg = ControlConfig(
            min_steering_rad=-0.610, max_steering_rad=0.610,
            max_steering_rate_rad_s=0.1,
            min_acceleration_mps2=-8.0, max_acceleration_mps2=4.0,
            min_speed_mps=0.0, max_speed_mps=33.33,
            brake_threshold_mps2=0.05, max_brake_mps2=8.0,
            stale_timeout_s=0.5, fallback_policy=FallbackPolicy.INVALID_COMMAND,
            safe_deceleration_mps2=-2.0,
        )
        r = SteeringController(cfg).compute(0.5, 0.0, 0.1)
        assert r.is_valid
        assert r.status == SteeringStatus.RATE_LIMITED

    def test_repr_contains_degrees(self):
        r = _ctrl().compute(0.0, None, 0.1)
        s = repr(r)
        assert "°" in s or "deg" in s.lower() or "0.0" in s
