"""
IndiDrive AI — Phase 10.4 | Tests: Control Manager
====================================================
Tests for ControlManager pipeline orchestration.
"""
from __future__ import annotations

import math
import sys
import os
import time

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))

from core.control.control_manager import ControlManager
from core.control.control_config import ControlConfig
from core.control.control_snapshot import VehicleControlCommand
from core.control.control_types import (
    CommandSource, ControlCommandStatus, FallbackPolicy,
    LongitudinalMode, SteeringStatus,
)

from tests.control104.helpers import (
    default_config, make_valid_snapshot, make_stale_snapshot,
    make_infeasible_snapshot, make_nan_steering_snapshot,
    make_inf_accel_snapshot,
)


def _manager(cfg=None) -> ControlManager:
    return ControlManager(cfg or default_config())


class TestControlManagerBasic:
    def test_step_valid_snapshot(self):
        m = _manager()
        snap = make_valid_snapshot(steering=0.1, acceleration=1.0)
        cmd = m.step(snap, 10.0, None, 0.1)
        assert cmd.is_valid
        assert cmd.source == CommandSource.MPC

    def test_step_zero_steering(self):
        m = _manager()
        snap = make_valid_snapshot(steering=0.0, acceleration=0.0)
        cmd = m.step(snap, 10.0, None, 0.1)
        assert abs(cmd.steering_angle_rad) < 1e-9
        assert cmd.is_valid

    def test_step_none_snapshot_returns_invalid(self):
        m = _manager()
        cmd = m.step(None, 10.0, None, 0.1)
        assert not cmd.is_valid

    def test_step_stale_snapshot_returns_stale(self):
        m = _manager()
        snap = make_stale_snapshot(age_s=2.0)
        cmd = m.step(snap, 10.0, None, 0.1, current_time=time.monotonic())
        assert not cmd.is_valid
        assert cmd.status in (ControlCommandStatus.STALE,
                               ControlCommandStatus.NO_SOLUTION,
                               ControlCommandStatus.INVALID)

    def test_step_infeasible_snapshot_returns_invalid(self):
        m = _manager()
        snap = make_infeasible_snapshot()
        cmd = m.step(snap, 10.0, None, 0.1)
        assert not cmd.is_valid

    def test_step_nan_steering_snapshot(self):
        m = _manager()
        snap = make_nan_steering_snapshot()
        cmd = m.step(snap, 10.0, None, 0.1)
        assert not cmd.is_valid

    def test_step_inf_accel_snapshot(self):
        m = _manager()
        snap = make_inf_accel_snapshot()
        cmd = m.step(snap, 10.0, None, 0.1)
        assert not cmd.is_valid

    def test_cycle_increments(self):
        m = _manager()
        assert m.cycle == 0
        snap = make_valid_snapshot()
        m.step(snap, 10.0, None, 0.1)
        assert m.cycle == 1
        m.step(snap, 10.0, None, 0.1)
        assert m.cycle == 2

    def test_previous_steering_updated(self):
        m = _manager()
        assert m.previous_steering_rad is None
        snap = make_valid_snapshot(steering=0.1)
        m.step(snap, 10.0, None, 0.1)
        # Previous steering should be set now
        assert m.previous_steering_rad is not None

    def test_reset_clears_state(self):
        m = _manager()
        snap = make_valid_snapshot(steering=0.2)
        m.step(snap, 10.0, None, 0.1)
        m.reset()
        assert m.previous_steering_rad is None
        assert m.previous_command is None

    def test_reset_does_not_reset_cycle(self):
        m = _manager()
        snap = make_valid_snapshot()
        m.step(snap, 10.0, None, 0.1)
        m.reset()
        assert m.cycle == 1  # cycle is monotonic


class TestControlManagerRateLimit:
    def test_steering_rate_limited_between_steps(self):
        from core.control.control_types import FallbackPolicy
        cfg = ControlConfig(
            min_steering_rad        = -0.610,
            max_steering_rad        =  0.610,
            max_steering_rate_rad_s =  0.1,   # very slow
            min_acceleration_mps2   = -8.0,
            max_acceleration_mps2   =  4.0,
            min_speed_mps           =  0.0,
            max_speed_mps           = 33.33,
            brake_threshold_mps2    =  0.05,
            max_brake_mps2          =  8.0,
            stale_timeout_s         =  1.0,
            fallback_policy         = FallbackPolicy.INVALID_COMMAND,
            safe_deceleration_mps2  = -2.0,
        )
        m = ControlManager(cfg)
        # First step: from 0.0 to 0.0 (prev=None → no rate limit)
        snap1 = make_valid_snapshot(steering=0.0, acceleration=0.0)
        m.step(snap1, 10.0, None, 0.1)
        # Second step: big steering jump
        snap2 = make_valid_snapshot(steering=0.5, acceleration=0.0)
        cmd2 = m.step(snap2, 10.0, None, 0.1)
        # max_delta = 0.1 * 0.1 = 0.01 rad; steering should be limited
        assert cmd2.rate_limited or abs(cmd2.steering_angle_rad) <= 0.01 + 1e-9


class TestControlManagerFallback:
    def test_hold_current_fallback(self):
        from core.control.control_types import FallbackPolicy
        cfg = ControlConfig(
            min_steering_rad=-0.610, max_steering_rad=0.610,
            max_steering_rate_rad_s=0.7,
            min_acceleration_mps2=-8.0, max_acceleration_mps2=4.0,
            min_speed_mps=0.0, max_speed_mps=33.33,
            brake_threshold_mps2=0.05, max_brake_mps2=8.0,
            stale_timeout_s=0.5,
            fallback_policy=FallbackPolicy.HOLD_CURRENT,
            safe_deceleration_mps2=-2.0,
        )
        m = ControlManager(cfg)
        # Step 1: get a valid command
        snap = make_valid_snapshot(steering=0.1, acceleration=1.0)
        cmd1 = m.step(snap, 10.0, None, 0.1)
        # Step 2: stale snapshot → should HOLD
        stale = make_stale_snapshot(age_s=2.0)
        cmd2 = m.step(stale, 10.0, None, 0.1, current_time=time.monotonic())
        # cmd2 should be the held previous command or at least not a new one
        # Under HOLD_CURRENT the manager returns the previous valid command
        assert cmd2.source == CommandSource.MPC or cmd2.source == CommandSource.HOLD

    def test_safe_decel_fallback(self):
        from core.control.control_types import FallbackPolicy
        cfg = ControlConfig(
            min_steering_rad=-0.610, max_steering_rad=0.610,
            max_steering_rate_rad_s=0.7,
            min_acceleration_mps2=-8.0, max_acceleration_mps2=4.0,
            min_speed_mps=0.0, max_speed_mps=33.33,
            brake_threshold_mps2=0.05, max_brake_mps2=8.0,
            stale_timeout_s=0.5,
            fallback_policy=FallbackPolicy.SAFE_DECELERATION,
            safe_deceleration_mps2=-2.0,
        )
        m = ControlManager(cfg)
        cmd = m.step(None, 10.0, None, 0.1)
        # Under SAFE_DECELERATION, should return a deceleration command
        assert cmd.acceleration_mps2 <= 0.0


class TestControlManagerInit:
    def test_wrong_config_type_raises(self):
        try:
            ControlManager({"enabled": True})
            assert False, "Should have raised TypeError"
        except TypeError:
            pass
