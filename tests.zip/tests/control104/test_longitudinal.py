"""
IndiDrive AI — Phase 10.4 | Tests: Speed / Longitudinal Controller
===================================================================
Tests for SpeedController, LongitudinalResult, and brake conversion.
"""
from __future__ import annotations

import math
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))

from core.control.speed_controller import SpeedController, LongitudinalResult
from core.control.control_config import ControlConfig
from core.control.control_types import LongitudinalMode, LongitudinalStatus, FallbackPolicy

from tests.control104.helpers import default_config, tight_config


def _ctrl(cfg=None) -> SpeedController:
    return SpeedController(cfg or default_config())


# ---------------------------------------------------------------------------
# Positive acceleration
# ---------------------------------------------------------------------------

class TestPositiveAcceleration:
    def test_positive_accel_valid(self):
        r = _ctrl().compute(2.0, 10.0, None, 0.1)
        assert r.acceleration_mps2 == 2.0
        assert r.status == LongitudinalStatus.VALID
        assert r.is_valid

    def test_positive_accel_no_brake(self):
        r = _ctrl().compute(2.0, 10.0, None, 0.1)
        assert r.brake_mps2 == 0.0

    def test_positive_accel_mode(self):
        r = _ctrl().compute(2.0, 10.0, None, 0.1)
        assert r.longitudinal_mode == LongitudinalMode.ACCELERATE

    def test_positive_accel_flags_clear(self):
        r = _ctrl().compute(1.0, 5.0, None, 0.1)
        assert not r.accel_limited
        assert not r.speed_limited


# ---------------------------------------------------------------------------
# Zero acceleration (coast)
# ---------------------------------------------------------------------------

class TestZeroAcceleration:
    def test_zero_accel_coast_mode(self):
        r = _ctrl().compute(0.0, 10.0, None, 0.1)
        assert r.longitudinal_mode == LongitudinalMode.COAST
        assert r.brake_mps2 == 0.0

    def test_zero_accel_valid(self):
        r = _ctrl().compute(0.0, 10.0, None, 0.1)
        assert r.is_valid


# ---------------------------------------------------------------------------
# Negative acceleration (deceleration / brake)
# ---------------------------------------------------------------------------

class TestNegativeAcceleration:
    def test_decelerate_below_threshold(self):
        """Small deceleration below threshold → DECELERATE mode, brake=0."""
        cfg = default_config()
        # brake_threshold = 0.05; use -0.02 → below threshold
        r = _ctrl(cfg).compute(-0.02, 10.0, None, 0.1)
        assert r.longitudinal_mode == LongitudinalMode.DECELERATE
        assert r.brake_mps2 == 0.0

    def test_decelerate_above_threshold(self):
        """Deceleration above threshold → BRAKE mode, brake>0."""
        cfg = default_config()
        r = _ctrl(cfg).compute(-2.0, 10.0, None, 0.1)
        assert r.longitudinal_mode == LongitudinalMode.BRAKE
        assert r.brake_mps2 > 0.0

    def test_brake_magnitude_equals_decel(self):
        """brake_mps2 should equal abs(acceleration) when within limits."""
        r = _ctrl().compute(-3.0, 10.0, None, 0.1)
        assert abs(r.brake_mps2 - 3.0) < 1e-9

    def test_brake_clamped_to_max(self):
        """Deceleration larger than max_brake → brake clamped."""
        cfg = default_config()  # max_brake=8.0
        r = _ctrl(cfg).compute(cfg.min_acceleration_mps2, 10.0, None, 0.1)
        # min_accel=-8.0, max_brake=8.0; exact boundary
        assert r.brake_mps2 <= cfg.max_brake_mps2 + 1e-9


# ---------------------------------------------------------------------------
# Acceleration saturation
# ---------------------------------------------------------------------------

class TestAccelerationSaturation:
    def test_above_max_accel_clamped(self):
        cfg = default_config()
        r = _ctrl(cfg).compute(cfg.max_acceleration_mps2 + 5.0, 10.0, None, 0.1)
        assert abs(r.acceleration_mps2 - cfg.max_acceleration_mps2) < 1e-9
        assert r.accel_limited
        assert r.status == LongitudinalStatus.LIMITED

    def test_below_min_accel_clamped(self):
        cfg = default_config()
        r = _ctrl(cfg).compute(cfg.min_acceleration_mps2 - 5.0, 10.0, None, 0.1)
        assert abs(r.acceleration_mps2 - cfg.min_acceleration_mps2) < 1e-9
        assert r.accel_limited

    def test_at_max_accel_not_limited(self):
        cfg = default_config()
        r = _ctrl(cfg).compute(cfg.max_acceleration_mps2, 10.0, None, 0.1)
        assert not r.accel_limited


# ---------------------------------------------------------------------------
# Speed limiting
# ---------------------------------------------------------------------------

class TestSpeedLimit:
    def test_ref_speed_within_limits(self):
        cfg = default_config()
        r = _ctrl(cfg).compute(0.0, 10.0, 15.0, 0.1)
        assert abs(r.target_speed_mps - 15.0) < 1e-9
        assert not r.speed_limited

    def test_ref_speed_above_max_clamped(self):
        cfg = default_config()  # max=33.33
        r = _ctrl(cfg).compute(0.0, 10.0, 100.0, 0.1)
        assert abs(r.target_speed_mps - cfg.max_speed_mps) < 1e-9
        assert r.speed_limited

    def test_ref_speed_zero(self):
        r = _ctrl().compute(0.0, 0.0, 0.0, 0.1)
        assert r.target_speed_mps == 0.0

    def test_no_ref_speed_integrates_velocity(self):
        """Without ref_speed, target is estimated from v + a*dt."""
        r = _ctrl().compute(2.0, 10.0, None, 0.1)
        # v + a*dt = 10 + 2*0.1 = 10.2
        assert abs(r.target_speed_mps - 10.2) < 1e-9


# ---------------------------------------------------------------------------
# Target speed generation
# ---------------------------------------------------------------------------

class TestTargetSpeed:
    def test_target_speed_finite(self):
        r = _ctrl().compute(1.0, 10.0, None, 0.1)
        assert math.isfinite(r.target_speed_mps)

    def test_target_speed_non_negative(self):
        # Even with strong braking from zero, target should be ≥ 0
        r = _ctrl().compute(-8.0, 0.0, None, 0.1)
        assert r.target_speed_mps >= 0.0

    def test_target_speed_uses_ref_first(self):
        """Ref speed takes priority over integration."""
        r = _ctrl().compute(3.0, 5.0, 12.0, 0.1)
        assert abs(r.target_speed_mps - 12.0) < 1e-9

    def test_target_speed_zero_dt_uses_current_vel(self):
        """When dt=0 and no ref_speed, target = current_vel bounded."""
        r = _ctrl().compute(2.0, 8.0, None, 0.0)
        assert abs(r.target_speed_mps - 8.0) < 1e-9


# ---------------------------------------------------------------------------
# Invalid inputs
# ---------------------------------------------------------------------------

class TestLongitudinalInvalidInput:
    def test_nan_accel_rejected(self):
        r = _ctrl().compute(float("nan"), 10.0, None, 0.1)
        assert r.status == LongitudinalStatus.INVALID_INPUT
        assert not r.is_valid

    def test_inf_accel_rejected(self):
        r = _ctrl().compute(float("inf"), 10.0, None, 0.1)
        assert r.status == LongitudinalStatus.INVALID_INPUT

    def test_neg_inf_accel_rejected(self):
        r = _ctrl().compute(float("-inf"), 10.0, None, 0.1)
        assert r.status == LongitudinalStatus.INVALID_INPUT

    def test_negative_velocity_handled(self):
        """Negative current velocity is invalid but should not crash."""
        r = _ctrl().compute(0.0, -5.0, None, 0.1)
        # Should still return a result (velocity defaulted to 0)
        assert math.isfinite(r.acceleration_mps2)
        assert math.isfinite(r.target_speed_mps)

    def test_nan_velocity_handled(self):
        r = _ctrl().compute(0.0, float("nan"), None, 0.1)
        assert math.isfinite(r.target_speed_mps)


# ---------------------------------------------------------------------------
# Brake consistency
# ---------------------------------------------------------------------------

class TestBrakeConsistency:
    def test_no_brake_during_acceleration(self):
        r = _ctrl().compute(2.0, 10.0, None, 0.1)
        assert r.brake_mps2 == 0.0

    def test_no_brake_during_coast(self):
        r = _ctrl().compute(0.0, 10.0, None, 0.1)
        assert r.brake_mps2 == 0.0

    def test_brake_only_negative_accel(self):
        r = _ctrl().compute(-3.0, 10.0, None, 0.1)
        assert r.acceleration_mps2 < 0
        assert r.brake_mps2 > 0

    def test_brake_non_negative(self):
        for a in [2.0, 0.0, -1.0, -5.0]:
            r = _ctrl().compute(a, 10.0, None, 0.1)
            assert r.brake_mps2 >= 0.0, f"brake negative for a={a}"

    def test_no_simultaneous_positive_accel_and_brake(self):
        """acceleration > 0 must never co-occur with brake_mps2 > 0."""
        for a in [0.1, 1.0, 2.0, 3.99]:
            r = _ctrl().compute(a, 5.0, None, 0.1)
            assert not (r.acceleration_mps2 > 0 and r.brake_mps2 > 0), (
                f"Contradictory: a={r.acceleration_mps2}, brake={r.brake_mps2}"
            )


# ---------------------------------------------------------------------------
# SpeedController init
# ---------------------------------------------------------------------------

class TestSpeedControllerInit:
    def test_wrong_config_type_raises(self):
        try:
            SpeedController({"min": -8.0})
            assert False, "Should have raised TypeError"
        except TypeError:
            pass


# ---------------------------------------------------------------------------
# Result properties
# ---------------------------------------------------------------------------

class TestLongitudinalResultProperties:
    def test_valid_is_usable(self):
        r = _ctrl().compute(1.0, 10.0, None, 0.1)
        assert r.is_usable

    def test_invalid_not_usable(self):
        r = _ctrl().compute(float("nan"), 10.0, None, 0.1)
        assert not r.is_usable

    def test_repr_contains_mps2(self):
        r = _ctrl().compute(1.0, 10.0, None, 0.1)
        s = repr(r)
        assert "m/s" in s or "mps" in s.lower() or "1.0" in s
