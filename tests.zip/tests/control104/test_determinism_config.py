"""
IndiDrive AI — Phase 10.4 | Tests: Determinism and Config
==========================================================
Tests for deterministic behaviour and ControlConfig.
"""
from __future__ import annotations

import math
import sys
import os
import time

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))

from core.control.control_config import ControlConfig
from core.control.control_types import FallbackPolicy
from core.control.steering_controller import SteeringController
from core.control.speed_controller import SpeedController
from core.control.control_manager import ControlManager
from core.control.control_snapshot import VehicleControlCommand

from tests.control104.helpers import (
    default_config, make_valid_snapshot, tight_config,
)


# ---------------------------------------------------------------------------
# ControlConfig tests
# ---------------------------------------------------------------------------

class TestControlConfig:
    def test_default_config_valid(self):
        cfg = ControlConfig.default()
        assert cfg.enabled
        assert cfg.min_steering_rad < 0
        assert cfg.max_steering_rad > 0
        assert cfg.max_steering_rate_rad_s > 0
        assert cfg.min_acceleration_mps2 < 0
        assert cfg.max_acceleration_mps2 > 0
        assert cfg.min_speed_mps >= 0
        assert cfg.max_speed_mps > 0
        assert cfg.brake_threshold_mps2 >= 0
        assert cfg.max_brake_mps2 > 0
        assert cfg.stale_timeout_s > 0
        assert cfg.safe_deceleration_mps2 <= 0

    def test_frozen_cannot_mutate(self):
        cfg = ControlConfig.default()
        try:
            object.__setattr__(cfg, "max_steering_rad", 999.0)
            assert False, "Should have raised FrozenInstanceError"
        except Exception:
            pass

    def test_invalid_min_steering_positive_raises(self):
        try:
            ControlConfig(min_steering_rad=0.1, max_steering_rad=0.610)
            assert False
        except ValueError:
            pass

    def test_invalid_max_steering_negative_raises(self):
        try:
            ControlConfig(min_steering_rad=-0.610, max_steering_rad=-0.1)
            assert False
        except ValueError:
            pass

    def test_invalid_steering_range_raises(self):
        try:
            ControlConfig(min_steering_rad=-0.1, max_steering_rad=-0.2)
            assert False
        except ValueError:
            pass

    def test_invalid_rate_zero_raises(self):
        try:
            ControlConfig(max_steering_rate_rad_s=0.0)
            assert False
        except ValueError:
            pass

    def test_invalid_min_accel_positive_raises(self):
        try:
            ControlConfig(min_acceleration_mps2=1.0)
            assert False
        except ValueError:
            pass

    def test_invalid_max_accel_negative_raises(self):
        try:
            ControlConfig(max_acceleration_mps2=-1.0)
            assert False
        except ValueError:
            pass

    def test_invalid_stale_timeout_zero_raises(self):
        try:
            ControlConfig(stale_timeout_s=0.0)
            assert False
        except ValueError:
            pass

    def test_invalid_safe_decel_positive_raises(self):
        try:
            ControlConfig(safe_deceleration_mps2=1.0)
            assert False
        except ValueError:
            pass

    def test_nan_field_raises(self):
        try:
            ControlConfig(max_steering_rad=float("nan"))
            assert False
        except ValueError:
            pass

    def test_inf_field_raises(self):
        try:
            ControlConfig(stale_timeout_s=float("inf"))
            assert False
        except ValueError:
            pass

    def test_from_dict_empty_gives_defaults(self):
        cfg = ControlConfig.from_dict({})
        default = ControlConfig.default()
        assert cfg.min_steering_rad == default.min_steering_rad
        assert cfg.max_steering_rad == default.max_steering_rad

    def test_from_dict_steering_section(self):
        d = {
            "steering": {
                "min_angle": -0.3,
                "max_angle": 0.3,
                "max_rate": 0.5,
            }
        }
        cfg = ControlConfig.from_dict(d)
        assert abs(cfg.min_steering_rad + 0.3) < 1e-9
        assert abs(cfg.max_steering_rad - 0.3) < 1e-9
        assert abs(cfg.max_steering_rate_rad_s - 0.5) < 1e-9

    def test_from_dict_fallback_policy_hold(self):
        d = {"fallback": {"policy": "HOLD_CURRENT"}}
        cfg = ControlConfig.from_dict(d)
        assert cfg.fallback_policy == FallbackPolicy.HOLD_CURRENT

    def test_from_dict_unknown_policy_defaults(self):
        d = {"fallback": {"policy": "BOGUS_POLICY"}}
        cfg = ControlConfig.from_dict(d)
        assert cfg.fallback_policy == FallbackPolicy.INVALID_COMMAND


# ---------------------------------------------------------------------------
# Determinism tests
# ---------------------------------------------------------------------------

class TestSteeringDeterminism:
    def test_same_inputs_same_output(self):
        ctrl = SteeringController(default_config())
        results = [
            ctrl.compute(0.2, 0.1, 0.1)
            for _ in range(5)
        ]
        first = results[0]
        for r in results[1:]:
            assert r.steering_angle_rad == first.steering_angle_rad
            assert r.steering_rate_rad_s == first.steering_rate_rad_s
            assert r.status == first.status
            assert r.steering_limited == first.steering_limited
            assert r.rate_limited == first.rate_limited

    def test_different_inputs_different_output(self):
        ctrl = SteeringController(default_config())
        r1 = ctrl.compute(0.1, None, 0.1)
        r2 = ctrl.compute(0.2, None, 0.1)
        assert r1.steering_angle_rad != r2.steering_angle_rad


class TestLongitudinalDeterminism:
    def test_same_inputs_same_output(self):
        ctrl = SpeedController(default_config())
        results = [
            ctrl.compute(1.5, 10.0, 15.0, 0.1)
            for _ in range(5)
        ]
        first = results[0]
        for r in results[1:]:
            assert r.acceleration_mps2 == first.acceleration_mps2
            assert r.brake_mps2 == first.brake_mps2
            assert r.target_speed_mps == first.target_speed_mps
            assert r.status == first.status

    def test_nan_input_always_invalid(self):
        ctrl = SpeedController(default_config())
        from core.control.control_types import LongitudinalStatus
        for _ in range(5):
            r = ctrl.compute(float("nan"), 10.0, None, 0.1)
            assert r.status == LongitudinalStatus.INVALID_INPUT


class TestManagerDeterminism:
    def test_same_inputs_same_steering(self):
        """Without rate-limiting state, same MPC input → same steering output."""
        cfg = default_config()
        results = []
        fixed_ts = 1000.0  # fixed timestamp for reproducibility
        for _ in range(3):
            m = ControlManager(cfg)  # fresh manager each time (no state)
            snap = make_valid_snapshot(steering=0.15, acceleration=1.0,
                                       timestamp=fixed_ts)
            cmd = m.step(snap, 10.0, 12.0, 0.1,
                         current_time=fixed_ts + 0.05)
            results.append(cmd.steering_angle_rad)
        assert len(set(results)) == 1  # all identical
