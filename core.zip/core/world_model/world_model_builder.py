"""
IndiDrive AI — Phase 7 | World Model Builder
=============================================
Aggregates outputs from Phases 1–6 into a compact WorldModelSnapshot.

Builder responsibilities:
  1. Accept upstream outputs (all optional — graceful partial support)
  2. Validate each input type
  3. Normalise into WorldModel types
  4. Merge objects by stable identifier (deduplication)
  5. Aggregate confidence / uncertainty / completeness / freshness
  6. Assemble and return a WorldModelSnapshot

Builder does NOT:
  * perform new perception
  * perform new prediction
  * control the vehicle
  * plan paths
  * invoke LLMs or cloud services
  * create new sensor drivers
  * duplicate Phase 1–6 logic

All thresholds come from WorldModelConfig — no magic numbers.
"""
from __future__ import annotations

import math
import time
from typing import Dict, List, Optional, Sequence, Tuple

from .world_model_config import WorldModelConfig
from .world_model_types import (
    NOT_AVAILABLE,
    CoordinateFrame,
    InputModuleStatus,
    ObjectObservationState,
    PredictionAvailability,
    RoadRepresentationStatus,
    WorldAnomalySummary,
    WorldBoundarySummary,
    WorldDataQuality,
    WorldDrivableSpaceInfo,
    WorldIndianContextSummary,
    WorldLaneInfo,
    WorldModelSnapshot,
    WorldModelStatus,
    WorldObject,
    WorldObjectCollisionInfo,
    WorldObjectDimensions,
    WorldObjectLifecycle,
    WorldObjectMotionSummary,
    WorldObjectPosition,
    WorldObjectPredictionSummary,
    WorldObjectQuality,
    WorldObjectVelocity,
    WorldRoadRepresentation,
)

__all__ = ["WorldModelBuilder"]

# Speed threshold below which an object is considered stationary.
_STATIONARY_SPEED_MS = 0.3


class WorldModelBuilder:
    """
    Deterministic, stateless builder that produces one WorldModelSnapshot
    per call to build().

    All arguments to build() are optional.  The builder produces a valid
    (possibly partial) snapshot regardless of which inputs are present.
    """

    def __init__(self, config: WorldModelConfig) -> None:
        self._cfg = config

    # ------------------------------------------------------------------
    # Main entry point
    # ------------------------------------------------------------------

    def build(
        self,
        *,
        fused_world_state=None,        # core.fusion.fusion_types.FusedWorldState
        prediction_state=None,         # core.prediction.prediction_types.PredictedWorldState
        collision_state=None,          # core.prediction.phase4d_types.Phase4DWorldState
        memory_context=None,           # core.memory.integration_types.MemoryContext
        road_understanding_state=None, # core.perception.road_understanding_state.RoadUnderstandingState
        ref_timestamp: Optional[float] = None,
        frame_id: int = 0,
    ) -> WorldModelSnapshot:
        """
        Build a WorldModelSnapshot from available upstream outputs.

        Parameters
        ----------
        fused_world_state:
            Phase 3 FusedWorldState — fused objects, road state.
        prediction_state:
            Phase 4A PredictedWorldState — trajectories and motion.
        collision_state:
            Phase 4D Phase4DWorldState — TTC, closest approach, risk levels.
        memory_context:
            Phase 5 MemoryContext — stable IDs, prototypes, experiences.
        road_understanding_state:
            Phase 6.5 RoadUnderstandingState — road, lanes, anomalies, context.
        ref_timestamp:
            Reference timestamp for this cycle; defaults to time.time().
        frame_id:
            Frame/cycle counter from the primary upstream source.

        Returns
        -------
        WorldModelSnapshot
            Always returned — never raises.  Partial when inputs are absent.
        """
        ts = ref_timestamp if ref_timestamp is not None else time.time()

        # ------------------------------------------------------------------
        # Step 1: Assess input module availability
        # ------------------------------------------------------------------
        module_status = self._assess_module_status(
            fused_world_state, prediction_state, collision_state,
            memory_context, road_understanding_state, ts,
        )

        # ------------------------------------------------------------------
        # Step 2: Build lookup maps from prediction / collision for fast join
        # ------------------------------------------------------------------
        pred_by_track: Dict[str, object] = {}
        if prediction_state is not None:
            for pobj in getattr(prediction_state, "objects", []):
                tid = getattr(pobj, "track_id", None)
                if tid:
                    pred_by_track[tid] = pobj

        collision_by_track: Dict[str, object] = {}
        if collision_state is not None:
            for cobj in getattr(collision_state, "objects", []):
                tid = getattr(cobj, "track_id", None)
                if tid:
                    collision_by_track[tid] = cobj

        memory_by_track: Dict[str, object] = {}
        if memory_context is not None:
            for mobj in getattr(memory_context, "objects", []):
                tid = getattr(mobj, "track_id", None)
                if tid:
                    memory_by_track[tid] = mobj

        # ------------------------------------------------------------------
        # Step 3: Build world objects from fused objects
        # ------------------------------------------------------------------
        raw_objects: List[WorldObject] = []
        fused_objects = []
        if fused_world_state is not None:
            fused_objects = getattr(fused_world_state, "objects", []) or []

        for fobj in fused_objects:
            wo = self._build_world_object(
                fobj, ts, pred_by_track, collision_by_track, memory_by_track
            )
            if wo is not None:
                raw_objects.append(wo)

        # ------------------------------------------------------------------
        # Step 4: Deduplicate objects
        # ------------------------------------------------------------------
        deduped = self._deduplicate_objects(raw_objects, ts)

        # ------------------------------------------------------------------
        # Step 5: Enforce max_objects limit (drop lowest-quality last)
        # ------------------------------------------------------------------
        if len(deduped) > self._cfg.max_objects:
            deduped = sorted(
                deduped,
                key=lambda o: o.quality.object_confidence,
                reverse=True,
            )[: self._cfg.max_objects]

        objects_tuple = tuple(deduped)

        # ------------------------------------------------------------------
        # Step 6: Build road representation
        # ------------------------------------------------------------------
        road = self._build_road_representation(road_understanding_state, ts)

        # ------------------------------------------------------------------
        # Step 7: Build Indian context summary
        # ------------------------------------------------------------------
        indian_ctx = self._build_indian_context(road_understanding_state)

        # ------------------------------------------------------------------
        # Step 8: Build data quality assessment
        # ------------------------------------------------------------------
        dq = self._build_data_quality(
            module_status, fused_world_state, prediction_state,
            road_understanding_state, objects_tuple, ts,
        )

        # ------------------------------------------------------------------
        # Step 9: Determine overall status
        # ------------------------------------------------------------------
        status = self._determine_status(dq, objects_tuple, road)

        # ------------------------------------------------------------------
        # Step 10: Assemble snapshot
        # ------------------------------------------------------------------
        snapshot = WorldModelSnapshot(
            schema_version="7.0",
            timestamp=ts,
            frame_id=frame_id,
            _objects=objects_tuple,
            road=road,
            indian_context=indian_ctx,
            data_quality=dq,
            status=status,
            coordinate_frame=CoordinateFrame.VEHICLE,
        )
        return snapshot

    # ------------------------------------------------------------------
    # Module status assessment
    # ------------------------------------------------------------------

    def _assess_module_status(
        self, fused, prediction, collision, memory, road, ref_ts: float
    ) -> Dict[str, InputModuleStatus]:
        """
        Determine InputModuleStatus for each upstream module.
        A module is STALE when its timestamp is too old.
        A module is UNAVAILABLE when it is None.
        """
        result: Dict[str, InputModuleStatus] = {}

        def _assess(obj, name: str) -> InputModuleStatus:
            if obj is None:
                return InputModuleStatus.UNAVAILABLE
            ts = getattr(obj, "timestamp", None)
            if ts is not None and isinstance(ts, (int, float)) and math.isfinite(ts):
                age = ref_ts - ts
                if age > self._cfg.max_data_age_seconds:
                    return InputModuleStatus.DEGRADED
            # Check health fields
            health = (
                getattr(obj, "fusion_health", None)
                or getattr(obj, "prediction_health", None)
                or getattr(obj, "status", None)
            )
            health_str = str(health.value if hasattr(health, "value") else health)
            if "FAIL" in health_str or "INVALID" in health_str:
                return InputModuleStatus.INVALID
            if "DEGRAD" in health_str or "PARTIAL" in health_str:
                return InputModuleStatus.DEGRADED
            return InputModuleStatus.OK

        result["fusion"] = _assess(fused, "fusion")
        result["prediction"] = _assess(prediction, "prediction")
        result["collision"] = _assess(collision, "collision")
        result["memory"] = _assess(memory, "memory")
        result["road_understanding"] = _assess(road, "road_understanding")
        # Indian context is embedded in road understanding
        result["indian_context"] = result["road_understanding"]
        return result

    # ------------------------------------------------------------------
    # World object construction
    # ------------------------------------------------------------------

    def _build_world_object(
        self,
        fobj,
        ref_ts: float,
        pred_by_track: Dict,
        collision_by_track: Dict,
        memory_by_track: Dict,
    ) -> Optional[WorldObject]:
        """Convert one FusedObject into a WorldObject."""
        try:
            return self._build_world_object_unsafe(
                fobj, ref_ts, pred_by_track, collision_by_track, memory_by_track
            )
        except Exception:
            # Never crash — return None to skip this object
            return None

    def _build_world_object_unsafe(
        self, fobj, ref_ts, pred_by_track, collision_by_track, memory_by_track
    ) -> WorldObject:
        """Inner builder without try/except — called within safety wrapper."""
        # --- Identity ---
        fused_id = getattr(fobj, "fused_object_id", None)
        track_id = getattr(fobj, "track_id", None)
        obj_ts = getattr(fobj, "timestamp", ref_ts) or ref_ts

        # --- Memory lookup for stable object_id ---
        memory_ref = memory_by_track.get(track_id) if track_id else None
        object_id = getattr(memory_ref, "memory_id", None) if memory_ref else None

        # --- Classification ---
        obj_class = getattr(fobj, "object_class", NOT_AVAILABLE) or NOT_AVAILABLE

        # --- Position ---
        pos3d = getattr(fobj, "position_3d", None)
        position = WorldObjectPosition()
        if pos3d is not None:
            px = getattr(pos3d, "x", None)
            py = getattr(pos3d, "y", None)
            pz = getattr(pos3d, "z", None)
            position.x = px if isinstance(px, (int, float)) and math.isfinite(px) else None
            position.y = py if isinstance(py, (int, float)) and math.isfinite(py) else None
            position.z = pz if isinstance(pz, (int, float)) and math.isfinite(pz) else None
            position.distance_m = position.compute_distance()

        heading = getattr(fobj, "heading", None)
        if heading is not None and isinstance(heading, (int, float)) and math.isfinite(heading):
            position.heading_rad = heading

        # --- Velocity ---
        vel_raw = getattr(fobj, "velocity", None)
        velocity = WorldObjectVelocity()
        if vel_raw is not None:
            try:
                vx, vy, vz = float(vel_raw[0]), float(vel_raw[1]), float(vel_raw[2])
                if all(math.isfinite(v) for v in (vx, vy, vz)):
                    velocity.vx = vx
                    velocity.vy = vy
                    velocity.vz = vz
                    velocity.speed_ms = math.sqrt(vx ** 2 + vy ** 2 + vz ** 2)
            except (TypeError, IndexError, ValueError):
                pass

        # --- Dimensions ---
        dims_raw = getattr(fobj, "dimensions", None)
        dimensions = WorldObjectDimensions()
        if dims_raw is not None:
            lv = getattr(dims_raw, "length", None)
            wv = getattr(dims_raw, "width", None)
            hv = getattr(dims_raw, "height", None)
            if isinstance(lv, (int, float)) and lv > 0 and math.isfinite(lv):
                dimensions.length_m = lv
            if isinstance(wv, (int, float)) and wv > 0 and math.isfinite(wv):
                dimensions.width_m = wv
            if isinstance(hv, (int, float)) and hv > 0 and math.isfinite(hv):
                dimensions.height_m = hv

        # --- Motion summary (enhanced from Phase 4 prediction) ---
        speed = velocity.speed_ms
        model_str = NOT_AVAILABLE

        pred_obj = pred_by_track.get(track_id) if track_id else None
        if pred_obj is not None:
            ps_raw = getattr(pred_obj, "current_state", None)
            if ps_raw is not None:
                s = getattr(ps_raw, "speed", None)
                if isinstance(s, (int, float)) and math.isfinite(s):
                    speed = s
            mt = getattr(pred_obj, "selected_model", None)
            model_str = (mt.value if hasattr(mt, "value") else str(mt)) or NOT_AVAILABLE

        motion = WorldObjectMotionSummary(
            is_moving=(speed is not None and speed > _STATIONARY_SPEED_MS),
            speed_ms=speed,
            yaw_rate_rads=(
                getattr(getattr(pred_obj, "current_state", None), "yaw_rate", None)
                if pred_obj is not None else None
            ),
            motion_model=model_str,
        )

        # --- Prediction summary ---
        prediction_summary = self._build_prediction_summary(pred_obj, track_id, collision_by_track)

        # --- Collision info ---
        collision_info = self._build_collision_info(collision_by_track.get(track_id) if track_id else None)

        # --- Quality ---
        fobj_ts = getattr(fobj, "timestamp", ref_ts) or ref_ts
        data_age = max(0.0, ref_ts - fobj_ts)
        is_stale = data_age > self._cfg.max_data_age_seconds

        lc_raw = getattr(fobj, "lifecycle_state", None)
        lc_str = (lc_raw.value if hasattr(lc_raw, "value") else str(lc_raw)) if lc_raw else ""

        if is_stale:
            obs_state = ObjectObservationState.STALE
        elif "LOST" in lc_str or "DELETED" in lc_str:
            obs_state = ObjectObservationState.PREDICTED
        elif "DEGRADED" in lc_str:
            obs_state = ObjectObservationState.DEGRADED
        else:
            obs_state = ObjectObservationState.OBSERVED

        # sensor source label
        from core.fusion.fusion_types import source_label
        src_sensors = getattr(fobj, "source_sensors", frozenset())
        src_label = source_label(src_sensors) if src_sensors else NOT_AVAILABLE

        quality = WorldObjectQuality(
            object_confidence=self._clamp01(getattr(fobj, "class_confidence", 0.0)),
            position_confidence=self._clamp01(getattr(fobj, "position_confidence", 0.0)),
            velocity_confidence=self._clamp01(getattr(fobj, "velocity_confidence", 0.0)),
            existence_probability=self._clamp01(getattr(fobj, "existence_probability", 0.0)),
            data_age_s=data_age,
            observation_state=obs_state,
            is_stale=is_stale,
            is_degraded="DEGRADED" in lc_str,
            source_sensors=src_label,
        )

        # --- Lifecycle ---
        wm_lifecycle_map = {
            "NEW": WorldObjectLifecycle.NEW,
            "CONFIRMED": WorldObjectLifecycle.ACTIVE,
            "FUSED": WorldObjectLifecycle.ACTIVE,
            "DEGRADED": WorldObjectLifecycle.STALE,
            "LOST": WorldObjectLifecycle.LOST,
            "REMOVED": WorldObjectLifecycle.REMOVED,
            "ACTIVE": WorldObjectLifecycle.ACTIVE,
        }
        lifecycle = wm_lifecycle_map.get(lc_str, WorldObjectLifecycle.ACTIVE)

        return WorldObject(
            object_id=object_id,
            track_id=track_id,
            fused_id=fused_id,
            object_type=obj_class,
            object_subtype=NOT_AVAILABLE,
            position=position,
            velocity=velocity,
            dimensions=dimensions,
            motion=motion,
            prediction=prediction_summary,
            collision=collision_info,
            quality=quality,
            lifecycle=lifecycle,
            observation_timestamp=obj_ts,
            coordinate_frame=CoordinateFrame.VEHICLE,
        )

    def _build_prediction_summary(
        self, pred_obj, track_id, collision_by_track
    ) -> WorldObjectPredictionSummary:
        """Build a bounded prediction summary from Phase 4A/4D data.

        Hypotheses come from Phase 4D collision_by_track and are populated
        regardless of whether Phase 4A prediction data (pred_obj) is present.
        """
        # Always gather hypotheses from Phase 4D collision state
        hypotheses_from_collision: List[dict] = []
        cobj_hyp = collision_by_track.get(track_id) if track_id else None
        if cobj_hyp is not None:
            hyp_risks = getattr(cobj_hyp, "hypothesis_risks", []) or []
            for hr in hyp_risks[: self._cfg.max_prediction_hypotheses]:
                hypotheses_from_collision.append({
                    "behaviour": getattr(hr, "behaviour", NOT_AVAILABLE),
                    "probability": round(float(getattr(hr, "probability", 0.0)), 6),
                    "collision_likelihood": round(float(getattr(hr, "collision_likelihood", 0.0)), 4),
                    "risk_level": (
                        getattr(hr, "risk_level").value
                        if hasattr(getattr(hr, "risk_level", None), "value")
                        else NOT_AVAILABLE
                    ),
                })

        if pred_obj is None:
            avail = (
                PredictionAvailability.PARTIAL if hypotheses_from_collision
                else PredictionAvailability.NONE
            )
            return WorldObjectPredictionSummary(
                availability=avail,
                hypotheses=hypotheses_from_collision,
            )

        conf = getattr(pred_obj, "prediction_confidence", 0.0) or 0.0
        uncertainty = dict(getattr(pred_obj, "uncertainty", {}) or {})
        mt = getattr(pred_obj, "selected_model", None)
        model_str = (mt.value if hasattr(mt, "value") else str(mt)) if mt else NOT_AVAILABLE

        # Trajectory — bounded
        raw_traj = getattr(pred_obj, "trajectory", []) or []
        trajectory: List[Tuple[float, float, float, float]] = []
        max_pts = self._cfg.max_trajectory_points
        for pt in raw_traj[:max_pts]:
            px = getattr(pt, "x", None)
            py = getattr(pt, "y", None)
            pz = getattr(pt, "z", 0.0)
            pt_ts = getattr(pt, "timestamp", 0.0)
            if px is not None and py is not None:
                trajectory.append((
                    float(px) if math.isfinite(float(px)) else 0.0,
                    float(py) if math.isfinite(float(py)) else 0.0,
                    float(pz) if isinstance(pz, (int, float)) and math.isfinite(float(pz)) else 0.0,
                    float(pt_ts) if isinstance(pt_ts, (int, float)) and math.isfinite(float(pt_ts)) else 0.0,
                ))

        # Horizon from last trajectory point
        horizon = 0.0
        if raw_traj:
            last = raw_traj[-1]
            h = getattr(last, "horizon_s", 0.0)
            if isinstance(h, (int, float)) and math.isfinite(h):
                horizon = h

        # Hypotheses already gathered above from collision_by_track
        availability = (
            PredictionAvailability.FULL if trajectory else PredictionAvailability.PARTIAL
        )

        return WorldObjectPredictionSummary(
            availability=availability,
            trajectory=trajectory,
            prediction_horizon_s=horizon,
            prediction_confidence=self._clamp01(conf),
            prediction_uncertainty=uncertainty,
            hypotheses=hypotheses_from_collision,
            motion_model=model_str,
        )

    def _build_collision_info(self, cobj) -> WorldObjectCollisionInfo:
        """Build collision info from one Phase4DObject."""
        if cobj is None:
            return WorldObjectCollisionInfo()

        # TTC
        ttc_raw = getattr(cobj, "ttc", None)
        ttc_s = None
        ttc_status = NOT_AVAILABLE
        closing_speed = None
        if ttc_raw is not None:
            ttc_s_raw = getattr(ttc_raw, "ttc_s", None)
            ttc_s = ttc_s_raw if isinstance(ttc_s_raw, (int, float)) and math.isfinite(ttc_s_raw) else None
            ttc_st = getattr(ttc_raw, "status", None)
            ttc_status = ttc_st.value if hasattr(ttc_st, "value") else str(ttc_st)
            cs_raw = getattr(ttc_raw, "closing_speed_ms", None)
            closing_speed = cs_raw if isinstance(cs_raw, (int, float)) and math.isfinite(cs_raw) else None

        # Closest approach
        ca = getattr(cobj, "closest_approach", None)
        min_dist = None
        tca = None
        if ca is not None:
            md_raw = getattr(ca, "minimum_distance_m", None)
            min_dist = md_raw if isinstance(md_raw, (int, float)) and math.isfinite(md_raw) else None
            tca_raw = getattr(ca, "time_of_closest_approach_s", None)
            tca = tca_raw if isinstance(tca_raw, (int, float)) and math.isfinite(tca_raw) else None

        # Risk
        cl_raw = getattr(cobj, "collision_likelihood", 0.0)
        cl = self._clamp01(cl_raw) if isinstance(cl_raw, (int, float)) else None
        rl_raw = getattr(cobj, "risk_level", None)
        risk_level = rl_raw.value if hasattr(rl_raw, "value") else NOT_AVAILABLE

        # Max hypothesis risk
        hyp_risks = getattr(cobj, "hypothesis_risks", []) or []
        max_hyp_risk = None
        if hyp_risks:
            try:
                max_hyp_risk = max(float(getattr(h, "collision_likelihood", 0.0)) for h in hyp_risks)
            except (TypeError, ValueError):
                pass

        return WorldObjectCollisionInfo(
            ttc_s=ttc_s,
            ttc_status=ttc_status,
            closing_speed_ms=closing_speed,
            min_distance_m=min_dist,
            time_of_closest_approach_s=tca,
            collision_likelihood=cl,
            risk_level=risk_level,
            max_hypothesis_risk=max_hyp_risk,
            predicted_conflict=(cl is not None and cl > 0.5),
        )

    # ------------------------------------------------------------------
    # Object deduplication
    # ------------------------------------------------------------------

    def _deduplicate_objects(
        self, objects: List[WorldObject], ref_ts: float
    ) -> List[WorldObject]:
        """
        Merge duplicate WorldObjects by stable identifier.

        Priority order (spec step 10):
          1. Stable object_id (memory)
          2. track_id
          3. fused_id
          4. Fallback: same object_type + position distance below threshold

        When two objects share the same primary_id, keep the one with the
        higher confidence (newer data preferred on tie).

        Fallback position-based merge is only used when ALL three IDs are
        absent.  Two objects are NOT merged solely because they share a type.
        """
        seen: Dict[str, int] = {}   # canonical_id -> index in result
        result: List[WorldObject] = []

        for obj in objects:
            pid = obj.primary_id()

            if pid is not None:
                if pid in seen:
                    # Merge — keep higher confidence
                    existing = result[seen[pid]]
                    if obj.quality.object_confidence > existing.quality.object_confidence:
                        result[seen[pid]] = obj
                    continue
                seen[pid] = len(result)
                result.append(obj)
            else:
                # Fallback: check for positional overlap with same type
                merged = False
                for i, existing in enumerate(result):
                    if existing.primary_id() is not None:
                        continue  # only fall through for no-ID objects
                    if existing.object_type != obj.object_type:
                        continue  # MUST NOT merge different types
                    if not self._position_close(existing, obj):
                        continue
                    if not self._timestamp_compatible(existing, obj):
                        continue
                    # Merge: keep higher confidence
                    if obj.quality.object_confidence > existing.quality.object_confidence:
                        result[i] = obj
                    merged = True
                    break
                if not merged:
                    result.append(obj)

        return result

    def _position_close(self, a: WorldObject, b: WorldObject) -> bool:
        """Return True when a and b are within merge distance."""
        ax, ay = a.position.x, a.position.y
        bx, by = b.position.x, b.position.y
        if None in (ax, ay, bx, by):
            return False
        try:
            d = math.sqrt((ax - bx) ** 2 + (ay - by) ** 2)
            return d < self._cfg.object_merge_distance_m
        except (TypeError, ValueError):
            return False

    def _timestamp_compatible(self, a: WorldObject, b: WorldObject) -> bool:
        """Return True when timestamps are within merge tolerance."""
        return (
            abs(a.observation_timestamp - b.observation_timestamp)
            < self._cfg.object_merge_time_tolerance_s
        )

    # ------------------------------------------------------------------
    # Road representation
    # ------------------------------------------------------------------

    def _build_road_representation(self, rus, ref_ts: float) -> WorldRoadRepresentation:
        """Build WorldRoadRepresentation from Phase 6.5 RoadUnderstandingState."""
        if rus is None:
            return WorldRoadRepresentation(
                status=RoadRepresentationStatus.NONE,
                is_degraded=True,
            )

        road_conf = float(getattr(rus, "overall_confidence", 0.0) or 0.0)
        road_unc = float(getattr(rus, "overall_uncertainty", 1.0) or 1.0)

        # Timestamp
        rus_ts = getattr(rus, "timestamp", 0.0) or 0.0

        # Drivable space (Phase 6.1)
        drivable_space = self._build_drivable_space(rus)

        # Lane info (Phase 6.2)
        lane_info = self._build_lane_info(rus)

        # Anomalies (Phase 6.3)
        anomalies = self._build_anomalies(rus)

        # Overall status
        valid = bool(getattr(rus, "valid", False))
        degraded = bool(getattr(rus, "degraded", True))

        if valid and not degraded:
            status = RoadRepresentationStatus.FULL
        elif valid or not degraded:
            status = RoadRepresentationStatus.PARTIAL
        elif degraded:
            status = RoadRepresentationStatus.DEGRADED
        else:
            status = RoadRepresentationStatus.NONE

        return WorldRoadRepresentation(
            status=status,
            drivable_space=drivable_space,
            lane_info=lane_info,
            anomalies=anomalies,
            road_confidence=self._clamp01(road_conf),
            road_uncertainty=max(0.0, road_unc),
            timestamp=rus_ts,
            is_degraded=degraded,
        )

    def _build_drivable_space(self, rus) -> WorldDrivableSpaceInfo:
        """Extract drivable space from Phase 6.1 state embedded in RUS."""
        da_state = getattr(rus, "drivable_area_state", None)
        if da_state is None:
            return WorldDrivableSpaceInfo(available=False)

        # Try to get road width and confidence from the state
        road_width = None
        da_conf = 0.0
        da_unc = 1.0
        is_deg = True

        # RoadUnderstanding (Phase 6.1) — access what's available
        try:
            road_width_raw = getattr(da_state, "road_width_m", None)
            if isinstance(road_width_raw, (int, float)) and math.isfinite(road_width_raw) and road_width_raw > 0:
                road_width = road_width_raw
        except Exception:
            pass

        try:
            da_conf = float(getattr(da_state, "confidence", 0.0) or 0.0)
            da_unc = float(getattr(da_state, "uncertainty", 1.0) or 1.0)
        except Exception:
            pass

        try:
            status_raw = getattr(da_state, "status", None)
            status_str = status_raw.value if hasattr(status_raw, "value") else str(status_raw)
            is_deg = "DEGRAD" in status_str or "UNAVAIL" in status_str
        except Exception:
            pass

        # Left/right boundary — compact summary only
        left_pts = self._extract_boundary_points(da_state, "left_boundary")
        right_pts = self._extract_boundary_points(da_state, "right_boundary")

        left_b = WorldBoundarySummary(
            available=bool(left_pts),
            points=left_pts[: self._cfg.max_boundary_points],
            confidence=da_conf,
            source="phase61",
        )
        right_b = WorldBoundarySummary(
            available=bool(right_pts),
            points=right_pts[: self._cfg.max_boundary_points],
            confidence=da_conf,
            source="phase61",
        )

        return WorldDrivableSpaceInfo(
            available=True,
            road_width_m=road_width,
            free_space_confidence=self._clamp01(da_conf),
            drivable_space_uncertainty=max(0.0, da_unc),
            left_boundary=left_b,
            right_boundary=right_b,
            coordinate_frame=CoordinateFrame.VEHICLE,
            is_degraded=is_deg,
            source="phase61",
        )

    def _extract_boundary_points(self, da_state, attr: str) -> list:
        """Safely extract boundary points from a road-understanding state."""
        from .world_model_types import WorldBoundaryPoint
        raw = getattr(da_state, attr, None)
        if raw is None:
            return []
        result = []
        pts = getattr(raw, "points", None) or (raw if isinstance(raw, (list, tuple)) else [])
        for pt in pts:
            try:
                px = float(getattr(pt, "x", 0.0))
                py = float(getattr(pt, "y", 0.0))
                pz = float(getattr(pt, "z", 0.0)) if hasattr(pt, "z") else 0.0
                pc = float(getattr(pt, "confidence", 0.0)) if hasattr(pt, "confidence") else 0.0
                if math.isfinite(px) and math.isfinite(py):
                    result.append(WorldBoundaryPoint(x=px, y=py, z=pz, confidence=pc))
            except Exception:
                pass
        return result

    def _build_lane_info(self, rus) -> WorldLaneInfo:
        """Extract compact lane info from Phase 6.2 state."""
        ls_state = getattr(rus, "lane_structure_state", None)
        summary = getattr(rus, "summary", None)

        if ls_state is None and summary is None:
            return WorldLaneInfo(available=False)

        # Prefer lane_structure_state if available, fall back to summary
        marking_state = NOT_AVAILABLE
        lane_count = None
        lane_width = None
        road_dir = NOT_AVAILABLE
        curv = NOT_AVAILABLE
        inter_state = NOT_AVAILABLE
        obs_inf = NOT_AVAILABLE
        conf = 0.0
        unc = 1.0
        is_deg = True

        if ls_state is not None:
            try:
                ms_raw = getattr(ls_state, "marking_status", None)
                marking_state = ms_raw.value if hasattr(ms_raw, "value") else str(ms_raw) if ms_raw else NOT_AVAILABLE
            except Exception:
                pass
            try:
                lc = getattr(ls_state, "lane_count", None)
                if isinstance(lc, int) and lc >= 0:
                    lane_count = lc
            except Exception:
                pass
            try:
                lw = getattr(ls_state, "lane_width_m", None)
                if isinstance(lw, (int, float)) and lw > 0 and math.isfinite(lw):
                    lane_width = lw
            except Exception:
                pass
            try:
                conf_raw = getattr(ls_state, "confidence", 0.0) or 0.0
                conf = float(conf_raw)
            except Exception:
                pass
            try:
                unc_raw = getattr(ls_state, "uncertainty", 1.0) or 1.0
                unc = float(unc_raw)
            except Exception:
                pass
            try:
                deg_raw = getattr(ls_state, "status", None)
                deg_str = deg_raw.value if hasattr(deg_raw, "value") else str(deg_raw)
                is_deg = "DEGRAD" in deg_str or "UNAVAIL" in deg_str
            except Exception:
                pass

        if summary is not None:
            if marking_state == NOT_AVAILABLE:
                ms = getattr(summary, "lane_marking_state", NOT_AVAILABLE)
                marking_state = ms if ms else NOT_AVAILABLE
            if lane_count is None:
                lc2 = getattr(summary, "lane_count", None)
                if isinstance(lc2, int) and lc2 >= 0:
                    lane_count = lc2
            inter_state = getattr(summary, "intersection_state", NOT_AVAILABLE) or NOT_AVAILABLE

        return WorldLaneInfo(
            available=True,
            marking_state=marking_state,
            lane_count=lane_count,
            lane_width_m=lane_width,
            road_direction=road_dir,
            curvature_summary=curv,
            intersection_state=inter_state,
            observed_vs_inferred=obs_inf,
            lane_confidence=self._clamp01(conf),
            lane_uncertainty=max(0.0, unc),
            is_degraded=is_deg,
        )

    def _build_anomalies(self, rus) -> List[WorldAnomalySummary]:
        """Extract bounded anomaly list from Phase 6.3 state."""
        ra_state = getattr(rus, "road_anomaly_state", None)
        if ra_state is None:
            return []

        raw_anomalies = getattr(ra_state, "anomalies", []) or []
        result: List[WorldAnomalySummary] = []
        max_a = self._cfg.max_anomalies

        for obs in raw_anomalies[:max_a]:
            try:
                a = self._build_single_anomaly(obs)
                if a is not None:
                    result.append(a)
            except Exception:
                pass

        return result

    def _build_single_anomaly(self, obs) -> Optional[WorldAnomalySummary]:
        """Convert one RoadAnomalyObservation into WorldAnomalySummary."""
        atype_raw = getattr(obs, "anomaly_type", None)
        atype = atype_raw.value if hasattr(atype_raw, "value") else str(atype_raw) if atype_raw else NOT_AVAILABLE

        sev_raw = getattr(obs, "severity", None)
        severity = sev_raw.value if hasattr(sev_raw, "value") else str(sev_raw) if sev_raw else NOT_AVAILABLE

        # Position from geometry
        geom = getattr(obs, "geometry", None)
        pos_x = pos_y = None
        approx_w = approx_l = None
        if geom is not None:
            cx = getattr(geom, "centroid_x", None) or getattr(geom, "x", None)
            cy = getattr(geom, "centroid_y", None) or getattr(geom, "y", None)
            if isinstance(cx, (int, float)) and math.isfinite(cx):
                pos_x = cx
            if isinstance(cy, (int, float)) and math.isfinite(cy):
                pos_y = cy
            w_raw = getattr(geom, "width_m", None)
            l_raw = getattr(geom, "length_m", None)
            if isinstance(w_raw, (int, float)) and w_raw > 0:
                approx_w = w_raw
            if isinstance(l_raw, (int, float)) and l_raw > 0:
                approx_l = l_raw

        conf = float(getattr(obs, "confidence", 0.0) or 0.0)
        unc = float(getattr(obs, "uncertainty", 1.0) or 1.0)

        driv_raw = getattr(obs, "drivability_impact", None)
        driv = driv_raw.value if hasattr(driv_raw, "value") else str(driv_raw) if driv_raw else NOT_AVAILABLE

        temp_raw = getattr(obs, "temporal_state", None)
        temp = temp_raw.value if hasattr(temp_raw, "value") else str(temp_raw) if temp_raw else NOT_AVAILABLE

        da_rel_raw = getattr(obs, "drivable_area_relation", None)
        in_da = da_rel_raw is not None and "INSIDE" in str(
            da_rel_raw.value if hasattr(da_rel_raw, "value") else str(da_rel_raw)
        )

        lane_rel_raw = getattr(obs, "lane_relation", None)
        in_lane = lane_rel_raw is not None and "INSIDE" in str(
            lane_rel_raw.value if hasattr(lane_rel_raw, "value") else str(lane_rel_raw)
        )

        # anomaly_id
        aid = getattr(obs, "anomaly_id", NOT_AVAILABLE) or NOT_AVAILABLE

        return WorldAnomalySummary(
            anomaly_id=aid,
            anomaly_type=atype,
            position_x=pos_x,
            position_y=pos_y,
            approximate_width_m=approx_w,
            approximate_length_m=approx_l,
            severity=severity,
            drivability_impact=driv,
            confidence=self._clamp01(conf),
            uncertainty=max(0.0, unc),
            temporal_stability=temp,
            in_drivable_area=in_da,
            in_lane_corridor=in_lane,
        )

    # ------------------------------------------------------------------
    # Indian context
    # ------------------------------------------------------------------

    def _build_indian_context(self, rus) -> WorldIndianContextSummary:
        """Build WorldIndianContextSummary from Phase 6.4 state."""
        if rus is None:
            return WorldIndianContextSummary(available=False, is_degraded=True)

        ctx_state = getattr(rus, "indian_context_state", None)
        summary = getattr(rus, "summary", None)

        # Indian context is only "available" when the actual Phase 6.4
        # state is present.  The summary alone is NOT sufficient —
        # summary carries aggregated road data, not Indian-specific context.
        if ctx_state is None:
            return WorldIndianContextSummary(available=False, is_degraded=True)

        if ctx_state is None and summary is None:
            return WorldIndianContextSummary(available=False, is_degraded=True)

        def _enum_val(obj, attr):
            v = getattr(obj, attr, None) if obj else None
            return v.value if hasattr(v, "value") else str(v) if v else NOT_AVAILABLE

        road_type = _enum_val(ctx_state, "road_type") if ctx_state else _enum_val(summary, "road_type")
        traffic_density = (
            _enum_val(ctx_state, "traffic_density")
            if ctx_state else _enum_val(summary, "traffic_density")
        )
        road_complexity = (
            _enum_val(ctx_state, "road_complexity")
            if ctx_state else _enum_val(summary, "road_complexity")
        )

        # Traffic mix compact label
        traffic_mix = NOT_AVAILABLE
        if ctx_state is not None:
            tm = getattr(ctx_state, "traffic_mix_summary", None) or getattr(ctx_state, "traffic_mix", None)
            if tm is not None:
                traffic_mix = str(tm.to_dict() if hasattr(tm, "to_dict") else tm)[:120]

        # Flags
        cattle = False
        vru = False
        market = False
        roadside = NOT_AVAILABLE
        inter_ctx = NOT_AVAILABLE
        stability = NOT_AVAILABLE
        unusual: List[str] = []
        conf = 0.0
        unc = 1.0
        is_deg = True

        if ctx_state is not None:
            try:
                aa_raw = getattr(ctx_state, "animal_activity", None)
                aa_str = aa_raw.value if hasattr(aa_raw, "value") else str(aa_raw) if aa_raw else ""
                cattle = "CATTLE" in aa_str or "ACTIVE" in aa_str
            except Exception:
                pass
            try:
                vru_raw = getattr(ctx_state, "vru_presence", None)
                vru_str = vru_raw.value if hasattr(vru_raw, "value") else str(vru_raw) if vru_raw else ""
                vru = "HIGH" in vru_str or "PRESENT" in vru_str or "MANY" in vru_str
            except Exception:
                pass
            try:
                rs_raw = getattr(ctx_state, "roadside_activity", None)
                if rs_raw is not None:
                    rs_obj = getattr(rs_raw, "market_like", None)
                    market = bool(rs_obj)
                    roadside = str(rs_raw.to_dict() if hasattr(rs_raw, "to_dict") else rs_raw)[:80]
            except Exception:
                pass
            try:
                ic_raw = getattr(ctx_state, "intersection_context", None)
                inter_ctx = ic_raw.value if hasattr(ic_raw, "value") else str(ic_raw) if ic_raw else NOT_AVAILABLE
            except Exception:
                pass
            try:
                st_raw = getattr(ctx_state, "context_stability", None)
                stability = st_raw.value if hasattr(st_raw, "value") else str(st_raw) if st_raw else NOT_AVAILABLE
            except Exception:
                pass
            try:
                flags_raw = getattr(ctx_state, "context_flags", None) or []
                unusual = [
                    (f.value if hasattr(f, "value") else str(f))
                    for f in flags_raw
                    if f is not None
                ][:10]
            except Exception:
                pass
            try:
                conf = float(getattr(ctx_state, "confidence", 0.0) or 0.0)
                unc = float(getattr(ctx_state, "uncertainty", 1.0) or 1.0)
            except Exception:
                pass
            try:
                deg_raw = getattr(ctx_state, "status", None)
                deg_str = deg_raw.value if hasattr(deg_raw, "value") else str(deg_raw)
                is_deg = "DEGRAD" in deg_str or "UNAVAIL" in deg_str or "FAIL" in deg_str
            except Exception:
                pass

        # summary fallback
        if summary is not None:
            if not cattle and not vru:
                cattle = bool(getattr(summary, "animal_present", False))
                vru_s = getattr(summary, "vru_presence", NOT_AVAILABLE) or ""
                vru = "HIGH" in vru_s or "PRESENT" in vru_s

        # Urban/rural class from road_type
        urban_rural = NOT_AVAILABLE
        if road_type != NOT_AVAILABLE:
            rt_upper = road_type.upper()
            if "URBAN" in rt_upper or "CITY" in rt_upper:
                urban_rural = "URBAN"
            elif "RURAL" in rt_upper or "VILLAGE" in rt_upper:
                urban_rural = "RURAL"
            elif "HIGHWAY" in rt_upper or "EXPRESSWAY" in rt_upper:
                urban_rural = "HIGHWAY_LIKE"

        return WorldIndianContextSummary(
            available=True,
            road_type=road_type,
            urban_rural_class=urban_rural,
            traffic_density=traffic_density,
            traffic_mix=traffic_mix,
            vulnerable_road_users=vru,
            cattle_present=cattle,
            roadside_activity=roadside,
            market_like_activity=market,
            intersection_context=inter_ctx,
            unusual_road_indicators=unusual,
            road_complexity=road_complexity,
            context_stability=stability,
            context_confidence=self._clamp01(conf),
            context_uncertainty=max(0.0, unc),
            is_degraded=is_deg,
        )

    # ------------------------------------------------------------------
    # Data quality
    # ------------------------------------------------------------------

    def _build_data_quality(
        self,
        module_status: Dict[str, InputModuleStatus],
        fused, prediction, road_understanding, objects, ref_ts: float,
    ) -> WorldDataQuality:
        """
        Aggregate confidence, uncertainty, completeness, freshness.

        Formula is documented here — not hidden:
          completeness = (available modules) / (total expected modules)
          freshness = 1 - clamp(0, 1, avg_age / max_data_age)
          overall_confidence = weighted average of object/road/prediction conf
          overall_uncertainty = base + stale_penalty * n_stale + missing_penalty * n_missing
        """
        cfg = self._cfg

        # Module availability counts
        expected_modules = ("fusion", "prediction", "road_understanding")
        available = sum(
            1 for k in expected_modules
            if module_status.get(k) in (InputModuleStatus.OK, InputModuleStatus.DEGRADED)
        )
        completeness = available / len(expected_modules) if expected_modules else 0.0

        # Freshness: average data age across available modules
        ages = []
        for m in [fused, prediction, road_understanding]:
            if m is None:
                continue
            ts = getattr(m, "timestamp", None)
            if isinstance(ts, (int, float)) and math.isfinite(ts) and ts > 0:
                ages.append(max(0.0, ref_ts - ts))
        avg_age = sum(ages) / len(ages) if ages else cfg.max_data_age_seconds
        freshness = max(0.0, 1.0 - avg_age / cfg.max_data_age_seconds)
        freshness = min(1.0, freshness)

        # Object confidence (mean of top objects)
        obj_confs = [o.quality.object_confidence for o in objects if o is not None]
        avg_obj_conf = sum(obj_confs) / len(obj_confs) if obj_confs else 0.0

        # Road confidence
        road_conf = 0.0
        if road_understanding is not None:
            road_conf = float(getattr(road_understanding, "overall_confidence", 0.0) or 0.0)

        # Prediction confidence (mean)
        pred_confs = []
        if prediction is not None:
            for po in getattr(prediction, "objects", []) or []:
                c = getattr(po, "prediction_confidence", 0.0) or 0.0
                pred_confs.append(float(c))
        avg_pred_conf = sum(pred_confs) / len(pred_confs) if pred_confs else 0.0

        # Weighted overall confidence
        overall_conf = (
            cfg.confidence_object_weight * avg_obj_conf
            + cfg.confidence_road_weight * road_conf
            + cfg.confidence_prediction_weight * avg_pred_conf
        )
        overall_conf = self._clamp01(overall_conf)

        # Uncertainty — additive penalties
        n_stale = sum(
            1 for s in module_status.values()
            if s == InputModuleStatus.DEGRADED
        )
        n_missing = sum(
            1 for k in expected_modules
            if module_status.get(k) == InputModuleStatus.UNAVAILABLE
        )
        n_degraded = sum(
            1 for s in module_status.values()
            if s == InputModuleStatus.DEGRADED
        )
        base_unc = 1.0 - overall_conf
        uncertainty = (
            base_unc
            + cfg.uncertainty_stale_penalty * n_stale
            + cfg.uncertainty_missing_module_penalty * n_missing
            + cfg.uncertainty_degraded_module_penalty * n_degraded
        )
        uncertainty = max(0.0, min(2.0, uncertainty))  # cap at 2.0 for sanity

        # Accumulate warnings
        warnings: List[str] = []
        for name, s in module_status.items():
            if s == InputModuleStatus.UNAVAILABLE:
                warnings.append(f"module {name} is UNAVAILABLE")
            elif s == InputModuleStatus.DEGRADED:
                warnings.append(f"module {name} is DEGRADED (stale data)")
            elif s == InputModuleStatus.INVALID:
                warnings.append(f"module {name} is INVALID")

        is_partial = completeness < 1.0

        return WorldDataQuality(
            overall_confidence=overall_conf,
            overall_uncertainty=uncertainty,
            completeness=completeness,
            freshness=freshness,
            perception_status=module_status.get("perception", InputModuleStatus.UNAVAILABLE),
            fusion_status=module_status.get("fusion", InputModuleStatus.UNAVAILABLE),
            prediction_status=module_status.get("prediction", InputModuleStatus.UNAVAILABLE),
            memory_status=module_status.get("memory", InputModuleStatus.UNAVAILABLE),
            road_understanding_status=module_status.get("road_understanding", InputModuleStatus.UNAVAILABLE),
            indian_context_status=module_status.get("indian_context", InputModuleStatus.UNAVAILABLE),
            is_partial=is_partial,
            warnings=warnings,
        )

    # ------------------------------------------------------------------
    # Overall status
    # ------------------------------------------------------------------

    def _determine_status(
        self,
        dq: WorldDataQuality,
        objects: tuple,
        road: WorldRoadRepresentation,
    ) -> WorldModelStatus:
        """
        Determine overall WorldModelStatus from data quality.

        Logic (documented — not hidden):
          EMPTY    — no objects AND road is NONE/DEGRADED AND completeness ~ 0
          OK       — completeness >= 1.0 AND confidence >= 0.5 AND not degraded
          PARTIAL  — completeness >= 0.3 OR some objects present
          DEGRADED — completeness < 0.3 AND some data present
        """
        if dq.completeness < 0.01 and len(objects) == 0 and road.status in (
            RoadRepresentationStatus.NONE,
            RoadRepresentationStatus.DEGRADED,
        ):
            return WorldModelStatus.EMPTY

        if (
            dq.completeness >= 1.0
            and dq.overall_confidence >= 0.5
            and not dq.is_partial
        ):
            return WorldModelStatus.OK

        if dq.completeness >= 0.3 or len(objects) > 0:
            return WorldModelStatus.PARTIAL

        return WorldModelStatus.DEGRADED

    # ------------------------------------------------------------------
    # Utilities
    # ------------------------------------------------------------------

    @staticmethod
    def _clamp01(v) -> float:
        """Clamp a numeric value to [0, 1]."""
        if not isinstance(v, (int, float)) or not math.isfinite(v):
            return 0.0
        return max(0.0, min(1.0, float(v)))
