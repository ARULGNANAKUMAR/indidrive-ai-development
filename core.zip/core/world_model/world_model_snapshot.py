"""
IndiDrive AI — Phase 7 | World Model Snapshot Utilities
=========================================================
Helpers for working with immutable WorldModelSnapshot objects.

Provides:
  - Snapshot comparison / diff summary
  - Compact serialisation (to JSON string)
  - Snapshot age check
  - Safe copy (for tests and diagnostics)
"""
from __future__ import annotations

import copy
import json
import time
from typing import Optional

from .world_model_types import WorldModelSnapshot, WorldModelStatus

__all__ = [
    "snapshot_age_s",
    "is_snapshot_stale",
    "snapshot_to_json",
    "snapshot_summary",
    "safe_copy_snapshot",
]


def snapshot_age_s(snapshot: WorldModelSnapshot, ref_ts: Optional[float] = None) -> float:
    """Return the age of a snapshot in seconds (from its timestamp to ref_ts)."""
    ref = ref_ts if ref_ts is not None else time.time()
    return max(0.0, ref - snapshot.timestamp)


def is_snapshot_stale(snapshot: WorldModelSnapshot, max_age_s: float) -> bool:
    """Return True when the snapshot is older than max_age_s."""
    return snapshot_age_s(snapshot) > max_age_s


def snapshot_to_json(snapshot: WorldModelSnapshot, indent: Optional[int] = None) -> str:
    """Serialise a snapshot to a JSON string.  Sorted keys for determinism."""
    return json.dumps(snapshot.to_dict(), sort_keys=True, indent=indent)


def snapshot_summary(snapshot: WorldModelSnapshot) -> dict:
    """Return a compact human-readable summary dict — useful for logging."""
    return {
        "schema_version": snapshot.schema_version,
        "timestamp": round(snapshot.timestamp, 3),
        "frame_id": snapshot.frame_id,
        "status": snapshot.status.value,
        "object_count": snapshot.object_count,
        "moving_objects": len(snapshot.moving_objects()),
        "high_risk_objects": len(snapshot.high_risk_objects()),
        "road_status": snapshot.road.status.value,
        "anomaly_count": snapshot.road.anomaly_count,
        "has_critical_anomaly": snapshot.road.has_critical_anomaly,
        "indian_context_available": snapshot.indian_context.available,
        "overall_confidence": round(snapshot.data_quality.overall_confidence, 3),
        "overall_uncertainty": round(snapshot.data_quality.overall_uncertainty, 3),
        "completeness": round(snapshot.data_quality.completeness, 3),
        "freshness": round(snapshot.data_quality.freshness, 3),
        "is_partial": snapshot.data_quality.is_partial,
    }


def safe_copy_snapshot(snapshot: WorldModelSnapshot) -> WorldModelSnapshot:
    """Return a deep copy of a snapshot — safe for diagnostic use.

    Note: In production the snapshot should be treated as immutable.
    This copy is intended for test comparison and diagnostics only.
    """
    return copy.deepcopy(snapshot)
