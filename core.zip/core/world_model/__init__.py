"""
IndiDrive AI — Phase 7 | World Model Package
=============================================
Public interface for the Phase 7 World Model.

Quick start
-----------
    from core.world_model import WorldModel, WorldModelConfig

    wm = WorldModel()
    result = wm.build(
        fused_world_state=...,
        prediction_state=...,
        collision_state=...,
        memory_context=...,
        road_understanding_state=...,
    )
    snapshot = result.snapshot
"""
from .world_model import WorldModel
from .world_model_config import WorldModelConfig, load_world_model_config
from .world_model_types import (
    # Sentinels
    NOT_AVAILABLE,
    WORLD_MODEL_SCHEMA_VERSION,
    # Enums
    WorldModelStatus,
    ObjectObservationState,
    WorldObjectLifecycle,
    PredictionAvailability,
    RoadRepresentationStatus,
    CoordinateFrame,
    InputModuleStatus,
    # Object types
    WorldObjectPosition,
    WorldObjectVelocity,
    WorldObjectDimensions,
    WorldObjectMotionSummary,
    WorldObjectPredictionSummary,
    WorldObjectCollisionInfo,
    WorldObjectQuality,
    WorldObject,
    # Road types
    WorldBoundaryPoint,
    WorldBoundarySummary,
    WorldDrivableSpaceInfo,
    WorldLaneInfo,
    WorldAnomalySummary,
    WorldRoadRepresentation,
    # Context
    WorldIndianContextSummary,
    # Quality
    WorldDataQuality,
    # Snapshot
    WorldModelSnapshot,
    WorldModelBuildResult,
)
from .world_model_validator import WorldModelValidator, ValidationResult
from .world_model_snapshot import (
    snapshot_age_s,
    is_snapshot_stale,
    snapshot_to_json,
    snapshot_summary,
    safe_copy_snapshot,
)

__all__ = [
    "WorldModel",
    "WorldModelConfig",
    "load_world_model_config",
    "NOT_AVAILABLE",
    "WORLD_MODEL_SCHEMA_VERSION",
    "WorldModelStatus",
    "ObjectObservationState",
    "WorldObjectLifecycle",
    "PredictionAvailability",
    "RoadRepresentationStatus",
    "CoordinateFrame",
    "InputModuleStatus",
    "WorldObjectPosition",
    "WorldObjectVelocity",
    "WorldObjectDimensions",
    "WorldObjectMotionSummary",
    "WorldObjectPredictionSummary",
    "WorldObjectCollisionInfo",
    "WorldObjectQuality",
    "WorldObject",
    "WorldBoundaryPoint",
    "WorldBoundarySummary",
    "WorldDrivableSpaceInfo",
    "WorldLaneInfo",
    "WorldAnomalySummary",
    "WorldRoadRepresentation",
    "WorldIndianContextSummary",
    "WorldDataQuality",
    "WorldModelSnapshot",
    "WorldModelBuildResult",
    "WorldModelValidator",
    "ValidationResult",
    "snapshot_age_s",
    "is_snapshot_stale",
    "snapshot_to_json",
    "snapshot_summary",
    "safe_copy_snapshot",
]
