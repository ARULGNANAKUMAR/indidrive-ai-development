"""
IndiDrive AI — Phase 7 | World Model Public API
================================================
Main entry point for Phase 7.

Usage
-----
    config = WorldModelConfig()
    world_model = WorldModel(config=config)

    result = world_model.build(
        fused_world_state=fused,
        prediction_state=predicted,
        collision_state=collision,
        memory_context=memory,
        road_understanding_state=road,
    )

    snapshot = result.snapshot
    if result.is_valid:
        for obj in snapshot.objects:
            ...

The WorldModel is NOT a planner, controller, or reasoning engine.
It does NOT control the vehicle.
It does NOT perform path planning or MPC.
"""
from __future__ import annotations

import threading
import time
from collections import deque
from typing import Deque, List, Optional

from .world_model_builder import WorldModelBuilder
from .world_model_config import WorldModelConfig, load_world_model_config
from .world_model_types import WorldModelBuildResult, WorldModelSnapshot, WorldModelStatus
from .world_model_validator import WorldModelValidator

__all__ = ["WorldModel"]


class WorldModel:
    """
    Phase 7 World Model.

    Provides a clean, typed, vehicle-relative representation of the
    current driving environment, assembled from the outputs of Phases 1–6.

    Thread safety
    -------------
    build() is thread-safe — it acquires the snapshot buffer lock only
    when appending to the bounded history.  The snapshot itself is
    immutable after construction.

    Planner / controller / MPC
    --------------------------
    NOT implemented here.  This class only produces a structured
    representation; it does NOT make any vehicle-control decisions.
    """

    def __init__(
        self,
        config: Optional[WorldModelConfig] = None,
        config_path: Optional[str] = None,
    ) -> None:
        if config is not None:
            self._config = config
        else:
            self._config = load_world_model_config(config_path)

        self._builder = WorldModelBuilder(self._config)
        self._validator = WorldModelValidator(self._config)

        # Bounded snapshot history (thread-safe)
        buf_size = max(0, self._config.snapshot_buffer_size)
        self._snapshot_buffer: Deque[WorldModelSnapshot] = deque(maxlen=buf_size if buf_size > 0 else 1)
        self._buffer_lock = threading.Lock()

        # Latest build result
        self._latest_result: Optional[WorldModelBuildResult] = None
        self._result_lock = threading.Lock()

    # ------------------------------------------------------------------
    # Primary API
    # ------------------------------------------------------------------

    def build(
        self,
        *,
        fused_world_state=None,
        prediction_state=None,
        collision_state=None,
        memory_context=None,
        road_understanding_state=None,
        ref_timestamp: Optional[float] = None,
        frame_id: int = 0,
    ) -> WorldModelBuildResult:
        """
        Build a WorldModelSnapshot from available upstream outputs.

        All parameters are optional.  A valid (possibly partial) snapshot
        is returned regardless of which inputs are present.

        Returns
        -------
        WorldModelBuildResult
            Contains the snapshot, validation status, errors, warnings,
            and build duration.  Never raises.
        """
        t0 = time.perf_counter()

        try:
            snapshot = self._builder.build(
                fused_world_state=fused_world_state,
                prediction_state=prediction_state,
                collision_state=collision_state,
                memory_context=memory_context,
                road_understanding_state=road_understanding_state,
                ref_timestamp=ref_timestamp,
                frame_id=frame_id,
            )
        except Exception as exc:
            # Should never happen — builder is designed to never raise.
            # If it does, return a safe empty snapshot with the error recorded.
            snapshot = self._empty_snapshot(ref_timestamp, frame_id)
            result = WorldModelBuildResult(
                snapshot=snapshot,
                validation_status="invalid",
                validation_errors=[f"builder raised an unexpected exception: {exc!r}"],
                build_duration_s=time.perf_counter() - t0,
            )
            self._store_result(result)
            return result

        # Validate
        validation = self._validator.validate(snapshot)
        build_duration = time.perf_counter() - t0

        result = WorldModelBuildResult(
            snapshot=snapshot,
            validation_status=validation.status,
            validation_errors=list(validation.errors),
            validation_warnings=list(validation.warnings),
            build_duration_s=build_duration,
        )

        self._store_result(result)
        return result

    # ------------------------------------------------------------------
    # Snapshot history access
    # ------------------------------------------------------------------

    def latest_snapshot(self) -> Optional[WorldModelSnapshot]:
        """Return the most recently built snapshot, or None."""
        with self._result_lock:
            return self._latest_result.snapshot if self._latest_result is not None else None

    def latest_result(self) -> Optional[WorldModelBuildResult]:
        """Return the most recently built WorldModelBuildResult, or None."""
        with self._result_lock:
            return self._latest_result

    def snapshot_history(self) -> List[WorldModelSnapshot]:
        """Return a copy of the bounded snapshot history (oldest first)."""
        with self._buffer_lock:
            return list(self._snapshot_buffer)

    # ------------------------------------------------------------------
    # Health / diagnostics
    # ------------------------------------------------------------------

    def health_status(self) -> str:
        """Return a simple health string for monitoring."""
        with self._result_lock:
            if self._latest_result is None:
                return "NO_SNAPSHOT"
            snap = self._latest_result.snapshot
            return snap.status.value

    @property
    def config(self) -> WorldModelConfig:
        return self._config

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _store_result(self, result: WorldModelBuildResult) -> None:
        with self._result_lock:
            self._latest_result = result
        if self._config.snapshot_buffer_size > 0:
            with self._buffer_lock:
                self._snapshot_buffer.append(result.snapshot)

    @staticmethod
    def _empty_snapshot(ref_ts: Optional[float], frame_id: int) -> WorldModelSnapshot:
        from .world_model_types import (
            WorldDataQuality, WorldIndianContextSummary,
            WorldRoadRepresentation, CoordinateFrame, RoadRepresentationStatus,
        )
        return WorldModelSnapshot(
            schema_version="7.0",
            timestamp=ref_ts if ref_ts is not None else time.time(),
            frame_id=frame_id,
            _objects=tuple(),
            road=WorldRoadRepresentation(
                status=RoadRepresentationStatus.NONE,
                is_degraded=True,
            ),
            indian_context=WorldIndianContextSummary(available=False, is_degraded=True),
            data_quality=WorldDataQuality(),
            status=WorldModelStatus.EMPTY,
            coordinate_frame=CoordinateFrame.VEHICLE,
        )
