"""
IndiDrive AI — Phase 7 | World Model Data Contracts
=====================================================
Strongly-typed, compact data containers for the World Model snapshot.

The World Model answers:
  • What objects are around the vehicle?
  • Where, moving how, predicted where?
  • Which objects create collision risk?
  • What road space is available?
  • What road structure / anomalies exist?
  • What Indian-road context applies?
  • How reliable and complete is the picture?

Design rules (same as all prior phases):
  * dataclasses — not raw dicts
  * explicit NOT_AVAILABLE / unavailable / unknown — never fabricated
  * no raw sensor frames, no large tensors, no unbounded lists
  * confidence ≠ uncertainty ≠ completeness — kept separate
  * deterministic: same input → same output
  * compact: bounded lists, summaries only
  * immutable snapshots (WorldModelSnapshot)

This module contains ONLY structural containers.
Computation lives in world_model_builder.py.
"""
from __future__ import annotations

import math
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import List, Optional, Tuple

__all__ = [
    # Sentinels
    "NOT_AVAILABLE",
    # Schema
    "WORLD_MODEL_SCHEMA_VERSION",
    # Enums
    "WorldModelStatus",
    "ObjectObservationState",
    "WorldObjectLifecycle",
    "PredictionAvailability",
    "RoadRepresentationStatus",
    "CoordinateFrame",
    "InputModuleStatus",
    # Object sub-structures
    "WorldObjectPosition",
    "WorldObjectVelocity",
    "WorldObjectDimensions",
    "WorldObjectMotionSummary",
    "WorldObjectPredictionSummary",
    "WorldObjectCollisionInfo",
    "WorldObjectQuality",
    # Road sub-structures
    "WorldBoundaryPoint",
    "WorldBoundarySummary",
    "WorldDrivableSpaceInfo",
    "WorldLaneInfo",
    "WorldAnomalySummary",
    "WorldRoadRepresentation",
    # Indian context sub-structure
    "WorldIndianContextSummary",
    # Data quality
    "WorldDataQuality",
    # Primary containers
    "WorldObject",
    "WorldModelSnapshot",
    "WorldModelBuildResult",
]

NOT_AVAILABLE = "NOT_AVAILABLE"

# Schema version — bump on backward-incompatible field changes.
WORLD_MODEL_SCHEMA_VERSION = "7.0"


# ---------------------------------------------------------------------------
# Top-level status enums
# ---------------------------------------------------------------------------

class WorldModelStatus(str, Enum):
    """Overall health of the World Model snapshot."""
    OK         = "OK"          # full or nearly-full inputs; high confidence
    PARTIAL    = "PARTIAL"     # one or more modules absent/degraded; useful
    DEGRADED   = "DEGRADED"    # significant degradation; use with caution
    EMPTY      = "EMPTY"       # no usable inputs; snapshot is skeleton only
    INVALID    = "INVALID"     # validation failure; do not use


class ObjectObservationState(str, Enum):
    """Per-object epistemological state — how was this object known?"""
    OBSERVED          = "OBSERVED"          # directly seen this cycle
    TRACKED           = "TRACKED"           # in track but not observed this cycle
    PREDICTED         = "PREDICTED"         # trajectory only; lost observation
    PARTIALLY_OBSERVED = "PARTIALLY_OBSERVED"  # occlusion / sensor range limit
    STALE             = "STALE"             # last observation is old
    DEGRADED          = "DEGRADED"          # data quality below threshold
    UNAVAILABLE       = "UNAVAILABLE"       # no data available


class WorldObjectLifecycle(str, Enum):
    """Object lifecycle from the perspective of the World Model."""
    NEW       = "NEW"        # first time seen this cycle
    ACTIVE    = "ACTIVE"     # normal active object
    LOST      = "LOST"       # temporarily unobserved
    STALE     = "STALE"      # too old; may be removed next cycle
    REMOVED   = "REMOVED"    # marked for removal


class PredictionAvailability(str, Enum):
    FULL      = "FULL"       # trajectory + TTC + collision info available
    PARTIAL   = "PARTIAL"    # some prediction data available
    NONE      = "NONE"       # no prediction data for this object
    INVALID   = "INVALID"    # prediction data present but invalid


class RoadRepresentationStatus(str, Enum):
    FULL      = "FULL"       # drivable area + lanes + anomalies available
    PARTIAL   = "PARTIAL"    # some road info available
    NONE      = "NONE"       # no road understanding available
    DEGRADED  = "DEGRADED"   # below confidence threshold


class CoordinateFrame(str, Enum):
    """Declared coordinate frame of positional data."""
    VEHICLE   = "VEHICLE"    # +X fwd, +Y left, +Z up, rear-axle origin
    WORLD     = "WORLD"      # absolute world frame (not expected here)
    UNKNOWN   = "UNKNOWN"    # frame not declared
    INVALID   = "INVALID"    # declared frame is unsupported / conflicting


class InputModuleStatus(str, Enum):
    """Availability of an upstream input module this cycle."""
    OK          = "OK"
    DEGRADED    = "DEGRADED"
    UNAVAILABLE = "UNAVAILABLE"
    INVALID     = "INVALID"


# ---------------------------------------------------------------------------
# Object geometry sub-structures
# ---------------------------------------------------------------------------

@dataclass
class WorldObjectPosition:
    """Vehicle-relative position of an object's reference point.

    Coordinates: +X forward, +Y left, +Z up.
    Origin: rear-axle centre.  Units: metres.
    None = unknown.
    """
    x: Optional[float] = None   # forward (metres)
    y: Optional[float] = None   # lateral (metres; positive = left)
    z: Optional[float] = None   # vertical (metres; positive = up)
    distance_m: Optional[float] = None   # Euclidean distance from origin
    heading_rad: Optional[float] = None  # object heading in vehicle frame

    @staticmethod
    def _finite(v: Optional[float]) -> bool:
        return v is not None and isinstance(v, (int, float)) and math.isfinite(v)

    def is_valid(self) -> bool:
        """Returns True when x and y are both finite (z may be unavailable)."""
        return self._finite(self.x) and self._finite(self.y)

    def compute_distance(self) -> Optional[float]:
        """Compute Euclidean distance if x, y are available."""
        if self._finite(self.x) and self._finite(self.y):
            z = self.z if self._finite(self.z) else 0.0
            return math.sqrt(self.x ** 2 + self.y ** 2 + z ** 2)
        return None

    def to_dict(self) -> dict:
        def _r(v):
            return round(v, 4) if v is not None else NOT_AVAILABLE
        return {
            "x": _r(self.x),
            "y": _r(self.y),
            "z": _r(self.z),
            "distance_m": _r(self.distance_m),
            "heading_rad": _r(self.heading_rad),
        }


@dataclass
class WorldObjectVelocity:
    """Object velocity in vehicle-relative frame (metres/second)."""
    vx: Optional[float] = None
    vy: Optional[float] = None
    vz: Optional[float] = None
    speed_ms: Optional[float] = None
    ax: Optional[float] = None  # acceleration
    ay: Optional[float] = None
    az: Optional[float] = None

    def is_valid(self) -> bool:
        return (
            self.vx is not None and math.isfinite(self.vx) and
            self.vy is not None and math.isfinite(self.vy)
        )

    def to_dict(self) -> dict:
        def _r(v):
            return round(v, 4) if v is not None else NOT_AVAILABLE
        return {
            "vx": _r(self.vx), "vy": _r(self.vy), "vz": _r(self.vz),
            "speed_ms": _r(self.speed_ms),
            "ax": _r(self.ax), "ay": _r(self.ay), "az": _r(self.az),
        }


@dataclass
class WorldObjectDimensions:
    """Object bounding-box dimensions (metres).  None = unknown."""
    length_m: Optional[float] = None
    width_m: Optional[float] = None
    height_m: Optional[float] = None

    def is_valid(self) -> bool:
        return (
            self.length_m is not None and self.length_m > 0 and
            self.width_m is not None and self.width_m > 0 and
            self.height_m is not None and self.height_m > 0
        )

    def to_dict(self) -> dict:
        def _r(v):
            return round(v, 3) if v is not None else NOT_AVAILABLE
        return {
            "length_m": _r(self.length_m),
            "width_m": _r(self.width_m),
            "height_m": _r(self.height_m),
        }


@dataclass
class WorldObjectMotionSummary:
    """Compact motion state summary for one object."""
    is_moving: bool = False
    speed_ms: Optional[float] = None
    yaw_rate_rads: Optional[float] = None
    motion_model: str = NOT_AVAILABLE  # CV | CA | CTRV | NOT_AVAILABLE

    def to_dict(self) -> dict:
        return {
            "is_moving": self.is_moving,
            "speed_ms": round(self.speed_ms, 3) if self.speed_ms is not None else NOT_AVAILABLE,
            "yaw_rate_rads": round(self.yaw_rate_rads, 4) if self.yaw_rate_rads is not None else NOT_AVAILABLE,
            "motion_model": self.motion_model,
        }


@dataclass
class WorldObjectPredictionSummary:
    """Compact prediction summary attached to a WorldObject.

    Stores a bounded list of trajectory waypoints and up to
    max_hypotheses behaviour hypotheses.
    """
    availability: PredictionAvailability = PredictionAvailability.NONE
    # trajectory: list of (x, y, z, t) tuples — bounded externally
    trajectory: List[Tuple[float, float, float, float]] = field(default_factory=list)
    prediction_horizon_s: float = 0.0
    prediction_confidence: float = 0.0
    prediction_uncertainty: dict = field(default_factory=dict)  # {sigma_x, sigma_y, ...}
    # Behaviour hypotheses: list of {behaviour: str, probability: float}
    hypotheses: List[dict] = field(default_factory=list)
    motion_model: str = NOT_AVAILABLE

    def to_dict(self) -> dict:
        return {
            "availability": self.availability.value,
            "trajectory_points": len(self.trajectory),
            "prediction_horizon_s": round(self.prediction_horizon_s, 3),
            "prediction_confidence": round(self.prediction_confidence, 3),
            "prediction_uncertainty": self.prediction_uncertainty or NOT_AVAILABLE,
            "hypotheses_count": len(self.hypotheses),
            "hypotheses": self.hypotheses,
            "motion_model": self.motion_model,
        }


@dataclass
class WorldObjectCollisionInfo:
    """TTC and collision risk info for one object.

    None fields mean the value was not computed or is unavailable.
    Do not use zero as a substitute for 'unknown'.
    """
    ttc_s: Optional[float] = None
    ttc_status: str = NOT_AVAILABLE           # FINITE | NO_COLLISION | UNKNOWN
    closing_speed_ms: Optional[float] = None
    # Closest approach
    min_distance_m: Optional[float] = None
    time_of_closest_approach_s: Optional[float] = None
    # Risk
    collision_likelihood: Optional[float] = None  # [0, 1]
    risk_level: str = NOT_AVAILABLE               # LOW | MEDIUM | HIGH | CRITICAL
    # Per-hypothesis max risk
    max_hypothesis_risk: Optional[float] = None
    predicted_conflict: bool = False

    def to_dict(self) -> dict:
        def _r(v):
            return round(v, 4) if v is not None else NOT_AVAILABLE
        return {
            "ttc_s": _r(self.ttc_s),
            "ttc_status": self.ttc_status,
            "closing_speed_ms": _r(self.closing_speed_ms),
            "min_distance_m": _r(self.min_distance_m),
            "time_of_closest_approach_s": _r(self.time_of_closest_approach_s),
            "collision_likelihood": _r(self.collision_likelihood),
            "risk_level": self.risk_level,
            "max_hypothesis_risk": _r(self.max_hypothesis_risk),
            "predicted_conflict": self.predicted_conflict,
        }


@dataclass
class WorldObjectQuality:
    """Per-object data quality indicators."""
    object_confidence: float = 0.0
    position_confidence: float = 0.0
    velocity_confidence: float = 0.0
    existence_probability: float = 0.0
    data_age_s: float = 0.0       # seconds since last valid observation
    observation_state: ObjectObservationState = ObjectObservationState.UNAVAILABLE
    is_stale: bool = False
    is_degraded: bool = False
    source_sensors: str = NOT_AVAILABLE  # e.g. "CAMERA+LIDAR"

    def to_dict(self) -> dict:
        return {
            "object_confidence": round(self.object_confidence, 3),
            "position_confidence": round(self.position_confidence, 3),
            "velocity_confidence": round(self.velocity_confidence, 3),
            "existence_probability": round(self.existence_probability, 3),
            "data_age_s": round(self.data_age_s, 3),
            "observation_state": self.observation_state.value,
            "is_stale": self.is_stale,
            "is_degraded": self.is_degraded,
            "source_sensors": self.source_sensors,
        }


# ---------------------------------------------------------------------------
# Primary World Object
# ---------------------------------------------------------------------------

@dataclass
class WorldObject:
    """
    The fundamental unit of the World Model — one detected, tracked,
    and/or predicted object in the vehicle's environment.

    Identifiers (by priority):
      1. object_id   — stable ID from Phase 5 memory
      2. track_id    — stable ID from Phase 4 tracker
      3. fused_id    — ID from Phase 3 fusion

    None or NOT_AVAILABLE identifier means the object could not be
    correlated across sources.  Do NOT fabricate identifiers.
    """
    # --- Identity --------------------------------------------------------
    object_id: Optional[str] = None       # stable memory ID (Phase 5)
    track_id: Optional[str] = None        # track ID (Phase 4)
    fused_id: Optional[str] = None        # fused object ID (Phase 3)

    # --- Classification --------------------------------------------------
    object_type: str = NOT_AVAILABLE      # VEHICLE | PEDESTRIAN | CYCLIST | ...
    object_subtype: str = NOT_AVAILABLE   # CAR | TRUCK | AUTO | COW | ...

    # --- Geometry --------------------------------------------------------
    position: WorldObjectPosition = field(default_factory=WorldObjectPosition)
    velocity: WorldObjectVelocity = field(default_factory=WorldObjectVelocity)
    dimensions: WorldObjectDimensions = field(default_factory=WorldObjectDimensions)

    # --- Motion ----------------------------------------------------------
    motion: WorldObjectMotionSummary = field(default_factory=WorldObjectMotionSummary)

    # --- Prediction ------------------------------------------------------
    prediction: WorldObjectPredictionSummary = field(default_factory=WorldObjectPredictionSummary)

    # --- Collision risk --------------------------------------------------
    collision: WorldObjectCollisionInfo = field(default_factory=WorldObjectCollisionInfo)

    # --- Quality / lifecycle ---------------------------------------------
    quality: WorldObjectQuality = field(default_factory=WorldObjectQuality)
    lifecycle: WorldObjectLifecycle = WorldObjectLifecycle.NEW
    observation_timestamp: float = 0.0    # wall-clock time of last observation
    coordinate_frame: CoordinateFrame = CoordinateFrame.VEHICLE

    def primary_id(self) -> Optional[str]:
        """Return the highest-priority available identifier."""
        return self.object_id or self.track_id or self.fused_id

    def is_high_risk(self) -> bool:
        return self.collision.risk_level in ("HIGH", "CRITICAL")

    def is_moving(self) -> bool:
        return self.motion.is_moving

    def to_dict(self) -> dict:
        return {
            "object_id": self.object_id if self.object_id is not None else NOT_AVAILABLE,
            "track_id": self.track_id if self.track_id is not None else NOT_AVAILABLE,
            "fused_id": self.fused_id if self.fused_id is not None else NOT_AVAILABLE,
            "object_type": self.object_type,
            "object_subtype": self.object_subtype,
            "position": self.position.to_dict(),
            "velocity": self.velocity.to_dict(),
            "dimensions": self.dimensions.to_dict(),
            "motion": self.motion.to_dict(),
            "prediction": self.prediction.to_dict(),
            "collision": self.collision.to_dict(),
            "quality": self.quality.to_dict(),
            "lifecycle": self.lifecycle.value,
            "observation_timestamp": self.observation_timestamp,
            "coordinate_frame": self.coordinate_frame.value,
        }


# ---------------------------------------------------------------------------
# Road representation sub-structures
# ---------------------------------------------------------------------------

@dataclass
class WorldBoundaryPoint:
    """One point on a road or lane boundary (vehicle-relative metres)."""
    x: float
    y: float
    z: float = 0.0
    confidence: float = 0.0

    def to_dict(self) -> dict:
        return {
            "x": round(self.x, 3),
            "y": round(self.y, 3),
            "z": round(self.z, 3),
            "confidence": round(self.confidence, 3),
        }


@dataclass
class WorldBoundarySummary:
    """Compact left or right boundary summary.

    Points are bounded by max_boundary_points from config.
    """
    available: bool = False
    points: List[WorldBoundaryPoint] = field(default_factory=list)
    confidence: float = 0.0
    source: str = NOT_AVAILABLE

    def to_dict(self) -> dict:
        return {
            "available": self.available,
            "point_count": len(self.points),
            "confidence": round(self.confidence, 3),
            "source": self.source,
        }


@dataclass
class WorldDrivableSpaceInfo:
    """Compact drivable space summary from Phase 6.1."""
    available: bool = False
    road_width_m: Optional[float] = None
    free_space_confidence: float = 0.0
    drivable_space_uncertainty: float = 1.0
    left_boundary: WorldBoundarySummary = field(default_factory=WorldBoundarySummary)
    right_boundary: WorldBoundarySummary = field(default_factory=WorldBoundarySummary)
    coordinate_frame: CoordinateFrame = CoordinateFrame.VEHICLE
    is_degraded: bool = False
    source: str = NOT_AVAILABLE

    def to_dict(self) -> dict:
        return {
            "available": self.available,
            "road_width_m": round(self.road_width_m, 2) if self.road_width_m is not None else NOT_AVAILABLE,
            "free_space_confidence": round(self.free_space_confidence, 3),
            "drivable_space_uncertainty": round(self.drivable_space_uncertainty, 3),
            "left_boundary": self.left_boundary.to_dict(),
            "right_boundary": self.right_boundary.to_dict(),
            "coordinate_frame": self.coordinate_frame.value,
            "is_degraded": self.is_degraded,
            "source": self.source,
        }


@dataclass
class WorldLaneInfo:
    """Compact lane / road structure from Phase 6.2."""
    available: bool = False
    marking_state: str = NOT_AVAILABLE   # MARKED | WEAKLY_MARKED | UNMARKED | UNKNOWN
    lane_count: Optional[int] = None
    lane_width_m: Optional[float] = None
    road_direction: str = NOT_AVAILABLE
    curvature_summary: str = NOT_AVAILABLE  # STRAIGHT | MILD_CURVE | SHARP_CURVE | UNKNOWN
    intersection_state: str = NOT_AVAILABLE # NORMAL_ROAD | INTERSECTION | UNKNOWN
    observed_vs_inferred: str = NOT_AVAILABLE  # OBSERVED | INFERRED | MIXED | UNKNOWN
    lane_confidence: float = 0.0
    lane_uncertainty: float = 1.0
    is_degraded: bool = False

    def to_dict(self) -> dict:
        return {
            "available": self.available,
            "marking_state": self.marking_state,
            "lane_count": self.lane_count if self.lane_count is not None else NOT_AVAILABLE,
            "lane_width_m": round(self.lane_width_m, 2) if self.lane_width_m is not None else NOT_AVAILABLE,
            "road_direction": self.road_direction,
            "curvature_summary": self.curvature_summary,
            "intersection_state": self.intersection_state,
            "observed_vs_inferred": self.observed_vs_inferred,
            "lane_confidence": round(self.lane_confidence, 3),
            "lane_uncertainty": round(self.lane_uncertainty, 3),
            "is_degraded": self.is_degraded,
        }


@dataclass
class WorldAnomalySummary:
    """Compact representation of one road anomaly (from Phase 6.3).

    Preserves the fields needed by downstream consumers without storing
    full AnomalyGeometry (only position summary).
    """
    anomaly_id: str = NOT_AVAILABLE
    anomaly_type: str = NOT_AVAILABLE       # AnomalyType.value
    position_x: Optional[float] = None     # vehicle-relative metres
    position_y: Optional[float] = None
    approximate_width_m: Optional[float] = None
    approximate_length_m: Optional[float] = None
    severity: str = NOT_AVAILABLE           # MINOR | MODERATE | SEVERE | CRITICAL
    drivability_impact: str = NOT_AVAILABLE # NONE | LOW | MEDIUM | HIGH | BLOCKING
    confidence: float = 0.0
    uncertainty: float = 1.0
    temporal_stability: str = NOT_AVAILABLE # STABLE | VARIABLE | TRANSIENT | UNKNOWN
    in_drivable_area: bool = False
    in_lane_corridor: bool = False

    def to_dict(self) -> dict:
        def _r(v):
            return round(v, 3) if v is not None else NOT_AVAILABLE
        return {
            "anomaly_id": self.anomaly_id,
            "anomaly_type": self.anomaly_type,
            "position_x": _r(self.position_x),
            "position_y": _r(self.position_y),
            "approximate_width_m": _r(self.approximate_width_m),
            "approximate_length_m": _r(self.approximate_length_m),
            "severity": self.severity,
            "drivability_impact": self.drivability_impact,
            "confidence": round(self.confidence, 3),
            "uncertainty": round(self.uncertainty, 3),
            "temporal_stability": self.temporal_stability,
            "in_drivable_area": self.in_drivable_area,
            "in_lane_corridor": self.in_lane_corridor,
        }


@dataclass
class WorldRoadRepresentation:
    """
    Compact road-environment representation for one World Model snapshot.

    Aggregates Phase 6.1, 6.2, 6.3 outputs.  Indian context is kept
    separately in WorldIndianContextSummary.
    """
    status: RoadRepresentationStatus = RoadRepresentationStatus.NONE
    drivable_space: WorldDrivableSpaceInfo = field(default_factory=WorldDrivableSpaceInfo)
    lane_info: WorldLaneInfo = field(default_factory=WorldLaneInfo)
    # Bounded list of road anomalies
    anomalies: List[WorldAnomalySummary] = field(default_factory=list)
    road_confidence: float = 0.0
    road_uncertainty: float = 1.0
    timestamp: float = 0.0
    is_degraded: bool = True

    @property
    def anomaly_count(self) -> int:
        return len(self.anomalies)

    @property
    def has_critical_anomaly(self) -> bool:
        return any(a.severity == "CRITICAL" for a in self.anomalies)

    def to_dict(self) -> dict:
        return {
            "status": self.status.value,
            "drivable_space": self.drivable_space.to_dict(),
            "lane_info": self.lane_info.to_dict(),
            "anomaly_count": self.anomaly_count,
            "has_critical_anomaly": self.has_critical_anomaly,
            "anomalies": [a.to_dict() for a in self.anomalies],
            "road_confidence": round(self.road_confidence, 3),
            "road_uncertainty": round(self.road_uncertainty, 3),
            "timestamp": self.timestamp,
            "is_degraded": self.is_degraded,
        }


# ---------------------------------------------------------------------------
# Indian context summary
# ---------------------------------------------------------------------------

@dataclass
class WorldIndianContextSummary:
    """
    Compact Indian-road context from Phase 6.4.

    Only fields actually needed by the World Model are preserved.
    Unknown values are kept as NOT_AVAILABLE — never fabricated.
    """
    available: bool = False
    road_type: str = NOT_AVAILABLE               # VILLAGE_ROAD | URBAN | HIGHWAY | ...
    urban_rural_class: str = NOT_AVAILABLE       # URBAN | RURAL | HIGHWAY_LIKE | UNKNOWN
    traffic_density: str = NOT_AVAILABLE         # LOW | MEDIUM | HIGH | VERY_HIGH | UNKNOWN
    traffic_mix: str = NOT_AVAILABLE             # compact summary
    vulnerable_road_users: bool = False
    cattle_present: bool = False
    roadside_activity: str = NOT_AVAILABLE
    market_like_activity: bool = False
    intersection_context: str = NOT_AVAILABLE
    unusual_road_indicators: List[str] = field(default_factory=list)
    road_complexity: str = NOT_AVAILABLE         # LOW | MEDIUM | HIGH | VERY_HIGH | UNKNOWN
    context_stability: str = NOT_AVAILABLE       # STABLE | CHANGING | UNSTABLE | UNKNOWN
    context_confidence: float = 0.0
    context_uncertainty: float = 1.0
    is_degraded: bool = True

    def to_dict(self) -> dict:
        return {
            "available": self.available,
            "road_type": self.road_type,
            "urban_rural_class": self.urban_rural_class,
            "traffic_density": self.traffic_density,
            "traffic_mix": self.traffic_mix,
            "vulnerable_road_users": self.vulnerable_road_users,
            "cattle_present": self.cattle_present,
            "roadside_activity": self.roadside_activity,
            "market_like_activity": self.market_like_activity,
            "intersection_context": self.intersection_context,
            "unusual_road_indicators": list(self.unusual_road_indicators),
            "road_complexity": self.road_complexity,
            "context_stability": self.context_stability,
            "context_confidence": round(self.context_confidence, 3),
            "context_uncertainty": round(self.context_uncertainty, 3),
            "is_degraded": self.is_degraded,
        }


# ---------------------------------------------------------------------------
# Data quality / completeness
# ---------------------------------------------------------------------------

@dataclass
class WorldDataQuality:
    """
    Overall data quality assessment for a World Model snapshot.

    Distinguishes confidence, uncertainty, completeness, and freshness
    — these are NOT collapsed into a single number.
    """
    # Overall confidence in the world representation [0, 1]
    # Weighted average of object, road, prediction confidences.
    overall_confidence: float = 0.0

    # Overall uncertainty [0, ∞).  High uncertainty ≠ low confidence.
    # Grows with stale data, missing modules, coordinate conflicts.
    overall_uncertainty: float = 1.0

    # Completeness: fraction of expected input modules that delivered
    # valid data this cycle.  0.0 = no modules, 1.0 = all present.
    completeness: float = 0.0

    # Freshness: 0.0 = all inputs maximally stale; 1.0 = all fresh.
    freshness: float = 0.0

    # Degradation flags — per upstream module
    perception_status: InputModuleStatus = InputModuleStatus.UNAVAILABLE
    fusion_status: InputModuleStatus = InputModuleStatus.UNAVAILABLE
    prediction_status: InputModuleStatus = InputModuleStatus.UNAVAILABLE
    memory_status: InputModuleStatus = InputModuleStatus.UNAVAILABLE
    road_understanding_status: InputModuleStatus = InputModuleStatus.UNAVAILABLE
    indian_context_status: InputModuleStatus = InputModuleStatus.UNAVAILABLE

    # Whether the snapshot is partial (some modules absent)
    is_partial: bool = True

    # Accumulated warnings
    warnings: List[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "overall_confidence": round(self.overall_confidence, 3),
            "overall_uncertainty": round(self.overall_uncertainty, 3),
            "completeness": round(self.completeness, 3),
            "freshness": round(self.freshness, 3),
            "is_partial": self.is_partial,
            "perception_status": self.perception_status.value,
            "fusion_status": self.fusion_status.value,
            "prediction_status": self.prediction_status.value,
            "memory_status": self.memory_status.value,
            "road_understanding_status": self.road_understanding_status.value,
            "indian_context_status": self.indian_context_status.value,
            "warning_count": len(self.warnings),
            "warnings": list(self.warnings),
        }


# ---------------------------------------------------------------------------
# Primary snapshot
# ---------------------------------------------------------------------------

@dataclass
class WorldModelSnapshot:
    """
    One immutable, consistent World Model state for a single processing cycle.

    Consumers receive this snapshot and must not mutate it.  Internal
    collections are exposed as tuples (immutable) to prevent accidental
    mutation.

    Fields
    ------
    schema_version:
        Incremented when the field layout changes backward-incompatibly.
    timestamp:
        Wall-clock time when this snapshot was assembled (seconds since epoch).
    frame_id:
        Cycle / frame counter from the primary upstream input.
    objects:
        Bounded tuple of WorldObject instances (max = config.max_objects).
    road:
        Compact road representation.
    indian_context:
        Compact Indian-road context.
    data_quality:
        Confidence, uncertainty, completeness, freshness, degradation flags.
    status:
        Overall health of this snapshot.
    coordinate_frame:
        Declared coordinate frame (should always be VEHICLE).
    """
    schema_version: str = WORLD_MODEL_SCHEMA_VERSION
    timestamp: float = field(default_factory=time.time)
    frame_id: int = 0
    # Objects as a tuple for immutability after construction
    _objects: tuple = field(default_factory=tuple, repr=False)
    road: WorldRoadRepresentation = field(default_factory=WorldRoadRepresentation)
    indian_context: WorldIndianContextSummary = field(default_factory=WorldIndianContextSummary)
    data_quality: WorldDataQuality = field(default_factory=WorldDataQuality)
    status: WorldModelStatus = WorldModelStatus.EMPTY
    coordinate_frame: CoordinateFrame = CoordinateFrame.VEHICLE

    # ------------------------------------------------------------------
    # Safe immutable object access
    # ------------------------------------------------------------------

    @property
    def objects(self) -> tuple:
        """Read-only tuple of WorldObject.  Cannot be mutated by callers."""
        return self._objects

    @property
    def object_count(self) -> int:
        return len(self._objects)

    # ------------------------------------------------------------------
    # Convenience queries
    # ------------------------------------------------------------------

    def objects_by_risk(self) -> tuple:
        """Objects sorted by risk level descending (CRITICAL first)."""
        risk_order = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3, NOT_AVAILABLE: 4}
        return tuple(sorted(
            self._objects,
            key=lambda o: risk_order.get(o.collision.risk_level, 4)
        ))

    def moving_objects(self) -> tuple:
        return tuple(o for o in self._objects if o.motion.is_moving)

    def high_risk_objects(self) -> tuple:
        return tuple(o for o in self._objects if o.is_high_risk())

    # ------------------------------------------------------------------
    # Serialisation
    # ------------------------------------------------------------------

    def to_dict(self) -> dict:
        return {
            "schema_version": self.schema_version,
            "timestamp": self.timestamp,
            "frame_id": self.frame_id,
            "status": self.status.value,
            "coordinate_frame": self.coordinate_frame.value,
            "object_count": self.object_count,
            "objects": [o.to_dict() for o in self._objects],
            "road": self.road.to_dict(),
            "indian_context": self.indian_context.to_dict(),
            "data_quality": self.data_quality.to_dict(),
        }


# ---------------------------------------------------------------------------
# Build result (carries snapshot + validation outcome)
# ---------------------------------------------------------------------------

@dataclass
class WorldModelBuildResult:
    """Return value of WorldModel.build().

    Always present — never raises on partial or invalid inputs.
    """
    snapshot: WorldModelSnapshot
    validation_status: str = "valid"     # valid | partial | degraded | invalid
    validation_errors: List[str] = field(default_factory=list)
    validation_warnings: List[str] = field(default_factory=list)
    build_duration_s: float = 0.0

    @property
    def is_valid(self) -> bool:
        return self.validation_status in ("valid", "partial")

    def to_dict(self) -> dict:
        return {
            "snapshot": self.snapshot.to_dict(),
            "validation_status": self.validation_status,
            "validation_errors": list(self.validation_errors),
            "validation_warnings": list(self.validation_warnings),
            "build_duration_s": round(self.build_duration_s, 6),
        }
