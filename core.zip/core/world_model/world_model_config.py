"""
IndiDrive AI — Phase 7 | World Model Configuration
=====================================================
All thresholds and limits that govern World Model construction.
No magic numbers are embedded in the engine — every configurable
value lives here with a documented default and can be overridden
from config/world_model_config.yaml.

Design rules (same as all prior phases):
  * dataclasses — typed and explicit
  * safe defaults matching Indian-road conditions
  * no hidden heuristics
  * forward-compatible: from_dict() ignores unknown keys
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Optional

__all__ = [
    "WorldModelConfig",
    "load_world_model_config",
]

# Schema version — bump when any field is renamed or removed.
CONFIG_VERSION = "7.0"


@dataclass
class WorldModelConfig:
    """
    Configuration container for the Phase 7 World Model.

    All thresholds are documented in comments.  Safe defaults are
    chosen to be conservative and non-blocking for a partial world.
    """

    # ------------------------------------------------------------------
    # Object limits
    # ------------------------------------------------------------------

    max_objects: int = 128
    """Maximum world objects retained in a single snapshot.
    Objects beyond this limit are dropped (lowest-quality first).
    """

    max_trajectory_points: int = 50
    """Maximum PredictedState points stored per object trajectory.
    Truncated from the end (nearest points are kept).
    """

    max_prediction_hypotheses: int = 8
    """Maximum behaviour hypotheses retained per object."""

    # ------------------------------------------------------------------
    # Road / anomaly limits
    # ------------------------------------------------------------------

    max_anomalies: int = 64
    """Maximum road anomaly observations stored in the snapshot."""

    max_boundary_points: int = 128
    """Maximum road-boundary or lane-boundary points kept per boundary."""

    # ------------------------------------------------------------------
    # Temporal thresholds
    # ------------------------------------------------------------------

    max_data_age_seconds: float = 1.0
    """Inputs older than this are considered STALE and marked as such."""

    timestamp_tolerance_seconds: float = 0.2
    """Cross-module timestamp difference within which data is treated as
    synchronised.  Beyond this, consistency warnings are added.
    """

    # ------------------------------------------------------------------
    # Object deduplication / merge
    # ------------------------------------------------------------------

    object_merge_distance_m: float = 0.5
    """Fallback merge distance (metres) when no stable identifier matches.
    Two objects of the same type within this distance may be merged.
    Only used when stable IDs are absent — position-only matching
    is a last resort.
    """

    object_merge_time_tolerance_s: float = 0.3
    """Objects from different sources are only considered for merge
    when their timestamps differ by less than this (seconds).
    """

    # ------------------------------------------------------------------
    # Confidence / uncertainty aggregation
    # ------------------------------------------------------------------

    confidence_object_weight: float = 0.5
    """Weight of individual object confidence in world completeness score."""

    confidence_road_weight: float = 0.3
    """Weight of road understanding confidence in world completeness score."""

    confidence_prediction_weight: float = 0.2
    """Weight of prediction confidence in world completeness score."""

    uncertainty_stale_penalty: float = 0.20
    """Added to world uncertainty score when any input is stale."""

    uncertainty_missing_module_penalty: float = 0.10
    """Added to world uncertainty score per missing upstream module."""

    uncertainty_degraded_module_penalty: float = 0.05
    """Added to world uncertainty score when any module is degraded."""

    # ------------------------------------------------------------------
    # Snapshot buffer
    # ------------------------------------------------------------------

    snapshot_buffer_size: int = 10
    """Maximum number of historical snapshots retained for diagnostic
    access.  When the buffer is full, the oldest snapshot is dropped.
    This is NOT an unbounded history — zero means no history kept.
    """

    # ------------------------------------------------------------------
    # Validation strictness
    # ------------------------------------------------------------------

    strict_coordinate_frame: bool = True
    """When True, inputs with an unrecognised or conflicting coordinate
    frame are rejected (marked INVALID) rather than accepted with a
    warning.
    """

    max_valid_position_m: float = 300.0
    """Objects further than this distance from the ego vehicle origin
    are flagged as suspicious (outside expected sensor range).
    """

    min_valid_confidence: float = 0.0
    """Minimum valid confidence value (inclusive)."""

    max_valid_confidence: float = 1.0
    """Maximum valid confidence value (inclusive)."""

    min_valid_dimension_m: float = 0.01
    """Minimum valid object dimension in metres (length/width/height)."""

    max_valid_dimension_m: float = 50.0
    """Maximum valid object dimension in metres."""

    # ------------------------------------------------------------------
    # Coordinate frame
    # ------------------------------------------------------------------

    expected_coordinate_frame: str = "VEHICLE"
    """Expected coordinate frame for all positional data.
    Vehicle-relative: +X forward, +Y left, +Z up, origin rear-axle centre.
    Inputs declaring a different frame are flagged unless
    strict_coordinate_frame is False.
    """

    # ------------------------------------------------------------------
    # Config meta
    # ------------------------------------------------------------------

    config_version: str = CONFIG_VERSION

    # ------------------------------------------------------------------

    @classmethod
    def from_dict(cls, d: dict) -> "WorldModelConfig":
        """Load from a dict (e.g. from yaml.safe_load).
        Unknown keys are silently ignored for forward compatibility.
        """
        cfg = cls()
        for key, value in d.items():
            if hasattr(cfg, key):
                expected_type = type(getattr(cfg, key))
                try:
                    setattr(cfg, key, expected_type(value))
                except (TypeError, ValueError):
                    pass  # silently keep default on bad type
        return cfg

    def to_dict(self) -> dict:
        return {
            "config_version": self.config_version,
            "max_objects": self.max_objects,
            "max_trajectory_points": self.max_trajectory_points,
            "max_prediction_hypotheses": self.max_prediction_hypotheses,
            "max_anomalies": self.max_anomalies,
            "max_boundary_points": self.max_boundary_points,
            "max_data_age_seconds": self.max_data_age_seconds,
            "timestamp_tolerance_seconds": self.timestamp_tolerance_seconds,
            "object_merge_distance_m": self.object_merge_distance_m,
            "object_merge_time_tolerance_s": self.object_merge_time_tolerance_s,
            "confidence_object_weight": self.confidence_object_weight,
            "confidence_road_weight": self.confidence_road_weight,
            "confidence_prediction_weight": self.confidence_prediction_weight,
            "uncertainty_stale_penalty": self.uncertainty_stale_penalty,
            "uncertainty_missing_module_penalty": self.uncertainty_missing_module_penalty,
            "uncertainty_degraded_module_penalty": self.uncertainty_degraded_module_penalty,
            "snapshot_buffer_size": self.snapshot_buffer_size,
            "strict_coordinate_frame": self.strict_coordinate_frame,
            "max_valid_position_m": self.max_valid_position_m,
            "min_valid_confidence": self.min_valid_confidence,
            "max_valid_confidence": self.max_valid_confidence,
            "min_valid_dimension_m": self.min_valid_dimension_m,
            "max_valid_dimension_m": self.max_valid_dimension_m,
            "expected_coordinate_frame": self.expected_coordinate_frame,
        }


def load_world_model_config(path: Optional[str] = None) -> WorldModelConfig:
    """Load WorldModelConfig from a YAML file.

    Falls back to safe defaults when the file is absent or unreadable.
    Never raises — returns a default config on any error.
    """
    if path is None:
        # Check default location
        root = Path(__file__).resolve().parent.parent.parent
        default = root / "config" / "world_model_config.yaml"
        path_obj = default
    else:
        path_obj = Path(path)

    if not path_obj.exists():
        return WorldModelConfig()

    try:
        import yaml  # type: ignore
        with open(path_obj, "r", encoding="utf-8") as f:
            data = yaml.safe_load(f)
        if isinstance(data, dict):
            return WorldModelConfig.from_dict(data)
    except Exception:
        pass  # fall back to defaults — never crash

    return WorldModelConfig()
