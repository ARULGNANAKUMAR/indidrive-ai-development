"""
IndiDrive AI — Phase 7 | World Model Validator
===============================================
Validates WorldModelSnapshot contents.

Rules:
  * Returns structured results — never raises
  * Clear status: valid | partial | degraded | invalid
  * All checks documented in comments
  * All thresholds come from WorldModelConfig
  * No silent swallowing of errors
"""
from __future__ import annotations

import math
import time
from dataclasses import dataclass, field
from typing import List

from .world_model_config import WorldModelConfig
from .world_model_types import (
    WorldModelSnapshot, WorldObject, WorldAnomalySummary,
    CoordinateFrame, WorldModelStatus,
)

__all__ = [
    "ValidationResult",
    "WorldModelValidator",
]


@dataclass
class ValidationResult:
    """Structured output of one validation run."""
    status: str = "valid"           # valid | partial | degraded | invalid
    errors: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)

    def add_error(self, msg: str) -> None:
        self.errors.append(msg)
        # Any error at minimum makes the result partial
        if self.status == "valid":
            self.status = "partial"

    def add_warning(self, msg: str) -> None:
        self.warnings.append(msg)

    def mark_degraded(self) -> None:
        if self.status in ("valid", "partial"):
            self.status = "degraded"

    def mark_invalid(self) -> None:
        self.status = "invalid"

    @property
    def is_usable(self) -> bool:
        return self.status in ("valid", "partial")


class WorldModelValidator:
    """
    Validates a WorldModelSnapshot against WorldModelConfig thresholds.

    All validation methods return a ValidationResult — never raise.
    The validate() method is the single entry point.
    """

    def __init__(self, config: WorldModelConfig) -> None:
        self._cfg = config

    def validate(self, snapshot: WorldModelSnapshot) -> ValidationResult:
        """
        Full validation pass on a snapshot.

        Checks (in order):
          1. Schema version
          2. Timestamp validity
          3. Coordinate frame
          4. Object collection
          5. Road representation
          6. Indian context
          7. Data quality fields
          8. Cross-field consistency
        """
        result = ValidationResult()

        self._check_schema(snapshot, result)
        self._check_timestamp(snapshot, result)
        self._check_coordinate_frame(snapshot, result)
        self._check_objects(snapshot, result)
        self._check_road(snapshot, result)
        self._check_indian_context(snapshot, result)
        self._check_data_quality(snapshot, result)
        self._check_snapshot_status_consistency(snapshot, result)

        return result

    # ------------------------------------------------------------------
    # Individual checks
    # ------------------------------------------------------------------

    def _check_schema(self, snap: WorldModelSnapshot, r: ValidationResult) -> None:
        """Schema version must be non-empty."""
        if not snap.schema_version:
            r.add_error("schema_version is empty")

    def _check_timestamp(self, snap: WorldModelSnapshot, r: ValidationResult) -> None:
        """Timestamp must be positive and finite; not unreasonably old."""
        ts = snap.timestamp
        if not (isinstance(ts, (int, float)) and math.isfinite(ts)):
            r.add_error(f"snapshot.timestamp is not finite: {ts!r}")
            return
        if ts <= 0:
            r.add_error(f"snapshot.timestamp is non-positive: {ts}")
            return
        age = time.time() - ts
        if age > self._cfg.max_data_age_seconds * 10:
            # Very stale — warn but don't invalidate (could be replay)
            r.add_warning(f"snapshot.timestamp is {age:.1f}s old (max_data_age={self._cfg.max_data_age_seconds}s)")

    def _check_coordinate_frame(self, snap: WorldModelSnapshot, r: ValidationResult) -> None:
        """Coordinate frame must be VEHICLE when strict mode is on."""
        if snap.coordinate_frame == CoordinateFrame.INVALID:
            r.add_error("snapshot.coordinate_frame is INVALID")
        elif snap.coordinate_frame == CoordinateFrame.UNKNOWN:
            r.add_warning("snapshot.coordinate_frame is UNKNOWN")
        elif snap.coordinate_frame != CoordinateFrame.VEHICLE:
            msg = f"unexpected coordinate_frame={snap.coordinate_frame.value}"
            if self._cfg.strict_coordinate_frame:
                r.add_error(msg)
            else:
                r.add_warning(msg)

    def _check_objects(self, snap: WorldModelSnapshot, r: ValidationResult) -> None:
        """Validate object collection."""
        if len(snap.objects) > self._cfg.max_objects:
            r.add_error(
                f"object count {len(snap.objects)} exceeds max_objects={self._cfg.max_objects}"
            )

        seen_ids: dict = {}  # primary_id -> index — detect duplicates
        for i, obj in enumerate(snap.objects):
            self._check_single_object(obj, i, r)
            pid = obj.primary_id()
            if pid is not None:
                if pid in seen_ids:
                    r.add_error(
                        f"objects[{i}] duplicate primary_id={pid!r} "
                        f"(also objects[{seen_ids[pid]}])"
                    )
                else:
                    seen_ids[pid] = i

    def _check_single_object(self, obj: WorldObject, idx: int, r: ValidationResult) -> None:
        """Validate one WorldObject."""
        prefix = f"objects[{idx}]"

        # Position
        pos = obj.position
        if pos.x is not None:
            if not math.isfinite(pos.x):
                r.add_error(f"{prefix}.position.x is not finite")
            elif abs(pos.x) > self._cfg.max_valid_position_m:
                r.add_warning(f"{prefix}.position.x={pos.x:.1f}m exceeds max_valid_position_m")
        if pos.y is not None:
            if not math.isfinite(pos.y):
                r.add_error(f"{prefix}.position.y is not finite")
            elif abs(pos.y) > self._cfg.max_valid_position_m:
                r.add_warning(f"{prefix}.position.y={pos.y:.1f}m exceeds max_valid_position_m")

        # Dimensions
        dim = obj.dimensions
        for attr, name in [("length_m", "length"), ("width_m", "width"), ("height_m", "height")]:
            v = getattr(dim, attr)
            if v is not None:
                if not math.isfinite(v):
                    r.add_error(f"{prefix}.dimensions.{name} is not finite")
                elif v < self._cfg.min_valid_dimension_m or v > self._cfg.max_valid_dimension_m:
                    r.add_warning(
                        f"{prefix}.dimensions.{name}={v:.3f}m outside "
                        f"[{self._cfg.min_valid_dimension_m}, {self._cfg.max_valid_dimension_m}]"
                    )

        # Confidence / probability [0, 1]
        q = obj.quality
        for attr in ("object_confidence", "position_confidence", "velocity_confidence",
                     "existence_probability"):
            v = getattr(q, attr)
            if not (isinstance(v, (int, float)) and math.isfinite(v)):
                r.add_error(f"{prefix}.quality.{attr} is not finite: {v!r}")
            elif not (self._cfg.min_valid_confidence <= v <= self._cfg.max_valid_confidence):
                r.add_error(
                    f"{prefix}.quality.{attr}={v:.3f} outside "
                    f"[{self._cfg.min_valid_confidence}, {self._cfg.max_valid_confidence}]"
                )

        # Collision likelihood [0, 1] when present
        cl = obj.collision.collision_likelihood
        if cl is not None:
            if not math.isfinite(cl):
                r.add_error(f"{prefix}.collision.collision_likelihood is not finite")
            elif not (0.0 <= cl <= 1.0):
                r.add_error(f"{prefix}.collision.collision_likelihood={cl:.3f} outside [0,1]")

        # Prediction trajectory size
        n_traj = len(obj.prediction.trajectory)
        if n_traj > self._cfg.max_trajectory_points:
            r.add_error(
                f"{prefix}.prediction.trajectory has {n_traj} points "
                f"(max={self._cfg.max_trajectory_points})"
            )

        # Timestamp
        ot = obj.observation_timestamp
        if not (isinstance(ot, (int, float)) and math.isfinite(ot) and ot >= 0):
            r.add_error(f"{prefix}.observation_timestamp is invalid: {ot!r}")

    def _check_road(self, snap: WorldModelSnapshot, r: ValidationResult) -> None:
        """Validate road representation."""
        road = snap.road

        # Road confidence/uncertainty bounds
        rc = road.road_confidence
        if not (isinstance(rc, (int, float)) and math.isfinite(rc) and 0.0 <= rc <= 1.0):
            r.add_error(f"road.road_confidence={rc!r} outside [0,1]")

        ru = road.road_uncertainty
        if not (isinstance(ru, (int, float)) and math.isfinite(ru) and ru >= 0.0):
            r.add_error(f"road.road_uncertainty={ru!r} must be >= 0")

        # Anomaly count
        if len(road.anomalies) > self._cfg.max_anomalies:
            r.add_error(
                f"road.anomalies count {len(road.anomalies)} exceeds max_anomalies={self._cfg.max_anomalies}"
            )

        # Validate each anomaly
        for i, anomaly in enumerate(road.anomalies):
            self._check_anomaly(anomaly, i, r)

    def _check_anomaly(self, anomaly: WorldAnomalySummary, idx: int, r: ValidationResult) -> None:
        """Validate one anomaly summary."""
        prefix = f"road.anomalies[{idx}]"
        # Position values if present must be finite
        for attr in ("position_x", "position_y"):
            v = getattr(anomaly, attr)
            if v is not None and (not isinstance(v, (int, float)) or not math.isfinite(v)):
                r.add_error(f"{prefix}.{attr} is not finite: {v!r}")
        # Confidence bounds
        c = anomaly.confidence
        if not (isinstance(c, (int, float)) and math.isfinite(c) and 0.0 <= c <= 1.0):
            r.add_error(f"{prefix}.confidence={c!r} outside [0,1]")

    def _check_indian_context(self, snap: WorldModelSnapshot, r: ValidationResult) -> None:
        """Validate Indian context summary."""
        ctx = snap.indian_context
        cc = ctx.context_confidence
        if not (isinstance(cc, (int, float)) and math.isfinite(cc) and 0.0 <= cc <= 1.0):
            r.add_error(f"indian_context.context_confidence={cc!r} outside [0,1]")
        cu = ctx.context_uncertainty
        if not (isinstance(cu, (int, float)) and math.isfinite(cu) and cu >= 0.0):
            r.add_error(f"indian_context.context_uncertainty={cu!r} must be >= 0")

    def _check_data_quality(self, snap: WorldModelSnapshot, r: ValidationResult) -> None:
        """Validate WorldDataQuality fields."""
        dq = snap.data_quality
        for attr in ("overall_confidence", "completeness", "freshness"):
            v = getattr(dq, attr)
            if not (isinstance(v, (int, float)) and math.isfinite(v) and 0.0 <= v <= 1.0):
                r.add_error(f"data_quality.{attr}={v!r} outside [0,1]")
        ou = dq.overall_uncertainty
        if not (isinstance(ou, (int, float)) and math.isfinite(ou) and ou >= 0.0):
            r.add_error(f"data_quality.overall_uncertainty={ou!r} must be >= 0")

    def _check_snapshot_status_consistency(
        self, snap: WorldModelSnapshot, r: ValidationResult
    ) -> None:
        """Cross-check: status should match observed state."""
        if snap.status == WorldModelStatus.EMPTY and snap.object_count > 0:
            r.add_warning(
                f"snapshot.status=EMPTY but object_count={snap.object_count} — "
                "consider PARTIAL or OK"
            )
        if snap.status == WorldModelStatus.OK and snap.data_quality.is_partial:
            r.add_warning(
                "snapshot.status=OK but data_quality.is_partial=True"
            )
