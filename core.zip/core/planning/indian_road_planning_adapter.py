"""
IndiDrive AI — Phase 9.5 | Indian-Road Path Planning Adapter
=============================================================
Translates Phase 6.4 Indian-road context into planning constraints and
candidate-generation parameters for Phase 9.2.

Phase 9.5 answers:
    «"Given the current Indian-road context, what planning constraints
      should shape Phase 9.2 candidate path generation this cycle?"»

Phase 9.5 does NOT:
  - select a final/best/optimal path
  - issue steering / throttle / brake / target_speed commands
  - implement MPC or any vehicle controller
  - re-implement road perception (Phase 6)
  - re-implement risk scoring (Phase 9.3)
  - re-implement replanning decision (Phase 9.4)
  - call LLMs, cloud APIs, or neural networks

Architecture position:

    Phase 6.4  IndianRoadContextState
         +
    Phase 9.1  PlanningSpace  (carries IndianRoadContextSummary)
         +
    Phase 9.4  ReplanningRequest  (triggers refresh when replanning needed)
         ↓
    Phase 9.5  IndianRoadPlanningAdapter.build_constraints()
         ↓
    IndianRoadPlanningConstraints
         ↓
    Phase 9.2  CandidatePathGenerator  (receives adapted config)
         ↓
    CandidatePathSet
         ↓
    Phase 9.3  PathRiskEngine

Design rules:
  * stateful only for mode hysteresis (previous mode + frame counter)
  * deterministic: same inputs → same mode → same constraints
  * lightweight: no image/LiDAR processing, no solvers, no deep learning
  * graceful degradation when any input is missing
  * no random() / uuid4() for planning decisions
"""
from __future__ import annotations

import math
import time
from dataclasses import replace
from typing import List, Optional, Tuple

from .indian_road_planning_config import IndianRoadPlanningConfig
from .indian_road_planning_types import (
    INDIAN_ROAD_PLANNING_SCHEMA_VERSION,
    IndianRoadPlanningConstraints,
    IndianRoadPlanningResult,
    LaneUsageMode,
    NarrowRoadState,
    PlanningMode,
    RoadAnomalyConstraint,
    TrafficContextSummary,
)
from .planning_input_types import PlanningInput
from .planning_space_types import PlanningSpace

__all__ = [
    "IndianRoadPlanningAdapter",
]

# ---------------------------------------------------------------------------
# Internal helpers for reading Phase 6.4 context from PlanningSpace
# ---------------------------------------------------------------------------

def _get_indian_context(planning_space: Optional[PlanningSpace]) -> Optional[object]:
    """Return the IndianRoadContextSummary embedded in planning_space, or None."""
    if planning_space is None:
        return None
    ctx = getattr(planning_space, "indian_road_context", None)
    return ctx if (ctx is not None and getattr(ctx, "available", False)) else None


def _get_lane_confidence(planning_space: Optional[PlanningSpace]) -> float:
    """Return the lane/road confidence from the planning space quality, [0, 1]."""
    if planning_space is None:
        return 0.0
    quality = getattr(planning_space, "quality", None)
    if quality is None:
        return 0.0
    # Use overall_confidence as proxy for lane info quality
    return float(getattr(quality, "overall_confidence", 0.0))


def _get_road_width_m(planning_space: Optional[PlanningSpace]) -> Optional[float]:
    """Return road width estimate from planning space spatial_extent, or None."""
    if planning_space is None:
        return None
    extent = getattr(planning_space, "spatial_extent", None)
    if extent is None:
        return None
    # Phase 9.1 spatial_extent has left_boundary_y_m and right_boundary_y_m
    left = getattr(extent, "left_boundary_y_m", None)
    right = getattr(extent, "right_boundary_y_m", None)
    if left is not None and right is not None:
        try:
            w = float(left) - float(right)
            return w if (math.isfinite(w) and w > 0) else None
        except (TypeError, ValueError):
            return None
    return None


# ---------------------------------------------------------------------------
# Mode selection logic (pure function — no state dependency)
# ---------------------------------------------------------------------------

_HIGH_DENSITY_TIERS = {"HIGH", "VERY_HIGH"}

def _select_mode_from_context(
    ctx,                   # IndianRoadContextSummary | None
    lane_confidence: float,
    road_width_m: Optional[float],
    cfg: IndianRoadPlanningConfig,
) -> PlanningMode:
    """
    Select PlanningMode deterministically from available context evidence.

    Precedence (highest → lowest):
      1. No context → DEGRADED
      2. Intersection area → INTERSECTION
      3. Highway / merge → HIGHWAY
      4. Very-narrow + unmarked → NARROW_ROAD
      5. Dense mixed traffic → MIXED_TRAFFIC
      6. Narrow road by width or road_type → NARROW_ROAD
      7. Unmarked / weak-marked → DRIVABLE_SPACE
      8. Reliable lanes → LANE_GUIDED
      9. Fallback → UNKNOWN
    """
    if ctx is None:
        return PlanningMode.DEGRADED

    road_type = str(getattr(ctx, "road_type", "UNKNOWN"))
    traffic_density = str(getattr(ctx, "traffic_density", "UNKNOWN"))
    intersection = str(getattr(ctx, "intersection_context", "UNKNOWN"))
    complexity = str(getattr(ctx, "road_complexity", "UNKNOWN"))
    context_confidence = float(getattr(ctx, "context_confidence", 0.0))

    # 1. Intersection takes precedence when confirmed
    if intersection in ("INTERSECTION", "COMPLEX_INTERSECTION"):
        return PlanningMode.INTERSECTION

    # 2. Highway / merge
    if road_type in ("HIGHWAY", "HIGHWAY_MERGE_AREA"):
        return PlanningMode.HIGHWAY

    # Determine road width state
    nw_state = _narrow_road_state(road_width_m, road_type, cfg)

    # 3. Dense mixed traffic (overrides narrow if both apply; retains lateral constraint)
    if traffic_density in _HIGH_DENSITY_TIERS:
        return PlanningMode.MIXED_TRAFFIC

    # 4. Narrow road (by width or road_type)
    if nw_state in (NarrowRoadState.NARROW, NarrowRoadState.VERY_NARROW):
        return PlanningMode.NARROW_ROAD

    # 5. Unmarked / very weak lanes → drivable-space
    if lane_confidence < cfg.unmarked_road_threshold:
        return PlanningMode.DRIVABLE_SPACE

    # 6. Reliable lane markings
    if lane_confidence >= cfg.lane_confidence_threshold:
        return PlanningMode.LANE_GUIDED

    # 7. Village / market roads with moderate confidence → drivable-space
    if road_type in ("VILLAGE_ROAD", "MARKET_ROAD", "NARROW_ROAD", "RESIDENTIAL_ROAD"):
        return PlanningMode.DRIVABLE_SPACE

    # 8. Context available but confidence is in the intermediate band → drivable-space
    if context_confidence < 0.4:
        return PlanningMode.DRIVABLE_SPACE

    return PlanningMode.UNKNOWN


def _narrow_road_state(
    road_width_m: Optional[float],
    road_type: str,
    cfg: IndianRoadPlanningConfig,
) -> NarrowRoadState:
    """Determine NarrowRoadState from road width and road_type."""
    # If road_type explicitly says narrow
    if road_type in ("NARROW_ROAD", "VILLAGE_ROAD"):
        if road_width_m is not None:
            if road_width_m < cfg.very_narrow_road_width_m:
                return NarrowRoadState.VERY_NARROW
            if road_width_m < cfg.narrow_road_width_m:
                return NarrowRoadState.NARROW
        # No width data but road_type says narrow → assume NARROW
        return NarrowRoadState.NARROW

    if road_width_m is None:
        return NarrowRoadState.UNKNOWN

    if road_width_m < cfg.very_narrow_road_width_m:
        return NarrowRoadState.VERY_NARROW
    if road_width_m < cfg.narrow_road_width_m:
        return NarrowRoadState.NARROW
    if road_width_m < cfg.approaching_narrow_width_m:
        return NarrowRoadState.APPROACHING

    return NarrowRoadState.NOT_NARROW


def _lane_usage_mode(
    mode: PlanningMode,
    lane_confidence: float,
    cfg: IndianRoadPlanningConfig,
) -> LaneUsageMode:
    """Derive LaneUsageMode from planning mode and lane confidence."""
    if mode == PlanningMode.LANE_GUIDED:
        return LaneUsageMode.STRICT
    if mode in (PlanningMode.HIGHWAY,):
        return LaneUsageMode.STRICT if lane_confidence >= cfg.lane_confidence_threshold else LaneUsageMode.ADVISORY
    if lane_confidence >= cfg.unmarked_road_threshold:
        return LaneUsageMode.ADVISORY
    return LaneUsageMode.IGNORE


# ---------------------------------------------------------------------------
# Lateral freedom computation
# ---------------------------------------------------------------------------

def _lateral_freedom(
    mode: PlanningMode,
    nw_state: NarrowRoadState,
    cfg: IndianRoadPlanningConfig,
) -> Tuple[float, float]:
    """Return (max_lateral_offset_m, lateral_step_m) for the current mode."""
    if nw_state == NarrowRoadState.VERY_NARROW:
        return (cfg.very_narrow_max_lateral_offset_m, 0.0)
    if nw_state == NarrowRoadState.NARROW or mode == PlanningMode.NARROW_ROAD:
        return (cfg.narrow_road_max_lateral_offset_m, cfg.narrow_road_lateral_step_m)

    if mode == PlanningMode.HIGHWAY:
        return (cfg.highway_max_lateral_offset_m, cfg.default_lateral_step_m)
    if mode == PlanningMode.DRIVABLE_SPACE:
        return (cfg.drivable_space_max_lateral_offset_m, cfg.default_lateral_step_m)
    if mode == PlanningMode.MIXED_TRAFFIC:
        return (cfg.mixed_traffic_max_lateral_offset_m, cfg.narrow_road_lateral_step_m)

    return (cfg.default_max_lateral_offset_m, cfg.default_lateral_step_m)


# ---------------------------------------------------------------------------
# Clearance margin computation
# ---------------------------------------------------------------------------

def _clearance_margins(
    mode: PlanningMode,
    nw_state: NarrowRoadState,
    traffic_ctx: TrafficContextSummary,
    cfg: IndianRoadPlanningConfig,
) -> dict:
    """Return a dict of clearance margins derived from context + config."""

    # Road-edge margin
    if nw_state == NarrowRoadState.VERY_NARROW:
        edge_margin = cfg.road_edge_margin_narrow_m
    elif nw_state == NarrowRoadState.NARROW:
        edge_margin = cfg.road_edge_margin_narrow_m
    else:
        edge_margin = cfg.road_edge_margin_default_m

    # General obstacle clearance
    if mode == PlanningMode.MIXED_TRAFFIC or traffic_ctx.market_like:
        obs_clearance = cfg.obstacle_clearance_market_m
    else:
        obs_clearance = cfg.obstacle_clearance_default_m

    vru_margin = cfg.vulnerable_user_margin_m if traffic_ctx.has_vulnerable_road_users else 0.0
    cattle_margin = cfg.cattle_clearance_margin_m if traffic_ctx.has_cattle else 0.0
    wrong_side = cfg.wrong_side_margin_m if traffic_ctx.has_wrong_side_traffic else 0.0

    return {
        "road_edge_margin_m": edge_margin,
        "obstacle_clearance_margin_m": obs_clearance,
        "vulnerable_user_margin_m": vru_margin,
        "cattle_clearance_margin_m": cattle_margin,
        "wrong_side_margin_m": wrong_side,
    }


# ---------------------------------------------------------------------------
# Traffic context extraction
# ---------------------------------------------------------------------------

def _traffic_context_from_indian_road(ctx) -> TrafficContextSummary:
    """Build a TrafficContextSummary from an IndianRoadContextSummary."""
    if ctx is None:
        return TrafficContextSummary()

    traffic_mix = getattr(ctx, "traffic_mix", None)
    roadside = getattr(ctx, "roadside_activity", "UNKNOWN")

    # Detect wrong-side traffic from context flags (Phase 6.4 ContextFlag)
    context_flags = getattr(ctx, "context_flags", [])
    flag_vals = {str(f) for f in (context_flags or [])}
    has_wrong_side = any("WRONG" in f or "ONCOMING" in f for f in flag_vals)

    density = str(getattr(ctx, "traffic_density", "UNKNOWN"))
    market = bool(getattr(ctx, "market_like_activity", False))
    cattle = bool(getattr(ctx, "cattle_present", False))
    vru = bool(getattr(ctx, "vulnerable_road_users", False))

    has_peds = False
    has_motos = False
    has_carts = False
    if traffic_mix is not None:
        has_peds = bool(getattr(traffic_mix, "pedestrians_present", False))
        has_motos = bool(getattr(traffic_mix, "motorcycles_present", False))
        has_carts = bool(getattr(traffic_mix, "non_motorised_present", False))

    return TrafficContextSummary(
        has_wrong_side_traffic=has_wrong_side,
        has_cattle=cattle,
        has_vulnerable_road_users=vru or has_peds,
        has_pedestrians=has_peds,
        has_motorcycles=has_motos,
        has_pushcarts=has_carts,
        high_density=density in _HIGH_DENSITY_TIERS,
        roadside_activity_level=str(roadside) if roadside else "UNKNOWN",
        market_like=market,
        confidence=float(getattr(ctx, "context_confidence", 0.0)),
    )


# ---------------------------------------------------------------------------
# Road anomaly constraint extraction
# ---------------------------------------------------------------------------

def _anomaly_constraints_from_space(
    planning_space: Optional[PlanningSpace],
    cfg: IndianRoadPlanningConfig,
) -> Tuple[RoadAnomalyConstraint, ...]:
    """
    Convert Phase 9.1 static hazard entries (from Phase 6.3) into
    RoadAnomalyConstraint objects.  Does NOT re-run road anomaly detection.
    """
    if planning_space is None:
        return ()

    hazards = getattr(planning_space, "static_hazards", ())
    if not hazards:
        return ()

    constraints: List[RoadAnomalyConstraint] = []
    for h in hazards:
        h_type = str(getattr(h, "hazard_type", "UNKNOWN")).upper()
        # Only road-surface anomalies (not static obstacles like parked cars)
        road_anomaly_types = {
            "POTHOLE", "CRACK", "GRAVEL", "DEBRIS",
            "CONSTRUCTION", "DAMAGED_SURFACE", "WATER_POOL",
            "ROAD_ANOMALY", "ROAD_DAMAGE", "UNKNOWN",
        }
        if not any(t in h_type for t in road_anomaly_types):
            continue

        lateral = float(getattr(h, "lateral_offset_y_m", 0.0) or 0.0)
        longitudinal = float(getattr(h, "longitudinal_offset_x_m", 0.0) or 0.0)
        width = float(getattr(h, "width_m", 0.5) or 0.5)
        confidence = float(getattr(h, "confidence", 0.0) or 0.0)
        passable = bool(getattr(h, "passable", False))

        if not (math.isfinite(lateral) and math.isfinite(longitudinal)):
            continue

        constraints.append(
            RoadAnomalyConstraint(
                anomaly_type=h_type,
                lateral_offset_m=lateral,
                longitudinal_offset_m=longitudinal,
                affected_width_m=max(0.1, width),
                avoidance_margin_m=cfg.anomaly_avoidance_margin_m,
                confidence=confidence,
                passable=passable,
            )
        )

    return tuple(constraints)


# ---------------------------------------------------------------------------
# Main adapter class
# ---------------------------------------------------------------------------

class IndianRoadPlanningAdapter:
    """
    Phase 9.5 — Indian-Road Path Planning Adapter.

    Consumes:
      - Phase 6.4 IndianRoadContextState (via PlanningSpace.indian_road_context)
      - Phase 9.1 PlanningSpace
      - Phase 9.1 PlanningInput
      - Phase 9.4 ReplanningRequest (optional, triggers refresh)

    Produces:
      - IndianRoadPlanningConstraints (for Phase 9.2 candidate generation)
      - IndianRoadPlanningResult (envelope with status + warnings)

    Does NOT produce:
      - steering / throttle / brake commands
      - selected_path / best_path / optimal_path
      - vehicle control commands
      - MPC output
    """

    def __init__(self, config: Optional[IndianRoadPlanningConfig] = None) -> None:
        self._config = config or IndianRoadPlanningConfig()

        # Hysteresis state
        self._current_mode: PlanningMode = PlanningMode.UNKNOWN
        self._mode_frame_count: int = 0
        self._last_frame_id: int = -1

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def build_constraints(
        self,
        planning_input: Optional[PlanningInput],
        planning_space: Optional[PlanningSpace],
        replanning_request=None,  # Optional ReplanningRequest from Phase 9.4
    ) -> IndianRoadPlanningResult:
        """
        Build IndianRoadPlanningConstraints for the current planning cycle.

        Parameters
        ----------
        planning_input      : Phase 9.1 PlanningInput (carries frame_id,
                              timestamp, and references to WorldModel/
                              PlanningContext).
        planning_space      : Phase 9.1 PlanningSpace (carries
                              IndianRoadContextSummary from Phase 6.4,
                              spatial_extent, static_hazards).
        replanning_request  : Optional Phase 9.4 ReplanningRequest that
                              triggered this cycle — used only to extract
                              frame_id / urgency for logging; no logic
                              changes based on urgency (that is 9.4's role).

        Returns
        -------
        IndianRoadPlanningResult — constraints + status + warnings.
        Never raises.
        """
        try:
            return self._build_impl(planning_input, planning_space, replanning_request)
        except Exception as exc:  # pragma: no cover — belt-and-suspenders
            return self._fallback_result(
                frame_id=getattr(planning_input, "frame_id", 0),
                reason=f"Unexpected adapter error: {exc}",
            )

    def reset_hysteresis(self) -> None:
        """Reset mode hysteresis state (e.g. on a new scenario or test reset)."""
        self._current_mode = PlanningMode.UNKNOWN
        self._mode_frame_count = 0
        self._last_frame_id = -1

    # ------------------------------------------------------------------
    # Internal implementation
    # ------------------------------------------------------------------

    def _build_impl(
        self,
        planning_input: Optional[PlanningInput],
        planning_space: Optional[PlanningSpace],
        replanning_request,
    ) -> IndianRoadPlanningResult:
        cfg = self._config
        warnings: List[str] = []

        # --- Extract frame / timestamp identity ---------------------------
        frame_id = getattr(planning_input, "frame_id", 0)
        if frame_id is None:
            frame_id = 0
        ts = time.time()

        # --- Validate primary inputs --------------------------------------
        if not cfg.enabled:
            return self._fallback_result(frame_id, "Phase 9.5 disabled in config.")

        if planning_space is None:
            warnings.append("PlanningSpace is None; returning degraded constraints.")
            return self._fallback_result(frame_id, warnings[-1])

        # --- Check context availability -----------------------------------
        ctx = _get_indian_context(planning_space)
        if ctx is None:
            warnings.append(
                "IndianRoadContextSummary unavailable or not yet populated; "
                "using generic drivable-space fallback."
            )

        # --- Extract inputs from planning space ---------------------------
        lane_confidence = _get_lane_confidence(planning_space)
        road_width_m = _get_road_width_m(planning_space)

        # Road width from Indian context takes precedence over spatial_extent
        if ctx is not None:
            ctx_width = getattr(ctx, "road_width_m", None)
            if ctx_width is not None:
                try:
                    w = float(ctx_width)
                    if math.isfinite(w) and w > 0:
                        road_width_m = w
                except (TypeError, ValueError):
                    pass

        road_type = str(getattr(ctx, "road_type", "UNKNOWN")) if ctx else "UNKNOWN"
        marking_state = "UNKNOWN"
        if ctx is not None:
            # IndianRoadContextSummary doesn't carry marking_state directly;
            # derive from lane_confidence
            if lane_confidence >= cfg.lane_confidence_threshold:
                marking_state = "MARKED"
            elif lane_confidence >= cfg.unmarked_road_threshold:
                marking_state = "WEAKLY_MARKED"
            else:
                marking_state = "UNMARKED"

        context_confidence = float(getattr(ctx, "context_confidence", 0.0)) if ctx else 0.0
        context_uncertainty = 1.0 - context_confidence
        is_degraded = (ctx is None) or bool(getattr(ctx, "is_degraded", True))

        # --- Mode selection (with hysteresis) -----------------------------
        candidate_mode = _select_mode_from_context(
            ctx, lane_confidence, road_width_m, cfg
        )
        final_mode = self._apply_hysteresis(candidate_mode, frame_id)

        # --- Derived sub-structures ---------------------------------------
        nw_state = _narrow_road_state(road_width_m, road_type, cfg)
        lane_mode = _lane_usage_mode(final_mode, lane_confidence, cfg)
        traffic_ctx = _traffic_context_from_indian_road(ctx)
        anomaly_constraints = _anomaly_constraints_from_space(planning_space, cfg)

        max_lat, lat_step = _lateral_freedom(final_mode, nw_state, cfg)
        clearances = _clearance_margins(final_mode, nw_state, traffic_ctx, cfg)

        drivable_required = final_mode in (
            PlanningMode.DRIVABLE_SPACE,
            PlanningMode.NARROW_ROAD,
            PlanningMode.MIXED_TRAFFIC,
            PlanningMode.DEGRADED,
        )
        use_center_tendency = final_mode == PlanningMode.DRIVABLE_SPACE

        # --- Validate numeric values -------------------------------------
        if not math.isfinite(max_lat) or max_lat < 0:
            warnings.append(f"max_lateral_offset_m={max_lat} is invalid; clamping to 0.")
            max_lat = 0.0
        if not math.isfinite(lat_step) or lat_step < 0:
            lat_step = 0.0

        # --- Assemble constraints ----------------------------------------
        constraints = IndianRoadPlanningConstraints(
            frame_id=frame_id,
            timestamp=ts,
            schema_version=INDIAN_ROAD_PLANNING_SCHEMA_VERSION,
            planning_mode=final_mode,
            lane_usage_mode=lane_mode,
            narrow_road_state=nw_state,
            max_lateral_offset_m=max_lat,
            lateral_offset_step_m=lat_step,
            road_edge_margin_m=clearances["road_edge_margin_m"],
            obstacle_clearance_margin_m=clearances["obstacle_clearance_margin_m"],
            vulnerable_user_margin_m=clearances["vulnerable_user_margin_m"],
            cattle_clearance_margin_m=clearances["cattle_clearance_margin_m"],
            wrong_side_margin_m=clearances["wrong_side_margin_m"],
            drivable_region_required=drivable_required,
            use_road_center_tendency=use_center_tendency,
            road_anomaly_constraints=anomaly_constraints,
            traffic_context=traffic_ctx,
            confidence=context_confidence,
            uncertainty=context_uncertainty,
            degraded=is_degraded,
            road_type=road_type,
            marking_state=marking_state,
            road_width_m=road_width_m,
        )

        status = "DEGRADED" if (is_degraded or final_mode == PlanningMode.DEGRADED) else "OK"
        if warnings:
            status = "FALLBACK" if status == "OK" else status

        return IndianRoadPlanningResult(
            constraints=constraints,
            status=status,
            warnings=tuple(warnings),
            schema_version=INDIAN_ROAD_PLANNING_SCHEMA_VERSION,
        )

    # ------------------------------------------------------------------
    # Hysteresis
    # ------------------------------------------------------------------

    def _apply_hysteresis(self, candidate: PlanningMode, frame_id: int) -> PlanningMode:
        """
        Apply mode-persistence hysteresis to prevent rapid switching.

        Rules:
          - If candidate == current mode → increment frame counter, keep mode.
          - If candidate != current mode:
              - If frame counter >= mode_persistence_frames → switch + reset counter.
              - Else → keep old mode, do not reset counter
                       (counts frames in the *new* candidate direction).
          - DEGRADED and UNKNOWN are never suppressed by hysteresis — they
            always pass through immediately.
          - frame_id wrap-around (int overflow) is harmless.
        """
        cfg = self._config

        # Always propagate safety-critical states immediately
        if candidate in (PlanningMode.DEGRADED, PlanningMode.UNKNOWN):
            self._current_mode = candidate
            self._mode_frame_count = 0
            self._last_frame_id = frame_id
            return candidate

        # First call or same candidate
        if self._current_mode == PlanningMode.UNKNOWN or candidate == self._current_mode:
            self._current_mode = candidate
            self._mode_frame_count += 1
            self._last_frame_id = frame_id
            return self._current_mode

        # Candidate has changed — check persistence
        self._mode_frame_count += 1
        if self._mode_frame_count >= cfg.mode_persistence_frames:
            # Switch accepted
            self._current_mode = candidate
            self._mode_frame_count = 0

        self._last_frame_id = frame_id
        return self._current_mode

    # ------------------------------------------------------------------
    # Fallback / error helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _fallback_result(
        frame_id: int,
        reason: str = "",
    ) -> IndianRoadPlanningResult:
        """Return a safe degraded result when critical inputs are missing."""
        constraints = IndianRoadPlanningConstraints(
            frame_id=frame_id,
            timestamp=time.time(),
            schema_version=INDIAN_ROAD_PLANNING_SCHEMA_VERSION,
            planning_mode=PlanningMode.DEGRADED,
            lane_usage_mode=LaneUsageMode.IGNORE,
            narrow_road_state=NarrowRoadState.UNKNOWN,
            max_lateral_offset_m=0.5,
            lateral_offset_step_m=0.25,
            drivable_region_required=True,
            use_road_center_tendency=True,
            confidence=0.0,
            uncertainty=1.0,
            degraded=True,
        )
        return IndianRoadPlanningResult(
            constraints=constraints,
            status="FALLBACK",
            warnings=(reason,) if reason else (),
            schema_version=INDIAN_ROAD_PLANNING_SCHEMA_VERSION,
        )
