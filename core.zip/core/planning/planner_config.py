"""
IndiDrive AI — Phase 9.6 | Final Planner Integration — Configuration
=====================================================================
Configuration for the Phase 9.6 integrated planner pipeline.

Reuses existing phase-specific configs where possible.
Only adds values specific to the integration layer.
"""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from typing import Optional

import yaml

__all__ = [
    "PlannerConfig",
    "load_planner_config",
    "DEFAULT_PLANNER_CONFIG_PATH",
]

DEFAULT_PLANNER_CONFIG_PATH = os.path.join(
    os.path.dirname(__file__), "..", "..", "config", "planner96_config.yaml"
)


@dataclass
class PlannerConfig:
    """
    Configuration for the Phase 9.6 integrated planner.

    Thresholds marked (ms) are in milliseconds.
    Thresholds marked (s) are in seconds.
    """

    # --- Global enable flag -------------------------------------------------
    enabled: bool = True

    # --- Input staleness thresholds (seconds) -------------------------------
    max_world_model_age_s: float = 2.0
    max_planning_context_age_s: float = 2.0
    max_planning_space_age_s: float = 2.0
    max_candidate_set_age_s: float = 2.0
    max_risk_set_age_s: float = 2.0
    max_replanning_result_age_s: float = 2.0

    # --- Required inputs ----------------------------------------------------
    require_world_model: bool = False       # degrade gracefully without it
    require_planning_context: bool = False  # degrade gracefully without it
    require_planning_space: bool = True
    require_candidate_set: bool = True
    require_risk_set: bool = True

    # --- Planning permission -------------------------------------------------
    allow_degraded_planning: bool = True
    """Allow the planner to produce a degraded result when inputs are stale."""

    # --- Candidate selection (planning-level only) --------------------------
    allow_selection: bool = True
    """
    When True, the planner selects the lowest-risk valid candidate as a
    planning-level recommendation (NOT a vehicle control command).
    Selection is deterministic: lowest composite risk score, tie-broken by
    ascending candidate_id string comparison.
    """

    # --- Risk thresholds for selection --------------------------------------
    max_acceptable_risk_score: float = 0.80
    """
    Candidates with composite risk score above this threshold are not eligible
    for selection.  If all candidates exceed this, status becomes BLOCKED.
    """

    # --- Coordinate frame validation ----------------------------------------
    expected_coordinate_frame: str = "VEHICLE"

    # --- Benchmark ----------------------------------------------------------
    benchmark_enabled: bool = True


def load_planner_config(path: Optional[str] = None) -> PlannerConfig:
    """Load PlannerConfig from a YAML file, falling back to defaults."""
    cfg = PlannerConfig()
    config_path = path or DEFAULT_PLANNER_CONFIG_PATH
    if os.path.exists(config_path):
        try:
            with open(config_path, "r") as fh:
                raw = yaml.safe_load(fh) or {}
            section = raw.get("phase_9_6", raw.get("planner96", {}))
            for key, value in section.items():
                if hasattr(cfg, key):
                    setattr(cfg, key, value)
        except Exception:
            pass  # use defaults on any parse error
    return cfg
