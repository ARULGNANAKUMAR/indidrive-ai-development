"""
IndiDrive AI — Phase 9.5 | Indian-Road Path Planning — Data Contracts
=======================================================================
Strongly-typed structural containers for Phase 9.5 Indian-Road Path Planning.

Phase 9.5 answers:
    «"Given the current Indian-road context, what planning constraints and
      candidate-generation parameters are appropriate for this cycle?"»

Phase 9.5 does NOT answer:
    «"Which path should the vehicle take?"»
    «"What is the target speed?"»
    «"What steering / throttle / brake should be applied?"»

Design rules:
  * dataclasses — not raw dicts
  * explicit NOT_AVAILABLE / UNKNOWN — never fabricated
  * deterministic: same input → same output
  * no steering, no throttle, no brake, no target_speed, no selected_path
  * no best_path, no optimal_path, no vehicle_control
  * offline — no LLM, no cloud, no neural networks
  * lightweight — only transforms existing structured context into constraints

Coordinate convention (vehicle frame — same as Phase 9.1/9.2):
    +X = forward
    +Y = left
    +Z = up
    Origin = vehicle rear-axle centre
    Units = metres
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from enum import Enum
from typing import List, Optional, Tuple

__all__ = [
    # Sentinel / schema
    "NOT_AVAILABLE",
    "INDIAN_ROAD_PLANNING_SCHEMA_VERSION",
    # Enums
    "PlanningMode",
    "LaneUsageMode",
    "NarrowRoadState",
    # Sub-structures
    "RoadAnomalyConstraint",
    "TrafficContextSummary",
    # Primary output
    "IndianRoadPlanningConstraints",
    "IndianRoadPlanningResult",
]

NOT_AVAILABLE = "NOT_AVAILABLE"
INDIAN_ROAD_PLANNING_SCHEMA_VERSION = "9.5"


# ---------------------------------------------------------------------------
# Planning mode
# ---------------------------------------------------------------------------

class PlanningMode(str, Enum):
    """
    Deterministic planning mode selected by Phase 9.5 based on road context.

    Each mode shapes which constraints are passed to Phase 9.2 candidate
    generation.  The mode does NOT control the vehicle directly.

    LANE_GUIDED     — reliable lane markings; use lane geometry as primary
                      constraint for candidate generation.
    DRIVABLE_SPACE  — unmarked / weakly-marked road; use drivable region,
                      road boundaries, and obstacle clearance as constraints.
    NARROW_ROAD     — road width restricts lateral candidate freedom; reduced
                      lateral offset range.
    MIXED_TRAFFIC   — dense, heterogeneous traffic including VRU / cattle;
                      enlarged clearance margins, reduced speed-assumption.
    INTERSECTION    — unsignalized or complex intersection zone; widened
                      planning envelope for crossing movements.
    HIGHWAY         — high-speed structured road; lane-guided with merge
                      awareness; no lateral freedom beyond usable lanes.
    DEGRADED        — critical upstream inputs unavailable; safe conservative
                      fallback constraints returned.
    UNKNOWN         — mode cannot be determined from available inputs.
    """
    LANE_GUIDED    = "LANE_GUIDED"
    DRIVABLE_SPACE = "DRIVABLE_SPACE"
    NARROW_ROAD    = "NARROW_ROAD"
    MIXED_TRAFFIC  = "MIXED_TRAFFIC"
    INTERSECTION   = "INTERSECTION"
    HIGHWAY        = "HIGHWAY"
    DEGRADED       = "DEGRADED"
    UNKNOWN        = "UNKNOWN"


class LaneUsageMode(str, Enum):
    """
    How the planner should treat lane information for candidate generation.

    STRICT      — lane markings are reliable; candidates follow lane geometry.
    ADVISORY    — lane markings exist but weak; use as soft guidance only.
    IGNORE      — no usable lane information; fall back to drivable region.
    UNKNOWN     — lane usage mode cannot be determined.
    """
    STRICT  = "STRICT"
    ADVISORY = "ADVISORY"
    IGNORE  = "IGNORE"
    UNKNOWN = "UNKNOWN"


class NarrowRoadState(str, Enum):
    """
    Whether the current road requires narrow-road planning constraints.

    NOT_NARROW      — road is wide enough for standard lateral freedom.
    APPROACHING     — road is narrowing; start reducing lateral options.
    NARROW          — road width restricts lateral candidates significantly.
    VERY_NARROW     — minimal lateral freedom; near single-track conditions.
    UNKNOWN         — road width data unavailable.
    """
    NOT_NARROW   = "NOT_NARROW"
    APPROACHING  = "APPROACHING"
    NARROW       = "NARROW"
    VERY_NARROW  = "VERY_NARROW"
    UNKNOWN      = "UNKNOWN"


# ---------------------------------------------------------------------------
# Road anomaly constraint
# ---------------------------------------------------------------------------

@dataclass
class RoadAnomalyConstraint:
    """
    Compact representation of a spatial road anomaly as a planning constraint.

    Consumed from Phase 6.3 road anomaly data; NOT generated here.
    Phase 9.5 converts road anomaly descriptions into spatial exclusion
    hints for Phase 9.2 candidate generation.
    """
    anomaly_type: str = NOT_AVAILABLE        # e.g. "POTHOLE", "DEBRIS", "CONSTRUCTION"
    lateral_offset_m: float = 0.0            # approximate centre of anomaly (+Y=left)
    longitudinal_offset_m: float = 0.0       # approximate distance ahead
    affected_width_m: float = 0.5            # approximate lateral span
    avoidance_margin_m: float = 0.3          # additional clearance needed
    confidence: float = 0.0
    passable: bool = False                   # True if anomaly is drivable at low speed

    def to_dict(self) -> dict:
        return {
            "anomaly_type": self.anomaly_type,
            "lateral_offset_m": round(self.lateral_offset_m, 3),
            "longitudinal_offset_m": round(self.longitudinal_offset_m, 3),
            "affected_width_m": round(self.affected_width_m, 3),
            "avoidance_margin_m": round(self.avoidance_margin_m, 3),
            "confidence": round(self.confidence, 3),
            "passable": self.passable,
        }


# ---------------------------------------------------------------------------
# Traffic context summary (for candidate generation)
# ---------------------------------------------------------------------------

@dataclass
class TrafficContextSummary:
    """
    Compact traffic context projected into planning constraints.

    Derived from Phase 6.4 IndianRoadContextState; NOT independently observed.
    """
    has_wrong_side_traffic: bool = False
    has_cattle: bool = False
    has_vulnerable_road_users: bool = False
    has_pedestrians: bool = False
    has_motorcycles: bool = False
    has_pushcarts: bool = False
    high_density: bool = False
    roadside_activity_level: str = NOT_AVAILABLE   # LOW / MEDIUM / HIGH / UNKNOWN
    market_like: bool = False
    confidence: float = 0.0

    def to_dict(self) -> dict:
        return {
            "has_wrong_side_traffic": self.has_wrong_side_traffic,
            "has_cattle": self.has_cattle,
            "has_vulnerable_road_users": self.has_vulnerable_road_users,
            "has_pedestrians": self.has_pedestrians,
            "has_motorcycles": self.has_motorcycles,
            "has_pushcarts": self.has_pushcarts,
            "high_density": self.high_density,
            "roadside_activity_level": self.roadside_activity_level,
            "market_like": self.market_like,
            "confidence": round(self.confidence, 3),
        }


# ---------------------------------------------------------------------------
# Primary Phase 9.5 output: IndianRoadPlanningConstraints
# ---------------------------------------------------------------------------

@dataclass
class IndianRoadPlanningConstraints:
    """
    Phase 9.5 primary output — Indian-road-specific planning constraints.

    This structure is consumed by Phase 9.2 (via IndianRoadPlanningAdapter)
    to adapt candidate path generation to the current Indian-road context.

    It does NOT select a final path, issue a vehicle control command,
    contain steering / throttle / brake / target_speed, or replace
    Phase 9.3 risk scoring.

    Field groups
    ------------
    Identity        — frame_id, timestamp, schema_version
    Planning mode   — planning_mode, lane_usage_mode, narrow_road_state
    Lateral freedom — max_lateral_offset_m, lateral_offset_step_m
    Clearance       — road_edge_margin_m, obstacle_clearance_margin_m,
                      vulnerable_user_margin_m, cattle_clearance_margin_m
    Drivable region — drivable_region_required, use_road_center_tendency
    Anomalies       — road_anomaly_constraints
    Traffic context — traffic_context
    Uncertainty     — confidence, uncertainty, degraded
    Source          — road_type, marking_state (informational only)
    """

    # --- Identity -----------------------------------------------------------
    frame_id: int = 0
    timestamp: float = field(default_factory=time.time)
    schema_version: str = INDIAN_ROAD_PLANNING_SCHEMA_VERSION

    # --- Planning mode ------------------------------------------------------
    planning_mode: PlanningMode = PlanningMode.UNKNOWN
    lane_usage_mode: LaneUsageMode = LaneUsageMode.UNKNOWN
    narrow_road_state: NarrowRoadState = NarrowRoadState.UNKNOWN

    # --- Lateral freedom (metres) -------------------------------------------
    max_lateral_offset_m: float = 1.5
    """Maximum lateral offset from reference centreline for candidate generation."""

    lateral_offset_step_m: float = 0.75
    """Step size between successive lateral offsets (candidate spacing)."""

    # --- Clearance margins (metres) -----------------------------------------
    road_edge_margin_m: float = 0.5
    """Minimum distance from detected road edge for candidates."""

    obstacle_clearance_margin_m: float = 0.5
    """General obstacle clearance margin for candidate validation."""

    vulnerable_user_margin_m: float = 1.0
    """Additional clearance margin when VRUs (pedestrians, cyclists) are present."""

    cattle_clearance_margin_m: float = 1.5
    """Additional clearance margin when cattle are present or predicted nearby."""

    wrong_side_margin_m: float = 0.8
    """Additional lateral margin when wrong-side traffic is detected."""

    # --- Drivable region ----------------------------------------------------
    drivable_region_required: bool = False
    """If True, candidates must stay within the confirmed drivable region."""

    use_road_center_tendency: bool = False
    """If True, bias candidates toward inferred road centre (unmarked roads)."""

    # --- Road anomaly constraints -------------------------------------------
    road_anomaly_constraints: Tuple[RoadAnomalyConstraint, ...] = field(
        default_factory=tuple
    )
    """Spatial constraints derived from Phase 6.3 road anomalies."""

    # --- Traffic context (informational for 9.2) ----------------------------
    traffic_context: TrafficContextSummary = field(
        default_factory=TrafficContextSummary
    )

    # --- Confidence / uncertainty -------------------------------------------
    confidence: float = 0.0
    uncertainty: float = 1.0
    degraded: bool = True

    # --- Source fields (informational only) ---------------------------------
    road_type: str = NOT_AVAILABLE
    """Road type string from Phase 6.4 (informational)."""

    marking_state: str = NOT_AVAILABLE
    """Road marking state from Phase 6.4 (informational)."""

    road_width_m: Optional[float] = None
    """Estimated road width from Phase 6.4 in metres, or None if unknown."""

    # -----------------------------------------------------------------------

    def to_dict(self) -> dict:
        return {
            "schema_version": self.schema_version,
            "frame_id": self.frame_id,
            "timestamp": round(self.timestamp, 6),
            "planning_mode": self.planning_mode.value,
            "lane_usage_mode": self.lane_usage_mode.value,
            "narrow_road_state": self.narrow_road_state.value,
            "max_lateral_offset_m": round(self.max_lateral_offset_m, 3),
            "lateral_offset_step_m": round(self.lateral_offset_step_m, 3),
            "road_edge_margin_m": round(self.road_edge_margin_m, 3),
            "obstacle_clearance_margin_m": round(self.obstacle_clearance_margin_m, 3),
            "vulnerable_user_margin_m": round(self.vulnerable_user_margin_m, 3),
            "cattle_clearance_margin_m": round(self.cattle_clearance_margin_m, 3),
            "wrong_side_margin_m": round(self.wrong_side_margin_m, 3),
            "drivable_region_required": self.drivable_region_required,
            "use_road_center_tendency": self.use_road_center_tendency,
            "road_anomaly_constraints": [a.to_dict() for a in self.road_anomaly_constraints],
            "traffic_context": self.traffic_context.to_dict(),
            "confidence": round(self.confidence, 3),
            "uncertainty": round(self.uncertainty, 3),
            "degraded": self.degraded,
            "road_type": self.road_type,
            "marking_state": self.marking_state,
            "road_width_m": (
                round(self.road_width_m, 3) if self.road_width_m is not None else None
            ),
        }


# ---------------------------------------------------------------------------
# Phase 9.5 result envelope (wraps constraints + metadata)
# ---------------------------------------------------------------------------

@dataclass
class IndianRoadPlanningResult:
    """
    Envelope returned by IndianRoadPlanningAdapter.build_constraints().

    Carries the constraints plus status and warnings.
    Does NOT contain a selected path, vehicle command, or risk score.
    """
    constraints: IndianRoadPlanningConstraints = field(
        default_factory=IndianRoadPlanningConstraints
    )
    status: str = "UNKNOWN"          # "OK" | "DEGRADED" | "FALLBACK" | "UNKNOWN"
    warnings: Tuple[str, ...] = field(default_factory=tuple)
    schema_version: str = INDIAN_ROAD_PLANNING_SCHEMA_VERSION

    def to_dict(self) -> dict:
        return {
            "schema_version": self.schema_version,
            "status": self.status,
            "warnings": list(self.warnings),
            "constraints": self.constraints.to_dict(),
        }
