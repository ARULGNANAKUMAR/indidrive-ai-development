"""
IndiDrive AI — Phase 9.4 | Active Path Monitor
===============================================
Monitors the currently active candidate path against the latest
Phase 9.3 risk scores and Phase 9.1/9.2 planning state.

Responsibilities:
  - Maintain a reference to the current active candidate ID.
  - Track the last-known risk state of that candidate.
  - Evaluate validity of the active path on each cycle.
  - Produce a compact PlanningStateSnapshot for change detection.
  - Extract per-object context from PathRiskSet for change tracking.

This module does NOT:
  - Select a new active path.
  - Generate candidate paths (Phase 9.2).
  - Score candidates (Phase 9.3).
  - Issue vehicle commands.
  - Perform emergency braking.
"""
from __future__ import annotations

import math
import time
from typing import Dict, Optional, Tuple

from .replanning_types import (
    NOT_AVAILABLE,
    ActivePath,
    ActivePathValidity,
    PlanningStateSnapshot,
    ReplanningReasonCode,
    REPLANNING_SCHEMA_VERSION,
)
from .replanning_config import ReplanningConfig
from .candidate_path_types import (
    CandidatePath,
    CandidatePathSet,
    GeometricValidity,
    BoundaryValidity,
    DrivableSpaceValidity,
)
from .path_risk_types import (
    CandidatePathRisk,
    PathRiskSet,
    RiskLevel,
)
from .planning_space_types import PlanningSpace, PlanningSpaceStatus

__all__ = ["ActivePathMonitor"]

_FINITE_SENTINEL = 1e9


def _finite(v) -> Optional[float]:
    """Return float(v) if finite, else None."""
    try:
        f = float(v)
        return f if math.isfinite(f) else None
    except (TypeError, ValueError):
        return None


class ActivePathMonitor:
    """
    Monitors the active candidate path and builds state snapshots.

    This is a stateful object — it retains knowledge of the previously
    set active candidate ID and the last snapshot produced.

    Thread-safety: This object should be owned by a single planning thread.
    Do not share instances across threads without external locking.
    """

    def __init__(self, config: Optional[ReplanningConfig] = None) -> None:
        self._config = config or ReplanningConfig()
        self._active_candidate_id: str = NOT_AVAILABLE
        self._active_path: Optional[ActivePath] = None
        self._last_snapshot: Optional[PlanningStateSnapshot] = None

    # -----------------------------------------------------------------------
    # Public API
    # -----------------------------------------------------------------------

    @property
    def active_candidate_id(self) -> str:
        return self._active_candidate_id

    @property
    def active_path(self) -> Optional[ActivePath]:
        return self._active_path

    @property
    def last_snapshot(self) -> Optional[PlanningStateSnapshot]:
        return self._last_snapshot

    def set_active_candidate(
        self,
        candidate_id: str,
        frame_id: int = 0,
        source_frame_id: int = 0,
    ) -> None:
        """Record which candidate is currently the active path.

        This does NOT choose the candidate — the caller supplies the ID.
        Phase 9.4 only monitors; path selection is a future phase.
        """
        if not isinstance(candidate_id, str) or not candidate_id:
            candidate_id = NOT_AVAILABLE

        now = time.time()
        self._active_candidate_id = candidate_id
        self._active_path = ActivePath(
            candidate_id=candidate_id,
            frame_id=frame_id,
            timestamp=now,
            activation_timestamp=now,
            last_evaluated_at=now,
            validity=ActivePathValidity.UNKNOWN,
            source_frame_id=source_frame_id,
        )
        # Reset snapshot so change detection starts fresh for new candidate
        self._last_snapshot = None

    def evaluate(
        self,
        frame_id: int,
        risk_set: Optional[PathRiskSet],
        candidate_set: Optional[CandidatePathSet],
        planning_space: Optional[PlanningSpace],
        timestamp: Optional[float] = None,
    ) -> Tuple[ActivePath, PlanningStateSnapshot]:
        """
        Evaluate the current active path against updated state.

        Returns
        -------
        active_path     : updated ActivePath with current validity and risk.
        snapshot        : compact PlanningStateSnapshot for change detection.
        """
        now = timestamp if timestamp is not None else time.time()

        # If no active path has been set, return sentinel state
        if self._active_path is None or self._active_candidate_id == NOT_AVAILABLE:
            ap = ActivePath(
                candidate_id=NOT_AVAILABLE,
                frame_id=frame_id,
                timestamp=now,
                activation_timestamp=now,
                last_evaluated_at=now,
                validity=ActivePathValidity.NOT_SET,
            )
            snap = self._build_snapshot(frame_id, now, NOT_AVAILABLE, 0.0,
                                        NOT_AVAILABLE, None, risk_set,
                                        planning_space, False)
            self._active_path = ap
            self._last_snapshot = snap
            return ap, snap

        cid = self._active_candidate_id

        # --- Find risk for active candidate ---
        active_risk: Optional[CandidatePathRisk] = None
        if risk_set is not None and risk_set.has_risks:
            for r in risk_set.risks:
                if r.candidate_id == cid:
                    active_risk = r
                    break

        # --- Find candidate path ---
        active_candidate: Optional[CandidatePath] = None
        if candidate_set is not None and candidate_set.has_candidates:
            for c in candidate_set.candidates:
                if c.candidate_id == cid:
                    active_candidate = c
                    break

        # --- Evaluate validity ---
        validity = self._evaluate_path_validity(
            active_candidate, active_risk, planning_space, now
        )

        # --- Extract risk values ---
        risk_score = 0.0
        risk_level_str = NOT_AVAILABLE
        ttc_s: Optional[float] = None
        critical_ids: Tuple[str, ...] = ()

        if active_risk is not None:
            r_score = _finite(active_risk.total_risk)
            risk_score = r_score if r_score is not None else 0.0
            risk_level_str = active_risk.risk_level.value
            # Extract minimum TTC from object contributions
            ttcs = []
            crit = []
            for oc in active_risk.object_contributions:
                if oc.ttc_s is not None:
                    t = _finite(oc.ttc_s)
                    if t is not None and t >= 0.0:
                        ttcs.append(t)
                if oc.is_critical:
                    crit.append(oc.object_id)
            ttc_s = min(ttcs) if ttcs else None
            critical_ids = tuple(sorted(crit))

        # --- Update active path ---
        ap = ActivePath(
            candidate_id=cid,
            frame_id=frame_id,
            timestamp=now,
            activation_timestamp=self._active_path.activation_timestamp,
            last_evaluated_at=now,
            validity=validity,
            risk_score=risk_score,
            risk_level=risk_level_str,
            ttc_s=ttc_s,
            critical_object_ids=critical_ids,
            source_frame_id=self._active_path.source_frame_id,
        )

        # --- Safety gate ---
        # PlanningSpace carries safety_gate_state and planning_allowed directly
        sg_state = NOT_AVAILABLE
        planning_allowed = False
        if planning_space is not None:
            sg_state = getattr(planning_space, "safety_gate_state", NOT_AVAILABLE) or NOT_AVAILABLE
            planning_allowed = bool(getattr(planning_space, "planning_allowed", False))

        # --- Build snapshot ---
        snap = self._build_snapshot(
            frame_id, now, cid, risk_score, risk_level_str,
            ttc_s, risk_set, planning_space,
            active_risk.degraded if active_risk else True,
        )
        snap.safety_gate_state = sg_state
        snap.planning_allowed = planning_allowed

        self._active_path = ap
        self._last_snapshot = snap
        return ap, snap

    # -----------------------------------------------------------------------
    # Internal helpers
    # -----------------------------------------------------------------------

    def _evaluate_path_validity(
        self,
        candidate: Optional[CandidatePath],
        risk: Optional[CandidatePathRisk],
        space: Optional[PlanningSpace],
        now: float,
    ) -> ActivePathValidity:
        """Determine validity of the active path from available data."""

        # No data at all
        if candidate is None and risk is None:
            # Check age of existing active path
            if self._active_path is not None:
                age = now - self._active_path.last_evaluated_at
                if age > self._config.max_active_path_age_s:
                    return ActivePathValidity.STALE
            return ActivePathValidity.UNKNOWN

        # Candidate geometric invalidity
        if candidate is not None:
            geom_bad = candidate.geometric_validity == GeometricValidity.INVALID
            bound_bad = candidate.boundary_validity == BoundaryValidity.INVALID
            driv_bad = (
                candidate.drivable_space_validity == DrivableSpaceValidity.INVALID
            )
            if geom_bad or bound_bad or driv_bad:
                return ActivePathValidity.INVALID

        # Risk says geometrically invalid
        if risk is not None and risk.is_geometrically_invalid:
            return ActivePathValidity.INVALID

        # Planning space says planning restricted
        if space is not None:
            if space.status in (PlanningSpaceStatus.RESTRICTED, PlanningSpaceStatus.INVALID):
                return ActivePathValidity.INVALID

        # Degraded inputs
        degraded = (risk is not None and risk.degraded) or (
            candidate is not None and candidate.metadata.is_degraded
        )
        if degraded:
            return ActivePathValidity.DEGRADED

        return ActivePathValidity.VALID

    def _build_snapshot(
        self,
        frame_id: int,
        now: float,
        candidate_id: str,
        risk_score: float,
        risk_level: str,
        ttc_s: Optional[float],
        risk_set: Optional[PathRiskSet],
        space: Optional[PlanningSpace],
        degraded: bool,
    ) -> PlanningStateSnapshot:
        """Build a compact PlanningStateSnapshot for change detection."""

        # --- Extract object positions/velocities from planning space ---
        object_ids: list = []
        object_positions: list = []
        object_velocities: list = []

        if space is not None and space.dynamic_objects:
            objs = list(space.dynamic_objects)[: self._config.max_tracked_objects]
            for obj in objs:
                oid = getattr(obj, "object_id", None) or NOT_AVAILABLE
                if oid == NOT_AVAILABLE:
                    continue
                object_ids.append(oid)
                # DynamicObjectEntry uses position_x / position_y / velocity_x / velocity_y
                x = _finite(getattr(obj, "position_x", None) or getattr(obj, "x_m", 0.0)) or 0.0
                y = _finite(getattr(obj, "position_y", None) or getattr(obj, "y_m", 0.0)) or 0.0
                vx = _finite(getattr(obj, "velocity_x", None) or 0.0) or 0.0
                vy = _finite(getattr(obj, "velocity_y", None) or 0.0) or 0.0
                import math as _math
                speed = _math.sqrt(vx * vx + vy * vy)
                object_positions.append((oid, x, y))
                object_velocities.append((oid, speed))

        # --- Road state ---
        drivable_width = 0.0
        has_anomaly = False
        if space is not None:
            extent = space.spatial_extent
            if extent is not None:
                # SpatialExtent uses road_width_m
                w = _finite(
                    getattr(extent, "road_width_m", None)
                    or getattr(extent, "drivable_width_m", 0.0)
                )
                drivable_width = w if w is not None else 0.0
            has_anomaly = bool(
                space.static_hazards and len(space.static_hazards) > 0
            )

        # --- Uncertainty ---
        uncertainty = 0.0
        if risk_set is not None and risk_set.has_risks:
            # Use maximum uncertainty across all risks as planning uncertainty
            unc_vals = [r.uncertainty for r in risk_set.risks if _finite(r.uncertainty) is not None]
            if unc_vals:
                uncertainty = max(unc_vals)

        snap = PlanningStateSnapshot(
            frame_id=frame_id,
            timestamp=now,
            active_candidate_id=candidate_id,
            risk_score=risk_score,
            risk_level=risk_level,
            ttc_s=ttc_s,
            object_ids=tuple(sorted(object_ids)),
            object_positions=tuple(object_positions),
            object_velocities=tuple(object_velocities),
            drivable_width_m=drivable_width,
            has_road_anomaly=has_anomaly,
            uncertainty=uncertainty,
        )
        return snap
