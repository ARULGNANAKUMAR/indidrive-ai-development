"""
IndiDrive AI — Phase 9.4 | Replanning Validator
================================================
Validates ReplanningRequest and ReplanningContext structures.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import List, Tuple

from .replanning_types import (
    NOT_AVAILABLE,
    ReplanningRequest,
    ReplanningContext,
    ReplanningDecision,
    ReplanningUrgency,
    ReplanningReasonCode,
    ActivePath,
    ActivePathValidity,
    REPLANNING_SCHEMA_VERSION,
)

__all__ = [
    "ReplanningValidator",
    "ReplanningValidationResult",
]

_FORBIDDEN_FIELDS = {
    "steering_command",
    "throttle_command",
    "brake_command",
    "vehicle_control",
    "target_speed",
    "mpc",
    "controller_command",
    "selected_path",
    "best_path",
    "optimal_path",
    "chosen_path",
    "path_generation",
    "trajectory_generation",
}


def _finite(v) -> bool:
    try:
        return math.isfinite(float(v))
    except (TypeError, ValueError):
        return False


@dataclass
class ReplanningValidationResult:
    """Result of validating a ReplanningRequest."""
    is_valid: bool = True
    errors: Tuple[str, ...] = field(default_factory=tuple)
    warnings: Tuple[str, ...] = field(default_factory=tuple)

    def to_dict(self) -> dict:
        return {
            "is_valid": self.is_valid,
            "error_count": len(self.errors),
            "errors": list(self.errors),
            "warning_count": len(self.warnings),
            "warnings": list(self.warnings),
        }


class ReplanningValidator:
    """Validates Phase 9.4 output structures."""

    def validate_request(
        self, request: ReplanningRequest
    ) -> ReplanningValidationResult:
        errors: List[str] = []
        warnings: List[str] = []

        if request is None:
            return ReplanningValidationResult(
                is_valid=False,
                errors=("request is None",),
            )

        # Schema
        if request.schema_version != REPLANNING_SCHEMA_VERSION:
            warnings.append(
                f"schema_version mismatch: {request.schema_version!r} "
                f"!= {REPLANNING_SCHEMA_VERSION!r}"
            )

        # Frame ID
        if not isinstance(request.frame_id, int) or request.frame_id < 0:
            errors.append(f"invalid frame_id: {request.frame_id!r}")

        # Timestamp
        if not _finite(request.timestamp):
            errors.append("timestamp is not finite")

        # Decision
        if not isinstance(request.decision, ReplanningDecision):
            errors.append(f"invalid decision: {request.decision!r}")

        # Urgency
        if not isinstance(request.urgency, ReplanningUrgency):
            errors.append(f"invalid urgency: {request.urgency!r}")

        # Dominant reason
        if not isinstance(request.dominant_reason, ReplanningReasonCode):
            errors.append(f"invalid dominant_reason: {request.dominant_reason!r}")

        # Risk values
        if not _finite(request.current_risk) or not (0.0 <= request.current_risk <= 1.0):
            errors.append(f"current_risk out of range: {request.current_risk!r}")
        if not _finite(request.previous_risk) or not (0.0 <= request.previous_risk <= 1.0):
            errors.append(f"previous_risk out of range: {request.previous_risk!r}")
        if not _finite(request.risk_delta) or request.risk_delta < 0:
            errors.append(f"risk_delta invalid: {request.risk_delta!r}")

        # Reason codes
        for rc in request.reason_codes:
            if not isinstance(rc, ReplanningReasonCode):
                errors.append(f"invalid reason_code: {rc!r}")

        # Uncertainty
        if not _finite(request.uncertainty) or not (0.0 <= request.uncertainty <= 1.0):
            warnings.append(f"uncertainty out of range: {request.uncertainty!r}")

        # Forbidden fields — check request dict
        req_dict = request.to_dict()
        for f in _FORBIDDEN_FIELDS:
            if f in req_dict:
                errors.append(f"FORBIDDEN field present in request: {f!r}")

        return ReplanningValidationResult(
            is_valid=len(errors) == 0,
            errors=tuple(errors),
            warnings=tuple(warnings),
        )

    def validate_context(
        self, context: ReplanningContext
    ) -> ReplanningValidationResult:
        errors: List[str] = []
        warnings: List[str] = []

        if context is None:
            return ReplanningValidationResult(
                is_valid=False,
                errors=("context is None",),
            )

        if context.schema_version != REPLANNING_SCHEMA_VERSION:
            warnings.append(f"schema_version mismatch: {context.schema_version!r}")

        if not isinstance(context.frame_id, int) or context.frame_id < 0:
            errors.append(f"invalid frame_id: {context.frame_id!r}")

        if not _finite(context.timestamp):
            errors.append("timestamp is not finite")

        if not _finite(context.current_risk) or not (0.0 <= context.current_risk <= 1.0):
            errors.append(f"current_risk out of range: {context.current_risk!r}")

        # Forbidden fields
        ctx_dict = context.to_dict()
        for f in _FORBIDDEN_FIELDS:
            if f in ctx_dict:
                errors.append(f"FORBIDDEN field present in context: {f!r}")

        return ReplanningValidationResult(
            is_valid=len(errors) == 0,
            errors=tuple(errors),
            warnings=tuple(warnings),
        )

    def validate_active_path(
        self, active_path: ActivePath
    ) -> ReplanningValidationResult:
        errors: List[str] = []
        warnings: List[str] = []

        if active_path is None:
            return ReplanningValidationResult(
                is_valid=False,
                errors=("active_path is None",),
            )

        if not isinstance(active_path.validity, ActivePathValidity):
            errors.append(f"invalid validity: {active_path.validity!r}")

        if not _finite(active_path.risk_score) or not (0.0 <= active_path.risk_score <= 1.0):
            errors.append(f"risk_score out of range: {active_path.risk_score!r}")

        # Forbidden fields
        ap_dict = active_path.to_dict()
        for f in _FORBIDDEN_FIELDS:
            if f in ap_dict:
                errors.append(f"FORBIDDEN field present in active_path: {f!r}")

        return ReplanningValidationResult(
            is_valid=len(errors) == 0,
            errors=tuple(errors),
            warnings=tuple(warnings),
        )
