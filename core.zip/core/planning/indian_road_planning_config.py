"""
IndiDrive AI — Phase 9.5 | Indian-Road Path Planning — Configuration
=====================================================================
All configurable thresholds for Phase 9.5.  No safety-critical magic numbers
are embedded in the adapter — every tunable value lives here.

Follows the same convention as Phase 9.2 CandidateGeneratorConfig and
Phase 9.4 ReplanningConfig.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

import yaml

__all__ = [
    "IndianRoadPlanningConfig",
    "load_indian_road_planning_config",
]

CONFIG_VERSION = "9.5"
_YAML_SECTION = "phase_9_5"


@dataclass
class IndianRoadPlanningConfig:
    """
    Configuration for Phase 9.5 Indian-Road Path Planning Adapter.

    All defaults are tuned conservatively for unstructured Indian-road conditions.
    """

    enabled: bool = True

    # -----------------------------------------------------------------------
    # Mode selection thresholds
    # -----------------------------------------------------------------------

    lane_confidence_threshold: float = 0.60
    """Minimum lane confidence (from Phase 6.4) to use LANE_GUIDED mode."""

    unmarked_road_threshold: float = 0.30
    """If lane confidence falls below this, switch to DRIVABLE_SPACE mode."""

    mixed_traffic_density_threshold: str = "HIGH"
    """TrafficDensity string that triggers MIXED_TRAFFIC mode override.
    Options: VERY_LOW / LOW / MEDIUM / HIGH / VERY_HIGH."""

    # -----------------------------------------------------------------------
    # Mode hysteresis
    # -----------------------------------------------------------------------

    mode_persistence_frames: int = 3
    """Minimum frames a mode must persist before allowing a switch.
    Prevents rapid LANE_GUIDED ↔ DRIVABLE_SPACE oscillation."""

    lane_confidence_hysteresis_activate: float = 0.65
    """Confidence must RISE above this to re-activate LANE_GUIDED from DRIVABLE_SPACE."""

    lane_confidence_hysteresis_deactivate: float = 0.40
    """Confidence must FALL below this to deactivate LANE_GUIDED and enter DRIVABLE_SPACE."""

    # -----------------------------------------------------------------------
    # Narrow-road thresholds
    # -----------------------------------------------------------------------

    very_narrow_road_width_m: float = 3.5
    """Roads narrower than this → VERY_NARROW state (near single-track)."""

    narrow_road_width_m: float = 5.0
    """Roads narrower than this → NARROW state."""

    approaching_narrow_width_m: float = 6.5
    """Roads narrower than this → APPROACHING state."""

    # -----------------------------------------------------------------------
    # Lateral freedom
    # -----------------------------------------------------------------------

    default_max_lateral_offset_m: float = 1.5
    """Standard lateral offset range for marked urban roads."""

    narrow_road_max_lateral_offset_m: float = 0.4
    """Lateral range on narrow roads — reduce candidates to what fits."""

    very_narrow_max_lateral_offset_m: float = 0.0
    """Lateral range on very narrow roads — center-only candidate."""

    highway_max_lateral_offset_m: float = 1.5
    """Lateral range on highways — within usable lane width."""

    drivable_space_max_lateral_offset_m: float = 1.0
    """Lateral range when using drivable-space planning (unmarked roads)."""

    mixed_traffic_max_lateral_offset_m: float = 0.75
    """Lateral range in dense mixed traffic — conservative."""

    default_lateral_step_m: float = 0.75
    """Default lateral step between candidates."""

    narrow_road_lateral_step_m: float = 0.2
    """Lateral step on narrow roads."""

    # -----------------------------------------------------------------------
    # Clearance margins (metres)
    # -----------------------------------------------------------------------

    road_edge_margin_default_m: float = 0.5
    """Default minimum distance from road edge."""

    road_edge_margin_narrow_m: float = 0.3
    """Road edge margin on narrow roads — reduced to fit."""

    road_edge_margin_village_m: float = 0.4
    """Road edge margin on village roads with soft/irregular edges."""

    obstacle_clearance_default_m: float = 0.5
    """Default general obstacle clearance for candidates."""

    obstacle_clearance_market_m: float = 0.8
    """Increased clearance on market roads (higher VRU density)."""

    vulnerable_user_margin_m: float = 1.0
    """Extra clearance when pedestrians / cyclists are confirmed present."""

    cattle_clearance_margin_m: float = 1.5
    """Extra clearance for cattle — unpredictable motion."""

    wrong_side_margin_m: float = 0.8
    """Extra lateral margin when wrong-side traffic is detected."""

    pushcart_margin_m: float = 0.6
    """Extra clearance for pushcarts."""

    # -----------------------------------------------------------------------
    # Road anomaly handling
    # -----------------------------------------------------------------------

    anomaly_avoidance_margin_m: float = 0.3
    """Minimum clearance added around each road anomaly (pothole / debris)."""

    # -----------------------------------------------------------------------
    # Input freshness
    # -----------------------------------------------------------------------

    max_context_age_s: float = 2.0
    """Maximum age of Indian-road context state before treating as stale/degraded."""

    def to_dict(self) -> dict:
        return {
            "config_version": CONFIG_VERSION,
            "enabled": self.enabled,
            "lane_confidence_threshold": self.lane_confidence_threshold,
            "unmarked_road_threshold": self.unmarked_road_threshold,
            "mixed_traffic_density_threshold": self.mixed_traffic_density_threshold,
            "mode_persistence_frames": self.mode_persistence_frames,
            "lane_confidence_hysteresis_activate": self.lane_confidence_hysteresis_activate,
            "lane_confidence_hysteresis_deactivate": self.lane_confidence_hysteresis_deactivate,
            "very_narrow_road_width_m": self.very_narrow_road_width_m,
            "narrow_road_width_m": self.narrow_road_width_m,
            "approaching_narrow_width_m": self.approaching_narrow_width_m,
            "default_max_lateral_offset_m": self.default_max_lateral_offset_m,
            "narrow_road_max_lateral_offset_m": self.narrow_road_max_lateral_offset_m,
            "very_narrow_max_lateral_offset_m": self.very_narrow_max_lateral_offset_m,
            "highway_max_lateral_offset_m": self.highway_max_lateral_offset_m,
            "drivable_space_max_lateral_offset_m": self.drivable_space_max_lateral_offset_m,
            "mixed_traffic_max_lateral_offset_m": self.mixed_traffic_max_lateral_offset_m,
            "default_lateral_step_m": self.default_lateral_step_m,
            "narrow_road_lateral_step_m": self.narrow_road_lateral_step_m,
            "road_edge_margin_default_m": self.road_edge_margin_default_m,
            "road_edge_margin_narrow_m": self.road_edge_margin_narrow_m,
            "road_edge_margin_village_m": self.road_edge_margin_village_m,
            "obstacle_clearance_default_m": self.obstacle_clearance_default_m,
            "obstacle_clearance_market_m": self.obstacle_clearance_market_m,
            "vulnerable_user_margin_m": self.vulnerable_user_margin_m,
            "cattle_clearance_margin_m": self.cattle_clearance_margin_m,
            "wrong_side_margin_m": self.wrong_side_margin_m,
            "pushcart_margin_m": self.pushcart_margin_m,
            "anomaly_avoidance_margin_m": self.anomaly_avoidance_margin_m,
            "max_context_age_s": self.max_context_age_s,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "IndianRoadPlanningConfig":
        known = set(cls.__dataclass_fields__)  # type: ignore[attr-defined]
        filtered = {k: v for k, v in data.items() if k in known}
        return cls(**filtered)


def load_indian_road_planning_config(
    config_path: Optional[Path] = None,
) -> IndianRoadPlanningConfig:
    """Load IndianRoadPlanningConfig from planner_config.yaml.

    Falls back to safe defaults if the file is absent or the
    ``phase_9_5`` section is missing.
    """
    if config_path is None:
        config_path = (
            Path(__file__).resolve().parent.parent.parent
            / "config"
            / "planner_config.yaml"
        )

    if not config_path.exists():
        return IndianRoadPlanningConfig()

    try:
        with open(config_path, "r", encoding="utf-8") as fh:
            raw = yaml.safe_load(fh) or {}
        section = raw.get(_YAML_SECTION, {})
        if not section:
            return IndianRoadPlanningConfig()
        return IndianRoadPlanningConfig.from_dict(section)
    except Exception:
        return IndianRoadPlanningConfig()
