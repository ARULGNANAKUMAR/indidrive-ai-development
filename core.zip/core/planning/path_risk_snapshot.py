"""
IndiDrive AI — Phase 9.3 | Path Risk Snapshot
==============================================
Immutable snapshot wrapper for a PathRiskSet.

Follows the same snapshot pattern as Phase 9.1 PlanningSnapshot
and Phase 9.2 CandidateSnapshot.
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field

from .path_risk_types import (
    NOT_AVAILABLE,
    PathRiskSet,
    PathRiskStatus,
)

__all__ = ["PathRiskSnapshot"]


@dataclass
class PathRiskSnapshot:
    """
    Immutable snapshot of the Phase 9.3 path risk set for one cycle.

    Consumers read this; they MUST NOT mutate it.

    Fields
    ------
    risk_set            : the PathRiskSet for this cycle.
    snapshot_id         : unique ID for this snapshot.
    timestamp           : wall-clock time when snapshot was assembled.
    evaluation_duration_s: wall-clock evaluation time (informational).

    FORBIDDEN:
        selected_path, best_path, optimal_path — never present here.
    """
    risk_set: PathRiskSet
    snapshot_id: str = NOT_AVAILABLE
    timestamp: float = field(default_factory=time.time)
    evaluation_duration_s: float = 0.0

    @property
    def is_evaluated(self) -> bool:
        return self.risk_set.status in (
            PathRiskStatus.EVALUATED, PathRiskStatus.DEGRADED
        )

    @property
    def has_risks(self) -> bool:
        return self.risk_set.has_risks

    @property
    def risk_count(self) -> int:
        return self.risk_set.risk_count

    @property
    def status(self) -> PathRiskStatus:
        return self.risk_set.status

    def to_dict(self) -> dict:
        return {
            "snapshot_id": self.snapshot_id,
            "timestamp": self.timestamp,
            "evaluation_duration_s": round(self.evaluation_duration_s, 6),
            "is_evaluated": self.is_evaluated,
            "has_risks": self.has_risks,
            "risk_count": self.risk_count,
            "risk_set": self.risk_set.to_dict(),
        }
