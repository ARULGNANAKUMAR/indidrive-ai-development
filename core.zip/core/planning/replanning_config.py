"""
IndiDrive AI — Phase 9.4 | Adaptive Replanning Configuration
=============================================================
All configurable thresholds and parameters for Phase 9.4.

No safety-critical threshold is hard-coded in the engine.
Every parameter lives here and can be overridden from the
planner_config.yaml 'phase_9_4' section via load_replanning_config().

Defaults are tuned for Indian road conditions (mixed traffic, VRUs,
narrow roads, unstructured intersections).
"""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Optional

import yaml

__all__ = [
    "ReplanningConfig",
    "load_replanning_config",
]

CONFIG_VERSION = "9.4"
_YAML_SECTION = "phase_9_4"

# Path to default config file (same directory as other configs)
_DEFAULT_CONFIG_PATH = Path(__file__).parent.parent.parent / "config" / "planner_config.yaml"


@dataclass
class ReplanningConfig:
    """
    Configuration for Phase 9.4 Adaptive Replanning Engine.

    All defaults are chosen conservatively for Indian road conditions.
    """

    # -----------------------------------------------------------------------
    # Enable / disable
    # -----------------------------------------------------------------------
    enabled: bool = True

    # -----------------------------------------------------------------------
    # Risk change thresholds
    # -----------------------------------------------------------------------
    # Risk delta that triggers RISK_ESCALATION
    risk_escalation_delta_threshold: float = 0.20
    # Risk score that classifies the path as critical
    critical_risk_threshold: float = 0.80
    # Risk delta below which changes are considered noise (hysteresis)
    risk_noise_floor: float = 0.02
    # Risk delta for de-escalation to NOT trigger (prevents oscillation)
    risk_deescalation_replan: bool = False

    # -----------------------------------------------------------------------
    # TTC thresholds
    # -----------------------------------------------------------------------
    # TTC (seconds) below which TTC_DEGRADATION triggers
    ttc_critical_threshold_s: float = 2.0
    # Minimum TTC delta (seconds) to treat as a meaningful change
    ttc_delta_threshold_s: float = 1.0

    # -----------------------------------------------------------------------
    # Path validity
    # -----------------------------------------------------------------------
    # Clearance below which the path is considered geometrically invalid
    min_acceptable_clearance_m: float = 0.3

    # -----------------------------------------------------------------------
    # Object change thresholds
    # -----------------------------------------------------------------------
    # Position delta (metres) to consider an object "significantly moved"
    object_position_delta_threshold_m: float = 1.5
    # Velocity delta (m/s) to consider an object "significantly changed speed"
    object_velocity_delta_threshold: float = 2.0
    # Minimum predicted trajectory deviation (metres) for PREDICTION_CHANGE
    trajectory_deviation_threshold_m: float = 1.0
    # Maximum number of objects to track for change detection
    max_tracked_objects: int = 30
    # How close (metres) an object must be to the active path to be "relevant"
    object_path_relevance_radius_m: float = 4.0

    # -----------------------------------------------------------------------
    # Road structure thresholds
    # -----------------------------------------------------------------------
    # Minimum drivable width change (metres) for DRIVABLE_REGION_CHANGE
    drivable_width_delta_threshold_m: float = 0.5

    # -----------------------------------------------------------------------
    # Cooldown / debounce
    # -----------------------------------------------------------------------
    # Minimum seconds between non-critical replanning requests
    cooldown_interval_s: float = 0.5
    # Critical conditions bypass cooldown entirely
    critical_bypasses_cooldown: bool = True

    # -----------------------------------------------------------------------
    # Hysteresis
    # -----------------------------------------------------------------------
    # Risk must drop below this for the HIGH_RISK state to clear
    risk_hysteresis_clear_threshold: float = 0.65
    # Risk must exceed this to enter HIGH_RISK triggering state
    risk_hysteresis_trigger_threshold: float = 0.75

    # -----------------------------------------------------------------------
    # Input freshness
    # -----------------------------------------------------------------------
    # Maximum age (seconds) before a planning state is marked stale
    max_input_age_s: float = 2.0
    # Maximum age (seconds) before an active path is marked stale
    max_active_path_age_s: float = 3.0

    # -----------------------------------------------------------------------
    # Uncertainty
    # -----------------------------------------------------------------------
    # Uncertainty above which UNCERTAINTY_ESCALATION triggers
    uncertainty_escalation_threshold: float = 0.75

    # -----------------------------------------------------------------------
    # Safety gate
    # -----------------------------------------------------------------------
    # States that require replanning evaluation on transition
    safety_gate_replan_states: List[str] = field(
        default_factory=lambda: ["CAUTION", "HIGH_ALERT", "CRITICAL", "DEGRADED"]
    )

    # -----------------------------------------------------------------------
    # HAZARD_CLEARED policy
    # -----------------------------------------------------------------------
    # Whether HAZARD_CLEARED triggers a replanning request
    replan_on_hazard_cleared: bool = False

    # -----------------------------------------------------------------------
    # Schema / versioning
    # -----------------------------------------------------------------------
    config_version: str = CONFIG_VERSION


def load_replanning_config(
    path: Optional[Path] = None,
    section: str = _YAML_SECTION,
) -> ReplanningConfig:
    """Load ReplanningConfig from a YAML file.

    Falls back to defaults if the file or section is missing.

    Parameters
    ----------
    path    : path to the YAML config file (default: planner_config.yaml).
    section : YAML key holding phase_9_4 config (default: 'phase_9_4').
    """
    cfg_path = path or _DEFAULT_CONFIG_PATH

    try:
        with open(cfg_path, "r", encoding="utf-8") as fh:
            raw = yaml.safe_load(fh)
    except (FileNotFoundError, OSError, yaml.YAMLError):
        return ReplanningConfig()

    if not isinstance(raw, dict):
        return ReplanningConfig()

    section_data = raw.get(section, {})
    if not isinstance(section_data, dict):
        return ReplanningConfig()

    cfg = ReplanningConfig()

    def _get(key: str, default):
        return section_data.get(key, default)

    cfg.enabled = bool(_get("enabled", cfg.enabled))
    cfg.risk_escalation_delta_threshold = float(
        _get("risk_escalation_delta_threshold", cfg.risk_escalation_delta_threshold)
    )
    cfg.critical_risk_threshold = float(
        _get("critical_risk_threshold", cfg.critical_risk_threshold)
    )
    cfg.risk_noise_floor = float(
        _get("risk_noise_floor", cfg.risk_noise_floor)
    )
    cfg.risk_deescalation_replan = bool(
        _get("risk_deescalation_replan", cfg.risk_deescalation_replan)
    )
    cfg.ttc_critical_threshold_s = float(
        _get("ttc_critical_threshold_s", cfg.ttc_critical_threshold_s)
    )
    cfg.ttc_delta_threshold_s = float(
        _get("ttc_delta_threshold_s", cfg.ttc_delta_threshold_s)
    )
    cfg.min_acceptable_clearance_m = float(
        _get("min_acceptable_clearance_m", cfg.min_acceptable_clearance_m)
    )
    cfg.object_position_delta_threshold_m = float(
        _get("object_position_delta_threshold_m", cfg.object_position_delta_threshold_m)
    )
    cfg.object_velocity_delta_threshold = float(
        _get("object_velocity_delta_threshold", cfg.object_velocity_delta_threshold)
    )
    cfg.trajectory_deviation_threshold_m = float(
        _get("trajectory_deviation_threshold_m", cfg.trajectory_deviation_threshold_m)
    )
    cfg.max_tracked_objects = int(
        _get("max_tracked_objects", cfg.max_tracked_objects)
    )
    cfg.object_path_relevance_radius_m = float(
        _get("object_path_relevance_radius_m", cfg.object_path_relevance_radius_m)
    )
    cfg.drivable_width_delta_threshold_m = float(
        _get("drivable_width_delta_threshold_m", cfg.drivable_width_delta_threshold_m)
    )
    cfg.cooldown_interval_s = float(
        _get("cooldown_interval_s", cfg.cooldown_interval_s)
    )
    cfg.critical_bypasses_cooldown = bool(
        _get("critical_bypasses_cooldown", cfg.critical_bypasses_cooldown)
    )
    cfg.risk_hysteresis_clear_threshold = float(
        _get("risk_hysteresis_clear_threshold", cfg.risk_hysteresis_clear_threshold)
    )
    cfg.risk_hysteresis_trigger_threshold = float(
        _get("risk_hysteresis_trigger_threshold", cfg.risk_hysteresis_trigger_threshold)
    )
    cfg.max_input_age_s = float(
        _get("max_input_age_s", cfg.max_input_age_s)
    )
    cfg.max_active_path_age_s = float(
        _get("max_active_path_age_s", cfg.max_active_path_age_s)
    )
    cfg.uncertainty_escalation_threshold = float(
        _get("uncertainty_escalation_threshold", cfg.uncertainty_escalation_threshold)
    )
    gate_states = _get("safety_gate_replan_states", None)
    if isinstance(gate_states, list):
        cfg.safety_gate_replan_states = [str(s) for s in gate_states]
    cfg.replan_on_hazard_cleared = bool(
        _get("replan_on_hazard_cleared", cfg.replan_on_hazard_cleared)
    )

    return cfg
