"""
IndiDrive AI — Phase 9.3 | Path Risk Validator
===============================================
Validation for CandidatePathRisk and PathRiskSet outputs.

Validates:
  - candidate_id presence and type
  - frame_id type
  - coordinate_frame
  - total_risk range [0, 1]
  - uncertainty/confidence ranges
  - reason codes structure
  - schema version
  - no forbidden fields (selected_path, best_path, etc.)

Never silently produces nonsense risk values.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import List

from .path_risk_types import (
    NOT_AVAILABLE,
    PATH_RISK_SCHEMA_VERSION,
    CandidatePathRisk,
    PathRiskSet,
    RiskReasonCode,
)

__all__ = [
    "PathRiskValidationResult",
    "PathRiskSetValidationResult",
    "PathRiskValidator",
]


@dataclass
class PathRiskValidationResult:
    """Result of validating one CandidatePathRisk."""
    is_valid: bool = False
    errors: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    candidate_id: str = NOT_AVAILABLE

    def to_dict(self) -> dict:
        return {
            "candidate_id": self.candidate_id,
            "is_valid": self.is_valid,
            "error_count": len(self.errors),
            "errors": list(self.errors),
            "warning_count": len(self.warnings),
            "warnings": list(self.warnings),
        }


@dataclass
class PathRiskSetValidationResult:
    """Result of validating a PathRiskSet."""
    is_valid: bool = False
    errors: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    per_risk_results: List[PathRiskValidationResult] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "is_valid": self.is_valid,
            "error_count": len(self.errors),
            "errors": list(self.errors),
            "warning_count": len(self.warnings),
            "warnings": list(self.warnings),
            "risk_count": len(self.per_risk_results),
            "per_risk_results": [r.to_dict() for r in self.per_risk_results],
        }


def _finite(v) -> bool:
    try:
        return math.isfinite(float(v))
    except (TypeError, ValueError):
        return False


def _in_range(v, lo: float, hi: float) -> bool:
    if not _finite(v):
        return False
    return lo <= float(v) <= hi


class PathRiskValidator:
    """Validates Phase 9.3 output structures."""

    # Fields that MUST NOT appear in CandidatePathRisk
    FORBIDDEN_FIELDS = [
        "best_path", "selected_path", "optimal_path", "chosen_path",
        "steering_angle", "throttle", "brake", "target_speed",
        "acceleration_cmd", "replan", "replan_trigger", "lane_change",
        "mpc_output", "carla_command", "vehicle_command",
        "waypoint_generation", "trajectory_optimization",
    ]

    def validate_risk(self, risk: CandidatePathRisk) -> PathRiskValidationResult:
        """Validate one CandidatePathRisk object."""
        errors: List[str] = []
        warnings: List[str] = []

        # candidate_id
        cid = getattr(risk, "candidate_id", None)
        if not cid or cid == NOT_AVAILABLE:
            errors.append("candidate_id is missing or NOT_AVAILABLE")
        elif not isinstance(cid, str):
            errors.append(f"candidate_id must be str, got {type(cid)}")

        # frame_id
        fid = getattr(risk, "frame_id", None)
        if not isinstance(fid, int):
            errors.append(f"frame_id must be int, got {type(fid)}")

        # coordinate_frame
        cf = getattr(risk, "coordinate_frame", None)
        if cf != "VEHICLE":
            errors.append(f"coordinate_frame must be 'VEHICLE', got '{cf}'")

        # total_risk range
        tr = getattr(risk, "total_risk", None)
        if not _in_range(tr, 0.0, 1.0):
            errors.append(f"total_risk={tr} is outside [0, 1] or non-finite")

        # confidence range
        conf = getattr(risk, "confidence", None)
        if not _in_range(conf, 0.0, 1.0):
            errors.append(f"confidence={conf} is outside [0, 1]")

        # uncertainty range
        unc = getattr(risk, "uncertainty", None)
        if not _in_range(unc, 0.0, 1.0):
            errors.append(f"uncertainty={unc} is outside [0, 1]")

        # risk_level must be a RiskLevel
        rl = getattr(risk, "risk_level", None)
        if rl is None:
            errors.append("risk_level is None")

        # reason_codes must be a tuple
        rc = getattr(risk, "reason_codes", None)
        if not isinstance(rc, (tuple, list)):
            errors.append(f"reason_codes must be tuple/list, got {type(rc)}")

        # schema_version
        sv = getattr(risk, "schema_version", None)
        if sv != PATH_RISK_SCHEMA_VERSION:
            warnings.append(
                f"schema_version '{sv}' != expected '{PATH_RISK_SCHEMA_VERSION}'"
            )

        # Forbidden fields check
        for ff in self.FORBIDDEN_FIELDS:
            if hasattr(risk, ff):
                errors.append(f"Forbidden field '{ff}' found in CandidatePathRisk")

        # object_contributions validation (spot check)
        contribs = getattr(risk, "object_contributions", ())
        for i, oc in enumerate(contribs):
            ocr = getattr(oc, "combined_object_risk", None)
            if not _in_range(ocr, 0.0, 1.0):
                warnings.append(
                    f"object_contributions[{i}].combined_object_risk={ocr} "
                    "is outside [0, 1]"
                )

        return PathRiskValidationResult(
            is_valid=len(errors) == 0,
            errors=errors,
            warnings=warnings,
            candidate_id=str(cid) if cid else NOT_AVAILABLE,
        )

    def validate_risk_set(self, risk_set: PathRiskSet) -> PathRiskSetValidationResult:
        """Validate a PathRiskSet."""
        errors: List[str] = []
        warnings: List[str] = []
        per_risk: List[PathRiskValidationResult] = []

        # set_id
        sid = getattr(risk_set, "set_id", None)
        if not sid:
            warnings.append("set_id is empty or None")

        # schema_version
        sv = getattr(risk_set, "schema_version", None)
        if sv != PATH_RISK_SCHEMA_VERSION:
            warnings.append(
                f"PathRiskSet schema_version '{sv}' != '{PATH_RISK_SCHEMA_VERSION}'"
            )

        # coordinate_frame
        cf = getattr(risk_set, "coordinate_frame", None)
        if cf != "VEHICLE":
            errors.append(f"PathRiskSet coordinate_frame must be 'VEHICLE', got '{cf}'")

        # Forbidden fields on the set
        for ff in self.FORBIDDEN_FIELDS:
            if hasattr(risk_set, ff):
                errors.append(f"Forbidden field '{ff}' found in PathRiskSet")

        # Per-risk validation
        risks = getattr(risk_set, "risks", ())
        frame_ids = set()
        for r in risks:
            result = self.validate_risk(r)
            per_risk.append(result)
            if not result.is_valid:
                errors.append(
                    f"CandidatePathRisk '{result.candidate_id}' failed validation"
                )
            frame_ids.add(getattr(r, "frame_id", None))

        if len(frame_ids) > 1:
            warnings.append(
                f"PathRiskSet contains risks from multiple frame_ids: {frame_ids}"
            )

        return PathRiskSetValidationResult(
            is_valid=len(errors) == 0,
            errors=errors,
            warnings=warnings,
            per_risk_results=per_risk,
        )
