"""
IndiDrive AI — Phase 9.2 | Candidate Path Generator
====================================================
Generates geometrically feasible candidate paths from a PlanningSpace.

Phase 9.2 answers:
    «"Given the current planning space, what feasible candidate paths
      are geometrically possible?"»

Phase 9.2 does NOT:
  - score candidates for collision / risk
  - select a winner / best path
  - perform adaptive replanning
  - issue steering, throttle, brake, or speed commands

Design rules:
  * stateless — no global mutable state
  * deterministic — same inputs → same output
  * lightweight — no deep learning, no solvers, no cloud APIs
  * partial availability — produces best safe partial output
  * respects Phase 8.4 planning_allowed flag
  * does NOT override Phase 8.4 safety gate

Algorithm summary:
  1. Safety gate check (Phase 8.4 planning_allowed).
  2. Extract geometry from PlanningSpace.spatial_extent.
  3. Build reference centreline from boundary interpolation.
  4. Determine usable lateral offsets (clipped to available boundary).
  5. For each offset, sample waypoints along the planning horizon.
  6. Compute geometric heading and curvature from waypoint diffs.
  7. Validate each candidate (boundary, drivable space, geometry).
  8. Return deterministic CandidatePathSet.

Coordinate convention (vehicle frame — same as Phase 9.1):
    +X = forward
    +Y = left
    +Z = up
    Origin = vehicle rear-axle centre
    Units = metres
"""
from __future__ import annotations

import math
import time
import uuid
from typing import List, Optional, Tuple

from .candidate_generator_config import CandidateGeneratorConfig
from .candidate_path_types import (
    NOT_AVAILABLE,
    CANDIDATE_PATH_SCHEMA_VERSION,
    BoundaryValidity,
    CandidateGenerationStatus,
    CandidateMetadata,
    CandidatePath,
    CandidatePathSet,
    DrivableSpaceValidity,
    GenerationMethod,
    GeometricValidity,
    PathPoint,
)
from .candidate_validator import CandidateValidator
from .planning_input_types import PlanningInput
from .planning_space_types import (
    BoundarySegment,
    DrivableState,
    PlanningSpace,
    PlanningSpaceStatus,
    RegionKind,
)

__all__ = [
    "CandidatePathGenerator",
]

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

_COORD_FRAME = "VEHICLE"
_SMALL = 1e-6  # numerical epsilon


# ---------------------------------------------------------------------------
# Geometry helpers
# ---------------------------------------------------------------------------

def _safe_float(v, default: float = 0.0) -> float:
    try:
        f = float(v)
        return f if math.isfinite(f) else default
    except (TypeError, ValueError):
        return default


def _interp_boundary(x: float, bnd: Tuple[BoundarySegment, ...]) -> Optional[float]:
    """Linearly interpolate the y-coordinate of a boundary at longitudinal position x.

    Returns None if the boundary is empty.
    Extrapolates flat at the nearest endpoint when x is outside the boundary range.
    """
    if not bnd:
        return None

    # Single point — flat extrapolation
    if len(bnd) == 1:
        return bnd[0].y

    # x before first segment
    if x <= bnd[0].x:
        return bnd[0].y

    # x after last segment
    if x >= bnd[-1].x:
        return bnd[-1].y

    # Binary search for surrounding segment
    lo, hi = 0, len(bnd) - 1
    while lo + 1 < hi:
        mid = (lo + hi) // 2
        if bnd[mid].x <= x:
            lo = mid
        else:
            hi = mid

    # Linear interpolation between lo and hi
    span = bnd[hi].x - bnd[lo].x
    if span < _SMALL:
        return bnd[lo].y
    t = (x - bnd[lo].x) / span
    return bnd[lo].y + t * (bnd[hi].y - bnd[lo].y)


def _centre_y(
    x: float,
    left_bnd: Tuple[BoundarySegment, ...],
    right_bnd: Tuple[BoundarySegment, ...],
    left_m: Optional[float],
    right_m: Optional[float],
    road_width_m: Optional[float],
) -> float:
    """Compute the centreline y-coordinate at longitudinal position x.

    Priority:
      1. Both boundary arrays available → midpoint.
      2. One boundary array + road_width → estimate other side.
      3. left_m / right_m scalars if no arrays → midpoint.
      4. Fallback → 0.0 (vehicle centreline).
    """
    left_y: Optional[float] = None
    right_y: Optional[float] = None

    if left_bnd:
        left_y = _interp_boundary(x, left_bnd)
    elif left_m is not None:
        left_y = left_m

    if right_bnd:
        right_y = _interp_boundary(x, right_bnd)
    elif right_m is not None:
        right_y = right_m

    if left_y is not None and right_y is not None:
        return (left_y + right_y) / 2.0

    if left_y is not None and road_width_m is not None:
        return left_y - road_width_m / 2.0

    if right_y is not None and road_width_m is not None:
        return right_y + road_width_m / 2.0

    return 0.0


def _lateral_limits(
    x: float,
    left_bnd: Tuple[BoundarySegment, ...],
    right_bnd: Tuple[BoundarySegment, ...],
    left_m: Optional[float],
    right_m: Optional[float],
    road_width_m: Optional[float],
    centre_y: float,
) -> Tuple[Optional[float], Optional[float]]:
    """Return (max_left_from_centre, max_right_from_centre) at position x.

    Returns (None, None) if boundaries are fully unknown.
    max_left_from_centre > 0 (how far left from centre is available).
    max_right_from_centre > 0 (how far right from centre is available; magnitude).
    """
    left_y: Optional[float] = None
    right_y: Optional[float] = None

    if left_bnd:
        left_y = _interp_boundary(x, left_bnd)
    elif left_m is not None:
        left_y = left_m

    if right_bnd:
        right_y = _interp_boundary(x, right_bnd)
    elif right_m is not None:
        right_y = right_m

    # Estimate from road_width if only one side known
    if left_y is None and right_y is not None and road_width_m is not None:
        left_y = right_y + road_width_m
    if right_y is None and left_y is not None and road_width_m is not None:
        right_y = left_y - road_width_m

    max_left: Optional[float] = None
    max_right: Optional[float] = None

    if left_y is not None:
        max_left = left_y - centre_y
    if right_y is not None:
        max_right = centre_y - right_y  # positive magnitude

    return max_left, max_right


def _sample_xs(horizon_m: float, resolution_m: float, max_length_m: float) -> List[float]:
    """Generate monotonically increasing x sample positions."""
    effective_horizon = min(horizon_m, max_length_m)
    if effective_horizon <= 0 or resolution_m <= 0:
        return [0.0]

    xs = []
    x = 0.0
    while x <= effective_horizon + _SMALL:
        xs.append(min(x, effective_horizon))
        x += resolution_m
    # Ensure we always start at 0
    if not xs or xs[0] > _SMALL:
        xs.insert(0, 0.0)
    # Ensure last point is at horizon
    if xs[-1] < effective_horizon - _SMALL:
        xs.append(effective_horizon)
    return xs


def _compute_heading_curvature(
    waypoints: List[PathPoint],
) -> List[PathPoint]:
    """Compute heading and curvature from waypoint positions.

    Heading: forward-difference angle from consecutive (x, y) pairs.
    Curvature: three-point Menger curvature (signed, positive = left turn).
    This is purely geometric — no optimization, no smoothing.
    """
    n = len(waypoints)
    if n == 0:
        return waypoints

    result: List[PathPoint] = []

    for i, pt in enumerate(waypoints):
        # Heading
        if i < n - 1:
            nxt = waypoints[i + 1]
            dx = nxt.x - pt.x
            dy = nxt.y - pt.y
            heading = math.atan2(dy, dx) if (abs(dx) + abs(dy) > _SMALL) else 0.0
        elif i > 0:
            prev = waypoints[i - 1]
            dx = pt.x - prev.x
            dy = pt.y - prev.y
            heading = math.atan2(dy, dx) if (abs(dx) + abs(dy) > _SMALL) else 0.0
        else:
            heading = 0.0

        # Curvature via Menger formula using three points
        curvature: Optional[float] = None
        if 0 < i < n - 1:
            p0 = waypoints[i - 1]
            p1 = pt
            p2 = waypoints[i + 1]
            ax, ay = p1.x - p0.x, p1.y - p0.y
            bx, by = p2.x - p1.x, p2.y - p1.y
            cross = ax * by - ay * bx   # signed area × 2
            la = math.hypot(ax, ay)
            lb = math.hypot(bx, by)
            d02 = math.hypot(p2.x - p0.x, p2.y - p0.y)
            if la > _SMALL and lb > _SMALL and d02 > _SMALL:
                # k = 2 * |area| / (|p0p1| * |p1p2| * |p0p2|)
                # signed: positive = left turn
                curvature = 2.0 * cross / (la * lb * d02)

        result.append(
            PathPoint(
                x=pt.x,
                y=pt.y,
                z=pt.z,
                longitudinal_s=pt.longitudinal_s,
                lateral_offset_m=pt.lateral_offset_m,
                heading=heading,
                curvature=curvature,
            )
        )

    return result


def _assign_candidate_id(offset: float, pos_count: int, neg_count: int) -> str:
    """Assign a stable deterministic candidate ID based on lateral offset.

    Center → "CENTER"
    k-th positive offset (ascending magnitude) → "LEFT_{k}"
    k-th negative offset (ascending magnitude) → "RIGHT_{k}"
    """
    if abs(offset) < _SMALL:
        return "CENTER"
    if offset > 0:
        return f"LEFT_{pos_count}"
    return f"RIGHT_{neg_count}"


def _is_point_in_region(px: float, py: float, region) -> bool:
    """Check if (px, py) is within the bounding box of a planning region."""
    xmin = region.x_min
    xmax = region.x_max
    ymin = region.y_min
    ymax = region.y_max
    if xmin is None or xmax is None or ymin is None or ymax is None:
        return False
    return xmin <= px <= xmax and ymin <= py <= ymax


# ---------------------------------------------------------------------------
# CandidatePathGenerator
# ---------------------------------------------------------------------------

class CandidatePathGenerator:
    """Generates geometrically feasible candidate paths for one processing cycle.

    Usage:
        generator = CandidatePathGenerator(config)
        path_set = generator.generate(planning_input, planning_space)

    The generator is stateless — each call to generate() is independent.
    The output CandidatePathSet is immutable after creation.
    """

    def __init__(self, config: Optional[CandidateGeneratorConfig] = None) -> None:
        self._config = config or CandidateGeneratorConfig()
        self._validator = CandidateValidator(self._config)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def generate(
        self,
        planning_input: PlanningInput,
        planning_space: PlanningSpace,
    ) -> CandidatePathSet:
        """Generate candidate paths from the supplied planning space.

        Parameters
        ----------
        planning_input  : Phase 9.1 PlanningInput (carries references to
                          WorldModelSnapshot and PlanningContext).
        planning_space  : Phase 9.1 PlanningSpace built by PlanningSpaceBuilder.

        Returns
        -------
        CandidatePathSet — immutable set of candidate paths (may be empty).

        Never raises — all errors result in a structured empty CandidatePathSet.
        """
        try:
            return self._generate_impl(planning_input, planning_space)
        except Exception as exc:  # pragma: no cover — belt-and-suspenders
            return self._error_set(
                planning_space=planning_space,
                reason=f"Unexpected generation error: {exc}",
            )

    # ------------------------------------------------------------------
    # Internal implementation
    # ------------------------------------------------------------------

    def _generate_impl(
        self,
        planning_input: PlanningInput,
        planning_space: PlanningSpace,
    ) -> CandidatePathSet:
        cfg = self._config
        ts = time.time()
        frame_id = getattr(planning_input, "frame_id", 0)

        # ----------------------------------------------------------------
        # Step 1: Safety gate check (Phase 8.4)
        # ----------------------------------------------------------------
        if not planning_space.planning_allowed:
            return CandidatePathSet(
                set_id=self._make_id(),
                frame_id=frame_id,
                timestamp=ts,
                coordinate_frame=_COORD_FRAME,
                planning_space_ref=planning_space.space_id,
                safety_gate_state=planning_space.safety_gate_state,
                planning_allowed=False,
                _candidates=(),
                generation_status=(
                    CandidateGenerationStatus.NO_CANDIDATES_DUE_TO_PLANNING_RESTRICTION
                ),
                generation_reason=(
                    f"Planning not allowed: "
                    f"safety_gate_state={planning_space.safety_gate_state}"
                ),
                schema_version=CANDIDATE_PATH_SCHEMA_VERSION,
            )

        # ----------------------------------------------------------------
        # Step 2: Extract geometry from PlanningSpace
        # ----------------------------------------------------------------
        extent = planning_space.spatial_extent
        horizon_m = planning_space.horizon.longitudinal_m
        if not (math.isfinite(horizon_m) and horizon_m > 0):
            horizon_m = 50.0  # safe fallback

        left_bnd: Tuple[BoundarySegment, ...] = extent.left_boundary
        right_bnd: Tuple[BoundarySegment, ...] = extent.right_boundary
        left_m: Optional[float] = extent.left_m
        right_m: Optional[float] = extent.right_m
        road_width_m: Optional[float] = extent.road_width_m

        is_degraded = planning_space.quality.is_degraded or planning_space.quality.is_partial
        planning_mode = planning_space.planning_mode

        # ----------------------------------------------------------------
        # Step 3: Check if we have enough geometry to generate candidates
        # ----------------------------------------------------------------
        has_any_geometry = (
            bool(left_bnd)
            or bool(right_bnd)
            or left_m is not None
            or right_m is not None
            or road_width_m is not None
        )
        if (
            planning_space.status in (PlanningSpaceStatus.EMPTY, PlanningSpaceStatus.INVALID)
            and not has_any_geometry
        ):
            return CandidatePathSet(
                set_id=self._make_id(),
                frame_id=frame_id,
                timestamp=ts,
                coordinate_frame=_COORD_FRAME,
                planning_space_ref=planning_space.space_id,
                safety_gate_state=planning_space.safety_gate_state,
                planning_allowed=planning_space.planning_allowed,
                _candidates=(),
                generation_status=(
                    CandidateGenerationStatus.NO_CANDIDATES_INSUFFICIENT_SPACE
                ),
                generation_reason=(
                    f"Planning space status={planning_space.status.value} "
                    "with no geometry available"
                ),
                schema_version=CANDIDATE_PATH_SCHEMA_VERSION,
            )

        # ----------------------------------------------------------------
        # Step 4: Sample longitudinal positions
        # ----------------------------------------------------------------
        xs = _sample_xs(horizon_m, cfg.sample_resolution_m, cfg.maximum_path_length_m)
        xs = xs[: cfg.max_waypoints]  # hard cap on waypoints

        # ----------------------------------------------------------------
        # Step 5: Build reference centreline y values at each x
        # ----------------------------------------------------------------
        centre_ys = [
            _centre_y(x, left_bnd, right_bnd, left_m, right_m, road_width_m)
            for x in xs
        ]

        # ----------------------------------------------------------------
        # Step 6: Determine usable lateral offsets
        # ----------------------------------------------------------------
        raw_offsets = list(cfg.lateral_offsets_m)
        usable_offsets = self._filter_offsets(
            raw_offsets, xs, left_bnd, right_bnd, left_m, right_m, road_width_m, centre_ys
        )

        # ----------------------------------------------------------------
        # Step 7: Generate a candidate for each offset
        # ----------------------------------------------------------------
        candidates: List[CandidatePath] = []
        pos_count = 0
        neg_count = 0
        centre_generated = False

        for offset in usable_offsets:
            if len(candidates) >= cfg.max_candidates:
                break

            # Skip duplicate center
            if abs(offset) < _SMALL:
                if centre_generated:
                    continue
                centre_generated = True

            # Assign stable ID
            if abs(offset) < _SMALL:
                cand_id = "CENTER"
            elif offset > 0:
                pos_count += 1
                cand_id = f"LEFT_{pos_count}"
            else:
                neg_count += 1
                cand_id = f"RIGHT_{neg_count}"

            candidate = self._make_candidate(
                candidate_id=cand_id,
                frame_id=frame_id,
                timestamp=ts,
                xs=xs,
                centre_ys=centre_ys,
                lateral_offset=offset,
                planning_space=planning_space,
                planning_mode=planning_mode,
                is_degraded=is_degraded,
                index=len(candidates),
            )
            if candidate is not None:
                candidates.append(candidate)

        # ----------------------------------------------------------------
        # Step 8: Determine generation status
        # ----------------------------------------------------------------
        if not candidates:
            status = CandidateGenerationStatus.EMPTY_NO_VALID_GEOMETRY
            reason = "No geometrically valid candidates could be generated"
        elif is_degraded:
            status = CandidateGenerationStatus.PARTIAL_CANDIDATES_DEGRADED_INPUT
            reason = "Candidates generated from degraded/partial planning space"
        else:
            status = CandidateGenerationStatus.CANDIDATES_GENERATED
            reason = f"{len(candidates)} candidate(s) generated"

        # ----------------------------------------------------------------
        # Step 9: Assemble immutable CandidatePathSet
        # ----------------------------------------------------------------
        path_set = CandidatePathSet(
            set_id=self._make_id(),
            frame_id=frame_id,
            timestamp=ts,
            coordinate_frame=_COORD_FRAME,
            planning_space_ref=planning_space.space_id,
            safety_gate_state=planning_space.safety_gate_state,
            planning_allowed=planning_space.planning_allowed,
            _candidates=tuple(candidates),
            generation_status=status,
            generation_reason=reason,
            schema_version=CANDIDATE_PATH_SCHEMA_VERSION,
        )

        return path_set

    # ------------------------------------------------------------------
    # Offset filtering
    # ------------------------------------------------------------------

    def _filter_offsets(
        self,
        offsets: List[float],
        xs: List[float],
        left_bnd: Tuple[BoundarySegment, ...],
        right_bnd: Tuple[BoundarySegment, ...],
        left_m: Optional[float],
        right_m: Optional[float],
        road_width_m: Optional[float],
        centre_ys: List[float],
    ) -> List[float]:
        """Return only offsets that fit within the available boundary at all sampled positions.

        An offset is accepted if the offset path (centre_y + offset) stays within
        the known boundary (minus vehicle_half_width_m margin) at every x.

        If boundary is unknown, all configured offsets are returned (no rejection).
        """
        cfg = self._config
        margin = cfg.vehicle_half_width_m
        has_boundary = (
            bool(left_bnd) or bool(right_bnd)
            or left_m is not None or right_m is not None
            or road_width_m is not None
        )

        if not has_boundary:
            # Cannot validate offsets — return all, generation will mark UNKNOWN boundary
            return list(offsets)

        valid_offsets: List[float] = []
        for offset in offsets:
            fits = True
            for x, cy in zip(xs, centre_ys):
                path_y = cy + offset
                max_left, max_right = _lateral_limits(
                    x, left_bnd, right_bnd, left_m, right_m, road_width_m, cy
                )
                if max_left is not None and offset > max_left - margin:
                    fits = False
                    break
                if max_right is not None and (-offset) > max_right - margin:
                    fits = False
                    break
            if fits:
                valid_offsets.append(offset)

        # If filtering rejected everything but we have geometry, fall back to center
        if not valid_offsets and has_boundary:
            valid_offsets = [0.0]

        return valid_offsets

    # ------------------------------------------------------------------
    # Single candidate generation
    # ------------------------------------------------------------------

    def _make_candidate(
        self,
        *,
        candidate_id: str,
        frame_id: int,
        timestamp: float,
        xs: List[float],
        centre_ys: List[float],
        lateral_offset: float,
        planning_space: PlanningSpace,
        planning_mode: str,
        is_degraded: bool,
        index: int,
    ) -> Optional[CandidatePath]:
        """Generate one CandidatePath for a given lateral offset."""
        cfg = self._config
        extent = planning_space.spatial_extent
        left_bnd = extent.left_boundary
        right_bnd = extent.right_boundary
        left_m = extent.left_m
        right_m = extent.right_m
        road_width_m = extent.road_width_m

        # Build raw waypoints
        raw_waypoints: List[PathPoint] = []
        s = 0.0
        prev_x: Optional[float] = None
        prev_y: Optional[float] = None

        for x, cy in zip(xs, centre_ys):
            y = cy + lateral_offset

            # Accumulate arc-length (straight-line approximation between samples)
            if prev_x is not None and prev_y is not None:
                dx = x - prev_x
                dy = y - prev_y
                s += math.hypot(dx, dy)
            else:
                s = 0.0

            raw_waypoints.append(
                PathPoint(
                    x=x,
                    y=y,
                    z=0.0,
                    longitudinal_s=s,
                    lateral_offset_m=lateral_offset,
                )
            )
            prev_x, prev_y = x, y

        if not raw_waypoints:
            return None

        # Truncate to max_waypoints
        raw_waypoints = raw_waypoints[: cfg.max_waypoints]

        # Compute heading/curvature from geometry
        waypoints = _compute_heading_curvature(raw_waypoints)

        # Reject if too few waypoints
        if len(waypoints) < cfg.min_waypoints:
            return None

        # Longitudinal extent = x of last waypoint
        longitudinal_extent = waypoints[-1].x

        # Reject if path is too short
        if longitudinal_extent < cfg.minimum_path_length_m:
            return None

        # Determine generation method
        if abs(lateral_offset) < _SMALL:
            method = GenerationMethod.CENTER
        else:
            marking_state = planning_space.road_structure.marking_state
            if marking_state in ("UNMARKED", "NOT_AVAILABLE") or not planning_space.road_structure.lane_info_available:
                method = GenerationMethod.UNMARKED_ROAD_INFERRED
            else:
                method = GenerationMethod.LATERAL_OFFSET

        # Validate boundary
        bnd_validity = self._check_boundary_validity(
            waypoints, left_bnd, right_bnd, left_m, right_m, road_width_m
        )

        # Validate drivable space
        drv_validity = self._check_drivable_space_validity(waypoints, planning_space)

        # Check geometric continuity
        geom_validity = self._check_geometric_validity(waypoints)

        # Path length for metadata
        path_length = waypoints[-1].longitudinal_s if waypoints else 0.0

        metadata = CandidateMetadata(
            candidate_index=index,
            generation_timestamp=timestamp,
            planning_space_ref=planning_space.space_id,
            planning_mode=planning_mode,
            path_length_m=round(path_length, 3),
            waypoint_count=len(waypoints),
            nominal_lateral_offset_m=lateral_offset,
            is_partial=is_degraded,
            is_degraded=is_degraded,
            generation_notes=(
                f"road_marking={planning_space.road_structure.marking_state}"
            ),
        )

        return CandidatePath(
            candidate_id=candidate_id,
            frame_id=frame_id,
            timestamp=timestamp,
            coordinate_frame=_COORD_FRAME,
            _waypoints=tuple(waypoints),
            longitudinal_extent_m=longitudinal_extent,
            lateral_offset_m=lateral_offset,
            generation_method=method,
            source_reference=planning_space.space_id,
            geometric_validity=geom_validity,
            boundary_validity=bnd_validity,
            drivable_space_validity=drv_validity,
            metadata=metadata,
            schema_version=CANDIDATE_PATH_SCHEMA_VERSION,
        )

    # ------------------------------------------------------------------
    # Validity checks
    # ------------------------------------------------------------------

    def _check_geometric_validity(
        self, waypoints: List[PathPoint]
    ) -> GeometricValidity:
        """Check self-consistency of waypoint geometry.

        Rejects:
          - non-finite coordinates
          - non-monotone longitudinal_s
          - excessive lateral jumps between consecutive points
        """
        if not waypoints:
            return GeometricValidity.INVALID

        cfg = self._config
        prev_s: Optional[float] = None
        prev_y: Optional[float] = None
        had_partial = False

        for pt in waypoints:
            # Finite check
            for attr in ("x", "y", "z", "longitudinal_s"):
                val = getattr(pt, attr)
                if not math.isfinite(val):
                    return GeometricValidity.INVALID

            # Monotone longitudinal_s
            if prev_s is not None and pt.longitudinal_s < prev_s - _SMALL:
                return GeometricValidity.INVALID

            # Lateral jump
            if prev_y is not None:
                jump = abs(pt.y - prev_y)
                if jump > cfg.max_lateral_jump_m:
                    had_partial = True

            prev_s = pt.longitudinal_s
            prev_y = pt.y

        return GeometricValidity.PARTIALLY_VALID if had_partial else GeometricValidity.VALID

    def _check_boundary_validity(
        self,
        waypoints: List[PathPoint],
        left_bnd: Tuple[BoundarySegment, ...],
        right_bnd: Tuple[BoundarySegment, ...],
        left_m: Optional[float],
        right_m: Optional[float],
        road_width_m: Optional[float],
    ) -> BoundaryValidity:
        """Check whether waypoints stay within known road/drivable boundaries.

        Returns UNKNOWN when no boundary data is available.
        """
        cfg = self._config
        if not cfg.boundary_check_enabled:
            return BoundaryValidity.UNKNOWN

        has_left = bool(left_bnd) or left_m is not None
        has_right = bool(right_bnd) or right_m is not None

        if not has_left and not has_right:
            # Try to infer from road_width_m
            if road_width_m is None:
                return BoundaryValidity.UNKNOWN

        violations = 0
        total = len(waypoints)
        if total == 0:
            return BoundaryValidity.UNKNOWN

        for pt in waypoints:
            centre_at_x = _centre_y(
                pt.x, left_bnd, right_bnd, left_m, right_m, road_width_m
            )
            max_left, max_right = _lateral_limits(
                pt.x, left_bnd, right_bnd, left_m, right_m, road_width_m, centre_at_x
            )
            offset_from_centre = pt.y - centre_at_x

            if max_left is not None and offset_from_centre > max_left:
                violations += 1
                continue
            if max_right is not None and -offset_from_centre > max_right:
                violations += 1

        if violations == 0:
            return BoundaryValidity.VALID
        if violations == total:
            return BoundaryValidity.INVALID
        return BoundaryValidity.PARTIALLY_VALID

    def _check_drivable_space_validity(
        self,
        waypoints: List[PathPoint],
        planning_space: PlanningSpace,
    ) -> DrivableSpaceValidity:
        """Check whether waypoints are within confirmed drivable space.

        Checks against:
          - non_drivable_regions (clear non-drivable → INVALID)
          - restricted_regions (safety/hard constraint areas → INVALID)

        Does NOT check dynamic object positions (that is Phase 9.3).
        """
        cfg = self._config
        if not cfg.drivable_space_check_enabled:
            return DrivableSpaceValidity.UNKNOWN

        non_drivable = planning_space.non_drivable_regions
        restricted = planning_space.restricted_regions

        if not non_drivable and not restricted:
            # No restriction data — cannot determine
            return DrivableSpaceValidity.UNKNOWN

        violations = 0
        total = len(waypoints)
        if total == 0:
            return DrivableSpaceValidity.UNKNOWN

        for pt in waypoints:
            px, py = pt.x, pt.y

            # Check non-drivable regions
            in_non_drivable = any(
                _is_point_in_region(px, py, r)
                for r in non_drivable
                if r.drivable_state in (DrivableState.NON_DRIVABLE,)
            )
            if in_non_drivable:
                violations += 1
                continue

            # Check restricted regions (from safety gate)
            in_restricted = any(
                _is_point_in_region(px, py, r) for r in restricted
            )
            if in_restricted:
                violations += 1

        if violations == 0:
            return DrivableSpaceValidity.VALID
        if violations == total:
            return DrivableSpaceValidity.INVALID
        return DrivableSpaceValidity.PARTIALLY_VALID

    # ------------------------------------------------------------------
    # Utilities
    # ------------------------------------------------------------------

    @staticmethod
    def _make_id() -> str:
        return str(uuid.uuid4())

    def _error_set(
        self,
        planning_space: Optional[PlanningSpace],
        reason: str,
    ) -> CandidatePathSet:
        """Build an empty error CandidatePathSet."""
        return CandidatePathSet(
            set_id=self._make_id(),
            frame_id=0,
            timestamp=time.time(),
            coordinate_frame=_COORD_FRAME,
            planning_space_ref=(
                planning_space.space_id if planning_space is not None else NOT_AVAILABLE
            ),
            safety_gate_state=(
                planning_space.safety_gate_state
                if planning_space is not None
                else NOT_AVAILABLE
            ),
            planning_allowed=False,
            _candidates=(),
            generation_status=CandidateGenerationStatus.GENERATION_ERROR,
            generation_reason=reason,
            schema_version=CANDIDATE_PATH_SCHEMA_VERSION,
        )
