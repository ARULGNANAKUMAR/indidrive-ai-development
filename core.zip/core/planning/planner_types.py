"""
IndiDrive AI — Phase 9.6 | Final Planner Integration — Data Contracts
=======================================================================
Strongly-typed containers for the Phase 9.6 integrated planner pipeline.

Phase 9.6 answers:
    «"Given the full planning context (World Model, Safety Gate, Road
      Understanding, Planning Space, Indian-road constraints, candidate
      paths, and path risk information), can the planning subsystem
      operate as one consistent, end-to-end planning pipeline?"»

Phase 9.6 does NOT:
  - issue steering / throttle / brake / actuator commands
  - implement MPC, PID, or any vehicle controller
  - run new perception, prediction, or sensor fusion
  - call LLMs, cloud APIs, or neural networks

Design rules:
  * dataclasses — not raw dicts
  * enums for all finite states
  * explicit NOT_AVAILABLE / UNKNOWN — never fabricated
  * deterministic: same input → same output
  * no vehicle control of any kind
  * lightweight — no heavy solvers or ML inference

Coordinate convention (vehicle frame — same as all prior planning phases):
    +X = forward
    +Y = left
    +Z = up
    Origin = vehicle rear-axle centre
    Units = metres
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Optional, Tuple

__all__ = [
    # Sentinels / schema
    "NOT_AVAILABLE",
    "PLANNER_SCHEMA_VERSION",
    # Enums
    "PlannerStatus",
    "PlannerState",
    "InputValidationStatus",
    # Primary containers
    "PlannerInput",
    "PlannerOutput",
    "PlannerSnapshot",
    "CandidateSummary",
    "RiskSummary",
    "ReplanSummary",
    "PlannerMetrics",
]

NOT_AVAILABLE = "NOT_AVAILABLE"
PLANNER_SCHEMA_VERSION = "9.6"


# ---------------------------------------------------------------------------
# Planner status — deterministic pipeline-level states
# ---------------------------------------------------------------------------

class PlannerStatus(str, Enum):
    """
    Top-level planner pipeline status for one evaluation cycle.

    READY                — planner is initialised and idle; no planning requested.
    PLANNING             — pipeline is actively processing (in-progress marker).
    PLAN_AVAILABLE       — pipeline completed; at least one valid, risk-evaluated
                           candidate is available; replanning not required.
    REPLAN_REQUIRED      — pipeline completed; replanning engine has determined
                           a new planning cycle is needed.
    DEGRADED             — pipeline completed in degraded mode due to missing or
                           stale inputs; result carries elevated uncertainty.
    BLOCKED              — all evaluated candidates have unacceptable risk; no
                           feasible plan is currently available.
    SAFETY_RESTRICTED    — Phase 8.4 safety gate forbids planning (planning_allowed=False).
    INVALID_INPUT        — input validation failed; pipeline did not execute.
    STALE_INPUT          — one or more critical inputs exceeded staleness threshold.
    NO_FEASIBLE_CANDIDATE — Phase 9.2 produced no geometrically valid candidate.
    UNKNOWN              — pipeline state cannot be determined.
    """
    READY                  = "READY"
    PLANNING               = "PLANNING"
    PLAN_AVAILABLE         = "PLAN_AVAILABLE"
    REPLAN_REQUIRED        = "REPLAN_REQUIRED"
    DEGRADED               = "DEGRADED"
    BLOCKED                = "BLOCKED"
    SAFETY_RESTRICTED      = "SAFETY_RESTRICTED"
    INVALID_INPUT          = "INVALID_INPUT"
    STALE_INPUT            = "STALE_INPUT"
    NO_FEASIBLE_CANDIDATE  = "NO_FEASIBLE_CANDIDATE"
    UNKNOWN                = "UNKNOWN"


class PlannerState(str, Enum):
    """
    Operational state of the planner instance between cycles.

    UNINITIALISED — planner has never been run.
    IDLE          — planner has run at least once and is awaiting new input.
    ACTIVE        — planner is mid-cycle (PLANNING status above).
    ERROR         — planner encountered an unrecoverable internal error.
    """
    UNINITIALISED = "UNINITIALISED"
    IDLE          = "IDLE"
    ACTIVE        = "ACTIVE"
    ERROR         = "ERROR"


class InputValidationStatus(str, Enum):
    """Result of Stage 1 input validation."""
    VALID            = "VALID"
    VALID_DEGRADED   = "VALID_DEGRADED"   # inputs present but with elevated uncertainty
    STALE            = "STALE"
    MISSING_CRITICAL = "MISSING_CRITICAL"
    FRAME_MISMATCH   = "FRAME_MISMATCH"
    INVALID          = "INVALID"


# ---------------------------------------------------------------------------
# Candidate summary — compact per-cycle snapshot of Phase 9.2 results
# ---------------------------------------------------------------------------

@dataclass
class CandidateSummary:
    """Compact summary of the Phase 9.2 candidate generation result."""
    candidate_count: int = 0
    valid_candidate_count: int = 0
    invalid_candidate_count: int = 0
    generation_status: str = NOT_AVAILABLE
    coordinate_frame: str = NOT_AVAILABLE
    planning_allowed: bool = False

    def to_dict(self) -> dict:
        return {
            "candidate_count": self.candidate_count,
            "valid_candidate_count": self.valid_candidate_count,
            "invalid_candidate_count": self.invalid_candidate_count,
            "generation_status": self.generation_status,
            "coordinate_frame": self.coordinate_frame,
            "planning_allowed": self.planning_allowed,
        }


# ---------------------------------------------------------------------------
# Risk summary — compact per-cycle snapshot of Phase 9.3 results
# ---------------------------------------------------------------------------

@dataclass
class RiskSummary:
    """Compact summary of the Phase 9.3 path risk evaluation result."""
    risk_evaluation_count: int = 0
    high_risk_candidate_count: int = 0
    critical_risk_candidate_count: int = 0
    all_candidates_high_risk: bool = False
    lowest_risk_candidate_id: str = NOT_AVAILABLE
    risk_status: str = NOT_AVAILABLE
    dominant_risk_reason: str = NOT_AVAILABLE

    def to_dict(self) -> dict:
        return {
            "risk_evaluation_count": self.risk_evaluation_count,
            "high_risk_candidate_count": self.high_risk_candidate_count,
            "critical_risk_candidate_count": self.critical_risk_candidate_count,
            "all_candidates_high_risk": self.all_candidates_high_risk,
            "lowest_risk_candidate_id": self.lowest_risk_candidate_id,
            "risk_status": self.risk_status,
            "dominant_risk_reason": self.dominant_risk_reason,
        }


# ---------------------------------------------------------------------------
# Replan summary — compact per-cycle snapshot of Phase 9.4 results
# ---------------------------------------------------------------------------

@dataclass
class ReplanSummary:
    """Compact summary of the Phase 9.4 replanning decision result."""
    replanning_required: bool = False
    replanning_decision: str = NOT_AVAILABLE
    replanning_urgency: str = NOT_AVAILABLE
    dominant_reason: str = NOT_AVAILABLE
    reason_codes: Tuple[str, ...] = field(default_factory=tuple)
    safety_gate_state: str = NOT_AVAILABLE

    def to_dict(self) -> dict:
        return {
            "replanning_required": self.replanning_required,
            "replanning_decision": self.replanning_decision,
            "replanning_urgency": self.replanning_urgency,
            "dominant_reason": self.dominant_reason,
            "reason_codes": list(self.reason_codes),
            "safety_gate_state": self.safety_gate_state,
        }


# ---------------------------------------------------------------------------
# Planner input — clean input contract for Phase 9.6 pipeline
# ---------------------------------------------------------------------------

@dataclass
class PlannerInput:
    """
    Clean input contract for the Phase 9.6 pipeline.

    Carries references to all upstream phase outputs that the integrated
    planner needs.  Does NOT copy or re-compute any upstream data.

    Forbidden fields:
        steering, throttle, brake, actuator_command, wheel_angle,
        motor_command, MPC_output, camera images, LiDAR point clouds,
        raw radar packets.
    """
    frame_id: int = 0
    timestamp: float = field(default_factory=time.time)
    schema_version: str = PLANNER_SCHEMA_VERSION

    # --- Upstream phase outputs (references, not copies) ---
    world_model_snapshot: Optional[object] = None    # Phase 7
    planning_context: Optional[object] = None        # Phase 8.4
    planning_input: Optional[object] = None          # Phase 9.1 PlanningInput
    planning_space: Optional[object] = None          # Phase 9.1 PlanningSpace
    candidate_set: Optional[object] = None           # Phase 9.2 CandidatePathSet
    risk_set: Optional[object] = None                # Phase 9.3 PathRiskSet
    replanning_result: Optional[object] = None       # Phase 9.4 ReplanningDecisionResult
    indian_road_result: Optional[object] = None      # Phase 9.5 IndianRoadPlanningResult

    def to_dict(self) -> dict:
        return {
            "frame_id": self.frame_id,
            "timestamp": round(self.timestamp, 6),
            "schema_version": self.schema_version,
            "world_model_available": self.world_model_snapshot is not None,
            "planning_context_available": self.planning_context is not None,
            "planning_input_available": self.planning_input is not None,
            "planning_space_available": self.planning_space is not None,
            "candidate_set_available": self.candidate_set is not None,
            "risk_set_available": self.risk_set is not None,
            "replanning_result_available": self.replanning_result is not None,
            "indian_road_result_available": self.indian_road_result is not None,
        }


# ---------------------------------------------------------------------------
# Planner output — integrated planning result
# ---------------------------------------------------------------------------

@dataclass
class PlannerOutput:
    """
    Integrated planning result produced by the Phase 9.6 pipeline.

    This is a planning-level output ONLY.  It does NOT contain:
        steering, throttle, brake, actuator_command, wheel_angle,
        motor_command, MPC_output, PID_output, control_command.

    selected_candidate_id — ID of the planning-recommended candidate,
    determined by the deterministic safety-gated selection mechanism in
    PlannerEngine.  This is a planning recommendation ONLY; it must be
    consumed by Phase 10 (MPC/trajectory tracking) before any vehicle
    actuation occurs.
    """
    # --- Identity -----------------------------------------------------------
    frame_id: int = 0
    timestamp: float = field(default_factory=time.time)
    schema_version: str = PLANNER_SCHEMA_VERSION

    # --- Pipeline gate ------------------------------------------------------
    planning_allowed: bool = False
    safety_gate_state: str = NOT_AVAILABLE

    # --- Pipeline result ----------------------------------------------------
    planning_status: PlannerStatus = PlannerStatus.UNKNOWN
    planning_mode: str = NOT_AVAILABLE

    # --- Stage summaries ----------------------------------------------------
    input_validation_status: InputValidationStatus = InputValidationStatus.INVALID
    candidate_summary: CandidateSummary = field(default_factory=CandidateSummary)
    risk_summary: RiskSummary = field(default_factory=RiskSummary)
    replan_summary: ReplanSummary = field(default_factory=ReplanSummary)

    # --- Candidate selection (planning-level only) --------------------------
    candidate_count: int = 0
    candidate_paths_available: bool = False
    risk_evaluations_available: bool = False
    selected_candidate_id: str = NOT_AVAILABLE
    """
    Deterministic planning-level candidate recommendation.
    Selected as the geometrically valid candidate with lowest composite risk score.
    NOT a vehicle control command.  Consumed by Phase 10.
    """

    # --- Replanning ---------------------------------------------------------
    replanning_required: bool = False
    active_planning_requirement: str = NOT_AVAILABLE

    # --- Quality / confidence -----------------------------------------------
    confidence: float = 0.0
    uncertainty: float = 1.0
    degraded: bool = True
    stale: bool = False

    # --- Diagnostics --------------------------------------------------------
    reason_codes: Tuple[str, ...] = field(default_factory=tuple)
    warnings: Tuple[str, ...] = field(default_factory=tuple)
    validation_errors: Tuple[str, ...] = field(default_factory=tuple)

    def to_dict(self) -> dict:
        return {
            "schema_version": self.schema_version,
            "frame_id": self.frame_id,
            "timestamp": round(self.timestamp, 6),
            "planning_allowed": self.planning_allowed,
            "safety_gate_state": self.safety_gate_state,
            "planning_status": self.planning_status.value,
            "planning_mode": self.planning_mode,
            "input_validation_status": self.input_validation_status.value,
            "candidate_count": self.candidate_count,
            "candidate_paths_available": self.candidate_paths_available,
            "risk_evaluations_available": self.risk_evaluations_available,
            "selected_candidate_id": self.selected_candidate_id,
            "replanning_required": self.replanning_required,
            "active_planning_requirement": self.active_planning_requirement,
            "confidence": round(self.confidence, 3),
            "uncertainty": round(self.uncertainty, 3),
            "degraded": self.degraded,
            "stale": self.stale,
            "reason_codes": list(self.reason_codes),
            "warnings": list(self.warnings),
            "validation_errors": list(self.validation_errors),
            "candidate_summary": self.candidate_summary.to_dict(),
            "risk_summary": self.risk_summary.to_dict(),
            "replan_summary": self.replan_summary.to_dict(),
        }

    @property
    def has_valid_plan(self) -> bool:
        """True only when planning yielded a usable candidate."""
        return (
            self.planning_status == PlannerStatus.PLAN_AVAILABLE
            and self.planning_allowed
            and self.candidate_paths_available
            and self.selected_candidate_id != NOT_AVAILABLE
        )


# ---------------------------------------------------------------------------
# Planner snapshot — immutable/serialisable planner state
# ---------------------------------------------------------------------------

@dataclass
class PlannerSnapshot:
    """
    Immutable snapshot of one planning cycle result.

    Created by PlannerEngine after each run() call.
    Does NOT expose mutable internal engine state.
    """
    frame_id: int = 0
    timestamp: float = field(default_factory=time.time)
    schema_version: str = PLANNER_SCHEMA_VERSION

    planner_status: PlannerStatus = PlannerStatus.UNKNOWN
    planning_mode: str = NOT_AVAILABLE
    safety_gate_state: str = NOT_AVAILABLE
    planning_allowed: bool = False

    candidate_count: int = 0
    valid_candidate_count: int = 0
    risk_evaluated_count: int = 0
    high_risk_count: int = 0

    replanning_required: bool = False
    replanning_decision: str = NOT_AVAILABLE

    selected_candidate_id: str = NOT_AVAILABLE

    confidence: float = 0.0
    uncertainty: float = 1.0
    degraded: bool = True
    stale: bool = False

    reason_codes: Tuple[str, ...] = field(default_factory=tuple)
    warnings: Tuple[str, ...] = field(default_factory=tuple)

    def to_dict(self) -> dict:
        return {
            "schema_version": self.schema_version,
            "frame_id": self.frame_id,
            "timestamp": round(self.timestamp, 6),
            "planner_status": self.planner_status.value,
            "planning_mode": self.planning_mode,
            "safety_gate_state": self.safety_gate_state,
            "planning_allowed": self.planning_allowed,
            "candidate_count": self.candidate_count,
            "valid_candidate_count": self.valid_candidate_count,
            "risk_evaluated_count": self.risk_evaluated_count,
            "high_risk_count": self.high_risk_count,
            "replanning_required": self.replanning_required,
            "replanning_decision": self.replanning_decision,
            "selected_candidate_id": self.selected_candidate_id,
            "confidence": round(self.confidence, 3),
            "uncertainty": round(self.uncertainty, 3),
            "degraded": self.degraded,
            "stale": self.stale,
            "reason_codes": list(self.reason_codes),
            "warnings": list(self.warnings),
        }


# ---------------------------------------------------------------------------
# Planner metrics — per-cycle performance measurements
# ---------------------------------------------------------------------------

@dataclass
class PlannerMetrics:
    """
    Measurable per-cycle planning performance metrics.

    All durations are in milliseconds.  Zero means not measured.
    No accuracy percentages are invented — only counts and timings.
    """
    frame_id: int = 0
    timestamp: float = field(default_factory=time.time)

    # Latency (ms)
    planning_latency_ms: float = 0.0
    input_validation_latency_ms: float = 0.0

    # Candidate generation
    candidate_count: int = 0
    valid_candidate_count: int = 0
    invalid_candidate_count: int = 0

    # Risk evaluation
    risk_evaluation_count: int = 0
    high_risk_candidate_count: int = 0
    critical_risk_candidate_count: int = 0

    # Replanning
    replan_requested: bool = False
    replan_required: bool = False
    replan_reason: str = NOT_AVAILABLE

    # Pipeline outcome
    planning_success: bool = False
    no_feasible_candidate: bool = False
    safety_blocked: bool = False
    degraded_planning: bool = False

    # Geometry (where available from candidate set)
    boundary_violation_count: int = 0
    drivable_region_violation_count: int = 0

    def to_dict(self) -> dict:
        return {
            "frame_id": self.frame_id,
            "timestamp": round(self.timestamp, 6),
            "planning_latency_ms": round(self.planning_latency_ms, 3),
            "input_validation_latency_ms": round(self.input_validation_latency_ms, 3),
            "candidate_count": self.candidate_count,
            "valid_candidate_count": self.valid_candidate_count,
            "invalid_candidate_count": self.invalid_candidate_count,
            "risk_evaluation_count": self.risk_evaluation_count,
            "high_risk_candidate_count": self.high_risk_candidate_count,
            "critical_risk_candidate_count": self.critical_risk_candidate_count,
            "replan_requested": self.replan_requested,
            "replan_required": self.replan_required,
            "replan_reason": self.replan_reason,
            "planning_success": self.planning_success,
            "no_feasible_candidate": self.no_feasible_candidate,
            "safety_blocked": self.safety_blocked,
            "degraded_planning": self.degraded_planning,
            "boundary_violation_count": self.boundary_violation_count,
            "drivable_region_violation_count": self.drivable_region_violation_count,
        }
