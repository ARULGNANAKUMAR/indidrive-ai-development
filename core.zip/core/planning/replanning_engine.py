"""
IndiDrive AI — Phase 9.4 | Adaptive Replanning Engine
======================================================
Orchestrates the adaptive replanning cycle.

Phase 9.4 answers:
    «"Does the current planning solution require a new planning cycle?"»

Primary responsibilities:
  1.  Evaluate active path validity (via ActivePathMonitor).
  2.  Detect meaningful changes (via ChangeDetector).
  3.  Apply direct trigger checks (critical risk, TTC, dynamic blockage,
      geometry invalidity, safety gate, stale state).
  4.  Apply hysteresis and cooldown.
  5.  Determine replanning decision, urgency, and reason codes.
  6.  Produce a structured ReplanningRequest and optional ReplanningContext.
  7.  Integrate with Phase 9.2 (candidate regeneration request).
  8.  Integrate with Phase 9.3 (path risk set).

This engine does NOT:
  - select the best/next path
  - generate candidate paths
  - issue steering, throttle, brake, or MPC commands
  - control the vehicle
  - call neural networks, LLMs, or cloud APIs
"""
from __future__ import annotations

import math
import time
from typing import List, Optional, Set, Tuple

from .replanning_types import (
    NOT_AVAILABLE,
    REPLANNING_SCHEMA_VERSION,
    ActivePath,
    ActivePathValidity,
    ChangeMagnitudes,
    CooldownState,
    PlanningStateSnapshot,
    ReplanningContext,
    ReplanningDecision,
    ReplanningDecisionResult,
    ReplanningReasonCode,
    ReplanningRequest,
    ReplanningUrgency,
)
from .replanning_config import ReplanningConfig, load_replanning_config
from .replanning_change_detector import ChangeDetector, ChangeDetectionResult
from .active_path_monitor import ActivePathMonitor, _finite
from .candidate_path_types import (
    CandidatePathSet,
    CandidatePath,
    GeometricValidity,
    BoundaryValidity,
    DrivableSpaceValidity,
)
from .path_risk_types import (
    CandidatePathRisk,
    PathRiskSet,
    RiskLevel,
)
from .planning_space_types import PlanningSpace, PlanningSpaceStatus

__all__ = ["ReplanningEngine"]

# Deterministic priority ordering: higher index = higher priority
_REASON_PRIORITY = {
    ReplanningReasonCode.CRITICAL_PATH_RISK:    100,
    ReplanningReasonCode.TTC_DEGRADATION:        90,
    ReplanningReasonCode.DYNAMIC_PATH_BLOCKAGE:  80,
    ReplanningReasonCode.PATH_GEOMETRY_INVALID:  75,
    ReplanningReasonCode.SAFETY_GATE_CHANGE:     70,
    ReplanningReasonCode.RISK_ESCALATION:        60,
    ReplanningReasonCode.NEW_RELEVANT_OBJECT:    55,
    ReplanningReasonCode.PREDICTION_CHANGE:      50,
    ReplanningReasonCode.DRIVABLE_REGION_CHANGE: 45,
    ReplanningReasonCode.ROAD_STRUCTURE_CHANGE:  44,
    ReplanningReasonCode.ROAD_ANOMALY_CHANGE:    43,
    ReplanningReasonCode.UNCERTAINTY_ESCALATION: 40,
    ReplanningReasonCode.PLANNING_CONTEXT_CHANGE:35,
    ReplanningReasonCode.HAZARD_CLEARED:         20,
    ReplanningReasonCode.STALE_PLANNING_STATE:   15,
    ReplanningReasonCode.NO_ACTIVE_PATH:          5,
}

_URGENCY_CRITICAL_REASONS = {
    ReplanningReasonCode.CRITICAL_PATH_RISK,
    ReplanningReasonCode.TTC_DEGRADATION,
    ReplanningReasonCode.DYNAMIC_PATH_BLOCKAGE,
    ReplanningReasonCode.PATH_GEOMETRY_INVALID,
}

_URGENCY_URGENT_REASONS = {
    ReplanningReasonCode.RISK_ESCALATION,
    ReplanningReasonCode.SAFETY_GATE_CHANGE,
    ReplanningReasonCode.PREDICTION_CHANGE,
    ReplanningReasonCode.NEW_RELEVANT_OBJECT,
}

_URGENCY_ELEVATED_REASONS = {
    ReplanningReasonCode.DRIVABLE_REGION_CHANGE,
    ReplanningReasonCode.ROAD_ANOMALY_CHANGE,
    ReplanningReasonCode.ROAD_STRUCTURE_CHANGE,
    ReplanningReasonCode.UNCERTAINTY_ESCALATION,
}


class ReplanningEngine:
    """
    Adaptive Replanning Engine for Phase 9.4.

    Evaluates the current planning state each cycle and determines
    whether a new planning pass (candidate generation + risk scoring)
    is required.

    Usage
    -----
    engine = ReplanningEngine()
    engine.set_active_candidate(candidate_id, frame_id)

    for each cycle:
        result = engine.evaluate(
            frame_id=frame_id,
            risk_set=risk_set,          # from Phase 9.3
            candidate_set=candidate_set, # from Phase 9.2
            planning_space=space,        # from Phase 9.1
        )
        if result.is_replan:
            # Pass result.context to the next Phase 9.2 / 9.3 cycle
            ...

    Thread-safety: not thread-safe by default. Own one instance per
    planning thread, or synchronise externally.
    """

    def __init__(self, config: Optional[ReplanningConfig] = None) -> None:
        self._config = config or load_replanning_config()
        self._monitor = ActivePathMonitor(self._config)
        self._detector = ChangeDetector(self._config)
        self._previous_snapshot: Optional[PlanningStateSnapshot] = None
        self._last_replan_time: float = 0.0
        self._cycle_counter: int = 0
        # Hysteresis state
        self._high_risk_state: bool = False

    # -----------------------------------------------------------------------
    # Public API
    # -----------------------------------------------------------------------

    def set_active_candidate(
        self,
        candidate_id: str,
        frame_id: int = 0,
        source_frame_id: int = 0,
    ) -> None:
        """Record the currently active candidate ID.

        This does NOT choose the candidate — the caller (a future planning
        phase) supplies which candidate is being tracked.
        """
        self._monitor.set_active_candidate(candidate_id, frame_id, source_frame_id)
        # Reset snapshot when a new candidate is set
        self._previous_snapshot = None

    def evaluate(
        self,
        frame_id: int,
        risk_set: Optional[PathRiskSet] = None,
        candidate_set: Optional[CandidatePathSet] = None,
        planning_space: Optional[PlanningSpace] = None,
        timestamp: Optional[float] = None,
    ) -> ReplanningDecisionResult:
        """
        Evaluate the current active path and decide whether replanning is needed.

        Parameters
        ----------
        frame_id        : current processing frame counter.
        risk_set        : Phase 9.3 PathRiskSet for this cycle.
        candidate_set   : Phase 9.2 CandidatePathSet for this cycle.
        planning_space  : Phase 9.1 PlanningSpace for this cycle.
        timestamp       : override wall-clock time (for deterministic testing).

        Returns
        -------
        ReplanningDecisionResult with request (always) and context (when replan).
        """
        t_start = time.time()
        now = timestamp if timestamp is not None else t_start
        self._cycle_counter += 1

        # --- Step 1: Evaluate active path and build current snapshot ---
        active_path, current_snap = self._monitor.evaluate(
            frame_id=frame_id,
            risk_set=risk_set,
            candidate_set=candidate_set,
            planning_space=planning_space,
            timestamp=now,
        )

        # --- Step 2: Safety gate check ---
        # PlanningSpace carries planning_allowed and safety_gate_state directly
        planning_allowed = True  # default to allowed unless gate says otherwise
        sg_state = NOT_AVAILABLE
        if planning_space is not None:
            planning_allowed = bool(getattr(planning_space, "planning_allowed", True))
            sg_state = getattr(planning_space, "safety_gate_state", NOT_AVAILABLE) or NOT_AVAILABLE
        # Also pull from candidate set if available (more recent gate state)
        if candidate_set is not None:
            if not candidate_set.planning_allowed:
                planning_allowed = False
            cs_gate = getattr(candidate_set, "safety_gate_state", NOT_AVAILABLE)
            if cs_gate and cs_gate != NOT_AVAILABLE:
                sg_state = cs_gate

        # --- Step 3: Collect direct triggers ---
        direct_reasons: List[ReplanningReasonCode] = []
        is_path_invalid = False

        # 3a. No active path
        if active_path.validity == ActivePathValidity.NOT_SET:
            direct_reasons.append(ReplanningReasonCode.NO_ACTIVE_PATH)
        # 3b. Stale path
        elif active_path.validity == ActivePathValidity.STALE:
            direct_reasons.append(ReplanningReasonCode.STALE_PLANNING_STATE)
        # 3c. Geometrically/contextually invalid
        elif active_path.validity == ActivePathValidity.INVALID:
            direct_reasons.append(ReplanningReasonCode.PATH_GEOMETRY_INVALID)
            is_path_invalid = True

        # 3d. Critical risk
        curr_risk = _finite(active_path.risk_score) or 0.0
        if curr_risk >= self._config.critical_risk_threshold:
            direct_reasons.append(ReplanningReasonCode.CRITICAL_PATH_RISK)

        # 3e. TTC critical
        if active_path.ttc_s is not None:
            ttc = _finite(active_path.ttc_s)
            if ttc is not None and ttc <= self._config.ttc_critical_threshold_s:
                direct_reasons.append(ReplanningReasonCode.TTC_DEGRADATION)

        # 3f. Dynamic blockage (critical objects present)
        if active_path.critical_object_ids:
            direct_reasons.append(ReplanningReasonCode.DYNAMIC_PATH_BLOCKAGE)

        # 3g. Stale input
        if risk_set is not None:
            age = now - risk_set.timestamp
            if age > self._config.max_input_age_s:
                direct_reasons.append(ReplanningReasonCode.STALE_PLANNING_STATE)

        # 3h. Safety gate explicitly blocks planning
        if not planning_allowed:
            direct_reasons.append(ReplanningReasonCode.SAFETY_GATE_CHANGE)

        # --- Step 4: Change detection from snapshots ---
        change_result = self._detector.detect(
            self._previous_snapshot, current_snap
        )

        # --- Step 5: Hysteresis for risk ---
        if curr_risk >= self._config.risk_hysteresis_trigger_threshold:
            self._high_risk_state = True
        elif curr_risk < self._config.risk_hysteresis_clear_threshold:
            self._high_risk_state = False

        # --- Step 6: Merge all reasons ---
        all_reasons = list(direct_reasons)
        for r in change_result.triggered_reasons:
            if r not in all_reasons:
                all_reasons.append(r)

        # --- Step 7: Determine urgency ---
        urgency = self._compute_urgency(all_reasons, curr_risk, active_path)

        # --- Step 8: Is replanning needed? ---
        is_critical = urgency == ReplanningUrgency.CRITICAL
        has_any_trigger = len(all_reasons) > 0
        is_invalid_path = is_path_invalid or (
            active_path.validity == ActivePathValidity.NOT_SET
        )

        # --- Step 9: Cooldown check ---
        cooldown_state = self._check_cooldown(now, is_critical)
        suppressed = (
            cooldown_state == CooldownState.ACTIVE
            and not is_critical
            and not is_invalid_path
        )

        # --- Step 10: Decision ---
        decision = self._compute_decision(
            has_any_trigger=has_any_trigger,
            is_invalid_path=is_invalid_path,
            is_critical=is_critical,
            suppressed=suppressed,
            planning_allowed=planning_allowed,
            active_path_validity=active_path.validity,
            degraded=active_path.validity == ActivePathValidity.DEGRADED,
        )

        # --- Step 11: Dominant reason (deterministic) ---
        dominant = self._dominant_reason(all_reasons)

        # --- Step 12: Deduplicate and sort reasons ---
        final_reasons = self._sort_reasons(all_reasons)

        # --- Step 13: Extract previous risk ---
        prev_risk = 0.0
        if self._previous_snapshot is not None:
            prev_risk = _finite(self._previous_snapshot.risk_score) or 0.0

        risk_delta = abs(curr_risk - prev_risk)

        # --- Step 14: Build request ID (deterministic) ---
        request_id = f"replan_f{frame_id:06d}_c{self._cycle_counter:08d}"

        # --- Step 15: Build ReplanningRequest ---
        all_critical_ids = tuple(sorted(set(
            list(active_path.critical_object_ids) +
            list(change_result.new_object_ids)
        )))

        request = ReplanningRequest(
            request_id=request_id,
            frame_id=frame_id,
            timestamp=now,
            active_candidate_id=active_path.candidate_id,
            decision=decision,
            urgency=urgency,
            dominant_reason=dominant,
            reason_codes=final_reasons,
            risk_delta=risk_delta,
            current_risk=curr_risk,
            previous_risk=prev_risk,
            critical_object_ids=all_critical_ids,
            changed_object_ids=change_result.changed_object_ids,
            new_object_ids=change_result.new_object_ids,
            safety_gate_state=sg_state,
            planning_allowed=planning_allowed,
            uncertainty=current_snap.uncertainty,
            degraded=active_path.validity == ActivePathValidity.DEGRADED,
            cooldown_state=cooldown_state,
            change_magnitudes=change_result.magnitudes,
        )

        # --- Step 16: Build context (only when replan triggered) ---
        context: Optional[ReplanningContext] = None
        if decision in (
            ReplanningDecision.REPLAN_REQUESTED,
            ReplanningDecision.REPLAN_REQUIRED,
            ReplanningDecision.DEGRADED_REPLAN,
        ):
            context_id = f"ctx_f{frame_id:06d}_c{self._cycle_counter:08d}"
            context = ReplanningContext(
                context_id=context_id,
                frame_id=frame_id,
                timestamp=now,
                request_id=request_id,
                active_path_state=active_path,
                previous_snapshot=self._previous_snapshot,
                urgency=urgency,
                dominant_reason=dominant,
                reason_codes=final_reasons,
                safety_gate_state=sg_state,
                planning_allowed=planning_allowed,
                critical_object_ids=all_critical_ids,
                changed_object_ids=change_result.changed_object_ids,
                new_object_ids=change_result.new_object_ids,
                current_risk=curr_risk,
                uncertainty=current_snap.uncertainty,
                degraded=active_path.validity == ActivePathValidity.DEGRADED,
            )
            # Update cooldown timestamp on triggered replan
            self._last_replan_time = now

        # --- Step 17: Store snapshot for next cycle ---
        self._previous_snapshot = current_snap

        processing_time = time.time() - t_start
        return ReplanningDecisionResult(
            request=request,
            context=context,
            active_path=active_path,
            processing_time_s=processing_time,
        )

    # -----------------------------------------------------------------------
    # Request candidate regeneration from Phase 9.2
    # -----------------------------------------------------------------------

    def request_candidate_regeneration(
        self,
        context: ReplanningContext,
        candidate_generator,  # CandidatePathGenerator instance from Phase 9.2
        planning_space: Optional[PlanningSpace] = None,
    ) -> Optional[CandidatePathSet]:
        """
        Request candidate regeneration from Phase 9.2.

        Phase 9.4 detects replanning is needed and calls the existing
        Phase 9.2 CandidatePathGenerator — it does NOT reimplement
        candidate generation.

        Returns the new CandidatePathSet, or None on failure.
        """
        if candidate_generator is None:
            return None
        if planning_space is None:
            return None
        try:
            return candidate_generator.generate(planning_space)
        except Exception:
            return None

    # -----------------------------------------------------------------------
    # Internal helpers
    # -----------------------------------------------------------------------

    def _compute_urgency(
        self,
        reasons: List[ReplanningReasonCode],
        curr_risk: float,
        active_path: ActivePath,
    ) -> ReplanningUrgency:
        """Determine urgency from active reasons and risk level."""
        reason_set = set(reasons)

        if reason_set & _URGENCY_CRITICAL_REASONS:
            return ReplanningUrgency.CRITICAL
        if curr_risk >= self._config.critical_risk_threshold:
            return ReplanningUrgency.CRITICAL
        if active_path.validity == ActivePathValidity.INVALID:
            return ReplanningUrgency.CRITICAL
        if reason_set & _URGENCY_URGENT_REASONS:
            return ReplanningUrgency.URGENT
        if self._high_risk_state:
            return ReplanningUrgency.URGENT
        if reason_set & _URGENCY_ELEVATED_REASONS:
            return ReplanningUrgency.ELEVATED
        if reasons:
            return ReplanningUrgency.ELEVATED
        return ReplanningUrgency.NORMAL

    def _compute_decision(
        self,
        has_any_trigger: bool,
        is_invalid_path: bool,
        is_critical: bool,
        suppressed: bool,
        planning_allowed: bool,
        active_path_validity: ActivePathValidity,
        degraded: bool,
    ) -> ReplanningDecision:
        """Compute top-level replanning decision.

        Priority order:
          1. UNKNOWN — no active path at all.
          2. NO_REPLAN — no triggers detected.
          3. REPLAN_BLOCKED — safety gate does not allow planning (never overridden).
          4. REPLAN_REQUIRED — path is geometrically invalid or critically unsafe.
          5. NO_REPLAN — cooldown suppresses non-critical request.
          6. DEGRADED_REPLAN — inputs are degraded.
          7. REPLAN_REQUESTED — normal meaningful-change trigger.
        """
        # 1. No active path
        if active_path_validity == ActivePathValidity.NOT_SET:
            return ReplanningDecision.UNKNOWN

        # 2. No triggers
        if not has_any_trigger:
            return ReplanningDecision.NO_REPLAN

        # 3. Safety gate blocks planning — must not be overridden
        if not planning_allowed:
            return ReplanningDecision.REPLAN_BLOCKED

        # 4. Mandatory replan
        if is_invalid_path or is_critical:
            if degraded:
                return ReplanningDecision.DEGRADED_REPLAN
            return ReplanningDecision.REPLAN_REQUIRED

        # 5. Cooldown suppression (non-critical)
        if suppressed:
            return ReplanningDecision.NO_REPLAN

        # 6. Degraded inputs
        if degraded:
            return ReplanningDecision.DEGRADED_REPLAN

        # 7. Normal replan
        return ReplanningDecision.REPLAN_REQUESTED

    def _dominant_reason(
        self,
        reasons: List[ReplanningReasonCode],
    ) -> ReplanningReasonCode:
        """Select the dominant reason code deterministically by priority."""
        if not reasons:
            return ReplanningReasonCode.NO_ACTIVE_PATH
        return max(reasons, key=lambda r: _REASON_PRIORITY.get(r, 0))

    def _sort_reasons(
        self,
        reasons: List[ReplanningReasonCode],
    ) -> Tuple[ReplanningReasonCode, ...]:
        """Deduplicate and sort reason codes deterministically."""
        seen: Set[ReplanningReasonCode] = set()
        unique: List[ReplanningReasonCode] = []
        for r in reasons:
            if r not in seen:
                seen.add(r)
                unique.append(r)
        # Sort: highest priority first, then alphabetical for ties
        unique.sort(
            key=lambda r: (-_REASON_PRIORITY.get(r, 0), r.value)
        )
        return tuple(unique)

    def _check_cooldown(
        self,
        now: float,
        is_critical: bool,
    ) -> CooldownState:
        """Check and return the current cooldown state."""
        elapsed = now - self._last_replan_time
        in_cooldown = elapsed < self._config.cooldown_interval_s

        if not in_cooldown:
            return CooldownState.INACTIVE
        if is_critical and self._config.critical_bypasses_cooldown:
            return CooldownState.CRITICAL_BYPASS
        return CooldownState.ACTIVE
