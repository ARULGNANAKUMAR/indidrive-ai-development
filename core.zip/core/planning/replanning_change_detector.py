"""
IndiDrive AI — Phase 9.4 | Change Detector
===========================================
Deterministic comparison of two PlanningStateSnapshots to identify
meaningful changes that may warrant replanning.

Responsibilities:
  - Compare previous and current planning state snapshots.
  - Compute change magnitudes.
  - Identify which trigger categories fire.
  - Remain strictly deterministic (same inputs → same outputs).
  - Apply configurable thresholds.
  - Avoid triggering on numerical noise.

This module does NOT:
  - Generate candidate paths.
  - Score candidates.
  - Issue vehicle commands.
  - Select a path.
"""
from __future__ import annotations

import math
from typing import Dict, List, Optional, Set, Tuple

from .replanning_types import (
    NOT_AVAILABLE,
    ChangeMagnitudes,
    PlanningStateSnapshot,
    ReplanningReasonCode,
)
from .replanning_config import ReplanningConfig
from .active_path_monitor import _finite

__all__ = ["ChangeDetector", "ChangeDetectionResult"]


class ChangeDetectionResult:
    """Result of comparing two planning state snapshots.

    Fields
    ------
    triggered_reasons   : sorted tuple of detected reason codes.
    magnitudes          : quantified change magnitudes.
    new_object_ids      : IDs of newly appeared relevant objects.
    disappeared_ids     : IDs of objects that left the scene.
    changed_object_ids  : IDs of objects with significant state change.
    """

    def __init__(
        self,
        triggered_reasons: Tuple[ReplanningReasonCode, ...],
        magnitudes: ChangeMagnitudes,
        new_object_ids: Tuple[str, ...],
        disappeared_ids: Tuple[str, ...],
        changed_object_ids: Tuple[str, ...],
    ) -> None:
        self.triggered_reasons = triggered_reasons
        self.magnitudes = magnitudes
        self.new_object_ids = new_object_ids
        self.disappeared_ids = disappeared_ids
        self.changed_object_ids = changed_object_ids

    @property
    def has_triggers(self) -> bool:
        return len(self.triggered_reasons) > 0

    def to_dict(self) -> dict:
        return {
            "triggered_reasons": [r.value for r in self.triggered_reasons],
            "magnitudes": self.magnitudes.to_dict(),
            "new_object_ids": list(self.new_object_ids),
            "disappeared_ids": list(self.disappeared_ids),
            "changed_object_ids": list(self.changed_object_ids),
        }


class ChangeDetector:
    """
    Deterministic change detector for the Adaptive Replanning Engine.

    Compares two PlanningStateSnapshots and determines which
    trigger categories fire, along with change magnitudes.

    All comparisons use configured thresholds — no magic numbers.
    """

    def __init__(self, config: Optional[ReplanningConfig] = None) -> None:
        self._config = config or ReplanningConfig()

    def detect(
        self,
        previous: Optional[PlanningStateSnapshot],
        current: PlanningStateSnapshot,
    ) -> ChangeDetectionResult:
        """Compare previous and current snapshots, returning triggered reasons.

        If previous is None, any active state is treated as a first-cycle
        baseline — no triggers fire from the comparison itself.
        """
        reasons: List[ReplanningReasonCode] = []
        magnitudes = ChangeMagnitudes()
        new_ids: List[str] = []
        disappeared_ids: List[str] = []
        changed_ids: List[str] = []

        if previous is None:
            # First cycle — no delta available
            return ChangeDetectionResult(
                triggered_reasons=(),
                magnitudes=magnitudes,
                new_object_ids=(),
                disappeared_ids=(),
                changed_object_ids=(),
            )

        cfg = self._config

        # ---------------------------------------------------------------
        # 1. Risk change detection
        # ---------------------------------------------------------------
        prev_risk = _finite(previous.risk_score) or 0.0
        curr_risk = _finite(current.risk_score) or 0.0
        risk_delta = abs(curr_risk - prev_risk)
        magnitudes.risk_delta = risk_delta

        # Remove noise
        if risk_delta >= cfg.risk_noise_floor:
            if curr_risk > prev_risk:
                # Escalation
                if risk_delta >= cfg.risk_escalation_delta_threshold:
                    reasons.append(ReplanningReasonCode.RISK_ESCALATION)
            else:
                # De-escalation
                if cfg.risk_deescalation_replan and risk_delta >= cfg.risk_escalation_delta_threshold:
                    reasons.append(ReplanningReasonCode.RISK_ESCALATION)

        # ---------------------------------------------------------------
        # 2. TTC change detection
        # ---------------------------------------------------------------
        prev_ttc = previous.ttc_s
        curr_ttc = current.ttc_s

        if curr_ttc is not None and prev_ttc is not None:
            ttc_delta = prev_ttc - curr_ttc  # positive = TTC decreased (worse)
            magnitudes.ttc_delta_s = ttc_delta
            if ttc_delta >= cfg.ttc_delta_threshold_s:
                reasons.append(ReplanningReasonCode.TTC_DEGRADATION)
        elif curr_ttc is not None and curr_ttc < cfg.ttc_critical_threshold_s:
            # First time TTC appears and it's already critical
            magnitudes.ttc_delta_s = None
            reasons.append(ReplanningReasonCode.TTC_DEGRADATION)

        # ---------------------------------------------------------------
        # 3. Object set change detection
        # ---------------------------------------------------------------
        prev_ids: Set[str] = set(previous.object_ids)
        curr_ids: Set[str] = set(current.object_ids)

        appeared = sorted(curr_ids - prev_ids)
        vanished = sorted(prev_ids - curr_ids)

        magnitudes.new_object_count = len(appeared)
        magnitudes.disappeared_object_count = len(vanished)

        if appeared:
            new_ids = list(appeared)
            reasons.append(ReplanningReasonCode.NEW_RELEVANT_OBJECT)

        if vanished:
            disappeared_ids = list(vanished)
            if cfg.replan_on_hazard_cleared:
                reasons.append(ReplanningReasonCode.HAZARD_CLEARED)

        # ---------------------------------------------------------------
        # 4. Object position / velocity changes
        # ---------------------------------------------------------------
        prev_pos: Dict[str, Tuple[float, float]] = {
            oid: (x, y) for oid, x, y in previous.object_positions
        }
        curr_pos: Dict[str, Tuple[float, float]] = {
            oid: (x, y) for oid, x, y in current.object_positions
        }
        prev_vel: Dict[str, float] = {
            oid: v for oid, v in previous.object_velocities
        }
        curr_vel: Dict[str, float] = {
            oid: v for oid, v in current.object_velocities
        }

        max_pos_delta: Optional[float] = None
        max_vel_delta: Optional[float] = None
        prediction_changed = False

        common_ids = sorted(prev_ids & curr_ids)
        for oid in common_ids:
            if oid in prev_pos and oid in curr_pos:
                px, py = prev_pos[oid]
                cx, cy = curr_pos[oid]
                pos_d = math.sqrt((cx - px) ** 2 + (cy - py) ** 2)
                if max_pos_delta is None or pos_d > max_pos_delta:
                    max_pos_delta = pos_d
                if pos_d >= cfg.object_position_delta_threshold_m:
                    if oid not in changed_ids:
                        changed_ids.append(oid)
                    if pos_d >= cfg.trajectory_deviation_threshold_m:
                        prediction_changed = True

            if oid in prev_vel and oid in curr_vel:
                pv = prev_vel[oid]
                cv = curr_vel[oid]
                vel_d = abs(cv - pv)
                if max_vel_delta is None or vel_d > max_vel_delta:
                    max_vel_delta = vel_d
                if vel_d >= cfg.object_velocity_delta_threshold:
                    if oid not in changed_ids:
                        changed_ids.append(oid)
                    prediction_changed = True

        magnitudes.max_position_delta_m = max_pos_delta
        magnitudes.max_velocity_delta = max_vel_delta

        if prediction_changed:
            reasons.append(ReplanningReasonCode.PREDICTION_CHANGE)

        # ---------------------------------------------------------------
        # 5. Road structure / drivable region change
        # ---------------------------------------------------------------
        prev_width = _finite(previous.drivable_width_m) or 0.0
        curr_width = _finite(current.drivable_width_m) or 0.0
        width_delta = abs(curr_width - prev_width)
        magnitudes.drivable_width_delta_m = width_delta

        if width_delta >= cfg.drivable_width_delta_threshold_m:
            reasons.append(ReplanningReasonCode.DRIVABLE_REGION_CHANGE)

        # ---------------------------------------------------------------
        # 6. Road anomaly change
        # ---------------------------------------------------------------
        if current.has_road_anomaly and not previous.has_road_anomaly:
            reasons.append(ReplanningReasonCode.ROAD_ANOMALY_CHANGE)

        # ---------------------------------------------------------------
        # 7. Safety gate state change
        # ---------------------------------------------------------------
        if (previous.safety_gate_state != current.safety_gate_state
                and current.safety_gate_state != NOT_AVAILABLE):
            if current.safety_gate_state in self._config.safety_gate_replan_states:
                reasons.append(ReplanningReasonCode.SAFETY_GATE_CHANGE)

        if not previous.planning_allowed and current.planning_allowed:
            # Planning became allowed — context change
            reasons.append(ReplanningReasonCode.PLANNING_CONTEXT_CHANGE)
        elif previous.planning_allowed and not current.planning_allowed:
            reasons.append(ReplanningReasonCode.SAFETY_GATE_CHANGE)

        # ---------------------------------------------------------------
        # 8. Uncertainty escalation
        # ---------------------------------------------------------------
        curr_unc = _finite(current.uncertainty) or 0.0
        prev_unc = _finite(previous.uncertainty) or 0.0
        unc_delta = curr_unc - prev_unc
        magnitudes.uncertainty_delta = unc_delta
        if curr_unc >= cfg.uncertainty_escalation_threshold and unc_delta > 0:
            reasons.append(ReplanningReasonCode.UNCERTAINTY_ESCALATION)

        # ---------------------------------------------------------------
        # Deduplicate and sort reasons deterministically
        # ---------------------------------------------------------------
        seen: Set[ReplanningReasonCode] = set()
        unique_reasons: List[ReplanningReasonCode] = []
        for r in reasons:
            if r not in seen:
                seen.add(r)
                unique_reasons.append(r)
        unique_reasons.sort(key=lambda r: r.value)

        return ChangeDetectionResult(
            triggered_reasons=tuple(unique_reasons),
            magnitudes=magnitudes,
            new_object_ids=tuple(sorted(new_ids)),
            disappeared_ids=tuple(sorted(disappeared_ids)),
            changed_object_ids=tuple(sorted(changed_ids)),
        )
