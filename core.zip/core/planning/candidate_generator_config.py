"""
IndiDrive AI — Phase 9.2 | Candidate Generator Configuration
=============================================================
All configurable thresholds and limits for Phase 9.2 Candidate Path Generation.
No magic numbers are embedded in the generator — every configurable value
lives here with a documented default.

Conventions follow Phase 9.1 PlanningSpaceConfig pattern.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Optional

import yaml

__all__ = [
    "CandidateGeneratorConfig",
    "load_candidate_generator_config",
]

CONFIG_VERSION = "9.2"

# Default config section name inside the YAML file
_YAML_SECTION = "phase_9_2"


@dataclass
class CandidateGeneratorConfig:
    """
    Configuration for Phase 9.2 Candidate Path Generator.

    All defaults are chosen conservatively for Indian-road conditions.
    """

    # --- Enable / disable ---
    enabled: bool = True

    # --- Candidate count ---
    max_candidates: int = 5
    """Maximum total candidate paths to return.
    Default 5: center + 2 slight + 2 moderate alternatives.
    """

    # --- Sampling resolution ---
    sample_resolution_m: float = 2.0
    """Distance between consecutive path waypoints (metres).
    Default 2.0 m gives ~25 waypoints over a 50 m horizon.
    Smaller → more detailed but more computation.
    Larger → coarser but faster.
    """

    # --- Lateral offsets ---
    lateral_offsets_m: List[float] = field(
        default_factory=lambda: [0.0, 0.75, -0.75, 1.5, -1.5]
    )
    """Nominal lateral offsets from the reference centreline (metres).
    Positive = left (+Y), negative = right (-Y).
    Default set: center, slight-left, slight-right, moderate-left, moderate-right.
    Actual offsets are clipped to the available boundary at generation time.
    """

    # --- Path length limits ---
    minimum_path_length_m: float = 5.0
    """Minimum required path length to be considered a valid candidate.
    Candidates shorter than this are rejected.
    """

    maximum_path_length_m: float = 60.0
    """Maximum path length cap (metres).
    Clips the generated path to this even if the horizon is longer.
    """

    # --- Waypoint limits ---
    min_waypoints: int = 3
    """Minimum waypoints for a valid candidate path."""

    max_waypoints: int = 150
    """Maximum waypoints stored per candidate (hard cap)."""

    # --- Vehicle geometry (for boundary margin) ---
    vehicle_half_width_m: float = 1.0
    """Approximate half-width of the vehicle (metres).
    Used to ensure candidates have at least this clearance from boundaries.
    Default 1.0 m provides a 1 m margin on each side.
    """

    # --- Geometric continuity ---
    max_lateral_jump_m: float = 1.0
    """Maximum allowed lateral jump between consecutive waypoints (metres).
    A jump larger than this triggers a PARTIALLY_VALID / INVALID geometric flag.
    """

    # --- Boundary checks ---
    boundary_check_enabled: bool = True
    """Whether to validate candidate paths against known road boundaries."""

    drivable_space_check_enabled: bool = True
    """Whether to validate candidate paths against drivable / restricted regions."""

    # --- Determinism ---
    deterministic: bool = True
    """Guarantee stable ordering of all output collections."""

    @classmethod
    def from_dict(cls, data: dict) -> "CandidateGeneratorConfig":
        """Create from a dict, ignoring unknown keys (forward-compatible)."""
        known = {f for f in cls.__dataclass_fields__}  # type: ignore[attr-defined]
        filtered: dict = {}
        for k, v in data.items():
            if k not in known:
                continue
            if k == "lateral_offsets_m":
                # Ensure it is a list of floats
                try:
                    filtered[k] = [float(x) for x in (v or [])]
                except (TypeError, ValueError):
                    pass
            else:
                filtered[k] = v
        return cls(**filtered)

    def to_dict(self) -> dict:
        return {
            "config_version": CONFIG_VERSION,
            "enabled": self.enabled,
            "max_candidates": self.max_candidates,
            "sample_resolution_m": self.sample_resolution_m,
            "lateral_offsets_m": list(self.lateral_offsets_m),
            "minimum_path_length_m": self.minimum_path_length_m,
            "maximum_path_length_m": self.maximum_path_length_m,
            "min_waypoints": self.min_waypoints,
            "max_waypoints": self.max_waypoints,
            "vehicle_half_width_m": self.vehicle_half_width_m,
            "max_lateral_jump_m": self.max_lateral_jump_m,
            "boundary_check_enabled": self.boundary_check_enabled,
            "drivable_space_check_enabled": self.drivable_space_check_enabled,
            "deterministic": self.deterministic,
        }


def load_candidate_generator_config(
    config_path: Optional[Path] = None,
) -> CandidateGeneratorConfig:
    """Load CandidateGeneratorConfig from a YAML file.

    Falls back to safe defaults if the file is absent or the
    `phase_9_2` section is missing.
    """
    if config_path is None:
        # Locate default config relative to this file
        config_path = (
            Path(__file__).resolve().parent.parent.parent
            / "config"
            / "planner_config.yaml"
        )

    if not config_path.exists():
        return CandidateGeneratorConfig()

    try:
        with open(config_path, "r", encoding="utf-8") as fh:
            raw = yaml.safe_load(fh) or {}
        section = raw.get(_YAML_SECTION, {})
        if not section:
            return CandidateGeneratorConfig()
        return CandidateGeneratorConfig.from_dict(section)
    except Exception:
        # Never crash the pipeline on a config read error — use defaults.
        return CandidateGeneratorConfig()
