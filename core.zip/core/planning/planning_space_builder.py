"""
IndiDrive AI — Phase 9.1 | Planning Space Builder
==================================================
Converts upstream Phase 7 WorldModelSnapshot and Phase 8.4 PlanningContext
into a structured PlanningSpace.

Module flow (Section 36 of spec):
    PlanningInput
    ↓ Input Validation
    ↓ World Model Projection
    ↓ Road Space Projection
    ↓ Static Restriction Projection
    ↓ Dynamic Restriction Projection
    ↓ Safety Constraint Projection
    ↓ Uncertainty / Degradation Propagation
    ↓ Planning Space Construction
    ↓ Planning Space Validation
    ↓ Immutable Planning Snapshot

Design rules:
  * stateless — no global mutable state
  * deterministic — stable ordering everywhere
  * partial availability — produces best safe partial output
  * no path generation, no path scoring
  * no maneuver selection
  * consumes upstream outputs only — no new estimation
"""
from __future__ import annotations

import math
import time
import uuid
from typing import List, Optional, Tuple

from .planning_space_config import PlanningSpaceConfig
from .planning_space_types import (
    NOT_AVAILABLE,
    PLANNING_SPACE_SCHEMA_VERSION,
    BoundarySegment,
    CoordinateFrameInfo,
    DrivableState,
    DynamicObjectEntry,
    EvidenceClass,
    IndianRoadContextSummary,
    OccupancyState,
    PlanningHorizon,
    PlanningHorizonValidity,
    PlanningRegion,
    PlanningSpace,
    PlanningSpaceQuality,
    PlanningSpaceStatus,
    RegionKind,
    RestrictionKind,
    RoadStructureSummary,
    SafetyConstraintSummary,
    SpatialExtent,
    StaticHazardEntry,
)
from .planning_input_types import PlanningInput, PlanningInputValidationResult
from .planning_snapshot import PlanningSnapshot
from .planning_space_validator import PlanningSpaceValidator

__all__ = [
    "PlanningSpaceBuilder",
]

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _safe_float(v, default: float = 0.0) -> float:
    try:
        f = float(v)
        return f if math.isfinite(f) else default
    except (TypeError, ValueError):
        return default


def _evidence_from_str(s: str) -> EvidenceClass:
    """Map a string evidence label to EvidenceClass."""
    mapping = {
        "OBSERVED": EvidenceClass.OBSERVED,
        "INFERRED": EvidenceClass.INFERRED,
        "PREDICTED": EvidenceClass.PREDICTED,
        "COMBINED": EvidenceClass.COMBINED,
        "MIXED": EvidenceClass.COMBINED,
    }
    return mapping.get(str(s).upper(), EvidenceClass.UNKNOWN)


def _drivable_state_from_world(
    drivable_space,
    config: PlanningSpaceConfig,
) -> DrivableState:
    """Derive drivable state from WorldDrivableSpaceInfo."""
    if drivable_space is None or not drivable_space.available:
        return DrivableState.UNKNOWN
    if drivable_space.is_degraded:
        return DrivableState.DEGRADED
    conf = _safe_float(drivable_space.free_space_confidence)
    if conf >= config.min_confidence_for_drivable:
        return DrivableState.DRIVABLE
    return DrivableState.UNCERTAIN


def _short_uid(prefix: str, index: int) -> str:
    return f"{prefix}_{index:04d}"


# ---------------------------------------------------------------------------
# Builder
# ---------------------------------------------------------------------------

class PlanningSpaceBuilder:
    """
    Stateless deterministic builder for PlanningSpace.

    Usage:
        builder = PlanningSpaceBuilder(config)
        snapshot = builder.build(planning_input)
    """

    def __init__(self, config: Optional[PlanningSpaceConfig] = None) -> None:
        self._config = config or PlanningSpaceConfig()
        self._validator = PlanningSpaceValidator()

    # ------------------------------------------------------------------
    # Public build entry point
    # ------------------------------------------------------------------

    def build(self, inp: PlanningInput) -> PlanningSnapshot:
        """Build and validate a PlanningSpace from a PlanningInput.

        Always returns a PlanningSnapshot — never raises.
        If the input is critically invalid, returns a skeleton INVALID snapshot.

        Args:
            inp: PlanningInput carrying WorldModelSnapshot and PlanningContext.

        Returns:
            PlanningSnapshot with the constructed PlanningSpace.
        """
        t_start = time.monotonic()

        # --- Step 1: Input validation ---
        input_validation = self._validator.validate_input(inp)
        if not input_validation.is_valid:
            return self._make_invalid_snapshot(
                inp, input_validation, time.monotonic() - t_start
            )

        # --- Step 2: Extract upstream objects ---
        wm = inp.world_model_snapshot   # WorldModelSnapshot or None
        pc = inp.planning_context       # PlanningContext or None

        # --- Step 3: Build horizon ---
        horizon = self._build_horizon(wm)

        # --- Step 4: World model projection — road space ---
        spatial_extent, road_structure, indian_context = self._project_road_space(wm)

        # --- Step 5: Static restriction projection ---
        static_hazards = self._project_static_hazards(wm)

        # --- Step 6: Dynamic restriction projection ---
        dynamic_objects = self._project_dynamic_objects(wm)

        # --- Step 7: Safety constraint projection ---
        hard_constraints, soft_constraints = self._project_safety_constraints(pc)

        # --- Step 8: Drivable / non-drivable / restricted regions ---
        drivable_regions, non_drivable_regions, restricted_regions = (
            self._build_regions(wm, pc, spatial_extent, static_hazards, dynamic_objects)
        )

        # --- Step 9: Safety gate passthrough ---
        gate_state, planning_allowed, planning_mode = self._extract_gate_info(pc)

        # --- Step 10: Quality / uncertainty propagation ---
        quality = self._compute_quality(wm, pc)

        # --- Step 11: Overall status ---
        status = self._compute_status(quality, gate_state, planning_allowed)

        # --- Step 12: Assemble PlanningSpace ---
        space = PlanningSpace(
            schema_version=PLANNING_SPACE_SCHEMA_VERSION,
            space_id=f"ps_{inp.frame_id}_{int(inp.timestamp * 1000) % 1_000_000}",
            timestamp=inp.timestamp,
            frame_id=inp.frame_id,
            coordinate_frame=CoordinateFrameInfo(),
            status=status,
            horizon=horizon,
            spatial_extent=spatial_extent,
            road_structure=road_structure,
            indian_road_context=indian_context,
            _drivable_regions=tuple(drivable_regions),
            _non_drivable_regions=tuple(non_drivable_regions),
            _restricted_regions=tuple(restricted_regions),
            _dynamic_objects=tuple(dynamic_objects),
            _static_hazards=tuple(static_hazards),
            _hard_constraints=tuple(hard_constraints),
            _soft_constraints=tuple(soft_constraints),
            safety_gate_state=gate_state,
            planning_allowed=planning_allowed,
            planning_mode=planning_mode,
            quality=quality,
        )

        # --- Step 13: Validate output ---
        validation = self._validator.validate(space)

        build_dur = time.monotonic() - t_start
        return PlanningSnapshot(
            space=space,
            validation=validation,
            build_duration_s=build_dur,
            snapshot_id=f"snap_{inp.frame_id}_{int(inp.timestamp * 1000) % 1_000_000}",
            timestamp=inp.timestamp,
        )

    # ------------------------------------------------------------------
    # Horizon
    # ------------------------------------------------------------------

    def _build_horizon(self, wm) -> PlanningHorizon:
        cfg = self._config
        # Check if World Model is degraded / partial
        if wm is not None:
            try:
                wm_status = str(wm.status.value)
                if wm_status in ("DEGRADED", "EMPTY", "INVALID"):
                    return PlanningHorizon(
                        longitudinal_m=cfg.planning_horizon_m,
                        lateral_extent_m=cfg.lateral_extent_m,
                        temporal_horizon_s=cfg.temporal_horizon_s,
                        validity=PlanningHorizonValidity.DEGRADED,
                        source="config_degraded",
                    )
            except Exception:
                pass

        return PlanningHorizon(
            longitudinal_m=cfg.planning_horizon_m,
            lateral_extent_m=cfg.lateral_extent_m,
            temporal_horizon_s=cfg.temporal_horizon_s,
            validity=PlanningHorizonValidity.VALID,
            source="config",
        )

    # ------------------------------------------------------------------
    # Road space projection
    # ------------------------------------------------------------------

    def _project_road_space(
        self, wm
    ) -> Tuple[SpatialExtent, RoadStructureSummary, IndianRoadContextSummary]:
        """Project Phase 7 road representation into planning-space structures."""
        if wm is None:
            return (
                SpatialExtent(),
                RoadStructureSummary(),
                IndianRoadContextSummary(),
            )

        road = getattr(wm, "road", None)
        spatial = self._project_spatial_extent(road)
        road_struct = self._project_road_structure(road)
        indian = self._project_indian_context(getattr(wm, "indian_context", None))
        return spatial, road_struct, indian

    def _project_spatial_extent(self, road) -> SpatialExtent:
        if road is None:
            return SpatialExtent()

        ds = getattr(road, "drivable_space", None)
        if ds is None or not getattr(ds, "available", False):
            return SpatialExtent()

        cfg = self._config
        left_pts = self._convert_boundary_points(
            getattr(getattr(ds, "left_boundary", None), "points", [])
        )
        right_pts = self._convert_boundary_points(
            getattr(getattr(ds, "right_boundary", None), "points", [])
        )

        left_avail = getattr(getattr(ds, "left_boundary", None), "available", False)
        right_avail = getattr(getattr(ds, "right_boundary", None), "available", False)

        # Estimate lateral positions from boundary points
        left_y = None
        right_y = None
        if left_avail and left_pts:
            ys = [p.y for p in left_pts if math.isfinite(p.y)]
            left_y = sum(ys) / len(ys) if ys else None
        if right_avail and right_pts:
            ys = [p.y for p in right_pts if math.isfinite(p.y)]
            right_y = sum(ys) / len(ys) if ys else None

        road_width = getattr(ds, "road_width_m", None)
        if road_width is not None and not math.isfinite(_safe_float(road_width)):
            road_width = None

        return SpatialExtent(
            forward_m=cfg.planning_horizon_m,
            left_m=left_y,
            right_m=right_y,
            road_width_m=_safe_float(road_width) if road_width is not None else None,
            left_boundary_available=bool(left_avail),
            right_boundary_available=bool(right_avail),
            left_boundary=tuple(left_pts[: cfg.max_boundary_points]),
            right_boundary=tuple(right_pts[: cfg.max_boundary_points]),
        )

    def _convert_boundary_points(self, points) -> List[BoundarySegment]:
        result = []
        for p in (points or []):
            try:
                x = _safe_float(getattr(p, "x", None))
                y = _safe_float(getattr(p, "y", None))
                conf = _safe_float(getattr(p, "confidence", 0.0))
                result.append(BoundarySegment(
                    x=x, y=y, confidence=conf, evidence=EvidenceClass.OBSERVED
                ))
            except Exception:
                continue
        if self._config.deterministic:
            result.sort(key=lambda b: (b.x, b.y))
        return result

    def _project_road_structure(self, road) -> RoadStructureSummary:
        if road is None:
            return RoadStructureSummary()

        li = getattr(road, "lane_info", None)
        if li is None or not getattr(li, "available", False):
            return RoadStructureSummary(
                lane_info_available=False,
                is_degraded=True,
            )

        ovi_raw = getattr(li, "observed_vs_inferred", "UNKNOWN")
        ovi = _evidence_from_str(str(ovi_raw))

        return RoadStructureSummary(
            marking_state=str(getattr(li, "marking_state", NOT_AVAILABLE)),
            lane_count=getattr(li, "lane_count", None),
            lane_width_m=getattr(li, "lane_width_m", None),
            road_direction=str(getattr(li, "road_direction", NOT_AVAILABLE)),
            intersection_state=str(getattr(li, "intersection_state", NOT_AVAILABLE)),
            curvature_summary=str(getattr(li, "curvature_summary", NOT_AVAILABLE)),
            lane_info_available=True,
            observed_vs_inferred=ovi,
            confidence=_safe_float(getattr(li, "lane_confidence", 0.0)),
            uncertainty=_safe_float(getattr(li, "lane_uncertainty", 1.0), default=1.0),
            is_degraded=bool(getattr(li, "is_degraded", False)),
        )

    def _project_indian_context(self, ic) -> IndianRoadContextSummary:
        if ic is None or not getattr(ic, "available", False):
            return IndianRoadContextSummary()
        return IndianRoadContextSummary(
            available=True,
            road_type=str(getattr(ic, "road_type", NOT_AVAILABLE)),
            traffic_density=str(getattr(ic, "traffic_density", NOT_AVAILABLE)),
            vulnerable_road_users=bool(getattr(ic, "vulnerable_road_users", False)),
            cattle_present=bool(getattr(ic, "cattle_present", False)),
            roadside_activity=str(getattr(ic, "roadside_activity", NOT_AVAILABLE)),
            market_like_activity=bool(getattr(ic, "market_like_activity", False)),
            intersection_context=str(getattr(ic, "intersection_context", NOT_AVAILABLE)),
            road_complexity=str(getattr(ic, "road_complexity", NOT_AVAILABLE)),
            context_confidence=_safe_float(getattr(ic, "context_confidence", 0.0)),
            context_uncertainty=_safe_float(getattr(ic, "context_uncertainty", 1.0), 1.0),
            is_degraded=bool(getattr(ic, "is_degraded", True)),
        )

    # ------------------------------------------------------------------
    # Static hazard projection
    # ------------------------------------------------------------------

    def _project_static_hazards(self, wm) -> List[StaticHazardEntry]:
        if wm is None:
            return []

        road = getattr(wm, "road", None)
        if road is None:
            return []

        anomalies = getattr(road, "anomalies", []) or []
        result: List[StaticHazardEntry] = []

        for i, a in enumerate(anomalies[: self._config.max_static_hazards]):
            try:
                result.append(StaticHazardEntry(
                    hazard_id=str(getattr(a, "anomaly_id", _short_uid("hz", i))),
                    hazard_type=str(getattr(a, "anomaly_type", NOT_AVAILABLE)),
                    position_x=getattr(a, "position_x", None),
                    position_y=getattr(a, "position_y", None),
                    approx_width_m=getattr(a, "approximate_width_m", None),
                    approx_length_m=getattr(a, "approximate_length_m", None),
                    severity=str(getattr(a, "severity", NOT_AVAILABLE)),
                    drivability_impact=str(getattr(a, "drivability_impact", NOT_AVAILABLE)),
                    confidence=_safe_float(getattr(a, "confidence", 0.0)),
                    uncertainty=_safe_float(getattr(a, "uncertainty", 1.0), 1.0),
                    evidence=EvidenceClass.OBSERVED,
                    in_drivable_area=bool(getattr(a, "in_drivable_area", False)),
                ))
            except Exception:
                continue

        if self._config.deterministic:
            result.sort(key=lambda h: h.hazard_id)
        return result

    # ------------------------------------------------------------------
    # Dynamic object projection
    # ------------------------------------------------------------------

    def _project_dynamic_objects(self, wm) -> List[DynamicObjectEntry]:
        if wm is None:
            return []

        objects = getattr(wm, "objects", ()) or ()
        result: List[DynamicObjectEntry] = []

        for i, obj in enumerate(objects[: self._config.max_dynamic_objects]):
            try:
                obj_id = str(getattr(obj, "object_id", _short_uid("obj", i)))
                obj_type = str(getattr(obj, "object_type", NOT_AVAILABLE))

                # Position from WorldObjectPosition
                pos = getattr(obj, "position", None)
                px = getattr(pos, "x", None) if pos else None
                py = getattr(pos, "y", None) if pos else None

                # Velocity from WorldObjectMotionSummary
                motion = getattr(obj, "motion", None)
                vx = getattr(motion, "vx", None) if motion else None
                vy = getattr(motion, "vy", None) if motion else None

                # Prediction summary
                pred = getattr(obj, "prediction", None)
                pred_avail = (
                    pred is not None
                    and str(getattr(pred, "availability", "NONE")) not in ("NONE", "INVALID")
                )

                pred_x = pred_y = None
                if pred_avail:
                    pred_x = getattr(pred, "most_likely_endpoint_x", None)
                    pred_y = getattr(pred, "most_likely_endpoint_y", None)

                # Quality
                quality = getattr(obj, "quality", None)
                conf = _safe_float(getattr(quality, "confidence", 0.0) if quality else 0.0)
                unc = _safe_float(getattr(quality, "uncertainty", 1.0) if quality else 1.0, 1.0)

                # Observation state → evidence
                obs_state = str(getattr(obj, "observation_state", "UNKNOWN"))
                if obs_state == "OBSERVED":
                    ev = EvidenceClass.OBSERVED
                elif obs_state == "PREDICTED":
                    ev = EvidenceClass.PREDICTED
                elif obs_state in ("TRACKED", "PARTIALLY_OBSERVED"):
                    ev = EvidenceClass.COMBINED
                else:
                    ev = EvidenceClass.UNKNOWN

                # Approximate bounding box from dimensions
                dims = getattr(obj, "dimensions", None)
                dw = _safe_float(getattr(dims, "width_m", None) or 0.0)
                dl = _safe_float(getattr(dims, "length_m", None) or 0.0)
                ax_min = ax_max = ay_min = ay_max = None
                if px is not None and py is not None and (dl > 0 or dw > 0):
                    ax_min = _safe_float(px) - dl / 2
                    ax_max = _safe_float(px) + dl / 2
                    ay_min = _safe_float(py) - dw / 2
                    ay_max = _safe_float(py) + dw / 2

                entry = DynamicObjectEntry(
                    object_id=obj_id,
                    object_type=obj_type,
                    position_x=px,
                    position_y=py,
                    velocity_x=vx,
                    velocity_y=vy,
                    predicted_position_x=pred_x,
                    predicted_position_y=pred_y,
                    confidence=conf,
                    uncertainty=unc,
                    evidence=ev,
                    prediction_available=pred_avail,
                    time_valid_s=_safe_float(
                        getattr(pred, "prediction_horizon_s", None) or 0.0
                    ) or None,
                    affected_x_min=ax_min,
                    affected_x_max=ax_max,
                    affected_y_min=ay_min,
                    affected_y_max=ay_max,
                )
                result.append(entry)
            except Exception:
                continue

        if self._config.deterministic:
            result.sort(key=lambda o: o.object_id)
        return result

    # ------------------------------------------------------------------
    # Safety constraint projection
    # ------------------------------------------------------------------

    def _project_safety_constraints(self, pc) -> Tuple[
        List[SafetyConstraintSummary], List[SafetyConstraintSummary]
    ]:
        hard: List[SafetyConstraintSummary] = []
        soft: List[SafetyConstraintSummary] = []

        if pc is None:
            return hard, soft

        for i, c in enumerate(
            list(getattr(pc, "hard_constraints", ()) or ())[: self._config.max_hard_constraints]
        ):
            try:
                hard.append(SafetyConstraintSummary(
                    constraint_id=str(getattr(c, "constraint_id", _short_uid("hc", i))),
                    constraint_type=str(getattr(c, "constraint_type", NOT_AVAILABLE)),
                    hardness="HARD",
                    description=str(getattr(c, "description", NOT_AVAILABLE)),
                    confidence=_safe_float(getattr(c, "confidence", 0.0)),
                    evidence=EvidenceClass.OBSERVED,
                ))
            except Exception:
                continue

        for i, c in enumerate(
            list(getattr(pc, "soft_constraints", ()) or ())[: self._config.max_soft_constraints]
        ):
            try:
                soft.append(SafetyConstraintSummary(
                    constraint_id=str(getattr(c, "constraint_id", _short_uid("sc", i))),
                    constraint_type=str(getattr(c, "constraint_type", NOT_AVAILABLE)),
                    hardness="SOFT",
                    description=str(getattr(c, "description", NOT_AVAILABLE)),
                    confidence=_safe_float(getattr(c, "confidence", 0.0)),
                    evidence=EvidenceClass.OBSERVED,
                ))
            except Exception:
                continue

        if self._config.deterministic:
            hard.sort(key=lambda c: c.constraint_id)
            soft.sort(key=lambda c: c.constraint_id)

        return hard, soft

    # ------------------------------------------------------------------
    # Region building
    # ------------------------------------------------------------------

    def _build_regions(
        self, wm, pc, spatial_extent: SpatialExtent,
        static_hazards: List[StaticHazardEntry],
        dynamic_objects: List[DynamicObjectEntry],
    ) -> Tuple[
        List[PlanningRegion], List[PlanningRegion], List[PlanningRegion]
    ]:
        drivable: List[PlanningRegion] = []
        non_drivable: List[PlanningRegion] = []
        restricted: List[PlanningRegion] = []
        cfg = self._config

        # --- Primary drivable corridor ---
        if wm is not None:
            road = getattr(wm, "road", None)
            ds = getattr(road, "drivable_space", None) if road else None
            if ds is not None and getattr(ds, "available", False):
                ds_state = _drivable_state_from_world(ds, cfg)
                conf = _safe_float(getattr(ds, "free_space_confidence", 0.0))

                if len(drivable) < cfg.max_drivable_regions:
                    x_max = cfg.planning_horizon_m
                    y_min_v = spatial_extent.right_m
                    y_max_v = spatial_extent.left_m

                    drivable.append(PlanningRegion(
                        region_id="dr_primary_corridor",
                        kind=RegionKind.DRIVABLE_CORRIDOR,
                        drivable_state=ds_state,
                        restriction_kind=RestrictionKind.UNKNOWN,
                        x_min=0.0,
                        x_max=x_max if math.isfinite(x_max) else None,
                        y_min=y_min_v,
                        y_max=y_max_v,
                        confidence=conf,
                        uncertainty=_safe_float(
                            getattr(ds, "drivable_space_uncertainty", 1.0), 1.0
                        ),
                        evidence=EvidenceClass.OBSERVED,
                        source="world_model_drivable_space",
                    ))

        # --- Non-drivable from left/right boundary absence ---
        if wm is not None:
            road = getattr(wm, "road", None)
            ds = getattr(road, "drivable_space", None) if road else None
            if ds is not None and getattr(ds, "available", False):
                left_bd = getattr(ds, "left_boundary", None)
                right_bd = getattr(ds, "right_boundary", None)

                # Beyond left boundary
                if left_bd and getattr(left_bd, "available", False):
                    if len(non_drivable) < cfg.max_non_drivable_regions:
                        left_conf = _safe_float(getattr(left_bd, "confidence", 0.0))
                        left_y = spatial_extent.left_m
                        non_drivable.append(PlanningRegion(
                            region_id="ndr_beyond_left_boundary",
                            kind=RegionKind.NON_DRIVABLE,
                            drivable_state=DrivableState.NON_DRIVABLE,
                            restriction_kind=RestrictionKind.ROAD_BOUNDARY,
                            x_min=0.0,
                            x_max=cfg.planning_horizon_m,
                            y_min=left_y,
                            y_max=None,
                            confidence=left_conf,
                            uncertainty=1.0 - left_conf,
                            evidence=EvidenceClass.OBSERVED,
                            source="left_road_boundary",
                        ))

                # Beyond right boundary
                if right_bd and getattr(right_bd, "available", False):
                    if len(non_drivable) < cfg.max_non_drivable_regions:
                        right_conf = _safe_float(getattr(right_bd, "confidence", 0.0))
                        right_y = spatial_extent.right_m
                        non_drivable.append(PlanningRegion(
                            region_id="ndr_beyond_right_boundary",
                            kind=RegionKind.NON_DRIVABLE,
                            drivable_state=DrivableState.NON_DRIVABLE,
                            restriction_kind=RestrictionKind.ROAD_BOUNDARY,
                            x_min=0.0,
                            x_max=cfg.planning_horizon_m,
                            y_min=None,
                            y_max=right_y,
                            confidence=right_conf,
                            uncertainty=1.0 - right_conf,
                            evidence=EvidenceClass.OBSERVED,
                            source="right_road_boundary",
                        ))

        # --- Restricted zones from static hazards ---
        for i, hz in enumerate(static_hazards[: cfg.max_restricted_regions]):
            if len(restricted) >= cfg.max_restricted_regions:
                break
            px = hz.position_x
            py = hz.position_y
            if px is None or py is None:
                continue
            hw = (hz.approx_width_m or 1.0) / 2.0
            hl = (hz.approx_length_m or 1.0) / 2.0
            restricted.append(PlanningRegion(
                region_id=f"rz_hazard_{hz.hazard_id}",
                kind=RegionKind.RESTRICTED_ZONE,
                drivable_state=DrivableState.NON_DRIVABLE
                    if hz.drivability_impact in ("HIGH", "BLOCKING")
                    else DrivableState.UNCERTAIN,
                restriction_kind=RestrictionKind.ROAD_ANOMALY,
                x_min=_safe_float(px) - hl,
                x_max=_safe_float(px) + hl,
                y_min=_safe_float(py) - hw,
                y_max=_safe_float(py) + hw,
                confidence=hz.confidence,
                uncertainty=hz.uncertainty,
                evidence=hz.evidence,
                source=f"static_hazard_{hz.hazard_type}",
            ))

        # --- Restricted zones from dynamic objects ---
        for i, obj in enumerate(dynamic_objects[: cfg.max_restricted_regions]):
            if len(restricted) >= cfg.max_restricted_regions:
                break
            px = obj.position_x
            py = obj.position_y
            if px is None or py is None:
                continue
            restricted.append(PlanningRegion(
                region_id=f"rz_dyn_{obj.object_id}",
                kind=RegionKind.RESTRICTED_ZONE,
                drivable_state=DrivableState.NON_DRIVABLE,
                restriction_kind=RestrictionKind.DYNAMIC_OBJECT,
                x_min=obj.affected_x_min if obj.affected_x_min is not None else _safe_float(px) - 1.5,
                x_max=obj.affected_x_max if obj.affected_x_max is not None else _safe_float(px) + 1.5,
                y_min=obj.affected_y_min if obj.affected_y_min is not None else _safe_float(py) - 1.0,
                y_max=obj.affected_y_max if obj.affected_y_max is not None else _safe_float(py) + 1.0,
                confidence=obj.confidence,
                uncertainty=obj.uncertainty,
                evidence=obj.evidence,
                source=f"dynamic_object_{obj.object_type}",
            ))

        # --- Restricted zones from hard safety constraints ---
        if pc is not None:
            gate = str(getattr(pc, "safety_gate_state", "UNKNOWN"))
            if gate in ("CRITICAL", "HIGH_ALERT", "RESTRICTED"):
                if len(restricted) < cfg.max_restricted_regions:
                    restricted.append(PlanningRegion(
                        region_id="rz_safety_gate_restriction",
                        kind=RegionKind.RESTRICTED_ZONE,
                        drivable_state=DrivableState.UNCERTAIN,
                        restriction_kind=RestrictionKind.SAFETY_HARD,
                        confidence=_safe_float(getattr(pc, "confidence", 0.0)),
                        uncertainty=1.0,
                        evidence=EvidenceClass.COMBINED,
                        source=f"safety_gate_{gate}",
                    ))

        # Deterministic ordering
        if cfg.deterministic:
            drivable.sort(key=lambda r: r.region_id)
            non_drivable.sort(key=lambda r: r.region_id)
            restricted.sort(key=lambda r: r.region_id)

        return (
            drivable[: cfg.max_drivable_regions],
            non_drivable[: cfg.max_non_drivable_regions],
            restricted[: cfg.max_restricted_regions],
        )

    # ------------------------------------------------------------------
    # Safety gate passthrough
    # ------------------------------------------------------------------

    def _extract_gate_info(self, pc) -> Tuple[str, bool, str]:
        if pc is None:
            return NOT_AVAILABLE, False, NOT_AVAILABLE
        gate_state = str(getattr(getattr(pc, "safety_gate_state", None), "value",
                                 getattr(pc, "safety_gate_state", NOT_AVAILABLE)))
        planning_allowed = bool(getattr(pc, "planning_allowed", False))
        planning_mode = str(getattr(getattr(pc, "planning_mode", None), "value",
                                    getattr(pc, "planning_mode", NOT_AVAILABLE)))
        return gate_state, planning_allowed, planning_mode

    # ------------------------------------------------------------------
    # Quality computation
    # ------------------------------------------------------------------

    def _compute_quality(self, wm, pc) -> PlanningSpaceQuality:
        wm_avail = wm is not None
        pc_avail = pc is not None

        wm_conf = 0.0
        wm_unc = 1.0
        wm_completeness = 0.0
        wm_degraded = True

        if wm_avail:
            dq = getattr(wm, "data_quality", None)
            if dq:
                wm_conf = _safe_float(getattr(dq, "overall_confidence", 0.0))
                wm_unc = _safe_float(getattr(dq, "overall_uncertainty", 1.0), 1.0)
                wm_completeness = _safe_float(getattr(dq, "completeness", 0.0))
            wm_degraded = str(getattr(getattr(wm, "status", None), "value", "EMPTY")) in (
                "DEGRADED", "EMPTY", "INVALID"
            )

        pc_conf = 0.0
        if pc_avail:
            pc_conf = _safe_float(getattr(pc, "confidence", 0.0))

        # Weighted average confidence
        if wm_avail and pc_avail:
            overall_conf = 0.6 * wm_conf + 0.4 * pc_conf
        elif wm_avail:
            overall_conf = wm_conf
        elif pc_avail:
            overall_conf = pc_conf * 0.5
        else:
            overall_conf = 0.0

        # Road info available
        road_avail = False
        if wm_avail:
            road = getattr(wm, "road", None)
            if road:
                road_avail = str(getattr(getattr(road, "status", None), "value", "NONE")) not in (
                    "NONE", "UNKNOWN"
                )

        # Dynamic objects available
        dyn_avail = wm_avail and bool(getattr(wm, "object_count", 0))

        # Static hazards available
        hz_avail = False
        if wm_avail:
            road = getattr(wm, "road", None)
            if road:
                hz_avail = bool(getattr(road, "anomaly_count", 0))

        # Completeness fraction
        expected = 2  # world_model + planning_context
        available_count = int(wm_avail) + int(pc_avail)
        completeness = available_count / expected if expected > 0 else 0.0

        is_degraded = wm_degraded or not wm_avail
        is_partial = not (wm_avail and pc_avail)

        warnings: List[str] = []
        if not wm_avail:
            warnings.append("WorldModelSnapshot not available")
        if not pc_avail:
            warnings.append("PlanningContext not available")
        if wm_degraded and wm_avail:
            warnings.append("WorldModelSnapshot is degraded")

        return PlanningSpaceQuality(
            overall_confidence=min(1.0, max(0.0, overall_conf)),
            overall_uncertainty=max(0.0, wm_unc),
            completeness=completeness,
            is_degraded=is_degraded,
            is_partial=is_partial,
            world_model_available=wm_avail,
            planning_context_available=pc_avail,
            road_info_available=road_avail,
            dynamic_objects_available=dyn_avail,
            static_hazards_available=hz_avail,
            warnings=tuple(warnings),
        )

    # ------------------------------------------------------------------
    # Overall status
    # ------------------------------------------------------------------

    def _compute_status(
        self,
        quality: PlanningSpaceQuality,
        gate_state: str,
        planning_allowed: bool,
    ) -> PlanningSpaceStatus:
        if not quality.world_model_available and not quality.planning_context_available:
            return PlanningSpaceStatus.EMPTY

        if gate_state in ("CRITICAL", "HIGH_ALERT"):
            return PlanningSpaceStatus.RESTRICTED

        if gate_state == "RESTRICTED":
            return PlanningSpaceStatus.RESTRICTED

        if quality.is_degraded:
            return PlanningSpaceStatus.DEGRADED

        if quality.is_partial:
            return PlanningSpaceStatus.PARTIAL

        return PlanningSpaceStatus.OK

    # ------------------------------------------------------------------
    # Invalid snapshot fallback
    # ------------------------------------------------------------------

    def _make_invalid_snapshot(
        self,
        inp: PlanningInput,
        input_validation: PlanningInputValidationResult,
        build_dur: float,
    ) -> PlanningSnapshot:
        ts = inp.timestamp if inp is not None else time.time()
        fid = inp.frame_id if inp is not None else 0
        space = PlanningSpace(
            space_id=f"ps_invalid_{fid}",
            timestamp=ts,
            frame_id=fid,
            status=PlanningSpaceStatus.INVALID,
            planning_allowed=False,
            quality=PlanningSpaceQuality(
                warnings=input_validation.errors,
            ),
        )
        from .planning_space_validator import PlanningSpaceValidationResult
        val = PlanningSpaceValidationResult(
            is_valid=False,
            errors=input_validation.errors,
            warnings=input_validation.warnings,
        )
        return PlanningSnapshot(
            space=space,
            validation=val,
            build_duration_s=build_dur,
            snapshot_id=f"snap_invalid_{fid}",
            timestamp=ts,
        )
