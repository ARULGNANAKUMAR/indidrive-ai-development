"""
IndiDrive AI — Phase 9.1 | Planning Space Validator
====================================================
Validates PlanningInput and PlanningSpace instances before and after
construction.

Rejects or safely degrades malformed inputs.
Does NOT crash the pipeline for non-critical missing optional inputs.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import List, Tuple

from .planning_space_types import (
    PlanningSpace,
    PlanningSpaceStatus,
    OccupancyState,
    DrivableState,
    EvidenceClass,
    NOT_AVAILABLE,
)
from .planning_input_types import PlanningInput, PlanningInputValidationResult

__all__ = [
    "PlanningSpaceValidator",
    "PlanningSpaceValidationResult",
]

VALID_EVIDENCE_VALUES = {e.value for e in EvidenceClass}
VALID_DRIVABLE_VALUES = {d.value for d in DrivableState}
VALID_OCCUPANCY_VALUES = {o.value for o in OccupancyState}
VALID_STATUS_VALUES = {s.value for s in PlanningSpaceStatus}


@dataclass
class PlanningSpaceValidationResult:
    """Result of validating a PlanningSpace."""
    is_valid: bool = False
    errors: Tuple[str, ...] = field(default_factory=tuple)
    warnings: Tuple[str, ...] = field(default_factory=tuple)

    def to_dict(self) -> dict:
        return {
            "is_valid": self.is_valid,
            "error_count": len(self.errors),
            "errors": list(self.errors),
            "warning_count": len(self.warnings),
            "warnings": list(self.warnings),
        }


class PlanningSpaceValidator:
    """Validates PlanningInput and PlanningSpace.

    Follows the same validation pattern as Phase 8.4 ArbitrationValidator:
      - accumulate errors / warnings
      - return a result object
      - never raise on non-critical issues
      - reject INVALID states explicitly
    """

    # ------------------------------------------------------------------
    # Input validation
    # ------------------------------------------------------------------

    @staticmethod
    def validate_input(inp: PlanningInput) -> PlanningInputValidationResult:
        """Validate a PlanningInput before construction.

        Returns a result indicating whether input is valid.
        """
        errors: List[str] = []
        warnings: List[str] = []

        if inp is None:
            return PlanningInputValidationResult(
                is_valid=False,
                errors=("PlanningInput is None",),
            )

        # Timestamp must be a positive finite float
        if not isinstance(inp.timestamp, (int, float)):
            errors.append("timestamp must be numeric")
        elif not math.isfinite(float(inp.timestamp)):
            errors.append("timestamp must be finite")
        elif inp.timestamp <= 0:
            errors.append("timestamp must be positive")

        # frame_id must be non-negative int
        if not isinstance(inp.frame_id, int):
            errors.append("frame_id must be int")
        elif inp.frame_id < 0:
            errors.append("frame_id must be >= 0")

        # Optional upstream data — warnings only
        if inp.world_model_snapshot is None:
            warnings.append("world_model_snapshot is None — planning space will be partial")
        if inp.planning_context is None:
            warnings.append("planning_context is None — safety gate state will be UNKNOWN")

        return PlanningInputValidationResult(
            is_valid=len(errors) == 0,
            errors=tuple(errors),
            warnings=tuple(warnings),
        )

    # ------------------------------------------------------------------
    # Planning space validation
    # ------------------------------------------------------------------

    @staticmethod
    def validate(ps: PlanningSpace) -> PlanningSpaceValidationResult:
        """Validate a PlanningSpace after construction."""
        errors: List[str] = []
        warnings: List[str] = []

        if ps is None:
            return PlanningSpaceValidationResult(
                is_valid=False,
                errors=("PlanningSpace is None",),
            )

        # --- Coordinate frame ---
        cf = ps.coordinate_frame
        if cf.frame_id != "VEHICLE":
            errors.append(f"coordinate_frame.frame_id must be 'VEHICLE', got {cf.frame_id!r}")
        if cf.unit != "metres":
            errors.append(f"coordinate_frame.unit must be 'metres', got {cf.unit!r}")

        # --- Timestamp ---
        if not math.isfinite(ps.timestamp):
            errors.append("timestamp must be finite")
        elif ps.timestamp <= 0:
            errors.append("timestamp must be positive")

        # --- Frame ID ---
        if not isinstance(ps.frame_id, int) or ps.frame_id < 0:
            errors.append("frame_id must be a non-negative integer")

        # --- Status ---
        if ps.status.value not in VALID_STATUS_VALUES:
            errors.append(f"invalid status value: {ps.status!r}")

        # --- Horizon ---
        h = ps.horizon
        if not math.isfinite(h.longitudinal_m) or h.longitudinal_m <= 0:
            errors.append(f"horizon.longitudinal_m must be > 0 and finite, got {h.longitudinal_m}")
        if not math.isfinite(h.lateral_extent_m) or h.lateral_extent_m <= 0:
            errors.append(f"horizon.lateral_extent_m must be > 0 and finite, got {h.lateral_extent_m}")
        if h.temporal_horizon_s is not None:
            if not math.isfinite(h.temporal_horizon_s) or h.temporal_horizon_s <= 0:
                errors.append(f"horizon.temporal_horizon_s must be > 0 and finite")

        # --- Quality ---
        q = ps.quality
        if not (0.0 <= q.overall_confidence <= 1.0):
            errors.append(f"quality.overall_confidence out of [0,1]: {q.overall_confidence}")
        if not math.isfinite(q.overall_uncertainty) or q.overall_uncertainty < 0:
            errors.append(f"quality.overall_uncertainty must be >= 0 and finite")
        if not (0.0 <= q.completeness <= 1.0):
            errors.append(f"quality.completeness out of [0,1]: {q.completeness}")

        # --- Regions ---
        seen_ids = set()
        for r in (*ps.drivable_regions, *ps.non_drivable_regions, *ps.restricted_regions):
            if r.region_id == NOT_AVAILABLE:
                warnings.append("region has no region_id")
            elif r.region_id in seen_ids:
                errors.append(f"duplicate region_id: {r.region_id!r}")
            else:
                seen_ids.add(r.region_id)

            if r.drivable_state.value not in VALID_DRIVABLE_VALUES:
                errors.append(f"invalid drivable_state: {r.drivable_state!r}")
            if r.evidence.value not in VALID_EVIDENCE_VALUES:
                errors.append(f"invalid evidence: {r.evidence!r}")

            for coord, name in [
                (r.x_min, "x_min"), (r.x_max, "x_max"),
                (r.y_min, "y_min"), (r.y_max, "y_max"),
            ]:
                if coord is not None and not math.isfinite(coord):
                    errors.append(f"region {r.region_id!r} {name} is not finite")

            if not (0.0 <= r.confidence <= 1.0):
                errors.append(f"region {r.region_id!r} confidence out of [0,1]")

        # --- Dynamic objects ---
        seen_obj_ids = set()
        for obj in ps.dynamic_objects:
            if obj.object_id == NOT_AVAILABLE:
                warnings.append("dynamic_object has no object_id")
            elif obj.object_id in seen_obj_ids:
                errors.append(f"duplicate dynamic object_id: {obj.object_id!r}")
            else:
                seen_obj_ids.add(obj.object_id)

            for coord, name in [
                (obj.position_x, "position_x"), (obj.position_y, "position_y"),
            ]:
                if coord is not None and not math.isfinite(coord):
                    errors.append(f"dynamic object {obj.object_id!r} {name} is not finite")

            if not (0.0 <= obj.confidence <= 1.0):
                errors.append(f"dynamic object {obj.object_id!r} confidence out of [0,1]")

        # --- Static hazards ---
        seen_hazard_ids = set()
        for hz in ps.static_hazards:
            if hz.hazard_id == NOT_AVAILABLE:
                warnings.append("static_hazard has no hazard_id")
            elif hz.hazard_id in seen_hazard_ids:
                errors.append(f"duplicate hazard_id: {hz.hazard_id!r}")
            else:
                seen_hazard_ids.add(hz.hazard_id)

            if not (0.0 <= hz.confidence <= 1.0):
                errors.append(f"hazard {hz.hazard_id!r} confidence out of [0,1]")

        # --- Safety gate state ---
        if ps.safety_gate_state == NOT_AVAILABLE:
            warnings.append("safety_gate_state is NOT_AVAILABLE — Phase 8.4 may be absent")

        # --- Schema version ---
        if ps.schema_version != "9.1":
            warnings.append(f"unexpected schema_version: {ps.schema_version!r}")

        # --- Forbidden planning outputs (negative check) ---
        forbidden = ps.to_dict()
        for forbidden_key in (
            "path", "candidate_paths", "waypoints", "trajectory",
            "steering_angle", "throttle", "brake", "target_speed",
            "acceleration_cmd", "lane_change_command", "overtake_command",
            "steer_cmd", "select_best_path", "generate_path",
        ):
            if forbidden_key in forbidden:
                errors.append(
                    f"FORBIDDEN field '{forbidden_key}' found in PlanningSpace serialisation"
                )

        return PlanningSpaceValidationResult(
            is_valid=len(errors) == 0,
            errors=tuple(errors),
            warnings=tuple(warnings),
        )
