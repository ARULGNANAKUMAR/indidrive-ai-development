"""
IndiDrive AI — Phase 9.3 | Dynamic Obstacle & Path Risk Scoring — Data Contracts
==================================================================================
Strongly-typed containers for Path Risk Scoring output.

Phase 9.3 answers:
    «"How risky is this candidate path given the currently predicted
      dynamic environment?"»

Phase 9.3 does NOT answer:
    «"Which path should the vehicle choose?"»
    «"What is the best path?"»

Path selection belongs to a later phase.

Design rules (same as all prior phases):
  * dataclasses — not raw dicts
  * explicit NOT_AVAILABLE / UNKNOWN — never fabricated
  * no path selection, no best-path, no replanning, no vehicle control
  * no steering, no throttle, no brake, no target_speed
  * confidence ≠ uncertainty ≠ risk — kept separate
  * deterministic: same input → same output
  * immutable snapshots
  * offline — no LLM, no cloud, no neural networks

Risk score semantics:
    0.0 → minimum risk
    1.0 → maximum risk
    This is a NORMALISED RISK SCORE — NOT a collision probability.

Coordinate convention (vehicle frame — same as Phase 9.1/9.2):
    +X = forward
    +Y = left
    +Z = up
    Origin = vehicle rear-axle centre
    Units = metres

This module contains ONLY structural containers.
Computation lives in path_risk_engine.py.
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from enum import Enum
from typing import List, Optional, Tuple

__all__ = [
    # Sentinels / schema
    "NOT_AVAILABLE",
    "PATH_RISK_SCHEMA_VERSION",
    # Enums
    "RiskLevel",
    "RiskReasonCode",
    "PathRiskStatus",
    # Sub-structures
    "ObjectRiskContribution",
    "RiskBreakdown",
    # Primary containers
    "CandidatePathRisk",
    "PathRiskSet",
]

NOT_AVAILABLE = "NOT_AVAILABLE"
PATH_RISK_SCHEMA_VERSION = "9.3"


# ---------------------------------------------------------------------------
# Risk level — configurable thresholds in path_risk_config.py
# ---------------------------------------------------------------------------

class RiskLevel(str, Enum):
    """
    Categorical risk level for a candidate path.

    LOW_RISK      — path interacts with no or minimal dynamic hazards
    MODERATE_RISK — path has non-trivial interactions; caution warranted
    HIGH_RISK     — significant dynamic interactions detected
    CRITICAL_RISK — severe or imminent interaction detected
    UNKNOWN_RISK  — risk cannot be assessed (degraded / missing inputs)

    Note: LOW_RISK does NOT mean "safe." Risk level is a relative
    descriptor of the normalised score. Path safety is determined by the
    planning phase that consumes this output.
    """
    LOW_RISK      = "LOW_RISK"
    MODERATE_RISK = "MODERATE_RISK"
    HIGH_RISK     = "HIGH_RISK"
    CRITICAL_RISK = "CRITICAL_RISK"
    UNKNOWN_RISK  = "UNKNOWN_RISK"


# ---------------------------------------------------------------------------
# Reason codes — deterministic structured codes
# ---------------------------------------------------------------------------

class RiskReasonCode(str, Enum):
    """
    Deterministic, structured reason codes explaining risk contributions.
    Multiple codes may apply to a single candidate.
    """
    DYNAMIC_OBJECT_NEAR_PATH      = "DYNAMIC_OBJECT_NEAR_PATH"
    TRAJECTORY_INTERSECTION       = "TRAJECTORY_INTERSECTION"
    LOW_TTC                       = "LOW_TTC"
    LOW_CLEARANCE                 = "LOW_CLEARANCE"
    CLOSE_APPROACH                = "CLOSE_APPROACH"
    HIGH_COLLISION_LIKELIHOOD     = "HIGH_COLLISION_LIKELIHOOD"
    VULNERABLE_USER_NEAR_PATH     = "VULNERABLE_USER_NEAR_PATH"
    UNCERTAIN_OBJECT_MOTION       = "UNCERTAIN_OBJECT_MOTION"
    ROAD_HAZARD_INTERACTION       = "ROAD_HAZARD_INTERACTION"
    NARROW_CLEARANCE              = "NARROW_CLEARANCE"
    STALE_PREDICTION              = "STALE_PREDICTION"
    DEGRADED_SENSOR_INPUT         = "DEGRADED_SENSOR_INPUT"
    OBJECT_APPROACHING_PATH       = "OBJECT_APPROACHING_PATH"
    CROSSING_TRAJECTORY           = "CROSSING_TRAJECTORY"
    TEMPORAL_CONFLICT             = "TEMPORAL_CONFLICT"
    MULTIPLE_OBJECTS_NEAR_PATH    = "MULTIPLE_OBJECTS_NEAR_PATH"
    WORLD_MODEL_UNAVAILABLE       = "WORLD_MODEL_UNAVAILABLE"
    PREDICTION_UNAVAILABLE        = "PREDICTION_UNAVAILABLE"
    PLANNING_NOT_ALLOWED          = "PLANNING_NOT_ALLOWED"
    CANDIDATE_GEOMETRICALLY_INVALID = "CANDIDATE_GEOMETRICALLY_INVALID"
    NO_DYNAMIC_OBJECTS            = "NO_DYNAMIC_OBJECTS"
    HIGH_UNCERTAINTY              = "HIGH_UNCERTAINTY"


# ---------------------------------------------------------------------------
# Path risk evaluation status
# ---------------------------------------------------------------------------

class PathRiskStatus(str, Enum):
    """
    Overall status of a path risk evaluation pass.

    EVALUATED           — risk scores computed for all usable candidates
    DEGRADED            — risk computed but with degraded/missing inputs
    UNAVAILABLE         — risk cannot be produced (safety gate / no world model)
    PLANNING_RESTRICTED — Phase 8.4 planning_allowed=False
    NO_CANDIDATES       — no candidates to evaluate
    ERROR               — unexpected failure during evaluation
    """
    EVALUATED            = "EVALUATED"
    DEGRADED             = "DEGRADED"
    UNAVAILABLE          = "UNAVAILABLE"
    PLANNING_RESTRICTED  = "PLANNING_RESTRICTED"
    NO_CANDIDATES        = "NO_CANDIDATES"
    ERROR                = "ERROR"


# ---------------------------------------------------------------------------
# Per-object risk contribution
# ---------------------------------------------------------------------------

@dataclass
class ObjectRiskContribution:
    """
    Risk contribution from one specific dynamic object to one candidate path.

    Fields
    ------
    object_id           : primary ID of the contributing object.
    object_type         : object classification (VEHICLE, PEDESTRIAN, ...).
    is_vulnerable_user  : True if special VRU weighting applied.
    clearance_risk      : spatial clearance component [0, 1].
    temporal_risk       : time-based interaction component [0, 1].
    ttc_risk            : TTC-derived risk component [0, 1].
    closest_approach_risk: closest approach distance risk [0, 1].
    intersection_risk   : trajectory intersection risk [0, 1].
    collision_likelihood_risk: collision-likelihood conversion [0, 1].
    uncertainty_risk    : prediction uncertainty contribution [0, 1].
    vulnerable_user_risk: VRU weighting contribution [0, 1].
    combined_object_risk: aggregated contribution from this object [0, 1].
    reason_codes        : reason codes from this object.
    ttc_s               : raw TTC in seconds (None if not available).
    ttc_status          : TTC status string.
    min_separation_m    : minimum predicted separation (metres).
    is_critical         : True if this object is the dominant risk source.
    """
    object_id: str = NOT_AVAILABLE
    object_type: str = NOT_AVAILABLE
    is_vulnerable_user: bool = False

    # Component scores [0, 1]
    clearance_risk: float = 0.0
    temporal_risk: float = 0.0
    ttc_risk: float = 0.0
    closest_approach_risk: float = 0.0
    intersection_risk: float = 0.0
    collision_likelihood_risk: float = 0.0
    uncertainty_risk: float = 0.0
    vulnerable_user_risk: float = 0.0

    # Aggregated per-object contribution [0, 1]
    combined_object_risk: float = 0.0

    # Reason codes from this object
    reason_codes: Tuple[RiskReasonCode, ...] = field(default_factory=tuple)

    # Raw values (preserved for diagnostics, not used by downstream selector)
    ttc_s: Optional[float] = None
    ttc_status: str = NOT_AVAILABLE
    min_separation_m: Optional[float] = None

    is_critical: bool = False

    def to_dict(self) -> dict:
        def _r(v):
            return round(v, 4) if v is not None else NOT_AVAILABLE
        return {
            "object_id": self.object_id,
            "object_type": self.object_type,
            "is_vulnerable_user": self.is_vulnerable_user,
            "clearance_risk": round(self.clearance_risk, 4),
            "temporal_risk": round(self.temporal_risk, 4),
            "ttc_risk": round(self.ttc_risk, 4),
            "closest_approach_risk": round(self.closest_approach_risk, 4),
            "intersection_risk": round(self.intersection_risk, 4),
            "collision_likelihood_risk": round(self.collision_likelihood_risk, 4),
            "uncertainty_risk": round(self.uncertainty_risk, 4),
            "vulnerable_user_risk": round(self.vulnerable_user_risk, 4),
            "combined_object_risk": round(self.combined_object_risk, 4),
            "reason_codes": [rc.value for rc in self.reason_codes],
            "ttc_s": _r(self.ttc_s),
            "ttc_status": self.ttc_status,
            "min_separation_m": _r(self.min_separation_m),
            "is_critical": self.is_critical,
        }


# ---------------------------------------------------------------------------
# Risk breakdown — per-component scores for one candidate
# ---------------------------------------------------------------------------

@dataclass
class RiskBreakdown:
    """
    Detailed per-component risk breakdown for one candidate path.

    All component scores are in [0, 1].
    These are COMPONENT CONTRIBUTIONS, not independent probabilities.
    They are combined by the configured aggregation formula.
    """
    # Dynamic object aggregate components
    clearance_risk: float = 0.0
    temporal_risk: float = 0.0
    ttc_risk: float = 0.0
    closest_approach_risk: float = 0.0
    trajectory_intersection_risk: float = 0.0
    collision_likelihood_risk: float = 0.0

    # Object-uncertainty component
    uncertainty_risk: float = 0.0

    # Special category components
    vulnerable_user_risk: float = 0.0
    road_hazard_risk: float = 0.0

    def to_dict(self) -> dict:
        return {
            "clearance_risk": round(self.clearance_risk, 4),
            "temporal_risk": round(self.temporal_risk, 4),
            "ttc_risk": round(self.ttc_risk, 4),
            "closest_approach_risk": round(self.closest_approach_risk, 4),
            "trajectory_intersection_risk": round(self.trajectory_intersection_risk, 4),
            "collision_likelihood_risk": round(self.collision_likelihood_risk, 4),
            "uncertainty_risk": round(self.uncertainty_risk, 4),
            "vulnerable_user_risk": round(self.vulnerable_user_risk, 4),
            "road_hazard_risk": round(self.road_hazard_risk, 4),
        }


# ---------------------------------------------------------------------------
# CandidatePathRisk — primary output of Phase 9.3
# ---------------------------------------------------------------------------

@dataclass
class CandidatePathRisk:
    """
    Risk assessment for ONE candidate path.

    Phase 9.3 produces one CandidatePathRisk per CandidatePath.

    FORBIDDEN fields (must never appear here):
        best_path, selected_path, optimal_path, chosen_path, winner,
        steering_angle, throttle, brake, target_speed, acceleration_cmd,
        replan, adaptive_replan, replan_trigger, lane_change_decision,
        model_predictive_output, carla_vehicle_command.

    Fields
    ------
    candidate_id        : matches the CandidatePath.candidate_id this scores.
    frame_id            : processing frame counter (matches candidate).
    timestamp           : wall-clock time of risk evaluation.
    coordinate_frame    : declared coordinate frame (always "VEHICLE").
    total_risk          : normalised aggregate risk score [0.0, 1.0].
    risk_level          : categorical risk level.
    breakdown           : per-component risk breakdown.
    dynamic_object_count: number of dynamic objects evaluated.
    critical_object_count: objects with is_critical=True.
    object_contributions: per-object risk contributions (bounded).
    affected_object_ids : IDs of objects that contributed risk.
    dominant_risk_reason: single primary reason code (or NOT_AVAILABLE).
    reason_codes        : all active reason codes for this candidate.
    confidence          : [0, 1] confidence in this risk assessment.
    uncertainty         : [0, 1] uncertainty in this risk assessment.
    degraded            : True if inputs were degraded or missing.
    is_geometrically_invalid: True if candidate was geometrically invalid.
    schema_version      : Phase 9.3 schema version.
    """
    # --- Identity ---
    candidate_id: str = NOT_AVAILABLE
    frame_id: int = 0
    timestamp: float = field(default_factory=time.time)
    coordinate_frame: str = "VEHICLE"

    # --- Aggregate risk score ---
    # Normalised: 0.0 = minimum risk, 1.0 = maximum risk.
    # This is NOT a collision probability.
    total_risk: float = 0.0
    risk_level: RiskLevel = RiskLevel.UNKNOWN_RISK

    # --- Detailed breakdown ---
    breakdown: RiskBreakdown = field(default_factory=RiskBreakdown)

    # --- Object interaction summary ---
    dynamic_object_count: int = 0
    critical_object_count: int = 0
    object_contributions: Tuple[ObjectRiskContribution, ...] = field(
        default_factory=tuple
    )

    # --- Affected object IDs ---
    affected_object_ids: Tuple[str, ...] = field(default_factory=tuple)

    # --- Reason codes ---
    dominant_risk_reason: str = NOT_AVAILABLE
    reason_codes: Tuple[RiskReasonCode, ...] = field(default_factory=tuple)

    # --- Epistemic state ---
    confidence: float = 0.0
    uncertainty: float = 1.0
    degraded: bool = True

    # --- Geometric state flag (from Phase 9.2, not re-evaluated here) ---
    is_geometrically_invalid: bool = False

    schema_version: str = PATH_RISK_SCHEMA_VERSION

    def to_dict(self) -> dict:
        return {
            "candidate_id": self.candidate_id,
            "frame_id": self.frame_id,
            "timestamp": self.timestamp,
            "coordinate_frame": self.coordinate_frame,
            "total_risk": round(self.total_risk, 4),
            "risk_level": self.risk_level.value,
            "breakdown": self.breakdown.to_dict(),
            "dynamic_object_count": self.dynamic_object_count,
            "critical_object_count": self.critical_object_count,
            "object_contributions": [oc.to_dict() for oc in self.object_contributions],
            "affected_object_ids": list(self.affected_object_ids),
            "dominant_risk_reason": self.dominant_risk_reason,
            "reason_codes": [rc.value for rc in self.reason_codes],
            "confidence": round(self.confidence, 4),
            "uncertainty": round(self.uncertainty, 4),
            "degraded": self.degraded,
            "is_geometrically_invalid": self.is_geometrically_invalid,
            "schema_version": self.schema_version,
        }


# ---------------------------------------------------------------------------
# PathRiskSet — immutable set of risk assessments for one planning frame
# ---------------------------------------------------------------------------

@dataclass
class PathRiskSet:
    """
    Immutable collection of CandidatePathRisk for one planning cycle.

    All assessments share the same frame_id and coordinate_frame.
    There is NO selected_path or best_path field here.
    Path comparison/selection belongs to a later phase.

    Fields
    ------
    set_id              : unique deterministic ID.
    frame_id            : processing frame counter.
    timestamp           : evaluation wall-clock time.
    coordinate_frame    : declared coordinate frame.
    status              : overall evaluation status.
    status_reason       : human-readable reason for status.
    risks               : immutable tuple of CandidatePathRisk.
    evaluation_duration_s: wall-clock evaluation time (informational).
    schema_version      : Phase 9.3 schema version.
    """
    set_id: str = NOT_AVAILABLE
    frame_id: int = 0
    timestamp: float = field(default_factory=time.time)
    coordinate_frame: str = "VEHICLE"

    status: PathRiskStatus = PathRiskStatus.ERROR
    status_reason: str = ""

    # Risks — immutable tuple; no selected/best element
    _risks: Tuple[CandidatePathRisk, ...] = field(
        default_factory=tuple, repr=False
    )

    evaluation_duration_s: float = 0.0
    schema_version: str = PATH_RISK_SCHEMA_VERSION

    @property
    def risks(self) -> Tuple[CandidatePathRisk, ...]:
        return self._risks

    @property
    def risk_count(self) -> int:
        return len(self._risks)

    @property
    def has_risks(self) -> bool:
        return self.risk_count > 0

    @property
    def critical_count(self) -> int:
        return sum(
            1 for r in self._risks if r.risk_level == RiskLevel.CRITICAL_RISK
        )

    def to_dict(self) -> dict:
        return {
            "set_id": self.set_id,
            "frame_id": self.frame_id,
            "timestamp": self.timestamp,
            "coordinate_frame": self.coordinate_frame,
            "status": self.status.value,
            "status_reason": self.status_reason,
            "risk_count": self.risk_count,
            "critical_count": self.critical_count,
            "risks": [r.to_dict() for r in self._risks],
            "evaluation_duration_s": round(self.evaluation_duration_s, 6),
            "schema_version": self.schema_version,
        }
