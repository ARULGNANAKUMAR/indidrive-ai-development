"""
IndiDrive AI — Phase 9.1 | Planning Input Data Contracts
=========================================================
Compact structured input contract for Phase 9.1.

PlanningInput is the clean interface between Phase 8.4 outputs and
Phase 9.1 planning space construction.  It carries references / snapshots
of exactly the upstream data Phase 9.1 needs — no raw sensor data.

FORBIDDEN in PlanningInput:
    camera images, LiDAR point clouds, radar raw packets,
    path, trajectory, steering, throttle, brake, target_speed,
    waypoints, lane_change_command, overtake_command.
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Optional

__all__ = [
    "NOT_AVAILABLE",
    "PLANNING_INPUT_SCHEMA_VERSION",
    "PlanningInput",
    "PlanningInputValidationResult",
]

NOT_AVAILABLE = "NOT_AVAILABLE"
PLANNING_INPUT_SCHEMA_VERSION = "9.1"


@dataclass
class PlanningInput:
    """
    Clean input contract for Phase 9.1.

    Carries compact references/snapshots of:
      - WorldModelSnapshot (from Phase 7)
      - PlanningContext (from Phase 8.4)
      - timestamp
      - frame_id

    Does NOT carry:
      - raw camera images
      - raw LiDAR point clouds
      - raw radar packets
      - complete duplicates of large upstream structures

    The world_model_snapshot and planning_context fields hold the actual
    upstream output objects by reference — do NOT deep-copy them.
    Phase 9.1 reads them immutably.
    """
    input_id: str = NOT_AVAILABLE
    timestamp: float = field(default_factory=time.time)
    frame_id: int = 0
    schema_version: str = PLANNING_INPUT_SCHEMA_VERSION

    # --- Primary upstream inputs (references, not copies) ---
    # Type annotation uses Optional[object] to avoid circular imports;
    # runtime consumers check .status / .schema_version fields.
    world_model_snapshot: Optional[object] = None   # WorldModelSnapshot from Phase 7
    planning_context: Optional[object] = None       # PlanningContext from Phase 8.4

    # --- Derived flags for quick inspection ---
    world_model_available: bool = False
    planning_context_available: bool = False

    def to_dict(self) -> dict:
        return {
            "input_id": self.input_id,
            "timestamp": self.timestamp,
            "frame_id": self.frame_id,
            "schema_version": self.schema_version,
            "world_model_available": self.world_model_available,
            "planning_context_available": self.planning_context_available,
        }


@dataclass
class PlanningInputValidationResult:
    """Result of validating a PlanningInput before construction."""
    is_valid: bool = False
    errors: tuple = field(default_factory=tuple)
    warnings: tuple = field(default_factory=tuple)

    def to_dict(self) -> dict:
        return {
            "is_valid": self.is_valid,
            "error_count": len(self.errors),
            "errors": list(self.errors),
            "warning_count": len(self.warnings),
            "warnings": list(self.warnings),
        }
