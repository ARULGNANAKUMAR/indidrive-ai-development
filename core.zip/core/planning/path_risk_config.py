"""
IndiDrive AI — Phase 9.3 | Path Risk Engine Configuration
==========================================================
All configurable thresholds and weights for the Path Risk Engine.

No safety-critical threshold is hard-coded in path_risk_engine.py.
Every parameter lives here and can be overridden from the planner_config.yaml
'phase_9_3' section via load_path_risk_config().

Design: dataclass with defaults that are reasonable for Indian road conditions.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict


@dataclass
class PathRiskConfig:
    """
    Configuration for Phase 9.3 Dynamic Obstacle & Path Risk Scoring.

    All weights are used in the aggregation formula:
        total_risk = weighted combination of component scores, clamped to [0, 1].

    Weights do not need to sum to 1.0 — they control relative importance.
    The engine normalises the result by clamping to [0, 1].
    """

    # -----------------------------------------------------------------------
    # Aggregation weights (relative importance of each component)
    # -----------------------------------------------------------------------
    w_clearance: float = 0.20
    w_temporal: float = 0.15
    w_ttc: float = 0.25
    w_closest_approach: float = 0.10
    w_intersection: float = 0.15
    w_collision_likelihood: float = 0.20
    w_uncertainty: float = 0.05
    w_vulnerable_user: float = 0.10    # additive boost when VRU detected
    w_road_hazard: float = 0.10

    # -----------------------------------------------------------------------
    # Clearance risk thresholds (metres)
    # -----------------------------------------------------------------------
    # Distance at which clearance risk saturates to 1.0
    clearance_critical_m: float = 0.5
    # Distance at which clearance risk starts rising (from 0.0)
    clearance_safe_m: float = 6.0

    # -----------------------------------------------------------------------
    # TTC risk thresholds (seconds)
    # -----------------------------------------------------------------------
    ttc_critical_s: float = 1.5    # TTC ≤ this → risk = 1.0
    ttc_safe_s: float = 8.0        # TTC ≥ this → risk = 0.0
    # If TTC is unavailable but object is close, apply this fallback risk
    ttc_unavailable_near_fallback: float = 0.4

    # -----------------------------------------------------------------------
    # Closest approach risk thresholds (metres)
    # -----------------------------------------------------------------------
    closest_approach_critical_m: float = 0.8
    closest_approach_safe_m: float = 5.0

    # -----------------------------------------------------------------------
    # Trajectory intersection
    # -----------------------------------------------------------------------
    # Risk assigned when a trajectory intersection is detected
    intersection_detected_risk: float = 0.8
    # Risk assigned when no intersection (but evaluated)
    intersection_clear_risk: float = 0.05

    # -----------------------------------------------------------------------
    # Collision likelihood (Phase 4 output, [0, 1])
    # -----------------------------------------------------------------------
    # Scale factor for Phase 4 collision_likelihood → risk contribution
    # Phase 4 likelihood is already [0, 1]; we pass it through with a cap
    collision_likelihood_max: float = 1.0

    # -----------------------------------------------------------------------
    # Temporal / time-of-conflict risk
    # -----------------------------------------------------------------------
    # Predicted path-object temporal overlap window (seconds)
    temporal_conflict_window_s: float = 5.0

    # -----------------------------------------------------------------------
    # Stale data thresholds (seconds)
    # -----------------------------------------------------------------------
    # Object data age above which staleness penalty applies
    stale_data_age_s: float = 0.5
    # Object data age above which object is marked "very stale"
    very_stale_data_age_s: float = 2.0

    # -----------------------------------------------------------------------
    # Vulnerable road user (VRU) types and weighting
    # -----------------------------------------------------------------------
    # Additional multiplicative risk boost for VRU objects [0, 1]
    vru_risk_boost: float = 0.25
    # Object types considered as VRU
    vru_types: tuple = field(default_factory=lambda: (
        "PEDESTRIAN", "CYCLIST", "CYCLE", "CATTLE", "CHILD",
        "PUSHCART", "ANIMAL",
    ))

    # -----------------------------------------------------------------------
    # Road hazard risk thresholds
    # -----------------------------------------------------------------------
    # Maximum risk contribution from one road anomaly
    hazard_max_risk: float = 0.6
    # Lateral distance within which a road anomaly interacts with a path (metres)
    hazard_interaction_lateral_m: float = 1.5
    # Severity → base risk mapping
    hazard_severity_risk: Dict[str, float] = field(default_factory=lambda: {
        "CRITICAL": 0.6,
        "SEVERE":   0.5,
        "MODERATE": 0.3,
        "MINOR":    0.1,
        "UNKNOWN":  0.15,
    })

    # -----------------------------------------------------------------------
    # Uncertainty risk
    # -----------------------------------------------------------------------
    # Prediction confidence below which uncertainty risk starts rising
    low_confidence_threshold: float = 0.4
    # Max uncertainty risk contribution
    uncertainty_risk_max: float = 0.5

    # -----------------------------------------------------------------------
    # Risk level thresholds (applied to total_risk [0, 1])
    # -----------------------------------------------------------------------
    risk_level_low_max: float = 0.30
    risk_level_moderate_max: float = 0.55
    risk_level_high_max: float = 0.80
    # CRITICAL_RISK: total_risk > risk_level_high_max

    # -----------------------------------------------------------------------
    # Performance / bounding
    # -----------------------------------------------------------------------
    # Maximum dynamic objects evaluated per candidate (bounded for O(N·M))
    max_objects_per_candidate: int = 20

    # -----------------------------------------------------------------------
    # Candidate path envelope (approximate vehicle width used for clearance)
    # -----------------------------------------------------------------------
    path_half_width_m: float = 1.1   # ~ego half-width + small margin

    # -----------------------------------------------------------------------
    # Object-type risk weight multipliers
    # Object types not listed get weight 1.0.
    # -----------------------------------------------------------------------
    object_type_weights: Dict[str, float] = field(default_factory=lambda: {
        "PEDESTRIAN": 1.4,
        "CYCLIST":    1.3,
        "CYCLE":      1.3,
        "CATTLE":     1.3,
        "CHILD":      1.5,
        "PUSHCART":   1.1,
        "MOTORCYCLE": 1.1,
        "SCOOTER":    1.1,
        "AUTO":       1.0,
        "CAR":        1.0,
        "BUS":        1.2,
        "TRUCK":      1.2,
        "TRACTOR":    1.1,
        "OBSTACLE":   0.9,
    })


def load_path_risk_config(config_dict: dict | None = None) -> PathRiskConfig:
    """
    Build a PathRiskConfig from an optional config dict (from planner_config.yaml
    'phase_9_3' section).  Falls back to defaults for any missing key.

    Args:
        config_dict: optional dict from config loader, keyed by field names.

    Returns:
        Populated PathRiskConfig.
    """
    cfg = PathRiskConfig()
    if not config_dict:
        return cfg

    # Scalar fields
    scalar_fields = [
        "w_clearance", "w_temporal", "w_ttc", "w_closest_approach",
        "w_intersection", "w_collision_likelihood", "w_uncertainty",
        "w_vulnerable_user", "w_road_hazard",
        "clearance_critical_m", "clearance_safe_m",
        "ttc_critical_s", "ttc_safe_s", "ttc_unavailable_near_fallback",
        "closest_approach_critical_m", "closest_approach_safe_m",
        "intersection_detected_risk", "intersection_clear_risk",
        "collision_likelihood_max",
        "temporal_conflict_window_s",
        "stale_data_age_s", "very_stale_data_age_s",
        "vru_risk_boost",
        "hazard_max_risk", "hazard_interaction_lateral_m",
        "low_confidence_threshold", "uncertainty_risk_max",
        "risk_level_low_max", "risk_level_moderate_max", "risk_level_high_max",
        "max_objects_per_candidate", "path_half_width_m",
    ]
    for f in scalar_fields:
        if f in config_dict:
            try:
                setattr(cfg, f, type(getattr(cfg, f))(config_dict[f]))
            except (TypeError, ValueError):
                pass  # keep default

    # Dict fields
    if "hazard_severity_risk" in config_dict and isinstance(
        config_dict["hazard_severity_risk"], dict
    ):
        cfg.hazard_severity_risk = dict(config_dict["hazard_severity_risk"])

    if "object_type_weights" in config_dict and isinstance(
        config_dict["object_type_weights"], dict
    ):
        cfg.object_type_weights = dict(config_dict["object_type_weights"])

    if "vru_types" in config_dict and isinstance(config_dict["vru_types"], (list, tuple)):
        cfg.vru_types = tuple(str(v).upper() for v in config_dict["vru_types"])

    return cfg
