"""
IndiDrive AI — Phase 9.6 | Final Planner Integration — Planner Engine
=======================================================================
Deterministic, end-to-end planning pipeline that integrates:

    Phase 9.1  Planning Space
    Phase 9.5  Indian-Road Planning Adaptation
    Phase 9.2  Candidate Path Generation
    Phase 9.3  Dynamic Path Risk Scoring
    Phase 9.4  Adaptive Replanning
    Phase 9.6  Final Planner Integration  ← THIS MODULE

The engine orchestrates the pipeline stages, validates inputs and outputs,
selects the lowest-risk valid candidate (planning-level only), and produces
a structured PlannerOutput and PlannerSnapshot.

Forbidden outputs:
    steering, throttle, brake, actuator_command, wheel_angle,
    motor_command, MPC_output, PID_output, control_command.

Forbidden implementations:
    MPC, PID, vehicle dynamics, trajectory tracking controllers,
    new perception/prediction/sensor fusion,
    LLMs, cloud APIs, neural networks, internet calls.

Architecture position:

    Phase 9.1 Planning Space
    ↓
    Phase 9.5 Indian-Road Adaptation
    ↓
    Phase 9.2 Candidate Path Generation
    ↓
    Phase 9.3 Dynamic Risk Scoring
    ↓
    Phase 9.4 Adaptive Replanning
    ↓
    Phase 9.6 PlannerEngine.run()          ← integration layer
    ↓
    PlannerOutput / Phase 10 MPC (future)

Design rules:
  * stateless pipeline stages
  * minimal stateful store: last_snapshot only
  * deterministic selection (lowest risk, stable tie-break)
  * no unsafe global mutable state
  * no random(), uuid4(), or time-seeded IDs in selection logic
  * graceful degradation on any missing upstream input
"""
from __future__ import annotations

import math
import threading
import time
from typing import List, Optional, Sequence, Tuple

from .planner_types import (
    NOT_AVAILABLE,
    PLANNER_SCHEMA_VERSION,
    CandidateSummary,
    InputValidationStatus,
    PlannerInput,
    PlannerMetrics,
    PlannerOutput,
    PlannerSnapshot,
    PlannerState,
    PlannerStatus,
    ReplanSummary,
    RiskSummary,
)
from .planner_validator import PlannerValidator, InputValidationResult
from .planner_config import PlannerConfig, load_planner_config

# Late imports for phase-specific types (avoid circular imports at module level)
from .candidate_path_types import (
    CandidatePathSet,
    CandidatePath,
    GeometricValidity,
    BoundaryValidity,
    DrivableSpaceValidity,
    CandidateGenerationStatus,
)
from .path_risk_types import (
    PathRiskSet,
    CandidatePathRisk,
    RiskLevel,
    PathRiskStatus,
)
from .replanning_types import (
    ReplanningDecision,
    ReplanningDecisionResult,
)
from .indian_road_planning_types import (
    IndianRoadPlanningResult,
    PlanningMode,
)

__all__ = ["PlannerEngine"]

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _finite(v) -> Optional[float]:
    try:
        f = float(v)
        return f if math.isfinite(f) else None
    except (TypeError, ValueError):
        return None


def _risk_score(r: CandidatePathRisk) -> float:
    """Extract composite risk score from CandidatePathRisk.
    Phase 9.3 uses total_risk as the primary aggregate score.
    Fallback: check breakdown.composite_risk_score if present.
    """
    # Primary: total_risk (the real Phase 9.3 aggregate field)
    v = _finite(getattr(r, "total_risk", None))
    if v is not None:
        return v
    # Secondary: breakdown sub-field (may not exist in all versions)
    rb = getattr(r, "breakdown", None) or getattr(r, "risk_breakdown", None)
    if rb is not None:
        v = _finite(getattr(rb, "composite_risk_score", None))
        if v is not None:
            return v
    return 1.0  # unknown → treat as maximum risk


def _is_candidate_valid(c: CandidatePath) -> bool:
    """Return True if a candidate is geometrically feasible."""
    geo = getattr(c, "geometric_validity", None)
    bnd = getattr(c, "boundary_validity", None)
    drv = getattr(c, "drivable_space_validity", None)

    geo_ok = geo in (
        GeometricValidity.VALID,
        GeometricValidity.PARTIALLY_VALID,
    ) or geo is None
    bnd_ok = bnd in (
        BoundaryValidity.VALID,
        BoundaryValidity.PARTIALLY_VALID,
        None,
    )
    drv_ok = drv in (
        DrivableSpaceValidity.VALID,
        DrivableSpaceValidity.PARTIALLY_VALID,
        None,
    )
    return geo_ok and bnd_ok and drv_ok


def _high_risk(level: RiskLevel) -> bool:
    return level in (RiskLevel.HIGH_RISK, RiskLevel.CRITICAL_RISK)


def _critical_risk(level: RiskLevel) -> bool:
    return level == RiskLevel.CRITICAL_RISK


# ---------------------------------------------------------------------------
# PlannerEngine
# ---------------------------------------------------------------------------

class PlannerEngine:
    """
    Phase 9.6 integrated planning engine.

    Thread safety: each run() call is protected by a reentrant lock.
    The only shared mutable state is _last_snapshot; all pipeline stages
    are stateless.

    Usage:
        engine = PlannerEngine()
        output, snapshot, metrics = engine.run(planner_input)
    """

    def __init__(self, config: Optional[PlannerConfig] = None) -> None:
        self._cfg = config or load_planner_config()
        self._validator = PlannerValidator(self._cfg)
        self._lock = threading.RLock()
        self._state: PlannerState = PlannerState.UNINITIALISED
        self._last_snapshot: Optional[PlannerSnapshot] = None
        self._cycle_counter: int = 0

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    @property
    def state(self) -> PlannerState:
        return self._state

    @property
    def last_snapshot(self) -> Optional[PlannerSnapshot]:
        """Immutable snapshot from the most recent run()."""
        return self._last_snapshot

    def run(
        self,
        inp: PlannerInput,
    ) -> Tuple[PlannerOutput, PlannerSnapshot, PlannerMetrics]:
        """
        Execute one integrated planning cycle.

        Parameters
        ----------
        inp : PlannerInput
            All upstream phase outputs for this cycle.

        Returns
        -------
        (PlannerOutput, PlannerSnapshot, PlannerMetrics)

        Never raises — all errors are captured in PlannerOutput.planning_status.
        """
        with self._lock:
            try:
                return self._run_impl(inp)
            except Exception as exc:
                return self._error_output(inp, f"Unexpected pipeline error: {exc}")

    def reset(self) -> None:
        """Reset planner state (e.g. between scenarios in benchmark)."""
        with self._lock:
            self._state = PlannerState.UNINITIALISED
            self._last_snapshot = None
            self._cycle_counter = 0

    # ------------------------------------------------------------------
    # Internal pipeline
    # ------------------------------------------------------------------

    def _run_impl(
        self,
        inp: PlannerInput,
    ) -> Tuple[PlannerOutput, PlannerSnapshot, PlannerMetrics]:
        t0 = time.perf_counter()
        self._state = PlannerState.ACTIVE
        self._cycle_counter += 1
        now = getattr(inp, "timestamp", time.time()) or time.time()
        frame_id = getattr(inp, "frame_id", 0) or 0
        warnings: List[str] = []
        reason_codes: List[str] = []

        # ================================================================
        # Stage 1 — Input Validation
        # ================================================================
        t_val = time.perf_counter()
        val_result = self._validator.validate_input(inp, now=now)
        val_latency_ms = (time.perf_counter() - t_val) * 1000.0

        planning_allowed = val_result.planning_allowed
        sg_state = val_result.safety_gate_state
        warnings.extend(val_result.warnings)

        if not val_result.is_valid:
            # Hard input failure — do not silently produce a plan
            if val_result.status == InputValidationStatus.STALE:
                status = PlannerStatus.STALE_INPUT
                reason_codes.append("STALE_INPUT")
            else:
                status = PlannerStatus.INVALID_INPUT
                reason_codes.append("INVALID_INPUT")
            reason_codes.extend([e[:60] for e in val_result.errors])
            output = self._make_output(
                frame_id=frame_id,
                now=now,
                status=status,
                planning_allowed=planning_allowed,
                sg_state=sg_state,
                val_status=val_result.status,
                stale=val_result.status == InputValidationStatus.STALE,
                warnings=tuple(warnings),
                reason_codes=tuple(reason_codes),
                validation_errors=val_result.errors,
            )
            snap = self._make_snapshot(output)
            metrics = self._make_metrics(
                frame_id=frame_id,
                now=now,
                latency_ms=(time.perf_counter() - t0) * 1000.0,
                val_latency_ms=val_latency_ms,
                output=output,
            )
            self._last_snapshot = snap
            self._state = PlannerState.IDLE
            return output, snap, metrics

        if val_result.stale_fields:
            reason_codes.append("STALE_INPUT")

        # ================================================================
        # Stage 2 — Safety Gate Check
        # ================================================================
        if not planning_allowed:
            reason_codes.append("SAFETY_RESTRICTED")
            output = self._make_output(
                frame_id=frame_id,
                now=now,
                status=PlannerStatus.SAFETY_RESTRICTED,
                planning_allowed=False,
                sg_state=sg_state,
                val_status=val_result.status,
                warnings=tuple(warnings),
                reason_codes=tuple(reason_codes),
            )
            snap = self._make_snapshot(output)
            metrics = self._make_metrics(
                frame_id=frame_id,
                now=now,
                latency_ms=(time.perf_counter() - t0) * 1000.0,
                val_latency_ms=val_latency_ms,
                output=output,
            )
            self._last_snapshot = snap
            self._state = PlannerState.IDLE
            return output, snap, metrics

        # ================================================================
        # Stage 3 — Planning Space Preparation (consume Phase 9.1)
        # ================================================================
        planning_space = inp.planning_space
        ps_degraded = False
        if planning_space is not None:
            q = getattr(planning_space, "quality", None)
            if q is not None:
                ps_degraded = bool(
                    getattr(q, "is_degraded", False)
                    or getattr(q, "is_partial", False)
                )
            ps_status = getattr(planning_space, "status", None)
            if ps_status is not None:
                ps_str = str(ps_status)
                if "DEGRADED" in ps_str or "INVALID" in ps_str:
                    ps_degraded = True
                    warnings.append(f"planning_space.status={ps_str}")

        # ================================================================
        # Stage 4 — Indian-Road Mode (consume Phase 9.5)
        # ================================================================
        planning_mode = NOT_AVAILABLE
        indian_result = inp.indian_road_result
        if indian_result is not None:
            constraints = getattr(indian_result, "constraints", None)
            if constraints is not None:
                mode = getattr(constraints, "planning_mode", None)
                if mode is not None:
                    planning_mode = str(mode.value if hasattr(mode, "value") else mode)
                ir_degraded = getattr(constraints, "degraded", True)
                if ir_degraded:
                    ps_degraded = True
        elif planning_space is not None:
            # Fallback: extract mode from planning_space.planning_mode
            pm = getattr(planning_space, "planning_mode", None)
            if pm is not None:
                planning_mode = str(pm.value if hasattr(pm, "value") else pm)

        # ================================================================
        # Stage 5 — Candidate Set (consume Phase 9.2)
        # ================================================================
        candidate_set: Optional[CandidatePathSet] = inp.candidate_set
        cand_summary = self._build_candidate_summary(candidate_set)

        if candidate_set is None or cand_summary.candidate_count == 0:
            reason_codes.append("NO_FEASIBLE_CANDIDATE")
            output = self._make_output(
                frame_id=frame_id,
                now=now,
                status=PlannerStatus.NO_FEASIBLE_CANDIDATE,
                planning_allowed=planning_allowed,
                sg_state=sg_state,
                val_status=val_result.status,
                planning_mode=planning_mode,
                candidate_summary=cand_summary,
                degraded=ps_degraded,
                stale=bool(val_result.stale_fields),
                warnings=tuple(warnings),
                reason_codes=tuple(reason_codes),
            )
            snap = self._make_snapshot(output)
            metrics = self._make_metrics(
                frame_id=frame_id,
                now=now,
                latency_ms=(time.perf_counter() - t0) * 1000.0,
                val_latency_ms=val_latency_ms,
                output=output,
                cand_summary=cand_summary,
            )
            self._last_snapshot = snap
            self._state = PlannerState.IDLE
            return output, snap, metrics

        # ================================================================
        # Stage 6 — Dynamic Risk Evaluation (consume Phase 9.3)
        # ================================================================
        risk_set: Optional[PathRiskSet] = inp.risk_set
        risk_summary, selected_id = self._evaluate_risk(
            candidate_set, risk_set, warnings, reason_codes
        )

        # ================================================================
        # Stage 7 — Replanning State (consume Phase 9.4)
        # ================================================================
        replan_summary = self._build_replan_summary(inp.replanning_result)
        replanning_required = replan_summary.replanning_required

        # ================================================================
        # Determine final pipeline status
        # ================================================================
        overall_degraded = ps_degraded or bool(val_result.stale_fields)

        if risk_summary.all_candidates_high_risk:
            if replanning_required:
                status = PlannerStatus.REPLAN_REQUIRED
            else:
                status = PlannerStatus.BLOCKED
            reason_codes.append("ALL_CANDIDATES_HIGH_RISK")
        elif replanning_required:
            status = PlannerStatus.REPLAN_REQUIRED
            reason_codes.append("REPLAN_REQUIRED")
        elif overall_degraded:
            status = PlannerStatus.DEGRADED
            reason_codes.append("DEGRADED_INPUT")
        else:
            status = PlannerStatus.PLAN_AVAILABLE

        # If selection is disabled or no valid selection exists
        if not self._cfg.allow_selection:
            selected_id = NOT_AVAILABLE

        # ================================================================
        # Build output
        # ================================================================
        output = self._make_output(
            frame_id=frame_id,
            now=now,
            status=status,
            planning_allowed=planning_allowed,
            sg_state=sg_state,
            val_status=val_result.status,
            planning_mode=planning_mode,
            candidate_summary=cand_summary,
            risk_summary=risk_summary,
            replan_summary=replan_summary,
            selected_id=selected_id,
            replanning_required=replanning_required,
            degraded=overall_degraded,
            stale=bool(val_result.stale_fields),
            warnings=tuple(warnings),
            reason_codes=tuple(set(reason_codes)),  # deduplicate, order stable via set
        )

        # Validate output before returning
        out_val = self._validator.validate_output(output)
        if not out_val.is_valid:
            for e in out_val.errors:
                warnings.append(f"OUTPUT_VALIDATION: {e}")

        latency_ms = (time.perf_counter() - t0) * 1000.0
        snap = self._make_snapshot(output)
        metrics = self._make_metrics(
            frame_id=frame_id,
            now=now,
            latency_ms=latency_ms,
            val_latency_ms=val_latency_ms,
            output=output,
            cand_summary=cand_summary,
            risk_summary=risk_summary,
            replan_summary=replan_summary,
        )
        self._last_snapshot = snap
        self._state = PlannerState.IDLE
        return output, snap, metrics

    # ------------------------------------------------------------------
    # Stage helpers
    # ------------------------------------------------------------------

    def _build_candidate_summary(
        self,
        candidate_set: Optional[CandidatePathSet],
    ) -> CandidateSummary:
        if candidate_set is None:
            return CandidateSummary()

        candidates: Sequence[CandidatePath] = list(
            getattr(candidate_set, "candidates", None)
            or getattr(candidate_set, "_candidates", ())
        )
        total = len(candidates)
        valid = sum(1 for c in candidates if _is_candidate_valid(c))
        invalid = total - valid

        gen_status = getattr(candidate_set, "generation_status", NOT_AVAILABLE)
        gen_status_str = (
            gen_status.value if hasattr(gen_status, "value") else str(gen_status)
        )
        coord = getattr(candidate_set, "coordinate_frame", NOT_AVAILABLE) or NOT_AVAILABLE
        planning_ok = bool(getattr(candidate_set, "planning_allowed", True))

        return CandidateSummary(
            candidate_count=total,
            valid_candidate_count=valid,
            invalid_candidate_count=invalid,
            generation_status=gen_status_str,
            coordinate_frame=coord,
            planning_allowed=planning_ok,
        )

    def _evaluate_risk(
        self,
        candidate_set: CandidatePathSet,
        risk_set: Optional[PathRiskSet],
        warnings: List[str],
        reason_codes: List[str],
    ) -> Tuple[RiskSummary, str]:
        """
        Build RiskSummary and select the best candidate id.

        Selection is deterministic:
          1. Eligible = geometrically valid AND risk_score < max_acceptable
          2. Among eligible, pick the one with lowest composite risk score
          3. Tie-break: ascending candidate_id string comparison (stable)

        Returns (RiskSummary, selected_candidate_id).
        """
        candidates: List[CandidatePath] = list(
            getattr(candidate_set, "candidates", None)
            or getattr(candidate_set, "_candidates", ())
        )

        if risk_set is None:
            warnings.append("risk_set is absent; risk evaluation unavailable")
            risk_status = NOT_AVAILABLE
            cand_summary_from_risk = RiskSummary(
                risk_evaluation_count=0,
                risk_status=risk_status,
                all_candidates_high_risk=False,
            )
            # Select without risk info: first valid candidate
            selected_id = self._select_without_risk(candidates)
            return cand_summary_from_risk, selected_id

        rs_status = getattr(risk_set, "status", None)
        rs_status_str = (
            rs_status.value if hasattr(rs_status, "value") else str(rs_status or NOT_AVAILABLE)
        )

        risks: List[CandidatePathRisk] = list(
            getattr(risk_set, "risks", None)
            or getattr(risk_set, "_risks", ())
        )
        n_risks = len(risks)
        high_count = sum(1 for r in risks if _high_risk(getattr(r, "risk_level", RiskLevel.UNKNOWN_RISK)))
        crit_count = sum(1 for r in risks if _critical_risk(getattr(r, "risk_level", RiskLevel.UNKNOWN_RISK)))

        # Build risk index: candidate_id → CandidatePathRisk
        risk_index = {
            str(getattr(r, "candidate_id", "")): r
            for r in risks
            if getattr(r, "candidate_id", None)
        }

        # Dominant risk reason
        dominant_risk_reason = NOT_AVAILABLE
        dom_reasons = [
            str(getattr(r, "dominant_risk_reason", NOT_AVAILABLE))
            for r in risks
            if getattr(r, "dominant_risk_reason", None) not in (None, NOT_AVAILABLE)
        ]
        if dom_reasons:
            dominant_risk_reason = dom_reasons[0]

        # Determine all_candidates_high_risk
        # (only meaningful when we have risk evaluations)
        valid_candidates = [c for c in candidates if _is_candidate_valid(c)]
        all_high_risk = False
        lowest_risk_id = NOT_AVAILABLE

        if n_risks > 0 and valid_candidates:
            eligible = []
            for c in valid_candidates:
                cid = str(getattr(c, "candidate_id", ""))
                r = risk_index.get(cid)
                if r is None:
                    continue
                score = _risk_score(r)
                if score < self._cfg.max_acceptable_risk_score:
                    eligible.append((score, cid, c))

            if not eligible:
                all_high_risk = True
                reason_codes.append("ALL_CANDIDATES_HIGH_RISK")
            else:
                # Sort: ascending score, then ascending cid for stable tie-break
                eligible.sort(key=lambda x: (x[0], x[1]))
                lowest_risk_id = eligible[0][1]

        elif valid_candidates:
            # No risk evaluations available — select first valid
            lowest_risk_id = self._select_without_risk(valid_candidates)

        elif candidates:
            # All candidates invalid geometry
            all_high_risk = True

        return (
            RiskSummary(
                risk_evaluation_count=n_risks,
                high_risk_candidate_count=high_count,
                critical_risk_candidate_count=crit_count,
                all_candidates_high_risk=all_high_risk,
                lowest_risk_candidate_id=lowest_risk_id,
                risk_status=rs_status_str,
                dominant_risk_reason=dominant_risk_reason,
            ),
            lowest_risk_id,
        )

    def _select_without_risk(self, candidates: List[CandidatePath]) -> str:
        """
        Select the first valid candidate by ascending candidate_id when risk data
        is unavailable.  Deterministic.
        """
        valid = [c for c in candidates if _is_candidate_valid(c)]
        if not valid:
            return NOT_AVAILABLE
        valid.sort(key=lambda c: str(getattr(c, "candidate_id", "")))
        return str(getattr(valid[0], "candidate_id", NOT_AVAILABLE))

    def _build_replan_summary(
        self,
        replan_result: Optional[ReplanningDecisionResult],
    ) -> ReplanSummary:
        if replan_result is None:
            return ReplanSummary()

        req = getattr(replan_result, "request", None)
        if req is None:
            return ReplanSummary()

        decision = getattr(req, "decision", None)
        decision_str = (
            decision.value if hasattr(decision, "value") else str(decision or NOT_AVAILABLE)
        )
        urgency = getattr(req, "urgency", None)
        urgency_str = (
            urgency.value if hasattr(urgency, "value") else str(urgency or NOT_AVAILABLE)
        )
        dom_raw = getattr(req, "dominant_reason", NOT_AVAILABLE)
        dominant = (
            dom_raw.value if hasattr(dom_raw, "value") else str(dom_raw or NOT_AVAILABLE)
        )
        reason_codes_raw = getattr(req, "reason_codes", ()) or ()
        codes = tuple(
            str(rc.value if hasattr(rc, "value") else rc)
            for rc in reason_codes_raw
        )
        sg = str(getattr(req, "safety_gate_state", NOT_AVAILABLE) or NOT_AVAILABLE)

        replanning_required = decision in (
            ReplanningDecision.REPLAN_REQUIRED,
            ReplanningDecision.REPLAN_REQUESTED,
            ReplanningDecision.DEGRADED_REPLAN,
        )

        return ReplanSummary(
            replanning_required=replanning_required,
            replanning_decision=decision_str,
            replanning_urgency=urgency_str,
            dominant_reason=dominant,
            reason_codes=codes,
            safety_gate_state=sg,
        )

    # ------------------------------------------------------------------
    # Output factories
    # ------------------------------------------------------------------

    def _make_output(
        self,
        frame_id: int,
        now: float,
        status: PlannerStatus,
        planning_allowed: bool,
        sg_state: str,
        val_status: InputValidationStatus,
        planning_mode: str = NOT_AVAILABLE,
        candidate_summary: Optional[CandidateSummary] = None,
        risk_summary: Optional[RiskSummary] = None,
        replan_summary: Optional[ReplanSummary] = None,
        selected_id: str = NOT_AVAILABLE,
        replanning_required: bool = False,
        degraded: bool = True,
        stale: bool = False,
        warnings: Tuple[str, ...] = (),
        reason_codes: Tuple[str, ...] = (),
        validation_errors: Tuple[str, ...] = (),
    ) -> PlannerOutput:
        cs = candidate_summary or CandidateSummary()
        rs = risk_summary or RiskSummary()
        rps = replan_summary or ReplanSummary()

        # Confidence: invert relationship with degraded/stale/risk
        confidence = 0.0
        uncertainty = 1.0
        if status == PlannerStatus.PLAN_AVAILABLE:
            confidence = 0.7 if not degraded else 0.4
            uncertainty = 1.0 - confidence

        return PlannerOutput(
            frame_id=frame_id,
            timestamp=now,
            schema_version=PLANNER_SCHEMA_VERSION,
            planning_allowed=planning_allowed,
            safety_gate_state=sg_state,
            planning_status=status,
            planning_mode=planning_mode,
            input_validation_status=val_status,
            candidate_summary=cs,
            risk_summary=rs,
            replan_summary=rps,
            candidate_count=cs.candidate_count,
            candidate_paths_available=cs.valid_candidate_count > 0,
            risk_evaluations_available=rs.risk_evaluation_count > 0,
            selected_candidate_id=(
                selected_id
                if (status == PlannerStatus.PLAN_AVAILABLE and planning_allowed)
                else NOT_AVAILABLE
            ),
            replanning_required=replanning_required,
            active_planning_requirement=(
                rps.replanning_decision if replanning_required else NOT_AVAILABLE
            ),
            confidence=confidence,
            uncertainty=uncertainty,
            degraded=degraded,
            stale=stale,
            reason_codes=tuple(sorted(set(reason_codes))),
            warnings=warnings,
            validation_errors=validation_errors,
        )

    def _make_snapshot(self, output: PlannerOutput) -> PlannerSnapshot:
        return PlannerSnapshot(
            frame_id=output.frame_id,
            timestamp=output.timestamp,
            schema_version=PLANNER_SCHEMA_VERSION,
            planner_status=output.planning_status,
            planning_mode=output.planning_mode,
            safety_gate_state=output.safety_gate_state,
            planning_allowed=output.planning_allowed,
            candidate_count=output.candidate_summary.candidate_count,
            valid_candidate_count=output.candidate_summary.valid_candidate_count,
            risk_evaluated_count=output.risk_summary.risk_evaluation_count,
            high_risk_count=output.risk_summary.high_risk_candidate_count,
            replanning_required=output.replanning_required,
            replanning_decision=output.replan_summary.replanning_decision,
            selected_candidate_id=output.selected_candidate_id,
            confidence=output.confidence,
            uncertainty=output.uncertainty,
            degraded=output.degraded,
            stale=output.stale,
            reason_codes=output.reason_codes,
            warnings=output.warnings,
        )

    def _make_metrics(
        self,
        frame_id: int,
        now: float,
        latency_ms: float,
        val_latency_ms: float,
        output: PlannerOutput,
        cand_summary: Optional[CandidateSummary] = None,
        risk_summary: Optional[RiskSummary] = None,
        replan_summary: Optional[ReplanSummary] = None,
    ) -> PlannerMetrics:
        cs = cand_summary or output.candidate_summary
        rs = risk_summary or output.risk_summary
        rps = replan_summary or output.replan_summary

        return PlannerMetrics(
            frame_id=frame_id,
            timestamp=now,
            planning_latency_ms=latency_ms,
            input_validation_latency_ms=val_latency_ms,
            candidate_count=cs.candidate_count,
            valid_candidate_count=cs.valid_candidate_count,
            invalid_candidate_count=cs.invalid_candidate_count,
            risk_evaluation_count=rs.risk_evaluation_count,
            high_risk_candidate_count=rs.high_risk_candidate_count,
            critical_risk_candidate_count=rs.critical_risk_candidate_count,
            replan_requested=rps.replanning_required,
            replan_required=output.replanning_required,
            replan_reason=rps.dominant_reason,
            planning_success=output.planning_status == PlannerStatus.PLAN_AVAILABLE,
            no_feasible_candidate=output.planning_status == PlannerStatus.NO_FEASIBLE_CANDIDATE,
            safety_blocked=output.planning_status == PlannerStatus.SAFETY_RESTRICTED,
            degraded_planning=output.degraded,
        )

    def _error_output(
        self,
        inp: PlannerInput,
        reason: str,
    ) -> Tuple[PlannerOutput, PlannerSnapshot, PlannerMetrics]:
        frame_id = getattr(inp, "frame_id", 0) or 0
        now = getattr(inp, "timestamp", time.time()) or time.time()
        output = self._make_output(
            frame_id=frame_id,
            now=now,
            status=PlannerStatus.UNKNOWN,
            planning_allowed=False,
            sg_state=NOT_AVAILABLE,
            val_status=InputValidationStatus.INVALID,
            warnings=(reason,),
            reason_codes=("PIPELINE_ERROR",),
        )
        snap = self._make_snapshot(output)
        metrics = self._make_metrics(
            frame_id=frame_id,
            now=now,
            latency_ms=0.0,
            val_latency_ms=0.0,
            output=output,
        )
        self._state = PlannerState.ERROR
        self._last_snapshot = snap
        return output, snap, metrics
