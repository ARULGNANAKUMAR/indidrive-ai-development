"""
IndiDrive AI — Phase 9.6 | Final Planner Integration — Benchmark
=================================================================
Deterministic benchmark suite for the Phase 9.6 integrated planner.

Each scenario is defined by structured PlannerInput data — NOT by
scenario-name logic.  The planner derives its result from the data,
not from if/else on the scenario name.

DO NOT ADD: if scenario_name == "X": return HARDCODED_RESULT
All results must come from actual structured inputs flowing through
the real Phase 9.6 pipeline.

Usage:
    results = PlannerBenchmark().run_all()
    for r in results:
        print(r.to_dict())
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import List, Optional, Tuple

from .planner_types import (
    NOT_AVAILABLE,
    PLANNER_SCHEMA_VERSION,
    PlannerInput,
    PlannerOutput,
    PlannerSnapshot,
    PlannerMetrics,
    PlannerStatus,
)
from .planner_engine import PlannerEngine
from .planner_config import PlannerConfig

# Phase 9.1 types — use the actual field names from planning_space_types.py
from .planning_space_types import (
    PlanningSpace,
    PlanningSpaceStatus,
    PlanningSpaceQuality,
    PlanningHorizon,
    PlanningHorizonValidity,
    SpatialExtent,
    CoordinateFrameInfo,
    DynamicObjectEntry,
    StaticHazardEntry,
    RoadStructureSummary,
    IndianRoadContextSummary,
    EvidenceClass,
)

# Phase 9.2 types
from .candidate_path_types import (
    CandidatePath,
    CandidatePathSet,
    CandidateGenerationStatus,
    CandidateMetadata,
    GeometricValidity,
    BoundaryValidity,
    DrivableSpaceValidity,
    GenerationMethod,
    PathPoint,
)

# Phase 9.3 types
from .path_risk_types import (
    CandidatePathRisk,
    PathRiskSet,
    PathRiskStatus,
    RiskLevel,
    RiskBreakdown,
    RiskReasonCode,
    ObjectRiskContribution,
)

# Phase 9.4 types
from .replanning_types import (
    ReplanningDecision,
    ReplanningUrgency,
    ReplanningDecisionResult,
    ReplanningRequest,
)

# Phase 9.5 types
from .indian_road_planning_types import (
    IndianRoadPlanningResult,
    IndianRoadPlanningConstraints,
    PlanningMode,
    LaneUsageMode,
    NarrowRoadState,
    TrafficContextSummary,
)

__all__ = ["PlannerBenchmark", "BenchmarkResult"]

_T0 = 1_700_000_000.0  # Deterministic base timestamp


# ---------------------------------------------------------------------------
# Benchmark result container
# ---------------------------------------------------------------------------

@dataclass
class BenchmarkResult:
    scenario_id: str = NOT_AVAILABLE
    run_id: str = NOT_AVAILABLE
    planning_status: str = NOT_AVAILABLE
    planning_mode: str = NOT_AVAILABLE
    candidate_count: int = 0
    valid_candidate_count: int = 0
    risk_evaluated_count: int = 0
    replanning_required: bool = False
    replanning_decision: str = NOT_AVAILABLE
    planning_latency_ms: float = 0.0
    degraded: bool = False
    safety_blocked: bool = False
    validation_errors: Tuple[str, ...] = field(default_factory=tuple)
    reason_codes: Tuple[str, ...] = field(default_factory=tuple)
    selected_candidate_id: str = NOT_AVAILABLE

    def to_dict(self) -> dict:
        return {
            "scenario_id": self.scenario_id,
            "run_id": self.run_id,
            "planning_status": self.planning_status,
            "planning_mode": self.planning_mode,
            "candidate_count": self.candidate_count,
            "valid_candidate_count": self.valid_candidate_count,
            "risk_evaluated_count": self.risk_evaluated_count,
            "replanning_required": self.replanning_required,
            "replanning_decision": self.replanning_decision,
            "planning_latency_ms": round(self.planning_latency_ms, 3),
            "degraded": self.degraded,
            "safety_blocked": self.safety_blocked,
            "validation_errors": list(self.validation_errors),
            "reason_codes": list(self.reason_codes),
            "selected_candidate_id": self.selected_candidate_id,
        }


# ---------------------------------------------------------------------------
# Scenario builder helpers — use real dataclass field names
# ---------------------------------------------------------------------------

def _make_quality(
    confidence: float = 0.75,
    uncertainty: float = 0.25,
    degraded: bool = False,
    partial: bool = False,
) -> PlanningSpaceQuality:
    return PlanningSpaceQuality(
        overall_confidence=confidence,
        overall_uncertainty=uncertainty,
        completeness=0.85,
        is_degraded=degraded,
        is_partial=partial,
        world_model_available=True,
        planning_context_available=True,
        road_info_available=True,
        dynamic_objects_available=True,
        static_hazards_available=True,
    )



def _make_horizon(distance_m: float = 50.0) -> PlanningHorizon:
    return PlanningHorizon(
        longitudinal_m=distance_m,
        temporal_horizon_s=5.0,
        validity=PlanningHorizonValidity.VALID,
    )


def _make_extent(
    left_m: float = 2.0,
    right_m: float = -2.0,
    width_m: float = 4.0,
) -> SpatialExtent:
    return SpatialExtent(
        left_m=left_m,
        right_m=right_m,
        road_width_m=width_m,
    )


def _make_road_structure(
    has_lanes: bool = True,
    lane_confidence: float = 0.7,
) -> RoadStructureSummary:
    return RoadStructureSummary(
        marking_state="MARKED" if has_lanes else "UNMARKED",
        lane_count=2 if has_lanes else 0,
        lane_width_m=3.5 if has_lanes else None,
        lane_info_available=has_lanes,
        confidence=lane_confidence if has_lanes else 0.1,
        uncertainty=1.0 - (lane_confidence if has_lanes else 0.1),
        is_degraded=not has_lanes,
    )



def _make_indian_context(
    traffic_density: str = "MEDIUM",
    cattle: bool = False,
    vru: bool = False,
    market_like: bool = False,
    intersection: str = "NO_INTERSECTION",
    road_type: str = "URBAN_ROAD",
    confidence: float = 0.7,
    degraded: bool = False,
) -> IndianRoadContextSummary:
    return IndianRoadContextSummary(
        available=True,
        road_type=road_type,
        traffic_density=traffic_density,
        vulnerable_road_users=vru,
        cattle_present=cattle,
        roadside_activity="HIGH" if market_like else "LOW",
        market_like_activity=market_like,
        intersection_context=intersection,
        road_complexity="HIGH" if (cattle or vru or market_like) else "LOW",
        context_confidence=confidence,
        context_uncertainty=1.0 - confidence,
        is_degraded=degraded,
    )



def _make_dynamic_obj(
    obj_id: str,
    obj_type: str,
    x: float,
    y: float,
    vx: float = 0.0,
    vy: float = 0.0,
    confidence: float = 0.75,
) -> DynamicObjectEntry:
    return DynamicObjectEntry(
        object_id=obj_id,
        object_type=obj_type,
        position_x=x,
        position_y=y,
        velocity_x=vx,
        velocity_y=vy,
        confidence=confidence,
        uncertainty=1.0 - confidence,
        evidence=EvidenceClass.OBSERVED,
    )


def _make_static_hazard(
    hazard_id: str,
    hazard_type: str,
    x: float,
    y: float,
    width_m: float = 0.6,
    confidence: float = 0.8,
) -> StaticHazardEntry:
    return StaticHazardEntry(
        hazard_id=hazard_id,
        hazard_type=hazard_type,
        position_x=x,
        position_y=y,
        approx_width_m=width_m,
        confidence=confidence,
        uncertainty=1.0 - confidence,
        evidence=EvidenceClass.OBSERVED,
        in_drivable_area=True,
        severity="MODERATE",
        drivability_impact="PARTIAL",
    )


def _make_planning_space(
    frame_id: int,
    ts: float,
    planning_allowed: bool = True,
    sg_state: str = "CLEAR",
    quality: Optional[PlanningSpaceQuality] = None,
    horizon: Optional[PlanningHorizon] = None,
    extent: Optional[SpatialExtent] = None,
    road_structure: Optional[RoadStructureSummary] = None,
    indian_context: Optional[IndianRoadContextSummary] = None,
    dynamic_objects: Tuple[DynamicObjectEntry, ...] = (),
    static_hazards: Tuple[StaticHazardEntry, ...] = (),
    planning_mode: str = "DRIVABLE_SPACE",
) -> PlanningSpace:
    return PlanningSpace(
        space_id=f"bench_ps_{frame_id}",
        frame_id=frame_id,
        timestamp=ts,
        coordinate_frame=CoordinateFrameInfo(),
        status=PlanningSpaceStatus.OK,
        planning_allowed=planning_allowed,
        safety_gate_state=sg_state,
        quality=quality or _make_quality(),
        horizon=horizon or _make_horizon(),
        spatial_extent=extent or _make_extent(),
        road_structure=road_structure or _make_road_structure(),
        indian_road_context=indian_context or _make_indian_context(),
        _dynamic_objects=dynamic_objects,
        _static_hazards=static_hazards,
        planning_mode=planning_mode,
    )


def _make_candidate(
    cid: str,
    lateral_offset: float = 0.0,
    valid: bool = True,
) -> CandidatePath:
    pts = tuple(
        PathPoint(
            x=float(i * 2),
            y=lateral_offset,
            z=0.0,
            longitudinal_s=float(i * 2),
            lateral_offset_m=lateral_offset,
            heading=0.0,
            curvature=0.0,
        )
        for i in range(6)
    )
    geo = GeometricValidity.VALID if valid else GeometricValidity.INVALID
    return CandidatePath(
        candidate_id=cid,
        frame_id=0,
        timestamp=_T0,
        coordinate_frame="VEHICLE",
        _waypoints=pts,
        longitudinal_extent_m=10.0,
        lateral_offset_m=lateral_offset,
        generation_method=GenerationMethod.LATERAL_OFFSET,
        geometric_validity=geo,
        boundary_validity=BoundaryValidity.VALID if valid else BoundaryValidity.INVALID,
        drivable_space_validity=DrivableSpaceValidity.VALID if valid else DrivableSpaceValidity.INVALID,
        metadata=CandidateMetadata(),
    )


def _make_candidate_set(
    frame_id: int,
    ts: float,
    candidates: List[CandidatePath],
    planning_allowed: bool = True,
    sg_state: str = "CLEAR",
) -> CandidatePathSet:
    return CandidatePathSet(
        set_id=f"bench_cs_{frame_id}",
        frame_id=frame_id,
        timestamp=ts,
        coordinate_frame="VEHICLE",
        planning_space_ref=f"bench_ps_{frame_id}",
        safety_gate_state=sg_state,
        planning_allowed=planning_allowed,
        _candidates=tuple(candidates),
        generation_status=CandidateGenerationStatus.CANDIDATES_GENERATED,
        generation_reason="benchmark",
        schema_version="9.2",
    )


def _make_risk(
    cid: str,
    score: float,
    level: RiskLevel,
    reason: RiskReasonCode = RiskReasonCode.NO_DYNAMIC_OBJECTS,
) -> CandidatePathRisk:
    breakdown = RiskBreakdown(
        clearance_risk=round(score * 0.3, 4),
        ttc_risk=round(score * 0.3, 4),
        trajectory_intersection_risk=round(score * 0.2, 4),
        uncertainty_risk=round(score * 0.1, 4),
        vulnerable_user_risk=0.0,
        road_hazard_risk=round(score * 0.1, 4),
    )
    return CandidatePathRisk(
        candidate_id=cid,
        frame_id=0,
        timestamp=_T0,
        coordinate_frame="VEHICLE",
        total_risk=score,
        risk_level=level,
        breakdown=breakdown,
        dominant_risk_reason=str(reason.value if hasattr(reason, "value") else reason),
        confidence=0.75,
        uncertainty=0.25,
        degraded=False,
    )


def _make_risk_set(
    frame_id: int,
    ts: float,
    risks: List[CandidatePathRisk],
) -> PathRiskSet:
    return PathRiskSet(
        set_id=f"bench_rs_{frame_id}",
        frame_id=frame_id,
        timestamp=ts,
        coordinate_frame="VEHICLE",
        status=PathRiskStatus.EVALUATED,
        status_reason="benchmark",
        _risks=tuple(risks),
        schema_version="9.3",
    )


def _make_replan_result(
    decision: ReplanningDecision = ReplanningDecision.NO_REPLAN,
    urgency: ReplanningUrgency = ReplanningUrgency.NORMAL,
    sg_state: str = "CLEAR",
) -> ReplanningDecisionResult:
    from .replanning_types import ReplanningReasonCode, CooldownState, ChangeMagnitudes
    req = ReplanningRequest(
        decision=decision,
        urgency=urgency,
        safety_gate_state=sg_state,
        planning_allowed=(decision == ReplanningDecision.NO_REPLAN),
        reason_codes=(),
        dominant_reason=ReplanningReasonCode.NO_ACTIVE_PATH,
        cooldown_state=CooldownState.INACTIVE,
        change_magnitudes=ChangeMagnitudes(),
    )
    return ReplanningDecisionResult(request=req, context=None)


def _make_indian_result(
    mode: PlanningMode,
    narrow: NarrowRoadState = NarrowRoadState.NOT_NARROW,
    cattle: bool = False,
    vru: bool = False,
    pedestrians: bool = False,
    motorcycles: bool = False,
    market_like: bool = False,
    wrong_side: bool = False,
    max_lateral_m: float = 1.5,
    road_width_m: Optional[float] = None,
) -> IndianRoadPlanningResult:
    tc = TrafficContextSummary(
        has_cattle=cattle,
        has_vulnerable_road_users=vru,
        has_pedestrians=pedestrians,
        has_motorcycles=motorcycles,
        market_like=market_like,
        has_wrong_side_traffic=wrong_side,
        high_density=(market_like or (pedestrians and motorcycles)),
        confidence=0.7,
    )
    lane_mode = (
        LaneUsageMode.STRICT
        if mode == PlanningMode.HIGHWAY
        else LaneUsageMode.IGNORE
    )
    constraints = IndianRoadPlanningConstraints(
        planning_mode=mode,
        lane_usage_mode=lane_mode,
        narrow_road_state=narrow,
        max_lateral_offset_m=max_lateral_m,
        drivable_region_required=True,
        traffic_context=tc,
        cattle_clearance_margin_m=1.5 if cattle else 0.0,
        vulnerable_user_margin_m=1.0 if (vru or pedestrians) else 0.0,
        wrong_side_margin_m=0.8 if wrong_side else 0.0,
        confidence=0.7,
        uncertainty=0.3,
        degraded=False,
        road_width_m=road_width_m,
    )
    return IndianRoadPlanningResult(
        constraints=constraints,
        status="OK",
        warnings=(),
    )


# ---------------------------------------------------------------------------
# PlannerBenchmark
# ---------------------------------------------------------------------------

class PlannerBenchmark:
    """
    Deterministic benchmark suite for the Phase 9.6 integrated planner.

    Exercises 11 required Indian-road scenarios.
    Results come from structured data, NOT from scenario-name if/else logic.
    """

    def __init__(self, config: Optional[PlannerConfig] = None) -> None:
        self._engine = PlannerEngine(config)

    def run_all(self) -> List[BenchmarkResult]:
        """Run all 11 required benchmark scenarios and return results."""
        scenarios = [
            self._scenario_village_unmarked,
            self._scenario_narrow_village,
            self._scenario_dense_market,
            self._scenario_highway_merge,
            self._scenario_unsignalized_intersection,
            self._scenario_cattle_crossing,
            self._scenario_wrong_side_traffic,
            self._scenario_damaged_narrow_road,
            self._scenario_pedestrian_heavy_market,
            self._scenario_mixed_motorcycle_traffic,
            self._scenario_construction_zone,
        ]
        results = []
        for fn in scenarios:
            self._engine.reset()
            sid, inp = fn()
            t0 = time.perf_counter()
            output, snap, metrics = self._engine.run(inp)
            latency = (time.perf_counter() - t0) * 1000.0
            results.append(self._make_result(sid, output, snap, latency))
        return results

    def run_scenario(self, scenario_id: str) -> BenchmarkResult:
        """Run a single named scenario."""
        mapping = {
            "village_unmarked": self._scenario_village_unmarked,
            "narrow_village": self._scenario_narrow_village,
            "dense_market": self._scenario_dense_market,
            "highway_merge": self._scenario_highway_merge,
            "unsignalized_intersection": self._scenario_unsignalized_intersection,
            "cattle_crossing": self._scenario_cattle_crossing,
            "wrong_side_traffic": self._scenario_wrong_side_traffic,
            "damaged_narrow_road": self._scenario_damaged_narrow_road,
            "pedestrian_heavy_market": self._scenario_pedestrian_heavy_market,
            "mixed_motorcycle_traffic": self._scenario_mixed_motorcycle_traffic,
            "construction_zone": self._scenario_construction_zone,
        }
        fn = mapping.get(scenario_id)
        if fn is None:
            raise ValueError(f"Unknown scenario_id: {scenario_id!r}")
        self._engine.reset()
        sid, inp = fn()
        t0 = time.perf_counter()
        output, snap, metrics = self._engine.run(inp)
        latency = (time.perf_counter() - t0) * 1000.0
        return self._make_result(sid, output, snap, latency)

    # ------------------------------------------------------------------
    # Scenario 1: Village unmarked road
    # ------------------------------------------------------------------

    def _scenario_village_unmarked(self) -> Tuple[str, PlannerInput]:
        fid, ts = 1001, _T0 + 1.0
        objs = (
            _make_dynamic_obj("vru_1", "PEDESTRIAN", 15.0, 0.8, 0.3, 0.1, 0.7),
            _make_dynamic_obj("moto_1", "MOTORCYCLE", 20.0, -0.5, 5.0, 0.2, 0.8),
        )
        ps = _make_planning_space(
            fid, ts, planning_mode="DRIVABLE_SPACE",
            extent=_make_extent(2.0, -2.0, 4.0),
            road_structure=_make_road_structure(has_lanes=False, lane_confidence=0.0),
            indian_context=_make_indian_context(
                road_type="VILLAGE_ROAD", traffic_density="MEDIUM",
                vru=True, market_like=False,
            ),
            dynamic_objects=objs,
        )
        cands = [_make_candidate("c1_center", 0.0), _make_candidate("c1_left", 0.5),
                 _make_candidate("c1_right", -0.5)]
        cs = _make_candidate_set(fid, ts, cands)
        rs = _make_risk_set(fid, ts, [
            _make_risk("c1_center", 0.25, RiskLevel.LOW_RISK),
            _make_risk("c1_left", 0.35, RiskLevel.LOW_RISK),
            _make_risk("c1_right", 0.20, RiskLevel.LOW_RISK),
        ])
        rr = _make_replan_result(ReplanningDecision.NO_REPLAN)
        ir = _make_indian_result(PlanningMode.DRIVABLE_SPACE, vru=True)
        return "village_unmarked", PlannerInput(
            frame_id=fid, timestamp=ts,
            planning_space=ps, candidate_set=cs, risk_set=rs,
            replanning_result=rr, indian_road_result=ir,
        )

    # ------------------------------------------------------------------
    # Scenario 2: Narrow village road
    # ------------------------------------------------------------------

    def _scenario_narrow_village(self) -> Tuple[str, PlannerInput]:
        fid, ts = 1002, _T0 + 2.0
        ps = _make_planning_space(
            fid, ts, planning_mode="NARROW_ROAD",
            extent=_make_extent(1.4, -1.4, 2.8),
            road_structure=_make_road_structure(has_lanes=False, lane_confidence=0.1),
            indian_context=_make_indian_context(road_type="VILLAGE_ROAD", traffic_density="LOW"),
            quality=_make_quality(0.6, 0.4),
        )
        cands = [_make_candidate("c2_center", 0.0)]
        cs = _make_candidate_set(fid, ts, cands)
        rs = _make_risk_set(fid, ts, [_make_risk("c2_center", 0.25, RiskLevel.LOW_RISK)])
        rr = _make_replan_result(ReplanningDecision.NO_REPLAN)
        ir = _make_indian_result(
            PlanningMode.NARROW_ROAD, narrow=NarrowRoadState.NARROW,
            max_lateral_m=0.4, road_width_m=2.8,
        )
        return "narrow_village", PlannerInput(
            frame_id=fid, timestamp=ts,
            planning_space=ps, candidate_set=cs, risk_set=rs,
            replanning_result=rr, indian_road_result=ir,
        )

    # ------------------------------------------------------------------
    # Scenario 3: Dense market
    # ------------------------------------------------------------------

    def _scenario_dense_market(self) -> Tuple[str, PlannerInput]:
        fid, ts = 1003, _T0 + 3.0
        objs = tuple(
            _make_dynamic_obj(f"mkt_ped_{i}", "PEDESTRIAN",
                              float(4 + i * 3), float(i % 2 - 0.5),
                              0.5, 0.2, 0.7)
            for i in range(4)
        )
        ps = _make_planning_space(
            fid, ts, planning_mode="MIXED_TRAFFIC",
            dynamic_objects=objs,
            indian_context=_make_indian_context(
                road_type="URBAN_ROAD", traffic_density="HIGH",
                vru=True, market_like=True,
            ),
        )
        cands = [_make_candidate("c3_center", 0.0), _make_candidate("c3_left", 0.5)]
        cs = _make_candidate_set(fid, ts, cands)
        rs = _make_risk_set(fid, ts, [
            _make_risk("c3_center", 0.42, RiskLevel.MODERATE_RISK, RiskReasonCode.LOW_CLEARANCE),
            _make_risk("c3_left", 0.52, RiskLevel.MODERATE_RISK, RiskReasonCode.VULNERABLE_USER_NEAR_PATH),
        ])
        rr = _make_replan_result(ReplanningDecision.NO_REPLAN)
        ir = _make_indian_result(
            PlanningMode.MIXED_TRAFFIC, vru=True, pedestrians=True, market_like=True,
        )
        return "dense_market", PlannerInput(
            frame_id=fid, timestamp=ts,
            planning_space=ps, candidate_set=cs, risk_set=rs,
            replanning_result=rr, indian_road_result=ir,
        )

    # ------------------------------------------------------------------
    # Scenario 4: Highway merge
    # ------------------------------------------------------------------

    def _scenario_highway_merge(self) -> Tuple[str, PlannerInput]:
        fid, ts = 1004, _T0 + 4.0
        objs = (_make_dynamic_obj("hw_car_1", "CAR", 25.0, -3.5, 18.0, 0.5, 0.9),)
        ps = _make_planning_space(
            fid, ts, planning_mode="HIGHWAY",
            extent=_make_extent(3.5, -3.5, 7.0),
            road_structure=_make_road_structure(has_lanes=True, lane_confidence=0.92),
            indian_context=_make_indian_context(road_type="HIGHWAY", traffic_density="MEDIUM"),
            dynamic_objects=objs,
        )
        cands = [_make_candidate("c4_center", 0.0), _make_candidate("c4_left", 1.5)]
        cs = _make_candidate_set(fid, ts, cands)
        rs = _make_risk_set(fid, ts, [
            _make_risk("c4_center", 0.30, RiskLevel.LOW_RISK),
            _make_risk("c4_left", 0.60, RiskLevel.MODERATE_RISK, RiskReasonCode.LOW_TTC),
        ])
        rr = _make_replan_result(ReplanningDecision.NO_REPLAN)
        ir = _make_indian_result(PlanningMode.HIGHWAY)
        return "highway_merge", PlannerInput(
            frame_id=fid, timestamp=ts,
            planning_space=ps, candidate_set=cs, risk_set=rs,
            replanning_result=rr, indian_road_result=ir,
        )

    # ------------------------------------------------------------------
    # Scenario 5: Unsignalized intersection
    # ------------------------------------------------------------------

    def _scenario_unsignalized_intersection(self) -> Tuple[str, PlannerInput]:
        fid, ts = 1005, _T0 + 5.0
        objs = (
            _make_dynamic_obj("intx_car_1", "CAR", 15.0, 5.0, 2.0, -4.0, 0.75),
            _make_dynamic_obj("intx_moto_1", "MOTORCYCLE", 10.0, -3.0, 3.0, 5.0, 0.65),
        )
        ps = _make_planning_space(
            fid, ts, planning_mode="INTERSECTION",
            dynamic_objects=objs,
            indian_context=_make_indian_context(
                road_type="INTERSECTION", traffic_density="HIGH",
                intersection="UNSIGNALIZED_INTERSECTION",
            ),
            quality=_make_quality(0.60, 0.40),
        )
        cands = [_make_candidate("c5_center", 0.0), _make_candidate("c5_right", -0.5)]
        cs = _make_candidate_set(fid, ts, cands)
        rs = _make_risk_set(fid, ts, [
            _make_risk("c5_center", 0.52, RiskLevel.MODERATE_RISK,
                       RiskReasonCode.TRAJECTORY_INTERSECTION),
            _make_risk("c5_right", 0.40, RiskLevel.MODERATE_RISK, RiskReasonCode.LOW_TTC),
        ])
        rr = _make_replan_result(ReplanningDecision.NO_REPLAN)
        ir = _make_indian_result(PlanningMode.INTERSECTION)
        return "unsignalized_intersection", PlannerInput(
            frame_id=fid, timestamp=ts,
            planning_space=ps, candidate_set=cs, risk_set=rs,
            replanning_result=rr, indian_road_result=ir,
        )

    # ------------------------------------------------------------------
    # Scenario 6: Sudden cattle crossing
    # ------------------------------------------------------------------

    def _scenario_cattle_crossing(self) -> Tuple[str, PlannerInput]:
        fid, ts = 1006, _T0 + 6.0
        objs = (
            _make_dynamic_obj("cattle_1", "CATTLE", 12.0, 0.5, 0.3, -1.2, 0.55),
            _make_dynamic_obj("cattle_2", "CATTLE", 14.0, -0.3, 0.2, -1.0, 0.50),
        )
        ps = _make_planning_space(
            fid, ts, planning_mode="MIXED_TRAFFIC",
            dynamic_objects=objs,
            indian_context=_make_indian_context(
                road_type="VILLAGE_ROAD", traffic_density="LOW", cattle=True,
            ),
        )
        cands = [_make_candidate("c6_center", 0.0), _make_candidate("c6_left", 1.0)]
        cs = _make_candidate_set(fid, ts, cands)
        # Both paths have HIGH risk from cattle (score > max_acceptable_risk 0.80)
        rs = _make_risk_set(fid, ts, [
            _make_risk("c6_center", 0.85, RiskLevel.HIGH_RISK, RiskReasonCode.LOW_CLEARANCE),
            _make_risk("c6_left", 0.82, RiskLevel.HIGH_RISK, RiskReasonCode.LOW_CLEARANCE),
        ])
        rr = _make_replan_result(ReplanningDecision.REPLAN_REQUIRED, ReplanningUrgency.URGENT)
        ir = _make_indian_result(PlanningMode.MIXED_TRAFFIC, cattle=True, max_lateral_m=0.75)
        return "cattle_crossing", PlannerInput(
            frame_id=fid, timestamp=ts,
            planning_space=ps, candidate_set=cs, risk_set=rs,
            replanning_result=rr, indian_road_result=ir,
        )

    # ------------------------------------------------------------------
    # Scenario 7: Wrong-side traffic
    # ------------------------------------------------------------------

    def _scenario_wrong_side_traffic(self) -> Tuple[str, PlannerInput]:
        fid, ts = 1007, _T0 + 7.0
        objs = (_make_dynamic_obj("wrong_car_1", "CAR", 20.0, 0.0, -8.0, 0.0, 0.85),)
        ps = _make_planning_space(
            fid, ts, planning_mode="DRIVABLE_SPACE",
            dynamic_objects=objs,
            indian_context=_make_indian_context(road_type="URBAN_ROAD", traffic_density="LOW"),
        )
        cands = [_make_candidate("c7_center", 0.0), _make_candidate("c7_right", -1.0)]
        cs = _make_candidate_set(fid, ts, cands)
        rs = _make_risk_set(fid, ts, [
            _make_risk("c7_center", 0.72, RiskLevel.HIGH_RISK, RiskReasonCode.LOW_TTC),
            _make_risk("c7_right", 0.40, RiskLevel.MODERATE_RISK, RiskReasonCode.LOW_CLEARANCE),
        ])
        rr = _make_replan_result(ReplanningDecision.REPLAN_REQUESTED, ReplanningUrgency.ELEVATED)
        ir = _make_indian_result(PlanningMode.DRIVABLE_SPACE, wrong_side=True)
        return "wrong_side_traffic", PlannerInput(
            frame_id=fid, timestamp=ts,
            planning_space=ps, candidate_set=cs, risk_set=rs,
            replanning_result=rr, indian_road_result=ir,
        )

    # ------------------------------------------------------------------
    # Scenario 8: Damaged narrow road
    # ------------------------------------------------------------------

    def _scenario_damaged_narrow_road(self) -> Tuple[str, PlannerInput]:
        fid, ts = 1008, _T0 + 8.0
        hazards = (_make_static_hazard("pothole_1", "POTHOLE", 8.0, 0.3, 0.6),)
        ps = _make_planning_space(
            fid, ts, planning_mode="NARROW_ROAD",
            extent=_make_extent(1.2, -1.2, 2.4),
            road_structure=_make_road_structure(has_lanes=False),
            indian_context=_make_indian_context(road_type="VILLAGE_ROAD", traffic_density="LOW"),
            static_hazards=hazards,
            quality=_make_quality(0.55, 0.45),
        )
        cands = [_make_candidate("c8_center", 0.0), _make_candidate("c8_left", 0.4)]
        cs = _make_candidate_set(fid, ts, cands)
        rs = _make_risk_set(fid, ts, [
            _make_risk("c8_center", 0.58, RiskLevel.MODERATE_RISK, RiskReasonCode.ROAD_HAZARD_INTERACTION),
            _make_risk("c8_left", 0.32, RiskLevel.LOW_RISK),
        ])
        rr = _make_replan_result(ReplanningDecision.NO_REPLAN)
        ir = _make_indian_result(
            PlanningMode.NARROW_ROAD, narrow=NarrowRoadState.VERY_NARROW,
            max_lateral_m=0.0, road_width_m=2.4,
        )
        return "damaged_narrow_road", PlannerInput(
            frame_id=fid, timestamp=ts,
            planning_space=ps, candidate_set=cs, risk_set=rs,
            replanning_result=rr, indian_road_result=ir,
        )

    # ------------------------------------------------------------------
    # Scenario 9: Pedestrian-heavy market
    # ------------------------------------------------------------------

    def _scenario_pedestrian_heavy_market(self) -> Tuple[str, PlannerInput]:
        fid, ts = 1009, _T0 + 9.0
        objs = tuple(
            _make_dynamic_obj(f"ped_{i}", "PEDESTRIAN",
                              float(4 + i * 2), float((i % 3) - 1.0), 0.8, 0.3, 0.7)
            for i in range(6)
        )
        ps = _make_planning_space(
            fid, ts, planning_mode="MIXED_TRAFFIC",
            dynamic_objects=objs,
            indian_context=_make_indian_context(
                traffic_density="HIGH", vru=True, market_like=True,
            ),
        )
        cands = [
            _make_candidate("c9_center", 0.0),
            _make_candidate("c9_left", 0.5),
            _make_candidate("c9_right", -0.5),
        ]
        cs = _make_candidate_set(fid, ts, cands)
        rs = _make_risk_set(fid, ts, [
            _make_risk("c9_center", 0.55, RiskLevel.MODERATE_RISK, RiskReasonCode.VULNERABLE_USER_NEAR_PATH),
            _make_risk("c9_left", 0.70, RiskLevel.HIGH_RISK, RiskReasonCode.VULNERABLE_USER_NEAR_PATH),
            _make_risk("c9_right", 0.38, RiskLevel.LOW_RISK),
        ])
        rr = _make_replan_result(ReplanningDecision.NO_REPLAN)
        ir = _make_indian_result(
            PlanningMode.MIXED_TRAFFIC, vru=True, pedestrians=True, market_like=True,
        )
        return "pedestrian_heavy_market", PlannerInput(
            frame_id=fid, timestamp=ts,
            planning_space=ps, candidate_set=cs, risk_set=rs,
            replanning_result=rr, indian_road_result=ir,
        )

    # ------------------------------------------------------------------
    # Scenario 10: Mixed motorcycle traffic
    # ------------------------------------------------------------------

    def _scenario_mixed_motorcycle_traffic(self) -> Tuple[str, PlannerInput]:
        fid, ts = 1010, _T0 + 10.0
        objs = (
            _make_dynamic_obj("moto_1", "MOTORCYCLE", 10.0, 0.8, 6.0, -0.5, 0.80),
            _make_dynamic_obj("moto_2", "MOTORCYCLE", 15.0, -0.5, 7.0, 0.4, 0.75),
            _make_dynamic_obj("moto_3", "MOTORCYCLE", 20.0, 0.2, 5.0, -0.3, 0.70),
        )
        ps = _make_planning_space(
            fid, ts, planning_mode="MIXED_TRAFFIC",
            dynamic_objects=objs,
            indian_context=_make_indian_context(traffic_density="HIGH", vru=True),
        )
        cands = [
            _make_candidate("c10_center", 0.0),
            _make_candidate("c10_left", 0.75),
            _make_candidate("c10_right", -0.75),
        ]
        cs = _make_candidate_set(fid, ts, cands)
        rs = _make_risk_set(fid, ts, [
            _make_risk("c10_center", 0.42, RiskLevel.MODERATE_RISK, RiskReasonCode.LOW_CLEARANCE),
            _make_risk("c10_left", 0.60, RiskLevel.MODERATE_RISK, RiskReasonCode.LOW_TTC),
            _make_risk("c10_right", 0.35, RiskLevel.LOW_RISK),
        ])
        rr = _make_replan_result(ReplanningDecision.NO_REPLAN)
        ir = _make_indian_result(PlanningMode.MIXED_TRAFFIC, motorcycles=True)
        return "mixed_motorcycle_traffic", PlannerInput(
            frame_id=fid, timestamp=ts,
            planning_space=ps, candidate_set=cs, risk_set=rs,
            replanning_result=rr, indian_road_result=ir,
        )

    # ------------------------------------------------------------------
    # Scenario 11: Construction zone
    # ------------------------------------------------------------------

    def _scenario_construction_zone(self) -> Tuple[str, PlannerInput]:
        fid, ts = 1011, _T0 + 11.0
        hazards = (_make_static_hazard("barrier_1", "CONSTRUCTION_BARRIER", 12.0, 1.5, 1.0),)
        objs = (_make_dynamic_obj("worker_1", "PEDESTRIAN", 14.0, 1.2, 0.2, 0.0, 0.85),)
        ps = _make_planning_space(
            fid, ts, planning_mode="DRIVABLE_SPACE",
            extent=_make_extent(0.8, -2.0, 2.8),
            static_hazards=hazards,
            dynamic_objects=objs,
            indian_context=_make_indian_context(traffic_density="LOW", vru=True),
            quality=_make_quality(0.65, 0.35),
        )
        cands = [_make_candidate("c11_center", 0.0), _make_candidate("c11_right", -0.8)]
        cs = _make_candidate_set(fid, ts, cands)
        rs = _make_risk_set(fid, ts, [
            _make_risk("c11_center", 0.62, RiskLevel.MODERATE_RISK, RiskReasonCode.ROAD_HAZARD_INTERACTION),
            _make_risk("c11_right", 0.28, RiskLevel.LOW_RISK),
        ])
        rr = _make_replan_result(ReplanningDecision.REPLAN_REQUESTED, ReplanningUrgency.NORMAL)
        ir = _make_indian_result(PlanningMode.DRIVABLE_SPACE, vru=True)
        return "construction_zone", PlannerInput(
            frame_id=fid, timestamp=ts,
            planning_space=ps, candidate_set=cs, risk_set=rs,
            replanning_result=rr, indian_road_result=ir,
        )

    # ------------------------------------------------------------------
    # Result factory
    # ------------------------------------------------------------------

    def _make_result(
        self,
        scenario_id: str,
        output: PlannerOutput,
        snap: PlannerSnapshot,
        latency_ms: float,
    ) -> BenchmarkResult:
        return BenchmarkResult(
            scenario_id=scenario_id,
            run_id=f"{scenario_id}_{snap.frame_id}",
            planning_status=output.planning_status.value,
            planning_mode=output.planning_mode,
            candidate_count=output.candidate_count,
            valid_candidate_count=output.candidate_summary.valid_candidate_count,
            risk_evaluated_count=output.risk_summary.risk_evaluation_count,
            replanning_required=output.replanning_required,
            replanning_decision=output.replan_summary.replanning_decision,
            planning_latency_ms=latency_ms,
            degraded=output.degraded,
            safety_blocked=output.planning_status == PlannerStatus.SAFETY_RESTRICTED,
            validation_errors=output.validation_errors,
            reason_codes=output.reason_codes,
            selected_candidate_id=output.selected_candidate_id,
        )
