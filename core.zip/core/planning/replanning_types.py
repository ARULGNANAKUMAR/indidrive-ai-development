"""
IndiDrive AI — Phase 9.4 | Adaptive Replanning — Data Contracts
================================================================
Strongly-typed containers for Phase 9.4 Adaptive Replanning.

Phase 9.4 answers:
    «"Does the current planning solution require a new planning cycle?"»

Phase 9.4 does NOT answer:
    «"Which candidate path should be chosen?"»
    «"What is the target speed?"»
    «"What steering/throttle/brake should be applied?"»

Design rules (same as all prior phases):
  * dataclasses — not raw dicts
  * explicit NOT_AVAILABLE / UNKNOWN — never fabricated
  * no path selection, no best-path, no vehicle control
  * no steering, no throttle, no brake, no target_speed
  * deterministic: same input → same output
  * immutable snapshots
  * offline — no LLM, no cloud, no neural networks

This module contains ONLY structural containers.
Computation lives in replanning_engine.py and active_path_monitor.py.
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Optional, Tuple

__all__ = [
    # Sentinels / schema
    "NOT_AVAILABLE",
    "REPLANNING_SCHEMA_VERSION",
    # Enums
    "ReplanningDecision",
    "ReplanningUrgency",
    "ReplanningReasonCode",
    "ActivePathValidity",
    "CooldownState",
    # Sub-structures
    "ActivePath",
    "PlanningStateSnapshot",
    "ChangeMagnitudes",
    # Primary output containers
    "ReplanningRequest",
    "ReplanningContext",
    "ReplanningDecisionResult",
]

NOT_AVAILABLE = "NOT_AVAILABLE"
REPLANNING_SCHEMA_VERSION = "9.4"


# ---------------------------------------------------------------------------
# Replanning decision — top-level outcome
# ---------------------------------------------------------------------------

class ReplanningDecision(str, Enum):
    """Top-level replanning decision for one evaluation cycle.

    NO_REPLAN           — current path remains valid and acceptable; no action needed.
    REPLAN_REQUESTED    — meaningful change detected; new planning cycle is warranted.
    REPLAN_REQUIRED     — path is invalid or critically unsafe; replanning is mandatory.
    REPLAN_BLOCKED      — replanning is desired but planning_allowed=False (safety gate).
    DEGRADED_REPLAN     — replanning triggered but inputs are degraded; result is uncertain.
    UNKNOWN             — decision cannot be made (missing active path or severe degradation).
    """
    NO_REPLAN        = "NO_REPLAN"
    REPLAN_REQUESTED = "REPLAN_REQUESTED"
    REPLAN_REQUIRED  = "REPLAN_REQUIRED"
    REPLAN_BLOCKED   = "REPLAN_BLOCKED"
    DEGRADED_REPLAN  = "DEGRADED_REPLAN"
    UNKNOWN          = "UNKNOWN"


# ---------------------------------------------------------------------------
# Replanning urgency
# ---------------------------------------------------------------------------

class ReplanningUrgency(str, Enum):
    """Urgency level of a replanning request.

    NORMAL   — minor/routine change; next planning cycle is sufficient.
    ELEVATED — moderate change; planning should occur promptly.
    URGENT   — significant dynamic conflict; high-priority planning needed.
    CRITICAL — severe/imminent conflict; immediate planning pass required.

    Urgency is derived from actual trigger inputs — it is NOT a vehicle
    control command.
    """
    NORMAL   = "NORMAL"
    ELEVATED = "ELEVATED"
    URGENT   = "URGENT"
    CRITICAL = "CRITICAL"


# ---------------------------------------------------------------------------
# Replanning reason codes — deterministic, structured
# ---------------------------------------------------------------------------

class ReplanningReasonCode(str, Enum):
    """Deterministic structured reason codes for replanning triggers.

    Multiple codes may apply simultaneously. The engine preserves all
    relevant codes and identifies a dominant reason.
    """
    # Geometry / validity
    PATH_GEOMETRY_INVALID    = "PATH_GEOMETRY_INVALID"
    DRIVABLE_REGION_CHANGE   = "DRIVABLE_REGION_CHANGE"
    ROAD_STRUCTURE_CHANGE    = "ROAD_STRUCTURE_CHANGE"
    ROAD_ANOMALY_CHANGE      = "ROAD_ANOMALY_CHANGE"

    # Dynamic obstacles
    DYNAMIC_PATH_BLOCKAGE    = "DYNAMIC_PATH_BLOCKAGE"
    NEW_RELEVANT_OBJECT      = "NEW_RELEVANT_OBJECT"
    HAZARD_CLEARED           = "HAZARD_CLEARED"

    # Risk
    RISK_ESCALATION          = "RISK_ESCALATION"
    CRITICAL_PATH_RISK       = "CRITICAL_PATH_RISK"
    UNCERTAINTY_ESCALATION   = "UNCERTAINTY_ESCALATION"

    # Time-to-collision
    TTC_DEGRADATION          = "TTC_DEGRADATION"

    # Prediction
    PREDICTION_CHANGE        = "PREDICTION_CHANGE"

    # Safety gate
    SAFETY_GATE_CHANGE       = "SAFETY_GATE_CHANGE"

    # Context / state
    STALE_PLANNING_STATE     = "STALE_PLANNING_STATE"
    PLANNING_CONTEXT_CHANGE  = "PLANNING_CONTEXT_CHANGE"
    NO_ACTIVE_PATH           = "NO_ACTIVE_PATH"


# ---------------------------------------------------------------------------
# Active path validity
# ---------------------------------------------------------------------------

class ActivePathValidity(str, Enum):
    """Validity classification of the currently active path.

    VALID           — path is geometrically and contextually valid.
    INVALID         — path is explicitly invalid (geometry, boundaries, gate).
    STALE           — path data is too old to be trusted.
    DEGRADED        — path data is partially available but uncertain.
    NOT_SET         — no active path has been set.
    UNKNOWN         — validity cannot be determined.
    """
    VALID    = "VALID"
    INVALID  = "INVALID"
    STALE    = "STALE"
    DEGRADED = "DEGRADED"
    NOT_SET  = "NOT_SET"
    UNKNOWN  = "UNKNOWN"


# ---------------------------------------------------------------------------
# Cooldown state
# ---------------------------------------------------------------------------

class CooldownState(str, Enum):
    """Cooldown / debounce state for replanning requests.

    INACTIVE        — no cooldown; replanning can proceed.
    ACTIVE          — cooldown in effect; low-priority requests suppressed.
    CRITICAL_BYPASS — cooldown bypassed due to critical condition.
    """
    INACTIVE        = "INACTIVE"
    ACTIVE          = "ACTIVE"
    CRITICAL_BYPASS = "CRITICAL_BYPASS"


# ---------------------------------------------------------------------------
# ActivePath — representation of the current active candidate/path
# ---------------------------------------------------------------------------

@dataclass
class ActivePath:
    """Representation of the currently active candidate path being monitored.

    FORBIDDEN fields (must never appear here):
        steering_angle, throttle, brake, target_speed, acceleration_cmd,
        controller_state, mpc_output, carla_command.

    Fields
    ------
    candidate_id        : ID of the active candidate (from Phase 9.2).
    frame_id            : frame when this path was activated.
    timestamp           : wall-clock time of activation.
    activation_timestamp: when this path became the active path.
    last_evaluated_at   : wall-clock time of last evaluation.
    validity            : current validity classification.
    risk_score          : last known risk score from Phase 9.3 [0, 1].
    risk_level          : last known risk level string.
    ttc_s               : last known minimum TTC in seconds (None if unknown).
    critical_object_ids : IDs of objects flagged as critical at last eval.
    source_frame_id     : frame_id of the candidate set this came from.
    schema_version      : Phase 9.4 schema version.
    """
    candidate_id: str = NOT_AVAILABLE
    frame_id: int = 0
    timestamp: float = field(default_factory=time.time)
    activation_timestamp: float = field(default_factory=time.time)
    last_evaluated_at: float = field(default_factory=time.time)
    validity: ActivePathValidity = ActivePathValidity.NOT_SET
    risk_score: float = 0.0
    risk_level: str = NOT_AVAILABLE
    ttc_s: Optional[float] = None
    critical_object_ids: Tuple[str, ...] = field(default_factory=tuple)
    source_frame_id: int = 0
    schema_version: str = REPLANNING_SCHEMA_VERSION

    def to_dict(self) -> dict:
        return {
            "candidate_id": self.candidate_id,
            "frame_id": self.frame_id,
            "timestamp": self.timestamp,
            "activation_timestamp": self.activation_timestamp,
            "last_evaluated_at": self.last_evaluated_at,
            "validity": self.validity.value,
            "risk_score": round(self.risk_score, 4),
            "risk_level": self.risk_level,
            "ttc_s": round(self.ttc_s, 3) if self.ttc_s is not None else NOT_AVAILABLE,
            "critical_object_ids": list(self.critical_object_ids),
            "source_frame_id": self.source_frame_id,
            "schema_version": self.schema_version,
        }


# ---------------------------------------------------------------------------
# PlanningStateSnapshot — compact previous-state record for change detection
# ---------------------------------------------------------------------------

@dataclass
class PlanningStateSnapshot:
    """Compact snapshot of planning state used for change detection.

    This captures only what is needed for delta comparison — it does NOT
    replicate the entire World Model.

    Fields
    ------
    frame_id            : source frame.
    timestamp           : snapshot wall-clock time.
    active_candidate_id : candidate ID at snapshot time.
    risk_score          : aggregate risk at snapshot time.
    risk_level          : categorical risk level at snapshot time.
    ttc_s               : minimum TTC at snapshot time.
    object_ids          : set of tracked object IDs (as sorted tuple).
    object_positions    : dict mapping object_id → (x, y) position tuple.
    object_velocities   : dict mapping object_id → speed (m/s).
    safety_gate_state   : Phase 8.4 safety gate state string.
    planning_allowed    : Phase 8.4 planning_allowed flag.
    drivable_width_m    : estimated drivable width at snapshot time.
    has_road_anomaly    : True if a road anomaly was present.
    uncertainty         : aggregate planning uncertainty.
    schema_version      : Phase 9.4 schema version.
    """
    frame_id: int = 0
    timestamp: float = field(default_factory=time.time)
    active_candidate_id: str = NOT_AVAILABLE
    risk_score: float = 0.0
    risk_level: str = NOT_AVAILABLE
    ttc_s: Optional[float] = None
    object_ids: Tuple[str, ...] = field(default_factory=tuple)
    object_positions: Tuple[Tuple[str, float, float], ...] = field(default_factory=tuple)
    object_velocities: Tuple[Tuple[str, float], ...] = field(default_factory=tuple)
    safety_gate_state: str = NOT_AVAILABLE
    planning_allowed: bool = False
    drivable_width_m: float = 0.0
    has_road_anomaly: bool = False
    uncertainty: float = 0.0
    schema_version: str = REPLANNING_SCHEMA_VERSION

    def to_dict(self) -> dict:
        return {
            "frame_id": self.frame_id,
            "timestamp": self.timestamp,
            "active_candidate_id": self.active_candidate_id,
            "risk_score": round(self.risk_score, 4),
            "risk_level": self.risk_level,
            "ttc_s": round(self.ttc_s, 3) if self.ttc_s is not None else NOT_AVAILABLE,
            "object_count": len(self.object_ids),
            "safety_gate_state": self.safety_gate_state,
            "planning_allowed": self.planning_allowed,
            "drivable_width_m": round(self.drivable_width_m, 3),
            "has_road_anomaly": self.has_road_anomaly,
            "uncertainty": round(self.uncertainty, 4),
            "schema_version": self.schema_version,
        }


# ---------------------------------------------------------------------------
# ChangeMagnitudes — quantified change measures
# ---------------------------------------------------------------------------

@dataclass
class ChangeMagnitudes:
    """Quantified magnitude of detected changes between planning snapshots.

    All magnitudes are normalised or in natural units as documented.
    None indicates the value was not computable.

    Fields
    ------
    risk_delta          : absolute change in risk score [0, 1].
    ttc_delta_s         : change in minimum TTC (seconds; positive = improved).
    new_object_count    : number of new relevant objects since last snapshot.
    disappeared_object_count: number of objects that left the scene.
    max_position_delta_m: maximum position change of any tracked object (metres).
    max_velocity_delta  : maximum speed change of any tracked object (m/s).
    drivable_width_delta_m: change in drivable width (metres).
    uncertainty_delta   : change in planning uncertainty [0, 1].
    """
    risk_delta: float = 0.0
    ttc_delta_s: Optional[float] = None
    new_object_count: int = 0
    disappeared_object_count: int = 0
    max_position_delta_m: Optional[float] = None
    max_velocity_delta: Optional[float] = None
    drivable_width_delta_m: float = 0.0
    uncertainty_delta: float = 0.0

    def to_dict(self) -> dict:
        def _r(v):
            return round(v, 4) if v is not None else NOT_AVAILABLE
        return {
            "risk_delta": round(self.risk_delta, 4),
            "ttc_delta_s": _r(self.ttc_delta_s),
            "new_object_count": self.new_object_count,
            "disappeared_object_count": self.disappeared_object_count,
            "max_position_delta_m": _r(self.max_position_delta_m),
            "max_velocity_delta": _r(self.max_velocity_delta),
            "drivable_width_delta_m": round(self.drivable_width_delta_m, 4),
            "uncertainty_delta": round(self.uncertainty_delta, 4),
        }


# ---------------------------------------------------------------------------
# ReplanningRequest — primary Phase 9.4 output
# ---------------------------------------------------------------------------

@dataclass
class ReplanningRequest:
    """Structured replanning request produced by Phase 9.4.

    This is the primary output of the Adaptive Replanning Engine.

    FORBIDDEN fields (must never appear here):
        selected_path, best_path, optimal_path, chosen_path, winner,
        steering_angle, throttle, brake, target_speed, acceleration_cmd,
        controller_state, mpc_output, carla_vehicle_command.

    Fields
    ------
    request_id          : stable deterministic request ID.
    frame_id            : processing frame counter.
    timestamp           : wall-clock time of request generation.
    active_candidate_id : the candidate ID being monitored.
    decision            : top-level replanning decision.
    urgency             : urgency level of this request.
    dominant_reason     : the single most important reason code.
    reason_codes        : all active reason codes (deterministic ordering).
    risk_delta          : magnitude of risk change.
    current_risk        : current risk score of active path.
    previous_risk       : previous risk score at last snapshot.
    critical_object_ids : IDs of objects that are critical.
    changed_object_ids  : IDs of objects that changed significantly.
    new_object_ids      : IDs of newly detected relevant objects.
    safety_gate_state   : current Phase 8.4 safety gate state.
    planning_allowed    : current Phase 8.4 planning_allowed flag.
    uncertainty         : planning uncertainty at request time.
    degraded            : True if inputs were degraded.
    cooldown_state      : cooldown / debounce state.
    change_magnitudes   : quantified change magnitudes.
    schema_version      : Phase 9.4 schema version.
    """
    request_id: str = NOT_AVAILABLE
    frame_id: int = 0
    timestamp: float = field(default_factory=time.time)
    active_candidate_id: str = NOT_AVAILABLE

    # Core decision output
    decision: ReplanningDecision = ReplanningDecision.UNKNOWN
    urgency: ReplanningUrgency = ReplanningUrgency.NORMAL
    dominant_reason: ReplanningReasonCode = ReplanningReasonCode.NO_ACTIVE_PATH
    reason_codes: Tuple[ReplanningReasonCode, ...] = field(default_factory=tuple)

    # Risk deltas
    risk_delta: float = 0.0
    current_risk: float = 0.0
    previous_risk: float = 0.0

    # Object tracking
    critical_object_ids: Tuple[str, ...] = field(default_factory=tuple)
    changed_object_ids: Tuple[str, ...] = field(default_factory=tuple)
    new_object_ids: Tuple[str, ...] = field(default_factory=tuple)

    # Safety gate state
    safety_gate_state: str = NOT_AVAILABLE
    planning_allowed: bool = False

    # Epistemic state
    uncertainty: float = 0.0
    degraded: bool = False

    # Cooldown
    cooldown_state: CooldownState = CooldownState.INACTIVE

    # Change magnitudes
    change_magnitudes: ChangeMagnitudes = field(default_factory=ChangeMagnitudes)

    schema_version: str = REPLANNING_SCHEMA_VERSION

    def to_dict(self) -> dict:
        return {
            "request_id": self.request_id,
            "frame_id": self.frame_id,
            "timestamp": self.timestamp,
            "active_candidate_id": self.active_candidate_id,
            "decision": self.decision.value,
            "urgency": self.urgency.value,
            "dominant_reason": self.dominant_reason.value,
            "reason_codes": [rc.value for rc in self.reason_codes],
            "risk_delta": round(self.risk_delta, 4),
            "current_risk": round(self.current_risk, 4),
            "previous_risk": round(self.previous_risk, 4),
            "critical_object_ids": list(self.critical_object_ids),
            "changed_object_ids": list(self.changed_object_ids),
            "new_object_ids": list(self.new_object_ids),
            "safety_gate_state": self.safety_gate_state,
            "planning_allowed": self.planning_allowed,
            "uncertainty": round(self.uncertainty, 4),
            "degraded": self.degraded,
            "cooldown_state": self.cooldown_state.value,
            "change_magnitudes": self.change_magnitudes.to_dict(),
            "schema_version": self.schema_version,
        }


# ---------------------------------------------------------------------------
# ReplanningContext — compact snapshot for the next planning cycle
# ---------------------------------------------------------------------------

@dataclass
class ReplanningContext:
    """Compact snapshot provided to the next planning cycle after a replan trigger.

    This is consumed by Phase 9.2 (candidate generation) and Phase 9.3
    (risk scoring) to orient the new planning pass.

    Do NOT copy the entire World Model into this structure.

    FORBIDDEN fields:
        selected_path, best_path, optimal_path, chosen_path, winner,
        steering_angle, throttle, brake, target_speed, acceleration_cmd.

    Fields
    ------
    context_id          : deterministic context ID.
    frame_id            : source frame.
    timestamp           : context generation time.
    request_id          : linked ReplanningRequest ID.
    active_path_state   : summary of the active path at trigger time.
    previous_snapshot   : compact previous state snapshot.
    urgency             : replanning urgency.
    dominant_reason     : primary trigger reason.
    reason_codes        : all active reason codes.
    safety_gate_state   : safety gate state.
    planning_allowed    : planning_allowed flag.
    critical_object_ids : critical object IDs.
    changed_object_ids  : changed object IDs.
    new_object_ids      : new object IDs.
    current_risk        : current risk of active path.
    uncertainty         : current planning uncertainty.
    degraded            : True if context is degraded.
    schema_version      : Phase 9.4 schema version.
    """
    context_id: str = NOT_AVAILABLE
    frame_id: int = 0
    timestamp: float = field(default_factory=time.time)
    request_id: str = NOT_AVAILABLE

    # Active path summary (not the full CandidatePath object)
    active_path_state: Optional[ActivePath] = None

    # Previous state for reference
    previous_snapshot: Optional[PlanningStateSnapshot] = None

    # Trigger context
    urgency: ReplanningUrgency = ReplanningUrgency.NORMAL
    dominant_reason: ReplanningReasonCode = ReplanningReasonCode.NO_ACTIVE_PATH
    reason_codes: Tuple[ReplanningReasonCode, ...] = field(default_factory=tuple)

    # Safety state
    safety_gate_state: str = NOT_AVAILABLE
    planning_allowed: bool = False

    # Object context
    critical_object_ids: Tuple[str, ...] = field(default_factory=tuple)
    changed_object_ids: Tuple[str, ...] = field(default_factory=tuple)
    new_object_ids: Tuple[str, ...] = field(default_factory=tuple)

    # Risk context
    current_risk: float = 0.0
    uncertainty: float = 0.0
    degraded: bool = False

    schema_version: str = REPLANNING_SCHEMA_VERSION

    def to_dict(self) -> dict:
        return {
            "context_id": self.context_id,
            "frame_id": self.frame_id,
            "timestamp": self.timestamp,
            "request_id": self.request_id,
            "active_path_state": self.active_path_state.to_dict() if self.active_path_state else None,
            "previous_snapshot": self.previous_snapshot.to_dict() if self.previous_snapshot else None,
            "urgency": self.urgency.value,
            "dominant_reason": self.dominant_reason.value,
            "reason_codes": [rc.value for rc in self.reason_codes],
            "safety_gate_state": self.safety_gate_state,
            "planning_allowed": self.planning_allowed,
            "critical_object_ids": list(self.critical_object_ids),
            "changed_object_ids": list(self.changed_object_ids),
            "new_object_ids": list(self.new_object_ids),
            "current_risk": round(self.current_risk, 4),
            "uncertainty": round(self.uncertainty, 4),
            "degraded": self.degraded,
            "schema_version": self.schema_version,
        }


# ---------------------------------------------------------------------------
# ReplanningDecisionResult — full result from one evaluation cycle
# ---------------------------------------------------------------------------

@dataclass
class ReplanningDecisionResult:
    """Complete result of one replanning evaluation cycle.

    Bundles the ReplanningRequest, optional ReplanningContext (only when
    replanning is triggered), and diagnostic information.

    Fields
    ------
    request             : the replanning request (always present).
    context             : replanning context (None when NO_REPLAN).
    active_path         : current active path state.
    processing_time_s   : wall-clock time to produce this result.
    schema_version      : Phase 9.4 schema version.
    """
    request: Optional[ReplanningRequest] = None
    context: Optional[ReplanningContext] = None
    active_path: Optional[ActivePath] = None
    processing_time_s: float = 0.0
    schema_version: str = REPLANNING_SCHEMA_VERSION

    @property
    def is_replan(self) -> bool:
        """True if this result represents a triggered replanning request."""
        if self.request is None:
            return False
        return self.request.decision in (
            ReplanningDecision.REPLAN_REQUESTED,
            ReplanningDecision.REPLAN_REQUIRED,
            ReplanningDecision.DEGRADED_REPLAN,
        )

    @property
    def is_critical(self) -> bool:
        """True if urgency is CRITICAL."""
        if self.request is None:
            return False
        return self.request.urgency == ReplanningUrgency.CRITICAL

    def to_dict(self) -> dict:
        return {
            "request": self.request.to_dict() if self.request else None,
            "context": self.context.to_dict() if self.context else None,
            "active_path": self.active_path.to_dict() if self.active_path else None,
            "is_replan": self.is_replan,
            "is_critical": self.is_critical,
            "processing_time_s": round(self.processing_time_s, 6),
            "schema_version": self.schema_version,
        }
