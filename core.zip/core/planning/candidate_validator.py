"""
IndiDrive AI — Phase 9.2 | Candidate Path Validator
====================================================
Validates CandidatePath and CandidatePathSet instances.

Validation targets:
  - candidate_id presence
  - timestamps / frame_id
  - coordinate_frame
  - waypoint ordering (monotone longitudinal_s)
  - finite coordinates (no NaN / Inf)
  - path length within configured bounds
  - waypoint count within configured bounds
  - lateral offset within expected range
  - duplicate candidate detection in a set
  - enum values
  - schema version
  - no forbidden scoring fields (structural check)

This module does NOT:
  - perform risk scoring
  - select a winner candidate
  - override Phase 8.4 safety constraints
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import List, Set, Tuple

from .candidate_path_types import (
    NOT_AVAILABLE,
    CANDIDATE_PATH_SCHEMA_VERSION,
    CandidatePath,
    CandidatePathSet,
    CandidateGenerationStatus,
    GeometricValidity,
    BoundaryValidity,
    DrivableSpaceValidity,
    GenerationMethod,
    PathPoint,
)
from .candidate_generator_config import CandidateGeneratorConfig

__all__ = [
    "CandidateValidator",
    "CandidateValidationResult",
    "CandidateSetValidationResult",
]


# ---------------------------------------------------------------------------
# Result containers
# ---------------------------------------------------------------------------

@dataclass
class CandidateValidationResult:
    """Result of validating a single CandidatePath."""
    is_valid: bool = False
    errors: Tuple[str, ...] = field(default_factory=tuple)
    warnings: Tuple[str, ...] = field(default_factory=tuple)

    def to_dict(self) -> dict:
        return {
            "is_valid": self.is_valid,
            "error_count": len(self.errors),
            "errors": list(self.errors),
            "warning_count": len(self.warnings),
            "warnings": list(self.warnings),
        }


@dataclass
class CandidateSetValidationResult:
    """Result of validating a CandidatePathSet."""
    is_valid: bool = False
    errors: Tuple[str, ...] = field(default_factory=tuple)
    warnings: Tuple[str, ...] = field(default_factory=tuple)

    def to_dict(self) -> dict:
        return {
            "is_valid": self.is_valid,
            "error_count": len(self.errors),
            "errors": list(self.errors),
            "warning_count": len(self.warnings),
            "warnings": list(self.warnings),
        }


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _is_finite(v: float) -> bool:
    try:
        return math.isfinite(float(v))
    except (TypeError, ValueError):
        return False


def _check_point_finite(pt: PathPoint, idx: int) -> List[str]:
    errs = []
    for attr in ("x", "y", "z", "longitudinal_s", "lateral_offset_m"):
        val = getattr(pt, attr, None)
        if val is None or not _is_finite(val):
            errs.append(f"waypoint[{idx}].{attr} is non-finite ({val})")
    for attr in ("heading", "curvature"):
        val = getattr(pt, attr, None)
        if val is not None and not _is_finite(val):
            errs.append(f"waypoint[{idx}].{attr} is non-finite ({val})")
    return errs


# ---------------------------------------------------------------------------
# CandidateValidator
# ---------------------------------------------------------------------------

class CandidateValidator:
    """Validates CandidatePath and CandidatePathSet instances.

    Follows the same validator pattern as PlanningSpaceValidator:
      - accumulate errors / warnings
      - return a result object
      - never raise on non-critical issues
      - never suppress critical errors
    """

    def __init__(self, config: CandidateGeneratorConfig | None = None) -> None:
        self._config = config or CandidateGeneratorConfig()

    # ------------------------------------------------------------------
    # Single candidate
    # ------------------------------------------------------------------

    def validate_candidate(self, candidate: CandidatePath) -> CandidateValidationResult:
        """Validate a single CandidatePath.

        Returns CandidateValidationResult with accumulated errors/warnings.
        """
        errors: List[str] = []
        warnings: List[str] = []

        if candidate is None:
            return CandidateValidationResult(
                is_valid=False,
                errors=("candidate is None",),
            )

        # --- candidate_id ---
        if not candidate.candidate_id or candidate.candidate_id == NOT_AVAILABLE:
            errors.append("candidate_id is missing or NOT_AVAILABLE")

        # --- frame_id ---
        if candidate.frame_id < 0:
            errors.append(f"frame_id is negative ({candidate.frame_id})")

        # --- timestamp ---
        if not _is_finite(candidate.timestamp) or candidate.timestamp < 0:
            errors.append(f"timestamp is invalid ({candidate.timestamp})")

        # --- coordinate_frame ---
        if candidate.coordinate_frame != "VEHICLE":
            warnings.append(
                f"coordinate_frame is '{candidate.coordinate_frame}', expected 'VEHICLE'"
            )

        # --- schema_version ---
        if candidate.schema_version != CANDIDATE_PATH_SCHEMA_VERSION:
            warnings.append(
                f"schema_version mismatch: got '{candidate.schema_version}', "
                f"expected '{CANDIDATE_PATH_SCHEMA_VERSION}'"
            )

        # --- enum values ---
        try:
            GenerationMethod(candidate.generation_method)
        except ValueError:
            errors.append(f"invalid generation_method: '{candidate.generation_method}'")

        try:
            GeometricValidity(candidate.geometric_validity)
        except ValueError:
            errors.append(f"invalid geometric_validity: '{candidate.geometric_validity}'")

        try:
            BoundaryValidity(candidate.boundary_validity)
        except ValueError:
            errors.append(f"invalid boundary_validity: '{candidate.boundary_validity}'")

        try:
            DrivableSpaceValidity(candidate.drivable_space_validity)
        except ValueError:
            errors.append(f"invalid drivable_space_validity: '{candidate.drivable_space_validity}'")

        # --- waypoints ---
        waypoints = candidate.waypoints
        cfg = self._config

        if len(waypoints) < cfg.min_waypoints:
            errors.append(
                f"waypoint_count={len(waypoints)} < min_waypoints={cfg.min_waypoints}"
            )
        if len(waypoints) > cfg.max_waypoints:
            errors.append(
                f"waypoint_count={len(waypoints)} > max_waypoints={cfg.max_waypoints}"
            )

        prev_s = None
        for i, pt in enumerate(waypoints):
            # Finite check
            pt_errs = _check_point_finite(pt, i)
            errors.extend(pt_errs)
            if pt_errs:
                continue

            # Monotone longitudinal_s
            if prev_s is not None:
                if pt.longitudinal_s < prev_s - 1e-6:
                    errors.append(
                        f"waypoint[{i}].longitudinal_s={pt.longitudinal_s:.4f} < "
                        f"waypoint[{i-1}].longitudinal_s={prev_s:.4f} (non-monotone)"
                    )
            prev_s = pt.longitudinal_s

        # --- path length ---
        if _is_finite(candidate.longitudinal_extent_m):
            if candidate.longitudinal_extent_m < cfg.minimum_path_length_m:
                warnings.append(
                    f"longitudinal_extent_m={candidate.longitudinal_extent_m:.2f} < "
                    f"minimum_path_length_m={cfg.minimum_path_length_m:.2f}"
                )
            if candidate.longitudinal_extent_m > cfg.maximum_path_length_m:
                warnings.append(
                    f"longitudinal_extent_m={candidate.longitudinal_extent_m:.2f} > "
                    f"maximum_path_length_m={cfg.maximum_path_length_m:.2f}"
                )

        # --- lateral_offset finite ---
        if not _is_finite(candidate.lateral_offset_m):
            errors.append(f"lateral_offset_m is non-finite ({candidate.lateral_offset_m})")

        is_valid = len(errors) == 0
        return CandidateValidationResult(
            is_valid=is_valid,
            errors=tuple(errors),
            warnings=tuple(warnings),
        )

    # ------------------------------------------------------------------
    # Candidate set
    # ------------------------------------------------------------------

    def validate_set(self, path_set: CandidatePathSet) -> CandidateSetValidationResult:
        """Validate a CandidatePathSet.

        Validates the set-level fields and checks for duplicate candidates.
        """
        errors: List[str] = []
        warnings: List[str] = []

        if path_set is None:
            return CandidateSetValidationResult(
                is_valid=False,
                errors=("path_set is None",),
            )

        # --- set_id ---
        if not path_set.set_id or path_set.set_id == NOT_AVAILABLE:
            errors.append("set_id is missing or NOT_AVAILABLE")

        # --- frame_id ---
        if path_set.frame_id < 0:
            errors.append(f"set frame_id is negative ({path_set.frame_id})")

        # --- timestamp ---
        if not _is_finite(path_set.timestamp) or path_set.timestamp < 0:
            errors.append(f"set timestamp is invalid ({path_set.timestamp})")

        # --- coordinate_frame ---
        if path_set.coordinate_frame != "VEHICLE":
            warnings.append(
                f"set coordinate_frame is '{path_set.coordinate_frame}', expected 'VEHICLE'"
            )

        # --- schema_version ---
        if path_set.schema_version != CANDIDATE_PATH_SCHEMA_VERSION:
            warnings.append(
                f"set schema_version mismatch: got '{path_set.schema_version}', "
                f"expected '{CANDIDATE_PATH_SCHEMA_VERSION}'"
            )

        # --- generation_status enum ---
        try:
            CandidateGenerationStatus(path_set.generation_status)
        except ValueError:
            errors.append(f"invalid generation_status: '{path_set.generation_status}'")

        # --- candidate count vs max ---
        if path_set.candidate_count > self._config.max_candidates:
            errors.append(
                f"candidate_count={path_set.candidate_count} > "
                f"max_candidates={self._config.max_candidates}"
            )

        # --- duplicate candidate IDs ---
        seen_ids: Set[str] = set()
        duplicate_ids: List[str] = []
        for c in path_set.candidates:
            cid = c.candidate_id
            if cid in seen_ids:
                duplicate_ids.append(cid)
            seen_ids.add(cid)
        if duplicate_ids:
            errors.append(f"duplicate candidate_ids: {sorted(set(duplicate_ids))}")

        # --- planning_restriction consistency ---
        if (
            path_set.generation_status
            == CandidateGenerationStatus.NO_CANDIDATES_DUE_TO_PLANNING_RESTRICTION
            and path_set.candidate_count > 0
        ):
            errors.append(
                "generation_status=NO_CANDIDATES_DUE_TO_PLANNING_RESTRICTION "
                "but candidate_count > 0 (inconsistent)"
            )

        # --- per-candidate validation warnings only ---
        for i, c in enumerate(path_set.candidates):
            result = self.validate_candidate(c)
            if not result.is_valid:
                warnings.append(
                    f"candidate[{i}] ({c.candidate_id}) has validation errors: "
                    f"{list(result.errors)}"
                )

        is_valid = len(errors) == 0
        return CandidateSetValidationResult(
            is_valid=is_valid,
            errors=tuple(errors),
            warnings=tuple(warnings),
        )
