"""
IndiDrive AI — Phase 9.3 | Dynamic Obstacle & Path Risk Engine
===============================================================
Evaluates the dynamic and temporal risk of each candidate path using the
existing World Model, prediction, collision, and safety context.

Phase 9.3 answers:
    «"How risky is this candidate path given the currently predicted
      dynamic environment?"»

Phase 9.3 does NOT:
    - select a best path
    - generate paths
    - issue vehicle control commands (no steering, throttle, brake, MPC)
    - reimplement prediction, TTC, closest approach, or trajectory intersection
    - invoke any LLM, cloud, or neural network

All component computations consume existing Phase 4/7/8.4 outputs.
The engine is fully deterministic: same inputs + config → same output.

Coordinate convention:
    +X = forward, +Y = left, +Z = up, origin = vehicle rear-axle centre, metres.
"""
from __future__ import annotations

import math
import time
from typing import Dict, List, Optional, Sequence, Tuple

from .path_risk_types import (
    NOT_AVAILABLE,
    CandidatePathRisk,
    ObjectRiskContribution,
    PathRiskSet,
    PathRiskStatus,
    RiskBreakdown,
    RiskLevel,
    RiskReasonCode,
)
from .path_risk_config import PathRiskConfig, load_path_risk_config
from .candidate_path_types import CandidatePath, GeometricValidity, BoundaryValidity

# ---------------------------------------------------------------------------
# Sentinel / guard helpers
# ---------------------------------------------------------------------------

def _finite(v) -> Optional[float]:
    """Return float(v) if v is a finite number, else None."""
    try:
        f = float(v)
        return f if math.isfinite(f) else None
    except (TypeError, ValueError):
        return None


def _clamp(v: float, lo: float = 0.0, hi: float = 1.0) -> float:
    """Clamp v to [lo, hi]."""
    if v < lo:
        return lo
    if v > hi:
        return hi
    return v


def _linear_risk(value: float, safe: float, critical: float) -> float:
    """
    Linearly interpolate risk from 0.0 at 'safe' to 1.0 at 'critical'.
    Works for both increasing risk (safe > critical) and decreasing risk
    (safe < critical).
    """
    if abs(safe - critical) < 1e-9:
        return 0.0 if value >= safe else 1.0
    risk = (value - safe) / (critical - safe)
    return _clamp(risk)


# ---------------------------------------------------------------------------
# VRU detection
# ---------------------------------------------------------------------------

def _is_vru(object_type: str, cfg: PathRiskConfig) -> bool:
    """Return True if the object type is classified as a Vulnerable Road User."""
    return object_type.upper() in cfg.vru_types


# ---------------------------------------------------------------------------
# Object type risk multiplier
# ---------------------------------------------------------------------------

def _object_type_multiplier(object_type: str, cfg: PathRiskConfig) -> float:
    """Return the configured risk multiplier for this object type."""
    return cfg.object_type_weights.get(object_type.upper(), 1.0)


# ---------------------------------------------------------------------------
# Clearance risk: spatial separation between path envelope and object
# ---------------------------------------------------------------------------

def _compute_clearance_risk(
    path: CandidatePath,
    obj_x: Optional[float],
    obj_y: Optional[float],
    obj_half_width: float,
    cfg: PathRiskConfig,
) -> float:
    """
    Compute spatial clearance risk for one object against a candidate path.

    Finds the minimum lateral distance between the object position and any
    path waypoint (projected), then converts to a risk score.

    Args:
        path: the candidate path.
        obj_x: object forward position (metres, vehicle frame).
        obj_y: object lateral position (metres, vehicle frame).
        obj_half_width: approximate half-width of the object.
        cfg: risk configuration.

    Returns:
        Clearance risk in [0, 1].
    """
    ox = _finite(obj_x)
    oy = _finite(obj_y)
    if ox is None or oy is None:
        return 0.0  # cannot assess without position

    waypoints = path.waypoints
    if not waypoints:
        return 0.0

    min_dist = math.inf
    for wp in waypoints:
        px = _finite(wp.x)
        py = _finite(wp.y)
        if px is None or py is None:
            continue
        # Euclidean distance from object to this waypoint
        d = math.sqrt((ox - px) ** 2 + (oy - py) ** 2)
        if d < min_dist:
            min_dist = d

    if min_dist == math.inf:
        return 0.0

    # Adjust for object footprint + path half-width
    effective_clearance = max(
        0.0, min_dist - obj_half_width - cfg.path_half_width_m
    )

    return _linear_risk(effective_clearance, cfg.clearance_safe_m, cfg.clearance_critical_m)


# ---------------------------------------------------------------------------
# TTC risk: convert Phase 4/World Model TTC to risk score
# ---------------------------------------------------------------------------

def _compute_ttc_risk(
    ttc_s: Optional[float],
    ttc_status: str,
    data_age_s: float,
    cfg: PathRiskConfig,
) -> Tuple[float, List[RiskReasonCode]]:
    """
    Convert TTC information to a risk score.

    Reuses existing TTC information from the World Model (Phase 7 /
    Phase 4D).  Does NOT recompute TTC.

    Args:
        ttc_s: time to collision in seconds (None if unavailable).
        ttc_status: FINITE | NO_COLLISION | UNKNOWN | NOT_AVAILABLE.
        data_age_s: age of the object data.
        cfg: risk configuration.

    Returns:
        (ttc_risk in [0, 1], reason_codes).
    """
    codes: List[RiskReasonCode] = []

    # Stale data check (uses configurable stale_data_age_s threshold)
    if data_age_s >= cfg.stale_data_age_s:
        codes.append(RiskReasonCode.STALE_PREDICTION)

    if ttc_status in ("NO_COLLISION",):
        return 0.0, codes

    if ttc_status in ("UNKNOWN", NOT_AVAILABLE, "NOT_AVAILABLE") or ttc_s is None:
        # TTC is unavailable — return a moderate fallback risk
        # (do NOT convert unavailability to zero risk)
        codes.append(RiskReasonCode.UNCERTAIN_OBJECT_MOTION)
        return cfg.ttc_unavailable_near_fallback, codes

    t = _finite(ttc_s)
    if t is None:
        codes.append(RiskReasonCode.UNCERTAIN_OBJECT_MOTION)
        return cfg.ttc_unavailable_near_fallback, codes

    if t <= cfg.ttc_critical_s:
        codes.append(RiskReasonCode.LOW_TTC)
        return 1.0, codes

    risk = _linear_risk(t, cfg.ttc_safe_s, cfg.ttc_critical_s)
    if risk > 0.3:
        codes.append(RiskReasonCode.LOW_TTC)
    return risk, codes


# ---------------------------------------------------------------------------
# Closest approach risk: convert Phase 4 closest approach to risk
# ---------------------------------------------------------------------------

def _compute_closest_approach_risk(
    min_distance_m: Optional[float],
    cfg: PathRiskConfig,
) -> Tuple[float, List[RiskReasonCode]]:
    """
    Convert closest approach distance to risk score.

    Reuses existing closest_approach info from World Model / Phase 4D.

    Args:
        min_distance_m: minimum predicted separation in metres.
        cfg: risk configuration.

    Returns:
        (closest_approach_risk in [0, 1], reason_codes).
    """
    codes: List[RiskReasonCode] = []
    d = _finite(min_distance_m)
    if d is None:
        return 0.0, codes

    d = max(0.0, d)
    risk = _linear_risk(d, cfg.closest_approach_safe_m, cfg.closest_approach_critical_m)
    if risk >= 0.7:
        codes.append(RiskReasonCode.CLOSE_APPROACH)
    return risk, codes


# ---------------------------------------------------------------------------
# Trajectory intersection risk
# ---------------------------------------------------------------------------

def _compute_trajectory_intersection_risk(
    path: CandidatePath,
    obj_trajectory: List[Tuple[float, float, float, float]],  # (x, y, z, t)
    cfg: PathRiskConfig,
) -> Tuple[float, List[RiskReasonCode]]:
    """
    Evaluate whether the object's predicted trajectory intersects the
    candidate path envelope.

    Reuses the predicted trajectory from WorldObjectPredictionSummary
    (stored as list of (x, y, z, t) tuples, Phase 7 format).

    Approach: for each trajectory point, find the nearest path waypoint
    and check if the point falls within the path half-width.

    Args:
        path: candidate path.
        obj_trajectory: list of (x, y, z, t) tuples.
        cfg: risk configuration.

    Returns:
        (intersection_risk in [0, 1], reason_codes).
    """
    codes: List[RiskReasonCode] = []
    waypoints = path.waypoints
    if not waypoints or not obj_trajectory:
        return cfg.intersection_clear_risk, codes

    collision_r = cfg.path_half_width_m + 1.0   # object half-width conservative

    earliest_conflict_t: Optional[float] = None
    overlap_count = 0
    min_sep = math.inf

    for traj_pt in obj_trajectory:
        # Unpack: (x, y, z, t)
        try:
            tx, ty = float(traj_pt[0]), float(traj_pt[1])
            tt = float(traj_pt[3]) if len(traj_pt) > 3 else 0.0
        except (TypeError, ValueError, IndexError):
            continue
        if not (math.isfinite(tx) and math.isfinite(ty) and math.isfinite(tt)):
            continue

        # Find separation from nearest waypoint
        nearest_sep = math.inf
        for wp in waypoints:
            wpx = _finite(wp.x)
            wpy = _finite(wp.y)
            if wpx is None or wpy is None:
                continue
            sep = math.sqrt((tx - wpx) ** 2 + (ty - wpy) ** 2) - collision_r
            if sep < nearest_sep:
                nearest_sep = sep

        if nearest_sep < min_sep:
            min_sep = nearest_sep

        if nearest_sep <= 0.0:
            overlap_count += 1
            if earliest_conflict_t is None:
                earliest_conflict_t = tt

    if overlap_count > 0:
        codes.append(RiskReasonCode.TRAJECTORY_INTERSECTION)
        codes.append(RiskReasonCode.CROSSING_TRAJECTORY)
        # Risk scales with how early/many the overlaps are
        intersection_risk = min(
            cfg.intersection_detected_risk,
            cfg.intersection_detected_risk * (1.0 + 0.1 * (overlap_count - 1))
        )
        return _clamp(intersection_risk), codes

    # No intersection — risk based on minimum separation
    if min_sep < math.inf:
        clearance_risk = _linear_risk(
            max(0.0, min_sep),
            cfg.clearance_safe_m,
            cfg.clearance_critical_m,
        )
        if clearance_risk > 0.3:
            codes.append(RiskReasonCode.OBJECT_APPROACHING_PATH)
        return clearance_risk * 0.5, codes

    return cfg.intersection_clear_risk, codes


# ---------------------------------------------------------------------------
# Temporal risk: distinguish spatially close but diverging vs converging
# ---------------------------------------------------------------------------

def _compute_temporal_risk(
    obj_vx: Optional[float],
    obj_vy: Optional[float],
    path: CandidatePath,
    obj_x: Optional[float],
    obj_y: Optional[float],
    cfg: PathRiskConfig,
) -> Tuple[float, List[RiskReasonCode]]:
    """
    Evaluate time-aware path interaction risk.

    Considers whether the object's current velocity points toward or away
    from the path.  Uses the simple dot product between the object-to-path
    vector and the object velocity vector.

    Args:
        obj_vx: object velocity in +X direction (m/s).
        obj_vy: object velocity in +Y direction (m/s).
        path: candidate path.
        obj_x: current object X position.
        obj_y: current object Y position.
        cfg: risk configuration.

    Returns:
        (temporal_risk in [0, 1], reason_codes).
    """
    codes: List[RiskReasonCode] = []
    ox = _finite(obj_x)
    oy = _finite(obj_y)
    vx = _finite(obj_vx)
    vy = _finite(obj_vy)

    if ox is None or oy is None:
        return 0.0, codes

    waypoints = path.waypoints
    if not waypoints:
        return 0.0, codes

    # Find nearest waypoint
    min_dist = math.inf
    nearest_px, nearest_py = 0.0, 0.0
    for wp in waypoints:
        wpx = _finite(wp.x)
        wpy = _finite(wp.y)
        if wpx is None or wpy is None:
            continue
        d = math.sqrt((ox - wpx) ** 2 + (oy - wpy) ** 2)
        if d < min_dist:
            min_dist = d
            nearest_px, nearest_py = wpx, wpy

    if min_dist == math.inf:
        return 0.0, codes

    # Without velocity, can only assess spatial proximity
    if vx is None or vy is None:
        spatial_risk = _linear_risk(min_dist, cfg.clearance_safe_m, cfg.clearance_critical_m)
        return spatial_risk * 0.6, codes

    speed = math.sqrt(vx * vx + vy * vy)
    if speed < 0.1:
        # Object is stationary — spatial-only
        spatial_risk = _linear_risk(min_dist, cfg.clearance_safe_m, cfg.clearance_critical_m)
        return spatial_risk * 0.4, codes

    # Direction from object to nearest path point
    dx = nearest_px - ox
    dy = nearest_py - oy
    dist_to_path = math.sqrt(dx * dx + dy * dy)

    if dist_to_path < 1e-6:
        codes.append(RiskReasonCode.TEMPORAL_CONFLICT)
        return 0.8, codes

    # Dot product: positive → object approaching path, negative → receding
    dot = (vx * dx + vy * dy) / (speed * dist_to_path)

    # Approaching = dot > 0, Receding = dot < 0
    if dot > 0.1:
        # Approaching the path
        codes.append(RiskReasonCode.OBJECT_APPROACHING_PATH)
        approach_factor = _clamp(dot)  # 0..1 based on alignment
        base_risk = _linear_risk(dist_to_path, cfg.clearance_safe_m, cfg.clearance_critical_m)
        temporal_risk = base_risk * (0.5 + 0.5 * approach_factor)
        if temporal_risk > 0.5:
            codes.append(RiskReasonCode.TEMPORAL_CONFLICT)
        return _clamp(temporal_risk), codes
    elif dot < -0.1:
        # Object moving away from path — low temporal risk
        base_risk = _linear_risk(dist_to_path, cfg.clearance_safe_m, cfg.clearance_critical_m)
        return base_risk * 0.15, codes
    else:
        # Approximately perpendicular — crossing potential
        base_risk = _linear_risk(dist_to_path, cfg.clearance_safe_m, cfg.clearance_critical_m)
        return _clamp(base_risk * 0.7), codes


# ---------------------------------------------------------------------------
# Collision likelihood risk (reuse Phase 4/World Model value)
# ---------------------------------------------------------------------------

def _compute_collision_likelihood_risk(
    collision_likelihood: Optional[float],
    cfg: PathRiskConfig,
) -> Tuple[float, List[RiskReasonCode]]:
    """
    Convert the existing Phase 4D collision_likelihood score into a risk
    component.  Does NOT recompute collision likelihood.

    The Phase 4D collision_likelihood is already a deterministic risk
    score in [0, 1].  We pass it through (with a configurable cap) as a
    component contribution to the path risk.

    Args:
        collision_likelihood: from WorldObjectCollisionInfo.collision_likelihood.
        cfg: risk configuration.

    Returns:
        (collision_likelihood_risk in [0, 1], reason_codes).
    """
    codes: List[RiskReasonCode] = []
    cl = _finite(collision_likelihood)
    if cl is None:
        return 0.0, codes

    risk = _clamp(cl, 0.0, cfg.collision_likelihood_max)
    if risk >= 0.6:
        codes.append(RiskReasonCode.HIGH_COLLISION_LIKELIHOOD)
    return risk, codes


# ---------------------------------------------------------------------------
# Uncertainty risk
# ---------------------------------------------------------------------------

def _compute_uncertainty_risk(
    prediction_confidence: float,
    is_stale: bool,
    is_degraded: bool,
    cfg: PathRiskConfig,
) -> Tuple[float, List[RiskReasonCode]]:
    """
    Convert object prediction quality indicators to an uncertainty risk.

    Args:
        prediction_confidence: from WorldObjectPredictionSummary.
        is_stale: from WorldObjectQuality.
        is_degraded: from WorldObjectQuality.
        cfg: risk configuration.

    Returns:
        (uncertainty_risk in [0, 1], reason_codes).
    """
    codes: List[RiskReasonCode] = []
    conf = _finite(prediction_confidence)
    if conf is None:
        conf = 0.0

    if is_stale:
        codes.append(RiskReasonCode.STALE_PREDICTION)
    if is_degraded:
        codes.append(RiskReasonCode.DEGRADED_SENSOR_INPUT)

    # Low confidence → higher uncertainty risk
    uncertainty_risk = _linear_risk(
        conf,
        cfg.low_confidence_threshold,  # above this → near-zero uncertainty risk
        0.0,                           # zero confidence → max uncertainty risk
    )
    uncertainty_risk = _clamp(uncertainty_risk * cfg.uncertainty_risk_max)
    if uncertainty_risk > 0.2:
        codes.append(RiskReasonCode.UNCERTAIN_OBJECT_MOTION)
    return uncertainty_risk, codes


# ---------------------------------------------------------------------------
# Vulnerable road user risk
# ---------------------------------------------------------------------------

def _compute_vru_risk(
    is_vru: bool,
    base_object_risk: float,
    cfg: PathRiskConfig,
) -> float:
    """
    Apply VRU risk boost.  The boost is additive (not multiplicative) to
    avoid double-exponential amplification.

    Args:
        is_vru: True if this object is a vulnerable road user.
        base_object_risk: the combined pre-VRU risk for this object.
        cfg: risk configuration.

    Returns:
        vru_risk_contribution in [0, 1].
    """
    if not is_vru or base_object_risk < 0.05:
        return 0.0
    return _clamp(base_object_risk * cfg.vru_risk_boost)


# ---------------------------------------------------------------------------
# Road hazard interaction risk
# ---------------------------------------------------------------------------

def _compute_road_hazard_risk(
    path: CandidatePath,
    anomalies: list,  # list of WorldAnomalySummary
    cfg: PathRiskConfig,
) -> Tuple[float, List[RiskReasonCode]]:
    """
    Evaluate interaction risk between a candidate path and static road
    anomalies (potholes, debris, construction, road damage, etc.).

    Uses existing WorldAnomalySummary data — does NOT re-detect anomalies.

    A path that is already geometrically invalid is NOT scored here
    (geometric invalidity is separate from risk, per spec §18).

    Args:
        path: candidate path.
        anomalies: list of WorldAnomalySummary from World Model road.
        cfg: risk configuration.

    Returns:
        (road_hazard_risk in [0, 1], reason_codes).
    """
    codes: List[RiskReasonCode] = []
    if not anomalies:
        return 0.0, codes

    max_risk = 0.0
    waypoints = path.waypoints

    for anomaly in anomalies:
        ax = _finite(getattr(anomaly, "position_x", None))
        ay = _finite(getattr(anomaly, "position_y", None))
        if ax is None or ay is None:
            continue

        severity = getattr(anomaly, "severity", "UNKNOWN")
        base_hazard_risk = cfg.hazard_severity_risk.get(
            str(severity).upper(), cfg.hazard_severity_risk.get("UNKNOWN", 0.15)
        )

        # Check proximity to any path waypoint
        for wp in waypoints:
            wpx = _finite(wp.x)
            wpy = _finite(wp.y)
            if wpx is None or wpy is None:
                continue

            lateral_sep = abs(ay - wpy)
            long_sep = abs(ax - wpx)

            if (lateral_sep <= cfg.hazard_interaction_lateral_m and
                    long_sep <= cfg.clearance_safe_m):
                # Proximity factor: closer → more risk
                dist = math.sqrt((ax - wpx) ** 2 + (ay - wpy) ** 2)
                proximity_factor = _linear_risk(
                    dist, cfg.clearance_safe_m, cfg.clearance_critical_m
                )
                hazard_contribution = _clamp(base_hazard_risk * (0.4 + 0.6 * proximity_factor))
                if hazard_contribution > max_risk:
                    max_risk = hazard_contribution
                break  # one anomaly contributes once

    if max_risk > 0.05:
        codes.append(RiskReasonCode.ROAD_HAZARD_INTERACTION)

    return _clamp(max_risk, 0.0, cfg.hazard_max_risk), codes


# ---------------------------------------------------------------------------
# Aggregation formula
# ---------------------------------------------------------------------------

def _aggregate_risk(
    breakdown: RiskBreakdown,
    cfg: PathRiskConfig,
) -> float:
    """
    Deterministic weighted aggregation of risk components.

    Formula (configurable weights):
        risk = w_ttc * ttc_risk
             + w_collision_likelihood * collision_likelihood_risk
             + w_clearance * clearance_risk
             + w_closest_approach * closest_approach_risk
             + w_intersection * trajectory_intersection_risk
             + w_temporal * temporal_risk
             + w_uncertainty * uncertainty_risk
             + w_vulnerable_user * vulnerable_user_risk
             + w_road_hazard * road_hazard_risk

    The sum is then normalised (clamped) to [0, 1].

    Components that are highly correlated (ttc + collision_likelihood)
    share their weight rather than stacking, which is achieved by
    configuring them as fractions of the total budget.
    """
    raw = (
        cfg.w_ttc               * breakdown.ttc_risk
        + cfg.w_collision_likelihood * breakdown.collision_likelihood_risk
        + cfg.w_clearance        * breakdown.clearance_risk
        + cfg.w_closest_approach * breakdown.closest_approach_risk
        + cfg.w_intersection     * breakdown.trajectory_intersection_risk
        + cfg.w_temporal         * breakdown.temporal_risk
        + cfg.w_uncertainty      * breakdown.uncertainty_risk
        + cfg.w_vulnerable_user  * breakdown.vulnerable_user_risk
        + cfg.w_road_hazard      * breakdown.road_hazard_risk
    )
    return _clamp(raw)


# ---------------------------------------------------------------------------
# Risk level classification
# ---------------------------------------------------------------------------

def _classify_risk_level(total_risk: float, cfg: PathRiskConfig) -> RiskLevel:
    """Classify normalised risk score into a categorical level."""
    if total_risk <= cfg.risk_level_low_max:
        return RiskLevel.LOW_RISK
    if total_risk <= cfg.risk_level_moderate_max:
        return RiskLevel.MODERATE_RISK
    if total_risk <= cfg.risk_level_high_max:
        return RiskLevel.HIGH_RISK
    return RiskLevel.CRITICAL_RISK


# ---------------------------------------------------------------------------
# Dominant reason selection
# ---------------------------------------------------------------------------

def _select_dominant_reason(
    reason_codes: List[RiskReasonCode],
) -> str:
    """
    Return the single most-important reason code as a string.

    Priority order: LOW_TTC > HIGH_COLLISION_LIKELIHOOD >
    TRAJECTORY_INTERSECTION > CLOSE_APPROACH > VULNERABLE_USER_NEAR_PATH >
    DYNAMIC_OBJECT_NEAR_PATH > (everything else alphabetically).
    """
    priority = [
        RiskReasonCode.LOW_TTC,
        RiskReasonCode.HIGH_COLLISION_LIKELIHOOD,
        RiskReasonCode.TRAJECTORY_INTERSECTION,
        RiskReasonCode.CROSSING_TRAJECTORY,
        RiskReasonCode.CLOSE_APPROACH,
        RiskReasonCode.TEMPORAL_CONFLICT,
        RiskReasonCode.VULNERABLE_USER_NEAR_PATH,
        RiskReasonCode.OBJECT_APPROACHING_PATH,
        RiskReasonCode.DYNAMIC_OBJECT_NEAR_PATH,
        RiskReasonCode.ROAD_HAZARD_INTERACTION,
        RiskReasonCode.STALE_PREDICTION,
        RiskReasonCode.UNCERTAIN_OBJECT_MOTION,
        RiskReasonCode.DEGRADED_SENSOR_INPUT,
        RiskReasonCode.HIGH_UNCERTAINTY,
        RiskReasonCode.MULTIPLE_OBJECTS_NEAR_PATH,
        RiskReasonCode.NARROW_CLEARANCE,
    ]
    code_set = set(reason_codes)
    for p in priority:
        if p in code_set:
            return p.value
    if reason_codes:
        return sorted(c.value for c in reason_codes)[0]
    return NOT_AVAILABLE


# ---------------------------------------------------------------------------
# Per-object risk evaluation
# ---------------------------------------------------------------------------

def _evaluate_object_for_path(
    path: CandidatePath,
    world_obj,                   # WorldObject
    cfg: PathRiskConfig,
) -> ObjectRiskContribution:
    """
    Evaluate the risk contribution of one WorldObject for one CandidatePath.

    Reuses:
      - WorldObject.position (clearance, temporal)
      - WorldObject.velocity (temporal)
      - WorldObject.collision.ttc_s / ttc_status (TTC risk)
      - WorldObject.collision.min_distance_m (closest approach)
      - WorldObject.collision.collision_likelihood (collision likelihood)
      - WorldObject.prediction.trajectory (trajectory intersection)
      - WorldObject.prediction.prediction_confidence (uncertainty)
      - WorldObject.quality.is_stale / is_degraded (uncertainty)
      - WorldObject.quality.data_age_s (stale check)
    """
    obj_id = (
        getattr(world_obj, "object_id", None)
        or getattr(world_obj, "track_id", None)
        or getattr(world_obj, "fused_id", None)
        or NOT_AVAILABLE
    )
    object_type = str(getattr(world_obj, "object_type", NOT_AVAILABLE))

    pos = getattr(world_obj, "position", None)
    vel = getattr(world_obj, "velocity", None)
    collision_info = getattr(world_obj, "collision", None)
    prediction_info = getattr(world_obj, "prediction", None)
    quality = getattr(world_obj, "quality", None)
    dims = getattr(world_obj, "dimensions", None)

    # Position
    obj_x = _finite(getattr(pos, "x", None)) if pos else None
    obj_y = _finite(getattr(pos, "y", None)) if pos else None

    # Velocity
    obj_vx = _finite(getattr(vel, "vx", None)) if vel else None
    obj_vy = _finite(getattr(vel, "vy", None)) if vel else None

    # Dimensions
    obj_half_width = 1.0  # conservative default
    if dims is not None:
        w = _finite(getattr(dims, "width_m", None))
        if w is not None and w > 0.1:
            obj_half_width = w / 2.0

    # TTC info (from WorldObjectCollisionInfo, Phase 7 re-packaging of Phase 4D)
    ttc_s: Optional[float] = None
    ttc_status: str = NOT_AVAILABLE
    min_distance_m: Optional[float] = None
    collision_likelihood: Optional[float] = None
    if collision_info is not None:
        ttc_s = _finite(getattr(collision_info, "ttc_s", None))
        ttc_status = str(getattr(collision_info, "ttc_status", NOT_AVAILABLE))
        min_distance_m = _finite(getattr(collision_info, "min_distance_m", None))
        collision_likelihood = _finite(getattr(collision_info, "collision_likelihood", None))

    # Prediction info
    prediction_confidence = 0.0
    trajectory: List[Tuple[float, float, float, float]] = []
    if prediction_info is not None:
        prediction_confidence = float(
            getattr(prediction_info, "prediction_confidence", 0.0) or 0.0
        )
        trajectory = getattr(prediction_info, "trajectory", []) or []

    # Quality flags
    is_stale = False
    is_degraded = False
    data_age_s = 0.0
    if quality is not None:
        is_stale = bool(getattr(quality, "is_stale", False))
        is_degraded = bool(getattr(quality, "is_degraded", False))
        data_age_s = float(getattr(quality, "data_age_s", 0.0) or 0.0)

    # VRU
    vru = _is_vru(object_type, cfg)

    # --- Component computations ---

    # 1. Clearance risk
    clearance_risk = _compute_clearance_risk(
        path, obj_x, obj_y, obj_half_width, cfg
    )

    # 2. TTC risk
    ttc_risk, ttc_codes = _compute_ttc_risk(
        ttc_s, ttc_status, data_age_s, cfg
    )

    # 3. Closest approach risk
    ca_risk, ca_codes = _compute_closest_approach_risk(min_distance_m, cfg)

    # 4. Trajectory intersection risk
    intersection_risk, inter_codes = _compute_trajectory_intersection_risk(
        path, trajectory, cfg
    )

    # 5. Collision likelihood risk
    cl_risk, cl_codes = _compute_collision_likelihood_risk(
        collision_likelihood, cfg
    )

    # 6. Temporal risk
    temporal_risk, temp_codes = _compute_temporal_risk(
        obj_vx, obj_vy, path, obj_x, obj_y, cfg
    )

    # 7. Uncertainty risk
    uncertainty_risk, unc_codes = _compute_uncertainty_risk(
        prediction_confidence, is_stale, is_degraded, cfg
    )

    # 8. VRU pre-combination check
    pre_vru_risk = max(clearance_risk, ttc_risk, intersection_risk, cl_risk)
    vru_risk = _compute_vru_risk(vru, pre_vru_risk, cfg)

    # Accumulate all reason codes
    all_codes: List[RiskReasonCode] = []
    if clearance_risk >= 0.5:
        all_codes.append(RiskReasonCode.DYNAMIC_OBJECT_NEAR_PATH)
        if clearance_risk >= 0.7:
            all_codes.append(RiskReasonCode.LOW_CLEARANCE)
    all_codes.extend(ttc_codes)
    all_codes.extend(ca_codes)
    all_codes.extend(inter_codes)
    all_codes.extend(cl_codes)
    all_codes.extend(temp_codes)
    all_codes.extend(unc_codes)
    if vru and vru_risk > 0:
        all_codes.append(RiskReasonCode.VULNERABLE_USER_NEAR_PATH)

    # Per-object aggregation: take weighted max-dominance combination
    # Avoid double-counting correlated signals (ttc ↔ collision_likelihood)
    obj_type_mult = _object_type_multiplier(object_type, cfg)

    combined = _clamp(
        cfg.w_clearance * clearance_risk
        + cfg.w_ttc * ttc_risk
        + cfg.w_closest_approach * ca_risk
        + cfg.w_intersection * intersection_risk
        + cfg.w_collision_likelihood * cl_risk
        + cfg.w_temporal * temporal_risk
        + cfg.w_uncertainty * uncertainty_risk
        + cfg.w_vulnerable_user * vru_risk
    ) * obj_type_mult

    combined = _clamp(combined)

    # Deduplicate reason codes, preserving insertion order
    seen = set()
    unique_codes: List[RiskReasonCode] = []
    for rc in all_codes:
        if rc not in seen:
            seen.add(rc)
            unique_codes.append(rc)

    is_critical = combined >= 0.75 or ttc_risk >= 0.9 or intersection_risk >= 0.8

    return ObjectRiskContribution(
        object_id=obj_id if obj_id else NOT_AVAILABLE,
        object_type=object_type,
        is_vulnerable_user=vru,
        clearance_risk=clearance_risk,
        temporal_risk=temporal_risk,
        ttc_risk=ttc_risk,
        closest_approach_risk=ca_risk,
        intersection_risk=intersection_risk,
        collision_likelihood_risk=cl_risk,
        uncertainty_risk=uncertainty_risk,
        vulnerable_user_risk=vru_risk,
        combined_object_risk=combined,
        reason_codes=tuple(unique_codes),
        ttc_s=ttc_s,
        ttc_status=ttc_status,
        min_separation_m=min_distance_m,
        is_critical=is_critical,
    )


# ---------------------------------------------------------------------------
# Per-candidate risk evaluation
# ---------------------------------------------------------------------------

def _evaluate_candidate(
    candidate: CandidatePath,
    world_model_snapshot,         # WorldModelSnapshot or None
    cfg: PathRiskConfig,
    frame_id: int,
    planning_allowed: bool,
) -> CandidatePathRisk:
    """
    Evaluate the full risk of one CandidatePath.

    Args:
        candidate: the candidate path to evaluate.
        world_model_snapshot: Phase 7 WorldModelSnapshot (may be None).
        cfg: risk configuration.
        frame_id: processing frame counter.
        planning_allowed: from Phase 8.4 PlanningContext.

    Returns:
        CandidatePathRisk.
    """
    cid = candidate.candidate_id

    # --- Geometric validity check (from Phase 9.2, not re-evaluated) ---
    is_geo_invalid = (
        candidate.geometric_validity == GeometricValidity.INVALID
        or candidate.boundary_validity == BoundaryValidity.INVALID
    )

    base_risk = CandidatePathRisk(
        candidate_id=cid,
        frame_id=frame_id,
        timestamp=time.time(),
        coordinate_frame="VEHICLE",
        schema_version="9.3",
    )

    if is_geo_invalid:
        return CandidatePathRisk(
            candidate_id=cid,
            frame_id=frame_id,
            timestamp=time.time(),
            coordinate_frame="VEHICLE",
            total_risk=1.0,
            risk_level=RiskLevel.CRITICAL_RISK,
            confidence=0.0,
            uncertainty=1.0,
            degraded=True,
            is_geometrically_invalid=True,
            dominant_risk_reason=RiskReasonCode.CANDIDATE_GEOMETRICALLY_INVALID.value,
            reason_codes=(RiskReasonCode.CANDIDATE_GEOMETRICALLY_INVALID,),
            schema_version="9.3",
        )

    # --- World Model unavailable ---
    if world_model_snapshot is None:
        return CandidatePathRisk(
            candidate_id=cid,
            frame_id=frame_id,
            timestamp=time.time(),
            coordinate_frame="VEHICLE",
            total_risk=0.5,    # unknown → moderate risk (not zero)
            risk_level=RiskLevel.UNKNOWN_RISK,
            confidence=0.0,
            uncertainty=1.0,
            degraded=True,
            dominant_risk_reason=RiskReasonCode.WORLD_MODEL_UNAVAILABLE.value,
            reason_codes=(RiskReasonCode.WORLD_MODEL_UNAVAILABLE,),
            schema_version="9.3",
        )

    # --- Collect dynamic objects ---
    wm_objects = list(getattr(world_model_snapshot, "objects", ()) or ())
    # Bound evaluation
    if len(wm_objects) > cfg.max_objects_per_candidate:
        # Prioritise objects with high collision risk from World Model
        def _obj_risk_key(o):
            rl = getattr(getattr(o, "collision", None), "risk_level", "LOW")
            order = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3}
            return order.get(str(rl), 4)
        wm_objects = sorted(wm_objects, key=_obj_risk_key)[:cfg.max_objects_per_candidate]

    # --- Evaluate per-object contributions ---
    contributions: List[ObjectRiskContribution] = []
    for obj in wm_objects:
        try:
            contrib = _evaluate_object_for_path(candidate, obj, cfg)
            contributions.append(contrib)
        except Exception:
            # Individual object failure must not crash the whole evaluation
            pass

    # --- Road hazard risk ---
    road = getattr(world_model_snapshot, "road", None)
    anomalies = list(getattr(road, "anomalies", []) or [])
    hazard_risk, hazard_codes = _compute_road_hazard_risk(candidate, anomalies, cfg)

    # --- Build aggregate breakdown ---
    # Take the maximum (or weighted sum) across all object contributions
    # for each component to avoid single-object domination hiding others.

    def _max_contrib(attr: str) -> float:
        if not contributions:
            return 0.0
        return max(getattr(c, attr, 0.0) for c in contributions)

    def _weighted_sum_contrib(attr: str) -> float:
        if not contributions:
            return 0.0
        # Use max of individual contributions (prevents hiding critical obj)
        vals = [getattr(c, attr, 0.0) for c in contributions]
        if not vals:
            return 0.0
        # Weighted combine: max + fraction of next-highest
        vals_sorted = sorted(vals, reverse=True)
        result = vals_sorted[0]
        if len(vals_sorted) > 1:
            result = min(1.0, result + 0.3 * vals_sorted[1])
        return _clamp(result)

    breakdown = RiskBreakdown(
        clearance_risk=_weighted_sum_contrib("clearance_risk"),
        temporal_risk=_weighted_sum_contrib("temporal_risk"),
        ttc_risk=_weighted_sum_contrib("ttc_risk"),
        closest_approach_risk=_weighted_sum_contrib("closest_approach_risk"),
        trajectory_intersection_risk=_weighted_sum_contrib("intersection_risk"),
        collision_likelihood_risk=_weighted_sum_contrib("collision_likelihood_risk"),
        uncertainty_risk=_weighted_sum_contrib("uncertainty_risk"),
        vulnerable_user_risk=_weighted_sum_contrib("vulnerable_user_risk"),
        road_hazard_risk=hazard_risk,
    )

    # --- Aggregate total risk ---
    total_risk = _aggregate_risk(breakdown, cfg)

    # --- Multiple objects bonus ---
    dynamic_count = len(contributions)
    critical_count = sum(1 for c in contributions if c.is_critical)
    if dynamic_count >= 3:
        total_risk = _clamp(total_risk + 0.05)  # small multi-object penalty

    # --- Reason codes aggregation ---
    all_reason_codes: List[RiskReasonCode] = []
    for c in contributions:
        all_reason_codes.extend(c.reason_codes)
    all_reason_codes.extend(hazard_codes)
    if dynamic_count == 0:
        all_reason_codes.append(RiskReasonCode.NO_DYNAMIC_OBJECTS)
    elif dynamic_count >= 3:
        all_reason_codes.append(RiskReasonCode.MULTIPLE_OBJECTS_NEAR_PATH)

    # Deduplicate
    seen_r: set = set()
    unique_reason_codes: List[RiskReasonCode] = []
    for rc in all_reason_codes:
        if rc not in seen_r:
            seen_r.add(rc)
            unique_reason_codes.append(rc)

    # --- Risk level ---
    risk_level = _classify_risk_level(total_risk, cfg)

    # --- Dominant reason ---
    dominant_reason = _select_dominant_reason(unique_reason_codes)

    # --- Confidence / uncertainty ---
    wm_quality = getattr(world_model_snapshot, "data_quality", None)
    wm_confidence = float(getattr(wm_quality, "overall_confidence", 0.5) or 0.5)
    wm_uncertainty = float(getattr(wm_quality, "overall_uncertainty", 0.5) or 0.5)
    is_degraded = bool(getattr(wm_quality, "is_partial", True))

    # Affected object IDs
    affected_ids = tuple(
        c.object_id for c in contributions
        if c.combined_object_risk > 0.05 and c.object_id != NOT_AVAILABLE
    )

    return CandidatePathRisk(
        candidate_id=cid,
        frame_id=frame_id,
        timestamp=time.time(),
        coordinate_frame="VEHICLE",
        total_risk=total_risk,
        risk_level=risk_level,
        breakdown=breakdown,
        dynamic_object_count=dynamic_count,
        critical_object_count=critical_count,
        object_contributions=tuple(contributions),
        affected_object_ids=affected_ids,
        dominant_risk_reason=dominant_reason,
        reason_codes=tuple(unique_reason_codes),
        confidence=_clamp(wm_confidence),
        uncertainty=_clamp(wm_uncertainty),
        degraded=is_degraded,
        is_geometrically_invalid=False,
        schema_version="9.3",
    )


# ---------------------------------------------------------------------------
# PathRiskEngine — public API
# ---------------------------------------------------------------------------

class PathRiskEngine:
    """
    Phase 9.3 Dynamic Obstacle & Path Risk Scoring Engine.

    Evaluates the dynamic and temporal risk of each candidate path
    using existing World Model, prediction, and safety context.

    This engine:
      * DOES NOT select a best path
      * DOES NOT generate paths
      * DOES NOT issue vehicle control commands
      * DOES NOT reimplement TTC, closest approach, or trajectory prediction
      * IS fully deterministic (same input + config → same output)

    Usage:
        engine = PathRiskEngine(cfg)
        risk_set = engine.evaluate(
            candidate_paths,
            world_model_snapshot,
            planning_context,
            frame_id=42,
        )
    """

    def __init__(self, cfg: PathRiskConfig | None = None):
        """
        Args:
            cfg: PathRiskConfig; if None, uses default configuration.
        """
        self._cfg = cfg if cfg is not None else PathRiskConfig()

    @property
    def config(self) -> PathRiskConfig:
        return self._cfg

    def evaluate(
        self,
        candidate_paths: Sequence[CandidatePath],
        world_model_snapshot,          # WorldModelSnapshot or None
        planning_context=None,         # PlanningContext from Phase 8.4 or None
        frame_id: int = 0,
        set_id: str = NOT_AVAILABLE,
    ) -> PathRiskSet:
        """
        Evaluate dynamic risk for each candidate path.

        Args:
            candidate_paths: sequence of CandidatePath from Phase 9.2.
            world_model_snapshot: Phase 7 WorldModelSnapshot (may be None).
            planning_context: Phase 8.4 PlanningContext (may be None).
            frame_id: processing frame counter.
            set_id: optional set ID for the result.

        Returns:
            PathRiskSet containing one CandidatePathRisk per candidate.
            NEVER contains a selected/best path.
        """
        t0 = time.perf_counter()

        # --- Safety gate check (Phase 8.4) ---
        planning_allowed = True
        if planning_context is not None:
            planning_allowed = bool(
                getattr(planning_context, "planning_allowed", True)
            )

        if not planning_allowed:
            # Phase 8.4 has forbidden planning — return restricted state
            return PathRiskSet(
                set_id=set_id,
                frame_id=frame_id,
                timestamp=time.time(),
                coordinate_frame="VEHICLE",
                status=PathRiskStatus.PLANNING_RESTRICTED,
                status_reason="Phase 8.4 planning_allowed=False",
                _risks=tuple(),
                evaluation_duration_s=time.perf_counter() - t0,
            )

        if not candidate_paths:
            return PathRiskSet(
                set_id=set_id,
                frame_id=frame_id,
                timestamp=time.time(),
                coordinate_frame="VEHICLE",
                status=PathRiskStatus.NO_CANDIDATES,
                status_reason="No candidate paths to evaluate",
                _risks=tuple(),
                evaluation_duration_s=time.perf_counter() - t0,
            )

        # --- Evaluate each candidate ---
        risks: List[CandidatePathRisk] = []
        any_degraded = False

        for candidate in candidate_paths:
            try:
                risk = _evaluate_candidate(
                    candidate,
                    world_model_snapshot,
                    self._cfg,
                    frame_id,
                    planning_allowed,
                )
                risks.append(risk)
                if risk.degraded:
                    any_degraded = True
            except Exception:
                # Must not crash — emit an unavailable risk for this candidate
                risks.append(CandidatePathRisk(
                    candidate_id=getattr(candidate, "candidate_id", NOT_AVAILABLE),
                    frame_id=frame_id,
                    timestamp=time.time(),
                    coordinate_frame="VEHICLE",
                    total_risk=0.5,
                    risk_level=RiskLevel.UNKNOWN_RISK,
                    confidence=0.0,
                    uncertainty=1.0,
                    degraded=True,
                    dominant_risk_reason=RiskReasonCode.WORLD_MODEL_UNAVAILABLE.value,
                    reason_codes=(RiskReasonCode.WORLD_MODEL_UNAVAILABLE,),
                    schema_version="9.3",
                ))
                any_degraded = True

        status = PathRiskStatus.DEGRADED if any_degraded else PathRiskStatus.EVALUATED

        return PathRiskSet(
            set_id=set_id,
            frame_id=frame_id,
            timestamp=time.time(),
            coordinate_frame="VEHICLE",
            status=status,
            status_reason="",
            _risks=tuple(risks),
            evaluation_duration_s=time.perf_counter() - t0,
        )
