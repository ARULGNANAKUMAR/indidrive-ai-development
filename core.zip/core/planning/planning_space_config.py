"""
IndiDrive AI — Phase 9.1 | Planning Space Configuration
========================================================
All configurable thresholds and limits for Phase 9.1.
No magic numbers are embedded in the builder — every configurable
value lives here with a documented default.

Conventions follow Phase 7 WorldModelConfig pattern.
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Optional

import yaml  # PyYAML — already in requirements.txt

__all__ = [
    "PlanningSpaceConfig",
    "load_planning_space_config",
]

CONFIG_VERSION = "9.1"

# Default config section name inside the YAML file
_YAML_SECTION = "phase_9_1"


@dataclass
class PlanningSpaceConfig:
    """
    Configuration for Phase 9.1 Planning Space builder.

    All defaults are chosen conservatively for Indian-road conditions.
    """

    # --- Enable / disable ---
    enabled: bool = True

    # --- Planning horizon ---
    planning_horizon_m: float = 50.0
    """Forward planning horizon in metres.
    Default 50 m is appropriate for urban Indian roads at moderate speed.
    """

    lateral_extent_m: float = 10.0
    """Half-width lateral coverage (metres, both sides from vehicle centreline).
    Default 10 m covers a 20 m total lateral band.
    """

    temporal_horizon_s: float = 5.0
    """Temporal horizon in seconds (used when prediction data is available).
    Default 5 s matches typical short-horizon prediction windows.
    """

    # --- Grid / region limits ---
    max_dynamic_objects: int = 64
    """Maximum dynamic object entries in the planning space."""

    max_static_hazards: int = 32
    """Maximum static hazard entries."""

    max_drivable_regions: int = 16
    """Maximum drivable region entries."""

    max_non_drivable_regions: int = 32
    """Maximum non-drivable region entries."""

    max_restricted_regions: int = 32
    """Maximum restricted region entries."""

    max_boundary_points: int = 128
    """Maximum boundary segment points per boundary side."""

    max_hard_constraints: int = 16
    """Maximum hard constraint summaries carried forward."""

    max_soft_constraints: int = 32
    """Maximum soft constraint summaries carried forward."""

    # --- Determinism ---
    deterministic: bool = True
    """Guarantee stable ordering of all output collections."""

    # --- Degradation thresholds ---
    min_confidence_for_drivable: float = 0.3
    """Minimum confidence to classify a region as DRIVABLE (not UNCERTAIN)."""

    stale_threshold_s: float = 1.0
    """World model inputs older than this are treated as STALE."""

    @classmethod
    def from_dict(cls, data: dict) -> "PlanningSpaceConfig":
        """Create from a dict, ignoring unknown keys (forward-compatible)."""
        known = {f for f in cls.__dataclass_fields__}  # type: ignore[attr-defined]
        filtered = {k: v for k, v in data.items() if k in known}
        return cls(**filtered)

    def to_dict(self) -> dict:
        return {
            "config_version": CONFIG_VERSION,
            "enabled": self.enabled,
            "planning_horizon_m": self.planning_horizon_m,
            "lateral_extent_m": self.lateral_extent_m,
            "temporal_horizon_s": self.temporal_horizon_s,
            "max_dynamic_objects": self.max_dynamic_objects,
            "max_static_hazards": self.max_static_hazards,
            "max_drivable_regions": self.max_drivable_regions,
            "max_non_drivable_regions": self.max_non_drivable_regions,
            "max_restricted_regions": self.max_restricted_regions,
            "max_boundary_points": self.max_boundary_points,
            "max_hard_constraints": self.max_hard_constraints,
            "max_soft_constraints": self.max_soft_constraints,
            "deterministic": self.deterministic,
            "min_confidence_for_drivable": self.min_confidence_for_drivable,
            "stale_threshold_s": self.stale_threshold_s,
        }


def load_planning_space_config(
    config_path: Optional[Path] = None,
) -> PlanningSpaceConfig:
    """Load PlanningSpaceConfig from a YAML file.

    Falls back to safe defaults if the file is absent or the
    `phase_9_1` section is missing.
    """
    if config_path is None:
        # Locate default config relative to this file
        config_path = (
            Path(__file__).resolve().parent.parent.parent
            / "config"
            / "planning_space_config.yaml"
        )

    if not config_path.exists():
        return PlanningSpaceConfig()

    try:
        with open(config_path, "r", encoding="utf-8") as fh:
            raw = yaml.safe_load(fh) or {}
        section = raw.get(_YAML_SECTION, raw)
        return PlanningSpaceConfig.from_dict(section)
    except Exception:
        # Never crash the pipeline on a config read error — use defaults.
        return PlanningSpaceConfig()
