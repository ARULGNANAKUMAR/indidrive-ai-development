"""
IndiDrive AI — Phase 9.1 | Planning Snapshot
=============================================
Immutable snapshot wrapper for PlanningSpace.

Follows the same snapshot pattern as Phase 7 WorldModelSnapshot
and Phase 8.4 ArbitrationSnapshot.
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Optional

from .planning_space_types import PlanningSpace, NOT_AVAILABLE
from .planning_space_validator import PlanningSpaceValidationResult

__all__ = [
    "PlanningSnapshot",
]


@dataclass
class PlanningSnapshot:
    """
    Immutable snapshot of the Phase 9.1 planning space for one cycle.

    Consumers read this; they MUST NOT mutate it.

    Fields
    ------
    space               : the PlanningSpace for this cycle.
    validation          : validation result from construction.
    build_duration_s    : wall-clock time to build (informational only).
    snapshot_id         : unique ID for this snapshot.
    timestamp           : wall-clock time when snapshot was assembled.
    """
    space: PlanningSpace
    validation: PlanningSpaceValidationResult = field(
        default_factory=PlanningSpaceValidationResult
    )
    build_duration_s: float = 0.0
    snapshot_id: str = NOT_AVAILABLE
    timestamp: float = field(default_factory=time.time)

    @property
    def is_valid(self) -> bool:
        return self.validation.is_valid

    @property
    def planning_allowed(self) -> bool:
        return self.space.planning_allowed

    @property
    def safety_gate_state(self) -> str:
        return self.space.safety_gate_state

    def to_dict(self) -> dict:
        return {
            "snapshot_id": self.snapshot_id,
            "timestamp": self.timestamp,
            "build_duration_s": round(self.build_duration_s, 6),
            "is_valid": self.is_valid,
            "space": self.space.to_dict(),
            "validation": self.validation.to_dict(),
        }
