"""
IndiDrive AI — Phase 9.2 | Candidate Snapshot
=============================================
Immutable snapshot wrapper for a CandidatePathSet.

Follows the same snapshot pattern as Phase 9.1 PlanningSnapshot
and Phase 8.4 ArbitrationSnapshot.
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field

from .candidate_path_types import (
    NOT_AVAILABLE,
    CandidatePathSet,
    CandidateGenerationStatus,
)
from .candidate_validator import CandidateSetValidationResult

__all__ = [
    "CandidateSnapshot",
]


@dataclass
class CandidateSnapshot:
    """
    Immutable snapshot of the Phase 9.2 candidate path set for one cycle.

    Consumers read this; they MUST NOT mutate it.

    Fields
    ------
    path_set            : the CandidatePathSet for this cycle.
    validation          : set-level validation result from construction.
    generation_duration_s: wall-clock time to generate (informational only).
    snapshot_id         : unique ID for this snapshot.
    timestamp           : wall-clock time when snapshot was assembled.
    """
    path_set: CandidatePathSet
    validation: CandidateSetValidationResult = field(
        default_factory=CandidateSetValidationResult
    )
    generation_duration_s: float = 0.0
    snapshot_id: str = NOT_AVAILABLE
    timestamp: float = field(default_factory=time.time)

    @property
    def is_valid(self) -> bool:
        return self.validation.is_valid

    @property
    def has_candidates(self) -> bool:
        return self.path_set.has_candidates

    @property
    def candidate_count(self) -> int:
        return self.path_set.candidate_count

    @property
    def planning_allowed(self) -> bool:
        return self.path_set.planning_allowed

    @property
    def safety_gate_state(self) -> str:
        return self.path_set.safety_gate_state

    @property
    def generation_status(self) -> CandidateGenerationStatus:
        return self.path_set.generation_status

    def to_dict(self) -> dict:
        return {
            "snapshot_id": self.snapshot_id,
            "timestamp": self.timestamp,
            "generation_duration_s": round(self.generation_duration_s, 6),
            "is_valid": self.is_valid,
            "has_candidates": self.has_candidates,
            "candidate_count": self.candidate_count,
            "path_set": self.path_set.to_dict(),
            "validation": self.validation.to_dict(),
        }
