"""
IndiDrive AI — Phase 9.1 + Phase 9.2 | Adaptive Path Planning
==============================================================
Phase 9.1: Planning Space & Planning Input Foundation.
Phase 9.2: Candidate Path Generation.
"""
from .planning_input_types import PlanningInput, PlanningInputValidationResult
from .planning_space_types import (
    PlanningSpace,
    PlanningSpaceStatus,
    OccupancyState,
    DrivableState,
    RestrictionKind,
    EvidenceClass,
    PlanningHorizon,
    PlanningRegion,
    DynamicObjectEntry,
    StaticHazardEntry,
    SafetyConstraintSummary,
    PlanningSpaceQuality,
    BoundarySegment,
    CoordinateFrameInfo,
    SpatialExtent,
    NOT_AVAILABLE,
    PLANNING_SPACE_SCHEMA_VERSION,
)
from .planning_snapshot import PlanningSnapshot
from .planning_space_builder import PlanningSpaceBuilder
from .planning_space_config import PlanningSpaceConfig, load_planning_space_config
from .planning_space_validator import PlanningSpaceValidator, PlanningSpaceValidationResult

# --- Phase 9.2 exports ---
from .candidate_path_types import (
    CANDIDATE_PATH_SCHEMA_VERSION,
    GenerationMethod,
    GeometricValidity,
    BoundaryValidity,
    DrivableSpaceValidity,
    CandidateGenerationStatus,
    PathPoint,
    CandidateMetadata,
    CandidatePath,
    CandidatePathSet,
)
from .candidate_generator_config import CandidateGeneratorConfig, load_candidate_generator_config
from .candidate_generator import CandidatePathGenerator
from .candidate_validator import (
    CandidateValidator,
    CandidateValidationResult,
    CandidateSetValidationResult,
)
from .candidate_snapshot import CandidateSnapshot

__all__ = [
    # Phase 9.1
    "PlanningInput", "PlanningInputValidationResult",
    "PlanningSpace", "PlanningSpaceStatus", "OccupancyState", "DrivableState",
    "RestrictionKind", "EvidenceClass", "PlanningHorizon", "PlanningRegion",
    "DynamicObjectEntry", "StaticHazardEntry", "SafetyConstraintSummary",
    "PlanningSpaceQuality", "BoundarySegment", "CoordinateFrameInfo", "SpatialExtent",
    "PlanningSnapshot", "PlanningSpaceBuilder", "PlanningSpaceConfig",
    "load_planning_space_config", "PlanningSpaceValidator", "PlanningSpaceValidationResult",
    "NOT_AVAILABLE", "PLANNING_SPACE_SCHEMA_VERSION",
    # Phase 9.2
    "CANDIDATE_PATH_SCHEMA_VERSION",
    "GenerationMethod", "GeometricValidity", "BoundaryValidity",
    "DrivableSpaceValidity", "CandidateGenerationStatus",
    "PathPoint", "CandidateMetadata", "CandidatePath", "CandidatePathSet",
    "CandidateGeneratorConfig", "load_candidate_generator_config",
    "CandidatePathGenerator",
    "CandidateValidator", "CandidateValidationResult", "CandidateSetValidationResult",
    "CandidateSnapshot",
]

# --- Phase 9.3 exports ---
from .path_risk_types import (
    PATH_RISK_SCHEMA_VERSION,
    RiskLevel,
    RiskReasonCode,
    PathRiskStatus,
    ObjectRiskContribution,
    RiskBreakdown,
    CandidatePathRisk,
    PathRiskSet,
)
from .path_risk_config import PathRiskConfig, load_path_risk_config
from .path_risk_engine import PathRiskEngine
from .path_risk_validator import (
    PathRiskValidator,
    PathRiskValidationResult,
    PathRiskSetValidationResult,
)
from .path_risk_snapshot import PathRiskSnapshot

# --- Phase 9.4 exports ---
from .replanning_types import (
    REPLANNING_SCHEMA_VERSION,
    ReplanningDecision,
    ReplanningUrgency,
    ReplanningReasonCode,
    ActivePathValidity,
    CooldownState,
    ActivePath,
    PlanningStateSnapshot,
    ChangeMagnitudes,
    ReplanningRequest,
    ReplanningContext,
    ReplanningDecisionResult,
)
from .replanning_config import ReplanningConfig, load_replanning_config
from .active_path_monitor import ActivePathMonitor
from .replanning_change_detector import ChangeDetector, ChangeDetectionResult
from .replanning_engine import ReplanningEngine
from .replanning_validator import (
    ReplanningValidator,
    ReplanningValidationResult,
)

# --- Phase 9.5 exports ---
from .indian_road_planning_types import (
    INDIAN_ROAD_PLANNING_SCHEMA_VERSION,
    PlanningMode,
    LaneUsageMode,
    NarrowRoadState,
    RoadAnomalyConstraint,
    TrafficContextSummary,
    IndianRoadPlanningConstraints,
    IndianRoadPlanningResult,
)
from .indian_road_planning_config import (
    IndianRoadPlanningConfig,
    load_indian_road_planning_config,
)
from .indian_road_planning_adapter import IndianRoadPlanningAdapter

# Phase 9.6 — Final Planner Integration
from .planner_types import (
    NOT_AVAILABLE,
    PLANNER_SCHEMA_VERSION,
    PlannerStatus,
    PlannerState,
    InputValidationStatus,
    PlannerInput,
    PlannerOutput,
    PlannerSnapshot,
    CandidateSummary,
    RiskSummary,
    ReplanSummary,
    PlannerMetrics,
)
from .planner_config import PlannerConfig, load_planner_config
from .planner_validator import PlannerValidator, InputValidationResult, OutputValidationResult
from .planner_engine import PlannerEngine
from .planner_pipeline import PlannerPipeline, run_pipeline
from .planner_benchmark import PlannerBenchmark, BenchmarkResult
