"""
IndiDrive AI — Phase 9.1 | Planning Space Data Contracts
=========================================================
Strongly-typed structural containers for Phase 9.1 Planning Space.

Phase 9.1 answers:
    «"What space is currently available for a future planner to reason about?"»

Phase 9.1 does NOT answer:
    «"Which path should the vehicle take?"»
    «"What is the target speed?"»
    «"Which lane change is needed?"»

Those belong to Phase 9.2+ (candidate path generation) and later.

Design rules (same as all prior phases):
  * dataclasses — not raw dicts
  * explicit NOT_AVAILABLE / UNKNOWN — never fabricated
  * no path generation, no steering, no throttle, no MPC
  * confidence ≠ uncertainty ≠ completeness — kept separate
  * deterministic: same input → same output
  * compact: bounded tuples, summaries only
  * immutable snapshots (PlanningSnapshot)
  * offline — no LLM, no cloud, no neural networks

Coordinate convention (vehicle frame):
    +X = forward
    +Y = left
    +Z = up
    Origin = vehicle rear-axle centre
    Units = metres

This module contains ONLY structural containers.
Computation lives in planning_space_builder.py.
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from enum import Enum
from typing import List, Optional, Tuple

__all__ = [
    # Sentinel
    "NOT_AVAILABLE",
    # Schema
    "PLANNING_SPACE_SCHEMA_VERSION",
    # Enums
    "PlanningSpaceStatus",
    "OccupancyState",
    "DrivableState",
    "RestrictionKind",
    "EvidenceClass",
    "PlanningHorizonValidity",
    "RegionKind",
    # Sub-structures
    "CoordinateFrameInfo",
    "PlanningHorizon",
    "BoundarySegment",
    "SpatialExtent",
    "PlanningRegion",
    "DynamicObjectEntry",
    "StaticHazardEntry",
    "SafetyConstraintSummary",
    "PlanningSpaceQuality",
    # Primary output
    "PlanningSpace",
]

NOT_AVAILABLE = "NOT_AVAILABLE"
PLANNING_SPACE_SCHEMA_VERSION = "9.1"


# ---------------------------------------------------------------------------
# Status / health
# ---------------------------------------------------------------------------

class PlanningSpaceStatus(str, Enum):
    """Overall health of the PlanningSpace for this cycle.

    OK        — full or nearly-full inputs; planning space is usable.
    PARTIAL   — some upstream data missing; planning space is partially filled.
    DEGRADED  — significant upstream degradation; use with caution.
    RESTRICTED— active hard constraints restrict the available space.
    EMPTY     — no usable upstream inputs; planning space is skeleton only.
    INVALID   — validation failure; do not use.
    UNKNOWN   — status cannot be determined.
    """
    OK         = "OK"
    PARTIAL    = "PARTIAL"
    DEGRADED   = "DEGRADED"
    RESTRICTED = "RESTRICTED"
    EMPTY      = "EMPTY"
    INVALID    = "INVALID"
    UNKNOWN    = "UNKNOWN"


# ---------------------------------------------------------------------------
# Occupancy / drivability states
# ---------------------------------------------------------------------------

class OccupancyState(str, Enum):
    """Cell-level occupancy state for the planning grid.

    FREE       — no known occupancy; currently open space.
    DRIVABLE   — confirmed drivable by road understanding.
    RESTRICTED — hard restriction present (safety gate, boundary, anomaly).
    OCCUPIED   — dynamic or static object occupies this cell.
    UNKNOWN    — insufficient information to classify.
    """
    FREE       = "FREE"
    DRIVABLE   = "DRIVABLE"
    RESTRICTED = "RESTRICTED"
    OCCUPIED   = "OCCUPIED"
    UNKNOWN    = "UNKNOWN"


class DrivableState(str, Enum):
    """Drivability classification for a planning region or zone.

    DRIVABLE    — confirmed drivable.
    NON_DRIVABLE— confirmed non-drivable (boundary, off-road, obstacle).
    UNCERTAIN   — drivability is uncertain; should be treated conservatively.
    DEGRADED    — upstream data is degraded; drivability cannot be confirmed.
    UNKNOWN     — no information available.
    UNAVAILABLE — upstream data not present for this region.
    """
    DRIVABLE    = "DRIVABLE"
    NON_DRIVABLE = "NON_DRIVABLE"
    UNCERTAIN   = "UNCERTAIN"
    DEGRADED    = "DEGRADED"
    UNKNOWN     = "UNKNOWN"
    UNAVAILABLE = "UNAVAILABLE"


# ---------------------------------------------------------------------------
# Restriction kind
# ---------------------------------------------------------------------------

class RestrictionKind(str, Enum):
    """Category of a spatial restriction.

    ROAD_BOUNDARY      — physical or detected road edge.
    NON_DRIVABLE_AREA  — surface confirmed non-drivable.
    ROAD_ANOMALY       — pothole, debris, damaged road, etc.
    CONSTRUCTION       — active construction zone.
    DYNAMIC_OBJECT     — vehicle, pedestrian, cyclist, cattle, etc.
    SAFETY_HARD        — hard safety constraint from Phase 8.4.
    SAFETY_SOFT        — soft safety constraint from Phase 8.4.
    PREDICTED_CONFLICT — predicted future conflict zone.
    UNKNOWN            — restriction kind not classifiable.
    """
    ROAD_BOUNDARY      = "ROAD_BOUNDARY"
    NON_DRIVABLE_AREA  = "NON_DRIVABLE_AREA"
    ROAD_ANOMALY       = "ROAD_ANOMALY"
    CONSTRUCTION       = "CONSTRUCTION"
    DYNAMIC_OBJECT     = "DYNAMIC_OBJECT"
    SAFETY_HARD        = "SAFETY_HARD"
    SAFETY_SOFT        = "SAFETY_SOFT"
    PREDICTED_CONFLICT = "PREDICTED_CONFLICT"
    UNKNOWN            = "UNKNOWN"


# ---------------------------------------------------------------------------
# Evidence class (mirrors Phase 8/7 EvidenceType but scoped to Phase 9.1)
# ---------------------------------------------------------------------------

class EvidenceClass(str, Enum):
    """Epistemological class of evidence for a planning-space element.

    OBSERVED  — directly seen in current perception/world-model data.
    INFERRED  — derived from observable dynamics with explicit evidence.
    PREDICTED — from prediction hypotheses (not yet confirmed).
    COMBINED  — mixture of observed, inferred, and/or predicted.
    UNKNOWN   — evidence class cannot be determined.
    """
    OBSERVED  = "OBSERVED"
    INFERRED  = "INFERRED"
    PREDICTED = "PREDICTED"
    COMBINED  = "COMBINED"
    UNKNOWN   = "UNKNOWN"


# ---------------------------------------------------------------------------
# Region kind
# ---------------------------------------------------------------------------

class RegionKind(str, Enum):
    """Spatial region role within the planning space.

    DRIVABLE_CORRIDOR — primary forward drivable corridor.
    NON_DRIVABLE      — area confirmed non-drivable.
    UNKNOWN_SPACE     — space with insufficient information.
    RESTRICTED_ZONE   — area subject to active restriction.
    """
    DRIVABLE_CORRIDOR = "DRIVABLE_CORRIDOR"
    NON_DRIVABLE      = "NON_DRIVABLE"
    UNKNOWN_SPACE     = "UNKNOWN_SPACE"
    RESTRICTED_ZONE   = "RESTRICTED_ZONE"


# ---------------------------------------------------------------------------
# Planning horizon validity
# ---------------------------------------------------------------------------

class PlanningHorizonValidity(str, Enum):
    VALID       = "VALID"
    DEGRADED    = "DEGRADED"   # horizon is smaller than nominal due to degradation
    UNAVAILABLE = "UNAVAILABLE"
    UNKNOWN     = "UNKNOWN"


# ---------------------------------------------------------------------------
# Coordinate frame information
# ---------------------------------------------------------------------------

@dataclass
class CoordinateFrameInfo:
    """Explicit coordinate frame declaration for all planning-space geometry.

    All Phase 9.1 geometry uses the vehicle-relative frame:
        +X = forward, +Y = left, +Z = up
        origin = vehicle rear-axle centre
        units = metres
    """
    frame_id: str = "VEHICLE"
    convention: str = "+X_forward_+Y_left_+Z_up"
    unit: str = "metres"
    origin: str = "vehicle_rear_axle_centre"

    def to_dict(self) -> dict:
        return {
            "frame_id": self.frame_id,
            "convention": self.convention,
            "unit": self.unit,
            "origin": self.origin,
        }


# ---------------------------------------------------------------------------
# Planning horizon
# ---------------------------------------------------------------------------

@dataclass
class PlanningHorizon:
    """Configurable planning horizon for Phase 9.1.

    Defines how far forward and laterally the planning space is populated.
    Does NOT define a trajectory or path.

    Fields
    ------
    longitudinal_m   : forward extent in metres (+X direction).
    lateral_extent_m : half-width of lateral coverage (metres, both sides).
    temporal_horizon_s: optional temporal horizon in seconds (prediction window).
    validity         : whether the horizon is valid, degraded, or unavailable.
    source           : where the horizon parameters came from.
    """
    longitudinal_m: float = 50.0
    lateral_extent_m: float = 10.0
    temporal_horizon_s: Optional[float] = None
    validity: PlanningHorizonValidity = PlanningHorizonValidity.VALID
    source: str = "config"

    def to_dict(self) -> dict:
        return {
            "longitudinal_m": round(self.longitudinal_m, 2),
            "lateral_extent_m": round(self.lateral_extent_m, 2),
            "temporal_horizon_s": (
                round(self.temporal_horizon_s, 2)
                if self.temporal_horizon_s is not None
                else NOT_AVAILABLE
            ),
            "validity": self.validity.value,
            "source": self.source,
        }


# ---------------------------------------------------------------------------
# Boundary segment
# ---------------------------------------------------------------------------

@dataclass
class BoundarySegment:
    """One sample along a road or lane boundary polyline.

    Coordinates are in the vehicle frame (metres).
    x = forward distance, y = lateral position.
    """
    x: float = 0.0
    y: float = 0.0
    confidence: float = 0.0
    evidence: EvidenceClass = EvidenceClass.UNKNOWN

    def to_dict(self) -> dict:
        return {
            "x": round(self.x, 3),
            "y": round(self.y, 3),
            "confidence": round(self.confidence, 3),
            "evidence": self.evidence.value,
        }


# ---------------------------------------------------------------------------
# Spatial extent
# ---------------------------------------------------------------------------

@dataclass
class SpatialExtent:
    """Bounding extent of the planning space in vehicle frame.

    Only stores what is actually known.  Unknown values stay NOT_AVAILABLE.
    """
    forward_m: Optional[float] = None       # how far forward coverage reaches
    left_m: Optional[float] = None          # left boundary at vehicle position
    right_m: Optional[float] = None         # right boundary at vehicle position
    road_width_m: Optional[float] = None    # estimated road width if available
    left_boundary_available: bool = False
    right_boundary_available: bool = False
    left_boundary: Tuple[BoundarySegment, ...] = field(default_factory=tuple)
    right_boundary: Tuple[BoundarySegment, ...] = field(default_factory=tuple)

    def to_dict(self) -> dict:
        def _r(v):
            return round(v, 3) if v is not None else NOT_AVAILABLE
        return {
            "forward_m": _r(self.forward_m),
            "left_m": _r(self.left_m),
            "right_m": _r(self.right_m),
            "road_width_m": _r(self.road_width_m),
            "left_boundary_available": self.left_boundary_available,
            "right_boundary_available": self.right_boundary_available,
            "left_boundary_point_count": len(self.left_boundary),
            "right_boundary_point_count": len(self.right_boundary),
        }


# ---------------------------------------------------------------------------
# Planning region
# ---------------------------------------------------------------------------

@dataclass
class PlanningRegion:
    """One bounded spatial region within the planning space.

    Represents a sub-area characterised by its drivable state, restriction
    kind, and evidence.  Geometry is approximate — not a precision shape.

    Phase 9.2+ will use these regions for path candidate generation.
    """
    region_id: str = NOT_AVAILABLE
    kind: RegionKind = RegionKind.UNKNOWN_SPACE
    drivable_state: DrivableState = DrivableState.UNKNOWN
    restriction_kind: RestrictionKind = RestrictionKind.UNKNOWN
    # Approximate bounding box in vehicle frame
    x_min: Optional[float] = None
    x_max: Optional[float] = None
    y_min: Optional[float] = None
    y_max: Optional[float] = None
    confidence: float = 0.0
    uncertainty: float = 1.0
    evidence: EvidenceClass = EvidenceClass.UNKNOWN
    source: str = NOT_AVAILABLE

    def to_dict(self) -> dict:
        def _r(v):
            return round(v, 3) if v is not None else NOT_AVAILABLE
        return {
            "region_id": self.region_id,
            "kind": self.kind.value,
            "drivable_state": self.drivable_state.value,
            "restriction_kind": self.restriction_kind.value,
            "x_min": _r(self.x_min),
            "x_max": _r(self.x_max),
            "y_min": _r(self.y_min),
            "y_max": _r(self.y_max),
            "confidence": round(self.confidence, 3),
            "uncertainty": round(self.uncertainty, 3),
            "evidence": self.evidence.value,
            "source": self.source,
        }


# ---------------------------------------------------------------------------
# Dynamic object entry
# ---------------------------------------------------------------------------

@dataclass
class DynamicObjectEntry:
    """Compact projection of a WorldObject into the planning space.

    Phase 9.1 does NOT implement path-collision scoring or avoidance
    maneuver selection.  Those belong to Phase 9.3.

    This entry is a compact reference to existing upstream data only.
    """
    object_id: str = NOT_AVAILABLE
    object_type: str = NOT_AVAILABLE           # VEHICLE | PEDESTRIAN | CYCLIST | CATTLE | ...
    position_x: Optional[float] = None        # vehicle-frame metres
    position_y: Optional[float] = None
    velocity_x: Optional[float] = None        # m/s
    velocity_y: Optional[float] = None
    predicted_position_x: Optional[float] = None  # predicted position if available
    predicted_position_y: Optional[float] = None
    confidence: float = 0.0
    uncertainty: float = 1.0
    evidence: EvidenceClass = EvidenceClass.UNKNOWN
    prediction_available: bool = False
    time_valid_s: Optional[float] = None      # seconds from now prediction is valid
    # Approximate affected region bounding box (if computable from existing data)
    affected_x_min: Optional[float] = None
    affected_x_max: Optional[float] = None
    affected_y_min: Optional[float] = None
    affected_y_max: Optional[float] = None

    def to_dict(self) -> dict:
        def _r(v):
            return round(v, 3) if v is not None else NOT_AVAILABLE
        return {
            "object_id": self.object_id,
            "object_type": self.object_type,
            "position_x": _r(self.position_x),
            "position_y": _r(self.position_y),
            "velocity_x": _r(self.velocity_x),
            "velocity_y": _r(self.velocity_y),
            "predicted_position_x": _r(self.predicted_position_x),
            "predicted_position_y": _r(self.predicted_position_y),
            "confidence": round(self.confidence, 3),
            "uncertainty": round(self.uncertainty, 3),
            "evidence": self.evidence.value,
            "prediction_available": self.prediction_available,
            "time_valid_s": _r(self.time_valid_s),
        }


# ---------------------------------------------------------------------------
# Static hazard entry
# ---------------------------------------------------------------------------

@dataclass
class StaticHazardEntry:
    """Compact projection of a Phase 6 road anomaly into the planning space.

    Does NOT re-detect or re-estimate hazards.
    Consumes existing Phase 6 WorldAnomalySummary output only.
    """
    hazard_id: str = NOT_AVAILABLE
    hazard_type: str = NOT_AVAILABLE      # POTHOLE | DEBRIS | CONSTRUCTION | ...
    position_x: Optional[float] = None
    position_y: Optional[float] = None
    approx_width_m: Optional[float] = None
    approx_length_m: Optional[float] = None
    severity: str = NOT_AVAILABLE         # MINOR | MODERATE | SEVERE | CRITICAL
    drivability_impact: str = NOT_AVAILABLE
    confidence: float = 0.0
    uncertainty: float = 1.0
    evidence: EvidenceClass = EvidenceClass.UNKNOWN
    in_drivable_area: bool = False

    def to_dict(self) -> dict:
        def _r(v):
            return round(v, 3) if v is not None else NOT_AVAILABLE
        return {
            "hazard_id": self.hazard_id,
            "hazard_type": self.hazard_type,
            "position_x": _r(self.position_x),
            "position_y": _r(self.position_y),
            "approx_width_m": _r(self.approx_width_m),
            "approx_length_m": _r(self.approx_length_m),
            "severity": self.severity,
            "drivability_impact": self.drivability_impact,
            "confidence": round(self.confidence, 3),
            "uncertainty": round(self.uncertainty, 3),
            "evidence": self.evidence.value,
            "in_drivable_area": self.in_drivable_area,
        }


# ---------------------------------------------------------------------------
# Safety constraint summary
# ---------------------------------------------------------------------------

@dataclass
class SafetyConstraintSummary:
    """Compact projection of a Phase 8.4 SafetyConstraint into the planning space.

    Does NOT reinterpret or override Phase 8.4.
    Preserves what Phase 8.4 produced.
    """
    constraint_id: str = NOT_AVAILABLE
    constraint_type: str = NOT_AVAILABLE   # type string from Phase 8.4
    hardness: str = NOT_AVAILABLE          # HARD | SOFT
    description: str = NOT_AVAILABLE
    confidence: float = 0.0
    evidence: EvidenceClass = EvidenceClass.UNKNOWN

    def to_dict(self) -> dict:
        return {
            "constraint_id": self.constraint_id,
            "constraint_type": self.constraint_type,
            "hardness": self.hardness,
            "description": self.description,
            "confidence": round(self.confidence, 3),
            "evidence": self.evidence.value,
        }


# ---------------------------------------------------------------------------
# Road structure summary
# ---------------------------------------------------------------------------

@dataclass
class RoadStructureSummary:
    """Compact road structure information for the planning space.

    Derived from upstream Phase 6 / Phase 7 data.
    Does NOT invent lane geometry when upstream data does not have it.
    """
    marking_state: str = NOT_AVAILABLE        # MARKED | WEAKLY_MARKED | UNMARKED | UNKNOWN
    lane_count: Optional[int] = None
    lane_width_m: Optional[float] = None
    road_direction: str = NOT_AVAILABLE
    intersection_state: str = NOT_AVAILABLE   # NORMAL_ROAD | INTERSECTION | UNKNOWN
    curvature_summary: str = NOT_AVAILABLE    # STRAIGHT | MILD_CURVE | SHARP_CURVE | UNKNOWN
    lane_info_available: bool = False
    observed_vs_inferred: EvidenceClass = EvidenceClass.UNKNOWN
    confidence: float = 0.0
    uncertainty: float = 1.0
    is_degraded: bool = True

    def to_dict(self) -> dict:
        return {
            "marking_state": self.marking_state,
            "lane_count": self.lane_count if self.lane_count is not None else NOT_AVAILABLE,
            "lane_width_m": round(self.lane_width_m, 2) if self.lane_width_m is not None else NOT_AVAILABLE,
            "road_direction": self.road_direction,
            "intersection_state": self.intersection_state,
            "curvature_summary": self.curvature_summary,
            "lane_info_available": self.lane_info_available,
            "observed_vs_inferred": self.observed_vs_inferred.value,
            "confidence": round(self.confidence, 3),
            "uncertainty": round(self.uncertainty, 3),
            "is_degraded": self.is_degraded,
        }


# ---------------------------------------------------------------------------
# Indian road context summary
# ---------------------------------------------------------------------------

@dataclass
class IndianRoadContextSummary:
    """Compact Indian-road context projected into the planning space.

    Preserved for Phase 9.5 (Indian-road path planning adaptation).
    Does not modify the context — passes upstream data through.
    """
    available: bool = False
    road_type: str = NOT_AVAILABLE
    traffic_density: str = NOT_AVAILABLE
    vulnerable_road_users: bool = False
    cattle_present: bool = False
    roadside_activity: str = NOT_AVAILABLE
    market_like_activity: bool = False
    intersection_context: str = NOT_AVAILABLE
    road_complexity: str = NOT_AVAILABLE
    context_confidence: float = 0.0
    context_uncertainty: float = 1.0
    is_degraded: bool = True

    def to_dict(self) -> dict:
        return {
            "available": self.available,
            "road_type": self.road_type,
            "traffic_density": self.traffic_density,
            "vulnerable_road_users": self.vulnerable_road_users,
            "cattle_present": self.cattle_present,
            "roadside_activity": self.roadside_activity,
            "market_like_activity": self.market_like_activity,
            "intersection_context": self.intersection_context,
            "road_complexity": self.road_complexity,
            "context_confidence": round(self.context_confidence, 3),
            "context_uncertainty": round(self.context_uncertainty, 3),
            "is_degraded": self.is_degraded,
        }


# ---------------------------------------------------------------------------
# Planning space quality
# ---------------------------------------------------------------------------

@dataclass
class PlanningSpaceQuality:
    """Data quality metrics for the PlanningSpace.

    Distinguishes confidence, uncertainty, completeness, and degradation
    — these are NOT collapsed into a single score.
    """
    overall_confidence: float = 0.0        # [0, 1]
    overall_uncertainty: float = 1.0       # [0, ∞)
    completeness: float = 0.0              # fraction of expected inputs present
    is_degraded: bool = True
    is_partial: bool = True
    world_model_available: bool = False
    planning_context_available: bool = False
    road_info_available: bool = False
    dynamic_objects_available: bool = False
    static_hazards_available: bool = False
    warnings: Tuple[str, ...] = field(default_factory=tuple)

    def to_dict(self) -> dict:
        return {
            "overall_confidence": round(self.overall_confidence, 3),
            "overall_uncertainty": round(self.overall_uncertainty, 3),
            "completeness": round(self.completeness, 3),
            "is_degraded": self.is_degraded,
            "is_partial": self.is_partial,
            "world_model_available": self.world_model_available,
            "planning_context_available": self.planning_context_available,
            "road_info_available": self.road_info_available,
            "dynamic_objects_available": self.dynamic_objects_available,
            "static_hazards_available": self.static_hazards_available,
            "warning_count": len(self.warnings),
            "warnings": list(self.warnings),
        }


# ---------------------------------------------------------------------------
# Primary PlanningSpace container
# ---------------------------------------------------------------------------

@dataclass
class PlanningSpace:
    """
    One immutable structured representation of the currently usable
    planning space for one processing cycle.

    Consumers receive this and MUST NOT mutate it.

    Phase 9.1 answers: «"Where may a future planner potentially operate?"»

    Phase 9.1 does NOT answer:
        «"Which path should the vehicle take?"»
        «"What should the target speed be?"»

    FORBIDDEN fields (must never appear here):
        path, candidate_paths, trajectory, waypoints, steering_angle,
        throttle, brake, target_speed, acceleration_cmd,
        lane_change_command, overtake_command, steer_cmd,
        select_best_path, generate_path, avoid_obstacle.

    Fields
    ------
    schema_version      : Phase 9.1 schema version.
    space_id            : unique ID for this planning space.
    timestamp           : generation wall-clock time.
    frame_id            : processing frame counter.
    coordinate_frame    : declared coordinate frame (always VEHICLE).
    status              : overall health of this planning space.
    horizon             : forward + lateral + temporal planning horizon.
    spatial_extent      : bounding geometry of the space.
    road_structure      : road structure from upstream Phase 6/7.
    indian_road_context : Indian-road context from Phase 6.4.
    drivable_regions    : tuple of drivable PlanningRegion entries.
    non_drivable_regions: tuple of confirmed non-drivable regions.
    restricted_regions  : tuple of restriction-zone regions.
    dynamic_objects     : tuple of dynamic object entries.
    static_hazards      : tuple of static hazard entries.
    safety_constraints  : compact projection of Phase 8.4 constraints.
    safety_gate_state   : Phase 8.4 safety gate state (preserved, not modified).
    planning_allowed    : from Phase 8.4 PlanningContext.
    planning_mode       : from Phase 8.4 PlanningContext.
    quality             : data quality metrics.
    """
    schema_version: str = PLANNING_SPACE_SCHEMA_VERSION
    space_id: str = NOT_AVAILABLE
    timestamp: float = field(default_factory=time.time)
    frame_id: int = 0

    # Coordinate frame
    coordinate_frame: CoordinateFrameInfo = field(default_factory=CoordinateFrameInfo)

    # Overall status
    status: PlanningSpaceStatus = PlanningSpaceStatus.UNKNOWN

    # Planning horizon
    horizon: PlanningHorizon = field(default_factory=PlanningHorizon)

    # Spatial extent
    spatial_extent: SpatialExtent = field(default_factory=SpatialExtent)

    # Road structure
    road_structure: RoadStructureSummary = field(default_factory=RoadStructureSummary)

    # Indian road context
    indian_road_context: IndianRoadContextSummary = field(
        default_factory=IndianRoadContextSummary
    )

    # Spatial regions — kept as tuples for immutability
    _drivable_regions: Tuple[PlanningRegion, ...] = field(
        default_factory=tuple, repr=False
    )
    _non_drivable_regions: Tuple[PlanningRegion, ...] = field(
        default_factory=tuple, repr=False
    )
    _restricted_regions: Tuple[PlanningRegion, ...] = field(
        default_factory=tuple, repr=False
    )

    # Dynamic objects (projected from WorldModel)
    _dynamic_objects: Tuple[DynamicObjectEntry, ...] = field(
        default_factory=tuple, repr=False
    )

    # Static hazards (projected from Phase 6)
    _static_hazards: Tuple[StaticHazardEntry, ...] = field(
        default_factory=tuple, repr=False
    )

    # Safety constraints (projected from Phase 8.4)
    _hard_constraints: Tuple[SafetyConstraintSummary, ...] = field(
        default_factory=tuple, repr=False
    )
    _soft_constraints: Tuple[SafetyConstraintSummary, ...] = field(
        default_factory=tuple, repr=False
    )

    # Safety gate passthrough from Phase 8.4
    safety_gate_state: str = NOT_AVAILABLE  # SafetyGateState.value
    planning_allowed: bool = False
    planning_mode: str = NOT_AVAILABLE      # PlanningMode.value

    # Quality
    quality: PlanningSpaceQuality = field(default_factory=PlanningSpaceQuality)

    # ------------------------------------------------------------------
    # Immutable read-only properties
    # ------------------------------------------------------------------

    @property
    def drivable_regions(self) -> Tuple[PlanningRegion, ...]:
        return self._drivable_regions

    @property
    def non_drivable_regions(self) -> Tuple[PlanningRegion, ...]:
        return self._non_drivable_regions

    @property
    def restricted_regions(self) -> Tuple[PlanningRegion, ...]:
        return self._restricted_regions

    @property
    def dynamic_objects(self) -> Tuple[DynamicObjectEntry, ...]:
        return self._dynamic_objects

    @property
    def static_hazards(self) -> Tuple[StaticHazardEntry, ...]:
        return self._static_hazards

    @property
    def hard_constraints(self) -> Tuple[SafetyConstraintSummary, ...]:
        return self._hard_constraints

    @property
    def soft_constraints(self) -> Tuple[SafetyConstraintSummary, ...]:
        return self._soft_constraints

    @property
    def dynamic_object_count(self) -> int:
        return len(self._dynamic_objects)

    @property
    def static_hazard_count(self) -> int:
        return len(self._static_hazards)

    @property
    def hard_constraint_count(self) -> int:
        return len(self._hard_constraints)

    @property
    def soft_constraint_count(self) -> int:
        return len(self._soft_constraints)

    @property
    def drivable_region_count(self) -> int:
        return len(self._drivable_regions)

    @property
    def restricted_region_count(self) -> int:
        return len(self._restricted_regions)

    # ------------------------------------------------------------------
    # Serialisation
    # ------------------------------------------------------------------

    def to_dict(self) -> dict:
        return {
            "schema_version": self.schema_version,
            "space_id": self.space_id,
            "timestamp": self.timestamp,
            "frame_id": self.frame_id,
            "coordinate_frame": self.coordinate_frame.to_dict(),
            "status": self.status.value,
            "horizon": self.horizon.to_dict(),
            "spatial_extent": self.spatial_extent.to_dict(),
            "road_structure": self.road_structure.to_dict(),
            "indian_road_context": self.indian_road_context.to_dict(),
            "drivable_region_count": self.drivable_region_count,
            "drivable_regions": [r.to_dict() for r in self._drivable_regions],
            "non_drivable_region_count": len(self._non_drivable_regions),
            "non_drivable_regions": [r.to_dict() for r in self._non_drivable_regions],
            "restricted_region_count": self.restricted_region_count,
            "restricted_regions": [r.to_dict() for r in self._restricted_regions],
            "dynamic_object_count": self.dynamic_object_count,
            "dynamic_objects": [o.to_dict() for o in self._dynamic_objects],
            "static_hazard_count": self.static_hazard_count,
            "static_hazards": [h.to_dict() for h in self._static_hazards],
            "hard_constraint_count": self.hard_constraint_count,
            "hard_constraints": [c.to_dict() for c in self._hard_constraints],
            "soft_constraint_count": self.soft_constraint_count,
            "soft_constraints": [c.to_dict() for c in self._soft_constraints],
            "safety_gate_state": self.safety_gate_state,
            "planning_allowed": self.planning_allowed,
            "planning_mode": self.planning_mode,
            "quality": self.quality.to_dict(),
        }
