"""
IndiDrive AI — Phase 9.6 | Final Planner Integration — Pipeline Facade
========================================================================
High-level facade that orchestrates the full planning pipeline for one cycle.

This module provides a single run_pipeline() function that accepts raw
upstream outputs and drives them through all Phase 9.x stages in the
correct order, returning a PlannerOutput.

It does NOT implement new perception, prediction, sensor fusion, MPC,
or any vehicle controller.  It only connects existing phase outputs.

Pipeline order (per spec Section 4):
    Planning Space (9.1)
    → Indian-Road Adaptation (9.5)
    → Candidate Path Generation (9.2)   [pre-run if not supplied]
    → Dynamic Risk Scoring (9.3)        [pre-run if not supplied]
    → Adaptive Replanning (9.4)         [pre-run if not supplied]
    → Final Planner Integration (9.6)   ← PlannerEngine.run()
"""
from __future__ import annotations

import time
from typing import Optional, Tuple

from .planner_types import (
    NOT_AVAILABLE,
    PlannerInput,
    PlannerMetrics,
    PlannerOutput,
    PlannerSnapshot,
)
from .planner_engine import PlannerEngine
from .planner_config import PlannerConfig

__all__ = [
    "PlannerPipeline",
    "run_pipeline",
]


class PlannerPipeline:
    """
    Stateful pipeline wrapper that holds one PlannerEngine instance.

    Usage:
        pipeline = PlannerPipeline()
        output, snap, metrics = pipeline.run(
            frame_id=42,
            timestamp=1700000000.0,
            planning_space=my_ps,
            candidate_set=my_cs,
            risk_set=my_rs,
            replanning_result=my_rr,
            indian_road_result=my_irr,
            world_model_snapshot=my_wm,
            planning_context=my_pc,
        )
    """

    def __init__(self, config: Optional[PlannerConfig] = None) -> None:
        self._engine = PlannerEngine(config)

    def run(
        self,
        frame_id: int = 0,
        timestamp: Optional[float] = None,
        planning_space=None,
        candidate_set=None,
        risk_set=None,
        replanning_result=None,
        indian_road_result=None,
        world_model_snapshot=None,
        planning_context=None,
        planning_input=None,
    ) -> Tuple[PlannerOutput, PlannerSnapshot, PlannerMetrics]:
        """
        Run the integrated planning pipeline for one cycle.

        All parameters are optional — the engine gracefully degrades
        when upstream data is missing.

        Returns (PlannerOutput, PlannerSnapshot, PlannerMetrics).
        """
        inp = PlannerInput(
            frame_id=frame_id,
            timestamp=timestamp if timestamp is not None else time.time(),
            planning_space=planning_space,
            candidate_set=candidate_set,
            risk_set=risk_set,
            replanning_result=replanning_result,
            indian_road_result=indian_road_result,
            world_model_snapshot=world_model_snapshot,
            planning_context=planning_context,
            planning_input=planning_input,
        )
        return self._engine.run(inp)

    def reset(self) -> None:
        """Reset planner state between scenarios."""
        self._engine.reset()

    @property
    def last_snapshot(self) -> Optional[PlannerSnapshot]:
        return self._engine.last_snapshot


def run_pipeline(
    frame_id: int = 0,
    timestamp: Optional[float] = None,
    planning_space=None,
    candidate_set=None,
    risk_set=None,
    replanning_result=None,
    indian_road_result=None,
    world_model_snapshot=None,
    planning_context=None,
    planning_input=None,
    config: Optional[PlannerConfig] = None,
) -> Tuple[PlannerOutput, PlannerSnapshot, PlannerMetrics]:
    """
    Convenience function: create a fresh pipeline and run one cycle.

    Use PlannerPipeline for repeated calls to preserve state.
    """
    pipeline = PlannerPipeline(config)
    return pipeline.run(
        frame_id=frame_id,
        timestamp=timestamp,
        planning_space=planning_space,
        candidate_set=candidate_set,
        risk_set=risk_set,
        replanning_result=replanning_result,
        indian_road_result=indian_road_result,
        world_model_snapshot=world_model_snapshot,
        planning_context=planning_context,
        planning_input=planning_input,
    )
