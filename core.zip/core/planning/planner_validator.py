"""
IndiDrive AI — Phase 9.6 | Final Planner Integration — Validator
=================================================================
Stage 1: Input Validation for the integrated planning pipeline.

Validates:
  - required fields
  - frame consistency
  - timestamps / staleness
  - coordinate frame
  - candidate validity
  - risk availability
  - safety state
  - planning permission
  - replanning consistency
  - output schema integrity
"""
from __future__ import annotations

import math
import time
from dataclasses import dataclass, field
from typing import List, Optional, Tuple

from .planner_types import (
    NOT_AVAILABLE,
    InputValidationStatus,
    PlannerInput,
    PlannerOutput,
    PlannerStatus,
)
from .planner_config import PlannerConfig

__all__ = [
    "PlannerValidator",
    "InputValidationResult",
    "OutputValidationResult",
]


@dataclass
class InputValidationResult:
    """Result of Stage 1 input validation."""
    status: InputValidationStatus = InputValidationStatus.INVALID
    errors: Tuple[str, ...] = field(default_factory=tuple)
    warnings: Tuple[str, ...] = field(default_factory=tuple)
    planning_allowed: bool = False
    safety_gate_state: str = NOT_AVAILABLE
    stale_fields: Tuple[str, ...] = field(default_factory=tuple)

    @property
    def is_valid(self) -> bool:
        return self.status in (
            InputValidationStatus.VALID,
            InputValidationStatus.VALID_DEGRADED,
        )

    def to_dict(self) -> dict:
        return {
            "status": self.status.value,
            "is_valid": self.is_valid,
            "planning_allowed": self.planning_allowed,
            "safety_gate_state": self.safety_gate_state,
            "error_count": len(self.errors),
            "errors": list(self.errors),
            "warning_count": len(self.warnings),
            "warnings": list(self.warnings),
            "stale_fields": list(self.stale_fields),
        }


@dataclass
class OutputValidationResult:
    """Result of validating a PlannerOutput before it is returned."""
    is_valid: bool = False
    errors: Tuple[str, ...] = field(default_factory=tuple)
    warnings: Tuple[str, ...] = field(default_factory=tuple)

    def to_dict(self) -> dict:
        return {
            "is_valid": self.is_valid,
            "error_count": len(self.errors),
            "errors": list(self.errors),
            "warnings": list(self.warnings),
        }


class PlannerValidator:
    """
    Validates inputs and outputs of the Phase 9.6 integrated planner.

    Stateless — safe for concurrent use.
    """

    def __init__(self, config: Optional[PlannerConfig] = None) -> None:
        self._cfg = config or PlannerConfig()

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def validate_input(
        self,
        inp: PlannerInput,
        now: Optional[float] = None,
    ) -> InputValidationResult:
        """
        Validate a PlannerInput before running the pipeline.

        Returns InputValidationResult with is_valid = True if the pipeline
        may proceed (possibly in degraded mode).
        """
        errors: List[str] = []
        warnings: List[str] = []
        stale_fields: List[str] = []
        now = now if now is not None else time.time()
        cfg = self._cfg

        # --- Extract safety gate state early --------------------------------
        planning_allowed, sg_state = self._extract_gate(inp)

        # --- Frame sanity ---------------------------------------------------
        frame_id = getattr(inp, "frame_id", None)
        if frame_id is None or not isinstance(frame_id, (int, float)):
            errors.append("frame_id is missing or non-numeric")

        # --- Timestamp validation -------------------------------------------
        ts = getattr(inp, "timestamp", None)
        if ts is None or not math.isfinite(float(ts if ts is not None else float("nan"))):
            errors.append("PlannerInput.timestamp is missing or non-finite")

        # --- Required upstream inputs ---------------------------------------
        if cfg.require_planning_space and inp.planning_space is None:
            errors.append("planning_space is required but missing")
        elif inp.planning_space is None:
            warnings.append("planning_space is absent; pipeline will degrade")

        if cfg.require_candidate_set and inp.candidate_set is None:
            errors.append("candidate_set is required but missing")
        elif inp.candidate_set is None:
            warnings.append("candidate_set is absent; no candidates to evaluate")

        if cfg.require_risk_set and inp.risk_set is None:
            errors.append("risk_set is required but missing")
        elif inp.risk_set is None:
            warnings.append("risk_set is absent; risk information unavailable")

        # --- Staleness checks -----------------------------------------------
        stale_fields = self._check_staleness(inp, now, cfg, warnings)

        # --- Coordinate frame checks ----------------------------------------
        self._check_frames(inp, warnings, errors)

        # --- Safety gate check ----------------------------------------------
        if not planning_allowed:
            # Not an error — valid restricted state
            warnings.append(
                f"safety_gate_state={sg_state}; planning_allowed=False"
            )

        # --- Determine status -----------------------------------------------
        if errors:
            status = InputValidationStatus.INVALID
        elif stale_fields:
            status = InputValidationStatus.STALE
        elif warnings:
            status = InputValidationStatus.VALID_DEGRADED
        else:
            status = InputValidationStatus.VALID

        return InputValidationResult(
            status=status,
            errors=tuple(errors),
            warnings=tuple(warnings),
            planning_allowed=planning_allowed,
            safety_gate_state=sg_state,
            stale_fields=tuple(stale_fields),
        )

    def validate_output(self, output: PlannerOutput) -> OutputValidationResult:
        """Validate a PlannerOutput before it leaves the pipeline."""
        errors: List[str] = []
        warnings: List[str] = []

        # Schema version
        if getattr(output, "schema_version", None) != "9.6":
            errors.append(
                f"Output schema_version mismatch: {output.schema_version!r}"
            )

        # Planning status must be set
        if not isinstance(output.planning_status, type(output.planning_status)):
            errors.append("planning_status is not a PlannerStatus enum")

        # selected_candidate_id must NOT be a vehicle control field
        sel_id = getattr(output, "selected_candidate_id", None)
        if sel_id not in (None, NOT_AVAILABLE):
            forbidden = ["steering", "throttle", "brake", "mpc", "pid", "actuator"]
            if any(kw in str(sel_id).lower() for kw in forbidden):
                errors.append(
                    f"selected_candidate_id looks like a control command: {sel_id!r}"
                )

        # If planning_allowed=False the status must not look like a valid normal plan
        if not output.planning_allowed:
            if output.planning_status == PlannerStatus.PLAN_AVAILABLE:
                errors.append(
                    "planning_allowed=False but planning_status=PLAN_AVAILABLE; "
                    "this would silently misrepresent a safety restriction"
                )

        # Confidence / uncertainty ranges
        if not (0.0 <= output.confidence <= 1.0):
            warnings.append(
                f"confidence={output.confidence} out of [0,1]"
            )
        if not (0.0 <= output.uncertainty <= 1.0):
            warnings.append(
                f"uncertainty={output.uncertainty} out of [0,1]"
            )

        return OutputValidationResult(
            is_valid=len(errors) == 0,
            errors=tuple(errors),
            warnings=tuple(warnings),
        )

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _extract_gate(self, inp: PlannerInput) -> Tuple[bool, str]:
        """Extract (planning_allowed, safety_gate_state) from available inputs."""
        planning_allowed = True
        sg_state = NOT_AVAILABLE

        # Check planning_context (Phase 8.4) first
        pc = inp.planning_context
        if pc is not None:
            pa = getattr(pc, "planning_allowed", None)
            if pa is not None:
                planning_allowed = bool(pa)
            sg = getattr(pc, "safety_gate_state", None)
            if sg is not None:
                sg_state = str(sg)

        # Check planning_space (may carry gate state too)
        ps = inp.planning_space
        if ps is not None:
            pa = getattr(ps, "planning_allowed", None)
            if pa is not None:
                planning_allowed = bool(pa) and planning_allowed
            sg = getattr(ps, "safety_gate_state", None)
            if sg and str(sg) not in ("", NOT_AVAILABLE):
                sg_state = str(sg)

        # Check candidate_set
        cs = inp.candidate_set
        if cs is not None:
            if not getattr(cs, "planning_allowed", True):
                planning_allowed = False

        return planning_allowed, sg_state

    def _check_staleness(
        self,
        inp: PlannerInput,
        now: float,
        cfg: PlannerConfig,
        warnings: List[str],
    ) -> List[str]:
        """Check staleness of each upstream input. Returns list of stale field names."""
        stale: List[str] = []

        checks = [
            ("world_model_snapshot", cfg.max_world_model_age_s),
            ("planning_context", cfg.max_planning_context_age_s),
            ("planning_space", cfg.max_planning_space_age_s),
            ("candidate_set", cfg.max_candidate_set_age_s),
            ("risk_set", cfg.max_risk_set_age_s),
        ]

        for attr_name, max_age_s in checks:
            obj = getattr(inp, attr_name, None)
            if obj is None:
                continue
            ts = getattr(obj, "timestamp", None)
            if ts is None:
                continue
            try:
                age = now - float(ts)
                if math.isfinite(age) and age > max_age_s:
                    stale.append(attr_name)
                    warnings.append(
                        f"{attr_name} is stale: age={age:.2f}s > max={max_age_s}s"
                    )
            except (TypeError, ValueError):
                pass

        return stale

    def _check_frames(
        self,
        inp: PlannerInput,
        warnings: List[str],
        errors: List[str],
    ) -> None:
        """Validate coordinate frame consistency across planning objects.

        Handles both plain-string coordinate_frame values ("VEHICLE") and
        CoordinateFrameInfo objects (which carry a frame_id string).
        """
        expected = self._cfg.expected_coordinate_frame
        frame_bearing_attrs = [
            ("planning_space", "coordinate_frame"),
            ("candidate_set", "coordinate_frame"),
            ("risk_set", "coordinate_frame"),
        ]
        for attr_name, frame_attr in frame_bearing_attrs:
            obj = getattr(inp, attr_name, None)
            if obj is None:
                continue
            raw = getattr(obj, frame_attr, None)
            # Extract string from CoordinateFrameInfo object if necessary
            if raw is not None and hasattr(raw, "frame_id"):
                frame_str = str(getattr(raw, "frame_id", "") or "")
            else:
                frame_str = str(raw) if raw is not None else ""
            if not frame_str or frame_str in ("None", NOT_AVAILABLE):
                warnings.append(
                    f"{attr_name}.{frame_attr} is missing or unknown"
                )
            elif frame_str.upper() != expected.upper():
                errors.append(
                    f"{attr_name}.{frame_attr}={frame_str!r} "
                    f"does not match expected={expected!r}"
                )
