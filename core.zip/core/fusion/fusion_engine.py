"""
IndiDrive AI — Phase 3 | Fusion Engine
==========================================
Turns one Phase 2 PerceptionFrame (camera + LiDAR + optional-radar
objects, already timestamped per object) into one FusedWorldState.

    PerceptionFrame
          |
          v
    split objects by source_sensor
          |
          v
    TimestampAligner            (per-sensor sync status/quality)
          |
          v
    DataAssociator               (cross-sensor object grouping)
          |
          v
    ObjectFusion + ConfidenceFusion   (-> FusedObject per group)
          |
          v
    TrackFusion                  (track_id / lifecycle across cycles)
          |
          v
    FusionHealthMonitor
          |
          v
    FusedWorldState

Contains no prediction (Phase 4) or planning (Phase 9) logic.
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Optional

from core.perception.perception_types import PerceptionFrame, SourceSensor, HealthState

from .fusion_types import FusedWorldState, FusedRoadAnomaly, FusionMetrics, FusionMode
from .timestamp_alignment import TimestampAligner, SyncConfig
from .data_association import DataAssociator, AssociationConfig
from .confidence_fusion import ConfidenceFusion, ConfidenceWeights
from .object_fusion import ObjectFusion
from .track_fusion import TrackFusion, TemporalConfig
from .sensor_calibration import SensorCalibration
from .fusion_health import FusionHealthMonitor

try:
    from core.logging_system import get_logger
except ImportError:  # pragma: no cover
    get_logger = None


@dataclass
class FusionEngineConfig:
    enabled: bool = True
    deterministic: bool = True
    sync: SyncConfig = field(default_factory=SyncConfig)
    association: AssociationConfig = field(default_factory=AssociationConfig)
    confidence_weights: ConfidenceWeights = field(default_factory=ConfidenceWeights)
    temporal: TemporalConfig = field(default_factory=TemporalConfig)


def _anomaly_distance(a, b) -> float:
    if a.location is None or b.location is None:
        return float("inf")
    return 1.0 - a.location.iou(b.location)


class FusionEngine:
    def __init__(self, config: Optional[FusionEngineConfig] = None, raw_config: Optional[dict] = None):
        self.config = config or FusionEngineConfig()
        self.calibration = SensorCalibration(raw_config)
        self.aligner = TimestampAligner(self.config.sync)
        self.associator = DataAssociator(self.config.association)
        self.object_fusion = ObjectFusion(ConfidenceFusion(self.config.confidence_weights))
        self.track_fusion = TrackFusion(self.config.temporal)
        self.health_monitor = FusionHealthMonitor()
        self._frame_counter = 0
        self._log = get_logger("system", component="fusion_engine") if get_logger else None

    def reset(self) -> None:
        self.track_fusion.reset()
        self._frame_counter = 0

    def _sensor_timestamp(self, objects: list, sensor: str, fallback: Optional[float]) -> Optional[float]:
        ts_values = [o.timestamp for o in objects if o.source_sensor.value == sensor]
        if ts_values:
            return sum(ts_values) / len(ts_values)
        return fallback

    def process(self, perception_frame: PerceptionFrame,
                camera_active: Optional[bool] = None,
                lidar_active: Optional[bool] = None,
                radar_active: bool = False) -> FusedWorldState:
        t_start = time.perf_counter()
        self._frame_counter += 1

        if not self.config.enabled:
            return FusedWorldState(
                timestamp=perception_frame.timestamp, frame_id=self._frame_counter,
                fusion_mode=FusionMode.NO_VALID_SENSOR, fusion_health=HealthState.NOT_CONFIGURED,
                warnings=["fusion disabled by configuration"],
            )

        by_sensor = {"camera": [], "lidar": [], "radar": []}
        for obj in perception_frame.objects:
            by_sensor.setdefault(obj.source_sensor.value, []).append(obj)

        # A sensor counts as "active this cycle" if it's structurally
        # enabled and (reported at least one object OR is otherwise
        # known to be running, e.g. via sensor_status). Absence of
        # detections is NOT the same as sensor absence.
        status = perception_frame.sensor_status or {}
        cam_active = camera_active if camera_active is not None else status.get("camera", {}).get("active", bool(by_sensor["camera"]))
        lidar_active_flag = lidar_active if lidar_active is not None else status.get("lidar", {}).get("active", bool(by_sensor["lidar"]))

        # -- 1. timestamp alignment -------------------------------------
        t0 = time.perf_counter()
        cam_ts = self._sensor_timestamp(perception_frame.objects, "camera",
                                         perception_frame.timestamp if cam_active else None)
        lidar_ts = self._sensor_timestamp(perception_frame.objects, "lidar",
                                           perception_frame.timestamp if lidar_active_flag else None)
        radar_ts = self._sensor_timestamp(perception_frame.objects, "radar",
                                           perception_frame.timestamp if radar_active else None)
        aligned = self.aligner.align({"camera": cam_ts, "lidar": lidar_ts, "radar": radar_ts})
        sync_latency_ms = (time.perf_counter() - t0) * 1000.0

        active_sensors = set(aligned.usable_sensors())
        usable_by_sensor = {s: (by_sensor[s] if s in active_sensors else []) for s in by_sensor}

        # -- 2. coordinate transform -------------------------------------
        # PerceptionObjects already carry vehicle-frame positions from
        # Phase 2 (see LiDAR ground-removal / camera monocular estimate);
        # explicit sensor->vehicle re-projection is only performed when a
        # caller needs camera pixel projection (coordinate_transform.py),
        # which is exercised directly by its own tests. Nothing to do
        # here beyond timing the (possibly zero-cost) pass-through.
        t1 = time.perf_counter()
        transform_latency_ms = (time.perf_counter() - t1) * 1000.0

        # -- 3. data association ------------------------------------------
        t2 = time.perf_counter()
        associations = self.associator.associate(usable_by_sensor)
        association_latency_ms = (time.perf_counter() - t2) * 1000.0

        # -- 4. object + confidence fusion --------------------------------
        t3 = time.perf_counter()
        fused_objects = [
            self.object_fusion.fuse(a, timestamp=aligned.reference_timestamp or perception_frame.timestamp,
                                     synchronization_quality=aligned.synchronization_quality)
            for a in associations
        ]
        confidence_latency_ms = (time.perf_counter() - t3) * 1000.0

        # -- 5. temporal fusion / lifecycle --------------------------------
        now_ts = aligned.reference_timestamp or perception_frame.timestamp
        fused_objects = self.track_fusion.update(fused_objects, now_ts)

        # -- 6. road anomaly fusion -----------------------------------------
        fused_anomalies = self._fuse_anomalies(perception_frame.road_anomalies)

        # -- 7. health -----------------------------------------------------
        fusion_latency_ms = (time.perf_counter() - t_start) * 1000.0
        health = self.health_monitor.assess(
            active_sensors=active_sensors,
            synchronization_quality=aligned.synchronization_quality,
            fusion_latency_ms=fusion_latency_ms,
            calibration_report=self.calibration.report(),
        )

        metrics = FusionMetrics(
            timestamp_alignment_latency_ms=sync_latency_ms,
            coordinate_transform_latency_ms=transform_latency_ms,
            association_latency_ms=association_latency_ms,
            confidence_fusion_latency_ms=confidence_latency_ms,
            fusion_latency_ms=fusion_latency_ms,
            objects_per_second=(len(fused_objects) / (fusion_latency_ms / 1000.0)) if fusion_latency_ms > 0 else 0.0,
            fusion_fps=(1000.0 / fusion_latency_ms) if fusion_latency_ms > 0 else 0.0,
        )

        warnings = list(aligned.warnings) + list(health.reasons)

        world_state = FusedWorldState(
            timestamp=now_ts,
            frame_id=self._frame_counter,
            fusion_mode=health.fusion_mode,
            objects=fused_objects,
            road_state=perception_frame.road_state,
            drivable_area=perception_frame.drivable_area,
            road_anomalies=fused_anomalies,
            sensor_health=status,
            fusion_health=health.state,
            synchronization_quality=aligned.synchronization_quality,
            sync_status={s: v.value for s, v in aligned.status.items()},
            warnings=warnings,
            metrics=metrics,
        )

        if self._log:
            self._log.info("fusion_cycle", frame_id=self._frame_counter,
                            fusion_mode=health.fusion_mode.value, objects=len(fused_objects),
                            fusion_health=health.state.value, latency_ms=round(fusion_latency_ms, 2))

        return world_state

    def _fuse_anomalies(self, anomalies: list) -> list[FusedRoadAnomaly]:
        """Groups same-type anomalies whose boxes overlap (camera +
        anomaly-capable geometry sources) — see spec section 25. With
        this codebase's current Phase 2 backends, road-damage detection
        is camera-only (NOT_CONFIGURED for the trained model), so in
        practice every group here has a single CAMERA source until a
        LiDAR-geometry anomaly signal is added; the grouping logic
        itself is source-agnostic and works as soon as one is."""
        if not anomalies:
            return []

        used = [False] * len(anomalies)
        groups: list[list] = []
        for i, a in enumerate(anomalies):
            if used[i]:
                continue
            group = [a]
            used[i] = True
            for j in range(i + 1, len(anomalies)):
                if used[j] or anomalies[j].anomaly_type != a.anomaly_type:
                    continue
                if _anomaly_distance(a, anomalies[j]) < 0.5:
                    group.append(anomalies[j])
                    used[j] = True
            groups.append(group)

        fused = []
        for group in groups:
            sources = frozenset(a.source for a in group)
            best = max(group, key=lambda a: a.confidence)
            product_absent = 1.0
            for a in group:
                product_absent *= max(0.0, 1.0 - a.confidence)
            confidence = 1.0 - product_absent
            fused.append(FusedRoadAnomaly(
                anomaly_type=best.anomaly_type,
                confidence=round(min(1.0, confidence), 3),
                location=best.location,
                size_estimate=best.size_estimate,
                severity=best.severity,
                source_sensors=sources,
                lidar_confirmed=(SourceSensor.LIDAR in sources),
                timestamp=best.timestamp,
            ))
        return fused
