"""
IndiDrive AI — Phase 3 | Fusion Utilities
=============================================
Small, dependency-free helpers used by the benchmark, replay and debug
API paths. No fusion logic lives here — see fusion_engine.py for that.
"""
from __future__ import annotations

from .fusion_types import FusedWorldState


def summarize_world_state(world_state: FusedWorldState) -> str:
    """One-line human-readable summary, e.g. for CLI/log output —
    mirrors the FUSION status block described in spec section 50."""
    obj_lines = ", ".join(
        f"{o.object_class}#{o.fused_object_id[-4:]}[{'+'.join(s.value for s in o.source_sensors)}]"
        for o in world_state.objects[:5]
    )
    more = f" (+{len(world_state.objects) - 5} more)" if len(world_state.objects) > 5 else ""
    return (
        f"FUSION[{world_state.fusion_health.value}] mode={world_state.fusion_mode.value} "
        f"objects={len(world_state.objects)} sync={world_state.synchronization_quality:.2f} "
        f"latency={world_state.metrics.fusion_latency_ms:.1f}ms :: {obj_lines}{more}"
    )


def replay_perception_frames(frames, fusion_manager):
    """Feeds a sequence of Phase 2 PerceptionFrames (e.g. loaded from a
    Phase 2 offline-replay session, see core/carla_integration/
    sensor_replay.py for the analogous Phase 1 pattern) through a
    FusionManager in order, preserving timestamps. Returns the list of
    resulting FusedWorldStates. Deterministic when
    fusion.deterministic=true in config — this function itself performs
    no randomization."""
    results = []
    for frame in frames:
        results.append(fusion_manager.process(frame))
    return results
