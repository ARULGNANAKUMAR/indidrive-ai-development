"""
IndiDrive AI — Phase 3 | Fusion Benchmark
=============================================
Measures ACTUAL fusion throughput/latency by running real
PerceptionFrames (synthetic sensor input, but real association/fusion
code paths) through FusionEngine and timing each cycle with
time.perf_counter(). Mirrors core/perception/perception_benchmark.py's
approach and honesty guarantees — every reported number is measured,
never a placeholder.
"""
from __future__ import annotations

import statistics
import time
import uuid
from dataclasses import dataclass, field
from typing import Optional

import numpy as np

from core.perception.perception_manager import PerceptionManager
from core.perception.object_detection import MockBackend
from core.perception.utils import percentile

from .fusion_engine import FusionEngine


@dataclass
class FusionBenchmarkReport:
    run_id: str
    iterations: int
    mean_total_latency_ms: float
    median_total_latency_ms: float
    p95_total_latency_ms: float
    min_total_latency_ms: float
    max_total_latency_ms: float
    mean_fps: float
    mean_timestamp_alignment_ms: float
    mean_coordinate_transform_ms: float
    mean_association_ms: float
    mean_confidence_fusion_ms: float
    mean_objects_per_cycle: float

    def to_dict(self) -> dict:
        return {
            "run_id": self.run_id,
            "iterations": self.iterations,
            "total_latency_ms": {
                "mean": round(self.mean_total_latency_ms, 3),
                "median": round(self.median_total_latency_ms, 3),
                "p95": round(self.p95_total_latency_ms, 3),
                "min": round(self.min_total_latency_ms, 3),
                "max": round(self.max_total_latency_ms, 3),
            },
            "mean_fps": round(self.mean_fps, 2),
            "stage_latency_ms_mean": {
                "timestamp_alignment": round(self.mean_timestamp_alignment_ms, 4),
                "coordinate_transform": round(self.mean_coordinate_transform_ms, 4),
                "association": round(self.mean_association_ms, 4),
                "confidence_fusion": round(self.mean_confidence_fusion_ms, 4),
            },
            "mean_objects_per_cycle": round(self.mean_objects_per_cycle, 2),
        }


def run_fusion_benchmark(iterations: int = 50, n_lidar_points: int = 20000,
                          n_camera_detections: int = 5,
                          image_size: tuple[int, int] = (640, 480)) -> FusionBenchmarkReport:
    """Runs `iterations` PerceptionManager.process_frame() +
    FusionEngine.process() cycles with synthetic (not fabricated-as-real)
    camera/LiDAR input, using MockBackend for detection so the benchmark
    is runnable without a trained model — mirrors
    perception_benchmark.py's honesty note about backend kind."""
    pmgr = PerceptionManager()
    pmgr.initialize()
    pmgr.engine.camera._detector = MockBackend(n_detections=n_camera_detections)
    pmgr.engine.camera._detector.load_model()

    engine = FusionEngine()
    w, h = image_size
    rng = np.random.default_rng(0)

    total_latencies = []
    sync_latencies, transform_latencies, assoc_latencies, conf_latencies = [], [], [], []
    object_counts = []

    for i in range(iterations):
        img = rng.integers(0, 255, size=(h, w, 3), dtype=np.uint8)
        pts = rng.uniform(-30, 30, size=(n_lidar_points, 4)).astype(np.float32)
        pts[:, 3] = np.abs(pts[:, 3])
        ts = time.time()

        frame = pmgr.process_frame(camera_image=img, camera_timestamp=ts,
                                    lidar_points=pts, lidar_timestamp=ts)

        t0 = time.perf_counter()
        world_state = engine.process(frame)
        total_latencies.append((time.perf_counter() - t0) * 1000.0)

        sync_latencies.append(world_state.metrics.timestamp_alignment_latency_ms)
        transform_latencies.append(world_state.metrics.coordinate_transform_latency_ms)
        assoc_latencies.append(world_state.metrics.association_latency_ms)
        conf_latencies.append(world_state.metrics.confidence_fusion_latency_ms)
        object_counts.append(len(world_state.objects))

    mean_ms = statistics.mean(total_latencies)
    return FusionBenchmarkReport(
        run_id=uuid.uuid4().hex[:10],
        iterations=iterations,
        mean_total_latency_ms=mean_ms,
        median_total_latency_ms=statistics.median(total_latencies),
        p95_total_latency_ms=percentile(total_latencies, 95),
        min_total_latency_ms=min(total_latencies),
        max_total_latency_ms=max(total_latencies),
        mean_fps=(1000.0 / mean_ms) if mean_ms > 0 else 0.0,
        mean_timestamp_alignment_ms=statistics.mean(sync_latencies),
        mean_coordinate_transform_ms=statistics.mean(transform_latencies),
        mean_association_ms=statistics.mean(assoc_latencies),
        mean_confidence_fusion_ms=statistics.mean(conf_latencies),
        mean_objects_per_cycle=statistics.mean(object_counts),
    )


if __name__ == "__main__":
    import json
    report = run_fusion_benchmark()
    print(json.dumps(report.to_dict(), indent=2))
