"""
IndiDrive AI — Phase 3 | Confidence Fusion
=============================================
Combines per-sensor confidence/quality signals into the fused object's
existence_probability / class_confidence / position_confidence /
velocity_confidence / overall quality.

Method (documented per spec section 17 — a deterministic weighted
baseline, explicitly NOT claimed to be statistically calibrated):

    existence_probability = 1 - product(1 - sensor_confidence_i)
        (independent-evidence combination: more agreeing sensors ->
         higher existence probability, each capped so a single very
         confident sensor cannot alone claim near-certainty)

    class_confidence      = confidence of the sensor best suited to
                             classify (camera > lidar > radar), scaled
                             down slightly if sensors disagree on class

    position_confidence   = higher when LiDAR (accurate range) is a
                             contributing source; camera-only positions
                             (monocular depth) are capped lower

    velocity_confidence   = 0 unless a sensor that actually measures
                             motion (radar radial velocity, or temporal
                             tracking) contributed one

    quality (overall)     = weighted average of the above, penalized by
                             synchronization_quality and conflict_state
"""
from __future__ import annotations

from dataclasses import dataclass, field

from core.perception.perception_types import PerceptionObject
from .fusion_types import ConflictState

_CLASS_AUTHORITY = {"camera": 1.0, "lidar": 0.55, "radar": 0.35}
_POSITION_AUTHORITY = {"lidar": 1.0, "radar": 0.75, "camera": 0.45}


@dataclass
class ConfidenceWeights:
    camera_weight: float = 0.35
    lidar_weight: float = 0.45
    radar_weight: float = 0.20


@dataclass
class FusedConfidence:
    existence_probability: float
    class_confidence: float
    position_confidence: float
    velocity_confidence: float
    overall_quality: float
    conflict_state: ConflictState


class ConfidenceFusion:
    def __init__(self, weights: ConfidenceWeights = None):
        self.weights = weights or ConfidenceWeights()

    def fuse(self, members: dict, synchronization_quality: float = 1.0) -> FusedConfidence:
        """members: {"camera": PerceptionObject, "lidar": ..., "radar": ...}"""
        if not members:
            return FusedConfidence(0.0, 0.0, 0.0, 0.0, 0.0, ConflictState.UNRESOLVED)

        # existence probability: independent-evidence combination
        product_absent = 1.0
        for sensor, obj in members.items():
            product_absent *= max(0.0, 1.0 - obj.confidence)
        existence = 1.0 - product_absent

        # class confidence: weight each sensor's vote by classification authority
        classes = {s: o.object_class for s, o in members.items()}
        best_sensor = max(members, key=lambda s: _CLASS_AUTHORITY.get(s, 0.2))
        class_conf = members[best_sensor].confidence * _CLASS_AUTHORITY.get(best_sensor, 0.2)
        distinct_classes = set(classes.values())
        conflict_state = ConflictState.CONSISTENT
        if len(distinct_classes) > 1:
            class_conf *= 0.7
            conflict_state = ConflictState.MINOR_CONFLICT
            # Large disagreement in reported position/distance on top of
            # a class mismatch is treated as a bigger conflict.
            distances = [o.distance for o in members.values() if o.distance is not None]
            if len(distances) >= 2 and (max(distances) - min(distances)) > 5.0:
                conflict_state = ConflictState.MAJOR_CONFLICT

        # position confidence: best available sensor's positional authority,
        # boosted slightly by multi-sensor agreement
        pos_sensor = max(members, key=lambda s: _POSITION_AUTHORITY.get(s, 0.2))
        pos_conf = _POSITION_AUTHORITY.get(pos_sensor, 0.2)
        if len(members) > 1:
            pos_conf = min(1.0, pos_conf + 0.10 * (len(members) - 1))

        # velocity confidence: only nonzero if a member actually carries a measured velocity
        velocity_conf = 0.0
        for sensor, obj in members.items():
            if obj.velocity is not None:
                velocity_conf = max(velocity_conf, 0.8 if sensor == "radar" else 0.4)

        overall = (0.30 * existence + 0.25 * class_conf + 0.25 * pos_conf + 0.20 * velocity_conf)
        overall *= max(0.1, synchronization_quality)
        if conflict_state == ConflictState.MAJOR_CONFLICT:
            overall *= 0.6
        elif conflict_state == ConflictState.MINOR_CONFLICT:
            overall *= 0.85

        return FusedConfidence(
            existence_probability=round(min(1.0, existence), 4),
            class_confidence=round(min(1.0, class_conf), 4),
            position_confidence=round(min(1.0, pos_conf), 4),
            velocity_confidence=round(min(1.0, velocity_conf), 4),
            overall_quality=round(min(1.0, max(0.0, overall)), 4),
            conflict_state=conflict_state,
        )
