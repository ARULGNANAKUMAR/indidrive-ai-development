"""
IndiDrive AI — Phase 3 | Temporal Fusion & Object Lifecycle
===============================================================
Basic short-term continuity only (spec section 22/21) — NOT the
Kalman/IMM trajectory predictor that belongs to Phase 4. This module
just answers: "is this cycle's fused object probably the same
real-world object as one from the previous cycle?" using nearest-3D
position (falling back to 2D IoU when neither side has a 3D position,
e.g. two consecutive camera-only detections), and assigns a stable
`track_id` + advances `lifecycle_state` / `age_cycles` accordingly.
"""
from __future__ import annotations

import math
import uuid
from dataclasses import dataclass

from .fusion_types import FusedObject, ObjectLifecycleState

DEFAULT_MAX_OBJECT_AGE_MS = 300.0
DEFAULT_MATCH_DISTANCE_M = 2.5


@dataclass
class TemporalConfig:
    enabled: bool = True
    max_object_age_ms: float = DEFAULT_MAX_OBJECT_AGE_MS
    match_distance_m: float = DEFAULT_MATCH_DISTANCE_M


class _Track:
    __slots__ = ("track_id", "last_object", "last_seen_ts", "hits", "misses")

    def __init__(self, track_id: str, obj: FusedObject):
        self.track_id = track_id
        self.last_object = obj
        self.last_seen_ts = obj.timestamp
        self.hits = 1
        self.misses = 0


def _dist(a: FusedObject, b: FusedObject) -> float:
    if a.position_3d is None or b.position_3d is None:
        return math.inf
    dx = a.position_3d.x - b.position_3d.x
    dy = a.position_3d.y - b.position_3d.y
    dz = a.position_3d.z - b.position_3d.z
    return math.sqrt(dx * dx + dy * dy + dz * dz)


def _bbox_similarity(a: FusedObject, b: FusedObject) -> float:
    if a.bbox_2d is None or b.bbox_2d is None:
        return 0.0
    return a.bbox_2d.iou(b.bbox_2d)


class TrackFusion:
    """Stateful across calls — one instance lives inside FusionEngine
    for the duration of a run/session."""

    def __init__(self, config: TemporalConfig = None):
        self.config = config or TemporalConfig()
        self._tracks: dict = {}

    def update(self, objects: list[FusedObject], now_ts: float) -> list[FusedObject]:
        if not self.config.enabled:
            return objects

        matched_track_ids = set()
        unmatched = list(objects)

        for track_id, track in list(self._tracks.items()):
            best_idx, best_score = None, None
            for i, obj in enumerate(unmatched):
                if obj.object_class != track.last_object.object_class:
                    continue
                d = _dist(obj, track.last_object)
                if d <= self.config.match_distance_m:
                    score = d
                elif d is math.inf:
                    iou = _bbox_similarity(obj, track.last_object)
                    score = (1.0 - iou) if iou > 0.1 else None
                else:
                    score = None
                if score is not None and (best_score is None or score < best_score):
                    best_idx, best_score = i, score

            if best_idx is not None:
                obj = unmatched.pop(best_idx)
                obj.track_id = track_id
                obj.age_cycles = track.hits
                obj.lifecycle_state = (
                    ObjectLifecycleState.CONFIRMED if track.hits >= 2 else ObjectLifecycleState.FUSED
                )
                track.last_object = obj
                track.last_seen_ts = obj.timestamp
                track.hits += 1
                track.misses = 0
                matched_track_ids.add(track_id)

        # Age out tracks that weren't matched this cycle.
        for track_id, track in list(self._tracks.items()):
            if track_id in matched_track_ids:
                continue
            age_ms = (now_ts - track.last_seen_ts) * 1000.0
            track.misses += 1
            if age_ms > self.config.max_object_age_ms:
                del self._tracks[track_id]
            else:
                track.last_object.lifecycle_state = ObjectLifecycleState.LOST

        # Remaining unmatched fused objects start new tracks.
        for obj in unmatched:
            track_id = f"track_{uuid.uuid4().hex[:10]}"
            obj.track_id = track_id
            obj.lifecycle_state = ObjectLifecycleState.NEW
            obj.age_cycles = 0
            self._tracks[track_id] = _Track(track_id, obj)

        return objects

    def active_track_count(self) -> int:
        return len(self._tracks)

    def reset(self) -> None:
        self._tracks.clear()
