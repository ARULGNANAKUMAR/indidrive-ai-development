"""
IndiDrive AI — Phase 3 | Coordinate Transformation
======================================================
Explicit sensor / vehicle / world frames (spec section 8):

    sensor frame  — raw sensor output (e.g. LiDAR points relative to
                    the LiDAR unit; camera pixels relative to the lens)
    vehicle frame — ego-vehicle-relative: +X forward, +Y left, +Z up,
                    origin at the vehicle's rear axle center. Meters.
    world frame   — CARLA/global frame. Only meaningful when CARLA (or
                    another absolute-pose source) is providing ego pose;
                    world-frame transforms are a pass-through identity
                    when no ego pose is available (documented, not
                    silently wrong).

Rotation convention: intrinsic roll (X) -> pitch (Y) -> yaw (Z),
right-handed, radians. Deliberately implemented with plain
lists-of-lists (no NumPy matrix requirement, no heavyweight geometry
library) per spec section 10 — this is 3x3/4x4 rotation composition,
nothing that needs Eigen-class tooling.
"""
from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Optional

from .sensor_calibration import Extrinsics, CameraIntrinsics


def _rotation_matrix(rpy: tuple[float, float, float]) -> list[list[float]]:
    roll, pitch, yaw = rpy
    cr, sr = math.cos(roll), math.sin(roll)
    cp, sp = math.cos(pitch), math.sin(pitch)
    cy, sy = math.cos(yaw), math.sin(yaw)
    # R = Rz(yaw) * Ry(pitch) * Rx(roll)
    return [
        [cy * cp, cy * sp * sr - sy * cr, cy * sp * cr + sy * sr],
        [sy * cp, sy * sp * sr + cy * cr, sy * sp * cr - cy * sr],
        [-sp, cp * sr, cp * cr],
    ]


def _matvec(m: list[list[float]], v: tuple[float, float, float]) -> tuple[float, float, float]:
    return (
        m[0][0] * v[0] + m[0][1] * v[1] + m[0][2] * v[2],
        m[1][0] * v[0] + m[1][1] * v[1] + m[1][2] * v[2],
        m[2][0] * v[0] + m[2][1] * v[1] + m[2][2] * v[2],
    )


@dataclass
class Transform3D:
    """Rigid transform: rotate then translate."""
    rotation: list  # 3x3
    translation: tuple

    @classmethod
    def identity(cls) -> "Transform3D":
        return cls(rotation=[[1.0, 0, 0], [0, 1.0, 0], [0, 0, 1.0]], translation=(0.0, 0.0, 0.0))

    @classmethod
    def from_extrinsics(cls, extr: Extrinsics) -> "Transform3D":
        return cls(rotation=_rotation_matrix(extr.rotation_rpy), translation=extr.translation)

    def apply(self, point: tuple[float, float, float]) -> tuple[float, float, float]:
        rx, ry, rz = _matvec(self.rotation, point)
        return (rx + self.translation[0], ry + self.translation[1], rz + self.translation[2])

    def inverse(self) -> "Transform3D":
        rt = [[self.rotation[j][i] for j in range(3)] for i in range(3)]  # transpose = inverse of rotation
        neg_t = tuple(-v for v in self.translation)
        inv_t = _matvec(rt, neg_t)
        return Transform3D(rotation=rt, translation=inv_t)


class CoordinateTransformer:
    """sensor -> vehicle -> world, and camera projection. Every method
    honestly reports when the calibration it needs isn't configured
    instead of assuming identity silently."""

    def __init__(self, calibration):
        self.calibration = calibration

    def sensor_to_vehicle(self, sensor: str, point: tuple[float, float, float]):
        entry = self.calibration.get(sensor)
        if not entry.configured or entry.extrinsics is None:
            return None, "NOT_CONFIGURED"
        t = Transform3D.from_extrinsics(entry.extrinsics)
        return t.apply(point), "OK"

    def vehicle_to_world(self, point: tuple[float, float, float], ego_pose: Optional[Transform3D] = None):
        """`ego_pose` is the vehicle->world transform (from CARLA/GNSS).
        Without it, world frame is undefined for this deployment and we
        report that rather than pretending vehicle frame == world frame."""
        if ego_pose is None:
            return None, "NOT_AVAILABLE"
        return ego_pose.apply(point), "OK"

    def project_to_camera(self, point_vehicle: tuple[float, float, float]):
        """Vehicle-frame 3D point -> camera pixel coordinates, only if
        both camera extrinsics and intrinsics are configured. Rejects
        points behind the camera or outside the image per spec §14."""
        entry = self.calibration.get("camera")
        if not entry.configured or entry.extrinsics is None or entry.intrinsics is None:
            return None, "NOT_CONFIGURED"

        vehicle_to_cam = Transform3D.from_extrinsics(entry.extrinsics).inverse()
        p_cam = vehicle_to_cam.apply(point_vehicle)
        x, y, z = p_cam

        if z <= 0.0:
            return None, "BEHIND_CAMERA"

        intr: CameraIntrinsics = entry.intrinsics
        u = intr.fx * (x / z) + intr.cx
        v = intr.fy * (y / z) + intr.cy

        if not (0.0 <= u < intr.image_width and 0.0 <= v < intr.image_height):
            return None, "OUTSIDE_IMAGE"

        return (u, v, z), "OK"
