"""
IndiDrive AI — Phase 3 | Fusion Health
==========================================
Rolls up sensor availability, synchronization quality, association
quality and latency into one HealthState per cycle, mirroring
core/perception/perception_health.py's role one layer up.
"""
from __future__ import annotations

from dataclasses import dataclass, field

from core.perception.perception_types import HealthState
from .fusion_types import FusionMode


@dataclass
class FusionHealthReport:
    state: HealthState
    fusion_mode: FusionMode
    reasons: list = field(default_factory=list)

    def to_dict(self) -> dict:
        return {"state": self.state.value, "fusion_mode": self.fusion_mode.value, "reasons": self.reasons}


class FusionHealthMonitor:
    def __init__(self, max_latency_ms: float = 100.0, min_sync_quality: float = 0.3):
        self.max_latency_ms = max_latency_ms
        self.min_sync_quality = min_sync_quality

    def assess(self, *, active_sensors: set, synchronization_quality: float,
               fusion_latency_ms: float, calibration_report: dict) -> FusionHealthReport:
        reasons = []

        n = len(active_sensors)
        if n >= 2:
            fusion_mode = FusionMode.FULL_FUSION if n >= 3 else FusionMode.PARTIAL_FUSION
        elif n == 1:
            fusion_mode = FusionMode.SINGLE_SENSOR
        else:
            fusion_mode = FusionMode.NO_VALID_SENSOR

        if fusion_mode == FusionMode.NO_VALID_SENSOR:
            reasons.append("no sensor produced usable objects this cycle")
            return FusionHealthReport(HealthState.FAILED, fusion_mode, reasons)

        state = HealthState.HEALTHY

        if fusion_mode == FusionMode.SINGLE_SENSOR:
            state = HealthState.DEGRADED
            reasons.append(f"only one sensor active ({next(iter(active_sensors))})")

        if synchronization_quality < self.min_sync_quality:
            state = HealthState.DEGRADED
            reasons.append(f"low synchronization quality ({synchronization_quality:.2f})")

        if fusion_latency_ms > self.max_latency_ms:
            state = HealthState.DEGRADED
            reasons.append(f"fusion latency {fusion_latency_ms:.1f}ms exceeds {self.max_latency_ms}ms")

        not_configured = [s for s, entry in calibration_report.items()
                           if s in active_sensors and not entry.get("configured", False)]
        if not_configured:
            reasons.append(f"calibration not configured for: {', '.join(not_configured)} "
                            f"(fusion still runs using raw per-sensor coordinates)")

        return FusionHealthReport(state, fusion_mode, reasons)
