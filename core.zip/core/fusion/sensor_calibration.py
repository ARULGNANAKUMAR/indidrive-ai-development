"""
IndiDrive AI — Phase 3 | Sensor Calibration
===============================================
Holds extrinsics/intrinsics needed to transform points between sensor,
vehicle and camera-image frames. Per spec section 9/36: calibration
values are never invented. If a calibration file isn't configured, the
corresponding transform honestly reports NOT_CONFIGURED and any
projection that depends on it is skipped (not faked).
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

from .fusion_types import NOT_CONFIGURED


@dataclass
class Extrinsics:
    """Rigid transform: translation (m) + rotation (radians, applied
    roll->pitch->yaw) from this sensor's frame into the vehicle frame."""
    translation: tuple[float, float, float] = (0.0, 0.0, 0.0)
    rotation_rpy: tuple[float, float, float] = (0.0, 0.0, 0.0)


@dataclass
class CameraIntrinsics:
    fx: float
    fy: float
    cx: float
    cy: float
    image_width: int
    image_height: int
    distortion: tuple = ()


@dataclass
class SensorCalibrationEntry:
    sensor: str
    configured: bool = False
    extrinsics: Optional[Extrinsics] = None
    intrinsics: Optional[CameraIntrinsics] = None
    source_file: str = ""
    status: str = NOT_CONFIGURED

    def to_dict(self) -> dict:
        return {
            "sensor": self.sensor,
            "configured": self.configured,
            "status": self.status,
            "source_file": self.source_file or NOT_CONFIGURED,
        }


class SensorCalibration:
    """Loads config/fusion_config.yaml's `calibration:` section (see
    fusion_config.yaml). Absent/partial calibration is a normal,
    honestly-reported state — not an error."""

    def __init__(self, raw_config: Optional[dict] = None):
        self._entries: dict[str, SensorCalibrationEntry] = {}
        cfg = (raw_config or {}).get("calibration", {}) if raw_config else {}
        for sensor in ("camera", "lidar", "radar"):
            sub = cfg.get(sensor, {}) if isinstance(cfg, dict) else {}
            configured = bool(sub.get("configured", False))
            entry = SensorCalibrationEntry(
                sensor=sensor,
                configured=configured,
                source_file=sub.get("file", "") or "",
                status="CONFIGURED" if configured else NOT_CONFIGURED,
            )
            if configured:
                # Explicit extrinsics/intrinsics may be provided directly
                # in config for offline/dev use (no external file parser
                # yet — that would be Phase 3.x tuning work). If absent
                # even though `configured: true`, we still don't invent
                # numbers: the entry stays configured=True structurally
                # but transforms depending on missing fields report
                # NOT_CONFIGURED individually (see coordinate_transform.py).
                extr = sub.get("extrinsics")
                if extr:
                    entry.extrinsics = Extrinsics(
                        translation=tuple(extr.get("translation", (0.0, 0.0, 0.0))),
                        rotation_rpy=tuple(extr.get("rotation_rpy", (0.0, 0.0, 0.0))),
                    )
                intr = sub.get("intrinsics")
                if intr and sensor == "camera":
                    entry.intrinsics = CameraIntrinsics(
                        fx=intr["fx"], fy=intr["fy"], cx=intr["cx"], cy=intr["cy"],
                        image_width=intr.get("image_width", 640),
                        image_height=intr.get("image_height", 480),
                        distortion=tuple(intr.get("distortion", ())),
                    )
            self._entries[sensor] = entry

    def get(self, sensor: str) -> SensorCalibrationEntry:
        return self._entries.get(sensor, SensorCalibrationEntry(sensor=sensor))

    def is_configured(self, sensor: str) -> bool:
        return self.get(sensor).configured

    def report(self) -> dict:
        return {s: e.to_dict() for s, e in self._entries.items()}
