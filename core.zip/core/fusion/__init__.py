"""
IndiDrive AI — Phase 3 | Multi-Sensor Fusion
================================================
Combines Phase 2 camera + LiDAR (+ optional radar) perception outputs
into a single FusedWorldState per cycle — the primary environmental
representation for Phase 4 (motion prediction). See
docs/FUSION_ARCHITECTURE.md for the full design.

Public entry points:
    FusionManager     — lifecycle + history (use this from application code)
    FusionEngine       — single-cycle processing (used internally / in tests)
    FusedWorldState / FusedObject — data contracts
"""
from .fusion_manager import FusionManager
from .fusion_engine import FusionEngine, FusionEngineConfig
from .fusion_types import (
    FusedObject, FusedWorldState, FusedRoadAnomaly, FusionMetrics,
    FusionMode, ConflictState, ObjectLifecycleState, SyncStatus,
)

__all__ = [
    "FusionManager", "FusionEngine", "FusionEngineConfig",
    "FusedObject", "FusedWorldState", "FusedRoadAnomaly", "FusionMetrics",
    "FusionMode", "ConflictState", "ObjectLifecycleState", "SyncStatus",
]
