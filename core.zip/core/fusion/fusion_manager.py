"""
IndiDrive AI — Phase 3 | Fusion Manager
===========================================
Top-level lifecycle and orchestration, mirroring the responsibilities
of Phase 2's core/perception/perception_manager.py one layer up:

    initialize()
    process(perception_frame)      -> FusedWorldState
    process_from_perception_manager(perception_manager)
    get_latest_world_state()
    get_history()
    get_health()
    get_metrics()
    reset()
    shutdown()

Contains no planner/decision logic and does not itself talk to
CARLA/sensors — it only consumes Phase 2 PerceptionFrames.
"""
from __future__ import annotations

import threading
from collections import deque
from pathlib import Path
from typing import Optional

from core.perception.perception_types import PerceptionFrame

from .fusion_engine import FusionEngine, FusionEngineConfig
from .timestamp_alignment import SyncConfig
from .data_association import AssociationConfig, AssociationWeights
from .confidence_fusion import ConfidenceWeights
from .track_fusion import TemporalConfig
from .fusion_types import FusedWorldState

try:
    from core.logging_system import get_logger
except ImportError:  # pragma: no cover
    get_logger = None

try:
    from core.config_loader import CONFIG_DIR
except ImportError:  # pragma: no cover
    CONFIG_DIR = None


DEFAULT_FUSION_CONFIG = {
    "fusion": {
        "enabled": True,
        "deterministic": True,
        "synchronization": {"enabled": True, "max_timestamp_delta_ms": 50, "stale_threshold_ms": 200},
        "association": {"enabled": True, "max_position_distance_m": 3.0, "min_iou": 0.10, "max_depth_error_m": 5.0},
        "confidence": {"camera_weight": 0.35, "lidar_weight": 0.45, "radar_weight": 0.20},
        "temporal": {"enabled": True, "max_object_age_ms": 300},
    },
    "calibration": {
        "camera": {"configured": False, "file": ""},
        "lidar": {"configured": False, "file": ""},
        "radar": {"configured": False, "file": ""},
    },
}


def _load_fusion_config() -> dict:
    if CONFIG_DIR is not None:
        try:
            path = Path(CONFIG_DIR) / "fusion_config.yaml"
            if path.exists():
                import yaml  # type: ignore
                with open(path, "r", encoding="utf-8") as f:
                    data = yaml.safe_load(f)
                if isinstance(data, dict) and "fusion" in data:
                    return data
        except Exception:
            pass
    return DEFAULT_FUSION_CONFIG


def _engine_config_from_raw(raw: dict) -> FusionEngineConfig:
    fcfg = raw.get("fusion", {})
    sync_cfg = fcfg.get("synchronization", {})
    assoc_cfg = fcfg.get("association", {})
    conf_cfg = fcfg.get("confidence", {})
    temporal_cfg = fcfg.get("temporal", {})

    return FusionEngineConfig(
        enabled=fcfg.get("enabled", True),
        deterministic=fcfg.get("deterministic", True),
        sync=SyncConfig(
            enabled=sync_cfg.get("enabled", True),
            max_timestamp_delta_ms=sync_cfg.get("max_timestamp_delta_ms", 50),
            stale_threshold_ms=sync_cfg.get("stale_threshold_ms", 200),
        ),
        association=AssociationConfig(
            enabled=assoc_cfg.get("enabled", True),
            max_position_distance_m=assoc_cfg.get("max_position_distance_m", 3.0),
            min_iou=assoc_cfg.get("min_iou", 0.10),
            max_depth_error_m=assoc_cfg.get("max_depth_error_m", 5.0),
        ),
        confidence_weights=ConfidenceWeights(
            camera_weight=conf_cfg.get("camera_weight", 0.35),
            lidar_weight=conf_cfg.get("lidar_weight", 0.45),
            radar_weight=conf_cfg.get("radar_weight", 0.20),
        ),
        temporal=TemporalConfig(
            enabled=temporal_cfg.get("enabled", True),
            max_object_age_ms=temporal_cfg.get("max_object_age_ms", 300),
        ),
    )


class FusionManager:
    def __init__(self, config: Optional[dict] = None, history_size: int = 30):
        self._raw_config = config or _load_fusion_config()
        self._log = get_logger("system", component="fusion_manager") if get_logger else None
        self._lock = threading.Lock()
        self._history: deque[FusedWorldState] = deque(maxlen=max(1, history_size))
        self._initialized = False
        self.engine: Optional[FusionEngine] = None

    # -- lifecycle --------------------------------------------------

    def initialize(self) -> None:
        if self._initialized:
            return
        engine_config = _engine_config_from_raw(self._raw_config)
        self.engine = FusionEngine(engine_config, raw_config=self._raw_config)
        self._initialized = True
        if self._log:
            self._log.info("fusion_manager_initialized", deterministic=engine_config.deterministic)

    def shutdown(self) -> None:
        with self._lock:
            self._history.clear()
        if self.engine:
            self.engine.reset()
        self._initialized = False
        if self._log:
            self._log.info("fusion_manager_shutdown")

    def reset(self) -> None:
        """Clears history and tracker state but keeps the manager
        initialized/configured (unlike shutdown())."""
        with self._lock:
            self._history.clear()
        if self.engine:
            self.engine.reset()

    def _require_engine(self) -> FusionEngine:
        if not self._initialized or self.engine is None:
            self.initialize()
        return self.engine

    # -- processing ---------------------------------------------------

    def process(self, perception_frame: PerceptionFrame, **kwargs) -> FusedWorldState:
        engine = self._require_engine()
        world_state = engine.process(perception_frame, **kwargs)
        with self._lock:
            self._history.append(world_state)
        return world_state

    def process_from_perception_manager(self, perception_manager) -> Optional[FusedWorldState]:
        """Convenience bridge to Phase 2's PerceptionManager: fuses
        whatever the manager's latest PerceptionFrame is. Returns None
        (does not crash) if nothing has been processed yet."""
        frame = perception_manager.get_latest_perception()
        if frame is None:
            return None
        return self.process(frame)

    # -- introspection ---------------------------------------------------

    def get_latest_world_state(self) -> Optional[FusedWorldState]:
        with self._lock:
            return self._history[-1] if self._history else None

    def get_history(self) -> list[FusedWorldState]:
        with self._lock:
            return list(self._history)

    def get_health(self) -> dict:
        latest = self.get_latest_world_state()
        if latest is None:
            return {"fusion_health": "NOT_CONFIGURED", "fusion_mode": "NO_VALID_SENSOR"}
        return {"fusion_health": latest.fusion_health.value, "fusion_mode": latest.fusion_mode.value,
                "warnings": latest.warnings}

    def get_metrics(self) -> dict:
        latest = self.get_latest_world_state()
        if latest is None:
            return {}
        return latest.metrics.to_dict()
