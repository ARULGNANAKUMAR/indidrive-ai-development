"""
IndiDrive AI — Phase 3 | Sensor Fusion Data Contracts
=========================================================
Strongly-typed containers for everything that flows OUT of the fusion
layer. Mirrors the design philosophy of Phase 2's
core/perception/perception_types.py: dataclasses (not raw dicts),
explicit "unavailable"/"not configured" states instead of fabricated
values, and a single stable shape (`FusedWorldState`) that Phase 4
(motion prediction) can depend on.

Nothing in this file performs association/fusion logic — these are
structural containers plus small helpers.
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Optional

from core.perception.perception_types import (
    NOT_AVAILABLE, BackendKind, HealthState, SourceSensor,
    BoundingBox2D, Position3D, Dimensions3D, RoadState, DrivableArea,
    RoadAnomaly,
)

__all__ = [
    "NOT_AVAILABLE", "NOT_CONFIGURED",
    "FusionMode", "ConflictState", "ObjectLifecycleState", "SyncStatus",
    "FusedObject", "FusedRoadAnomaly", "FusionMetrics", "FusedWorldState",
]

# Distinct sentinel from perception's NOT_AVAILABLE: fusion needs to
# distinguish "this sensor reported nothing this cycle" (NOT_AVAILABLE)
# from "this sensor/calibration was never set up" (NOT_CONFIGURED).
NOT_CONFIGURED = "NOT_CONFIGURED"


class FusionMode(str, Enum):
    """What combination of sensors actually contributed to a fusion
    cycle. Every FusedWorldState carries exactly one of these — see
    section 20 of the Phase 3 spec ("degraded mode")."""
    FULL_FUSION = "FULL_FUSION"              # camera + lidar + radar
    PARTIAL_FUSION = "PARTIAL_FUSION"        # exactly two of the three
    SINGLE_SENSOR = "SINGLE_SENSOR"          # exactly one sensor
    NO_VALID_SENSOR = "NO_VALID_SENSOR"      # nothing usable this cycle


class ConflictState(str, Enum):
    CONSISTENT = "CONSISTENT"
    MINOR_CONFLICT = "MINOR_CONFLICT"
    MAJOR_CONFLICT = "MAJOR_CONFLICT"
    UNRESOLVED = "UNRESOLVED"


class ObjectLifecycleState(str, Enum):
    NEW = "NEW"
    CONFIRMED = "CONFIRMED"
    FUSED = "FUSED"
    DEGRADED = "DEGRADED"
    LOST = "LOST"
    REMOVED = "REMOVED"


class SyncStatus(str, Enum):
    OK = "OK"
    STALE = "STALE"
    MISSING = "MISSING"


def source_label(sources: frozenset) -> str:
    """CAMERA / CAMERA+LIDAR / LIDAR+RADAR / ... — see spec section 5."""
    order = [SourceSensor.CAMERA, SourceSensor.LIDAR, SourceSensor.RADAR]
    present = [s.value.upper() for s in order if s in sources]
    return "+".join(present) if present else NOT_AVAILABLE


@dataclass
class FusedObject:
    """An object after multi-sensor fusion. Fields not supported by the
    contributing sensor(s) stay `None`/NOT_AVAILABLE — never fabricated
    (e.g. a LiDAR-only object has no `class_confidence` from a
    classifier, a camera-only object has no LiDAR-measured dimensions).
    """
    fused_object_id: str
    object_class: str
    class_confidence: float
    position_3d: Optional[Position3D]
    velocity: Optional[tuple[float, float, float]]
    dimensions: Optional[Dimensions3D]
    heading: Optional[float]
    distance: Optional[float]
    bbox_2d: Optional[BoundingBox2D]
    source_sensors: frozenset = field(default_factory=frozenset)
    position_confidence: float = 0.0
    velocity_confidence: float = 0.0
    existence_probability: float = 0.0
    quality: float = 0.0
    conflict_state: ConflictState = ConflictState.CONSISTENT
    lifecycle_state: ObjectLifecycleState = ObjectLifecycleState.NEW
    status: str = "FUSED"
    timestamp: float = 0.0
    age_cycles: int = 0
    track_id: Optional[str] = None          # stable ID across cycles (temporal fusion, section 22)
    contributing_ids: dict = field(default_factory=dict)  # {"camera": obj_id, "lidar": obj_id, ...}
    warnings: list = field(default_factory=list)

    @property
    def sensor_count(self) -> int:
        return len(self.source_sensors)

    def to_dict(self) -> dict:
        return {
            "fused_object_id": self.fused_object_id,
            "class": self.object_class,
            "class_confidence": round(self.class_confidence, 4),
            "position_3d": self.position_3d.to_dict() if self.position_3d else NOT_AVAILABLE,
            "velocity": list(self.velocity) if self.velocity else NOT_AVAILABLE,
            "dimensions": self.dimensions.to_dict() if self.dimensions else NOT_AVAILABLE,
            "heading": self.heading if self.heading is not None else NOT_AVAILABLE,
            "distance": self.distance if self.distance is not None else NOT_AVAILABLE,
            "bbox_2d": self.bbox_2d.to_dict() if self.bbox_2d else NOT_AVAILABLE,
            "source_sensors": source_label(self.source_sensors),
            "sensor_count": self.sensor_count,
            "position_confidence": round(self.position_confidence, 3),
            "velocity_confidence": round(self.velocity_confidence, 3),
            "existence_probability": round(self.existence_probability, 3),
            "quality": round(self.quality, 3),
            "conflict_state": self.conflict_state.value,
            "lifecycle_state": self.lifecycle_state.value,
            "status": self.status,
            "timestamp": self.timestamp,
            "age_cycles": self.age_cycles,
            "track_id": self.track_id if self.track_id is not None else NOT_AVAILABLE,
            "warnings": self.warnings,
        }


@dataclass
class FusedRoadAnomaly:
    """Camera anomaly candidate optionally corroborated by LiDAR
    geometry — see spec section 25. Never claims a sensor confirmation
    that did not happen."""
    anomaly_type: str
    confidence: float
    location: Optional[BoundingBox2D]
    size_estimate: Optional[Dimensions3D]
    severity: str
    source_sensors: frozenset = field(default_factory=frozenset)
    lidar_confirmed: bool = False
    timestamp: float = 0.0

    def to_dict(self) -> dict:
        return {
            "type": self.anomaly_type,
            "confidence": round(self.confidence, 3),
            "location": self.location.to_dict() if self.location else NOT_AVAILABLE,
            "size_estimate": self.size_estimate.to_dict() if self.size_estimate else NOT_AVAILABLE,
            "severity": self.severity,
            "sources": source_label(self.source_sensors),
            "lidar_confirmed": self.lidar_confirmed,
            "timestamp": self.timestamp,
        }


@dataclass
class FusionMetrics:
    """Every latency here is measured with time.perf_counter() at the
    point of use — never a placeholder or hard-coded value."""
    timestamp_alignment_latency_ms: float = 0.0
    coordinate_transform_latency_ms: float = 0.0
    association_latency_ms: float = 0.0
    confidence_fusion_latency_ms: float = 0.0
    fusion_latency_ms: float = 0.0
    objects_per_second: float = 0.0
    fusion_fps: float = 0.0

    def to_dict(self) -> dict:
        return {
            "timestamp_alignment_latency_ms": round(self.timestamp_alignment_latency_ms, 3),
            "coordinate_transform_latency_ms": round(self.coordinate_transform_latency_ms, 3),
            "association_latency_ms": round(self.association_latency_ms, 3),
            "confidence_fusion_latency_ms": round(self.confidence_fusion_latency_ms, 3),
            "fusion_latency_ms": round(self.fusion_latency_ms, 3),
            "objects_per_second": round(self.objects_per_second, 2),
            "fusion_fps": round(self.fusion_fps, 2),
        }


@dataclass
class FusedWorldState:
    """The primary interface consumed by Phase 4 (motion prediction).
    One FusedWorldState is produced per FusionManager processing cycle.
    """
    timestamp: float
    frame_id: int
    fusion_mode: FusionMode = FusionMode.NO_VALID_SENSOR
    objects: list[FusedObject] = field(default_factory=list)
    road_state: RoadState = field(default_factory=RoadState)
    drivable_area: DrivableArea = field(default_factory=DrivableArea)
    road_anomalies: list[FusedRoadAnomaly] = field(default_factory=list)
    sensor_health: dict = field(default_factory=dict)
    fusion_health: HealthState = HealthState.NOT_CONFIGURED
    synchronization_quality: float = 0.0
    sync_status: dict = field(default_factory=dict)   # {"camera": "OK", "lidar": "STALE", "radar": "MISSING"}
    warnings: list[str] = field(default_factory=list)
    metrics: FusionMetrics = field(default_factory=FusionMetrics)
    created_at: float = field(default_factory=time.time)

    def to_dict(self) -> dict:
        return {
            "timestamp": self.timestamp,
            "frame_id": self.frame_id,
            "fusion_mode": self.fusion_mode.value,
            "objects": [o.to_dict() for o in self.objects],
            "road_state": self.road_state.to_dict(),
            "drivable_area": self.drivable_area.to_dict(),
            "road_anomalies": [a.to_dict() for a in self.road_anomalies],
            "sensor_health": self.sensor_health,
            "fusion_health": self.fusion_health.value,
            "synchronization_quality": round(self.synchronization_quality, 3),
            "sync_status": self.sync_status,
            "warnings": self.warnings,
            "metrics": self.metrics.to_dict(),
        }
