"""
IndiDrive AI — Phase 3 | Object Fusion
==========================================
Turns one DataAssociator `Association` (a group of PerceptionObjects
from different sensors judged to be the same object) into a single
FusedObject. This is the camera+LiDAR(+radar) fusion path described in
spec section 11: camera contributes class + 2D box, LiDAR contributes
accurate 3D position/dimensions, radar (when present) contributes
measured velocity. No field is fabricated — an unsupported field stays
None and NOT_AVAILABLE downstream.
"""
from __future__ import annotations

import uuid

from core.perception.perception_types import SourceSensor
from .fusion_types import FusedObject, ObjectLifecycleState
from .confidence_fusion import ConfidenceFusion
from .data_association import Association

# Priority order for picking which sensor's value "wins" a field when
# more than one sensor reports it, chosen per spec §11/§15 (LiDAR is the
# accurate-range sensor, camera is the accurate-classification sensor).
_POSITION_PRIORITY = ("lidar", "radar", "camera")
_DIMENSIONS_PRIORITY = ("lidar", "camera")
_CLASS_PRIORITY = ("camera", "lidar", "radar")
_BBOX_PRIORITY = ("camera",)


def _pick(members: dict, priority: tuple, attr: str):
    for sensor in priority:
        obj = members.get(sensor)
        if obj is not None and getattr(obj, attr, None) is not None:
            return getattr(obj, attr), sensor
    return None, None


class ObjectFusion:
    def __init__(self, confidence_fusion: ConfidenceFusion = None):
        self.confidence_fusion = confidence_fusion or ConfidenceFusion()

    def fuse(self, association: Association, timestamp: float,
              synchronization_quality: float = 1.0) -> FusedObject:
        members = association.members

        object_class, class_sensor = _pick(members, _CLASS_PRIORITY, "object_class")
        position, _ = _pick(members, _POSITION_PRIORITY, "position_3d")
        dimensions, _ = _pick(members, _DIMENSIONS_PRIORITY, "dimensions_3d")
        bbox, _ = _pick(members, _BBOX_PRIORITY, "bbox_2d")
        heading, _ = _pick(members, ("lidar", "radar", "camera"), "heading")
        distance, _ = _pick(members, ("lidar", "radar", "camera"), "distance")
        velocity, _ = _pick(members, ("radar", "lidar", "camera"), "velocity")

        conf = self.confidence_fusion.fuse(members, synchronization_quality=synchronization_quality)

        source_sensors = frozenset(SourceSensor(s) for s in members.keys())
        contributing_ids = {s: o.object_id for s, o in members.items()}

        warnings = []
        if object_class is None:
            object_class = "unknown"
            warnings.append("no source sensor reported a class")
        if position is None:
            warnings.append("no 3D position available from any contributing sensor")

        return FusedObject(
            fused_object_id=f"fused_{uuid.uuid4().hex[:10]}",
            object_class=object_class,
            class_confidence=conf.class_confidence,
            position_3d=position,
            velocity=velocity,
            dimensions=dimensions,
            heading=heading,
            distance=distance,
            bbox_2d=bbox,
            source_sensors=source_sensors,
            position_confidence=conf.position_confidence,
            velocity_confidence=conf.velocity_confidence,
            existence_probability=conf.existence_probability,
            quality=conf.overall_quality,
            conflict_state=conf.conflict_state,
            lifecycle_state=ObjectLifecycleState.NEW,
            status="FUSED",
            timestamp=timestamp,
            age_cycles=0,
            contributing_ids=contributing_ids,
            warnings=warnings,
        )
