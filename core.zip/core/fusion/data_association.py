"""
IndiDrive AI — Phase 3 | Data Association
=============================================
Matches PerceptionObjects reported by different sensors in the same
fusion cycle so object_fusion.py can combine them. Deliberately NOT
class-only and NOT nearest-neighbour-only (spec section 12) — a
transparent weighted cost combines position, 2D IoU, depth, class
compatibility and timestamp difference, and only pairs below a
configurable gate are considered valid matches. Greedy min-cost
matching (not full Hungarian) — sufficient for the object counts this
project's scenarios produce, and keeps the implementation dependency-free.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Optional

from core.perception.perception_types import PerceptionObject

# Classes that may reasonably refer to the "same" physical object across
# sensors even when the label differs (e.g. LiDAR often only knows
# "road_obstacle" while camera knows "cattle"). Not used to force a
# match — only to avoid penalizing a plausible cross-sensor pairing.
_COMPATIBLE_UNKNOWN = {"unknown", "road_obstacle", "debris"}


@dataclass
class AssociationWeights:
    position: float = 0.40
    bbox_iou: float = 0.20
    depth: float = 0.20
    cls: float = 0.10
    time: float = 0.10


@dataclass
class AssociationConfig:
    enabled: bool = True
    max_position_distance_m: float = 3.0
    min_iou: float = 0.10
    max_depth_error_m: float = 5.0
    max_timestamp_delta_s: float = 0.2
    weights: AssociationWeights = field(default_factory=AssociationWeights)
    # cost above this is treated as "no match" even if it's the lowest available
    max_cost: float = 1.5


@dataclass
class Association:
    """One matched pair (or singleton) — a group of PerceptionObjects
    from different sensors judged to be the same real-world object."""
    members: dict = field(default_factory=dict)  # {"camera": obj, "lidar": obj, "radar": obj}
    cost: float = 0.0

    @property
    def sensors(self):
        return frozenset(self.members.keys())


def _position_distance(a: PerceptionObject, b: PerceptionObject) -> Optional[float]:
    if a.position_3d is None or b.position_3d is None:
        return None
    dx = a.position_3d.x - b.position_3d.x
    dy = a.position_3d.y - b.position_3d.y
    dz = a.position_3d.z - b.position_3d.z
    return math.sqrt(dx * dx + dy * dy + dz * dz)


def _class_mismatch(a: PerceptionObject, b: PerceptionObject) -> float:
    if a.object_class == b.object_class:
        return 0.0
    if a.object_class in _COMPATIBLE_UNKNOWN or b.object_class in _COMPATIBLE_UNKNOWN:
        return 0.5
    return 1.0


def pairwise_cost(a: PerceptionObject, b: PerceptionObject, config: AssociationConfig) -> Optional[float]:
    """Returns None if the pair is gated out entirely (too far apart in
    time, or no usable geometric signal to compare at all)."""
    dt = abs(a.timestamp - b.timestamp)
    if dt > config.max_timestamp_delta_s:
        return None

    w = config.weights
    terms = []
    total_weight = 0.0

    dist = _position_distance(a, b)
    have_position_signal = dist is not None
    if have_position_signal:
        if dist > config.max_position_distance_m:
            return None
        terms.append(w.position * (dist / config.max_position_distance_m))
        total_weight += w.position

    have_bbox_signal = a.bbox_2d is not None and b.bbox_2d is not None
    if have_bbox_signal:
        iou = a.bbox_2d.iou(b.bbox_2d)
        if iou < config.min_iou and not have_position_signal:
            # No 3D signal to fall back on and boxes barely overlap -> reject.
            return None
        terms.append(w.bbox_iou * (1.0 - iou))
        total_weight += w.bbox_iou

    have_depth_signal = a.distance is not None and b.distance is not None
    if have_depth_signal:
        depth_err = abs(a.distance - b.distance)
        if depth_err > config.max_depth_error_m:
            return None
        terms.append(w.depth * (depth_err / config.max_depth_error_m))
        total_weight += w.depth

    terms.append(w.cls * _class_mismatch(a, b))
    total_weight += w.cls

    terms.append(w.time * (dt / max(config.max_timestamp_delta_s, 1e-6)))
    total_weight += w.time

    if not (have_position_signal or have_bbox_signal or have_depth_signal):
        # Nothing geometric to compare at all (e.g. two radar-only
        # points with no position) — cannot responsibly associate.
        return None

    return sum(terms)


class DataAssociator:
    def __init__(self, config: Optional[AssociationConfig] = None):
        self.config = config or AssociationConfig()

    def associate(self, by_sensor: dict) -> list[Association]:
        """by_sensor: {"camera": [PerceptionObject, ...], "lidar": [...], "radar": [...]}
        Greedy association: build all valid cross-sensor pairs, sorted by
        cost, and merge into groups without ever assigning the same
        source object twice."""
        sensors = [s for s in ("camera", "lidar", "radar") if by_sensor.get(s)]
        candidates = []
        for i, sa in enumerate(sensors):
            for sb in sensors[i + 1:]:
                for a in by_sensor[sa]:
                    for b in by_sensor[sb]:
                        cost = pairwise_cost(a, b, self.config) if self.config.enabled else 0.0
                        if cost is not None and cost <= self.config.max_cost:
                            candidates.append((cost, sa, a, sb, b))

        candidates.sort(key=lambda c: c[0])

        # Objects aren't hashable (perception dataclasses define __eq__
        # without __hash__), so track "used" by identity via id().
        used_ids: dict = {s: set() for s in sensors}
        results = []

        for cost, sa, a, sb, b in candidates:
            if id(a) in used_ids[sa] or id(b) in used_ids[sb]:
                continue  # keep it simple: no partial re-linking in Phase 3
            used_ids[sa].add(id(a))
            used_ids[sb].add(id(b))
            results.append(Association(members={sa: a, sb: b}, cost=cost))

        # Anything left unmatched becomes its own singleton association
        # (a single-sensor object is a perfectly valid Phase 3 output).
        for s in sensors:
            for obj in by_sensor[s]:
                if id(obj) not in used_ids[s]:
                    results.append(Association(members={s: obj}, cost=0.0))

        return results
