"""
IndiDrive AI — Phase 3 | Timestamp Synchronization
======================================================
Camera/LiDAR/radar frames arrive at different wall-clock/sensor-clock
times (see Phase 1's core/carla_integration/sensor_types.py Timestamp).
This module decides, for one fusion cycle, whether the frames on hand
are close enough together to be treated as "the same moment" — it does
NOT assume perfect synchronization, and it never invents a timestamp
for a sensor that didn't report one.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

from .fusion_types import SyncStatus

DEFAULT_MAX_TIMESTAMP_DELTA_MS = 50.0
DEFAULT_STALE_THRESHOLD_MS = 200.0


@dataclass
class SyncConfig:
    enabled: bool = True
    max_timestamp_delta_ms: float = DEFAULT_MAX_TIMESTAMP_DELTA_MS
    stale_threshold_ms: float = DEFAULT_STALE_THRESHOLD_MS


@dataclass
class AlignedFrames:
    """Result of one alignment attempt. `reference_timestamp` is the
    timestamp the fusion cycle is anchored to (the newest available
    sensor timestamp)."""
    reference_timestamp: Optional[float]
    status: dict = field(default_factory=dict)          # sensor -> SyncStatus
    deltas_ms: dict = field(default_factory=dict)        # sensor -> |delta| vs reference, ms
    synchronization_quality: float = 0.0                 # 0..1, 1.0 = all present & aligned
    warnings: list = field(default_factory=list)

    def usable_sensors(self) -> list[str]:
        return [s for s, st in self.status.items() if st == SyncStatus.OK]


class TimestampAligner:
    """Stateless per-call aligner: pass in whatever timestamps are
    available this cycle (None for a sensor that reported nothing)."""

    def __init__(self, config: Optional[SyncConfig] = None):
        self.config = config or SyncConfig()

    def align(self, timestamps: dict) -> AlignedFrames:
        """timestamps: {"camera": float|None, "lidar": float|None, "radar": float|None}"""
        present = {s: t for s, t in timestamps.items() if t is not None}

        if not present:
            return AlignedFrames(
                reference_timestamp=None,
                status={s: SyncStatus.MISSING for s in timestamps},
                synchronization_quality=0.0,
                warnings=["no sensor reported a timestamp this cycle"],
            )

        # Reference = most recent timestamp on hand (newest data anchors the cycle).
        reference = max(present.values())

        status: dict = {}
        deltas_ms: dict = {}
        warnings: list = []
        ok_count = 0

        for sensor, ts in timestamps.items():
            if ts is None:
                status[sensor] = SyncStatus.MISSING
                continue
            delta_ms = abs(reference - ts) * 1000.0
            deltas_ms[sensor] = delta_ms
            if delta_ms > self.config.stale_threshold_ms:
                status[sensor] = SyncStatus.STALE
                warnings.append(f"{sensor} frame stale: {delta_ms:.1f}ms > {self.config.stale_threshold_ms}ms")
            elif not self.config.enabled or delta_ms <= self.config.max_timestamp_delta_ms:
                status[sensor] = SyncStatus.OK
                ok_count += 1
            else:
                status[sensor] = SyncStatus.STALE
                warnings.append(
                    f"{sensor} frame outside sync window: {delta_ms:.1f}ms > "
                    f"{self.config.max_timestamp_delta_ms}ms"
                )

        n_sensors = len(timestamps) or 1
        # Quality rewards both coverage (how many sensors reported) and
        # tightness (how close the OK ones are to the reference).
        coverage = ok_count / n_sensors
        if ok_count:
            avg_delta = sum(deltas_ms[s] for s in deltas_ms if status[s] == SyncStatus.OK) / ok_count
            tightness = max(0.0, 1.0 - (avg_delta / max(self.config.max_timestamp_delta_ms, 1e-6)))
        else:
            tightness = 0.0
        quality = round(0.5 * coverage + 0.5 * tightness, 4) if ok_count else 0.0

        return AlignedFrames(
            reference_timestamp=reference,
            status=status,
            deltas_ms=deltas_ms,
            synchronization_quality=quality,
            warnings=warnings,
        )
