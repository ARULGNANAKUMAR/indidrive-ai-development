"""
IndiDrive AI — Phase 10.1 | Vehicle State
==========================================
Typed kinematic state for the ego vehicle consumed by the bicycle model.

Coordinate convention (project-wide, all prior phases):
    +X = forward   (longitudinal)
    +Y = left      (lateral)
    +Z = up        (vertical)
    Origin = vehicle rear-axle centre
    Units  = metres, radians, seconds, m/s, m/s², rad/s

Fields
------
x               : Longitudinal position (m).
y               : Lateral position (m).
yaw             : Heading angle (rad), measured CCW from +X axis.
                  Normalised to [-π, π).
velocity        : Forward speed (m/s).  Must be ≥ 0.
                  Negative velocity (reverse) is NOT supported.
acceleration    : Current longitudinal acceleration (m/s²).
                  Carried forward from the last control input for bookkeeping.
steering_angle  : Current front-wheel steering angle (rad).
                  Carried forward from the last control input.
yaw_rate        : Rate of change of yaw (rad/s).  Derived from bicycle model.
timestamp       : Simulation time at which this state is valid (s).
frame_id        : Optional frame counter (integer ≥ 0).
coordinate_frame: CoordinateFrame enum — always VEHICLE for the bicycle model.
state_kind      : StateKind enum distinguishing measured/estimated/simulated.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Optional

from .vehicle_types import CoordinateFrame, StateKind


# ---------------------------------------------------------------------------
# Angle normalisation helper — shared with bicycle_model
# ---------------------------------------------------------------------------

def normalise_angle(angle_rad: float) -> float:
    """
    Wrap *angle_rad* to the half-open interval [-π, π).

    Uses the modulo identity so the result is deterministic and branchless.
    Handles values far from zero without iteration.

    Examples
    --------
    >>> normalise_angle(math.pi)      # → -π
    >>> normalise_angle(-math.pi)     # → -π
    >>> normalise_angle(3 * math.pi)  # → -π   (3π mod 2π = π → wraps)
    """
    # fmod-based wrap: brings any finite value into (-2π, 2π) first
    a = math.fmod(angle_rad + math.pi, 2.0 * math.pi)
    if a < 0.0:
        a += 2.0 * math.pi
    return a - math.pi


@dataclass
class VehicleState:
    """
    Kinematic state for the ego vehicle.

    This is a mathematical container for the bicycle model.
    It does NOT contain:
        * actuator commands
        * target steering / throttle / brake values
        * MPC horizon states
        * CARLA API objects

    See StateKind for provenance (MEASURED / ESTIMATED / SIMULATED).
    """

    # Primary bicycle-model state ----------------------------------------
    x:              float = 0.0   # longitudinal position (m)
    y:              float = 0.0   # lateral position (m)
    yaw:            float = 0.0   # heading angle (rad), normalised to [-π, π)
    velocity:       float = 0.0   # forward speed (m/s), ≥ 0

    # Derived / carried-forward quantities --------------------------------
    acceleration:   float = 0.0   # longitudinal acceleration (m/s²)
    steering_angle: float = 0.0   # front-wheel steering angle (rad)
    yaw_rate:       float = 0.0   # dψ/dt (rad/s)

    # Metadata ------------------------------------------------------------
    timestamp:        float          = 0.0
    frame_id:         int            = 0
    coordinate_frame: CoordinateFrame = CoordinateFrame.VEHICLE
    state_kind:       StateKind       = StateKind.SIMULATED

    # ------------------------------------------------------------------ #

    def __post_init__(self) -> None:
        # Normalise yaw on construction so the invariant is always satisfied.
        # This does NOT modify the caller's value — dataclass assigns to self.
        if math.isfinite(self.yaw):
            object.__setattr__(self, "yaw", normalise_angle(self.yaw))

    # ------------------------------------------------------------------ #
    # Validation helpers
    # ------------------------------------------------------------------ #

    def is_finite(self) -> bool:
        """Return True iff all numeric fields are finite."""
        return all(
            math.isfinite(v)
            for v in (
                self.x, self.y, self.yaw, self.velocity,
                self.acceleration, self.steering_angle, self.yaw_rate,
                self.timestamp,
            )
        )

    def validate(self) -> None:
        """
        Raise ValueError if the state is numerically invalid.

        Checks:
        * All float fields are finite.
        * velocity ≥ 0 (reverse not supported).
        * frame_id ≥ 0.
        """
        bad = [
            name for name, val in [
                ("x",              self.x),
                ("y",              self.y),
                ("yaw",            self.yaw),
                ("velocity",       self.velocity),
                ("acceleration",   self.acceleration),
                ("steering_angle", self.steering_angle),
                ("yaw_rate",       self.yaw_rate),
                ("timestamp",      self.timestamp),
            ]
            if not isinstance(val, (int, float)) or not math.isfinite(val)
        ]
        if bad:
            raise ValueError(
                f"VehicleState has non-finite field(s): {bad}"
            )
        if self.velocity < 0.0:
            raise ValueError(
                f"VehicleState.velocity must be ≥ 0 (reverse not supported), "
                f"got {self.velocity}"
            )
        if self.frame_id < 0:
            raise ValueError(
                f"VehicleState.frame_id must be ≥ 0, got {self.frame_id}"
            )

    # ------------------------------------------------------------------ #
    # Convenience constructors
    # ------------------------------------------------------------------ #

    @classmethod
    def origin(cls, timestamp: float = 0.0) -> "VehicleState":
        """Return the zero state at the given timestamp."""
        return cls(timestamp=timestamp, state_kind=StateKind.SIMULATED)

    def copy(self) -> "VehicleState":
        """Return a shallow copy of this state."""
        return VehicleState(
            x=self.x,
            y=self.y,
            yaw=self.yaw,
            velocity=self.velocity,
            acceleration=self.acceleration,
            steering_angle=self.steering_angle,
            yaw_rate=self.yaw_rate,
            timestamp=self.timestamp,
            frame_id=self.frame_id,
            coordinate_frame=self.coordinate_frame,
            state_kind=self.state_kind,
        )

    def __repr__(self) -> str:
        return (
            f"VehicleState(x={self.x:.3f}, y={self.y:.3f}, "
            f"yaw={math.degrees(self.yaw):.1f}°, v={self.velocity:.2f} m/s, "
            f"t={self.timestamp:.3f}s, kind={self.state_kind.value})"
        )
