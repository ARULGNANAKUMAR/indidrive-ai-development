"""
IndiDrive AI — Phase 10.1 | Dynamics Validator
===============================================
Centralised validation utilities for the vehicle dynamics package.

All validation is deterministic and raises ValueError on failure.
No side effects; no mutable state.
"""
from __future__ import annotations

import math
from typing import Sequence

from .vehicle_parameters import VehicleParameters
from .vehicle_state import VehicleState
from .vehicle_input import VehicleControlInput
from .bicycle_model import VehicleTrajectory


class DynamicsValidator:
    """
    Collection of validation checks for Phase 10.1 data contracts.

    Usage
    -----
    >>> DynamicsValidator.validate_trajectory(traj)
    >>> DynamicsValidator.validate_state_sequence_continuity(traj.states, dt=0.1)
    """

    @staticmethod
    def validate_parameters(params: VehicleParameters) -> None:
        """Delegate to VehicleParameters internal validation (already done at construction)."""
        # Parameters validate in __post_init__; re-invoke by creating a copy.
        # If this method is called on an already-valid frozen instance, it is a no-op.
        _ = params  # already validated; here for API symmetry

    @staticmethod
    def validate_state(state: VehicleState) -> None:
        """Raise ValueError if state is numerically invalid."""
        state.validate()

    @staticmethod
    def validate_control_input(u: VehicleControlInput) -> None:
        """Raise ValueError if control input is numerically invalid."""
        u.validate()

    @staticmethod
    def validate_dt(dt: float) -> None:
        """Raise ValueError if dt is non-positive or non-finite."""
        if not isinstance(dt, (int, float)):
            raise TypeError(f"dt must be numeric, got {type(dt)}")
        if not math.isfinite(dt):
            raise ValueError(f"dt must be finite, got {dt}")
        if dt <= 0.0:
            raise ValueError(f"dt must be > 0, got {dt}")

    @staticmethod
    def validate_trajectory(traj: VehicleTrajectory) -> None:
        """
        Validate a complete VehicleTrajectory.

        Checks:
        * All states are numerically finite.
        * Timestamps are non-decreasing (strictly monotone not required
          for a single-step trajectory but NaN/inf is not allowed).
        * At least one state present.
        """
        if traj.is_empty:
            raise ValueError("VehicleTrajectory must contain at least one state")
        for i, s in enumerate(traj.states):
            if not s.is_finite():
                raise ValueError(
                    f"VehicleTrajectory state[{i}] contains non-finite values"
                )
        # Check timestamp monotonicity
        for i in range(1, len(traj.states)):
            t_prev = traj.states[i - 1].timestamp
            t_curr = traj.states[i].timestamp
            if t_curr < t_prev:
                raise ValueError(
                    f"VehicleTrajectory timestamps are not monotone: "
                    f"states[{i}].timestamp={t_curr} < states[{i-1}].timestamp={t_prev}"
                )

    @staticmethod
    def validate_state_sequence_continuity(
        states: Sequence[VehicleState],
        dt: float,
        tolerance_fraction: float = 0.05,
    ) -> None:
        """
        Check that consecutive states have timestamps approximately dt apart.

        Parameters
        ----------
        states              : Ordered sequence of VehicleState.
        dt                  : Expected timestep (s).
        tolerance_fraction  : Allowed fractional deviation from dt.
                              Default 5 % (i.e. within ±0.05 * dt).
        """
        tolerance = abs(dt) * tolerance_fraction
        for i in range(1, len(states)):
            gap = states[i].timestamp - states[i - 1].timestamp
            if abs(gap - dt) > tolerance:
                raise ValueError(
                    f"State sequence gap [{i-1}→{i}] = {gap:.6f}s "
                    f"deviates from dt={dt:.6f}s by more than "
                    f"tolerance={tolerance:.6f}s"
                )

    @staticmethod
    def validate_trajectory_against_params(
        traj: VehicleTrajectory,
        params: VehicleParameters,
    ) -> None:
        """
        Check that all trajectory states respect the configured vehicle limits.

        Does NOT raise for small floating-point rounding; uses a small epsilon.
        """
        eps = 1e-6
        for i, s in enumerate(traj.states):
            if s.velocity < params.min_velocity_mps - eps:
                raise ValueError(
                    f"Trajectory state[{i}] velocity={s.velocity:.4f} < "
                    f"min_velocity_mps={params.min_velocity_mps}"
                )
            if s.velocity > params.max_velocity_mps + eps:
                raise ValueError(
                    f"Trajectory state[{i}] velocity={s.velocity:.4f} > "
                    f"max_velocity_mps={params.max_velocity_mps}"
                )
            if abs(s.steering_angle) > params.max_steering_angle_rad + eps:
                raise ValueError(
                    f"Trajectory state[{i}] steering_angle={s.steering_angle:.4f} "
                    f"exceeds ±{params.max_steering_angle_rad:.4f}"
                )
