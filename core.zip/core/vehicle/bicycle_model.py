"""
IndiDrive AI — Phase 10.1 | Kinematic Bicycle Model
=====================================================
Standard rear-axle kinematic bicycle model for the ego vehicle.

Model equations (rear-axle reference, zero slip angle)
-------------------------------------------------------
    State:   (x, y, ψ, v)
    Input:   (δ, a)       — steering angle, longitudinal acceleration
    Params:  L            — wheelbase (m)

    Continuous-time derivatives:
        ẋ  = v · cos(ψ)
        ẏ  = v · sin(ψ)
        ψ̇  = v / L · tan(δ)
        v̇  = a

    Euler forward integration (dt step):
        x(t+dt)  = x(t)  + ẋ  · dt
        y(t+dt)  = y(t)  + ẏ  · dt
        ψ(t+dt)  = normalise( ψ(t) + ψ̇ · dt )
        v(t+dt)  = clamp( v(t) + a · dt, v_min, v_max )

Derived quantities (available after each step)
-----------------------------------------------
    curvature  κ = tan(δ) / L
    yaw_rate   ψ̇ = v · κ

Limitations / assumptions
--------------------------
* Zero lateral slip (β = 0).  Accurate for low-speed / steady-state.
* Euler integration.  Sufficient for the Phase 10.1 foundation;
  Phase 10.3 (MPC) may use a tighter integrator if required.
* Reverse driving is not supported (v ≥ 0 enforced).
* No tyre dynamics, no pitch/roll, no suspension.

This is NOT:
    * an MPC controller
    * a trajectory tracking controller
    * a steering actuator
    * a speed/throttle controller

Design rules:
    * Stateless model object (parameters are frozen; no mutable model state).
    * Deterministic: same (state, input, dt) → same output, always.
    * No random number generation.
    * No global mutable state.
    * Thread-safe: multiple callers may share one model instance.

Coordinate convention (project-wide):
    +X = forward, +Y = left, +Z = up
    Origin = rear-axle centre
    Units  = metres, radians, seconds, m/s, m/s²
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import List, Sequence

from .vehicle_types import CoordinateFrame, ModelVersion, StateKind, SteeringPolicy
from .vehicle_parameters import VehicleParameters
from .vehicle_state import VehicleState, normalise_angle
from .vehicle_input import VehicleControlInput


# ---------------------------------------------------------------------------
# Timestep validation
# ---------------------------------------------------------------------------

_DT_MAX_SECONDS: float = 10.0   # configurable hard cap for safety


def _validate_dt(dt: float) -> None:
    """Raise ValueError for any dt that would make integration unsafe."""
    if not isinstance(dt, (int, float)):
        raise ValueError(f"dt must be numeric, got {type(dt)}")
    if not math.isfinite(dt):
        raise ValueError(f"dt must be finite, got {dt}")
    if dt <= 0.0:
        raise ValueError(f"dt must be > 0, got {dt}")
    if dt > _DT_MAX_SECONDS:
        raise ValueError(
            f"dt={dt} s exceeds safety cap of {_DT_MAX_SECONDS} s. "
            f"Split into smaller steps."
        )


# ---------------------------------------------------------------------------
# State derivative container
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class StateDerivative:
    """
    Continuous-time derivatives of the bicycle-model state.

    Fields
    ------
    x_dot   : dX/dt  (m/s) = v·cos(ψ)
    y_dot   : dY/dt  (m/s) = v·sin(ψ)
    yaw_dot : dψ/dt  (rad/s) = v/L·tan(δ)
    v_dot   : dv/dt  (m/s²) = acceleration

    These are the raw continuous-time quantities.  Integration produces
    the next VehicleState.
    """
    x_dot:   float = 0.0
    y_dot:   float = 0.0
    yaw_dot: float = 0.0
    v_dot:   float = 0.0


# ---------------------------------------------------------------------------
# Trajectory container
# ---------------------------------------------------------------------------

@dataclass
class VehicleTrajectory:
    """
    Sequence of VehicleStates produced by KinematicBicycleModel.simulate().

    All states share the same CoordinateFrame and ModelVersion.
    Timestamps increase monotonically by dt.

    This is a model-output container.  It does NOT contain:
        * actuator commands
        * MPC horizon
        * CARLA objects
    """
    states:        List[VehicleState]  = field(default_factory=list)
    model_version: ModelVersion        = ModelVersion.KINEMATIC_BICYCLE_V1
    coordinate_frame: CoordinateFrame  = CoordinateFrame.VEHICLE
    schema_version: str                = "10.1"

    @property
    def length(self) -> int:
        return len(self.states)

    @property
    def is_empty(self) -> bool:
        return len(self.states) == 0

    def duration_s(self) -> float:
        """Total simulated duration (s); 0 if fewer than 2 states."""
        if len(self.states) < 2:
            return 0.0
        return self.states[-1].timestamp - self.states[0].timestamp


# ---------------------------------------------------------------------------
# Kinematic Bicycle Model
# ---------------------------------------------------------------------------

class KinematicBicycleModel:
    """
    Deterministic, stateless kinematic bicycle model.

    Usage
    -----
    >>> params = VehicleParameters.default()
    >>> model  = KinematicBicycleModel(params)
    >>> s0     = VehicleState(velocity=10.0, timestamp=0.0)
    >>> u      = VehicleControlInput(steering_angle=0.1, acceleration=0.0)
    >>> s1     = model.step(s0, u, dt=0.1)

    The model object itself holds no mutable state; all state lives in the
    VehicleState passed to each call.
    """

    MODEL_VERSION: ModelVersion = ModelVersion.KINEMATIC_BICYCLE_V1

    def __init__(
        self,
        params:          VehicleParameters = None,
        steering_policy: SteeringPolicy    = SteeringPolicy.CLAMP,
    ) -> None:
        """
        Initialise the bicycle model.

        Parameters
        ----------
        params          : VehicleParameters (frozen).  Uses default if None.
        steering_policy : SteeringPolicy.CLAMP (default) or REJECT.
        """
        self._params  = params if params is not None else VehicleParameters.default()
        self._policy  = steering_policy

    # ------------------------------------------------------------------ #
    # Properties
    # ------------------------------------------------------------------ #

    @property
    def params(self) -> VehicleParameters:
        return self._params

    @property
    def steering_policy(self) -> SteeringPolicy:
        return self._policy

    # ------------------------------------------------------------------ #
    # Core mathematical API
    # ------------------------------------------------------------------ #

    def state_derivative(
        self,
        state:         VehicleState,
        control_input: VehicleControlInput,
    ) -> StateDerivative:
        """
        Compute continuous-time derivatives for MPC / higher-order integrators.

        Returns StateDerivative(x_dot, y_dot, yaw_dot, v_dot).

        Does NOT modify state or control_input.

        Notes
        -----
        Steering is validated/clamped here according to the configured policy
        so the derivative is always physically valid.
        """
        state.validate()
        control_input.validate()

        delta = self._apply_steering_policy(
            control_input.steering_angle, previous_angle=state.steering_angle, dt=None
        )
        a = self._params.clamp_acceleration(control_input.acceleration)

        v   = state.velocity
        psi = state.yaw
        L   = self._params.wheelbase_m

        x_dot   = v * math.cos(psi)
        y_dot   = v * math.sin(psi)
        yaw_dot = (v / L) * math.tan(delta) if L > 0 else 0.0
        v_dot   = a

        return StateDerivative(
            x_dot=x_dot,
            y_dot=y_dot,
            yaw_dot=yaw_dot,
            v_dot=v_dot,
        )

    def step(
        self,
        state:         VehicleState,
        control_input: VehicleControlInput,
        dt:            float,
    ) -> VehicleState:
        """
        Propagate *state* forward by *dt* seconds using Euler integration.

        Parameters
        ----------
        state         : Current VehicleState.  Not mutated.
        control_input : Mathematical model input.  Not mutated.
        dt            : Timestep (s).  Must be > 0 and finite.

        Returns
        -------
        VehicleState  : Next state (new object; inputs are never modified).

        Raises
        ------
        ValueError    : If dt is invalid, state is non-finite, or
                        SteeringPolicy.REJECT and steering exceeds limit.
        """
        _validate_dt(dt)
        state.validate()
        control_input.validate()

        delta = self._apply_steering_policy(
            control_input.steering_angle,
            previous_angle=state.steering_angle,
            dt=dt,
        )
        a = self._params.clamp_acceleration(control_input.acceleration)

        v   = state.velocity
        psi = state.yaw
        L   = self._params.wheelbase_m

        # --- Continuous-time derivatives --------------------------------
        x_dot   = v * math.cos(psi)
        y_dot   = v * math.sin(psi)
        yaw_dot = (v / L) * math.tan(delta)
        v_dot   = a

        # --- Euler forward integration ----------------------------------
        x_next   = state.x   + x_dot   * dt
        y_next   = state.y   + y_dot   * dt
        psi_next = normalise_angle(psi + yaw_dot * dt)
        v_next   = self._params.clamp_velocity(v + v_dot * dt)

        # --- Derived quantities -----------------------------------------
        curvature = self.curvature(delta)
        yaw_rate  = v_next * curvature   # use post-step velocity

        return VehicleState(
            x=x_next,
            y=y_next,
            yaw=psi_next,
            velocity=v_next,
            acceleration=a,
            steering_angle=delta,
            yaw_rate=yaw_rate,
            timestamp=state.timestamp + dt,
            frame_id=state.frame_id + 1,
            coordinate_frame=state.coordinate_frame,
            state_kind=StateKind.SIMULATED,
        )

    # ------------------------------------------------------------------ #
    # Derived quantities
    # ------------------------------------------------------------------ #

    def curvature(self, steering_angle_rad: float) -> float:
        """
        Instantaneous curvature κ (1/m) for a given steering angle.

            κ = tan(δ) / L

        Positive curvature = left turn (+Y direction).
        Returns 0.0 when steering_angle is 0 or wheelbase is pathological.
        """
        L = self._params.wheelbase_m
        if L <= 0 or not math.isfinite(steering_angle_rad):
            return 0.0
        return math.tan(steering_angle_rad) / L

    def yaw_rate(self, velocity_mps: float, steering_angle_rad: float) -> float:
        """
        Instantaneous yaw rate ψ̇ (rad/s).

            ψ̇ = v · κ = v / L · tan(δ)
        """
        return velocity_mps * self.curvature(steering_angle_rad)

    def turning_radius(self, steering_angle_rad: float) -> float:
        """
        Instantaneous turning radius R (m).

            R = L / tan(δ)

        Returns float('inf') when steering_angle ≈ 0 (straight line).
        """
        L = self._params.wheelbase_m
        tan_d = math.tan(steering_angle_rad)
        if abs(tan_d) < 1e-9:
            return math.inf
        return L / tan_d

    # ------------------------------------------------------------------ #
    # Simulation API
    # ------------------------------------------------------------------ #

    def simulate(
        self,
        initial_state:    VehicleState,
        control_sequence: Sequence[VehicleControlInput],
        dt:               float,
    ) -> VehicleTrajectory:
        """
        Simulate a trajectory from *initial_state* over *control_sequence*.

        Parameters
        ----------
        initial_state    : Starting VehicleState.
        control_sequence : Ordered sequence of VehicleControlInput objects.
                           One input per timestep.  May be empty.
        dt               : Fixed timestep (s) applied to every step.

        Returns
        -------
        VehicleTrajectory : Contains initial_state + one state per input.
                            Total length = len(control_sequence) + 1.

        Notes
        -----
        * Deterministic: same inputs → same trajectory.
        * Bounded: exactly len(control_sequence) + 1 states.
        * No infinite loops.
        * Timestamps preserved monotonically.
        """
        _validate_dt(dt)
        initial_state.validate()

        states: List[VehicleState] = [initial_state.copy()]
        current = initial_state

        for u in control_sequence:
            u.validate()
            current = self.step(current, u, dt)
            states.append(current)

        return VehicleTrajectory(
            states=states,
            model_version=self.MODEL_VERSION,
            coordinate_frame=initial_state.coordinate_frame,
        )

    # ------------------------------------------------------------------ #
    # Internal helpers
    # ------------------------------------------------------------------ #

    def _apply_steering_policy(
        self,
        steering_angle:  float,
        previous_angle:  float,
        dt:              float | None,
    ) -> float:
        """
        Apply SteeringPolicy and steering-rate check.

        If dt is provided, also validates against max_steering_rate.
        Returns the (possibly clamped) valid steering angle.
        """
        limit = self._params.max_steering_angle_rad

        if self._policy == SteeringPolicy.REJECT:
            if abs(steering_angle) > limit + 1e-9:
                raise ValueError(
                    f"SteeringPolicy.REJECT: steering_angle={steering_angle:.4f} rad "
                    f"exceeds limit ±{limit:.4f} rad"
                )
            delta = steering_angle
        else:
            # CLAMP (default)
            delta = self._params.clamp_steering(steering_angle)

        # Steering-rate check (informational — model continues; Phase 10.4 controls)
        if dt is not None and dt > 0:
            rate_limit = self._params.max_steering_rate_rad_s
            achieved_rate = abs(delta - previous_angle) / dt
            if achieved_rate > rate_limit + 1e-9:
                # Phase 10.1 notes the violation but does not raise.
                # Phase 10.4 will enforce smooth steering commands.
                pass  # rate_exceeded = True (for future use)

        return delta
