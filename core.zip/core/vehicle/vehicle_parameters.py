"""
IndiDrive AI — Phase 10.1 | Vehicle Parameters
===============================================
Validated, immutable physical parameters for the kinematic bicycle model.

All distances in metres, angles in radians, velocities in m/s,
accelerations in m/s².

These are configuration values, NOT measured vehicle specifications.
They represent a generic mid-size passenger car suitable for Indian roads.
They MUST be replaced with characterised values once a real vehicle is used.

Validation rules
----------------
* wheelbase          > 0
* front_axle_distance + rear_axle_distance == wheelbase  (within 1 mm)
* vehicle_length     >= wheelbase
* vehicle_width      > 0
* max_steering_angle > 0   (radians)
* max_steering_rate  > 0   (radians/second)
* max_acceleration   > 0   (m/s²)
* max_deceleration   > 0   (m/s², positive magnitude; applied as negative a)
* max_velocity       > min_velocity >= 0  (m/s)
* All values must be finite.
"""
from __future__ import annotations

import math
from dataclasses import dataclass


# ---------------------------------------------------------------------------
# Defaults — clearly labelled as configuration, not measured specs
# ---------------------------------------------------------------------------

_DEFAULT_WHEELBASE_M          = 2.85    # ~mid-size sedan
_DEFAULT_FRONT_AXLE_DIST_M    = 1.50    # rear-axle origin → front axle
_DEFAULT_REAR_AXLE_DIST_M     = 1.35    # rear-axle origin → rear bumper overhang
_DEFAULT_LENGTH_M             = 4.50
_DEFAULT_WIDTH_M              = 1.80
_DEFAULT_MAX_STEER_RAD        = 0.610   # ~35 °
_DEFAULT_MAX_STEER_RATE_RAD_S = 0.700   # rad/s
_DEFAULT_MIN_VEL_MPS          = 0.0     # forward only; reverse not supported
_DEFAULT_MAX_VEL_MPS          = 33.33   # ~120 km/h
_DEFAULT_MIN_ACCEL_MPS2       = -8.0    # max deceleration (sign convention: negative)
_DEFAULT_MAX_ACCEL_MPS2       = 4.0


@dataclass(frozen=True)
class VehicleParameters:
    """
    Immutable, validated vehicle parameters for the kinematic bicycle model.

    Attributes
    ----------
    wheelbase_m           : Distance between front and rear axles (m).
    front_axle_distance_m : Distance from rear-axle origin to front axle (m).
                            Equals wheelbase_m for rear-axle reference.
    rear_axle_distance_m  : Distance from rear-axle origin to rear of vehicle (m).
    vehicle_length_m      : Total vehicle length (m).
    vehicle_width_m       : Total vehicle width (m).
    max_steering_angle_rad: Maximum absolute steering angle at the front wheel (rad).
    max_steering_rate_rad_s: Maximum rate of change of steering angle (rad/s).
    min_velocity_mps      : Minimum allowed velocity (m/s).  0 for forward-only.
    max_velocity_mps      : Maximum allowed velocity (m/s).
    min_acceleration_mps2 : Minimum (most negative) longitudinal acceleration (m/s²).
    max_acceleration_mps2 : Maximum positive longitudinal acceleration (m/s²).
    """

    wheelbase_m:            float = _DEFAULT_WHEELBASE_M
    front_axle_distance_m:  float = _DEFAULT_FRONT_AXLE_DIST_M
    rear_axle_distance_m:   float = _DEFAULT_REAR_AXLE_DIST_M
    vehicle_length_m:       float = _DEFAULT_LENGTH_M
    vehicle_width_m:        float = _DEFAULT_WIDTH_M
    max_steering_angle_rad: float = _DEFAULT_MAX_STEER_RAD
    max_steering_rate_rad_s:float = _DEFAULT_MAX_STEER_RATE_RAD_S
    min_velocity_mps:       float = _DEFAULT_MIN_VEL_MPS
    max_velocity_mps:       float = _DEFAULT_MAX_VEL_MPS
    min_acceleration_mps2:  float = _DEFAULT_MIN_ACCEL_MPS2
    max_acceleration_mps2:  float = _DEFAULT_MAX_ACCEL_MPS2

    # ------------------------------------------------------------------ #
    # Post-init validation (dataclass frozen=True — cannot be bypassed)
    # ------------------------------------------------------------------ #

    def __post_init__(self) -> None:
        self._validate()

    def _validate(self) -> None:
        """Raise ValueError for any physically invalid parameter."""
        fields = {
            "wheelbase_m":            self.wheelbase_m,
            "front_axle_distance_m":  self.front_axle_distance_m,
            "rear_axle_distance_m":   self.rear_axle_distance_m,
            "vehicle_length_m":       self.vehicle_length_m,
            "vehicle_width_m":        self.vehicle_width_m,
            "max_steering_angle_rad": self.max_steering_angle_rad,
            "max_steering_rate_rad_s":self.max_steering_rate_rad_s,
            "min_velocity_mps":       self.min_velocity_mps,
            "max_velocity_mps":       self.max_velocity_mps,
            "min_acceleration_mps2":  self.min_acceleration_mps2,
            "max_acceleration_mps2":  self.max_acceleration_mps2,
        }
        for name, val in fields.items():
            if not isinstance(val, (int, float)):
                raise TypeError(f"VehicleParameters.{name} must be numeric, got {type(val)}")
            if not math.isfinite(val):
                raise ValueError(f"VehicleParameters.{name} must be finite, got {val}")

        if self.wheelbase_m <= 0:
            raise ValueError(
                f"wheelbase_m must be > 0, got {self.wheelbase_m}"
            )
        if self.front_axle_distance_m <= 0:
            raise ValueError(
                f"front_axle_distance_m must be > 0, got {self.front_axle_distance_m}"
            )
        if self.rear_axle_distance_m < 0:
            raise ValueError(
                f"rear_axle_distance_m must be >= 0, got {self.rear_axle_distance_m}"
            )
        axle_sum = self.front_axle_distance_m + self.rear_axle_distance_m
        if abs(axle_sum - self.wheelbase_m) > 1e-3:
            raise ValueError(
                f"front_axle_distance_m ({self.front_axle_distance_m}) + "
                f"rear_axle_distance_m ({self.rear_axle_distance_m}) = {axle_sum} "
                f"must equal wheelbase_m ({self.wheelbase_m}) within 1 mm"
            )
        if self.vehicle_length_m < self.wheelbase_m:
            raise ValueError(
                f"vehicle_length_m ({self.vehicle_length_m}) must be >= "
                f"wheelbase_m ({self.wheelbase_m})"
            )
        if self.vehicle_width_m <= 0:
            raise ValueError(
                f"vehicle_width_m must be > 0, got {self.vehicle_width_m}"
            )
        if self.max_steering_angle_rad <= 0:
            raise ValueError(
                f"max_steering_angle_rad must be > 0, got {self.max_steering_angle_rad}"
            )
        if self.max_steering_rate_rad_s <= 0:
            raise ValueError(
                f"max_steering_rate_rad_s must be > 0, got {self.max_steering_rate_rad_s}"
            )
        if self.min_velocity_mps < 0:
            raise ValueError(
                f"min_velocity_mps must be >= 0 (reverse not supported), "
                f"got {self.min_velocity_mps}"
            )
        if self.max_velocity_mps <= self.min_velocity_mps:
            raise ValueError(
                f"max_velocity_mps ({self.max_velocity_mps}) must be > "
                f"min_velocity_mps ({self.min_velocity_mps})"
            )
        if self.max_acceleration_mps2 <= 0:
            raise ValueError(
                f"max_acceleration_mps2 must be > 0, got {self.max_acceleration_mps2}"
            )
        if self.min_acceleration_mps2 >= 0:
            raise ValueError(
                f"min_acceleration_mps2 must be < 0 (represents deceleration), "
                f"got {self.min_acceleration_mps2}"
            )

    # ------------------------------------------------------------------ #
    # Derived properties
    # ------------------------------------------------------------------ #

    @property
    def front_overhang_m(self) -> float:
        """Distance from front axle to front bumper (m)."""
        return self.vehicle_length_m - self.front_axle_distance_m - self.rear_axle_distance_m

    @property
    def half_width_m(self) -> float:
        """Half vehicle width (m)."""
        return self.vehicle_width_m / 2.0

    def clamp_steering(self, delta_rad: float) -> float:
        """Return steering clamped to [-max_steering_angle_rad, +max_steering_angle_rad]."""
        return max(-self.max_steering_angle_rad,
                   min(self.max_steering_angle_rad, delta_rad))

    def clamp_acceleration(self, accel_mps2: float) -> float:
        """Return acceleration clamped to [min_acceleration_mps2, max_acceleration_mps2]."""
        return max(self.min_acceleration_mps2,
                   min(self.max_acceleration_mps2, accel_mps2))

    def clamp_velocity(self, vel_mps: float) -> float:
        """Return velocity clamped to [min_velocity_mps, max_velocity_mps]."""
        return max(self.min_velocity_mps, min(self.max_velocity_mps, vel_mps))

    @classmethod
    def default(cls) -> "VehicleParameters":
        """Return the default configuration-level parameters."""
        return cls()
