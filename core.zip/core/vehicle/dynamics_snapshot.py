"""
IndiDrive AI — Phase 10.1 | Dynamics Snapshot
==============================================
Immutable diagnostic snapshot of the vehicle dynamics state.

The snapshot captures everything needed to reproduce or audit a model
evaluation at a given instant:

    vehicle parameters (frozen)
    current state (copied)
    derived quantities
    model version
    coordinate frame
    schema version
    timestamp

Modifying any upstream object after snapshot creation does NOT mutate
the snapshot.

This is NOT a CARLA object.  It does NOT contain actuator commands.
"""
from __future__ import annotations

import math
import time
from dataclasses import dataclass, field
from typing import Optional

from .vehicle_types import (
    VEHICLE_SCHEMA_VERSION,
    CoordinateFrame,
    ModelVersion,
)
from .vehicle_parameters import VehicleParameters
from .vehicle_state import VehicleState
from .vehicle_input import VehicleControlInput


@dataclass(frozen=True)
class DynamicsSnapshot:
    """
    Immutable snapshot of one model evaluation.

    frozen=True guarantees that no field can be mutated after construction.
    All mutable inputs are deep-copied at creation time.

    Fields
    ------
    model_version       : ModelVersion enum (e.g. KINEMATIC_BICYCLE_V1).
    schema_version      : "10.1" (Phase 10.1).
    snapshot_timestamp  : Wall-clock time when the snapshot was taken (s).
    sim_timestamp       : Simulation time of the captured state (s).
    coordinate_frame    : Always VEHICLE for Phase 10.1.
    frame_id            : Frame counter from the captured state.

    # State (copies — immutable)
    x               : Position X (m).
    y               : Position Y (m).
    yaw             : Heading (rad), normalised to [-π, π).
    velocity        : Forward speed (m/s).
    acceleration    : Longitudinal acceleration (m/s²).
    steering_angle  : Front-wheel steering angle (rad).
    yaw_rate        : ψ̇ (rad/s).

    # Derived quantities
    curvature       : κ = tan(δ)/L  (1/m).
    turning_radius  : R = L/tan(δ)  (m); inf for straight.

    # Parameters (summary)
    wheelbase_m           : (m)
    max_steering_angle_rad: (rad)
    max_velocity_mps      : (m/s)
    """

    # Identity ---------------------------------------------------------------
    model_version:      ModelVersion    = ModelVersion.KINEMATIC_BICYCLE_V1
    schema_version:     str             = VEHICLE_SCHEMA_VERSION
    snapshot_timestamp: float           = field(default_factory=time.time)
    sim_timestamp:      float           = 0.0
    coordinate_frame:   CoordinateFrame = CoordinateFrame.VEHICLE
    frame_id:           int             = 0

    # State fields (copies of VehicleState scalars) --------------------------
    x:              float = 0.0
    y:              float = 0.0
    yaw:            float = 0.0
    velocity:       float = 0.0
    acceleration:   float = 0.0
    steering_angle: float = 0.0
    yaw_rate:       float = 0.0

    # Derived ----------------------------------------------------------------
    curvature:      float = 0.0
    turning_radius: float = math.inf

    # Parameter summary ------------------------------------------------------
    wheelbase_m:            float = 0.0
    max_steering_angle_rad: float = 0.0
    max_velocity_mps:       float = 0.0

    # ------------------------------------------------------------------ #
    # Factory
    # ------------------------------------------------------------------ #

    @classmethod
    def from_state(
        cls,
        state:          VehicleState,
        params:         VehicleParameters,
        model_version:  ModelVersion = ModelVersion.KINEMATIC_BICYCLE_V1,
    ) -> "DynamicsSnapshot":
        """
        Build a snapshot from a VehicleState and VehicleParameters.

        Derived quantities (curvature, turning_radius) are computed here.
        All values are scalar copies; no references to mutable objects.
        """
        delta = state.steering_angle
        L     = params.wheelbase_m

        tan_d     = math.tan(delta) if math.isfinite(delta) else 0.0
        curvature = tan_d / L if L > 0 else 0.0
        t_radius  = (L / tan_d) if abs(tan_d) > 1e-9 else math.inf

        return cls(
            model_version       = model_version,
            schema_version      = VEHICLE_SCHEMA_VERSION,
            snapshot_timestamp  = time.time(),
            sim_timestamp       = state.timestamp,
            coordinate_frame    = state.coordinate_frame,
            frame_id            = state.frame_id,
            # State scalars ---
            x               = float(state.x),
            y               = float(state.y),
            yaw             = float(state.yaw),
            velocity        = float(state.velocity),
            acceleration    = float(state.acceleration),
            steering_angle  = float(state.steering_angle),
            yaw_rate        = float(state.yaw_rate),
            # Derived ---
            curvature       = float(curvature),
            turning_radius  = float(t_radius),
            # Param summary ---
            wheelbase_m             = float(params.wheelbase_m),
            max_steering_angle_rad  = float(params.max_steering_angle_rad),
            max_velocity_mps        = float(params.max_velocity_mps),
        )

    # ------------------------------------------------------------------ #

    def __repr__(self) -> str:
        return (
            f"DynamicsSnapshot("
            f"model={self.model_version.value}, "
            f"t={self.sim_timestamp:.3f}s, "
            f"x={self.x:.3f}, y={self.y:.3f}, "
            f"yaw={math.degrees(self.yaw):.1f}°, "
            f"v={self.velocity:.2f} m/s)"
        )
