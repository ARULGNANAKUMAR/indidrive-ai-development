"""
IndiDrive AI — Phase 10.1 | Dynamics Configuration
====================================================
Runtime configuration for the vehicle dynamics package.

Loads from config/vehicle_config.yaml if a dynamics10 section is present,
otherwise falls back to code defaults.

All physical values are in SI units (metres, seconds, radians, m/s, m/s²).
These are configuration-level defaults, NOT characterised vehicle specs.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Optional

from .vehicle_types import ModelVersion, SteeringPolicy
from .vehicle_parameters import VehicleParameters


# ---------------------------------------------------------------------------
# Configuration dataclass
# ---------------------------------------------------------------------------

@dataclass
class DynamicsConfig:
    """
    Top-level runtime configuration for the Phase 10.1 dynamics package.

    Attributes
    ----------
    model_version   : Which bicycle model variant to use.
    steering_policy : CLAMP or REJECT for out-of-range steering inputs.
    params          : VehicleParameters (validated at construction).
    dt_max_s        : Maximum allowed integration timestep (s).
    """

    model_version:   ModelVersion    = ModelVersion.KINEMATIC_BICYCLE_V1
    steering_policy: SteeringPolicy  = SteeringPolicy.CLAMP
    params:          VehicleParameters = field(
        default_factory=VehicleParameters.default
    )
    dt_max_s: float = 10.0   # hard cap on dt (see bicycle_model._DT_MAX_SECONDS)

    def __post_init__(self) -> None:
        if not math.isfinite(self.dt_max_s) or self.dt_max_s <= 0:
            raise ValueError(
                f"DynamicsConfig.dt_max_s must be > 0 and finite, got {self.dt_max_s}"
            )

    # ------------------------------------------------------------------ #
    # Factory: build from a yaml-loaded dict (partial merge)
    # ------------------------------------------------------------------ #

    @classmethod
    def from_dict(cls, cfg: dict) -> "DynamicsConfig":
        """
        Build a DynamicsConfig from a dict such as those loaded from YAML.

        Only keys present in *cfg* override defaults.  Missing keys are
        silently ignored so partial configs are safe.

        Expected dict shape (all optional):

            model: "kinematic_bicycle"
            steering_policy: "CLAMP"        # or "REJECT"
            wheelbase_m: 2.85
            front_axle_distance_m: 1.50
            rear_axle_distance_m: 1.35
            length_m: 4.50
            width_m: 1.80
            max_steering_angle_rad: 0.610
            max_steering_rate_rad_s: 0.700
            min_velocity_mps: 0.0
            max_velocity_mps: 33.33
            min_acceleration_mps2: -8.0
            max_acceleration_mps2: 4.0
            dt_max_s: 10.0
        """
        def _f(key: str, default: float) -> float:
            val = cfg.get(key, default)
            return float(val) if val is not None else default

        params = VehicleParameters(
            wheelbase_m            = _f("wheelbase_m",             VehicleParameters().wheelbase_m),
            front_axle_distance_m  = _f("front_axle_distance_m",  VehicleParameters().front_axle_distance_m),
            rear_axle_distance_m   = _f("rear_axle_distance_m",   VehicleParameters().rear_axle_distance_m),
            vehicle_length_m       = _f("length_m",               VehicleParameters().vehicle_length_m),
            vehicle_width_m        = _f("width_m",                VehicleParameters().vehicle_width_m),
            max_steering_angle_rad = _f("max_steering_angle_rad", VehicleParameters().max_steering_angle_rad),
            max_steering_rate_rad_s= _f("max_steering_rate_rad_s",VehicleParameters().max_steering_rate_rad_s),
            min_velocity_mps       = _f("min_velocity_mps",       VehicleParameters().min_velocity_mps),
            max_velocity_mps       = _f("max_velocity_mps",       VehicleParameters().max_velocity_mps),
            min_acceleration_mps2  = _f("min_acceleration_mps2",  VehicleParameters().min_acceleration_mps2),
            max_acceleration_mps2  = _f("max_acceleration_mps2",  VehicleParameters().max_acceleration_mps2),
        )

        policy_str = cfg.get("steering_policy", "CLAMP").upper()
        try:
            policy = SteeringPolicy[policy_str]
        except KeyError:
            policy = SteeringPolicy.CLAMP

        return cls(
            model_version   = ModelVersion.KINEMATIC_BICYCLE_V1,
            steering_policy = policy,
            params          = params,
            dt_max_s        = _f("dt_max_s", 10.0),
        )

    @classmethod
    def default(cls) -> "DynamicsConfig":
        """Return a fully default DynamicsConfig."""
        return cls()
