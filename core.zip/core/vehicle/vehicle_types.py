"""
IndiDrive AI — Phase 10.1 | Vehicle Types — Enums and Constants
================================================================
Shared enumerations and schema sentinel for the vehicle dynamics package.

Nothing here performs computation.  All values are structural.

Coordinate convention (project-wide):
    +X = forward
    +Y = left
    +Z = up
    Origin = vehicle rear-axle centre
    Units  = metres, radians, seconds
"""
from __future__ import annotations

from enum import Enum

# ---------------------------------------------------------------------------
# Schema version
# ---------------------------------------------------------------------------

VEHICLE_SCHEMA_VERSION: str = "10.1"


# ---------------------------------------------------------------------------
# Model identity
# ---------------------------------------------------------------------------

class ModelVersion(str, Enum):
    """
    Explicit model-version tag attached to every snapshot.

    KINEMATIC_BICYCLE_V1 — rear-axle kinematic bicycle model
        Equations:
            x_dot   = v * cos(yaw)
            y_dot   = v * sin(yaw)
            yaw_dot = v / L * tan(delta)
            v_dot   = acceleration
        Assumptions:
            * zero slip angle (beta = 0)
            * point-mass approximation
            * no tyre dynamics, no lateral force model
            * Euler forward integration
    """
    KINEMATIC_BICYCLE_V1 = "KINEMATIC_BICYCLE_V1"
    UNKNOWN              = "UNKNOWN"


# ---------------------------------------------------------------------------
# Coordinate frame
# ---------------------------------------------------------------------------

class CoordinateFrame(str, Enum):
    """
    Reference frame in which a state or trajectory is expressed.

    VEHICLE — vehicle body frame
        Origin = rear-axle centre
        +X = forward (longitudinal)
        +Y = left    (lateral)
        +Z = up      (vertical)
    WORLD   — absolute/map frame (future use).
    UNKNOWN — frame not determined.
    """
    VEHICLE = "VEHICLE"
    WORLD   = "WORLD"
    UNKNOWN = "UNKNOWN"


# ---------------------------------------------------------------------------
# State kind
# ---------------------------------------------------------------------------

class StateKind(str, Enum):
    """
    Distinguishes how a VehicleState was produced.

    MEASURED  — directly observed (e.g. from sensor/localisation).
    ESTIMATED — filtered/estimated from measurements.
    SIMULATED — propagated forward by the bicycle model.
    UNKNOWN   — provenance not determined.
    """
    MEASURED  = "MEASURED"
    ESTIMATED = "ESTIMATED"
    SIMULATED = "SIMULATED"
    UNKNOWN   = "UNKNOWN"


# ---------------------------------------------------------------------------
# Steering policy
# ---------------------------------------------------------------------------

class SteeringPolicy(str, Enum):
    """
    Configured behaviour when a control input exceeds the steering limit.

    CLAMP  — silently clamp the steering angle to the configured limit.
             The model continues with the clamped value.
    REJECT — raise ValueError; the caller must supply a valid input.
    """
    CLAMP  = "CLAMP"
    REJECT = "REJECT"
