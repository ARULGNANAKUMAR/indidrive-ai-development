"""
IndiDrive AI — Phase 10.1 | Vehicle Dynamics + Bicycle Model Foundation
=========================================================================
Package exposing the kinematic bicycle model and supporting types.

Public API
----------
    VehicleParameters    — validated physical parameters
    VehicleState         — kinematic state (x, y, yaw, velocity, …)
    VehicleControlInput  — mathematical model input (NOT an actuator command)
    KinematicBicycleModel — standard rear-axle kinematic bicycle model
    StateDerivative      — dx/dt container
    VehicleTrajectory    — sequence of VehicleState with timestamps
    DynamicsSnapshot     — immutable diagnostic snapshot
    DynamicsConfig       — runtime configuration
    VEHICLE_SCHEMA_VERSION

Coordinate convention (same as all prior phases):
    +X = forward, +Y = left, +Z = up
    Origin = vehicle rear-axle centre
    Units  = metres, radians, seconds
"""

from .vehicle_types import (
    VEHICLE_SCHEMA_VERSION,
    CoordinateFrame,
    StateKind,
    SteeringPolicy,
    ModelVersion,
)
from .vehicle_parameters import VehicleParameters
from .vehicle_state import VehicleState
from .vehicle_input import VehicleControlInput
from .bicycle_model import (
    KinematicBicycleModel,
    StateDerivative,
    VehicleTrajectory,
)
from .dynamics_validator import DynamicsValidator
from .dynamics_snapshot import DynamicsSnapshot
from .dynamics_config import DynamicsConfig

__all__ = [
    "VEHICLE_SCHEMA_VERSION",
    "CoordinateFrame",
    "StateKind",
    "SteeringPolicy",
    "ModelVersion",
    "VehicleParameters",
    "VehicleState",
    "VehicleControlInput",
    "KinematicBicycleModel",
    "StateDerivative",
    "VehicleTrajectory",
    "DynamicsValidator",
    "DynamicsSnapshot",
    "DynamicsConfig",
]
