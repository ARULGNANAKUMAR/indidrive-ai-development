"""
IndiDrive AI — Phase 10.1 | Vehicle Control Input
==================================================
Typed mathematical input for the kinematic bicycle model.

⚠ This is a SIMULATION / MODEL INPUT — NOT an actuator command.

This structure is consumed by:
    KinematicBicycleModel.step(state, control_input, dt)

It does NOT:
    * send commands to CARLA (vehicle.apply_control)
    * set physical throttle, brake, or steering actuators
    * compute target speed or heading

Those actuator concerns belong to Phase 10.4 (Steering / Speed Control)
and Phase 10.5 (Planner → MPC Integration).

Fields
------
steering_angle  : Front-wheel steering angle (rad).
                  Must be within [-params.max_steering_angle_rad,
                                  +params.max_steering_angle_rad].
                  The model enforces the configured SteeringPolicy.
acceleration    : Longitudinal acceleration (m/s²).
                  Positive = accelerate; negative = decelerate.
                  Must be within [params.min_acceleration_mps2,
                                  params.max_acceleration_mps2].
timestamp       : Time at which this input is valid (s).
frame_id        : Optional frame counter (integer ≥ 0).
"""
from __future__ import annotations

import math
from dataclasses import dataclass


@dataclass
class VehicleControlInput:
    """
    Mathematical input to the kinematic bicycle model.

    This is NOT a vehicle actuator command.  It is the mathematical
    representation of steering and acceleration used by the model equations:

        yaw_dot = v / L * tan(steering_angle)
        v_dot   = acceleration

    The bicycle model validates and/or clamps these values against
    VehicleParameters before propagating state.
    """

    steering_angle: float = 0.0   # front-wheel steering angle (rad)
    acceleration:   float = 0.0   # longitudinal acceleration (m/s²)
    timestamp:      float = 0.0   # time at which this input applies (s)
    frame_id:       int   = 0     # optional frame counter

    # ------------------------------------------------------------------ #

    def is_finite(self) -> bool:
        """Return True iff all numeric fields are finite."""
        return (
            math.isfinite(self.steering_angle)
            and math.isfinite(self.acceleration)
            and math.isfinite(self.timestamp)
        )

    def validate(self) -> None:
        """
        Raise ValueError if any numeric field is non-finite or frame_id < 0.

        Limit-checking (steering/acceleration bounds) is deferred to the
        model and its configured SteeringPolicy, so the caller can supply
        an out-of-range value and let the model decide whether to clamp
        or reject.
        """
        for name, val in [
            ("steering_angle", self.steering_angle),
            ("acceleration",   self.acceleration),
            ("timestamp",      self.timestamp),
        ]:
            if not isinstance(val, (int, float)) or not math.isfinite(val):
                raise ValueError(
                    f"VehicleControlInput.{name} must be finite, got {val!r}"
                )
        if self.frame_id < 0:
            raise ValueError(
                f"VehicleControlInput.frame_id must be ≥ 0, got {self.frame_id}"
            )

    @classmethod
    def zero(cls, timestamp: float = 0.0) -> "VehicleControlInput":
        """Return a zero-input (coast, no steering) at the given timestamp."""
        return cls(steering_angle=0.0, acceleration=0.0, timestamp=timestamp)

    def __repr__(self) -> str:
        import math as _m
        return (
            f"VehicleControlInput("
            f"delta={_m.degrees(self.steering_angle):.1f}°, "
            f"a={self.acceleration:.2f} m/s², t={self.timestamp:.3f}s)"
        )
