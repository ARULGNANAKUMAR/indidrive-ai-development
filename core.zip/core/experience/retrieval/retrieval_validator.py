"""
IndiDrive AI — Phase 12.4 | Retrieval Validator
================================================
Validates Phase 12.4 retrieval structures.

Rules:
    * Returns (is_valid: bool, reason: str) — no exceptions for validation.
    * Does NOT silently correct corrupted data.
    * Deterministic.
"""
from __future__ import annotations

import math
from typing import Tuple

from .retrieval_types import (
    NOT_AVAILABLE,
    RETRIEVAL_SCHEMA_VERSION,
    ExperienceRetrievalQuery,
    ExperienceRetrievalResult,
    ExperienceReuseContext,
    RetrievedExperience,
    RetrievalStatus,
)

__all__ = ["RetrievalValidator"]

_ValidationResult = Tuple[bool, str]


class RetrievalValidator:
    """Validates Phase 12.4 retrieval structures."""

    # ------------------------------------------------------------------
    # Query validation

    def validate_query(self, q: ExperienceRetrievalQuery) -> _ValidationResult:
        if q is None:
            return False, "query is None"
        if q.schema_version != RETRIEVAL_SCHEMA_VERSION:
            return False, f"schema_version mismatch: {q.schema_version!r}"
        if not q.query_id or q.query_id == NOT_AVAILABLE:
            return False, "query_id missing"
        if not q.session_id or q.session_id == NOT_AVAILABLE:
            return False, "session_id missing"
        if q.timestamp < 0:
            return False, f"timestamp < 0: {q.timestamp}"
        if q.maximum_results < 1:
            return False, f"maximum_results < 1: {q.maximum_results}"
        ok, reason = self._check_float_range(q.minimum_relevance, "minimum_relevance")
        if not ok:
            return False, reason
        return True, "ok"

    # ------------------------------------------------------------------
    # Result validation

    def validate_result(self, r: ExperienceRetrievalResult) -> _ValidationResult:
        if r is None:
            return False, "result is None"
        if r.schema_version != RETRIEVAL_SCHEMA_VERSION:
            return False, f"schema_version mismatch: {r.schema_version!r}"
        if not r.query_id or r.query_id == NOT_AVAILABLE:
            return False, "query_id missing"
        expected_rid = f"{r.query_id}-RES"
        if r.result_id != expected_rid:
            return False, f"result_id {r.result_id!r} != expected {expected_rid!r}"
        if r.retrieval_timestamp < 0:
            return False, "retrieval_timestamp < 0"
        if not isinstance(r.retrieval_status, RetrievalStatus):
            return False, "retrieval_status invalid type"
        if r.returned_count != len(r.retrieved_experiences):
            return False, (
                f"returned_count {r.returned_count} != "
                f"len(retrieved_experiences) {len(r.retrieved_experiences)}"
            )
        if r.returned_count > r.total_candidates_scanned and r.total_candidates_scanned > 0:
            return False, "returned_count > total_candidates_scanned"
        # Validate each retrieved experience
        for i, exp in enumerate(r.retrieved_experiences):
            ok, reason = self.validate_retrieved_experience(exp)
            if not ok:
                return False, f"retrieved_experiences[{i}]: {reason}"
        return True, "ok"

    # ------------------------------------------------------------------
    # Retrieved experience validation

    def validate_retrieved_experience(
        self, exp: RetrievedExperience
    ) -> _ValidationResult:
        if exp is None:
            return False, "experience is None"
        if not exp.experience_id or exp.experience_id == NOT_AVAILABLE:
            return False, "experience_id missing"
        ok, reason = self._check_float_range(exp.relevance_score, "relevance_score")
        if not ok:
            return False, reason
        if not isinstance(exp.match_reasons, tuple):
            return False, "match_reasons must be tuple"
        if not isinstance(exp.mismatch_reasons, tuple):
            return False, "mismatch_reasons must be tuple"
        return True, "ok"

    # ------------------------------------------------------------------
    # Reuse context validation

    def validate_reuse_context(self, ctx: ExperienceReuseContext) -> _ValidationResult:
        if ctx is None:
            return False, "context is None"
        if ctx.schema_version != RETRIEVAL_SCHEMA_VERSION:
            return False, f"schema_version mismatch: {ctx.schema_version!r}"
        if ctx.retrieved_count != len(ctx.experiences):
            return False, (
                f"retrieved_count {ctx.retrieved_count} != "
                f"len(experiences) {len(ctx.experiences)}"
            )
        count_sum = (ctx.success_count + ctx.partial_success_count
                     + ctx.failure_count + ctx.unsafe_count)
        # Sum of named counts must not exceed total
        if count_sum > ctx.retrieved_count:
            return False, (
                f"outcome counts sum {count_sum} > retrieved_count {ctx.retrieved_count}"
            )
        return True, "ok"

    # ------------------------------------------------------------------
    # Helpers

    @staticmethod
    def _check_float_range(v: float, name: str) -> _ValidationResult:
        if not isinstance(v, (int, float)):
            return False, f"{name} must be numeric"
        if math.isnan(v) or math.isinf(v):
            return False, f"{name} is NaN or infinite"
        if not (0.0 <= v <= 1.0):
            return False, f"{name} {v} out of [0.0, 1.0]"
        return True, "ok"
