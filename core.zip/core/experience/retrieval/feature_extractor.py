"""
IndiDrive AI — Phase 12.4 | Feature Extractor
==============================================
Derives compact retrieval features from existing Phase 12.1/12.2 record types.

No new perception.  No new sensor processing.
Only reads from existing SituationRecord / ActionRecord / OutcomeRecord.

Usage
-----
extractor = FeatureExtractor()
road_ctx    = extractor.road_context_from_situation(sit)
traffic_ctx = extractor.traffic_context_from_situation(sit)
hazard_ctx  = extractor.hazard_context_from_situation(sit)
vehicle_ctx = extractor.vehicle_context_from_situation(sit)
planning_ctx = extractor.planning_context_from_action(act)
safety_ctx  = extractor.safety_context_from_situation(sit)
query       = extractor.build_query(record, evaluation, query_id, max_results)
"""
from __future__ import annotations

import time
from typing import Optional

from core.experience.record.record_types import (
    NOT_AVAILABLE,
    ActionRecord,
    ActionType,
    ExperienceRecord,
    OutcomeRecord,
    SituationRecord,
)
from core.experience.evaluation.evaluation_types import (
    OutcomeEvaluationSnapshot,
)

from .retrieval_types import (
    RETRIEVAL_SCHEMA_VERSION,
    ExperienceRetrievalConfig,
    ExperienceRetrievalQuery,
    HazardContext,
    PlanningContext,
    RetrievalPolicy,
    RoadContext,
    SafetyContext,
    TrafficContext,
    VehicleContext,
)

__all__ = ["FeatureExtractor"]

_STOPPED_THRESHOLD_MS = 0.5


def _upper(v: Optional[str]) -> str:
    if v is None or v == NOT_AVAILABLE:
        return ""
    return str(v).upper()


class FeatureExtractor:
    """
    Derives structured retrieval features from existing pipeline records.

    Stateless — one instance can be reused across many records.
    """

    # ------------------------------------------------------------------
    # Road context

    def road_context_from_situation(
        self, sit: Optional[SituationRecord]
    ) -> RoadContext:
        if sit is None:
            return RoadContext()
        return RoadContext(
            road_type=sit.road_type or NOT_AVAILABLE,
            road_structure=sit.road_structure or NOT_AVAILABLE,
            lane_marking_state=sit.lane_marking_state or NOT_AVAILABLE,
            intersection_state=sit.intersection_state or NOT_AVAILABLE,
            road_anomaly_present=bool(sit.road_hazard_present),
            road_anomaly_summary=sit.road_anomaly_summary or NOT_AVAILABLE,
        )

    # ------------------------------------------------------------------
    # Traffic context

    def traffic_context_from_situation(
        self, sit: Optional[SituationRecord]
    ) -> TrafficContext:
        if sit is None:
            return TrafficContext()
        return TrafficContext(
            traffic_density=sit.traffic_density or NOT_AVAILABLE,
            traffic_mix=sit.traffic_mix or NOT_AVAILABLE,
            nearby_object_count=int(sit.nearby_object_count or 0),
            vulnerable_road_user_present=bool(sit.vulnerable_road_user_present),
            cattle_present=bool(sit.cattle_present),
            # object_type_summary is not a SituationRecord field; derive from traffic_mix
            object_type_summary=sit.traffic_mix or NOT_AVAILABLE,
        )

    # ------------------------------------------------------------------
    # Hazard context

    def hazard_context_from_situation(
        self, sit: Optional[SituationRecord]
    ) -> HazardContext:
        if sit is None:
            return HazardContext()
        evt = sit.triggering_event_type or NOT_AVAILABLE
        events = (evt,) if evt != NOT_AVAILABLE else ()
        # dominant_hazard is on SituationRecord (not dominant_hazard_category)
        dom = getattr(sit, "dominant_hazard", NOT_AVAILABLE) or NOT_AVAILABLE
        return HazardContext(
            hazard_level=sit.hazard_level or NOT_AVAILABLE,
            dominant_hazard=dom,
            road_hazard_present=bool(sit.road_hazard_present),
            event_types=events,
        )

    # ------------------------------------------------------------------
    # Vehicle context

    def vehicle_context_from_situation(
        self, sit: Optional[SituationRecord]
    ) -> VehicleContext:
        if sit is None:
            return VehicleContext()
        speed = sit.ego_speed_ms
        is_stopped = speed is not None and speed <= _STOPPED_THRESHOLD_MS
        # SituationRecord does not have is_braking or control_state directly;
        # derive from ego_acceleration and is_degraded
        accel = sit.ego_acceleration_ms2
        is_braking = accel is not None and accel < -0.1
        is_degraded = bool(sit.is_degraded)
        return VehicleContext(
            speed_ms=speed,
            is_braking=is_braking,
            is_stopped=is_stopped,
            control_degraded=is_degraded,
        )

    # ------------------------------------------------------------------
    # Planning context

    def planning_context_from_action(
        self, act: Optional[ActionRecord]
    ) -> PlanningContext:
        if act is None:
            return PlanningContext()
        at = NOT_AVAILABLE
        replanning = False
        if act.requested is not None:
            if act.requested.action_type is not None:
                at = act.requested.action_type.value
            # replanning_active is on RequestedAction
            replanning = bool(getattr(act.requested, "replanning_active", False))
        return PlanningContext(
            action_type=at,
            replanning_active=replanning,
            planning_degraded=bool(act.is_degraded),
        )

    # ------------------------------------------------------------------
    # Safety context

    def safety_context_from_situation(
        self, sit: Optional[SituationRecord]
    ) -> SafetyContext:
        if sit is None:
            return SafetyContext()
        return SafetyContext(
            safety_state=sit.safety_state or NOT_AVAILABLE,
            emergency_state=sit.emergency_state or NOT_AVAILABLE,
            failsafe_state=sit.failsafe_state or NOT_AVAILABLE,
            safety_degraded=bool(sit.is_degraded),
        )

    # ------------------------------------------------------------------
    # Full query builder

    def build_query(
        self,
        record: ExperienceRecord,
        query_id: str,
        cfg: ExperienceRetrievalConfig,
    ) -> ExperienceRetrievalQuery:
        """
        Build a retrieval query from the current ExperienceRecord.

        Uses only existing pipeline outputs — no new perception.
        """
        sit = record.situation if record is not None else None
        act = record.action if record is not None else None

        road_ctx = self.road_context_from_situation(sit)
        traffic_ctx = self.traffic_context_from_situation(sit)
        hazard_ctx = self.hazard_context_from_situation(sit)
        vehicle_ctx = self.vehicle_context_from_situation(sit)
        planning_ctx = self.planning_context_from_action(act)
        safety_ctx = self.safety_context_from_situation(sit)

        session_id = NOT_AVAILABLE
        sit_type = NOT_AVAILABLE
        event_types: tuple = ()

        if record is not None:
            session_id = record.session_id or NOT_AVAILABLE
            if sit is not None:
                sit_type = sit.situation_type or NOT_AVAILABLE
                et = sit.triggering_event_type
                event_types = (et,) if et and et != NOT_AVAILABLE else ()

        return ExperienceRetrievalQuery(
            query_id=query_id,
            session_id=session_id,
            timestamp=time.time(),
            schema_version=RETRIEVAL_SCHEMA_VERSION,
            situation_type=sit_type,
            road_context=road_ctx,
            traffic_context=traffic_ctx,
            hazard_context=hazard_ctx,
            vehicle_context=vehicle_ctx,
            planning_context=planning_ctx,
            safety_context=safety_ctx,
            event_types=event_types,
            maximum_results=cfg.max_results,
            minimum_relevance=cfg.minimum_relevance,
            retrieval_policy=cfg.retrieval_policy.value,
        )
