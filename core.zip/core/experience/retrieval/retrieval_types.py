"""
IndiDrive AI — Phase 12.4 | Experience Retrieval Types
=======================================================
Strongly-typed containers for the Experience Retrieval layer.

Phase 12.4 answers ONLY:
    «"Have we seen a sufficiently similar driving situation before,
      and what happened when that experience occurred?"»

Phase 12.4 does NOT:
    - update knowledge, policies, or models     → Phase 12.5
    - improve future decisions automatically    → Phase 12.6
    - generate RL reward                        → Phase 12.6
    - control the vehicle                       → pipeline
    - override safety decisions                 → safety subsystems
    - require internet, cloud, or LLM
    - use external vector databases

Design rules (consistent with all prior phases):
    * dataclasses — not raw dicts
    * explicit NOT_AVAILABLE / UNKNOWN — never fabricated
    * deterministic: same query + same store → same results
    * immutable snapshots for external consumers
    * read-only: retrieval never mutates stored experiences
    * offline-first

ID conventions (extend Phase 12.1–12.3):
    Record:      <session_id>-R<seq:06d>
    Evaluation:  <record_id>-EVAL
    Query:       <session_id>-Q<seq:06d>
    Result:      <query_id>-RES
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from enum import Enum
from typing import List, Optional, Tuple

NOT_AVAILABLE = "NOT_AVAILABLE"
RETRIEVAL_SCHEMA_VERSION = "12.4"


# ---------------------------------------------------------------------------
# Retrieval status enums
# ---------------------------------------------------------------------------

class RetrievalStatus(str, Enum):
    """
    Operational status of one retrieval operation.

    SUCCESS   — retrieval completed normally (may have 0 results).
    DEGRADED  — completed but with reduced quality (e.g. store partially degraded).
    EMPTY     — store has no experiences to search.
    ERROR     — retrieval encountered an internal error; pipeline unaffected.
    DISABLED  — retrieval is disabled by configuration.
    """
    SUCCESS  = "SUCCESS"
    DEGRADED = "DEGRADED"
    EMPTY    = "EMPTY"
    ERROR    = "ERROR"
    DISABLED = "DISABLED"


class RetrievalPolicy(str, Enum):
    """
    Controls which experience outcome classes are eligible for retrieval.

    QUALITY_ONLY      — only SUCCESS and PARTIAL_SUCCESS experiences.
    ALL_EVALUATED     — any experience with a complete evaluation.
    ALL_COMPLETED     — any structurally complete record, regardless of evaluation.
    CUSTOM            — governed by individual include_* flags in config.
    """
    QUALITY_ONLY  = "QUALITY_ONLY"
    ALL_EVALUATED = "ALL_EVALUATED"
    ALL_COMPLETED = "ALL_COMPLETED"
    CUSTOM        = "CUSTOM"


class ExperienceQuality(str, Enum):
    """
    Compact quality rating for a retrieved experience, combining record
    completeness and evaluation confidence.

    HIGH    — complete record + HIGH evaluation confidence
    MEDIUM  — complete record + MEDIUM confidence, or partial + HIGH
    LOW     — partial/degraded record, or LOW confidence
    UNKNOWN — quality cannot be determined
    """
    HIGH    = "HIGH"
    MEDIUM  = "MEDIUM"
    LOW     = "LOW"
    UNKNOWN = "UNKNOWN"


# ---------------------------------------------------------------------------
# Feature context for retrieval queries
# ---------------------------------------------------------------------------

@dataclass
class RoadContext:
    """
    Compact road/environment features for matching.
    Derived from existing SituationRecord / WorldModel outputs.
    """
    road_type: str = NOT_AVAILABLE           # VILLAGE_ROAD | URBAN | HIGHWAY | ...
    road_structure: str = NOT_AVAILABLE
    lane_marking_state: str = NOT_AVAILABLE
    intersection_state: str = NOT_AVAILABLE
    road_anomaly_present: bool = False
    road_anomaly_summary: str = NOT_AVAILABLE

    def to_dict(self) -> dict:
        return {
            "road_type": self.road_type,
            "road_structure": self.road_structure,
            "lane_marking_state": self.lane_marking_state,
            "intersection_state": self.intersection_state,
            "road_anomaly_present": self.road_anomaly_present,
            "road_anomaly_summary": self.road_anomaly_summary,
        }


@dataclass
class TrafficContext:
    """
    Compact traffic features for matching.
    """
    traffic_density: str = NOT_AVAILABLE    # LOW | MEDIUM | HIGH | CONGESTED | ...
    traffic_mix: str = NOT_AVAILABLE
    nearby_object_count: int = 0
    vulnerable_road_user_present: bool = False
    cattle_present: bool = False
    object_type_summary: str = NOT_AVAILABLE

    def to_dict(self) -> dict:
        return {
            "traffic_density": self.traffic_density,
            "traffic_mix": self.traffic_mix,
            "nearby_object_count": self.nearby_object_count,
            "vulnerable_road_user_present": self.vulnerable_road_user_present,
            "cattle_present": self.cattle_present,
            "object_type_summary": self.object_type_summary,
        }


@dataclass
class HazardContext:
    """
    Compact hazard features for matching.
    """
    hazard_level: str = NOT_AVAILABLE       # NONE | LOW | MEDIUM | HIGH | CRITICAL
    dominant_hazard: str = NOT_AVAILABLE    # HazardCategory.value
    road_hazard_present: bool = False
    event_types: Tuple[str, ...] = field(default_factory=tuple)

    def to_dict(self) -> dict:
        return {
            "hazard_level": self.hazard_level,
            "dominant_hazard": self.dominant_hazard,
            "road_hazard_present": self.road_hazard_present,
            "event_types": list(self.event_types),
        }


@dataclass
class VehicleContext:
    """
    Compact ego-vehicle state features for matching.
    """
    speed_ms: Optional[float] = None
    is_braking: bool = False
    is_stopped: bool = False
    control_degraded: bool = False

    def to_dict(self) -> dict:
        def _r(v): return round(v, 2) if v is not None else NOT_AVAILABLE
        return {
            "speed_ms": _r(self.speed_ms),
            "is_braking": self.is_braking,
            "is_stopped": self.is_stopped,
            "control_degraded": self.control_degraded,
        }


@dataclass
class PlanningContext:
    """
    Compact planning features for matching.
    """
    action_type: str = NOT_AVAILABLE        # ActionType.value
    replanning_active: bool = False
    planning_degraded: bool = False

    def to_dict(self) -> dict:
        return {
            "action_type": self.action_type,
            "replanning_active": self.replanning_active,
            "planning_degraded": self.planning_degraded,
        }


@dataclass
class SafetyContext:
    """
    Compact safety features for matching.
    Preserves safety authority — never used to override it.
    """
    safety_state: str = NOT_AVAILABLE
    emergency_state: str = NOT_AVAILABLE
    failsafe_state: str = NOT_AVAILABLE
    safety_degraded: bool = False

    def to_dict(self) -> dict:
        return {
            "safety_state": self.safety_state,
            "emergency_state": self.emergency_state,
            "failsafe_state": self.failsafe_state,
            "safety_degraded": self.safety_degraded,
        }


# ---------------------------------------------------------------------------
# Retrieval query
# ---------------------------------------------------------------------------

@dataclass
class ExperienceRetrievalQuery:
    """
    Structured query representing the current driving situation.

    Built from existing pipeline state — no new perception.
    ID: <session_id>-Q<seq:06d>
    """
    query_id: str = NOT_AVAILABLE
    session_id: str = NOT_AVAILABLE
    sequence_id: int = 0
    timestamp: float = 0.0
    schema_version: str = RETRIEVAL_SCHEMA_VERSION

    # Situation classification (from existing reasoning)
    situation_type: str = NOT_AVAILABLE

    # Context features (from existing pipeline outputs)
    road_context: RoadContext = field(default_factory=RoadContext)
    traffic_context: TrafficContext = field(default_factory=TrafficContext)
    hazard_context: HazardContext = field(default_factory=HazardContext)
    vehicle_context: VehicleContext = field(default_factory=VehicleContext)
    planning_context: PlanningContext = field(default_factory=PlanningContext)
    safety_context: SafetyContext = field(default_factory=SafetyContext)

    # Event-type tags for coarse filtering
    event_types: Tuple[str, ...] = field(default_factory=tuple)
    scenario_tags: Tuple[str, ...] = field(default_factory=tuple)

    # Retrieval constraints
    maximum_results: int = 5
    minimum_relevance: float = 0.0        # [0.0, 1.0]
    retrieval_policy: str = RetrievalPolicy.QUALITY_ONLY.value

    def to_dict(self) -> dict:
        return {
            "query_id": self.query_id,
            "session_id": self.session_id,
            "sequence_id": self.sequence_id,
            "timestamp": self.timestamp,
            "schema_version": self.schema_version,
            "situation_type": self.situation_type,
            "road_context": self.road_context.to_dict(),
            "traffic_context": self.traffic_context.to_dict(),
            "hazard_context": self.hazard_context.to_dict(),
            "vehicle_context": self.vehicle_context.to_dict(),
            "planning_context": self.planning_context.to_dict(),
            "safety_context": self.safety_context.to_dict(),
            "event_types": list(self.event_types),
            "scenario_tags": list(self.scenario_tags),
            "maximum_results": self.maximum_results,
            "minimum_relevance": round(self.minimum_relevance, 3),
            "retrieval_policy": self.retrieval_policy,
        }


# ---------------------------------------------------------------------------
# Retrieved experience (one candidate result)
# ---------------------------------------------------------------------------

@dataclass
class RetrievedExperience:
    """
    One retrieved experience, with relevance explanation and outcome info.

    This is a read-only summary — it does NOT modify the stored record.
    It must never be used to directly issue vehicle commands.
    """
    experience_id: str = NOT_AVAILABLE       # ExperienceRecord.record_id
    session_id: str = NOT_AVAILABLE
    experience_timestamp: float = 0.0
    schema_version: str = RETRIEVAL_SCHEMA_VERSION

    # Relevance
    relevance_score: float = 0.0             # [0.0, 1.0]
    match_reasons: Tuple[str, ...] = field(default_factory=tuple)
    mismatch_reasons: Tuple[str, ...] = field(default_factory=tuple)

    # Outcome (from Phase 12.3 evaluation)
    outcome_class: str = NOT_AVAILABLE       # OutcomeClass.value
    outcome_confidence: str = NOT_AVAILABLE  # EvaluationConfidence.value
    outcome_evidence: Tuple[str, ...] = field(default_factory=tuple)

    # Quality
    experience_quality: ExperienceQuality = ExperienceQuality.UNKNOWN
    record_completeness: str = NOT_AVAILABLE  # RecordCompleteness.value

    # Key situation features (compact summary for reasoning context)
    situation_type: str = NOT_AVAILABLE
    road_type: str = NOT_AVAILABLE
    hazard_level: str = NOT_AVAILABLE
    action_type: str = NOT_AVAILABLE
    cattle_present: bool = False
    vru_present: bool = False

    source_schema_version: str = NOT_AVAILABLE  # original record schema

    def to_dict(self) -> dict:
        return {
            "experience_id": self.experience_id,
            "session_id": self.session_id,
            "experience_timestamp": self.experience_timestamp,
            "schema_version": self.schema_version,
            "relevance_score": round(self.relevance_score, 3),
            "match_reasons": list(self.match_reasons),
            "mismatch_reasons": list(self.mismatch_reasons),
            "outcome_class": self.outcome_class,
            "outcome_confidence": self.outcome_confidence,
            "outcome_evidence": list(self.outcome_evidence),
            "experience_quality": self.experience_quality.value,
            "record_completeness": self.record_completeness,
            "situation_type": self.situation_type,
            "road_type": self.road_type,
            "hazard_level": self.hazard_level,
            "action_type": self.action_type,
            "cattle_present": self.cattle_present,
            "vru_present": self.vru_present,
            "source_schema_version": self.source_schema_version,
        }


# ---------------------------------------------------------------------------
# Retrieval result
# ---------------------------------------------------------------------------

@dataclass
class ExperienceRetrievalResult:
    """
    Complete result of one retrieval operation.

    Immutable after construction — retrieval is read-only.
    """
    query_id: str = NOT_AVAILABLE
    result_id: str = NOT_AVAILABLE           # <query_id>-RES
    retrieval_timestamp: float = 0.0
    schema_version: str = RETRIEVAL_SCHEMA_VERSION

    retrieval_status: RetrievalStatus = RetrievalStatus.EMPTY
    total_candidates_scanned: int = 0
    returned_count: int = 0
    is_degraded: bool = False
    failure_reason: str = NOT_AVAILABLE

    # Ordered by relevance (highest first)
    retrieved_experiences: Tuple[RetrievedExperience, ...] = field(
        default_factory=tuple
    )

    def to_dict(self) -> dict:
        return {
            "query_id": self.query_id,
            "result_id": self.result_id,
            "retrieval_timestamp": self.retrieval_timestamp,
            "schema_version": self.schema_version,
            "retrieval_status": self.retrieval_status.value,
            "total_candidates_scanned": self.total_candidates_scanned,
            "returned_count": self.returned_count,
            "is_degraded": self.is_degraded,
            "failure_reason": self.failure_reason,
            "retrieved_experiences": [e.to_dict() for e in self.retrieved_experiences],
        }


# ---------------------------------------------------------------------------
# Experience reuse context — passed to reasoning layer
# ---------------------------------------------------------------------------

@dataclass
class ExperienceReuseContext:
    """
    Safe contextual representation of retrieved experiences for the reasoning layer.

    This is INFORMATIONAL ONLY.
    It must NOT directly issue vehicle commands, paths, or safety overrides.

    The reasoning layer may consider retrieved experiences as evidence,
    but remains fully responsible for current decision formation.
    Safety authority is never transferred to this context.
    """
    context_id: str = NOT_AVAILABLE          # matches query_id
    session_id: str = NOT_AVAILABLE
    timestamp: float = 0.0
    schema_version: str = RETRIEVAL_SCHEMA_VERSION

    retrieval_status: RetrievalStatus = RetrievalStatus.EMPTY
    retrieved_count: int = 0
    is_degraded: bool = False

    # Retrieved experiences (ordered by relevance)
    experiences: Tuple[RetrievedExperience, ...] = field(default_factory=tuple)

    # Summary counts by outcome class (for quick reasoning use)
    success_count: int = 0
    partial_success_count: int = 0
    failure_count: int = 0
    unsafe_count: int = 0

    # Explicit: this context does NOT control the vehicle
    # Callers must not use it to override safety or issue commands.

    def to_dict(self) -> dict:
        return {
            "context_id": self.context_id,
            "session_id": self.session_id,
            "timestamp": self.timestamp,
            "schema_version": self.schema_version,
            "retrieval_status": self.retrieval_status.value,
            "retrieved_count": self.retrieved_count,
            "is_degraded": self.is_degraded,
            "experiences": [e.to_dict() for e in self.experiences],
            "success_count": self.success_count,
            "partial_success_count": self.partial_success_count,
            "failure_count": self.failure_count,
            "unsafe_count": self.unsafe_count,
        }

    @property
    def has_experiences(self) -> bool:
        return len(self.experiences) > 0

    @property
    def best_experience(self) -> Optional[RetrievedExperience]:
        """Highest-relevance retrieved experience, or None."""
        return self.experiences[0] if self.experiences else None


# ---------------------------------------------------------------------------
# Retrieval configuration
# ---------------------------------------------------------------------------

@dataclass
class ExperienceRetrievalConfig:
    """
    Conservative, deterministic configuration for the retrieval layer.

    Uses the project's existing configuration style.
    """
    enabled: bool = True
    max_results: int = 5
    minimum_relevance: float = 0.0           # [0.0, 1.0]
    minimum_quality: ExperienceQuality = ExperienceQuality.LOW
    minimum_outcome_confidence: str = "LOW"  # EvaluationConfidence.value

    # Outcome class filters
    include_partial: bool = True
    include_degraded: bool = False
    include_inconclusive: bool = False
    include_failures: bool = True
    include_unsafe: bool = True

    # Default retrieval policy
    retrieval_policy: RetrievalPolicy = RetrievalPolicy.QUALITY_ONLY

    # Temporal decay: reduce relevance of older experiences
    # Set to 0.0 to disable. Expressed as fraction per 3600s (1 hour).
    temporal_decay_per_hour: float = 0.0

    # Maximum experience age to consider (seconds); 0 = no limit
    max_experience_age_s: float = 0.0

    @staticmethod
    def default() -> "ExperienceRetrievalConfig":
        return ExperienceRetrievalConfig()

    def to_dict(self) -> dict:
        return {
            "enabled": self.enabled,
            "max_results": self.max_results,
            "minimum_relevance": self.minimum_relevance,
            "minimum_quality": self.minimum_quality.value,
            "minimum_outcome_confidence": self.minimum_outcome_confidence,
            "include_partial": self.include_partial,
            "include_degraded": self.include_degraded,
            "include_inconclusive": self.include_inconclusive,
            "include_failures": self.include_failures,
            "include_unsafe": self.include_unsafe,
            "retrieval_policy": self.retrieval_policy.value,
            "temporal_decay_per_hour": self.temporal_decay_per_hour,
            "max_experience_age_s": self.max_experience_age_s,
        }


__all__ = [
    "NOT_AVAILABLE",
    "RETRIEVAL_SCHEMA_VERSION",
    "RetrievalStatus",
    "RetrievalPolicy",
    "ExperienceQuality",
    "RoadContext",
    "TrafficContext",
    "HazardContext",
    "VehicleContext",
    "PlanningContext",
    "SafetyContext",
    "ExperienceRetrievalQuery",
    "RetrievedExperience",
    "ExperienceRetrievalResult",
    "ExperienceReuseContext",
    "ExperienceRetrievalConfig",
]
