"""
IndiDrive AI — Phase 12.4 | Relevance Scorer
=============================================
Deterministic, inspectable relevance scoring for experience retrieval.

Design:
    * Fully deterministic: same query + same candidate → same score
    * No opaque scores: every component is documented and named
    * Composable: each dimension returns (score, reasons, mismatches)
    * No LLM, no embeddings, no cloud
    * Offline-first

Score breakdown:

    road_context_score      — road type, structure, intersection (weight: 0.20)
    traffic_context_score   — density, VRU, cattle             (weight: 0.20)
    hazard_context_score    — hazard level, hazard type        (weight: 0.25)
    vehicle_context_score   — speed band, braking state        (weight: 0.10)
    planning_context_score  — action type match                (weight: 0.15)
    safety_context_score    — safety/emergency/failsafe state  (weight: 0.10)

    total = weighted sum, clamped to [0.0, 1.0]

Temporal decay (optional, configurable):
    decayed_score = score * exp(-decay_rate * age_hours)

    decay_rate = temporal_decay_per_hour / ln(2)
    age_hours  = (query_timestamp - experience_timestamp) / 3600

    At decay_rate=0.0, no decay is applied.
"""
from __future__ import annotations

import math
from typing import List, Tuple

from .retrieval_types import (
    NOT_AVAILABLE,
    ExperienceRetrievalConfig,
    ExperienceRetrievalQuery,
    HazardContext,
    PlanningContext,
    RetrievedExperience,
    RoadContext,
    SafetyContext,
    TrafficContext,
    VehicleContext,
)

__all__ = ["RelevanceScorer", "ScoringWeights"]

# ---------------------------------------------------------------------------
# Scoring weights — all documented; must sum to 1.0
# ---------------------------------------------------------------------------

ROAD_WEIGHT     = 0.20
TRAFFIC_WEIGHT  = 0.20
HAZARD_WEIGHT   = 0.25
VEHICLE_WEIGHT  = 0.10
PLANNING_WEIGHT = 0.15
SAFETY_WEIGHT   = 0.10
_WEIGHT_SUM     = ROAD_WEIGHT + TRAFFIC_WEIGHT + HAZARD_WEIGHT + \
                  VEHICLE_WEIGHT + PLANNING_WEIGHT + SAFETY_WEIGHT
assert abs(_WEIGHT_SUM - 1.0) < 1e-9, "Weights must sum to 1.0"


class ScoringWeights:
    """Named, inspectable scoring weights."""
    road     = ROAD_WEIGHT
    traffic  = TRAFFIC_WEIGHT
    hazard   = HAZARD_WEIGHT
    vehicle  = VEHICLE_WEIGHT
    planning = PLANNING_WEIGHT
    safety   = SAFETY_WEIGHT


def _upper(v: str) -> str:
    if not v or v == NOT_AVAILABLE:
        return ""
    return str(v).upper()


def _match(a: str, b: str) -> bool:
    ua, ub = _upper(a), _upper(b)
    return bool(ua and ub and ua == ub)


def _available(v: str) -> bool:
    return bool(v and v != NOT_AVAILABLE)


# ---------------------------------------------------------------------------
# Per-dimension scoring
# ---------------------------------------------------------------------------

def _score_road(
    q: RoadContext,
    c: RoadContext,
) -> Tuple[float, List[str], List[str]]:
    """
    Score road context match.

    Points: road_type (0.5), road_structure (0.3), intersection_state (0.2)
    """
    score = 0.0
    match: List[str] = []
    miss: List[str] = []

    if _available(q.road_type) and _available(c.road_type):
        if _match(q.road_type, c.road_type):
            score += 0.5
            match.append(f"road_type:{q.road_type}")
        else:
            miss.append(f"road_type:{q.road_type}!={c.road_type}")
    elif not _available(c.road_type):
        score += 0.1  # small bonus for not conflicting

    if _available(q.road_structure) and _available(c.road_structure):
        if _match(q.road_structure, c.road_structure):
            score += 0.3
            match.append(f"road_structure:{q.road_structure}")
        else:
            miss.append(f"road_structure:{q.road_structure}!={c.road_structure}")

    if _available(q.intersection_state) and _available(c.intersection_state):
        if _match(q.intersection_state, c.intersection_state):
            score += 0.2
            match.append(f"intersection:{q.intersection_state}")
        else:
            miss.append(f"intersection:{q.intersection_state}!={c.intersection_state}")

    return min(score, 1.0), match, miss


def _score_traffic(
    q: TrafficContext,
    c: TrafficContext,
) -> Tuple[float, List[str], List[str]]:
    """
    Score traffic context match.

    Points: cattle (0.40), vru (0.30), traffic_density (0.30)
    """
    score = 0.0
    match: List[str] = []
    miss: List[str] = []

    # Cattle is high-signal for Indian roads
    if q.cattle_present == c.cattle_present:
        score += 0.40
        match.append(f"cattle_present:{q.cattle_present}")
    else:
        miss.append(f"cattle_present:{q.cattle_present}!={c.cattle_present}")

    # VRU
    if q.vulnerable_road_user_present == c.vulnerable_road_user_present:
        score += 0.30
        match.append(f"vru_present:{q.vulnerable_road_user_present}")
    else:
        miss.append(f"vru_present:{q.vulnerable_road_user_present}!={c.vulnerable_road_user_present}")

    # Traffic density
    if _available(q.traffic_density) and _available(c.traffic_density):
        if _match(q.traffic_density, c.traffic_density):
            score += 0.30
            match.append(f"traffic_density:{q.traffic_density}")
        else:
            # Partial credit for adjacent density levels
            adj = _adjacent_density(q.traffic_density, c.traffic_density)
            if adj:
                score += 0.10
                match.append(f"traffic_density~:{q.traffic_density}")
            else:
                miss.append(f"traffic_density:{q.traffic_density}!={c.traffic_density}")

    return min(score, 1.0), match, miss


_DENSITY_ORDER = ["NONE", "LOW", "MEDIUM", "HIGH", "CONGESTED", "STOP_AND_GO"]


def _adjacent_density(a: str, b: str) -> bool:
    """True when traffic density values are one step apart."""
    ua, ub = _upper(a), _upper(b)
    try:
        ia = _DENSITY_ORDER.index(ua)
        ib = _DENSITY_ORDER.index(ub)
        return abs(ia - ib) == 1
    except ValueError:
        return False


def _score_hazard(
    q: HazardContext,
    c: HazardContext,
) -> Tuple[float, List[str], List[str]]:
    """
    Score hazard context match.

    Points: hazard_level (0.40), dominant_hazard (0.35), road_hazard_present (0.25)
    """
    score = 0.0
    match: List[str] = []
    miss: List[str] = []

    if _available(q.hazard_level) and _available(c.hazard_level):
        if _match(q.hazard_level, c.hazard_level):
            score += 0.40
            match.append(f"hazard_level:{q.hazard_level}")
        else:
            # Adjacent hazard level gives partial credit
            adj = _adjacent_hazard(q.hazard_level, c.hazard_level)
            if adj:
                score += 0.15
                match.append(f"hazard_level~:{q.hazard_level}")
            else:
                miss.append(f"hazard_level:{q.hazard_level}!={c.hazard_level}")

    if _available(q.dominant_hazard) and _available(c.dominant_hazard):
        if _match(q.dominant_hazard, c.dominant_hazard):
            score += 0.35
            match.append(f"dominant_hazard:{q.dominant_hazard}")
        else:
            miss.append(f"dominant_hazard:{q.dominant_hazard}!={c.dominant_hazard}")

    if q.road_hazard_present == c.road_hazard_present:
        score += 0.25
        match.append(f"road_hazard_present:{q.road_hazard_present}")
    else:
        miss.append(f"road_hazard_present:{q.road_hazard_present}!={c.road_hazard_present}")

    return min(score, 1.0), match, miss


_HAZARD_ORDER = ["NONE", "LOW", "MEDIUM", "HIGH", "CRITICAL"]


def _adjacent_hazard(a: str, b: str) -> bool:
    ua, ub = _upper(a), _upper(b)
    try:
        ia = _HAZARD_ORDER.index(ua)
        ib = _HAZARD_ORDER.index(ub)
        return abs(ia - ib) == 1
    except ValueError:
        return False


def _score_vehicle(
    q: VehicleContext,
    c: VehicleContext,
) -> Tuple[float, List[str], List[str]]:
    """
    Score vehicle state match.

    Points: speed_band (0.40), braking (0.30), stopped (0.30)
    """
    score = 0.0
    match: List[str] = []
    miss: List[str] = []

    # Speed band comparison (±5 m/s = same band)
    if q.speed_ms is not None and c.speed_ms is not None:
        if abs(q.speed_ms - c.speed_ms) <= 5.0:
            score += 0.40
            match.append(f"speed_band:~{q.speed_ms:.1f}ms")
        else:
            miss.append(f"speed_ms:{q.speed_ms:.1f}!={c.speed_ms:.1f}")

    # Braking state
    if q.is_braking == c.is_braking:
        score += 0.30
        match.append(f"is_braking:{q.is_braking}")
    else:
        miss.append(f"is_braking:{q.is_braking}!={c.is_braking}")

    # Stopped state
    if q.is_stopped == c.is_stopped:
        score += 0.30
        match.append(f"is_stopped:{q.is_stopped}")
    else:
        miss.append(f"is_stopped:{q.is_stopped}!={c.is_stopped}")

    return min(score, 1.0), match, miss


def _score_planning(
    q: PlanningContext,
    c: PlanningContext,
) -> Tuple[float, List[str], List[str]]:
    """
    Score planning context match.

    Points: action_type (0.70), replanning_active (0.30)
    """
    score = 0.0
    match: List[str] = []
    miss: List[str] = []

    if _available(q.action_type) and _available(c.action_type):
        if _match(q.action_type, c.action_type):
            score += 0.70
            match.append(f"action_type:{q.action_type}")
        else:
            miss.append(f"action_type:{q.action_type}!={c.action_type}")

    if q.replanning_active == c.replanning_active:
        score += 0.30
        match.append(f"replanning_active:{q.replanning_active}")
    else:
        miss.append(f"replanning_active:{q.replanning_active}!={c.replanning_active}")

    return min(score, 1.0), match, miss


def _score_safety(
    q: SafetyContext,
    c: SafetyContext,
) -> Tuple[float, List[str], List[str]]:
    """
    Score safety context match.

    Points: safety_state (0.40), emergency_state (0.35), failsafe_state (0.25)
    """
    score = 0.0
    match: List[str] = []
    miss: List[str] = []

    if _available(q.safety_state) and _available(c.safety_state):
        if _match(q.safety_state, c.safety_state):
            score += 0.40
            match.append(f"safety_state:{q.safety_state}")
        else:
            miss.append(f"safety_state:{q.safety_state}!={c.safety_state}")

    if _available(q.emergency_state) and _available(c.emergency_state):
        if _match(q.emergency_state, c.emergency_state):
            score += 0.35
            match.append(f"emergency_state:{q.emergency_state}")
        else:
            miss.append(f"emergency_state:{q.emergency_state}!={c.emergency_state}")

    if _available(q.failsafe_state) and _available(c.failsafe_state):
        if _match(q.failsafe_state, c.failsafe_state):
            score += 0.25
            match.append(f"failsafe_state:{q.failsafe_state}")
        else:
            miss.append(f"failsafe_state:{q.failsafe_state}!={c.failsafe_state}")

    return min(score, 1.0), match, miss


# ---------------------------------------------------------------------------
# Temporal decay
# ---------------------------------------------------------------------------

def _apply_temporal_decay(
    score: float,
    query_timestamp: float,
    experience_timestamp: float,
    decay_per_hour: float,
    max_age_s: float,
) -> float:
    """
    Apply deterministic exponential temporal decay.

    decayed = score * exp(-decay_rate * age_hours)

    At decay_per_hour=0.0, no decay.
    At max_age_s>0, experiences older than max_age_s get score 0.0.
    """
    if decay_per_hour <= 0.0 and max_age_s <= 0.0:
        return score

    age_s = query_timestamp - experience_timestamp
    if age_s < 0:
        age_s = 0.0

    if max_age_s > 0.0 and age_s > max_age_s:
        return 0.0

    if decay_per_hour > 0.0:
        age_hours = age_s / 3600.0
        # decay_rate in natural-log space
        decay_rate = decay_per_hour
        decayed = score * math.exp(-decay_rate * age_hours)
        return max(0.0, decayed)

    return score


# ---------------------------------------------------------------------------
# Scorer
# ---------------------------------------------------------------------------

class RelevanceScorer:
    """
    Deterministic feature-based relevance scorer.

    Scores a candidate ExperienceRecord against a query.
    Returns a score in [0.0, 1.0] plus human-readable match/mismatch reasons.

    Usage
    -----
    scorer = RelevanceScorer(cfg)
    score, matches, mismatches = scorer.score(
        query,
        candidate_road_ctx,
        candidate_traffic_ctx,
        candidate_hazard_ctx,
        candidate_vehicle_ctx,
        candidate_planning_ctx,
        candidate_safety_ctx,
        candidate_timestamp,
    )
    """

    def __init__(self, cfg: ExperienceRetrievalConfig) -> None:
        self._cfg = cfg

    def score(
        self,
        query: ExperienceRetrievalQuery,
        cand_road: RoadContext,
        cand_traffic: TrafficContext,
        cand_hazard: HazardContext,
        cand_vehicle: VehicleContext,
        cand_planning: PlanningContext,
        cand_safety: SafetyContext,
        cand_timestamp: float,
    ) -> Tuple[float, List[str], List[str]]:
        """
        Compute relevance score between query and candidate context features.

        Returns (score, match_reasons, mismatch_reasons).
        Score is in [0.0, 1.0].
        Deterministic for fixed inputs.
        """
        all_match: List[str] = []
        all_miss: List[str] = []

        s_road,     m_road,     x_road     = _score_road(query.road_context, cand_road)
        s_traffic,  m_traffic,  x_traffic  = _score_traffic(query.traffic_context, cand_traffic)
        s_hazard,   m_hazard,   x_hazard   = _score_hazard(query.hazard_context, cand_hazard)
        s_vehicle,  m_vehicle,  x_vehicle  = _score_vehicle(query.vehicle_context, cand_vehicle)
        s_planning, m_planning, x_planning = _score_planning(query.planning_context, cand_planning)
        s_safety,   m_safety,   x_safety   = _score_safety(query.safety_context, cand_safety)

        all_match.extend(m_road)
        all_match.extend(m_traffic)
        all_match.extend(m_hazard)
        all_match.extend(m_vehicle)
        all_match.extend(m_planning)
        all_match.extend(m_safety)

        all_miss.extend(x_road)
        all_miss.extend(x_traffic)
        all_miss.extend(x_hazard)
        all_miss.extend(x_vehicle)
        all_miss.extend(x_planning)
        all_miss.extend(x_safety)

        raw_score = (
            s_road     * ROAD_WEIGHT
            + s_traffic  * TRAFFIC_WEIGHT
            + s_hazard   * HAZARD_WEIGHT
            + s_vehicle  * VEHICLE_WEIGHT
            + s_planning * PLANNING_WEIGHT
            + s_safety   * SAFETY_WEIGHT
        )
        raw_score = min(max(raw_score, 0.0), 1.0)

        # Apply temporal decay
        final_score = _apply_temporal_decay(
            raw_score,
            query.timestamp,
            cand_timestamp,
            self._cfg.temporal_decay_per_hour,
            self._cfg.max_experience_age_s,
        )
        final_score = round(min(max(final_score, 0.0), 1.0), 4)

        return final_score, all_match, all_miss
