"""
IndiDrive AI — Phase 12.4 | Experience Retrieval
=================================================
Public API for the Phase 12.4 experience retrieval layer.

Phase 12.4 retrieves previously evaluated experiences — it does NOT:
  - update knowledge or policies         → Phase 12.5
  - improve future decisions             → Phase 12.6
  - generate RL reward                   → Phase 12.6
  - control the vehicle                  → pipeline
  - override safety decisions            → safety subsystems
  - require internet, cloud, or LLM
  - use external vector databases
"""

from .retrieval_types import (
    NOT_AVAILABLE,
    RETRIEVAL_SCHEMA_VERSION,
    RetrievalStatus,
    RetrievalPolicy,
    ExperienceQuality,
    RoadContext,
    TrafficContext,
    HazardContext,
    VehicleContext,
    PlanningContext,
    SafetyContext,
    ExperienceRetrievalQuery,
    RetrievedExperience,
    ExperienceRetrievalResult,
    ExperienceReuseContext,
    ExperienceRetrievalConfig,
)
from .feature_extractor import FeatureExtractor
from .relevance_scorer import RelevanceScorer, ScoringWeights
from .experience_index import ExperienceIndex, IndexEntry
from .experience_retriever import ExperienceRetriever
from .retrieval_validator import RetrievalValidator

__all__ = [
    "NOT_AVAILABLE",
    "RETRIEVAL_SCHEMA_VERSION",
    "RetrievalStatus",
    "RetrievalPolicy",
    "ExperienceQuality",
    "RoadContext",
    "TrafficContext",
    "HazardContext",
    "VehicleContext",
    "PlanningContext",
    "SafetyContext",
    "ExperienceRetrievalQuery",
    "RetrievedExperience",
    "ExperienceRetrievalResult",
    "ExperienceReuseContext",
    "ExperienceRetrievalConfig",
    "FeatureExtractor",
    "RelevanceScorer",
    "ScoringWeights",
    "ExperienceIndex",
    "IndexEntry",
    "ExperienceRetriever",
    "RetrievalValidator",
]
