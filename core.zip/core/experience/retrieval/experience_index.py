"""
IndiDrive AI — Phase 12.4 | Experience Index
=============================================
Deterministic in-memory index over evaluated experiences.

The index combines:
    - Phase 12.1/12.2 ExperienceRecord (situation, action, outcome)
    - Phase 12.3 OutcomeEvaluationSnapshot

Indexed dimensions (for coarse filtering before scoring):
    - outcome_class
    - session_id
    - road_type
    - hazard_level
    - cattle_present
    - vru_present
    - action_type
    - event_type (triggering)

Design:
    * Read-only access to stored records — never modifies them
    * Bounded by max_index_size (FIFO)
    * Thread-safe
    * Deterministic: same state → same iteration order
    * No external dependencies
"""
from __future__ import annotations

import threading
from dataclasses import dataclass, field
from typing import Dict, FrozenSet, List, Optional, Set, Tuple

from core.experience.record.record_types import (
    NOT_AVAILABLE,
    ExperienceRecord,
    RecordCompleteness,
)
from core.experience.evaluation.evaluation_types import (
    EvaluationConfidence,
    EvaluationStatus,
    OutcomeClass,
    OutcomeEvaluationSnapshot,
)

from .retrieval_types import (
    RETRIEVAL_SCHEMA_VERSION,
    ExperienceQuality,
    ExperienceRetrievalConfig,
    RetrievalPolicy,
)
from .feature_extractor import FeatureExtractor

__all__ = ["ExperienceIndex", "IndexEntry"]

_EXT = FeatureExtractor()

# Quality confidence mapping
_CONF_QUALITY = {
    "HIGH":    ExperienceQuality.HIGH,
    "MEDIUM":  ExperienceQuality.MEDIUM,
    "LOW":     ExperienceQuality.LOW,
    "UNKNOWN": ExperienceQuality.UNKNOWN,
}

# Minimum quality ordinal for filtering
_QUALITY_ORD = {
    ExperienceQuality.UNKNOWN: 0,
    ExperienceQuality.LOW:     1,
    ExperienceQuality.MEDIUM:  2,
    ExperienceQuality.HIGH:    3,
}

# Outcome classes allowed by each policy
_POLICY_CLASSES: Dict[RetrievalPolicy, FrozenSet[str]] = {
    RetrievalPolicy.QUALITY_ONLY: frozenset({
        OutcomeClass.SUCCESS.value,
        OutcomeClass.PARTIAL_SUCCESS.value,
    }),
    RetrievalPolicy.ALL_EVALUATED: frozenset({
        OutcomeClass.SUCCESS.value,
        OutcomeClass.PARTIAL_SUCCESS.value,
        OutcomeClass.FAILURE.value,
        OutcomeClass.UNSAFE_OUTCOME.value,
        OutcomeClass.DEGRADED.value,
        OutcomeClass.INCONCLUSIVE.value,
        OutcomeClass.NO_OUTCOME.value,
    }),
    RetrievalPolicy.ALL_COMPLETED: frozenset({
        OutcomeClass.SUCCESS.value,
        OutcomeClass.PARTIAL_SUCCESS.value,
        OutcomeClass.FAILURE.value,
        OutcomeClass.UNSAFE_OUTCOME.value,
        OutcomeClass.DEGRADED.value,
        OutcomeClass.INCONCLUSIVE.value,
        OutcomeClass.NO_OUTCOME.value,
        OutcomeClass.NOT_EVALUATED.value,
    }),
    RetrievalPolicy.CUSTOM: frozenset(),  # governed by include_* flags
}


# ---------------------------------------------------------------------------
# Index entry
# ---------------------------------------------------------------------------

@dataclass
class IndexEntry:
    """
    One entry in the ExperienceIndex.

    Stores both pre-extracted features (for fast filtering) and
    references to the original record + evaluation for scoring.

    All fields are read-only (frozen after construction).
    """
    experience_id: str
    session_id: str
    experience_timestamp: float

    # Pre-extracted coarse features for filtering
    road_type: str
    hazard_level: str
    traffic_density: str
    cattle_present: bool
    vru_present: bool
    action_type: str
    event_type: str          # triggering event type

    # Evaluation data
    outcome_class: str       # OutcomeClass.value
    outcome_confidence: str  # EvaluationConfidence.value
    outcome_evidence: Tuple[str, ...]
    evaluation_valid: bool

    # Quality
    quality: ExperienceQuality
    record_completeness: str

    # Full feature contexts (for scoring)
    road_context: object     # RoadContext
    traffic_context: object  # TrafficContext
    hazard_context: object   # HazardContext
    vehicle_context: object  # VehicleContext
    planning_context: object # PlanningContext
    safety_context: object   # SafetyContext

    # Situation summary
    situation_type: str
    source_schema_version: str

    # Insertion sequence (for deterministic tie-breaking)
    insertion_seq: int = 0


# ---------------------------------------------------------------------------
# Index
# ---------------------------------------------------------------------------

class ExperienceIndex:
    """
    Bounded, deterministic in-memory index of evaluated experiences.

    Usage
    -----
    index = ExperienceIndex(max_size=1000)
    index.add(record, evaluation_snapshot)
    entries = index.query_candidates(cfg, policy)
    """

    def __init__(self, max_size: int = 1000) -> None:
        if max_size < 1:
            raise ValueError(f"max_size must be >=1, got {max_size}")
        self._max = max_size
        self._lock = threading.Lock()
        self._entries: Dict[str, IndexEntry] = {}   # keyed by experience_id
        self._order: List[str] = []                 # insertion order (FIFO)
        self._seq: int = 0

    # ------------------------------------------------------------------
    # Write

    def add(
        self,
        record: ExperienceRecord,
        evaluation: Optional[OutcomeEvaluationSnapshot],
    ) -> bool:
        """
        Add or update one experience in the index.

        Returns True on success.
        Does NOT modify record or evaluation.
        """
        if record is None:
            return False
        try:
            entry = self._make_entry(record, evaluation)
            with self._lock:
                if entry.experience_id in self._entries:
                    # Update in place (keep insertion order)
                    old_seq = self._entries[entry.experience_id].insertion_seq
                    entry = IndexEntry(
                        **{**entry.__dict__, "insertion_seq": old_seq}
                    )
                    self._entries[entry.experience_id] = entry
                else:
                    # FIFO eviction if at capacity
                    if len(self._entries) >= self._max:
                        oldest = self._order.pop(0)
                        self._entries.pop(oldest, None)
                    entry = IndexEntry(
                        **{**entry.__dict__, "insertion_seq": self._seq}
                    )
                    self._seq += 1
                    self._order.append(entry.experience_id)
                    self._entries[entry.experience_id] = entry
            return True
        except Exception:  # pylint: disable=broad-except
            return False

    def remove(self, experience_id: str) -> bool:
        """Remove one experience from the index."""
        with self._lock:
            if experience_id in self._entries:
                self._entries.pop(experience_id)
                try:
                    self._order.remove(experience_id)
                except ValueError:
                    pass
                return True
        return False

    # ------------------------------------------------------------------
    # Read

    def get(self, experience_id: str) -> Optional[IndexEntry]:
        with self._lock:
            return self._entries.get(experience_id)

    def size(self) -> int:
        with self._lock:
            return len(self._entries)

    def query_candidates(
        self,
        cfg: ExperienceRetrievalConfig,
        policy: RetrievalPolicy,
    ) -> List[IndexEntry]:
        """
        Return all candidates that pass policy + config filters.

        Returns a new list sorted by insertion_seq (oldest first) for
        deterministic downstream processing.
        No scoring is applied here — that is the scorer's job.
        """
        with self._lock:
            all_entries = [self._entries[eid] for eid in self._order
                           if eid in self._entries]

        allowed_classes = self._allowed_classes(policy, cfg)
        min_quality_ord = _QUALITY_ORD.get(cfg.minimum_quality, 0)

        results: List[IndexEntry] = []
        for entry in all_entries:
            # Outcome class filter
            if entry.outcome_class not in allowed_classes:
                continue
            # Individual include_* flag filters
            if not self._passes_include_flags(entry, cfg):
                continue
            # Quality filter
            entry_q_ord = _QUALITY_ORD.get(entry.quality, 0)
            if entry_q_ord < min_quality_ord:
                continue
            results.append(entry)

        # Sort by insertion_seq for deterministic ordering
        results.sort(key=lambda e: e.insertion_seq)
        return results

    # ------------------------------------------------------------------
    # Helpers

    @staticmethod
    def _allowed_classes(
        policy: RetrievalPolicy,
        cfg: ExperienceRetrievalConfig,
    ) -> Set[str]:
        """Return the set of allowed outcome class values for policy+cfg."""
        if policy == RetrievalPolicy.CUSTOM:
            allowed: Set[str] = {
                OutcomeClass.SUCCESS.value,
            }
            if cfg.include_partial:
                allowed.add(OutcomeClass.PARTIAL_SUCCESS.value)
            if cfg.include_failures:
                allowed.add(OutcomeClass.FAILURE.value)
            if cfg.include_unsafe:
                allowed.add(OutcomeClass.UNSAFE_OUTCOME.value)
            if cfg.include_degraded:
                allowed.add(OutcomeClass.DEGRADED.value)
            if cfg.include_inconclusive:
                allowed.add(OutcomeClass.INCONCLUSIVE.value)
            return allowed

        base = _POLICY_CLASSES.get(policy, frozenset())
        # Apply include_* restrictions on top of policy
        restricted: Set[str] = set()
        for cls_val in base:
            if cls_val == OutcomeClass.PARTIAL_SUCCESS.value and not cfg.include_partial:
                continue
            if cls_val == OutcomeClass.FAILURE.value and not cfg.include_failures:
                continue
            if cls_val == OutcomeClass.UNSAFE_OUTCOME.value and not cfg.include_unsafe:
                continue
            if cls_val == OutcomeClass.DEGRADED.value and not cfg.include_degraded:
                continue
            if cls_val == OutcomeClass.INCONCLUSIVE.value and not cfg.include_inconclusive:
                continue
            restricted.add(cls_val)
        return restricted

    @staticmethod
    def _passes_include_flags(entry: IndexEntry, cfg: ExperienceRetrievalConfig) -> bool:
        oc = entry.outcome_class
        if oc == OutcomeClass.PARTIAL_SUCCESS.value and not cfg.include_partial:
            return False
        if oc == OutcomeClass.FAILURE.value and not cfg.include_failures:
            return False
        if oc == OutcomeClass.UNSAFE_OUTCOME.value and not cfg.include_unsafe:
            return False
        if oc == OutcomeClass.DEGRADED.value and not cfg.include_degraded:
            return False
        if oc == OutcomeClass.INCONCLUSIVE.value and not cfg.include_inconclusive:
            return False
        return True

    def _make_entry(
        self,
        record: ExperienceRecord,
        evaluation: Optional[OutcomeEvaluationSnapshot],
    ) -> IndexEntry:
        sit = record.situation if record else None
        act = record.action if record else None
        exp_id = record.record_id if record else NOT_AVAILABLE
        sess_id = record.session_id if record else NOT_AVAILABLE
        ts = sit.timestamp if sit else 0.0

        # Feature contexts
        road_ctx  = _EXT.road_context_from_situation(sit)
        traf_ctx  = _EXT.traffic_context_from_situation(sit)
        haz_ctx   = _EXT.hazard_context_from_situation(sit)
        veh_ctx   = _EXT.vehicle_context_from_situation(sit)
        plan_ctx  = _EXT.planning_context_from_action(act)
        safe_ctx  = _EXT.safety_context_from_situation(sit)

        # Coarse filter fields
        road_type = sit.road_type if sit else NOT_AVAILABLE
        hazard_level = sit.hazard_level if sit else NOT_AVAILABLE
        traffic_density = sit.traffic_density if sit else NOT_AVAILABLE
        cattle = bool(sit.cattle_present) if sit else False
        vru = bool(sit.vulnerable_road_user_present) if sit else False
        evt = sit.triggering_event_type if sit else NOT_AVAILABLE
        sit_type = sit.situation_type if sit else NOT_AVAILABLE
        at = NOT_AVAILABLE
        if act and act.requested and act.requested.action_type:
            at = act.requested.action_type.value

        # Evaluation
        out_class = OutcomeClass.NOT_EVALUATED.value
        out_conf = EvaluationConfidence.UNKNOWN.value
        out_ev: Tuple[str, ...] = ()
        eval_valid = False
        quality = ExperienceQuality.UNKNOWN

        if evaluation is not None:
            out_class = evaluation.outcome_class.value
            out_conf = evaluation.confidence.value
            out_ev = evaluation.evidence
            eval_valid = evaluation.evaluation_status == EvaluationStatus.COMPLETE
            quality = _conf_to_quality(evaluation.confidence, record)

        rec_comp = (record.completeness.value
                    if record and record.completeness else NOT_AVAILABLE)
        src_schema = (record.schema_version
                      if record else NOT_AVAILABLE)

        return IndexEntry(
            experience_id=exp_id,
            session_id=sess_id,
            experience_timestamp=ts,
            road_type=road_type or NOT_AVAILABLE,
            hazard_level=hazard_level or NOT_AVAILABLE,
            traffic_density=traffic_density or NOT_AVAILABLE,
            cattle_present=cattle,
            vru_present=vru,
            action_type=at or NOT_AVAILABLE,
            event_type=evt or NOT_AVAILABLE,
            outcome_class=out_class,
            outcome_confidence=out_conf,
            outcome_evidence=out_ev,
            evaluation_valid=eval_valid,
            quality=quality,
            record_completeness=rec_comp,
            road_context=road_ctx,
            traffic_context=traf_ctx,
            hazard_context=haz_ctx,
            vehicle_context=veh_ctx,
            planning_context=plan_ctx,
            safety_context=safe_ctx,
            situation_type=sit_type or NOT_AVAILABLE,
            source_schema_version=src_schema or NOT_AVAILABLE,
            insertion_seq=0,  # assigned by add()
        )


def _conf_to_quality(
    conf: EvaluationConfidence,
    record: ExperienceRecord,
) -> ExperienceQuality:
    """Map evaluation confidence + record completeness to ExperienceQuality."""
    from core.experience.record.record_types import RecordCompleteness
    is_complete = (record is not None
                   and record.completeness == RecordCompleteness.COMPLETE)
    conf_val = conf.value if conf else "UNKNOWN"

    if conf_val == "HIGH" and is_complete:
        return ExperienceQuality.HIGH
    if conf_val in ("HIGH", "MEDIUM") and is_complete:
        return ExperienceQuality.MEDIUM
    if conf_val in ("HIGH", "MEDIUM"):
        return ExperienceQuality.LOW
    if conf_val == "LOW":
        return ExperienceQuality.LOW
    return ExperienceQuality.UNKNOWN
