"""
IndiDrive AI — Phase 12.4 | Experience Retriever
=================================================
Main retrieval engine: takes a query, searches the index, ranks and
filters candidates, and returns an ExperienceRetrievalResult.

Architecture:

    ExperienceRetrievalQuery
            ↓
    ExperienceIndex.query_candidates()   ← coarse filter by policy/quality
            ↓
    RelevanceScorer.score()              ← deterministic feature scoring
            ↓
    Filter by minimum_relevance
            ↓
    Sort by relevance (desc); deterministic tie-break by experience_id
            ↓
    Top-k selection
            ↓
    ExperienceRetrievalResult

Invariants:
    * Deterministic: same query + same index state → same result
    * Read-only: never modifies stored records or evaluations
    * Failure-isolated: exceptions → degraded result, pipeline unaffected
    * No vehicle control, no safety override, no policy learning
    * No LLM, no cloud, no internet
    * Safety authority is never transferred to this layer

Tie-breaking rule:
    When two candidates share the same relevance_score:
        1. Higher outcome_class quality wins
           (SUCCESS > PARTIAL_SUCCESS > FAILURE > ...)
        2. Earlier insertion_seq wins (older, more established experience)
        3. experience_id lexicographic order (deterministic final fallback)
"""
from __future__ import annotations

import time
from typing import List, Optional, Tuple

from core.experience.record.record_types import (
    NOT_AVAILABLE,
    ExperienceRecord,
)
from core.experience.evaluation.evaluation_types import (
    OutcomeClass,
    OutcomeEvaluationSnapshot,
)

from .retrieval_types import (
    RETRIEVAL_SCHEMA_VERSION,
    ExperienceQuality,
    ExperienceRetrievalConfig,
    ExperienceRetrievalQuery,
    ExperienceRetrievalResult,
    ExperienceReuseContext,
    RetrievalPolicy,
    RetrievalStatus,
    RetrievedExperience,
)
from .experience_index import ExperienceIndex, IndexEntry
from .feature_extractor import FeatureExtractor
from .relevance_scorer import RelevanceScorer

__all__ = ["ExperienceRetriever"]

# Outcome class quality order for tie-breaking (higher = better)
_OUTCOME_QUALITY_ORD = {
    OutcomeClass.SUCCESS.value:         5,
    OutcomeClass.PARTIAL_SUCCESS.value: 4,
    OutcomeClass.FAILURE.value:         3,
    OutcomeClass.UNSAFE_OUTCOME.value:  2,
    OutcomeClass.DEGRADED.value:        2,
    OutcomeClass.INCONCLUSIVE.value:    1,
    OutcomeClass.NO_OUTCOME.value:      1,
    OutcomeClass.NOT_EVALUATED.value:   0,
    OutcomeClass.INVALID.value:         0,
}


def _make_result_id(query_id: str) -> str:
    return f"{query_id}-RES"


class ExperienceRetriever:
    """
    Deterministic, failure-isolated experience retrieval engine.

    Usage
    -----
    index     = ExperienceIndex()
    retriever = ExperienceRetriever(index, cfg)

    # Build index from Phase 12.1/12.2/12.3 stores
    retriever.index_experience(record, evaluation_snapshot)

    # Retrieve for current situation
    result = retriever.retrieve(query)
    context = retriever.build_reuse_context(query, result)
    """

    def __init__(
        self,
        index: ExperienceIndex,
        config: Optional[ExperienceRetrievalConfig] = None,
    ) -> None:
        if not isinstance(index, ExperienceIndex):
            raise TypeError(f"Expected ExperienceIndex, got {type(index).__name__}")
        if config is None:
            config = ExperienceRetrievalConfig.default()
        self._index = index
        self._cfg = config
        self._scorer = RelevanceScorer(config)
        self._extractor = FeatureExtractor()

    @property
    def config(self) -> ExperienceRetrievalConfig:
        return self._cfg

    # ------------------------------------------------------------------
    # Index management (write path — delegates to ExperienceIndex)

    def index_experience(
        self,
        record: ExperienceRecord,
        evaluation: Optional[OutcomeEvaluationSnapshot] = None,
    ) -> bool:
        """
        Add one evaluated experience to the retrieval index.

        Returns True on success.
        Failure-isolated: exceptions return False.
        """
        try:
            return self._index.add(record, evaluation)
        except Exception:  # pylint: disable=broad-except
            return False

    # ------------------------------------------------------------------
    # Retrieval

    def retrieve(
        self,
        query: ExperienceRetrievalQuery,
    ) -> ExperienceRetrievalResult:
        """
        Retrieve the most relevant historical experiences for the query.

        Returns a complete ExperienceRetrievalResult.
        Never raises: exceptions produce a degraded/error result.
        """
        if query is None:
            return ExperienceRetrievalResult(
                query_id=NOT_AVAILABLE,
                result_id=f"{NOT_AVAILABLE}-RES",
                retrieval_timestamp=time.time(),
                schema_version=RETRIEVAL_SCHEMA_VERSION,
                retrieval_status=RetrievalStatus.ERROR,
                is_degraded=True,
                failure_reason="query is None",
            )

        if not self._cfg.enabled:
            return ExperienceRetrievalResult(
                query_id=query.query_id,
                result_id=_make_result_id(query.query_id),
                retrieval_timestamp=time.time(),
                schema_version=RETRIEVAL_SCHEMA_VERSION,
                retrieval_status=RetrievalStatus.DISABLED,
            )

        try:
            return self._retrieve_internal(query)
        except Exception as exc:  # pylint: disable=broad-except
            return ExperienceRetrievalResult(
                query_id=query.query_id,
                result_id=_make_result_id(query.query_id),
                retrieval_timestamp=time.time(),
                schema_version=RETRIEVAL_SCHEMA_VERSION,
                retrieval_status=RetrievalStatus.ERROR,
                is_degraded=True,
                failure_reason=str(exc),
            )

    def _retrieve_internal(
        self, query: ExperienceRetrievalQuery
    ) -> ExperienceRetrievalResult:
        policy = RetrievalPolicy(query.retrieval_policy)

        # Coarse filter
        candidates = self._index.query_candidates(self._cfg, policy)
        total_scanned = len(candidates)

        if total_scanned == 0:
            return ExperienceRetrievalResult(
                query_id=query.query_id,
                result_id=_make_result_id(query.query_id),
                retrieval_timestamp=time.time(),
                schema_version=RETRIEVAL_SCHEMA_VERSION,
                retrieval_status=RetrievalStatus.EMPTY,
                total_candidates_scanned=0,
                returned_count=0,
            )

        # Score each candidate
        scored: List[Tuple[float, IndexEntry, List[str], List[str]]] = []
        for entry in candidates:
            score, match_reasons, mismatch_reasons = self._scorer.score(
                query,
                entry.road_context,
                entry.traffic_context,
                entry.hazard_context,
                entry.vehicle_context,
                entry.planning_context,
                entry.safety_context,
                entry.experience_timestamp,
            )
            scored.append((score, entry, match_reasons, mismatch_reasons))

        # Filter by minimum relevance
        min_rel = max(0.0, query.minimum_relevance)
        scored = [(s, e, m, x) for s, e, m, x in scored if s >= min_rel]

        # Sort: relevance desc, then outcome quality desc, then
        # insertion_seq asc, then experience_id lex asc
        scored.sort(
            key=lambda t: (
                -t[0],
                -_OUTCOME_QUALITY_ORD.get(t[1].outcome_class, 0),
                t[1].insertion_seq,
                t[1].experience_id,
            )
        )

        # Top-k
        top_k = max(1, query.maximum_results)
        selected = scored[:top_k]

        retrieved = tuple(
            self._make_retrieved_experience(score, entry, matches, mismatches)
            for score, entry, matches, mismatches in selected
        )

        return ExperienceRetrievalResult(
            query_id=query.query_id,
            result_id=_make_result_id(query.query_id),
            retrieval_timestamp=time.time(),
            schema_version=RETRIEVAL_SCHEMA_VERSION,
            retrieval_status=RetrievalStatus.SUCCESS,
            total_candidates_scanned=total_scanned,
            returned_count=len(retrieved),
            is_degraded=False,
            retrieved_experiences=retrieved,
        )

    # ------------------------------------------------------------------
    # Reuse context builder

    def build_reuse_context(
        self,
        query: ExperienceRetrievalQuery,
        result: ExperienceRetrievalResult,
    ) -> ExperienceReuseContext:
        """
        Build a safe, informational reuse context for the reasoning layer.

        This context must NOT be used to:
          - issue steering, throttle, or brake commands
          - override safety decisions
          - modify the planner
        """
        success_n = sum(
            1 for e in result.retrieved_experiences
            if e.outcome_class == OutcomeClass.SUCCESS.value
        )
        partial_n = sum(
            1 for e in result.retrieved_experiences
            if e.outcome_class == OutcomeClass.PARTIAL_SUCCESS.value
        )
        fail_n = sum(
            1 for e in result.retrieved_experiences
            if e.outcome_class == OutcomeClass.FAILURE.value
        )
        unsafe_n = sum(
            1 for e in result.retrieved_experiences
            if e.outcome_class == OutcomeClass.UNSAFE_OUTCOME.value
        )
        return ExperienceReuseContext(
            context_id=query.query_id,
            session_id=query.session_id,
            timestamp=result.retrieval_timestamp,
            schema_version=RETRIEVAL_SCHEMA_VERSION,
            retrieval_status=result.retrieval_status,
            retrieved_count=result.returned_count,
            is_degraded=result.is_degraded,
            experiences=result.retrieved_experiences,
            success_count=success_n,
            partial_success_count=partial_n,
            failure_count=fail_n,
            unsafe_count=unsafe_n,
        )

    # ------------------------------------------------------------------
    # Convenience: build query from current record

    def build_query_from_record(
        self,
        record: ExperienceRecord,
        query_id: str,
    ) -> ExperienceRetrievalQuery:
        """Build a retrieval query from the current ExperienceRecord."""
        return self._extractor.build_query(record, query_id, self._cfg)

    # ------------------------------------------------------------------
    # Internal helpers

    @staticmethod
    def _make_retrieved_experience(
        score: float,
        entry: IndexEntry,
        match_reasons: List[str],
        mismatch_reasons: List[str],
    ) -> RetrievedExperience:
        return RetrievedExperience(
            experience_id=entry.experience_id,
            session_id=entry.session_id,
            experience_timestamp=entry.experience_timestamp,
            schema_version=RETRIEVAL_SCHEMA_VERSION,
            relevance_score=score,
            match_reasons=tuple(match_reasons),
            mismatch_reasons=tuple(mismatch_reasons),
            outcome_class=entry.outcome_class,
            outcome_confidence=entry.outcome_confidence,
            outcome_evidence=entry.outcome_evidence,
            experience_quality=entry.quality,
            record_completeness=entry.record_completeness,
            situation_type=entry.situation_type,
            road_type=entry.road_type,
            hazard_level=entry.hazard_level,
            action_type=entry.action_type,
            cattle_present=entry.cattle_present,
            vru_present=entry.vru_present,
            source_schema_version=entry.source_schema_version,
        )
