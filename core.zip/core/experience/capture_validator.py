"""
IndiDrive AI — Phase 12.1 | Experience Capture Validator
=========================================================
Validates ExperienceObservation and CaptureEvent instances.

Design rules:
  * Returns (is_valid: bool, reason: str) — no exceptions for validation failures.
  * Does NOT silently clamp safety-critical values.
  * UNKNOWN/INVALID states are preserved — never converted to healthy.
  * Deterministic.
"""
from __future__ import annotations

import math
import time
from typing import Tuple

from .experience_types import (
    EXPERIENCE_SCHEMA_VERSION,
    CaptureDataValidity,
    CaptureEvent,
    CaptureEventEvidence,
    CaptureEventType,
    DrivingExperienceSession,
    ExperienceCaptureConfig,
    ExperienceObservation,
    NOT_AVAILABLE,
    SessionStatus,
)

__all__ = ["CaptureValidator"]

_ValidationResult = Tuple[bool, str]

_FUTURE_TOLERANCE_S = 5.0  # seconds: allow small clock skew


class CaptureValidator:
    """
    Validates ExperienceObservation and CaptureEvent instances.

    Usage
    -----
    validator = CaptureValidator(config)
    ok, reason = validator.validate_observation(obs)
    ok, reason = validator.validate_event(event)
    ok, reason = validator.validate_session(session)
    """

    def __init__(self, config: ExperienceCaptureConfig) -> None:
        self._cfg = config

    # ------------------------------------------------------------------
    # Observation validation

    def validate_observation(
        self, obs: ExperienceObservation
    ) -> _ValidationResult:
        if obs is None:
            return False, "observation is None"

        # Schema version
        if obs.schema_version != EXPERIENCE_SCHEMA_VERSION:
            return False, (
                f"schema_version mismatch: got {obs.schema_version!r}, "
                f"expected {EXPERIENCE_SCHEMA_VERSION!r}"
            )

        # IDs
        if not obs.experience_id or obs.experience_id == NOT_AVAILABLE:
            return False, "experience_id is missing or NOT_AVAILABLE"
        if not obs.session_id or obs.session_id == NOT_AVAILABLE:
            return False, "session_id is missing or NOT_AVAILABLE"
        if obs.sequence_id < 0:
            return False, f"sequence_id must be >= 0, got {obs.sequence_id}"

        # Timestamp
        ok, reason = self._validate_timestamp(obs.timestamp)
        if not ok:
            return False, f"observation timestamp: {reason}"

        # Frame ID
        if obs.frame_id < 0:
            return False, f"frame_id must be >= 0, got {obs.frame_id}"

        # ID format: must embed session_id
        expected_prefix = f"{obs.session_id}-O"
        if not obs.experience_id.startswith(expected_prefix):
            return False, (
                f"experience_id {obs.experience_id!r} does not start with "
                f"{expected_prefix!r}"
            )

        # Data validity enum
        if not isinstance(obs.data_validity, CaptureDataValidity):
            return False, (
                f"data_validity must be CaptureDataValidity, got {type(obs.data_validity)}"
            )

        # Situation confidence/uncertainty ranges
        sit = obs.situation
        if not (0.0 <= sit.reasoning_confidence <= 1.0):
            return False, (
                f"reasoning_confidence {sit.reasoning_confidence} out of [0,1]"
            )
        if not (0.0 <= sit.reasoning_uncertainty <= 1.0):
            return False, (
                f"reasoning_uncertainty {sit.reasoning_uncertainty} out of [0,1]"
            )

        return True, "ok"

    # ------------------------------------------------------------------
    # Event validation

    def validate_event(self, event: CaptureEvent) -> _ValidationResult:
        if event is None:
            return False, "event is None"

        if event.schema_version != EXPERIENCE_SCHEMA_VERSION:
            return False, (
                f"schema_version mismatch: got {event.schema_version!r}, "
                f"expected {EXPERIENCE_SCHEMA_VERSION!r}"
            )

        if not event.event_id or event.event_id == NOT_AVAILABLE:
            return False, "event_id is missing or NOT_AVAILABLE"
        if not event.session_id or event.session_id == NOT_AVAILABLE:
            return False, "session_id is missing or NOT_AVAILABLE"
        if event.sequence_id < 0:
            return False, f"sequence_id must be >= 0, got {event.sequence_id}"

        expected_prefix = f"{event.session_id}-E"
        if not event.event_id.startswith(expected_prefix):
            return False, (
                f"event_id {event.event_id!r} does not start with "
                f"{expected_prefix!r}"
            )

        if not isinstance(event.event_type, CaptureEventType):
            return False, (
                f"event_type must be CaptureEventType, got {type(event.event_type)}"
            )

        ok, reason = self._validate_timestamp(event.timestamp)
        if not ok:
            return False, f"event timestamp: {reason}"

        if event.frame_id < 0:
            return False, f"frame_id must be >= 0, got {event.frame_id}"

        # Evidence confidence/uncertainty
        ev = event.evidence
        if not isinstance(ev, CaptureEventEvidence):
            return False, "event evidence is not CaptureEventEvidence"
        if not (0.0 <= ev.confidence <= 1.0):
            return False, f"evidence confidence {ev.confidence} out of [0,1]"
        if not (0.0 <= ev.uncertainty <= 1.0):
            return False, f"evidence uncertainty {ev.uncertainty} out of [0,1]"

        if not isinstance(ev.event_type, CaptureEventType):
            return False, (
                f"evidence event_type must be CaptureEventType, "
                f"got {type(ev.event_type)}"
            )

        return True, "ok"

    # ------------------------------------------------------------------
    # Session validation

    def validate_session(
        self, session: DrivingExperienceSession
    ) -> _ValidationResult:
        if session is None:
            return False, "session is None"

        if not session.session_id or session.session_id == NOT_AVAILABLE:
            return False, "session_id is missing or NOT_AVAILABLE"

        if not isinstance(session.status, SessionStatus):
            return False, f"status must be SessionStatus, got {type(session.status)}"

        if session.observation_count < 0:
            return False, f"observation_count must be >= 0, got {session.observation_count}"
        if session.event_count < 0:
            return False, f"event_count must be >= 0, got {session.event_count}"

        if session.observation_count > self._cfg.max_observations_per_session:
            return False, (
                f"observation_count {session.observation_count} exceeds "
                f"max {self._cfg.max_observations_per_session}"
            )
        if session.event_count > self._cfg.max_events_per_session:
            return False, (
                f"event_count {session.event_count} exceeds "
                f"max {self._cfg.max_events_per_session}"
            )

        if session.start_timestamp > 0.0 and session.last_timestamp > 0.0:
            if session.last_timestamp < session.start_timestamp:
                return False, (
                    f"last_timestamp {session.last_timestamp} < "
                    f"start_timestamp {session.start_timestamp}"
                )

        return True, "ok"

    # ------------------------------------------------------------------
    # Internal helpers

    @staticmethod
    def _validate_timestamp(ts: float) -> _ValidationResult:
        if ts is None:
            return False, "timestamp is None"
        if not isinstance(ts, (int, float)):
            return False, f"timestamp must be numeric, got {type(ts)}"
        if not math.isfinite(ts):
            return False, f"timestamp is not finite: {ts}"
        if ts < 0.0:
            return False, f"timestamp is negative: {ts}"
        now = time.time()
        if ts > now + _FUTURE_TOLERANCE_S:
            return False, (
                f"timestamp {ts} is {ts - now:.1f}s in the future "
                f"(tolerance={_FUTURE_TOLERANCE_S}s)"
            )
        return True, "ok"
