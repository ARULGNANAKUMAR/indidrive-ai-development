"""
IndiDrive AI — Phase 12.1 | Driving Experience Capture
=======================================================
Lightweight, offline-first, failure-isolated experience capture layer.

Public API
----------
from core.experience import (
    ExperienceCaptureEngine,
    PipelineCaptureAdapter,
    ExperienceCaptureConfig,
    ExperienceCaptureSnapshot,
    ExperienceObservation,
    CaptureEvent,
    CaptureEventType,
    DrivingExperienceSession,
)

Phase 12.1 boundary:
    Captures driving observations from existing pipeline state.
    Does NOT perform learning, reward calculation, outcome evaluation,
    experience retrieval, adaptive knowledge update, or decision improvement.
"""

from .experience_types import (
    NOT_AVAILABLE,
    EXPERIENCE_SCHEMA_VERSION,
    ExperienceCaptureStatus,
    SessionStatus,
    CaptureEventType,
    CaptureDataValidity,
    RetentionPolicy,
    EgoContextSummary,
    EnvironmentSummary,
    SituationSummary,
    PlanningSummary,
    ControlSummary,
    SafetySummary,
    CaptureEventEvidence,
    CaptureEvent,
    ExperienceObservation,
    DrivingExperienceSession,
    ExperienceCaptureSnapshot,
    ExperienceCaptureConfig,
)

from .capture_validator import CaptureValidator
from .capture_store import ExperienceCaptureStore
from .capture_engine import ExperienceCaptureEngine
from .pipeline_capture_adapter import PipelineCaptureAdapter

__all__ = [
    "NOT_AVAILABLE",
    "EXPERIENCE_SCHEMA_VERSION",
    "ExperienceCaptureStatus",
    "SessionStatus",
    "CaptureEventType",
    "CaptureDataValidity",
    "RetentionPolicy",
    "EgoContextSummary",
    "EnvironmentSummary",
    "SituationSummary",
    "PlanningSummary",
    "ControlSummary",
    "SafetySummary",
    "CaptureEventEvidence",
    "CaptureEvent",
    "ExperienceObservation",
    "DrivingExperienceSession",
    "ExperienceCaptureSnapshot",
    "ExperienceCaptureConfig",
    "CaptureValidator",
    "ExperienceCaptureStore",
    "ExperienceCaptureEngine",
    "PipelineCaptureAdapter",
]
