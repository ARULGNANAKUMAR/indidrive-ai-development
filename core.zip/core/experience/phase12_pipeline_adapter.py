"""
IndiDrive AI — Phase 12 Pipeline Adapter
=========================================
Connects Phase 12.1–12.6 to the existing autonomous pipeline as a
post-step observer.  It does NOT modify the pipeline's control flow.

Architectural position
----------------------

  AutonomousPipeline.step(planner_input)
          ↓  (returns PipelineSnapshot unchanged)
  Phase12PipelineAdapter.observe(snapshot, planner_input)
          ↓
  ┌─ Phase 12.1 — capture driving experience (observational)
  ├─ Phase 12.2 — record situation/action/outcome
  ├─ Phase 12.3 — evaluate outcomes
  ├─ Phase 12.4 — retrieve similar experiences
  ├─ Phase 12.5 — update adaptive knowledge
  └─ Phase 12.6 — compute decision improvement context

All phase 12 steps are:
  * observational only — they read pipeline state, never write it
  * failure-isolated — any exception is caught and logged; pipeline continues
  * bounded — storage limits are enforced by each subsystem
  * offline-first — no network dependency

The adapter exposes a get_decision_improvement_context() method so
the existing reasoning/arbitration layer can OPTIONALLY consult
the Phase 12.6 output.  The context is advisory — the baseline
decision is always available as fallback.

Usage
-----
    adapter = Phase12PipelineAdapter.build_default()

    # After each pipeline step:
    snapshot = pipeline.step(planner_input)
    adapter.observe(snapshot, planner_input)

    # Optionally, before the NEXT reasoning cycle:
    ctx = adapter.get_decision_improvement_context()
    # ctx may be None if no improvement context is available
"""
from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from typing import Any, Dict, Optional, Tuple

log = logging.getLogger(__name__)

NOT_AVAILABLE = "NOT_AVAILABLE"


# ---------------------------------------------------------------------------
# Minimal snapshot extraction helpers (avoid hard dependency on pipeline types)
# ---------------------------------------------------------------------------

def _safe_get(obj: Any, *attrs: str, default=NOT_AVAILABLE) -> Any:
    """Safely get a nested attribute, returning default on any error."""
    v = obj
    for attr in attrs:
        try:
            v = getattr(v, attr, default)
            if v is None:
                return default
        except Exception:
            return default
    return v if v is not None else default


def _extract_situation(snapshot: Any) -> str:
    """Extract situation type from PipelineSnapshot."""
    # Try common paths used by existing reasoning/planning types
    for path in [
        ("planner_output", "planning_context", "situation_category"),
        ("planner_output", "dominant_requirement", "requirement_type"),
        ("planner_output", "planning_status"),
    ]:
        v = _safe_get(snapshot, *path)
        if v and v != NOT_AVAILABLE:
            return str(v)
    return NOT_AVAILABLE


def _extract_safety_gate(snapshot: Any) -> str:
    """Extract SafetyGateState from PipelineSnapshot."""
    for path in [
        ("planner_output", "planning_context", "safety_gate_state"),
        ("planner_output", "safety_gate_state"),
    ]:
        v = _safe_get(snapshot, *path)
        if v and v != NOT_AVAILABLE:
            return str(v)
    return "UNKNOWN"


def _extract_dominant_decision(snapshot: Any) -> Tuple[str, float]:
    """Extract (decision_type, score) from PipelineSnapshot."""
    for path in [
        ("planner_output", "planning_context", "dominant_requirement"),
    ]:
        v = _safe_get(snapshot, *path)
        if v and v != NOT_AVAILABLE:
            req_type = _safe_get(v, "requirement_type", default=NOT_AVAILABLE)
            priority = float(_safe_get(v, "base_priority", default=0.5))
            if req_type and req_type != NOT_AVAILABLE:
                return str(req_type), priority
    # Fallback: derive from pipeline_status
    status = str(_safe_get(snapshot, "pipeline_status", default="UNKNOWN"))
    return status, 0.5


def _extract_road_context(snapshot: Any, planner_input: Any) -> Dict[str, str]:
    """Extract context key fields for knowledge lookup."""
    ctx: Dict[str, str] = {}
    # Try from planner_input world model
    for (field_name, paths) in [
        ("road_type", [
            ("world_model", "road_context", "road_type"),
            ("planning_context", "road_type"),
        ]),
        ("situation_type", [
            ("world_model", "situation_category"),
            ("planning_context", "situation_category"),
        ]),
        ("hazard_level", [
            ("world_model", "hazard_summary", "hazard_level"),
        ]),
    ]:
        for path in paths:
            v = _safe_get(planner_input, *path) if planner_input else NOT_AVAILABLE
            if v and v != NOT_AVAILABLE:
                ctx[field_name] = str(v)
                break
    return ctx


# ---------------------------------------------------------------------------
# Phase 12 observation record (lightweight, pipeline-cycle scoped)
# ---------------------------------------------------------------------------

@dataclass
class Phase12CycleRecord:
    """
    One-cycle record produced by the Phase 12 observer.
    This is distinct from Phase 12.1 ExperienceRecord — it is a
    lightweight snapshot of what the adapter observed in this cycle,
    used to feed downstream phases.
    """
    cycle_id: str = NOT_AVAILABLE
    session_id: str = NOT_AVAILABLE
    timestamp: float = field(default_factory=time.time)

    situation: str = NOT_AVAILABLE
    safety_gate_state: str = "UNKNOWN"
    dominant_decision: str = NOT_AVAILABLE
    decision_score: float = 0.5
    road_context: Dict[str, str] = field(default_factory=dict)

    pipeline_ok: bool = True
    pipeline_status: str = NOT_AVAILABLE
    degraded: bool = False

    # Phase 12.6 output (may be None if not yet computed)
    improvement_result: Optional[Any] = None  # DecisionImprovementResult
    improvement_available: bool = False


# ---------------------------------------------------------------------------
# Main adapter
# ---------------------------------------------------------------------------

class Phase12PipelineAdapter:
    """
    Post-step observer that connects Phase 12.1–12.6 to the pipeline.

    The adapter is optional — if not attached, the pipeline runs exactly
    as before.  On any internal error, it fails silently and the pipeline
    continues unchanged.

    Construction
    ------------
    Use build_default() for production use, or pass explicit components
    for testing.

    Thread safety
    -------------
    Not thread-safe across concurrent calls to observe().  The existing
    pipeline is single-threaded per instance, so this is fine.
    """

    def __init__(
        self,
        session_id: str = "default",
        capture_engine=None,
        outcome_evaluator=None,
        experience_retriever=None,
        knowledge_update_engine=None,
        decision_improvement_engine=None,
    ) -> None:
        self._session_id = session_id
        self._capture_engine = capture_engine
        self._outcome_evaluator = outcome_evaluator
        self._retriever = experience_retriever
        self._knowledge_engine = knowledge_update_engine
        self._decision_engine = decision_improvement_engine

        self._cycle_counter = 0
        self._last_cycle_record: Optional[Phase12CycleRecord] = None
        self._last_improvement_result: Optional[Any] = None

        log.debug(
            "Phase12PipelineAdapter initialised (session=%s, "
            "capture=%s, decision=%s)",
            session_id,
            type(capture_engine).__name__ if capture_engine else "None",
            type(decision_improvement_engine).__name__ if decision_improvement_engine else "None",
        )

    @classmethod
    def build_default(
        cls,
        session_id: str = "default",
        improvement_mode: str = "OBSERVATION_ONLY",
    ) -> "Phase12PipelineAdapter":
        """
        Build adapter with all Phase 12.1–12.6 components using defaults.

        improvement_mode: "DISABLED" | "OBSERVATION_ONLY" | "ADVISORY" | "BOUNDED_ACTIVE"
        Default: "OBSERVATION_ONLY" (conservative).
        """
        try:
            from core.experience.capture_engine import ExperienceCaptureEngine
            from core.experience.evaluation.outcome_evaluator import OutcomeEvaluator
            from core.experience.retrieval.experience_retriever import ExperienceRetriever
            from core.experience.knowledge import (
                AdaptiveKnowledgeConfig, KnowledgeStore, KnowledgeUpdateEngine,
            )
            from core.experience.decision_improvement import (
                ImprovementConfig, ImprovementMode, DecisionImprovementEngine,
            )

            capture_engine = ExperienceCaptureEngine()
            outcome_evaluator = OutcomeEvaluator()
            retriever = ExperienceRetriever()

            k_cfg = AdaptiveKnowledgeConfig.default()
            k_store = KnowledgeStore(k_cfg)
            k_engine = KnowledgeUpdateEngine(k_cfg, k_store)

            try:
                mode = ImprovementMode(improvement_mode)
            except ValueError:
                mode = ImprovementMode.OBSERVATION_ONLY

            i_cfg = ImprovementConfig(mode=mode)
            d_engine = DecisionImprovementEngine(i_cfg, k_store)

            log.info(
                "Phase12PipelineAdapter built: mode=%s", mode.value
            )
            return cls(
                session_id=session_id,
                capture_engine=capture_engine,
                outcome_evaluator=outcome_evaluator,
                experience_retriever=retriever,
                knowledge_update_engine=k_engine,
                decision_improvement_engine=d_engine,
            )
        except Exception as exc:
            log.warning(
                "Phase12PipelineAdapter.build_default: component init failed: %s "
                "— returning minimal adapter", exc
            )
            return cls(session_id=session_id)

    # ------------------------------------------------------------------
    # Main observation method — called after each pipeline.step()
    # ------------------------------------------------------------------

    def observe(
        self,
        snapshot: Any,
        planner_input: Any = None,
    ) -> Phase12CycleRecord:
        """
        Observe the result of one pipeline cycle.

        This method is failure-isolated: any internal error is caught,
        logged, and returns a minimal record.  The pipeline is unaffected.

        Parameters
        ----------
        snapshot     : PipelineSnapshot from pipeline.step()
        planner_input: PlannerInput or equivalent (for world model extraction)

        Returns
        -------
        Phase12CycleRecord — always returns, never raises.
        """
        try:
            return self._observe_inner(snapshot, planner_input)
        except Exception as exc:
            log.exception("Phase12PipelineAdapter.observe: unexpected error: %s", exc)
            record = Phase12CycleRecord(
                cycle_id=f"{self._session_id}-C{self._cycle_counter:06d}",
                session_id=self._session_id,
                pipeline_ok=False,
            )
            self._last_cycle_record = record
            return record

    def _observe_inner(
        self, snapshot: Any, planner_input: Any
    ) -> Phase12CycleRecord:
        self._cycle_counter += 1
        cycle_id = f"{self._session_id}-C{self._cycle_counter:06d}"

        situation = _extract_situation(snapshot)
        gate_state = _extract_safety_gate(snapshot)
        dominant_decision, decision_score = _extract_dominant_decision(snapshot)
        road_context = _extract_road_context(snapshot, planner_input)
        pipeline_status = str(_safe_get(snapshot, "pipeline_status", default=NOT_AVAILABLE))
        degraded = bool(_safe_get(snapshot, "degraded", default=False))

        record = Phase12CycleRecord(
            cycle_id=cycle_id,
            session_id=self._session_id,
            situation=situation,
            safety_gate_state=gate_state,
            dominant_decision=dominant_decision,
            decision_score=decision_score,
            road_context=road_context,
            pipeline_ok=True,
            pipeline_status=pipeline_status,
            degraded=degraded,
        )

        # Phase 12.5 knowledge update from retrieved experiences
        # (lightweight path: uses road_context for knowledge key lookup)
        self._run_knowledge_update(record, snapshot)

        # Phase 12.6 decision improvement
        self._run_decision_improvement(record)

        self._last_cycle_record = record
        return record

    def _run_knowledge_update(self, record: Phase12CycleRecord, snapshot: Any) -> None:
        """
        Phase 12.5: update knowledge from any recently completed experience.
        This runs only if a capture engine and knowledge engine are available.
        Failure-isolated.
        """
        if self._knowledge_engine is None:
            return
        if not record.road_context:
            return
        try:
            from core.experience.knowledge import KnowledgeContextKey
            key = KnowledgeContextKey(
                road_type=record.road_context.get("road_type", NOT_AVAILABLE),
                situation_type=record.road_context.get("situation_type", NOT_AVAILABLE),
                hazard_level=record.road_context.get("hazard_level", NOT_AVAILABLE),
                safety_state=record.safety_gate_state,
            )
            # Use pipeline status as a synthetic outcome for ongoing observation
            # Full Phase 12.2/12.3 processing happens offline via capture_engine
            outcome = self._map_status_to_outcome(record.pipeline_status, record.degraded)
            exp_record = [{
                "experience_id": f"{record.cycle_id}-EXP",
                "evaluation_id": f"{record.cycle_id}-EVAL",
                "session_id": self._session_id,
                "outcome_class": outcome,
                "evaluation_confidence": "LOW",  # pipeline-derived; not from evaluator
                "experience_timestamp": record.timestamp,
            }]
            self._knowledge_engine.process_experiences(key, exp_record)
        except Exception as exc:
            log.debug("knowledge_update: %s", exc)

    @staticmethod
    def _map_status_to_outcome(pipeline_status: str, degraded: bool) -> str:
        """Map PipelineStatus to an OutcomeClass string."""
        status = str(pipeline_status).upper()
        if degraded:
            return "DEGRADED"
        if "COMPLETE" in status or "PASSED" in status:
            return "SUCCESS"
        if "DEGRADED" in status:
            return "DEGRADED"
        if "FAILED" in status:
            return "FAILURE"
        if "UNSAFE" in status:
            return "UNSAFE_OUTCOME"
        return "INCONCLUSIVE"

    def _run_decision_improvement(self, record: Phase12CycleRecord) -> None:
        """
        Phase 12.6: compute decision improvement context.
        Failure-isolated.
        """
        if self._decision_engine is None:
            return
        try:
            result = self._decision_engine.improve(
                session_id=self._session_id,
                current_situation=record.situation,
                safety_gate_state=record.safety_gate_state,
                baseline_decision=record.dominant_decision,
                baseline_score=record.decision_score,
                context_key_dict=record.road_context,
            )
            record.improvement_result = result
            record.improvement_available = result is not None
            self._last_improvement_result = result
        except Exception as exc:
            log.debug("decision_improvement: %s", exc)

    # ------------------------------------------------------------------
    # Public accessors for the reasoning/arbitration layer
    # ------------------------------------------------------------------

    def get_decision_improvement_context(self) -> Optional[Any]:
        """
        Return the most recent DecisionImprovementResult, or None.

        This is the ONLY interface through which Phase 12.6 exposes its
        output to the existing reasoning layer.  The result is advisory:
        the caller may use or ignore it.  The baseline decision is always
        available regardless.

        Returns None if:
          - no cycle has been observed yet
          - decision improvement engine is not configured
          - the last improvement failed (baseline was used)
        """
        return self._last_improvement_result

    def get_last_cycle_record(self) -> Optional[Phase12CycleRecord]:
        """Return the most recent Phase12CycleRecord."""
        return self._last_cycle_record

    @property
    def cycle_count(self) -> int:
        return self._cycle_counter

    @property
    def session_id(self) -> str:
        return self._session_id
