"""
IndiDrive AI — Phase 12.2 | Situation → Action → Outcome Recording
===================================================================
Public API for the Phase 12.2 experience record layer.

Phase 12.2 records what happened — it does NOT evaluate it.
Evaluation (success/failure/reward) belongs to Phase 12.3.
"""

from .record_types import (
    NOT_AVAILABLE,
    RECORD_SCHEMA_VERSION,
    RecordCompleteness,
    ActionType,
    ActionSource,
    OutcomeObservationState,
    RecordStoreStatus,
    SituationRecord,
    RequestedAction,
    AppliedAction,
    ActionRecord,
    OutcomeRecord,
    ExperienceRecord,
    ExperienceRecordSnapshot,
    RecordStoreSnapshot,
    ExperienceRecordConfig,
)

from .record_validator import RecordValidator
from .record_builder import RecordBuilder
from .record_store import ExperienceRecordStore
from .record_engine import ExperienceRecordEngine, _make_record_id
from .pipeline_record_adapter import PipelineRecordAdapter

__all__ = [
    "NOT_AVAILABLE",
    "RECORD_SCHEMA_VERSION",
    "RecordCompleteness",
    "ActionType",
    "ActionSource",
    "OutcomeObservationState",
    "RecordStoreStatus",
    "SituationRecord",
    "RequestedAction",
    "AppliedAction",
    "ActionRecord",
    "OutcomeRecord",
    "ExperienceRecord",
    "ExperienceRecordSnapshot",
    "RecordStoreSnapshot",
    "ExperienceRecordConfig",
    "RecordValidator",
    "RecordBuilder",
    "ExperienceRecordStore",
    "ExperienceRecordEngine",
    "PipelineRecordAdapter",
    "_make_record_id",
]
