"""
IndiDrive AI — Phase 12.2 | Situation → Action → Outcome Record Types
======================================================================
Strongly-typed, compact data containers for experience record structures.

Phase 12.2 answers ONLY:
    «"Organize the captured situation, system action/response, and observed
      result into a structured chronological experience record."»

Phase 12.2 does NOT:
    - evaluate success or failure              → Phase 12.3
    - assign reward or quality scores          → Phase 12.3
    - retrieve similar past experiences        → Phase 12.4
    - update adaptive knowledge                → Phase 12.5
    - improve future decisions                 → Phase 12.6

Design rules (consistent with all prior phases):
  * dataclasses — not raw dicts
  * explicit NOT_AVAILABLE / UNKNOWN — never fabricated
  * no raw sensor frames, no point clouds, no video
  * confidence ≠ uncertainty — kept separate
  * deterministic IDs: session + sequence-based
  * compact: bounded collections, summaries only
  * immutable snapshots (ExperienceRecordSnapshot)
  * offline-first — no LLM, no cloud, no neural networks
  * observation-only — no new decisions, no new planning
  * causality is temporal correlation only — never causal claim

ID conventions (extend Phase 12.1):
    Observation:  <session_id>-O<seq:06d>   (Phase 12.1)
    Event:        <session_id>-E<seq:06d>   (Phase 12.1)
    Record:       <session_id>-R<seq:06d>   (Phase 12.2)
    Situation:    <record_id>-SIT
    Action:       <record_id>-ACT
    Outcome:      <record_id>-OUT
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from enum import Enum
from typing import List, Optional, Tuple

# Re-export Phase 12.1 sentinel for cross-module consistency
NOT_AVAILABLE = "NOT_AVAILABLE"

# Schema version for Phase 12.2 record structures
RECORD_SCHEMA_VERSION = "12.2"


# ---------------------------------------------------------------------------
# Record lifecycle enums
# ---------------------------------------------------------------------------

class RecordCompleteness(str, Enum):
    """
    Completeness state of an ExperienceRecord.

    This is about data availability — NOT success or quality.
    Phase 12.3 adds success/failure evaluation.
    """
    CAPTURING           = "CAPTURING"         # situation being built
    ACTION_ATTACHED     = "ACTION_ATTACHED"   # action appended, awaiting outcome
    OUTCOME_OBSERVING   = "OUTCOME_OBSERVING" # outcome window open
    COMPLETE            = "COMPLETE"          # situation+action+outcome all present
    PARTIAL             = "PARTIAL"           # some components available
    DEGRADED            = "DEGRADED"          # available but with reduced fidelity
    INCOMPLETE          = "INCOMPLETE"        # required components missing
    INVALID             = "INVALID"           # structural validation failure
    UNKNOWN             = "UNKNOWN"           # completeness cannot be determined


class ActionType(str, Enum):
    """
    Abstract action type derived from existing system outputs.

    Each value corresponds to an observable system behaviour that can be
    inferred from existing planner/control/safety state.
    No new decisions are made — only existing outputs are classified.
    """
    MAINTAIN_PROGRESS           = "MAINTAIN_PROGRESS"
    MAINTAIN_SAFE_SPACE         = "MAINTAIN_SAFE_SPACE"
    FOLLOW_REFERENCE            = "FOLLOW_REFERENCE"
    ADAPT_PATH                  = "ADAPT_PATH"
    REPLAN                      = "REPLAN"
    SLOW_DOWN                   = "SLOW_DOWN"
    ACCELERATE                  = "ACCELERATE"
    DECELERATE                  = "DECELERATE"
    STOP                        = "STOP"
    EMERGENCY_RESPONSE_STATE    = "EMERGENCY_RESPONSE_STATE"
    SAFETY_RESTRICTED_OPERATION = "SAFETY_RESTRICTED_OPERATION"
    DEGRADED_OPERATION          = "DEGRADED_OPERATION"
    FAIL_SAFE_OPERATION         = "FAIL_SAFE_OPERATION"
    UNKNOWN_ACTION              = "UNKNOWN_ACTION"


class ActionSource(str, Enum):
    """Origin subsystem of the recorded action."""
    PLANNER          = "PLANNER"
    SAFETY_SUPERVISOR = "SAFETY_SUPERVISOR"
    FAILSAFE_ENGINE  = "FAILSAFE_ENGINE"
    MPC_CONTROLLER   = "MPC_CONTROLLER"
    CONTROL_MANAGER  = "CONTROL_MANAGER"
    UNKNOWN          = "UNKNOWN"


class OutcomeObservationState(str, Enum):
    """
    State of observed outcome data.

    Purely descriptive — no evaluation.  Phase 12.3 evaluates.
    """
    OBSERVED   = "OBSERVED"    # outcome data is present and valid
    PARTIAL    = "PARTIAL"     # some outcome data available
    DEGRADED   = "DEGRADED"    # outcome observed but data quality reduced
    INCOMPLETE = "INCOMPLETE"  # observation window ended without full data
    MISSING    = "MISSING"     # no outcome data available
    UNKNOWN    = "UNKNOWN"     # state cannot be determined


class RecordStoreStatus(str, Enum):
    """Operational status of the ExperienceRecordStore."""
    ACTIVE   = "ACTIVE"
    IDLE     = "IDLE"
    OVERFLOW = "OVERFLOW"
    FAILED   = "FAILED"
    UNKNOWN  = "UNKNOWN"


# ---------------------------------------------------------------------------
# Situation record
# ---------------------------------------------------------------------------

@dataclass
class SituationRecord:
    """
    Structured situation description — the context of a recorded event.

    Derived from existing Phase 12.1 observations and upstream pipeline
    outputs.  No new perception or prediction is performed.

    ID: <record_id>-SIT
    """
    # Identity
    situation_id: str = NOT_AVAILABLE
    record_id: str = NOT_AVAILABLE
    session_id: str = NOT_AVAILABLE
    sequence_id: int = 0
    timestamp: float = 0.0
    frame_id: int = 0
    schema_version: str = RECORD_SCHEMA_VERSION

    # Triggering event reference (Phase 12.1)
    triggering_observation_id: str = NOT_AVAILABLE
    triggering_event_id: str = NOT_AVAILABLE
    triggering_event_type: str = NOT_AVAILABLE    # CaptureEventType.value

    # Environment (compact, from world model)
    road_type: str = NOT_AVAILABLE
    road_structure: str = NOT_AVAILABLE
    lane_marking_state: str = NOT_AVAILABLE
    intersection_state: str = NOT_AVAILABLE
    traffic_density: str = NOT_AVAILABLE
    traffic_mix: str = NOT_AVAILABLE
    road_anomaly_summary: str = NOT_AVAILABLE
    vulnerable_road_user_present: bool = False
    cattle_present: bool = False
    road_hazard_present: bool = False
    relevant_object_ids: Tuple[str, ...] = field(default_factory=tuple)
    relevant_hazard_ids: Tuple[str, ...] = field(default_factory=tuple)

    # Ego dynamic state
    ego_speed_ms: Optional[float] = None
    ego_acceleration_ms2: Optional[float] = None
    ego_yaw_rad: Optional[float] = None
    nearby_object_count: int = 0

    # Reasoning context (from existing reasoning engine)
    situation_type: str = NOT_AVAILABLE           # SituationCategory.value
    hazard_level: str = NOT_AVAILABLE             # RiskLevel.value
    dominant_hazard: str = NOT_AVAILABLE
    interaction_state: str = NOT_AVAILABLE
    reasoning_confidence: float = 0.0
    reasoning_uncertainty: float = 1.0
    reason_codes: Tuple[str, ...] = field(default_factory=tuple)

    # Safety context (from existing safety subsystems)
    safety_state: str = NOT_AVAILABLE
    emergency_state: str = NOT_AVAILABLE
    supervisor_authority: str = NOT_AVAILABLE
    failsafe_state: str = NOT_AVAILABLE

    # Data quality
    is_degraded: bool = False
    is_stale: bool = False

    def to_dict(self) -> dict:
        def _r(v):
            return round(v, 4) if v is not None else NOT_AVAILABLE
        return {
            "situation_id": self.situation_id,
            "record_id": self.record_id,
            "session_id": self.session_id,
            "sequence_id": self.sequence_id,
            "timestamp": self.timestamp,
            "frame_id": self.frame_id,
            "schema_version": self.schema_version,
            "triggering_observation_id": self.triggering_observation_id,
            "triggering_event_id": self.triggering_event_id,
            "triggering_event_type": self.triggering_event_type,
            "road_type": self.road_type,
            "road_structure": self.road_structure,
            "lane_marking_state": self.lane_marking_state,
            "intersection_state": self.intersection_state,
            "traffic_density": self.traffic_density,
            "traffic_mix": self.traffic_mix,
            "road_anomaly_summary": self.road_anomaly_summary,
            "vulnerable_road_user_present": self.vulnerable_road_user_present,
            "cattle_present": self.cattle_present,
            "road_hazard_present": self.road_hazard_present,
            "relevant_object_ids": list(self.relevant_object_ids),
            "relevant_hazard_ids": list(self.relevant_hazard_ids),
            "ego_speed_ms": _r(self.ego_speed_ms),
            "ego_acceleration_ms2": _r(self.ego_acceleration_ms2),
            "ego_yaw_rad": _r(self.ego_yaw_rad),
            "nearby_object_count": self.nearby_object_count,
            "situation_type": self.situation_type,
            "hazard_level": self.hazard_level,
            "dominant_hazard": self.dominant_hazard,
            "interaction_state": self.interaction_state,
            "reasoning_confidence": round(self.reasoning_confidence, 3),
            "reasoning_uncertainty": round(self.reasoning_uncertainty, 3),
            "reason_codes": list(self.reason_codes),
            "safety_state": self.safety_state,
            "emergency_state": self.emergency_state,
            "supervisor_authority": self.supervisor_authority,
            "failsafe_state": self.failsafe_state,
            "is_degraded": self.is_degraded,
            "is_stale": self.is_stale,
        }


# ---------------------------------------------------------------------------
# Action record — requested vs applied distinction
# ---------------------------------------------------------------------------

@dataclass
class RequestedAction:
    """
    What the planning/safety system requested/intended.

    Derived from existing planner and safety outputs only.
    No new planning decisions are made.
    """
    action_type: ActionType = ActionType.UNKNOWN_ACTION
    action_source: ActionSource = ActionSource.UNKNOWN
    planning_mode: str = NOT_AVAILABLE      # PlannerStatus.value
    planning_status: str = NOT_AVAILABLE
    path_id: str = NOT_AVAILABLE
    replanning_active: bool = False
    replanning_reason: str = NOT_AVAILABLE
    safety_authority: str = NOT_AVAILABLE   # ControlAuthority.value
    is_available: bool = False              # False if planner output was missing

    def to_dict(self) -> dict:
        return {
            "action_type": self.action_type.value,
            "action_source": self.action_source.value,
            "planning_mode": self.planning_mode,
            "planning_status": self.planning_status,
            "path_id": self.path_id,
            "replanning_active": self.replanning_active,
            "replanning_reason": self.replanning_reason,
            "safety_authority": self.safety_authority,
            "is_available": self.is_available,
        }


@dataclass
class AppliedAction:
    """
    What the control system actually applied/executed.

    Derived from existing Phase 10.4 control output only.
    No new control commands are generated.
    """
    tracking_state: str = NOT_AVAILABLE     # stage status from pipeline
    mpc_status: str = NOT_AVAILABLE
    control_status: str = NOT_AVAILABLE
    steering_status: str = NOT_AVAILABLE
    speed_status: str = NOT_AVAILABLE
    commanded_acceleration_ms2: Optional[float] = None
    commanded_steering_rad: Optional[float] = None
    is_available: bool = False              # False if control output was missing

    def to_dict(self) -> dict:
        def _r(v):
            return round(v, 4) if v is not None else NOT_AVAILABLE
        return {
            "tracking_state": self.tracking_state,
            "mpc_status": self.mpc_status,
            "control_status": self.control_status,
            "steering_status": self.steering_status,
            "speed_status": self.speed_status,
            "commanded_acceleration_ms2": _r(self.commanded_acceleration_ms2),
            "commanded_steering_rad": _r(self.commanded_steering_rad),
            "is_available": self.is_available,
        }


@dataclass
class ActionRecord:
    """
    Structured record of what the autonomous system attempted during a situation.

    Preserves the requested/applied distinction so Phase 12.3 can later
    determine whether the intended response actually executed.

    ID: <record_id>-ACT
    """
    action_id: str = NOT_AVAILABLE
    record_id: str = NOT_AVAILABLE
    session_id: str = NOT_AVAILABLE
    sequence_id: int = 0
    timestamp: float = 0.0
    frame_id: int = 0
    schema_version: str = RECORD_SCHEMA_VERSION

    # The action the system intended to take (from planner/safety)
    requested: RequestedAction = field(default_factory=RequestedAction)
    # The action the control layer actually applied
    applied: AppliedAction = field(default_factory=AppliedAction)

    # Correlation to triggering event
    triggering_observation_id: str = NOT_AVAILABLE
    triggering_event_id: str = NOT_AVAILABLE

    # Data quality
    is_degraded: bool = False
    is_stale: bool = False

    def to_dict(self) -> dict:
        return {
            "action_id": self.action_id,
            "record_id": self.record_id,
            "session_id": self.session_id,
            "sequence_id": self.sequence_id,
            "timestamp": self.timestamp,
            "frame_id": self.frame_id,
            "schema_version": self.schema_version,
            "requested": self.requested.to_dict(),
            "applied": self.applied.to_dict(),
            "triggering_observation_id": self.triggering_observation_id,
            "triggering_event_id": self.triggering_event_id,
            "is_degraded": self.is_degraded,
            "is_stale": self.is_stale,
        }


# ---------------------------------------------------------------------------
# Outcome record — purely observational
# ---------------------------------------------------------------------------

@dataclass
class OutcomeRecord:
    """
    What was observed after the recorded action, within a temporal window.

    This is PURELY OBSERVATIONAL — not evaluative.
    Fields are factual state observations only.

    Phase 12.3 assigns success/failure/quality to this record.
    Phase 12.2 only records what was observed.

    ID: <record_id>-OUT

    Temporal relationship:
        action_timestamp
        outcome_start_timestamp  = action_timestamp
        outcome_end_timestamp    = outcome_start_timestamp + observation_window_s
    """
    outcome_id: str = NOT_AVAILABLE
    record_id: str = NOT_AVAILABLE
    session_id: str = NOT_AVAILABLE
    sequence_id: int = 0
    schema_version: str = RECORD_SCHEMA_VERSION

    # Temporal window
    action_timestamp: float = 0.0
    outcome_start_timestamp: float = 0.0
    outcome_end_timestamp: float = 0.0
    observation_window_s: float = 0.0

    # Observed state — factual, not evaluative
    observation_state: OutcomeObservationState = OutcomeObservationState.UNKNOWN

    # Ego state after (from next pipeline cycle observation)
    vehicle_state_after: str = NOT_AVAILABLE    # compact summary
    ego_speed_after_ms: Optional[float] = None
    ego_acceleration_after_ms2: Optional[float] = None

    # Environment state after (factual)
    environment_state_after: str = NOT_AVAILABLE  # compact summary
    nearby_object_count_after: int = 0

    # Hazard state after (factual — not evaluated)
    hazard_state_after: str = NOT_AVAILABLE
    hazard_level_after: str = NOT_AVAILABLE

    # Path/planning state after (factual)
    path_state_after: str = NOT_AVAILABLE
    planning_status_after: str = NOT_AVAILABLE

    # Safety state after (factual)
    safety_state_after: str = NOT_AVAILABLE
    emergency_state_after: str = NOT_AVAILABLE

    # Sensor state after (factual)
    sensor_state_after: str = NOT_AVAILABLE

    # Control state after (factual)
    control_state_after: str = NOT_AVAILABLE

    # Factual event observations (no evaluation):
    # Phase 12.3 decides what these MEAN.
    collision_detected: Optional[bool] = None    # factual sensor observation
    emergency_active_after: Optional[bool] = None
    emergency_cleared: Optional[bool] = None     # factual: was emergency gone?
    replanning_occurred: Optional[bool] = None
    new_event_types: Tuple[str, ...] = field(default_factory=tuple)
    cleared_event_types: Tuple[str, ...] = field(default_factory=tuple)
    unresolved_event_types: Tuple[str, ...] = field(default_factory=tuple)

    # Termination context
    termination_reason: str = NOT_AVAILABLE   # why outcome window closed

    # Data quality
    is_degraded: bool = False

    def to_dict(self) -> dict:
        def _r(v):
            return round(v, 4) if v is not None else NOT_AVAILABLE
        def _b(v):
            return v if v is not None else NOT_AVAILABLE
        return {
            "outcome_id": self.outcome_id,
            "record_id": self.record_id,
            "session_id": self.session_id,
            "sequence_id": self.sequence_id,
            "schema_version": self.schema_version,
            "action_timestamp": self.action_timestamp,
            "outcome_start_timestamp": self.outcome_start_timestamp,
            "outcome_end_timestamp": self.outcome_end_timestamp,
            "observation_window_s": round(self.observation_window_s, 3),
            "observation_state": self.observation_state.value,
            "vehicle_state_after": self.vehicle_state_after,
            "ego_speed_after_ms": _r(self.ego_speed_after_ms),
            "ego_acceleration_after_ms2": _r(self.ego_acceleration_after_ms2),
            "environment_state_after": self.environment_state_after,
            "nearby_object_count_after": self.nearby_object_count_after,
            "hazard_state_after": self.hazard_state_after,
            "hazard_level_after": self.hazard_level_after,
            "path_state_after": self.path_state_after,
            "planning_status_after": self.planning_status_after,
            "safety_state_after": self.safety_state_after,
            "emergency_state_after": self.emergency_state_after,
            "sensor_state_after": self.sensor_state_after,
            "control_state_after": self.control_state_after,
            "collision_detected": _b(self.collision_detected),
            "emergency_active_after": _b(self.emergency_active_after),
            "emergency_cleared": _b(self.emergency_cleared),
            "replanning_occurred": _b(self.replanning_occurred),
            "new_event_types": list(self.new_event_types),
            "cleared_event_types": list(self.cleared_event_types),
            "unresolved_event_types": list(self.unresolved_event_types),
            "termination_reason": self.termination_reason,
            "is_degraded": self.is_degraded,
        }


# ---------------------------------------------------------------------------
# Experience record — the complete Situation → Action → Outcome unit
# ---------------------------------------------------------------------------

@dataclass
class ExperienceRecord:
    """
    One structured Situation → Action → Outcome experience record.

    ID: <session_id>-R<seq:06d>

    This is a recording structure only.  Phase 12.3 adds evaluation.
    Phase 12.4 adds retrieval.  Phase 12.5 adds adaptation.

    A record may be PARTIAL or INCOMPLETE if data was unavailable —
    this is explicitly represented, never silently fabricated.
    """
    record_id: str = NOT_AVAILABLE
    session_id: str = NOT_AVAILABLE
    sequence_id: int = 0
    schema_version: str = RECORD_SCHEMA_VERSION
    created_timestamp: float = field(default_factory=time.time)
    last_updated_timestamp: float = field(default_factory=time.time)

    # The three record components (may be None if not yet available)
    situation: Optional[SituationRecord] = None
    action: Optional[ActionRecord] = None
    outcome: Optional[OutcomeRecord] = None

    # Record completeness (NOT success/failure)
    completeness: RecordCompleteness = RecordCompleteness.UNKNOWN

    # Phase 12.1 source correlation
    source_observation_id: str = NOT_AVAILABLE
    source_event_ids: Tuple[str, ...] = field(default_factory=tuple)

    def to_dict(self) -> dict:
        return {
            "record_id": self.record_id,
            "session_id": self.session_id,
            "sequence_id": self.sequence_id,
            "schema_version": self.schema_version,
            "created_timestamp": self.created_timestamp,
            "last_updated_timestamp": self.last_updated_timestamp,
            "completeness": self.completeness.value,
            "source_observation_id": self.source_observation_id,
            "source_event_ids": list(self.source_event_ids),
            "situation": self.situation.to_dict() if self.situation else None,
            "action": self.action.to_dict() if self.action else None,
            "outcome": self.outcome.to_dict() if self.outcome else None,
        }


# ---------------------------------------------------------------------------
# Immutable snapshot of an ExperienceRecord for external consumption
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class ExperienceRecordSnapshot:
    """
    Immutable snapshot of one ExperienceRecord.

    Callers receive this; they must NOT mutate it.
    Situation/Action/Outcome sub-objects are read-only through the snapshot.
    """
    record_id: str = NOT_AVAILABLE
    session_id: str = NOT_AVAILABLE
    sequence_id: int = 0
    schema_version: str = RECORD_SCHEMA_VERSION
    created_timestamp: float = 0.0
    last_updated_timestamp: float = 0.0
    completeness: RecordCompleteness = RecordCompleteness.UNKNOWN
    source_observation_id: str = NOT_AVAILABLE
    source_event_ids: Tuple[str, ...] = field(default_factory=tuple)
    # Situation/action/outcome as frozen dicts (safe for external read)
    situation_dict: Optional[dict] = None
    action_dict: Optional[dict] = None
    outcome_dict: Optional[dict] = None
    has_situation: bool = False
    has_action: bool = False
    has_outcome: bool = False

    def to_dict(self) -> dict:
        return {
            "record_id": self.record_id,
            "session_id": self.session_id,
            "sequence_id": self.sequence_id,
            "schema_version": self.schema_version,
            "created_timestamp": self.created_timestamp,
            "last_updated_timestamp": self.last_updated_timestamp,
            "completeness": self.completeness.value,
            "source_observation_id": self.source_observation_id,
            "source_event_ids": list(self.source_event_ids),
            "has_situation": self.has_situation,
            "has_action": self.has_action,
            "has_outcome": self.has_outcome,
            "situation": self.situation_dict,
            "action": self.action_dict,
            "outcome": self.outcome_dict,
        }


# ---------------------------------------------------------------------------
# Session-level snapshot of the record store
# ---------------------------------------------------------------------------

@dataclass
class RecordStoreSnapshot:
    """
    Immutable view of the ExperienceRecordStore for one session.

    Returned by ExperienceRecordStore.get_store_snapshot().
    """
    schema_version: str = RECORD_SCHEMA_VERSION
    session_id: str = NOT_AVAILABLE
    store_status: RecordStoreStatus = RecordStoreStatus.UNKNOWN
    total_records: int = 0
    complete_records: int = 0
    partial_records: int = 0
    incomplete_records: int = 0
    recent_records: Tuple[ExperienceRecordSnapshot, ...] = field(default_factory=tuple)
    store_failed: bool = False
    failure_reason: str = NOT_AVAILABLE

    def to_dict(self) -> dict:
        return {
            "schema_version": self.schema_version,
            "session_id": self.session_id,
            "store_status": self.store_status.value,
            "total_records": self.total_records,
            "complete_records": self.complete_records,
            "partial_records": self.partial_records,
            "incomplete_records": self.incomplete_records,
            "recent_record_count": len(self.recent_records),
            "store_failed": self.store_failed,
            "failure_reason": self.failure_reason,
        }


# ---------------------------------------------------------------------------
# Record configuration
# ---------------------------------------------------------------------------

@dataclass
class ExperienceRecordConfig:
    """
    Conservative, deterministic configuration for the record layer.

    Defaults keep memory usage small and behavior predictable.
    """
    record_capture_enabled: bool = True
    max_records_per_session: int = 500
    recent_window_records: int = 20
    # Outcome observation windows
    immediate_outcome_window_s: float = 1.0
    short_term_outcome_window_s: float = 5.0
    max_outcome_window_s: float = 10.0
    # Staleness threshold for situation/action data
    stale_threshold_s: float = 2.0

    @staticmethod
    def default() -> "ExperienceRecordConfig":
        return ExperienceRecordConfig()

    def to_dict(self) -> dict:
        return {
            "record_capture_enabled": self.record_capture_enabled,
            "max_records_per_session": self.max_records_per_session,
            "recent_window_records": self.recent_window_records,
            "immediate_outcome_window_s": self.immediate_outcome_window_s,
            "short_term_outcome_window_s": self.short_term_outcome_window_s,
            "max_outcome_window_s": self.max_outcome_window_s,
            "stale_threshold_s": self.stale_threshold_s,
        }
