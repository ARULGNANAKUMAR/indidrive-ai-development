"""
IndiDrive AI — Phase 12.2 | Experience Record Store
====================================================
Bounded, offline-first, thread-safe store for ExperienceRecord objects.

Design principles:
  * No external database — in-memory only, offline-first.
  * Bounded: configurable max_records_per_session enforced strictly.
  * Thread-safe via threading.Lock (minimal lock scope).
  * Failure-isolated — storage failures do not propagate to pipeline.
  * No raw sensor data — compact structured records only.
  * Deterministic FIFO retention when bounds are reached.

This store does NOT:
  - evaluate success, failure, or quality (→ Phase 12.3).
  - retrieve similar records (→ Phase 12.4).
  - update knowledge or models (→ Phase 12.5).
  - modify planner, control, or safety outputs.
"""
from __future__ import annotations

import threading
import time
from typing import Dict, List, Optional, Tuple

from .record_types import (
    NOT_AVAILABLE,
    ExperienceRecord,
    ExperienceRecordConfig,
    ExperienceRecordSnapshot,
    RecordCompleteness,
    RecordStoreSnapshot,
    RecordStoreStatus,
)

__all__ = ["ExperienceRecordStore"]


class ExperienceRecordStore:
    """
    Bounded in-memory store for ExperienceRecord objects.

    One store manages one active session at a time.
    Thread-safe: all public methods are protected by self._lock.
    Snapshots return immutable ExperienceRecordSnapshot objects.

    Lifecycle
    ---------
    store = ExperienceRecordStore(config)
    store.start_session("session-001")
    store.add_record(record)
    store.update_record(record)   # after action or outcome attached
    snap = store.get_store_snapshot()
    store.finalize_session()
    """

    def __init__(self, config: ExperienceRecordConfig) -> None:
        if not isinstance(config, ExperienceRecordConfig):
            raise TypeError(
                f"ExperienceRecordStore requires ExperienceRecordConfig, "
                f"got {type(config)}"
            )
        self._cfg = config
        self._lock = threading.Lock()
        self._session_id: str = NOT_AVAILABLE
        self._records: List[ExperienceRecord] = []          # ordered by arrival
        self._record_index: Dict[str, ExperienceRecord] = {}  # id → record
        self._status: RecordStoreStatus = RecordStoreStatus.IDLE
        self._failure_reason: str = NOT_AVAILABLE

    # ------------------------------------------------------------------
    # Session lifecycle

    def start_session(self, session_id: str) -> bool:
        """Start a new session, replacing any active session."""
        if not session_id or session_id == NOT_AVAILABLE:
            self._record_failure("start_session: session_id empty or NOT_AVAILABLE")
            return False
        with self._lock:
            self._session_id = session_id
            self._records = []
            self._record_index = {}
            self._status = RecordStoreStatus.ACTIVE
            self._failure_reason = NOT_AVAILABLE
        return True

    def finalize_session(self) -> bool:
        """Mark session as no longer active."""
        with self._lock:
            if self._session_id == NOT_AVAILABLE:
                return False
            self._status = RecordStoreStatus.IDLE
        return True

    def clear_session(self) -> None:
        """Drop all session data."""
        with self._lock:
            self._session_id = NOT_AVAILABLE
            self._records = []
            self._record_index = {}
            self._status = RecordStoreStatus.IDLE
            self._failure_reason = NOT_AVAILABLE

    # ------------------------------------------------------------------
    # Record operations

    def add_record(self, record: ExperienceRecord) -> bool:
        """
        Add a new ExperienceRecord to the active session.

        Returns True on success.  Applies FIFO retention if at capacity.
        """
        if not self._cfg.record_capture_enabled:
            return True  # disabled — not a failure

        with self._lock:
            if self._session_id == NOT_AVAILABLE:
                self._record_failure("add_record: no active session")
                return False

            if record.record_id in self._record_index:
                # Duplicate — update instead
                self._record_index[record.record_id] = record
                return True

            max_r = self._cfg.max_records_per_session
            if len(self._records) >= max_r:
                # FIFO: drop oldest
                dropped = self._records.pop(0)
                self._record_index.pop(dropped.record_id, None)
                self._status = RecordStoreStatus.OVERFLOW

            self._records.append(record)
            self._record_index[record.record_id] = record
        return True

    def update_record(self, record: ExperienceRecord) -> bool:
        """
        Update an existing record (e.g., after action or outcome attached).

        Returns True on success.  If record not found, adds it.
        """
        with self._lock:
            if self._session_id == NOT_AVAILABLE:
                self._record_failure("update_record: no active session")
                return False
            if record.record_id in self._record_index:
                self._record_index[record.record_id] = record
                # Update in list
                for i, r in enumerate(self._records):
                    if r.record_id == record.record_id:
                        self._records[i] = record
                        break
                return True
        # Not found — add it
        return self.add_record(record)

    def get_record_snapshot(
        self, record_id: str
    ) -> Optional[ExperienceRecordSnapshot]:
        """Return an immutable snapshot of one record, or None if not found."""
        with self._lock:
            rec = self._record_index.get(record_id)
            if rec is None:
                return None
            return _make_record_snapshot(rec)

    def get_recent_records(
        self, n: Optional[int] = None
    ) -> Tuple[ExperienceRecordSnapshot, ...]:
        """Return up to n most recent record snapshots (immutable)."""
        window = n if n is not None else self._cfg.recent_window_records
        with self._lock:
            recent = self._records[-window:]
            return tuple(_make_record_snapshot(r) for r in recent)

    def get_incomplete_records(self) -> Tuple[ExperienceRecordSnapshot, ...]:
        """Return snapshots of records not yet COMPLETE."""
        with self._lock:
            incomplete = [
                r for r in self._records
                if r.completeness not in (
                    RecordCompleteness.COMPLETE,
                    RecordCompleteness.INVALID,
                )
            ]
            return tuple(_make_record_snapshot(r) for r in incomplete)

    def get_store_snapshot(self) -> RecordStoreSnapshot:
        """Return an immutable snapshot of the full store state."""
        with self._lock:
            window = self._cfg.recent_window_records
            recent = tuple(
                _make_record_snapshot(r) for r in self._records[-window:]
            )
            total = len(self._records)
            complete = sum(
                1 for r in self._records
                if r.completeness == RecordCompleteness.COMPLETE
            )
            partial = sum(
                1 for r in self._records
                if r.completeness in (
                    RecordCompleteness.PARTIAL,
                    RecordCompleteness.DEGRADED,
                    RecordCompleteness.ACTION_ATTACHED,
                    RecordCompleteness.OUTCOME_OBSERVING,
                )
            )
            incomplete = total - complete - partial - sum(
                1 for r in self._records
                if r.completeness in (
                    RecordCompleteness.INVALID,
                    RecordCompleteness.INCOMPLETE,
                )
            )
            return RecordStoreSnapshot(
                session_id=self._session_id,
                store_status=self._status,
                total_records=total,
                complete_records=complete,
                partial_records=partial,
                incomplete_records=max(0, incomplete),
                recent_records=recent,
                store_failed=(self._status == RecordStoreStatus.FAILED),
                failure_reason=self._failure_reason,
            )

    # ------------------------------------------------------------------
    # Status helpers

    @property
    def is_active(self) -> bool:
        with self._lock:
            return self._status == RecordStoreStatus.ACTIVE

    @property
    def store_status(self) -> RecordStoreStatus:
        with self._lock:
            return self._status

    @property
    def record_count(self) -> int:
        with self._lock:
            return len(self._records)

    # ------------------------------------------------------------------
    # Internal helpers

    def _record_failure(self, reason: str) -> None:
        self._failure_reason = reason
        self._status = RecordStoreStatus.FAILED


# ---------------------------------------------------------------------------
# Helper: make an immutable snapshot from a mutable ExperienceRecord
# ---------------------------------------------------------------------------

def _make_record_snapshot(rec: ExperienceRecord) -> ExperienceRecordSnapshot:
    return ExperienceRecordSnapshot(
        record_id=rec.record_id,
        session_id=rec.session_id,
        sequence_id=rec.sequence_id,
        schema_version=rec.schema_version,
        created_timestamp=rec.created_timestamp,
        last_updated_timestamp=rec.last_updated_timestamp,
        completeness=rec.completeness,
        source_observation_id=rec.source_observation_id,
        source_event_ids=rec.source_event_ids,
        has_situation=rec.situation is not None,
        has_action=rec.action is not None,
        has_outcome=rec.outcome is not None,
        situation_dict=rec.situation.to_dict() if rec.situation else None,
        action_dict=rec.action.to_dict() if rec.action else None,
        outcome_dict=rec.outcome.to_dict() if rec.outcome else None,
    )
