"""
IndiDrive AI — Phase 12.2 | Experience Record Engine
=====================================================
Orchestrates the creation and lifecycle of Situation → Action → Outcome
records from Phase 12.1 ExperienceObservation data.

Architectural position:
    Phase 12.1 ExperienceObservation / CaptureEvent
                    ↓
    ExperienceRecordEngine              ← Phase 12.2
                    ↓
    ExperienceRecord (Situation + Action + Outcome)

Key design decisions:
  1. Records are created from Phase 12.1 observations — no new pipeline state
     is fetched.
  2. Outcome is built from the NEXT available observation after the action
     observation — "action_timestamp then followed by observed outcome_obs".
  3. The record lifecycle progresses deterministically:
       CAPTURING → ACTION_ATTACHED → OUTCOME_OBSERVING → COMPLETE / PARTIAL
  4. Failure is isolated: any error leaves the engine in a degraded state
     but never propagates to the autonomous pipeline.
  5. No success/failure evaluation — that is Phase 12.3's responsibility.
  6. Deterministic IDs: <session_id>-R<seq:06d>

Thread safety: a single threading.Lock guards all mutable state.
Lock scope is kept minimal (no I/O under lock).
"""
from __future__ import annotations

import threading
import time
from typing import Dict, List, Optional, Tuple

from ..experience_types import (
    NOT_AVAILABLE,
    CaptureEvent,
    CaptureEventType,
    ExperienceObservation,
)
from .record_builder import RecordBuilder
from .record_store import ExperienceRecordStore
from .record_types import (
    RECORD_SCHEMA_VERSION,
    ExperienceRecord,
    ExperienceRecordConfig,
    RecordCompleteness,
    RecordStoreSnapshot,
    ExperienceRecordSnapshot,
)
from .record_validator import RecordValidator

__all__ = ["ExperienceRecordEngine"]


class ExperienceRecordEngine:
    """
    Orchestrates the Situation → Action → Outcome recording lifecycle.

    Usage
    -----
    config = ExperienceRecordConfig.default()
    engine = ExperienceRecordEngine(config)
    engine.start_session("session-001")

    # Each pipeline cycle, feed it a Phase 12.1 observation:
    engine.process_observation(obs, triggering_event=ev)

    # After N cycles, close pending outcome windows:
    engine.close_pending_outcomes(current_obs)

    snap = engine.get_store_snapshot()
    engine.finalize_session()

    Thread safety
    -------------
    All public methods acquire self._lock.
    """

    def __init__(self, config: ExperienceRecordConfig) -> None:
        if not isinstance(config, ExperienceRecordConfig):
            raise TypeError(
                f"ExperienceRecordEngine requires ExperienceRecordConfig, "
                f"got {type(config)}"
            )
        self._cfg = config
        self._store = ExperienceRecordStore(config)
        self._builder = RecordBuilder(config)
        self._validator = RecordValidator(config)
        self._lock = threading.Lock()

        # Sequence counter for record IDs
        self._record_seq: int = 0
        self._session_id: str = NOT_AVAILABLE

        # Pending outcome tracking:
        # record_id → (action_obs, action_timestamp, deadline)
        self._pending_outcomes: Dict[str, Tuple[ExperienceObservation, float, float]] = {}

        # Failure tracking
        self._last_failure: str = NOT_AVAILABLE

    # ------------------------------------------------------------------
    # Session lifecycle

    def start_session(self, session_id: str) -> bool:
        """Start a new recording session."""
        with self._lock:
            self._session_id = session_id
            self._record_seq = 0
            self._pending_outcomes = {}
            self._last_failure = NOT_AVAILABLE
        return self._store.start_session(session_id)

    def finalize_session(self) -> bool:
        """Finalize the current session — marks pending outcomes as PARTIAL."""
        with self._lock:
            # Close any still-pending outcomes as PARTIAL
            for record_id, (action_obs, action_ts, _) in list(self._pending_outcomes.items()):
                self._close_outcome_locked(
                    record_id, action_obs, action_ts,
                    after_obs=None,
                    termination_reason="session_finalized",
                )
            self._pending_outcomes.clear()
        return self._store.finalize_session()

    def reset(self) -> None:
        """Reset engine and clear all session data."""
        with self._lock:
            self._session_id = NOT_AVAILABLE
            self._record_seq = 0
            self._pending_outcomes = {}
            self._last_failure = NOT_AVAILABLE
        self._store.clear_session()

    # ------------------------------------------------------------------
    # Main processing entry point

    def process_observation(
        self,
        obs: ExperienceObservation,
        triggering_event: Optional[CaptureEvent] = None,
    ) -> Optional[str]:
        """
        Process one Phase 12.1 observation into the record layer.

        For each observation:
          1. Close any pending outcome windows whose deadline has passed,
             using this observation as the "after" state.
          2. If the observation carries a notable event (or always, for
             non-NORMAL_DRIVING cycles), open a new Situation→Action record
             and enqueue an outcome window.

        Parameters
        ----------
        obs              : ExperienceObservation
        triggering_event : CaptureEvent or None

        Returns
        -------
        str or None — the new record_id if a record was created, else None.
        """
        if obs is None:
            return None
        if self._session_id == NOT_AVAILABLE:
            return None

        try:
            return self._process_observation_inner(obs, triggering_event)
        except Exception as exc:  # pylint: disable=broad-except
            self._last_failure = f"process_observation: {exc}"
            return None

    def _process_observation_inner(
        self,
        obs: ExperienceObservation,
        triggering_event: Optional[CaptureEvent],
    ) -> Optional[str]:
        now = obs.timestamp if obs.timestamp > 0.0 else time.time()

        with self._lock:
            # 1. Close expired pending outcome windows using this obs as "after"
            expired_ids = [
                rid for rid, (_, _, deadline) in self._pending_outcomes.items()
                if now >= deadline
            ]
            for rid in expired_ids:
                action_obs, action_ts, _ = self._pending_outcomes.pop(rid)
                self._close_outcome_locked(
                    rid, action_obs, action_ts,
                    after_obs=obs,
                    termination_reason="window_elapsed",
                )

            # 2. Also partially close if we have any pending that are
            #    still within window — use this obs to update outcome
            #    for the most recent pending record (last-write-wins)
            if self._pending_outcomes:
                # Update the most recently opened pending outcome
                most_recent_rid = list(self._pending_outcomes.keys())[-1]
                action_obs, action_ts, deadline = self._pending_outcomes[most_recent_rid]
                # Only close if this is a different obs (frame_id advanced)
                if obs.frame_id > action_obs.frame_id:
                    self._pending_outcomes.pop(most_recent_rid)
                    self._close_outcome_locked(
                        most_recent_rid, action_obs, action_ts,
                        after_obs=obs,
                        termination_reason="next_observation",
                    )

            # 3. Decide whether to open a new record for this observation
            if not _should_create_record(obs, triggering_event):
                return None

            # Allocate record ID
            record_id = _make_record_id(self._session_id, self._record_seq)
            self._record_seq += 1

        # Build situation and action (outside lock — no shared state mutated)
        situation = self._builder.build_situation(record_id, obs, triggering_event)
        action = self._builder.build_action(record_id, obs, triggering_event)

        # Validate
        sit_ok, sit_reason = self._validator.validate_situation(situation)
        act_ok, act_reason = self._validator.validate_action(action)

        completeness = RecordCompleteness.ACTION_ATTACHED
        if not sit_ok or not act_ok:
            completeness = RecordCompleteness.DEGRADED

        source_ev_ids: Tuple[str, ...] = ()
        if triggering_event is not None:
            source_ev_ids = (triggering_event.event_id,)

        record = ExperienceRecord(
            record_id=record_id,
            session_id=self._session_id,
            sequence_id=self._record_seq - 1,
            schema_version=RECORD_SCHEMA_VERSION,
            created_timestamp=obs.timestamp,
            last_updated_timestamp=obs.timestamp,
            situation=situation,
            action=action,
            outcome=None,
            completeness=completeness,
            source_observation_id=obs.experience_id,
            source_event_ids=source_ev_ids,
        )

        self._store.add_record(record)

        # Enqueue outcome window
        deadline = now + self._cfg.max_outcome_window_s
        with self._lock:
            self._pending_outcomes[record_id] = (obs, obs.timestamp, deadline)

        return record_id

    def close_pending_outcomes(
        self,
        current_obs: Optional[ExperienceObservation],
        force: bool = False,
    ) -> int:
        """
        Close any pending outcome windows using current_obs as the "after" state.

        Parameters
        ----------
        current_obs : ExperienceObservation or None — the current pipeline state
        force       : bool — if True, close ALL pending windows regardless of deadline

        Returns
        -------
        int — number of outcome windows closed
        """
        closed = 0
        now = (current_obs.timestamp if current_obs and current_obs.timestamp > 0
               else time.time())

        with self._lock:
            to_close = [
                (rid, obs, ts, dl)
                for rid, (obs, ts, dl) in list(self._pending_outcomes.items())
                if force or now >= dl
            ]
            for rid, action_obs, action_ts, _ in to_close:
                self._pending_outcomes.pop(rid, None)
                self._close_outcome_locked(
                    rid, action_obs, action_ts,
                    after_obs=current_obs,
                    termination_reason="force_close" if force else "window_elapsed",
                )
                closed += 1
        return closed

    # ------------------------------------------------------------------
    # Store access

    def get_store_snapshot(self) -> RecordStoreSnapshot:
        """Return immutable snapshot of the record store."""
        return self._store.get_store_snapshot()

    def get_record_snapshot(
        self, record_id: str
    ) -> Optional[ExperienceRecordSnapshot]:
        """Return immutable snapshot of one record."""
        return self._store.get_record_snapshot(record_id)

    def get_recent_records(
        self, n: Optional[int] = None
    ) -> Tuple[ExperienceRecordSnapshot, ...]:
        """Return recent record snapshots."""
        return self._store.get_recent_records(n)

    def get_incomplete_records(self) -> Tuple[ExperienceRecordSnapshot, ...]:
        """Return snapshots of records not yet COMPLETE."""
        return self._store.get_incomplete_records()

    @property
    def pending_outcome_count(self) -> int:
        with self._lock:
            return len(self._pending_outcomes)

    @property
    def last_failure(self) -> str:
        return self._last_failure

    # ------------------------------------------------------------------
    # Internal: close one outcome window (called under self._lock)

    def _close_outcome_locked(
        self,
        record_id: str,
        action_obs: ExperienceObservation,
        action_timestamp: float,
        after_obs: Optional[ExperienceObservation],
        termination_reason: str,
    ) -> None:
        """Build and attach an outcome to a record.  Called under self._lock."""
        # Retrieve current record
        snap = self._store.get_record_snapshot(record_id)
        if snap is None:
            return

        # Build outcome (outside mutable state — builder is stateless)
        window = self._cfg.immediate_outcome_window_s
        outcome = self._builder.build_outcome(
            record_id=record_id,
            session_id=self._session_id,
            sequence_id=snap.sequence_id,
            action_timestamp=action_timestamp,
            before_obs=action_obs,
            after_obs=after_obs,
            observation_window_s=window,
            termination_reason=termination_reason,
        )

        ok, _ = self._validator.validate_outcome(outcome)

        # Determine completeness
        has_situation = snap.has_situation
        has_action = snap.has_action
        has_outcome = (ok and after_obs is not None)

        if has_situation and has_action and has_outcome:
            completeness = RecordCompleteness.COMPLETE
        elif has_situation and has_action:
            completeness = RecordCompleteness.PARTIAL
        elif not ok:
            completeness = RecordCompleteness.DEGRADED
        else:
            completeness = RecordCompleteness.INCOMPLETE

        # Reconstruct record with outcome attached
        updated = ExperienceRecord(
            record_id=record_id,
            session_id=snap.session_id,
            sequence_id=snap.sequence_id,
            schema_version=snap.schema_version,
            created_timestamp=snap.created_timestamp,
            last_updated_timestamp=time.time(),
            situation=_dict_to_situation(snap.situation_dict),
            action=_dict_to_action(snap.action_dict),
            outcome=outcome if ok else None,
            completeness=completeness,
            source_observation_id=snap.source_observation_id,
            source_event_ids=snap.source_event_ids,
        )
        self._store.update_record(updated)


# ---------------------------------------------------------------------------
# ID builder
# ---------------------------------------------------------------------------

def _make_record_id(session_id: str, seq: int) -> str:
    """Record ID: <session_id>-R<seq:06d>"""
    return f"{session_id}-R{seq:06d}"


# ---------------------------------------------------------------------------
# Filtering: which observations warrant a new record
# ---------------------------------------------------------------------------

def _should_create_record(
    obs: ExperienceObservation,
    triggering_event: Optional[CaptureEvent],
) -> bool:
    """
    Decide whether this observation should open a new experience record.

    Creates records for notable events (non-NORMAL_DRIVING) and for any
    observation with a non-LOW hazard level.  Normal cycling observations
    are not recorded individually to keep bounds manageable.
    """
    if triggering_event is not None:
        if triggering_event.event_type != CaptureEventType.NORMAL_DRIVING:
            return True

    # Also record if hazard level is notable
    hazard = obs.situation.hazard_level if obs.situation else NOT_AVAILABLE
    if hazard in ("HIGH", "CRITICAL", "MEDIUM"):
        return True

    # Record if replanning active
    if obs.planning and obs.planning.replanning_active:
        return True

    # Record if safety is degraded
    if obs.safety and obs.safety.safety_is_degraded:
        return True

    return False


# ---------------------------------------------------------------------------
# Lightweight reconstruction helpers (snapshot → partial objects)
# These are used only to reassemble a record from store snapshot dicts.
# They do NOT perform new analysis.
# ---------------------------------------------------------------------------

def _dict_to_situation(d: Optional[dict]):
    """Reconstruct a SituationRecord from its dict representation."""
    if d is None:
        return None
    from .record_types import SituationRecord, NOT_AVAILABLE

    # Fields that are Optional[float] — stored as float or NOT_AVAILABLE string
    _FLOAT_FIELDS = {
        "ego_speed_ms", "ego_acceleration_ms2", "ego_yaw_rad",
    }
    # Fields that are Tuple[str, ...] — stored as list in dict
    _TUPLE_FIELDS = {"relevant_object_ids", "relevant_hazard_ids", "reason_codes"}

    s = SituationRecord()
    for k, v in d.items():
        if not hasattr(s, k):
            continue
        try:
            if k in _FLOAT_FIELDS:
                # Restore None for NOT_AVAILABLE sentinel strings
                setattr(s, k, None if (v == NOT_AVAILABLE or v is None) else float(v))
            elif k in _TUPLE_FIELDS:
                setattr(s, k, tuple(v) if isinstance(v, (list, tuple)) else ())
            else:
                setattr(s, k, v)
        except Exception:  # pylint: disable=broad-except
            pass
    return s


def _dict_to_action(d: Optional[dict]):
    """Reconstruct an ActionRecord from its dict representation."""
    if d is None:
        return None
    from .record_types import (
        ActionRecord, RequestedAction, AppliedAction,
        ActionType, ActionSource, NOT_AVAILABLE,
    )

    # Optional[float] fields in AppliedAction
    _APPLIED_FLOAT = {"commanded_acceleration_ms2", "commanded_steering_rad"}

    a = ActionRecord()
    for k, v in d.items():
        if k == "requested" and isinstance(v, dict):
            req = RequestedAction()
            for rk, rv in v.items():
                if rk == "action_type":
                    try:
                        req.action_type = ActionType(rv)
                    except ValueError:
                        req.action_type = ActionType.UNKNOWN_ACTION
                elif rk == "action_source":
                    try:
                        req.action_source = ActionSource(rv)
                    except ValueError:
                        req.action_source = ActionSource.UNKNOWN
                elif hasattr(req, rk):
                    try:
                        setattr(req, rk, rv)
                    except Exception:  # pylint: disable=broad-except
                        pass
            a.requested = req
        elif k == "applied" and isinstance(v, dict):
            app = AppliedAction()
            for ak, av in v.items():
                if not hasattr(app, ak):
                    continue
                if ak in _APPLIED_FLOAT:
                    # Restore None for NOT_AVAILABLE sentinel
                    try:
                        setattr(app, ak, None if (av == NOT_AVAILABLE or av is None)
                                else float(av))
                    except Exception:  # pylint: disable=broad-except
                        setattr(app, ak, None)
                else:
                    try:
                        setattr(app, ak, av)
                    except Exception:  # pylint: disable=broad-except
                        pass
            a.applied = app
        elif hasattr(a, k):
            try:
                setattr(a, k, v)
            except Exception:  # pylint: disable=broad-except
                pass
    return a
