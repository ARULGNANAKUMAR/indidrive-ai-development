"""
IndiDrive AI — Phase 12.2 | Experience Record Validator
========================================================
Validates SituationRecord, ActionRecord, OutcomeRecord, ExperienceRecord.

Design rules:
  * Returns (is_valid: bool, reason: str) — no exceptions for validation.
  * Does NOT silently clamp safety-critical or evaluative values.
  * UNKNOWN/INVALID states preserved — never converted to healthy.
  * Does NOT evaluate success/failure — purely structural validation.
  * Deterministic.
"""
from __future__ import annotations

import math
import time
from typing import Tuple

from .record_types import (
    RECORD_SCHEMA_VERSION,
    NOT_AVAILABLE,
    ActionRecord,
    ActionType,
    ExperienceRecord,
    ExperienceRecordConfig,
    OutcomeObservationState,
    OutcomeRecord,
    RecordCompleteness,
    SituationRecord,
)

__all__ = ["RecordValidator"]

_ValidationResult = Tuple[bool, str]
_FUTURE_TOLERANCE_S = 5.0


class RecordValidator:
    """
    Validates Phase 12.2 record structures.

    Usage
    -----
    v = RecordValidator(config)
    ok, reason = v.validate_situation(sit)
    ok, reason = v.validate_action(act)
    ok, reason = v.validate_outcome(out)
    ok, reason = v.validate_record(rec)
    """

    def __init__(self, config: ExperienceRecordConfig) -> None:
        self._cfg = config

    # ------------------------------------------------------------------
    # Situation validation

    def validate_situation(self, sit: SituationRecord) -> _ValidationResult:
        if sit is None:
            return False, "situation is None"
        if sit.schema_version != RECORD_SCHEMA_VERSION:
            return False, f"schema_version mismatch: {sit.schema_version!r}"
        if not sit.situation_id or sit.situation_id == NOT_AVAILABLE:
            return False, "situation_id missing"
        if not sit.record_id or sit.record_id == NOT_AVAILABLE:
            return False, "record_id missing"
        if not sit.session_id or sit.session_id == NOT_AVAILABLE:
            return False, "session_id missing"
        if sit.sequence_id < 0:
            return False, f"sequence_id must be >=0, got {sit.sequence_id}"
        ok, reason = self._check_timestamp(sit.timestamp)
        if not ok:
            return False, f"situation timestamp: {reason}"
        if sit.frame_id < 0:
            return False, f"frame_id must be >=0, got {sit.frame_id}"
        # ID format
        expected = f"{sit.record_id}-SIT"
        if sit.situation_id != expected:
            return False, f"situation_id {sit.situation_id!r} != expected {expected!r}"
        if not (0.0 <= sit.reasoning_confidence <= 1.0):
            return False, f"reasoning_confidence {sit.reasoning_confidence} out of [0,1]"
        if not (0.0 <= sit.reasoning_uncertainty <= 1.0):
            return False, f"reasoning_uncertainty {sit.reasoning_uncertainty} out of [0,1]"
        return True, "ok"

    # ------------------------------------------------------------------
    # Action validation

    def validate_action(self, act: ActionRecord) -> _ValidationResult:
        if act is None:
            return False, "action is None"
        if act.schema_version != RECORD_SCHEMA_VERSION:
            return False, f"schema_version mismatch: {act.schema_version!r}"
        if not act.action_id or act.action_id == NOT_AVAILABLE:
            return False, "action_id missing"
        if not act.record_id or act.record_id == NOT_AVAILABLE:
            return False, "record_id missing"
        if not act.session_id or act.session_id == NOT_AVAILABLE:
            return False, "session_id missing"
        if act.sequence_id < 0:
            return False, f"sequence_id must be >=0, got {act.sequence_id}"
        ok, reason = self._check_timestamp(act.timestamp)
        if not ok:
            return False, f"action timestamp: {reason}"
        if act.frame_id < 0:
            return False, f"frame_id must be >=0, got {act.frame_id}"
        expected = f"{act.record_id}-ACT"
        if act.action_id != expected:
            return False, f"action_id {act.action_id!r} != expected {expected!r}"
        if not isinstance(act.requested.action_type, ActionType):
            return False, "requested.action_type must be ActionType"
        return True, "ok"

    # ------------------------------------------------------------------
    # Outcome validation

    def validate_outcome(self, out: OutcomeRecord) -> _ValidationResult:
        if out is None:
            return False, "outcome is None"
        if out.schema_version != RECORD_SCHEMA_VERSION:
            return False, f"schema_version mismatch: {out.schema_version!r}"
        if not out.outcome_id or out.outcome_id == NOT_AVAILABLE:
            return False, "outcome_id missing"
        if not out.record_id or out.record_id == NOT_AVAILABLE:
            return False, "record_id missing"
        if not out.session_id or out.session_id == NOT_AVAILABLE:
            return False, "session_id missing"
        if out.sequence_id < 0:
            return False, f"sequence_id must be >=0, got {out.sequence_id}"
        expected = f"{out.record_id}-OUT"
        if out.outcome_id != expected:
            return False, f"outcome_id {out.outcome_id!r} != expected {expected!r}"
        if not isinstance(out.observation_state, OutcomeObservationState):
            return False, "observation_state must be OutcomeObservationState"
        if out.observation_window_s < 0:
            return False, f"observation_window_s must be >=0, got {out.observation_window_s}"
        if (out.outcome_start_timestamp > 0 and out.outcome_end_timestamp > 0 and
                out.outcome_end_timestamp < out.outcome_start_timestamp):
            return False, "outcome_end_timestamp before outcome_start_timestamp"
        return True, "ok"

    # ------------------------------------------------------------------
    # Full record validation

    def validate_record(self, rec: ExperienceRecord) -> _ValidationResult:
        if rec is None:
            return False, "record is None"
        if rec.schema_version != RECORD_SCHEMA_VERSION:
            return False, f"schema_version mismatch: {rec.schema_version!r}"
        if not rec.record_id or rec.record_id == NOT_AVAILABLE:
            return False, "record_id missing"
        if not rec.session_id or rec.session_id == NOT_AVAILABLE:
            return False, "session_id missing"
        if rec.sequence_id < 0:
            return False, f"sequence_id must be >=0, got {rec.sequence_id}"
        if not isinstance(rec.completeness, RecordCompleteness):
            return False, "completeness must be RecordCompleteness"
        # ID prefix check
        expected_prefix = f"{rec.session_id}-R"
        if not rec.record_id.startswith(expected_prefix):
            return False, (
                f"record_id {rec.record_id!r} does not start with {expected_prefix!r}"
            )
        return True, "ok"

    # ------------------------------------------------------------------
    # Internal helpers

    @staticmethod
    def _check_timestamp(ts: float) -> _ValidationResult:
        if ts is None:
            return False, "timestamp is None"
        if not isinstance(ts, (int, float)):
            return False, f"timestamp must be numeric, got {type(ts)}"
        if not math.isfinite(ts):
            return False, f"timestamp not finite: {ts}"
        if ts < 0.0:
            return False, f"timestamp negative: {ts}"
        now = time.time()
        if ts > now + _FUTURE_TOLERANCE_S:
            return False, f"timestamp {ts:.1f} is {ts - now:.1f}s in the future"
        return True, "ok"
