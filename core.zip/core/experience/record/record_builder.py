"""
IndiDrive AI — Phase 12.2 | Experience Record Builder
======================================================
Builds SituationRecord, ActionRecord, and OutcomeRecord from existing
Phase 12.1 ExperienceObservation data and pipeline state snapshots.

Architectural role:
    Phase 12.1 ExperienceObservation
              ↓
    RecordBuilder
              ↓
    SituationRecord + ActionRecord + OutcomeRecord
              ↓
    ExperienceRecord

Design rules:
  * Only reads from existing Phase 12.1 structures and pipeline snapshots.
  * Does NOT create new perception, prediction, planning, or safety logic.
  * Does NOT generate new control commands, paths, or trajectories.
  * Does NOT evaluate success or failure (→ Phase 12.3).
  * Does NOT retrieve or compare historical records (→ Phase 12.4).
  * Causality is temporal correlation only — never causal claim.
  * All unavailable fields are explicitly marked NOT_AVAILABLE.
  * Deterministic: same input → same output.
"""
from __future__ import annotations

import math
import time
from typing import Optional, Tuple

from ..experience_types import (
    NOT_AVAILABLE,
    CaptureDataValidity,
    CaptureEvent,
    CaptureEventType,
    ControlSummary,
    EgoContextSummary,
    EnvironmentSummary,
    ExperienceObservation,
    PlanningSummary,
    SafetySummary,
    SituationSummary,
)
from .record_types import (
    RECORD_SCHEMA_VERSION,
    ActionRecord,
    ActionSource,
    ActionType,
    AppliedAction,
    ExperienceRecord,
    ExperienceRecordConfig,
    OutcomeObservationState,
    OutcomeRecord,
    RecordCompleteness,
    RequestedAction,
    SituationRecord,
)

__all__ = ["RecordBuilder"]


class RecordBuilder:
    """
    Builds the three record components from existing observation data.

    Usage
    -----
    builder = RecordBuilder(config)

    # Build situation from Phase 12.1 observation + triggering event
    sit = builder.build_situation(record_id, obs, triggering_event)

    # Build action from same observation
    act = builder.build_action(record_id, obs)

    # Build outcome from a later observation (the "after" state)
    out = builder.build_outcome(record_id, action_timestamp, after_obs)
    """

    def __init__(self, config: ExperienceRecordConfig) -> None:
        if not isinstance(config, ExperienceRecordConfig):
            raise TypeError(
                f"RecordBuilder requires ExperienceRecordConfig, got {type(config)}"
            )
        self._cfg = config

    # ------------------------------------------------------------------
    # Situation builder

    def build_situation(
        self,
        record_id: str,
        obs: ExperienceObservation,
        triggering_event: Optional[CaptureEvent] = None,
    ) -> SituationRecord:
        """
        Build a SituationRecord from a Phase 12.1 observation.

        Parameters
        ----------
        record_id         : str — parent record ID
        obs               : ExperienceObservation — the triggering observation
        triggering_event  : CaptureEvent or None — the event that triggered this record

        Returns
        -------
        SituationRecord — always returns a value; degrades gracefully on error.
        """
        try:
            return self._build_situation_inner(record_id, obs, triggering_event)
        except Exception:  # pylint: disable=broad-except
            return SituationRecord(
                situation_id=f"{record_id}-SIT",
                record_id=record_id,
                session_id=getattr(obs, "session_id", NOT_AVAILABLE),
                sequence_id=getattr(obs, "sequence_id", 0),
                timestamp=getattr(obs, "timestamp", 0.0),
                frame_id=getattr(obs, "frame_id", 0),
                is_degraded=True,
            )

    def _build_situation_inner(
        self,
        record_id: str,
        obs: ExperienceObservation,
        triggering_event: Optional[CaptureEvent],
    ) -> SituationRecord:
        env: EnvironmentSummary = obs.environment
        sit: SituationSummary = obs.situation
        ego: EgoContextSummary = obs.ego_context
        safety: SafetySummary = obs.safety

        # Triggering event correlation
        trig_obs_id = obs.experience_id
        trig_ev_id = NOT_AVAILABLE
        trig_ev_type = NOT_AVAILABLE
        if triggering_event is not None:
            trig_ev_id = triggering_event.event_id
            trig_ev_type = triggering_event.event_type.value

        # Stale check
        is_stale = (obs.data_validity == CaptureDataValidity.STALE)
        is_degraded = (obs.data_validity in (
            CaptureDataValidity.DEGRADED, CaptureDataValidity.INVALID
        ) or sit.is_degraded)

        return SituationRecord(
            situation_id=f"{record_id}-SIT",
            record_id=record_id,
            session_id=obs.session_id,
            sequence_id=obs.sequence_id,
            timestamp=obs.timestamp,
            frame_id=obs.frame_id,
            schema_version=RECORD_SCHEMA_VERSION,
            triggering_observation_id=trig_obs_id,
            triggering_event_id=trig_ev_id,
            triggering_event_type=trig_ev_type,
            # Environment
            road_type=env.road_type,
            road_structure=env.road_structure,
            lane_marking_state=env.lane_road_marking_state,
            intersection_state=env.intersection_state,
            traffic_density=env.traffic_density,
            traffic_mix=env.traffic_mix,
            road_anomaly_summary=env.road_anomaly_summary,
            vulnerable_road_user_present=env.vulnerable_road_user_present,
            cattle_present=env.cattle_present,
            road_hazard_present=env.road_hazard_present,
            relevant_object_ids=env.relevant_object_ids[:10],
            # Ego
            ego_speed_ms=ego.velocity_ms,
            ego_acceleration_ms2=ego.acceleration_ms2,
            ego_yaw_rad=ego.yaw_rad,
            nearby_object_count=env.nearby_object_count,
            # Reasoning
            situation_type=sit.situation_type,
            hazard_level=sit.hazard_level,
            dominant_hazard=sit.dominant_hazard,
            interaction_state=sit.interaction_state,
            reasoning_confidence=min(1.0, max(0.0, sit.reasoning_confidence)),
            reasoning_uncertainty=min(1.0, max(0.0, sit.reasoning_uncertainty)),
            reason_codes=sit.reason_codes,
            # Safety
            safety_state=safety.safety_state,
            emergency_state=safety.emergency_state,
            supervisor_authority=safety.supervisor_authority,
            failsafe_state=safety.failsafe_state,
            is_degraded=is_degraded,
            is_stale=is_stale,
        )

    # ------------------------------------------------------------------
    # Action builder

    def build_action(
        self,
        record_id: str,
        obs: ExperienceObservation,
        triggering_event: Optional[CaptureEvent] = None,
    ) -> ActionRecord:
        """
        Build an ActionRecord from a Phase 12.1 observation.

        Records what the system requested and what was applied.
        Does NOT generate new control commands or planning decisions.

        Returns
        -------
        ActionRecord — always returns a value; degrades gracefully on error.
        """
        try:
            return self._build_action_inner(record_id, obs, triggering_event)
        except Exception:  # pylint: disable=broad-except
            return ActionRecord(
                action_id=f"{record_id}-ACT",
                record_id=record_id,
                session_id=getattr(obs, "session_id", NOT_AVAILABLE),
                sequence_id=getattr(obs, "sequence_id", 0),
                timestamp=getattr(obs, "timestamp", 0.0),
                frame_id=getattr(obs, "frame_id", 0),
                is_degraded=True,
            )

    def _build_action_inner(
        self,
        record_id: str,
        obs: ExperienceObservation,
        triggering_event: Optional[CaptureEvent],
    ) -> ActionRecord:
        plan: PlanningSummary = obs.planning
        ctrl: ControlSummary = obs.control
        safety: SafetySummary = obs.safety

        is_stale = (obs.data_validity == CaptureDataValidity.STALE)
        is_degraded = (obs.data_validity in (
            CaptureDataValidity.DEGRADED, CaptureDataValidity.INVALID
        ))

        trig_obs_id = obs.experience_id
        trig_ev_id = NOT_AVAILABLE
        if triggering_event is not None:
            trig_ev_id = triggering_event.event_id

        # Classify the requested action from existing planner/safety state
        req_action_type = _classify_requested_action(plan, safety, obs)
        req_source = _classify_action_source(plan, safety)

        requested = RequestedAction(
            action_type=req_action_type,
            action_source=req_source,
            planning_mode=plan.planning_mode,
            planning_status=plan.planning_status,
            path_id=plan.active_candidate_id,
            replanning_active=plan.replanning_active,
            replanning_reason=plan.replanning_reason,
            safety_authority=safety.supervisor_authority,
            is_available=(plan.planning_mode != NOT_AVAILABLE),
        )

        applied = AppliedAction(
            tracking_state=ctrl.tracking_quality,
            mpc_status=ctrl.mpc_status,
            control_status=ctrl.control_status,
            steering_status=ctrl.steering_status,
            speed_status=ctrl.speed_status,
            # commanded values not directly available in summary — mark absent
            commanded_acceleration_ms2=None,
            commanded_steering_rad=None,
            is_available=(ctrl.control_status != NOT_AVAILABLE),
        )

        return ActionRecord(
            action_id=f"{record_id}-ACT",
            record_id=record_id,
            session_id=obs.session_id,
            sequence_id=obs.sequence_id,
            timestamp=obs.timestamp,
            frame_id=obs.frame_id,
            schema_version=RECORD_SCHEMA_VERSION,
            requested=requested,
            applied=applied,
            triggering_observation_id=trig_obs_id,
            triggering_event_id=trig_ev_id,
            is_degraded=is_degraded,
            is_stale=is_stale,
        )

    # ------------------------------------------------------------------
    # Outcome builder

    def build_outcome(
        self,
        record_id: str,
        session_id: str,
        sequence_id: int,
        action_timestamp: float,
        before_obs: ExperienceObservation,
        after_obs: Optional[ExperienceObservation],
        observation_window_s: Optional[float] = None,
        termination_reason: str = NOT_AVAILABLE,
    ) -> OutcomeRecord:
        """
        Build an OutcomeRecord from before and after observations.

        This is purely observational — no evaluation is performed.
        Phase 12.3 will decide if this outcome was good/bad/safe.

        Parameters
        ----------
        record_id            : str — parent record ID
        session_id           : str
        sequence_id          : int
        action_timestamp     : float — when the action was recorded
        before_obs           : ExperienceObservation — at action time
        after_obs            : ExperienceObservation or None — the "after" state
        observation_window_s : float or None — how long was observed
        termination_reason   : str — why outcome window closed

        Returns
        -------
        OutcomeRecord — always returns; degrades gracefully on error.
        """
        try:
            return self._build_outcome_inner(
                record_id, session_id, sequence_id, action_timestamp,
                before_obs, after_obs, observation_window_s, termination_reason
            )
        except Exception:  # pylint: disable=broad-except
            return OutcomeRecord(
                outcome_id=f"{record_id}-OUT",
                record_id=record_id,
                session_id=session_id,
                sequence_id=sequence_id,
                action_timestamp=action_timestamp,
                observation_state=OutcomeObservationState.MISSING,
                termination_reason="build_outcome_exception",
                is_degraded=True,
            )

    def _build_outcome_inner(
        self,
        record_id: str,
        session_id: str,
        sequence_id: int,
        action_timestamp: float,
        before_obs: ExperienceObservation,
        after_obs: Optional[ExperienceObservation],
        observation_window_s: Optional[float],
        termination_reason: str,
    ) -> OutcomeRecord:
        win = observation_window_s if observation_window_s is not None else (
            self._cfg.immediate_outcome_window_s
        )
        outcome_start = action_timestamp
        outcome_end = action_timestamp + win

        # No after observation — outcome is incomplete
        if after_obs is None:
            return OutcomeRecord(
                outcome_id=f"{record_id}-OUT",
                record_id=record_id,
                session_id=session_id,
                sequence_id=sequence_id,
                action_timestamp=action_timestamp,
                outcome_start_timestamp=outcome_start,
                outcome_end_timestamp=outcome_end,
                observation_window_s=win,
                observation_state=OutcomeObservationState.INCOMPLETE,
                termination_reason=termination_reason or "no_after_observation",
                is_degraded=False,
            )

        # Determine observation quality
        after_validity = after_obs.data_validity
        if after_validity == CaptureDataValidity.VALID:
            obs_state = OutcomeObservationState.OBSERVED
        elif after_validity == CaptureDataValidity.STALE:
            obs_state = OutcomeObservationState.PARTIAL
        elif after_validity == CaptureDataValidity.DEGRADED:
            obs_state = OutcomeObservationState.DEGRADED
        elif after_validity == CaptureDataValidity.INVALID:
            obs_state = OutcomeObservationState.MISSING
        else:
            obs_state = OutcomeObservationState.UNKNOWN

        after_ego = after_obs.ego_context
        after_env = after_obs.environment
        after_sit = after_obs.situation
        after_plan = after_obs.planning
        after_ctrl = after_obs.control
        after_safety = after_obs.safety

        # Factual event delta — what changed between before and after?
        # These are FACTUAL observations, not evaluations.
        before_sit = before_obs.situation
        before_safety = before_obs.safety

        collision_detected = None  # unknown — we don't have a direct collision sensor
        emergency_active = (after_safety.safety_state in ("CRITICAL", "HIGH_ALERT"))
        emergency_before = (before_safety.safety_state in ("CRITICAL", "HIGH_ALERT"))
        emergency_cleared = (emergency_before and not emergency_active)
        replanning_occurred = after_plan.replanning_active

        # Event type delta (factual, not evaluated)
        new_events: Tuple[str, ...] = ()
        cleared_events: Tuple[str, ...] = ()
        unresolved_events: Tuple[str, ...] = ()

        # Sensor degradation change (factual)
        before_degraded = set(before_safety.active_degraded_sensors)
        after_degraded = set(after_safety.active_degraded_sensors)
        new_degraded = after_degraded - before_degraded
        cleared_degraded = before_degraded - after_degraded
        if new_degraded:
            new_events = tuple(f"SENSOR_DEGRADATION:{s}" for s in sorted(new_degraded))
        if cleared_degraded:
            cleared_events = tuple(f"SENSOR_DEGRADATION:{s}" for s in sorted(cleared_degraded))

        is_degraded = obs_state in (
            OutcomeObservationState.DEGRADED,
            OutcomeObservationState.MISSING,
        )

        return OutcomeRecord(
            outcome_id=f"{record_id}-OUT",
            record_id=record_id,
            session_id=session_id,
            sequence_id=sequence_id,
            action_timestamp=action_timestamp,
            outcome_start_timestamp=outcome_start,
            outcome_end_timestamp=max(outcome_end, after_obs.timestamp),
            observation_window_s=win,
            observation_state=obs_state,
            # Vehicle state (factual)
            vehicle_state_after=after_ego.vehicle_state_validity,
            ego_speed_after_ms=after_ego.velocity_ms,
            ego_acceleration_after_ms2=after_ego.acceleration_ms2,
            # Environment state (factual)
            environment_state_after=after_env.world_model_validity,
            nearby_object_count_after=after_env.nearby_object_count,
            # Hazard state (factual)
            hazard_state_after=after_sit.hazard_level,
            hazard_level_after=after_sit.hazard_level,
            # Path/planning state (factual)
            path_state_after=after_plan.path_risk_summary,
            planning_status_after=after_plan.planning_status,
            # Safety state (factual)
            safety_state_after=after_safety.safety_state,
            emergency_state_after=after_safety.emergency_state,
            # Sensor state (factual)
            sensor_state_after=(
                "DEGRADED" if after_safety.active_degraded_sensors else "OK"
            ),
            # Control state (factual)
            control_state_after=after_ctrl.control_status,
            # Factual event observations (NO evaluation)
            collision_detected=collision_detected,
            emergency_active_after=emergency_active,
            emergency_cleared=emergency_cleared,
            replanning_occurred=replanning_occurred,
            new_event_types=new_events,
            cleared_event_types=cleared_events,
            unresolved_event_types=unresolved_events,
            termination_reason=termination_reason or "window_elapsed",
            is_degraded=is_degraded,
        )


# ---------------------------------------------------------------------------
# Action classification helpers — derived from existing pipeline state only
# ---------------------------------------------------------------------------

def _classify_requested_action(
    plan: PlanningSummary,
    safety: SafetySummary,
    obs: ExperienceObservation,
) -> ActionType:
    """
    Classify the abstract action type from existing planner/safety state.

    NO new decisions are made here — only existing outputs are classified.
    """
    # Safety-level overrides first
    if safety.failsafe_state not in (NOT_AVAILABLE, "NORMAL_OPERATION", "UNKNOWN"):
        return ActionType.FAIL_SAFE_OPERATION

    if safety.supervisor_authority in (
        "SAFETY_CONTROL_REQUIRED", "OVERRIDE_REQUIRED", "CONTROL_WITHHELD"
    ):
        return ActionType.SAFETY_RESTRICTED_OPERATION

    if safety.safety_state in ("CRITICAL", "HIGH_ALERT"):
        return ActionType.EMERGENCY_RESPONSE_STATE

    # Planning-level classification
    if plan.planning_is_degraded:
        return ActionType.DEGRADED_OPERATION

    mode = plan.planning_mode
    if mode in ("BLOCKED", "STALE_INPUT", "INVALID_INPUT"):
        return ActionType.DEGRADED_OPERATION

    if plan.replanning_active or mode == "REPLAN_REQUIRED":
        return ActionType.REPLAN

    if mode == "PLAN_AVAILABLE":
        # Classify from control summary if available
        ctrl = obs.control
        if ctrl.control_is_degraded:
            return ActionType.DEGRADED_OPERATION
        speed_status = ctrl.speed_status
        if speed_status == "STOPPING":
            return ActionType.STOP
        if speed_status == "DECELERATING":
            return ActionType.DECELERATE
        if speed_status == "ACCELERATING":
            return ActionType.ACCELERATE
        # Default for normal plan execution
        return ActionType.FOLLOW_REFERENCE

    if mode == "EMERGENCY_STOP":
        return ActionType.EMERGENCY_RESPONSE_STATE

    if mode == "SAFE_STOP":
        return ActionType.STOP

    return ActionType.UNKNOWN_ACTION


def _classify_action_source(
    plan: PlanningSummary,
    safety: SafetySummary,
) -> ActionSource:
    """Determine which subsystem produced the primary action."""
    if safety.failsafe_state not in (NOT_AVAILABLE, "NORMAL_OPERATION", "UNKNOWN"):
        return ActionSource.FAILSAFE_ENGINE
    if safety.supervisor_authority in (
        "SAFETY_CONTROL_REQUIRED", "OVERRIDE_REQUIRED", "CONTROL_WITHHELD"
    ):
        return ActionSource.SAFETY_SUPERVISOR
    if plan.planning_mode != NOT_AVAILABLE:
        return ActionSource.PLANNER
    return ActionSource.UNKNOWN
