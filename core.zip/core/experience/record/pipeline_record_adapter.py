"""
IndiDrive AI — Phase 12.2 | Pipeline Recording Adapter
=======================================================
Thin, failure-isolated adapter that feeds Phase 12.1 observation output
into the Phase 12.2 Situation → Action → Outcome record layer.

Integration flow:
    Phase 12.1 PipelineCaptureAdapter.observe()
                        ↓
                ExperienceCaptureSnapshot
                        ↓
    PipelineRecordAdapter.record_from_snapshot()    ← Phase 12.2
                        ↓
                RecordStoreSnapshot

Architectural guarantee:
    If the recording adapter fails for ANY reason, the autonomous pipeline
    is NOT affected.  The adapter is a side-effect-only observer.

    record_failed → experience recording degraded.
    record_failed ≠ planner_failed.
    record_failed ≠ safety_failed.
    record_failed ≠ Phase 12.1 capture_failed.

This module does NOT:
    - modify planner, MPC, control, or safety outputs.
    - evaluate success or failure (→ Phase 12.3).
    - retrieve similar experiences (→ Phase 12.4).
    - update knowledge (→ Phase 12.5).
    - call external APIs or require network access.
"""
from __future__ import annotations

import threading
from typing import Optional

from ..experience_types import (
    NOT_AVAILABLE,
    CaptureEvent,
    ExperienceCaptureSnapshot,
    ExperienceObservation,
)
from .record_engine import ExperienceRecordEngine
from .record_types import (
    ExperienceRecordConfig,
    RecordStoreSnapshot,
    RecordStoreStatus,
)

__all__ = ["PipelineRecordAdapter"]


class PipelineRecordAdapter:
    """
    Non-blocking, failure-isolated adapter for Phase 12.2 pipeline integration.

    Usage
    -----
    adapter = PipelineRecordAdapter()
    adapter.start_session("session-001")

    # After each Phase 12.1 capture cycle:
    store_snap = adapter.record_from_snapshot(capture_snap)

    # Or feed observations directly:
    store_snap = adapter.record_observation(obs, triggering_event)

    # At session end:
    adapter.finalize_session()
    """

    def __init__(
        self, config: Optional[ExperienceRecordConfig] = None
    ) -> None:
        self._cfg = config if config is not None else ExperienceRecordConfig.default()
        self._engine = ExperienceRecordEngine(self._cfg)
        self._lock = threading.Lock()

    # ------------------------------------------------------------------
    # Session lifecycle

    def start_session(self, session_id: str) -> bool:
        """Start a new recording session.  Failure is isolated."""
        try:
            return self._engine.start_session(session_id)
        except Exception:  # pylint: disable=broad-except
            return False

    def finalize_session(self) -> bool:
        """Finalize the current session.  Failure is isolated."""
        try:
            return self._engine.finalize_session()
        except Exception:  # pylint: disable=broad-except
            return False

    def reset(self) -> None:
        """Reset recording engine.  Failure is isolated."""
        try:
            self._engine.reset()
        except Exception:  # pylint: disable=broad-except
            pass

    # ------------------------------------------------------------------
    # Feed from Phase 12.1 snapshot

    def record_from_snapshot(
        self,
        capture_snap: ExperienceCaptureSnapshot,
    ) -> RecordStoreSnapshot:
        """
        Process the most recent Phase 12.1 capture snapshot.

        Feeds the latest observation and its most notable event into the
        record engine.  Never raises.

        Parameters
        ----------
        capture_snap : ExperienceCaptureSnapshot — from PipelineCaptureAdapter

        Returns
        -------
        RecordStoreSnapshot — always returns a valid snapshot.
        """
        try:
            if capture_snap is None:
                return self._safe_store_snapshot()

            obs_list = capture_snap.recent_observations
            ev_list = capture_snap.recent_events

            if not obs_list:
                return self._safe_store_snapshot()

            # Use the most recent observation
            obs = obs_list[-1]

            # Find the most notable event for this observation (by frame_id)
            triggering_ev: Optional[CaptureEvent] = None
            if ev_list:
                # Most recent event for same frame
                for ev in reversed(ev_list):
                    if ev.frame_id == obs.frame_id:
                        triggering_ev = ev
                        break
                # Fall back to most recent event overall
                if triggering_ev is None:
                    triggering_ev = ev_list[-1]

            self._engine.process_observation(obs, triggering_event=triggering_ev)
            return self._safe_store_snapshot()

        except Exception:  # pylint: disable=broad-except
            return self._safe_store_snapshot()

    # ------------------------------------------------------------------
    # Feed observation directly

    def record_observation(
        self,
        obs: ExperienceObservation,
        triggering_event: Optional[CaptureEvent] = None,
    ) -> RecordStoreSnapshot:
        """
        Process one observation directly.

        This method NEVER raises.

        Returns
        -------
        RecordStoreSnapshot — always returns a valid snapshot.
        """
        try:
            self._engine.process_observation(obs, triggering_event)
            return self._safe_store_snapshot()
        except Exception:  # pylint: disable=broad-except
            return self._safe_store_snapshot()

    def close_pending_outcomes(
        self,
        current_obs: Optional[ExperienceObservation] = None,
        force: bool = False,
    ) -> int:
        """Close expired outcome windows.  Never raises."""
        try:
            return self._engine.close_pending_outcomes(current_obs, force=force)
        except Exception:  # pylint: disable=broad-except
            return 0

    # ------------------------------------------------------------------
    # Snapshot access

    def get_store_snapshot(self) -> RecordStoreSnapshot:
        """Return current store state snapshot.  Never raises."""
        return self._safe_store_snapshot()

    # ------------------------------------------------------------------
    # Internal helpers

    def _safe_store_snapshot(self) -> RecordStoreSnapshot:
        """Return store snapshot, degrading gracefully on error."""
        try:
            return self._engine.get_store_snapshot()
        except Exception:  # pylint: disable=broad-except
            return RecordStoreSnapshot(
                session_id=NOT_AVAILABLE,
                store_status=RecordStoreStatus.FAILED,
                store_failed=True,
                failure_reason="adapter.get_store_snapshot exception",
            )
