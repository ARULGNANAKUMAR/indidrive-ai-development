"""
IndiDrive AI — Phase 12.6 | Experience-Driven Decision Improvement Types
=========================================================================
Strongly-typed, compact domain model for the Decision Improvement layer.

Phase 12.6 extends the existing decision architecture with experience-derived
decision support.  It does NOT replace any existing subsystem.

Architectural position
----------------------

  Current World State
          ↓
  Current Situation
          ↓
  Experience Retrieval  (Phase 12.4)
          ↓
  Adaptive Knowledge    (Phase 12.5)
          ↓
  Decision Improvement Context     ← Phase 12.6 begins
          ↓
  Existing Reasoning / Arbitration
          ↓
  Safety Validation    (SafetyGate — unchanged)
          ↓
  Approved Decision
          ↓
  Existing Planning / Control Pipeline

Phase 12.6 MUST NOT:
  * replace the planner, reasoning engine, MPC, tracking, control, SafetyGate
  * directly control steering / throttle / brake actuators
  * bypass SafetyGate or any safety validation
  * reduce safety margins or collision thresholds
  * implement RL / reward signals / model retraining
  * modify source code, config, or safety policy at runtime
  * introduce an uncontrolled feedback loop

Phase 12.6 MAY:
  * enrich the decision context with validated knowledge signals
  * apply bounded, configurable, auditable scoring adjustments
  * expose experience-informed candidate comparisons to existing reasoning
  * fall back to baseline behavior in any degraded or uncertain condition
  * record decision improvement audit trails
  * support controlled rollback

Safety authority always remains with the existing safety architecture.
SafetyGateState from the arbitration layer always takes precedence.

Naming conventions (consistent with prior phases):
  DecisionImprovementContext   — structured context feeding into reasoning
  DecisionCandidate            — one option with its scores
  DecisionImprovementResult    — final output of the improvement pipeline
  DecisionImprovementRecord    — audit record
  ImprovementConfig            — all tunable parameters
  ImprovementMode              — DISABLED / OBSERVATION_ONLY / ADVISORY / BOUNDED_ACTIVE
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from enum import Enum
from typing import List, Optional, Tuple

NOT_AVAILABLE = "NOT_AVAILABLE"
IMPROVEMENT_SCHEMA_VERSION = "12.6"

# ---------------------------------------------------------------------------
# Operation mode
# ---------------------------------------------------------------------------

class ImprovementMode(str, Enum):
    """
    Operating mode of the Decision Improvement layer.

    DISABLED
        No experience-derived influence.  The existing baseline system
        operates exactly as before.  Phase 12.6 is transparent.

    OBSERVATION_ONLY
        The improvement pipeline runs and produces analysis, but does NOT
        affect the decision output.  Safe for monitoring and debugging.
        DEFAULT MODE.

    ADVISORY
        Experience-informed scoring and ranking is computed and exposed to
        the reasoning system as advisory evidence.  The baseline system may
        use or ignore it.  No automatic decision override.

    BOUNDED_ACTIVE
        Validated, bounded experience influence is applied to candidate
        scoring.  All safety constraints still apply.  Influence is capped
        by maximum_influence configuration.  Safety always wins.

    Mode progression — always conservative by default:
        DISABLED < OBSERVATION_ONLY < ADVISORY < BOUNDED_ACTIVE

    BOUNDED_ACTIVE must only be used when all safety and validation
    requirements are satisfied.  Never enable automatically.
    """
    DISABLED          = "DISABLED"
    OBSERVATION_ONLY  = "OBSERVATION_ONLY"
    ADVISORY          = "ADVISORY"
    BOUNDED_ACTIVE    = "BOUNDED_ACTIVE"


# ---------------------------------------------------------------------------
# Decision improvement outcome
# ---------------------------------------------------------------------------

class ImprovementOutcome(str, Enum):
    """
    Classification of what the improvement pipeline produced.

    IMPROVED    — experience evidence shifted the selected candidate.
    UNCHANGED   — baseline candidate confirmed by experience evidence.
    FALLBACK    — improvement failed or was ineligible; baseline used.
    VETOED      — safety gate rejected the experience-informed candidate.
    OBSERVATION — mode is OBSERVATION_ONLY; no change attempted.
    DISABLED    — mode is DISABLED; pipeline not run.
    ERROR       — unexpected error; baseline used.
    """
    IMPROVED    = "IMPROVED"
    UNCHANGED   = "UNCHANGED"
    FALLBACK    = "FALLBACK"
    VETOED      = "VETOED"
    OBSERVATION = "OBSERVATION"
    DISABLED    = "DISABLED"
    ERROR       = "ERROR"


# ---------------------------------------------------------------------------
# Knowledge eligibility
# ---------------------------------------------------------------------------

class KnowledgeEligibility(str, Enum):
    """
    Eligibility status of a KnowledgeEntry for use in decision improvement.

    ELIGIBLE           — meets all configured criteria.
    LOW_CONFIDENCE     — confidence below minimum_knowledge_confidence.
    INSUFFICIENT_EVIDENCE — evidence count below minimum_evidence_count.
    STALE              — knowledge marked STALE.
    CONFLICTING        — knowledge marked CONFLICTING; uncertain.
    DEPRECATED         — superseded; must not influence decisions.
    REJECTED           — failed validation; must not influence decisions.
    INVALID            — invalid entry; ignored.
    DISABLED           — knowledge use disabled by configuration.
    """
    ELIGIBLE              = "ELIGIBLE"
    LOW_CONFIDENCE        = "LOW_CONFIDENCE"
    INSUFFICIENT_EVIDENCE = "INSUFFICIENT_EVIDENCE"
    STALE                 = "STALE"
    CONFLICTING           = "CONFLICTING"
    DEPRECATED            = "DEPRECATED"
    REJECTED              = "REJECTED"
    INVALID               = "INVALID"
    DISABLED              = "DISABLED"


# ---------------------------------------------------------------------------
# Fallback reason
# ---------------------------------------------------------------------------

class FallbackReason(str, Enum):
    """
    Reason why the improvement pipeline fell back to baseline behavior.

    NONE                — no fallback; improvement applied normally.
    KNOWLEDGE_UNAVAILABLE — no eligible knowledge for current context.
    KNOWLEDGE_STORE_UNAVAILABLE — knowledge store not accessible.
    RETRIEVAL_FAILURE   — Phase 12.4 retrieval failed.
    LOW_CONFIDENCE      — all relevant knowledge below confidence threshold.
    STALE_KNOWLEDGE     — all relevant knowledge is stale.
    CONFLICTING_EVIDENCE — contradictory knowledge; uncertainty too high.
    SAFETY_VETO         — SafetyGate rejected the improved candidate.
    MODE_DISABLED       — ImprovementMode is DISABLED or OBSERVATION_ONLY.
    TIMEOUT             — improvement computation took too long.
    EXCEPTION           — unexpected exception; fallback for safety.
    ROLLBACK            — degradation detected; improvement rolled back.
    """
    NONE                      = "NONE"
    KNOWLEDGE_UNAVAILABLE     = "KNOWLEDGE_UNAVAILABLE"
    KNOWLEDGE_STORE_UNAVAILABLE = "KNOWLEDGE_STORE_UNAVAILABLE"
    RETRIEVAL_FAILURE         = "RETRIEVAL_FAILURE"
    LOW_CONFIDENCE            = "LOW_CONFIDENCE"
    STALE_KNOWLEDGE           = "STALE_KNOWLEDGE"
    CONFLICTING_EVIDENCE      = "CONFLICTING_EVIDENCE"
    SAFETY_VETO               = "SAFETY_VETO"
    MODE_DISABLED             = "MODE_DISABLED"
    TIMEOUT                   = "TIMEOUT"
    EXCEPTION                 = "EXCEPTION"
    ROLLBACK                  = "ROLLBACK"


# ---------------------------------------------------------------------------
# Safety veto result
# ---------------------------------------------------------------------------

class SafetyVetoResult(str, Enum):
    """
    Result of the safety veto check applied to an improved decision.

    APPROVED  — improved candidate passed safety validation.
    VETOED    — SafetyGate rejected the improved candidate; baseline used.
    BYPASSED  — safety veto skipped (mode is OBSERVATION_ONLY or DISABLED).
    UNKNOWN   — safety veto status not yet determined.
    """
    APPROVED  = "APPROVED"
    VETOED    = "VETOED"
    BYPASSED  = "BYPASSED"
    UNKNOWN   = "UNKNOWN"


# ---------------------------------------------------------------------------
# Decision candidate
# ---------------------------------------------------------------------------

@dataclass
class DecisionCandidate:
    """
    One abstract decision candidate with its scoring breakdown.

    candidate_type maps to the existing RequirementType / ResponseFamily
    vocabulary from the arbitration layer.  It is NOT a vehicle command.

    Scoring formula (documented, deterministic):
        final_score = baseline_score + experience_adjustment
        experience_adjustment = experience_support - experience_risk
                                - uncertainty_penalty
        experience_adjustment is clamped to [-maximum_influence, +maximum_influence]

    baseline_score   — score from the existing arbitration engine [0, 1].
    experience_support — positive evidence from similar successful experiences [0, 1].
    experience_risk    — negative evidence from failure / unsafe outcomes [0, 1].
    uncertainty_penalty — applied when knowledge uncertainty is high [0, 1].
    experience_adjustment — net bounded adjustment [-max_influence, +max_influence].
    final_score      — baseline_score + experience_adjustment, clamped to [0, 1].
    """
    candidate_id: str = NOT_AVAILABLE
    candidate_type: str = NOT_AVAILABLE        # RequirementType.value or ResponseFamily.value
    description: str = NOT_AVAILABLE

    baseline_score: float = 0.0               # [0, 1] from existing arbitration
    experience_support: float = 0.0           # [0, 1] positive evidence
    experience_risk: float = 0.0              # [0, 1] negative evidence
    uncertainty_penalty: float = 0.0          # [0, 1] confidence penalty
    experience_adjustment: float = 0.0        # bounded net adjustment
    final_score: float = 0.0                  # baseline + adjustment, clamped [0, 1]

    # Evidence links
    knowledge_ids: Tuple[str, ...] = field(default_factory=tuple)
    experience_ids: Tuple[str, ...] = field(default_factory=tuple)
    eligibility: KnowledgeEligibility = KnowledgeEligibility.DISABLED

    is_baseline: bool = False                  # True = this is the unadjusted baseline
    is_experience_improved: bool = False       # True = adjustment was non-zero
    safety_veto: SafetyVetoResult = SafetyVetoResult.UNKNOWN


# ---------------------------------------------------------------------------
# Decision improvement context
# ---------------------------------------------------------------------------

@dataclass
class DecisionImprovementContext:
    """
    Structured context enriched with experience-derived knowledge signals.

    This context is passed into the existing reasoning / arbitration layer
    as ADDITIONAL ADVISORY information.  It does NOT replace any existing
    input to the arbitration engine.

    Safety gates and arbitration remain unchanged.
    The context must never be used to bypass SafetyGate.

    Fields
    ------
    context_id        — unique ID for this improvement context.
    session_id        — session this context belongs to.
    timestamp         — generation timestamp.
    schema_version    — always "12.6".

    current_situation — situation_type from the existing reasoning engine.
    safety_gate_state — current SafetyGateState (from existing arbitration).
                        NEVER modified by Phase 12.6.

    relevant_knowledge — knowledge_ids of eligible KnowledgeEntry objects.
    relevant_experiences — experience_ids of retrieved similar experiences.
    knowledge_confidence — average confidence of eligible knowledge.
    knowledge_status   — status labels of relevant knowledge entries.

    decision_candidates — ranked list of DecisionCandidate objects.
    supporting_evidence — summary of evidence used.

    improvement_mode   — current ImprovementMode.
    uncertainty        — overall uncertainty of the improvement context.
    degraded           — True if improvement quality is reduced.
    fallback_reason    — why fallback was triggered (NONE if not triggered).
    """
    context_id: str = NOT_AVAILABLE
    session_id: str = NOT_AVAILABLE
    timestamp: float = field(default_factory=time.time)
    schema_version: str = IMPROVEMENT_SCHEMA_VERSION

    # Current state (from existing pipeline — never modified here)
    current_situation: str = NOT_AVAILABLE
    safety_gate_state: str = NOT_AVAILABLE      # SafetyGateState.value — read-only

    # Knowledge signals (from Phase 12.5)
    relevant_knowledge: Tuple[str, ...] = field(default_factory=tuple)
    relevant_experiences: Tuple[str, ...] = field(default_factory=tuple)
    knowledge_confidence: float = 0.0
    knowledge_status: Tuple[str, ...] = field(default_factory=tuple)

    # Decision candidates (enriched with experience evidence)
    decision_candidates: Tuple[DecisionCandidate, ...] = field(default_factory=tuple)
    supporting_evidence: str = NOT_AVAILABLE

    # Improvement metadata
    improvement_mode: ImprovementMode = ImprovementMode.OBSERVATION_ONLY
    uncertainty: float = 0.0
    degraded: bool = False
    fallback_reason: FallbackReason = FallbackReason.NONE


# ---------------------------------------------------------------------------
# Decision improvement result
# ---------------------------------------------------------------------------

@dataclass
class DecisionImprovementResult:
    """
    Final output of the Phase 12.6 improvement pipeline for one cycle.

    Always contains:
    - baseline_decision (the original arbitration output)
    - final_decision    (same as baseline if no improvement or safety veto)
    - outcome           (what the pipeline produced)
    - explanation       (human-readable rationale)

    The final_decision is always a RequirementType.value or ResponseFamily.value
    from the existing arbitration vocabulary.  Never a vehicle command.

    Audit fields allow the full pipeline to be reconstructed from this record.
    """
    decision_id: str = NOT_AVAILABLE
    session_id: str = NOT_AVAILABLE
    timestamp: float = field(default_factory=time.time)
    schema_version: str = IMPROVEMENT_SCHEMA_VERSION

    # Input context
    context_id: str = NOT_AVAILABLE
    current_situation: str = NOT_AVAILABLE
    safety_gate_state: str = NOT_AVAILABLE      # from existing arbitration

    # Decisions
    baseline_decision: str = NOT_AVAILABLE      # RequirementType / ResponseFamily
    baseline_score: float = 0.0
    candidate_decision: str = NOT_AVAILABLE     # experience-informed candidate
    candidate_score: float = 0.0
    final_decision: str = NOT_AVAILABLE         # safety-validated final output
    final_score: float = 0.0

    # Improvement
    experience_adjustment: float = 0.0
    outcome: ImprovementOutcome = ImprovementOutcome.FALLBACK
    fallback_used: bool = True
    fallback_reason: FallbackReason = FallbackReason.KNOWLEDGE_UNAVAILABLE
    safety_veto: SafetyVetoResult = SafetyVetoResult.UNKNOWN

    # Evidence
    knowledge_ids: Tuple[str, ...] = field(default_factory=tuple)
    experience_ids: Tuple[str, ...] = field(default_factory=tuple)
    knowledge_confidence: float = 0.0

    # Explanation (human-readable)
    explanation: str = NOT_AVAILABLE
    reason_codes: Tuple[str, ...] = field(default_factory=tuple)

    # Quality
    degraded: bool = False
    error: Optional[str] = None


# ---------------------------------------------------------------------------
# Audit record
# ---------------------------------------------------------------------------

@dataclass
class DecisionImprovementRecord:
    """
    Append-only audit record for one improvement cycle.

    Fields map directly to DecisionImprovementResult for traceability.
    Phase 12.3 can later evaluate the outcome via experience_id linkage.
    """
    record_id: str = NOT_AVAILABLE
    decision_id: str = NOT_AVAILABLE
    session_id: str = NOT_AVAILABLE
    timestamp: float = field(default_factory=time.time)
    schema_version: str = IMPROVEMENT_SCHEMA_VERSION

    current_situation_id: str = NOT_AVAILABLE

    baseline_decision: str = NOT_AVAILABLE
    candidate_decision: str = NOT_AVAILABLE
    final_decision: str = NOT_AVAILABLE

    baseline_score: float = 0.0
    experience_adjustment: float = 0.0
    final_score: float = 0.0

    safety_gate_state: str = NOT_AVAILABLE
    safety_veto: SafetyVetoResult = SafetyVetoResult.UNKNOWN

    outcome: ImprovementOutcome = ImprovementOutcome.FALLBACK
    decision_mode: ImprovementMode = ImprovementMode.OBSERVATION_ONLY
    knowledge_confidence: float = 0.0

    knowledge_ids: Tuple[str, ...] = field(default_factory=tuple)
    experience_ids: Tuple[str, ...] = field(default_factory=tuple)

    reason_codes: Tuple[str, ...] = field(default_factory=tuple)
    fallback_used: bool = True
    degraded: bool = False


# ---------------------------------------------------------------------------
# Monitoring counters
# ---------------------------------------------------------------------------

@dataclass
class ImprovementMonitor:
    """
    Running counters for decision improvement effectiveness monitoring.

    Used to detect degradation and trigger rollback policy.
    Intended for inspection by health monitoring, not for direct decision use.
    """
    improvement_used_count: int = 0
    baseline_fallback_count: int = 0
    safety_veto_count: int = 0
    knowledge_rejected_count: int = 0
    knowledge_conflict_count: int = 0
    degraded_decision_count: int = 0
    observation_only_count: int = 0
    total_cycles: int = 0

    def record(self, result: "DecisionImprovementResult") -> None:
        self.total_cycles += 1
        if result.outcome == ImprovementOutcome.IMPROVED:
            self.improvement_used_count += 1
        if result.fallback_used:
            self.baseline_fallback_count += 1
        if result.safety_veto == SafetyVetoResult.VETOED:
            self.safety_veto_count += 1
        if result.outcome == ImprovementOutcome.OBSERVATION:
            self.observation_only_count += 1
        if result.degraded:
            self.degraded_decision_count += 1
        if result.fallback_reason == FallbackReason.CONFLICTING_EVIDENCE:
            self.knowledge_conflict_count += 1

    def to_dict(self) -> dict:
        return {
            "improvement_used_count": self.improvement_used_count,
            "baseline_fallback_count": self.baseline_fallback_count,
            "safety_veto_count": self.safety_veto_count,
            "knowledge_rejected_count": self.knowledge_rejected_count,
            "knowledge_conflict_count": self.knowledge_conflict_count,
            "degraded_decision_count": self.degraded_decision_count,
            "observation_only_count": self.observation_only_count,
            "total_cycles": self.total_cycles,
        }


# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

@dataclass
class ImprovementConfig:
    """
    All tunable parameters for Phase 12.6 Decision Improvement.

    All values are configurable.  No arbitrary values are hard-coded
    without documented justification.

    mode
        Default: OBSERVATION_ONLY.
        Justification: conservative default — improvement must be explicitly
        enabled. BOUNDED_ACTIVE must only be enabled with full validation.

    minimum_knowledge_confidence
        Default: 0.50 (MODERATE).
        Justification: LOW confidence knowledge should not influence decisions
        in a safety-critical system. MODERATE requires meaningful evidence.

    minimum_evidence_count
        Default: 3.
        Justification: consistent with Phase 12.5 default; single-observation
        knowledge should not influence decisions.

    maximum_influence
        Default: 0.10.
        Justification: experience adjustment is bounded to ±0.10 on the [0,1]
        baseline score. This prevents knowledge from overriding the baseline
        decision system. Must be < 0.5 to maintain baseline dominance.

    allow_negative_evidence
        Default: True.
        Justification: negative evidence (failure/unsafe patterns) is useful
        risk signal. Discarding it would reduce safety awareness.

    allow_conflicting_knowledge
        Default: False.
        Justification: CONFLICTING knowledge has unresolved contradictions.
        Allowing it to influence decisions would introduce noise.

    stale_knowledge_policy
        "exclude" (default) | "penalize" | "allow"
        Justification: stale knowledge may no longer reflect current reality.
        Excluding is the safe default.

    fallback_to_baseline
        Default: True.
        Must always be True. Disabling fallback is not safe and will be
        enforced regardless of config value.

    safety_required
        Default: True.
        Must always be True. Disabling safety validation is not safe and
        will be enforced regardless of config value.

    rollback_degradation_threshold
        Default: 0.20.
        If the ratio of degraded decisions to total decisions exceeds this
        threshold, the improvement mode is rolled back to OBSERVATION_ONLY.

    indian_road_context_aware
        Default: True.
        Enables additional scrutiny for mixed-traffic Indian road scenarios
        (pedestrians, motorcycles, cattle, auto-rickshaws, narrow roads,
        unmarked roads, dense intersections).
    """
    enabled: bool = True
    mode: ImprovementMode = ImprovementMode.OBSERVATION_ONLY

    # Evidence thresholds
    minimum_knowledge_confidence: float = 0.50
    minimum_evidence_count: int = 3

    # Bounded influence
    maximum_influence: float = 0.10       # must be in (0.0, 0.5]

    # Evidence policy
    allow_negative_evidence: bool = True
    allow_conflicting_knowledge: bool = False
    stale_knowledge_policy: str = "exclude"   # "exclude" | "penalize" | "allow"

    # Safety
    fallback_to_baseline: bool = True    # always enforced True
    safety_required: bool = True         # always enforced True

    # Rollback
    rollback_degradation_threshold: float = 0.20

    # Indian road context awareness
    indian_road_context_aware: bool = True

    @staticmethod
    def default() -> "ImprovementConfig":
        return ImprovementConfig()

    @staticmethod
    def observation_only() -> "ImprovementConfig":
        return ImprovementConfig(mode=ImprovementMode.OBSERVATION_ONLY)

    @staticmethod
    def advisory() -> "ImprovementConfig":
        return ImprovementConfig(
            mode=ImprovementMode.ADVISORY,
            minimum_knowledge_confidence=0.55,
        )

    @staticmethod
    def bounded_active(maximum_influence: float = 0.08) -> "ImprovementConfig":
        """
        Bounded active mode — must only be used with full validation.
        influence is capped at 0.08 by default (well below 0.5).
        """
        assert 0.0 < maximum_influence <= 0.5, \
            "maximum_influence must be in (0, 0.5]"
        return ImprovementConfig(
            mode=ImprovementMode.BOUNDED_ACTIVE,
            maximum_influence=maximum_influence,
            minimum_knowledge_confidence=0.60,
            minimum_evidence_count=4,
        )

    def effective_fallback(self) -> bool:
        """Fallback is always True regardless of config setting."""
        return True

    def effective_safety_required(self) -> bool:
        """Safety is always required regardless of config setting."""
        return True


__all__ = [
    "NOT_AVAILABLE",
    "IMPROVEMENT_SCHEMA_VERSION",
    "ImprovementMode",
    "ImprovementOutcome",
    "KnowledgeEligibility",
    "FallbackReason",
    "SafetyVetoResult",
    "DecisionCandidate",
    "DecisionImprovementContext",
    "DecisionImprovementResult",
    "DecisionImprovementRecord",
    "ImprovementMonitor",
    "ImprovementConfig",
]
