"""
IndiDrive AI — Phase 12.6 | Safety Veto
========================================
Enforces safety authority over all experience-derived decision improvements.

Safety is NON-NEGOTIABLE.
This module is the last gate before an experience-informed decision
is accepted as the final decision.

Rules (all enforced unconditionally):
  1. If SafetyGateState is CRITICAL or HIGH_ALERT → VETO any non-safe candidate.
  2. If SafetyGateState is RESTRICTED → VETO if candidate reduces safety level.
  3. If the improved candidate would require bypassing any hard safety constraint
     → VETO and use baseline.
  4. If safety_required=False in config → still enforce (override the config).
  5. This module NEVER modifies SafetyGateState.
  6. This module NEVER modifies collision thresholds or safety margins.
  7. This module NEVER disables SafetyGate behavior.

The veto logic is stateless and deterministic.
"""
from __future__ import annotations

import logging
from typing import Tuple

from .improvement_types import (
    DecisionCandidate,
    FallbackReason,
    SafetyVetoResult,
)

log = logging.getLogger(__name__)

# SafetyGateState values (strings) that require veto of non-conservative candidates
_CRITICAL_STATES = frozenset({"CRITICAL", "HIGH_ALERT"})
_RESTRICTED_STATES = frozenset({"RESTRICTED", "DEGRADED"})

# Candidate types (RequirementType / ResponseFamily) considered safety-conservative.
# These will never be vetoed by this module regardless of gate state.
_CONSERVATIVE_CANDIDATES = frozenset({
    "COLLISION_AVOIDANCE_REQUIRED",
    "SAFETY_CRITICAL",
    "HANDLE_UNCERTAINTY",
    "DEGRADED_OPERATION",
    "EMERGENCY_STOP",
    "DEGRADED",
})


def veto_check(
    gate_state: str,
    baseline_candidate: DecisionCandidate,
    improved_candidate: DecisionCandidate,
) -> Tuple[SafetyVetoResult, str, DecisionCandidate]:
    """
    Apply the safety veto to an improved decision candidate.

    Parameters
    ----------
    gate_state           : SafetyGateState.value (read-only; never modified)
    baseline_candidate   : the original arbitration candidate
    improved_candidate   : the experience-adjusted candidate

    Returns
    -------
    (SafetyVetoResult, reason_str, selected_candidate)
        If APPROVED → selected_candidate = improved_candidate
        If VETOED   → selected_candidate = baseline_candidate
    """
    try:
        return _veto_inner(gate_state, baseline_candidate, improved_candidate)
    except Exception as exc:  # noqa: BLE001
        log.exception("veto_check: unexpected error: %s", exc)
        # Safety: always fall back to baseline on error
        baseline_candidate.safety_veto = SafetyVetoResult.VETOED
        return (
            SafetyVetoResult.VETOED,
            f"safety_veto_error: {exc}",
            baseline_candidate,
        )


def _veto_inner(
    gate_state: str,
    baseline: DecisionCandidate,
    improved: DecisionCandidate,
) -> Tuple[SafetyVetoResult, str, DecisionCandidate]:
    gate = gate_state.upper() if gate_state else "UNKNOWN"

    # Rule 1: CRITICAL or HIGH_ALERT — only conservative candidates pass
    if gate in _CRITICAL_STATES:
        if improved.candidate_type.upper() not in _CONSERVATIVE_CANDIDATES:
            reason = (
                f"SAFETY_VETO: gate={gate} requires safety-conservative "
                f"decision; {improved.candidate_type} not approved"
            )
            log.warning(reason)
            baseline.safety_veto = SafetyVetoResult.VETOED
            improved.safety_veto = SafetyVetoResult.VETOED
            return SafetyVetoResult.VETOED, reason, baseline

    # Rule 2: RESTRICTED or DEGRADED — veto if improved score is lower than baseline
    # (experience improvement should not degrade the safety-driven decision)
    if gate in _RESTRICTED_STATES:
        if improved.final_score < baseline.baseline_score - 0.05:
            reason = (
                f"SAFETY_VETO: gate={gate} restricts planning; "
                f"improved score {improved.final_score:.3f} < "
                f"baseline {baseline.baseline_score:.3f}"
            )
            log.warning(reason)
            baseline.safety_veto = SafetyVetoResult.VETOED
            improved.safety_veto = SafetyVetoResult.VETOED
            return SafetyVetoResult.VETOED, reason, baseline

    # Rule 3: UNKNOWN gate — conservative; approve only if candidate is conservative
    if gate == "UNKNOWN":
        if improved.candidate_type.upper() not in _CONSERVATIVE_CANDIDATES:
            reason = "SAFETY_VETO: gate=UNKNOWN; only conservative candidates approved"
            log.warning(reason)
            baseline.safety_veto = SafetyVetoResult.VETOED
            improved.safety_veto = SafetyVetoResult.VETOED
            return SafetyVetoResult.VETOED, reason, baseline

    # All veto rules passed — approve
    improved.safety_veto = SafetyVetoResult.APPROVED
    reason = f"SAFETY_APPROVED: gate={gate}, candidate={improved.candidate_type}"
    return SafetyVetoResult.APPROVED, reason, improved
