"""
IndiDrive AI — Phase 12.6 | Experience Scorer
==============================================
Computes bounded, deterministic experience-adjustment scores for
decision candidates using Phase 12.5 knowledge.

Scoring model (documented, deterministic)
-----------------------------------------
For each eligible KnowledgeEntry k relevant to a decision candidate c:

    success_ratio_k = success_evidence_count / valid_evidence_count
    failure_ratio_k = (failure_count + unsafe_count) / valid_evidence_count

    support_signal_k  = success_ratio_k × k.confidence × (1 - penalty_k)
    risk_signal_k     = failure_ratio_k × k.confidence

    uncertainty_penalty_k = k.uncertainty × 0.5

Per candidate (averaging across K eligible knowledge entries):
    experience_support  = mean(support_signal_k)
    experience_risk     = mean(risk_signal_k)
    uncertainty_penalty = mean(uncertainty_penalty_k)

    raw_adjustment = experience_support - experience_risk - uncertainty_penalty
    experience_adjustment = clamp(raw_adjustment,
                                  -maximum_influence, +maximum_influence)

    final_score = clamp(baseline_score + experience_adjustment, 0.0, 1.0)

Design rules:
  * deterministic: same inputs → same output
  * bounded: |experience_adjustment| ≤ maximum_influence always
  * no vehicle commands: output is score deltas, not actuator values
  * negative evidence: FAILURE/UNSAFE reduces support_signal via failure_ratio
  * uncertainty: high knowledge uncertainty reduces both support and risk signals
  * Indian road context: additional risk weighting for pedestrian/cattle/VRU
                         scenarios when indian_road_context_aware is True

Safety invariants:
  * This scorer never modifies safety thresholds
  * This scorer never outputs vehicle commands
  * SafetyGateState is read-only here; it is never written or overridden
"""
from __future__ import annotations

import logging
from typing import List, Optional, Tuple

from ..knowledge.knowledge_types import KnowledgeEntrySnapshot, KnowledgeStatus
from .improvement_types import (
    NOT_AVAILABLE,
    DecisionCandidate,
    ImprovementConfig,
    KnowledgeEligibility,
    SafetyVetoResult,
)
from .knowledge_filter import compute_confidence_penalty

log = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Indian road context risk tags
# ---------------------------------------------------------------------------
# When indian_road_context_aware is True, if the knowledge context matches
# one of these high-risk tags, the risk_signal is amplified by INDIAN_RISK_FACTOR.
# This is purely a scoring signal — it does not change any safety parameter.
INDIAN_HIGH_RISK_TAGS = frozenset({
    "PEDESTRIAN", "PEDESTRIAN_CROSSING", "VRU", "VULNERABLE_ROAD_USER",
    "CATTLE", "CATTLE_CROSSING", "AUTO_RICKSHAW", "NARROW_ROAD",
    "UNMARKED_ROAD", "POTHOLE", "DENSE_INTERSECTION", "BUS_STOP",
    "MOTORCYCLE_CUT_IN",
})
INDIAN_RISK_FACTOR = 1.25  # amplify risk signal for high-risk Indian road scenarios


def _clamp(v: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, v))


def _is_indian_high_risk(snap: KnowledgeEntrySnapshot) -> bool:
    """Check if the knowledge context is a high-risk Indian road scenario."""
    context_str = (
        snap.context_key.situation_type.upper()
        + " " + snap.context_key.dominant_hazard.upper()
        + " " + snap.context_key.road_type.upper()
    )
    return any(tag in context_str for tag in INDIAN_HIGH_RISK_TAGS)


def score_candidate(
    candidate_type: str,
    baseline_score: float,
    eligible_knowledge: List[KnowledgeEntrySnapshot],
    config: ImprovementConfig,
    candidate_seq: int = 0,
) -> DecisionCandidate:
    """
    Compute a DecisionCandidate with experience-adjusted scoring.

    Parameters
    ----------
    candidate_type  : RequirementType.value or ResponseFamily.value
    baseline_score  : score from the existing arbitration engine [0, 1]
    eligible_knowledge : list of eligible KnowledgeEntrySnapshot objects
    config          : ImprovementConfig
    candidate_seq   : sequence number for candidate ID generation

    Returns
    -------
    DecisionCandidate with fully populated scoring fields
    """
    cid = f"CAND126-{candidate_type[:8].upper()}-{candidate_seq:04d}"

    if not eligible_knowledge:
        # No knowledge available — return baseline unchanged
        return DecisionCandidate(
            candidate_id=cid,
            candidate_type=candidate_type,
            description=f"Baseline: {candidate_type} (no experience evidence)",
            baseline_score=round(baseline_score, 6),
            experience_support=0.0,
            experience_risk=0.0,
            uncertainty_penalty=0.0,
            experience_adjustment=0.0,
            final_score=round(_clamp(baseline_score, 0.0, 1.0), 6),
            knowledge_ids=(),
            experience_ids=(),
            eligibility=KnowledgeEligibility.DISABLED,
            is_baseline=True,
            is_experience_improved=False,
            safety_veto=SafetyVetoResult.UNKNOWN,
        )

    support_signals: List[float] = []
    risk_signals: List[float] = []
    uncertainty_penalties: List[float] = []
    k_ids: List[str] = []
    e_ids: List[str] = []

    for snap in eligible_knowledge:
        v = max(1, snap.valid_evidence_count)
        success_ratio = snap.success_evidence_count / v
        neg_count = snap.failure_evidence_count + snap.unsafe_evidence_count
        failure_ratio = neg_count / v

        penalty = compute_confidence_penalty(snap, config)
        support_k = success_ratio * snap.confidence * (1.0 - penalty)

        risk_k = failure_ratio * snap.confidence
        # Amplify risk for Indian high-risk contexts
        if config.indian_road_context_aware and _is_indian_high_risk(snap):
            risk_k = min(1.0, risk_k * INDIAN_RISK_FACTOR)

        uncertainty_k = snap.uncertainty * 0.5

        support_signals.append(support_k)
        risk_signals.append(risk_k)
        uncertainty_penalties.append(uncertainty_k)
        k_ids.append(snap.knowledge_id)
        e_ids.extend(list(snap.supporting_experience_ids)[:5])  # compact

    n = len(support_signals)
    exp_support = sum(support_signals) / n
    exp_risk = sum(risk_signals) / n
    uncertainty_penalty = sum(uncertainty_penalties) / n

    raw_adjustment = exp_support - exp_risk - uncertainty_penalty
    max_inf = _clamp(config.maximum_influence, 0.0, 0.5)
    experience_adjustment = _clamp(raw_adjustment, -max_inf, max_inf)
    final_score = _clamp(baseline_score + experience_adjustment, 0.0, 1.0)

    is_improved = abs(experience_adjustment) > 1e-6

    desc = (
        f"{candidate_type}: baseline={baseline_score:.3f} "
        f"support={exp_support:.3f} risk={exp_risk:.3f} "
        f"adj={experience_adjustment:+.4f} final={final_score:.3f}"
    )

    return DecisionCandidate(
        candidate_id=cid,
        candidate_type=candidate_type,
        description=desc,
        baseline_score=round(baseline_score, 6),
        experience_support=round(exp_support, 6),
        experience_risk=round(exp_risk, 6),
        uncertainty_penalty=round(uncertainty_penalty, 6),
        experience_adjustment=round(experience_adjustment, 6),
        final_score=round(final_score, 6),
        knowledge_ids=tuple(k_ids),
        experience_ids=tuple(dict.fromkeys(e_ids))[:20],
        eligibility=KnowledgeEligibility.ELIGIBLE,
        is_baseline=False,
        is_experience_improved=is_improved,
        safety_veto=SafetyVetoResult.UNKNOWN,
    )


def score_baseline(
    candidate_type: str,
    baseline_score: float,
    candidate_seq: int = 0,
) -> DecisionCandidate:
    """Return a DecisionCandidate representing the unmodified baseline."""
    cid = f"BL126-{candidate_type[:8].upper()}-{candidate_seq:04d}"
    return DecisionCandidate(
        candidate_id=cid,
        candidate_type=candidate_type,
        description=f"Baseline (unmodified): {candidate_type}",
        baseline_score=round(baseline_score, 6),
        experience_support=0.0,
        experience_risk=0.0,
        uncertainty_penalty=0.0,
        experience_adjustment=0.0,
        final_score=round(_clamp(baseline_score, 0.0, 1.0), 6),
        knowledge_ids=(),
        experience_ids=(),
        eligibility=KnowledgeEligibility.DISABLED,
        is_baseline=True,
        is_experience_improved=False,
        safety_veto=SafetyVetoResult.UNKNOWN,
    )
