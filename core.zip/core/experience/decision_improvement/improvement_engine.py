"""
IndiDrive AI — Phase 12.6 | Decision Improvement Engine
========================================================
Orchestrates the full Phase 12.6 Experience-Driven Decision Improvement pipeline:

    1. Receive current situation + baseline decision + safety gate state
    2. Retrieve relevant knowledge from Phase 12.5 KnowledgeStore
    3. Filter knowledge for eligibility
    4. Score decision candidates with bounded experience adjustment
    5. Apply safety veto (safety always wins)
    6. Fall back to baseline if any condition fails
    7. Return DecisionImprovementResult + record audit

Critical safety invariants:
  * This engine NEVER modifies SafetyGateState
  * This engine NEVER modifies collision/safety thresholds
  * This engine NEVER bypasses SafetyGate
  * This engine NEVER directly controls vehicle actuators
  * This engine NEVER replaces the existing planner or reasoning engine
  * All adjustments are bounded by maximum_influence
  * Fallback to baseline is ALWAYS available
  * On any exception, baseline is used and error is logged
  * OBSERVATION_ONLY and DISABLED modes produce no decision changes

Closed-loop connection to Phase 12.3:
  * DecisionImprovementRecord links to experience_ids
  * Phase 12.3 outcome evaluator can later assess improvement effectiveness
  * Phase 12.5 knowledge update engine receives new experiences from those evaluations
  * This creates the controlled adaptive loop without uncontrolled amplification

Rollback:
  * ImprovementMonitor tracks degraded_decision_count / total_cycles
  * If degradation ratio > rollback_degradation_threshold,
    mode is downgraded to OBSERVATION_ONLY automatically
  * Rollback never disables safety
"""
from __future__ import annotations

import hashlib
import logging
import threading
import time
from typing import Dict, List, Optional, Tuple

from ..knowledge.knowledge_types import (
    KnowledgeEntrySnapshot,
    KnowledgeStatus,
)
from .improvement_types import (
    NOT_AVAILABLE,
    IMPROVEMENT_SCHEMA_VERSION,
    DecisionCandidate,
    DecisionImprovementContext,
    DecisionImprovementRecord,
    DecisionImprovementResult,
    FallbackReason,
    ImprovementConfig,
    ImprovementMode,
    ImprovementMonitor,
    ImprovementOutcome,
    KnowledgeEligibility,
    SafetyVetoResult,
)
from .knowledge_filter import filter_knowledge
from .experience_scorer import score_candidate, score_baseline
from .safety_veto import veto_check

log = logging.getLogger(__name__)


def _make_decision_id(session_id: str) -> str:
    ts_hex = hex(int(time.time() * 1000) & 0xFFFFFFFFFF)[2:].upper()
    return f"DI126-{session_id[:8].upper()}-{ts_hex}"


def _make_record_id(decision_id: str) -> str:
    return f"{decision_id}-REC"


def _make_context_id(session_id: str) -> str:
    ts_hex = hex(int(time.time() * 1000) & 0xFFFFFFFF)[2:].upper()
    return f"CTX126-{session_id[:8].upper()}-{ts_hex}"


def _build_explanation(result: DecisionImprovementResult) -> str:
    """Build a human-readable explanation for the improvement decision."""
    lines = [
        f"Decision: {result.final_decision}",
        f"Baseline: {result.baseline_decision} (score={result.baseline_score:.3f})",
    ]
    if result.outcome == ImprovementOutcome.IMPROVED:
        lines.append(
            f"Experience evidence: knowledge={len(result.knowledge_ids)} entries, "
            f"confidence={result.knowledge_confidence:.3f}"
        )
        lines.append(f"Experience adjustment: {result.experience_adjustment:+.4f}")
        lines.append(f"Final score: {result.final_score:.3f}")
        lines.append(f"Safety: {result.safety_veto.value}")
    elif result.outcome == ImprovementOutcome.VETOED:
        lines.append(f"Safety veto: {result.safety_veto.value}")
        lines.append(f"Gate state: {result.safety_gate_state}")
        lines.append("Baseline retained by safety authority.")
    elif result.outcome == ImprovementOutcome.FALLBACK:
        lines.append(f"Fallback reason: {result.fallback_reason.value}")
        lines.append("Baseline decision used.")
    elif result.outcome == ImprovementOutcome.OBSERVATION:
        lines.append("Mode: OBSERVATION_ONLY — analysis performed, no change applied.")
    elif result.outcome == ImprovementOutcome.DISABLED:
        lines.append("Mode: DISABLED — experience improvement not active.")
    elif result.outcome == ImprovementOutcome.UNCHANGED:
        lines.append("Experience evidence confirmed baseline decision; no change.")

    if result.reason_codes:
        lines.append(f"Reason codes: {', '.join(result.reason_codes)}")
    return "\n".join(lines)


class DecisionImprovementEngine:
    """
    Phase 12.6 Decision Improvement Engine.

    This engine extends the existing decision pipeline with experience-derived
    scoring.  It does NOT replace any existing subsystem.

    Usage
    -----
    engine = DecisionImprovementEngine(config, knowledge_store)

    result = engine.improve(
        session_id        = "session-001",
        current_situation = "PEDESTRIAN_CROSSING",
        safety_gate_state = "CAUTION",           # from existing arbitration
        baseline_decision = "NORMAL_PROGRESS",   # RequirementType / ResponseFamily
        baseline_score    = 0.75,                # from existing arbitration
        context_key_dict  = {...},               # KnowledgeContextKey.to_dict()
    )

    The result always contains a valid final_decision.
    On any failure, fallback_used=True and final_decision = baseline_decision.
    """

    def __init__(
        self,
        config: Optional[ImprovementConfig] = None,
        knowledge_store: Optional[object] = None,
    ) -> None:
        self._config = config or ImprovementConfig.default()
        self._store = knowledge_store   # KnowledgeStore from Phase 12.5 (or None)
        self._monitor = ImprovementMonitor()
        self._audit_log: List[DecisionImprovementRecord] = []
        self._lock = threading.RLock()
        self._rollback_active = False

        log.debug(
            "DecisionImprovementEngine init: mode=%s max_influence=%.3f",
            self._config.mode.value, self._config.maximum_influence,
        )

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    @property
    def config(self) -> ImprovementConfig:
        return self._config

    @property
    def monitor(self) -> ImprovementMonitor:
        with self._lock:
            return self._monitor

    def get_audit_log(self) -> Tuple[DecisionImprovementRecord, ...]:
        with self._lock:
            return tuple(self._audit_log)

    def rollback_to_observation(self, reason: str = "manual") -> None:
        """
        Roll back the improvement mode to OBSERVATION_ONLY.
        This preserves all safety behavior unchanged.
        """
        with self._lock:
            if self._config.mode == ImprovementMode.BOUNDED_ACTIVE:
                log.warning("rollback: downgrading BOUNDED_ACTIVE → OBSERVATION_ONLY (%s)",
                            reason)
                self._config = ImprovementConfig(
                    enabled=self._config.enabled,
                    mode=ImprovementMode.OBSERVATION_ONLY,
                    minimum_knowledge_confidence=self._config.minimum_knowledge_confidence,
                    minimum_evidence_count=self._config.minimum_evidence_count,
                    maximum_influence=self._config.maximum_influence,
                    allow_negative_evidence=self._config.allow_negative_evidence,
                    allow_conflicting_knowledge=self._config.allow_conflicting_knowledge,
                    stale_knowledge_policy=self._config.stale_knowledge_policy,
                    fallback_to_baseline=True,
                    safety_required=True,
                    rollback_degradation_threshold=self._config.rollback_degradation_threshold,
                    indian_road_context_aware=self._config.indian_road_context_aware,
                )
                self._rollback_active = True

    def improve(
        self,
        session_id: str = NOT_AVAILABLE,
        current_situation: str = NOT_AVAILABLE,
        safety_gate_state: str = "UNKNOWN",
        baseline_decision: str = NOT_AVAILABLE,
        baseline_score: float = 0.5,
        context_key_dict: Optional[Dict] = None,
    ) -> DecisionImprovementResult:
        """
        Run the decision improvement pipeline for one decision cycle.

        Parameters
        ----------
        session_id          : driving session identifier
        current_situation   : situation_type from existing reasoning
        safety_gate_state   : SafetyGateState.value from existing arbitration
                              (NEVER modified here)
        baseline_decision   : RequirementType.value or ResponseFamily.value
                              from existing arbitration
        baseline_score      : confidence/priority score from arbitration [0, 1]
        context_key_dict    : KnowledgeContextKey.to_dict() for knowledge lookup

        Returns
        -------
        DecisionImprovementResult — always valid, never raises.
        final_decision is always set; fallback_used=True if baseline was used.
        """
        try:
            result = self._improve_inner(
                session_id, current_situation, safety_gate_state,
                baseline_decision, baseline_score, context_key_dict or {},
            )
        except Exception as exc:  # noqa: BLE001
            log.exception("improve: unexpected error: %s", exc)
            result = self._make_fallback_result(
                session_id=session_id,
                current_situation=current_situation,
                safety_gate_state=safety_gate_state,
                baseline_decision=baseline_decision,
                baseline_score=baseline_score,
                reason=FallbackReason.EXCEPTION,
                error=str(exc),
            )

        # Check rollback trigger
        self._check_rollback(result)

        # Audit
        with self._lock:
            self._monitor.record(result)
            record = DecisionImprovementRecord(
                record_id=_make_record_id(result.decision_id),
                decision_id=result.decision_id,
                session_id=result.session_id,
                timestamp=result.timestamp,
                schema_version=IMPROVEMENT_SCHEMA_VERSION,
                current_situation_id=current_situation,
                baseline_decision=result.baseline_decision,
                candidate_decision=result.candidate_decision,
                final_decision=result.final_decision,
                baseline_score=result.baseline_score,
                experience_adjustment=result.experience_adjustment,
                final_score=result.final_score,
                safety_gate_state=result.safety_gate_state,
                safety_veto=result.safety_veto,
                outcome=result.outcome,
                decision_mode=self._config.mode,
                knowledge_confidence=result.knowledge_confidence,
                knowledge_ids=result.knowledge_ids,
                experience_ids=result.experience_ids,
                reason_codes=result.reason_codes,
                fallback_used=result.fallback_used,
                degraded=result.degraded,
            )
            self._audit_log.append(record)

        return result

    # ------------------------------------------------------------------
    # Internal pipeline
    # ------------------------------------------------------------------

    def _improve_inner(
        self,
        session_id: str,
        current_situation: str,
        safety_gate_state: str,
        baseline_decision: str,
        baseline_score: float,
        context_key_dict: Dict,
    ) -> DecisionImprovementResult:
        cfg = self._config
        now = time.time()
        decision_id = _make_decision_id(session_id)

        # Step 0: DISABLED mode
        if not cfg.enabled or cfg.mode == ImprovementMode.DISABLED:
            return DecisionImprovementResult(
                decision_id=decision_id,
                session_id=session_id,
                timestamp=now,
                schema_version=IMPROVEMENT_SCHEMA_VERSION,
                context_id=NOT_AVAILABLE,
                current_situation=current_situation,
                safety_gate_state=safety_gate_state,
                baseline_decision=baseline_decision,
                baseline_score=round(baseline_score, 6),
                candidate_decision=baseline_decision,
                candidate_score=round(baseline_score, 6),
                final_decision=baseline_decision,
                final_score=round(baseline_score, 6),
                experience_adjustment=0.0,
                outcome=ImprovementOutcome.DISABLED,
                fallback_used=True,
                fallback_reason=FallbackReason.MODE_DISABLED,
                safety_veto=SafetyVetoResult.BYPASSED,
                knowledge_ids=(),
                experience_ids=(),
                knowledge_confidence=0.0,
                explanation="Mode: DISABLED",
                reason_codes=("MODE_DISABLED",),
            )

        # Step 1: OBSERVATION_ONLY mode — run analysis but don't apply
        if cfg.mode == ImprovementMode.OBSERVATION_ONLY:
            # Run the full pipeline for observability, then return baseline
            analysis = self._run_analysis(
                session_id, current_situation, safety_gate_state,
                baseline_decision, baseline_score, context_key_dict, decision_id, now,
            )
            # Attach analysis info but use baseline
            result = DecisionImprovementResult(
                decision_id=decision_id,
                session_id=session_id,
                timestamp=now,
                schema_version=IMPROVEMENT_SCHEMA_VERSION,
                context_id=analysis.get("context_id", NOT_AVAILABLE),
                current_situation=current_situation,
                safety_gate_state=safety_gate_state,
                baseline_decision=baseline_decision,
                baseline_score=round(baseline_score, 6),
                candidate_decision=analysis.get("candidate_decision", baseline_decision),
                candidate_score=analysis.get("candidate_score", round(baseline_score, 6)),
                final_decision=baseline_decision,
                final_score=round(baseline_score, 6),
                experience_adjustment=analysis.get("experience_adjustment", 0.0),
                outcome=ImprovementOutcome.OBSERVATION,
                fallback_used=True,
                fallback_reason=FallbackReason.MODE_DISABLED,
                safety_veto=SafetyVetoResult.BYPASSED,
                knowledge_ids=analysis.get("knowledge_ids", ()),
                experience_ids=analysis.get("experience_ids", ()),
                knowledge_confidence=analysis.get("knowledge_confidence", 0.0),
                reason_codes=("OBSERVATION_ONLY",),
            )
            result.explanation = _build_explanation(result)
            return result

        # Steps 2–8: ADVISORY or BOUNDED_ACTIVE
        return self._run_active_improvement(
            session_id, current_situation, safety_gate_state,
            baseline_decision, baseline_score, context_key_dict, decision_id, now,
        )

    def _run_analysis(
        self,
        session_id: str,
        current_situation: str,
        safety_gate_state: str,
        baseline_decision: str,
        baseline_score: float,
        context_key_dict: Dict,
        decision_id: str,
        now: float,
    ) -> Dict:
        """Run full pipeline for observation; return analysis dict (no mutations)."""
        try:
            eligible, _ineligible = self._get_eligible_knowledge(context_key_dict)
            if not eligible:
                return {
                    "context_id": _make_context_id(session_id),
                    "candidate_decision": baseline_decision,
                    "candidate_score": round(baseline_score, 6),
                    "experience_adjustment": 0.0,
                    "knowledge_ids": (),
                    "experience_ids": (),
                    "knowledge_confidence": 0.0,
                }
            candidate = score_candidate(
                baseline_decision, baseline_score, eligible, self._config, 0
            )
            avg_conf = sum(k.confidence for k in eligible) / len(eligible)
            k_ids = tuple(k.knowledge_id for k in eligible)
            e_ids = tuple(
                eid for k in eligible for eid in k.supporting_experience_ids
            )[:20]
            return {
                "context_id": _make_context_id(session_id),
                "candidate_decision": candidate.candidate_type,
                "candidate_score": candidate.final_score,
                "experience_adjustment": candidate.experience_adjustment,
                "knowledge_ids": k_ids,
                "experience_ids": e_ids,
                "knowledge_confidence": round(avg_conf, 6),
            }
        except Exception as exc:  # noqa: BLE001
            log.exception("_run_analysis: error: %s", exc)
            return {}

    def _run_active_improvement(
        self,
        session_id: str,
        current_situation: str,
        safety_gate_state: str,
        baseline_decision: str,
        baseline_score: float,
        context_key_dict: Dict,
        decision_id: str,
        now: float,
    ) -> DecisionImprovementResult:
        cfg = self._config
        context_id = _make_context_id(session_id)
        reason_codes: List[str] = []

        # Step 2: Get eligible knowledge
        eligible, ineligible = self._get_eligible_knowledge(context_key_dict)

        if not eligible:
            inelig_reasons = {e.value for _, e in ineligible}
            if any(r in inelig_reasons for r in ("CONFLICTING",)):
                fb = FallbackReason.CONFLICTING_EVIDENCE
                reason_codes.append("CONFLICTING_EVIDENCE")
            elif any(r in inelig_reasons for r in ("STALE",)):
                fb = FallbackReason.STALE_KNOWLEDGE
                reason_codes.append("STALE_KNOWLEDGE")
            else:
                fb = FallbackReason.KNOWLEDGE_UNAVAILABLE
                reason_codes.append("KNOWLEDGE_UNAVAILABLE")

            return self._make_fallback_result(
                session_id=session_id,
                current_situation=current_situation,
                safety_gate_state=safety_gate_state,
                baseline_decision=baseline_decision,
                baseline_score=baseline_score,
                reason=fb,
                context_id=context_id,
                decision_id=decision_id,
                reason_codes=tuple(reason_codes),
            )

        # Step 3: Score baseline and improved candidates
        baseline_cand = score_baseline(baseline_decision, baseline_score, 0)
        improved_cand = score_candidate(
            baseline_decision, baseline_score, eligible, cfg, 1
        )

        avg_conf = sum(k.confidence for k in eligible) / len(eligible)
        k_ids = tuple(k.knowledge_id for k in eligible)
        e_ids = tuple(
            eid for k in eligible for eid in k.supporting_experience_ids
        )[:20]

        # Step 4: Apply safety veto (always enforced)
        veto_result, veto_reason, final_cand = veto_check(
            safety_gate_state, baseline_cand, improved_cand
        )

        # Step 5: Determine outcome
        if veto_result == SafetyVetoResult.VETOED:
            reason_codes.append("SAFETY_VETO")
            outcome = ImprovementOutcome.VETOED
            fallback_used = True
            fallback_reason = FallbackReason.SAFETY_VETO
            final_decision = baseline_decision
            final_score = baseline_score
            experience_adjustment = 0.0
        else:
            if cfg.mode == ImprovementMode.ADVISORY:
                # Advisory: compute and expose but don't apply
                reason_codes.append("ADVISORY_ONLY")
                outcome = ImprovementOutcome.OBSERVATION
                fallback_used = True
                fallback_reason = FallbackReason.MODE_DISABLED
                final_decision = baseline_decision
                final_score = baseline_score
                experience_adjustment = improved_cand.experience_adjustment
            else:
                # BOUNDED_ACTIVE: apply improvement
                if abs(improved_cand.experience_adjustment) < 1e-6:
                    outcome = ImprovementOutcome.UNCHANGED
                    reason_codes.append("NO_ADJUSTMENT")
                else:
                    outcome = ImprovementOutcome.IMPROVED
                    reason_codes.append("EXPERIENCE_APPLIED")
                fallback_used = False
                fallback_reason = FallbackReason.NONE
                final_decision = final_cand.candidate_type
                final_score = final_cand.final_score
                experience_adjustment = improved_cand.experience_adjustment

        result = DecisionImprovementResult(
            decision_id=decision_id,
            session_id=session_id,
            timestamp=now,
            schema_version=IMPROVEMENT_SCHEMA_VERSION,
            context_id=context_id,
            current_situation=current_situation,
            safety_gate_state=safety_gate_state,
            baseline_decision=baseline_decision,
            baseline_score=round(baseline_score, 6),
            candidate_decision=improved_cand.candidate_type,
            candidate_score=improved_cand.final_score,
            final_decision=final_decision,
            final_score=round(final_score, 6),
            experience_adjustment=round(experience_adjustment, 6),
            outcome=outcome,
            fallback_used=fallback_used,
            fallback_reason=fallback_reason,
            safety_veto=veto_result,
            knowledge_ids=k_ids,
            experience_ids=e_ids,
            knowledge_confidence=round(avg_conf, 6),
            explanation=NOT_AVAILABLE,  # filled below
            reason_codes=tuple(reason_codes),
            degraded=any(k.degraded for k in eligible),
        )
        result.explanation = _build_explanation(result)
        return result

    def _get_eligible_knowledge(
        self, context_key_dict: Dict
    ) -> Tuple[List[KnowledgeEntrySnapshot], List]:
        """Retrieve and filter relevant knowledge from Phase 12.5 store."""
        if self._store is None:
            return [], []

        try:
            all_contexts = self._store.list_contexts(
                status_filter=None  # filter in knowledge_filter
            )
            # Convert KnowledgeContext to KnowledgeEntrySnapshot for filtering
            # by reading the full snapshot from the store
            snaps: List[KnowledgeEntrySnapshot] = []
            for ctx in all_contexts:
                snap = self._store.get(ctx.knowledge_id)
                if snap is not None:
                    # Context relevance: match at least one non-trivial field
                    if self._is_contextually_relevant(snap, context_key_dict):
                        snaps.append(snap)

            eligible, ineligible = filter_knowledge(snaps, self._config)
            return eligible, ineligible
        except Exception as exc:  # noqa: BLE001
            log.exception("_get_eligible_knowledge: error: %s", exc)
            return [], []

    @staticmethod
    def _is_contextually_relevant(
        snap: KnowledgeEntrySnapshot, context_key_dict: Dict
    ) -> bool:
        """
        Check if a knowledge entry is contextually relevant to the current situation.

        Uses normalized field matching.  At least one field must match for relevance.
        Empty context → all knowledge is potentially relevant.
        """
        if not context_key_dict:
            return True  # no context filter → include all

        k = snap.context_key
        kd = {
            "road_type": k.road_type.upper(),
            "intersection_state": k.intersection_state.upper(),
            "hazard_level": k.hazard_level.upper(),
            "dominant_hazard": k.dominant_hazard.upper(),
            "traffic_density": k.traffic_density.upper(),
            "situation_type": k.situation_type.upper(),
        }

        for field, value in context_key_dict.items():
            if not isinstance(value, str):
                continue
            v = value.strip().upper()
            if not v or v in ("NOT_AVAILABLE", "UNKNOWN", "NONE"):
                continue
            kv = kd.get(field, "").strip()
            if kv and kv not in ("NOT_AVAILABLE", "UNKNOWN", "NONE") and kv == v:
                return True  # at least one field matches

        return False

    def _make_fallback_result(
        self,
        session_id: str,
        current_situation: str,
        safety_gate_state: str,
        baseline_decision: str,
        baseline_score: float,
        reason: FallbackReason,
        context_id: str = NOT_AVAILABLE,
        decision_id: Optional[str] = None,
        reason_codes: Tuple[str, ...] = (),
        error: Optional[str] = None,
    ) -> DecisionImprovementResult:
        did = decision_id or _make_decision_id(session_id)
        r = DecisionImprovementResult(
            decision_id=did,
            session_id=session_id,
            timestamp=time.time(),
            schema_version=IMPROVEMENT_SCHEMA_VERSION,
            context_id=context_id,
            current_situation=current_situation,
            safety_gate_state=safety_gate_state,
            baseline_decision=baseline_decision,
            baseline_score=round(baseline_score, 6),
            candidate_decision=baseline_decision,
            candidate_score=round(baseline_score, 6),
            final_decision=baseline_decision,
            final_score=round(baseline_score, 6),
            experience_adjustment=0.0,
            outcome=ImprovementOutcome.FALLBACK,
            fallback_used=True,
            fallback_reason=reason,
            safety_veto=SafetyVetoResult.UNKNOWN,
            knowledge_ids=(),
            experience_ids=(),
            knowledge_confidence=0.0,
            reason_codes=reason_codes or (reason.value,),
            degraded=False,
            error=error,
        )
        r.explanation = _build_explanation(r)
        return r

    def _check_rollback(self, result: DecisionImprovementResult) -> None:
        """Check if degradation threshold is exceeded and roll back if needed."""
        with self._lock:
            if self._rollback_active:
                return
            m = self._monitor
            if m.total_cycles < 10:
                return  # not enough data
            if m.total_cycles == 0:
                return
            degrade_ratio = m.degraded_decision_count / m.total_cycles
            if degrade_ratio > self._config.rollback_degradation_threshold:
                self.rollback_to_observation(
                    f"degradation_ratio={degrade_ratio:.3f} > "
                    f"threshold={self._config.rollback_degradation_threshold}"
                )
