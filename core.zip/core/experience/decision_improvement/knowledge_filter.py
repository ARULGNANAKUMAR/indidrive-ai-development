"""
IndiDrive AI — Phase 12.6 | Knowledge Filter
=============================================
Screens KnowledgeEntrySnapshot objects from Phase 12.5 for eligibility
to influence decision improvement.

Only ELIGIBLE knowledge should influence decisions.
All other knowledge produces informational context only.

Eligibility rules (deterministic, configurable):
  ACTIVE / VALIDATED → may be eligible (subject to confidence/evidence thresholds)
  CONFLICTING        → excluded unless allow_conflicting_knowledge=True (and then penalized)
  STALE              → governed by stale_knowledge_policy
  DEPRECATED         → always excluded
  REJECTED / INVALID → always excluded
  CANDIDATE          → excluded (not yet validated)
  WEAK               → excluded unless confidence meets minimum

Design rules:
  * deterministic: same input → same eligibility decision
  * no side effects: never mutates KnowledgeEntrySnapshot
  * conservative: uncertain or degraded knowledge is excluded or penalized
  * safety-typed: SAFETY knowledge is never used to reduce safety margins
"""
from __future__ import annotations

import logging
from typing import List, Optional, Tuple

from ..knowledge.knowledge_types import (
    KnowledgeEntrySnapshot,
    KnowledgeStatus,
    KnowledgeConfidenceClass,
)
from .improvement_types import (
    ImprovementConfig,
    KnowledgeEligibility,
)

log = logging.getLogger(__name__)

# KnowledgeStatus values that are always excluded from influencing decisions
_ALWAYS_EXCLUDED_STATUSES = frozenset({
    KnowledgeStatus.DEPRECATED,
    KnowledgeStatus.REJECTED,
    KnowledgeStatus.INVALID,
    KnowledgeStatus.CANDIDATE,
})


def assess_eligibility(
    snap: KnowledgeEntrySnapshot,
    config: ImprovementConfig,
) -> KnowledgeEligibility:
    """
    Assess whether a KnowledgeEntrySnapshot is eligible for decision improvement.

    Returns a KnowledgeEligibility classification.
    Never raises — unknown/error cases return INVALID.
    """
    try:
        return _assess(snap, config)
    except Exception as exc:  # noqa: BLE001
        log.exception("assess_eligibility: unexpected error: %s", exc)
        return KnowledgeEligibility.INVALID


def _assess(snap: KnowledgeEntrySnapshot, config: ImprovementConfig) -> KnowledgeEligibility:
    if not config.enabled:
        return KnowledgeEligibility.DISABLED

    # Always excluded statuses
    if snap.status in _ALWAYS_EXCLUDED_STATUSES:
        return KnowledgeEligibility(snap.status.value.upper()
                                    if snap.status.value.upper() in KnowledgeEligibility.__members__
                                    else "INVALID")

    # STALE: governed by policy
    if snap.status == KnowledgeStatus.STALE:
        policy = config.stale_knowledge_policy.lower()
        if policy == "exclude":
            return KnowledgeEligibility.STALE
        elif policy == "penalize":
            # Mark as eligible but caller should apply confidence penalty
            pass  # fall through to confidence check
        # "allow" → fall through

    # CONFLICTING: excluded unless explicitly allowed
    if snap.status == KnowledgeStatus.CONFLICTING:
        if not config.allow_conflicting_knowledge:
            return KnowledgeEligibility.CONFLICTING
        # allowed but will be penalized in scoring

    # WEAK: check confidence — may pass if above threshold
    # ACTIVE / VALIDATED: proceed to threshold checks

    # Minimum evidence count
    if snap.valid_evidence_count < config.minimum_evidence_count:
        return KnowledgeEligibility.INSUFFICIENT_EVIDENCE

    # Minimum confidence
    if snap.confidence < config.minimum_knowledge_confidence:
        return KnowledgeEligibility.LOW_CONFIDENCE

    # Degraded knowledge gets lower confidence effectively
    if snap.degraded and snap.confidence < config.minimum_knowledge_confidence * 1.2:
        return KnowledgeEligibility.LOW_CONFIDENCE

    return KnowledgeEligibility.ELIGIBLE


def filter_knowledge(
    snapshots: List[KnowledgeEntrySnapshot],
    config: ImprovementConfig,
) -> Tuple[List[KnowledgeEntrySnapshot], List[Tuple[KnowledgeEntrySnapshot, KnowledgeEligibility]]]:
    """
    Partition knowledge snapshots into eligible and ineligible.

    Returns:
        (eligible_list, [(snap, reason)] ineligible_list)
    """
    eligible: List[KnowledgeEntrySnapshot] = []
    ineligible: List[Tuple[KnowledgeEntrySnapshot, KnowledgeEligibility]] = []

    for snap in snapshots:
        elig = assess_eligibility(snap, config)
        if elig == KnowledgeEligibility.ELIGIBLE:
            eligible.append(snap)
        else:
            ineligible.append((snap, elig))
            log.debug("filter_knowledge: excluded %s (%s)",
                      snap.knowledge_id, elig.value)

    return eligible, ineligible


def compute_confidence_penalty(
    snap: KnowledgeEntrySnapshot,
    config: ImprovementConfig,
) -> float:
    """
    Compute a confidence penalty for a knowledge entry.

    Returns a value in [0.0, 1.0] that reduces the experience_adjustment.
    Higher penalty → less influence.

    Rules:
        STALE (penalize policy)  → 0.5 penalty (halve the influence)
        CONFLICTING (allowed)    → 0.4 penalty
        uncertainty > 0.5        → proportional penalty
        degraded                 → 0.2 additional penalty
    """
    penalty = 0.0

    if snap.status == KnowledgeStatus.STALE:
        penalty = max(penalty, 0.5)

    if snap.status == KnowledgeStatus.CONFLICTING:
        penalty = max(penalty, 0.4)

    if snap.uncertainty > 0.5:
        penalty = max(penalty, snap.uncertainty * 0.6)

    if snap.degraded:
        penalty = min(1.0, penalty + 0.2)

    return min(1.0, penalty)
