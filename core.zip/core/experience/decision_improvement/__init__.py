"""
IndiDrive AI — Phase 12.6 | Experience-Driven Decision Improvement
==================================================================
Public API for the Phase 12.6 decision improvement layer.

Phase 12.6 extends the existing decision pipeline with experience-derived
scoring.  It does NOT replace any existing subsystem.

Safety authority always remains with the existing safety architecture.
SafetyGateState is NEVER modified by this layer.

Typical usage
-------------
from core.experience.decision_improvement import (
    DecisionImprovementEngine,
    ImprovementConfig,
    ImprovementMode,
)

config = ImprovementConfig.observation_only()   # safe default
engine = DecisionImprovementEngine(config, knowledge_store)

result = engine.improve(
    session_id        = "session-001",
    current_situation = "PEDESTRIAN_CROSSING",
    safety_gate_state = "CAUTION",            # from existing arbitration
    baseline_decision = "NORMAL_PROGRESS",    # from existing arbitration
    baseline_score    = 0.75,
    context_key_dict  = {"road_type": "URBAN", "situation_type": "PEDESTRIAN_CROSSING"},
)

# result.final_decision  → final decision (baseline if fallback)
# result.outcome         → IMPROVED / UNCHANGED / FALLBACK / VETOED / OBSERVATION
# result.explanation     → human-readable rationale
# result.fallback_used   → True if baseline was used
"""

from .improvement_types import (
    NOT_AVAILABLE,
    IMPROVEMENT_SCHEMA_VERSION,
    ImprovementMode,
    ImprovementOutcome,
    KnowledgeEligibility,
    FallbackReason,
    SafetyVetoResult,
    DecisionCandidate,
    DecisionImprovementContext,
    DecisionImprovementResult,
    DecisionImprovementRecord,
    ImprovementMonitor,
    ImprovementConfig,
)
from .knowledge_filter import assess_eligibility, filter_knowledge
from .experience_scorer import score_candidate, score_baseline
from .safety_veto import veto_check
from .improvement_engine import DecisionImprovementEngine

__all__ = [
    "NOT_AVAILABLE",
    "IMPROVEMENT_SCHEMA_VERSION",
    "ImprovementMode",
    "ImprovementOutcome",
    "KnowledgeEligibility",
    "FallbackReason",
    "SafetyVetoResult",
    "DecisionCandidate",
    "DecisionImprovementContext",
    "DecisionImprovementResult",
    "DecisionImprovementRecord",
    "ImprovementMonitor",
    "ImprovementConfig",
    "assess_eligibility",
    "filter_knowledge",
    "score_candidate",
    "score_baseline",
    "veto_check",
    "DecisionImprovementEngine",
]
