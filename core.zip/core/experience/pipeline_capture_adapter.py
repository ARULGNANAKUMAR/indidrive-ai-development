"""
IndiDrive AI — Phase 12.1 | Pipeline Capture Adapter
=====================================================
Thin adapter that connects Phase 12.1 experience capture to the
existing autonomous pipeline as a non-blocking downstream observer.

Integration flow:
    Existing autonomous pipeline (Phases 0 → 11.5)
                    ↓
    PipelineCaptureAdapter.observe(...)    ← Phase 12.1
                    ↓
    ExperienceCaptureSnapshot (read-only)

Architectural guarantee:
    If the capture adapter fails for ANY reason — exception, memory
    limit, invalid state, serialization error — the autonomous
    pipeline is NOT affected.  The adapter is a side-effect-only
    observer.

    capture_failed → experience degraded.
    capture_failed ≠ planner_failed.
    capture_failed ≠ safety_failed.

This module does NOT:
    - modify planner, MPC, control, or safety outputs.
    - generate control commands, paths, or trajectories.
    - perform new perception, prediction, or sensor fusion.
    - call external APIs or require network access.
"""
from __future__ import annotations

import threading
import time
from typing import Optional

from .capture_engine import ExperienceCaptureEngine
from .experience_types import (
    NOT_AVAILABLE,
    ExperienceCaptureConfig,
    ExperienceCaptureSnapshot,
    ExperienceCaptureStatus,
)

__all__ = ["PipelineCaptureAdapter"]


class PipelineCaptureAdapter:
    """
    Non-blocking, failure-isolated adapter for pipeline integration.

    The adapter wraps ExperienceCaptureEngine and ensures that any
    failure inside the capture layer cannot propagate to the autonomous
    driving pipeline.

    Usage
    -----
    adapter = PipelineCaptureAdapter()
    adapter.start_session("session-2026-001")

    # After each pipeline cycle:
    snap = adapter.observe(
        world_model_snapshot=wm,
        reasoning_snapshot=rs,
        planner_snapshot=ps,
        pipeline_snapshot=pipeline,
        control_snapshot=ctrl,
        safety_state=safety,
        failsafe_snapshot=failsafe,
        supervisor_snapshot=supervisor,
        frame_id=cycle_id,
    )

    # At driving session end:
    adapter.finalize_session()
    """

    def __init__(
        self, config: Optional[ExperienceCaptureConfig] = None
    ) -> None:
        self._cfg = config if config is not None else ExperienceCaptureConfig.default()
        self._engine = ExperienceCaptureEngine(self._cfg)
        self._lock = threading.Lock()
        self._last_snapshot: Optional[ExperienceCaptureSnapshot] = None

    # ------------------------------------------------------------------
    # Session management

    def start_session(
        self,
        session_id: str,
        timestamp: Optional[float] = None,
    ) -> bool:
        """
        Start a new capture session.

        Returns True on success. Failure is isolated — does not affect pipeline.
        """
        try:
            return self._engine.start_session(session_id, timestamp)
        except Exception:  # pylint: disable=broad-except
            return False

    def finalize_session(self, degraded: bool = False) -> bool:
        """
        Finalize the current capture session.

        Returns True on success. Failure is isolated.
        """
        try:
            return self._engine.finalize_session(degraded=degraded)
        except Exception:  # pylint: disable=broad-except
            return False

    def reset(self) -> None:
        """Reset the capture engine and clear all session data."""
        try:
            self._engine.reset()
        except Exception:  # pylint: disable=broad-except
            pass

    # ------------------------------------------------------------------
    # Main observation call

    def observe(
        self,
        *,
        world_model_snapshot=None,
        reasoning_snapshot=None,
        planner_snapshot=None,
        pipeline_snapshot=None,
        control_snapshot=None,
        safety_state=None,
        failsafe_snapshot=None,
        supervisor_snapshot=None,
        frame_id: int = 0,
        timestamp: Optional[float] = None,
    ) -> ExperienceCaptureSnapshot:
        """
        Observe one pipeline cycle and capture the experience.

        This method NEVER raises.  If the capture layer encounters any
        error, the error is recorded inside the snapshot's failure_reason
        and ExperienceCaptureStatus.FAILED is set.  The autonomous pipeline
        continues unaffected.

        Parameters
        ----------
        All pipeline snapshot/state arguments are optional.

        Returns
        -------
        ExperienceCaptureSnapshot — always returns a valid snapshot object.
        """
        try:
            snap = self._engine.capture_cycle(
                world_model_snapshot=world_model_snapshot,
                reasoning_snapshot=reasoning_snapshot,
                planner_snapshot=planner_snapshot,
                pipeline_snapshot=pipeline_snapshot,
                control_snapshot=control_snapshot,
                safety_state=safety_state,
                failsafe_snapshot=failsafe_snapshot,
                supervisor_snapshot=supervisor_snapshot,
                frame_id=frame_id,
                timestamp=timestamp,
            )
            with self._lock:
                self._last_snapshot = snap
            return snap

        except Exception as exc:  # pylint: disable=broad-except
            # Return a failure snapshot — never propagate to pipeline
            from .experience_types import SessionStatus
            failure_snap = ExperienceCaptureSnapshot(
                capture_status=ExperienceCaptureStatus.FAILED,
                session_status=SessionStatus.UNKNOWN,
                capture_failed=True,
                failure_reason=f"adapter.observe exception: {exc}",
            )
            with self._lock:
                self._last_snapshot = failure_snap
            return failure_snap

    # ------------------------------------------------------------------
    # Status / snapshot access

    def get_snapshot(self) -> ExperienceCaptureSnapshot:
        """Return the current capture state snapshot from the engine.

        Always reads from the engine so that changes made by finalize_session()
        or reset() are immediately reflected.
        """
        try:
            return self._engine.get_snapshot()
        except Exception:  # pylint: disable=broad-except
            from .experience_types import SessionStatus
            return ExperienceCaptureSnapshot(
                capture_status=ExperienceCaptureStatus.IDLE,
                session_status=SessionStatus.UNKNOWN,
            )

    @property
    def capture_status(self) -> ExperienceCaptureStatus:
        """Current capture status (never raises)."""
        try:
            return self._engine.capture_status
        except Exception:  # pylint: disable=broad-except
            return ExperienceCaptureStatus.UNKNOWN
