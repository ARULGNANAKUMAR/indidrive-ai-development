"""
IndiDrive AI — Phase 12.5 | Knowledge Validator
================================================
Validates a KnowledgeCandidate against configured evidence thresholds
before it may be inserted into the KnowledgeStore.

Decision outcomes:
    ACCEPTED — candidate met all thresholds; may be inserted.
    DEFERRED — candidate is below threshold; accumulate more evidence.
    REJECTED — candidate will never be acceptable (e.g. dominated by unsafe).
    ERROR    — internal validation error; treat as DEFERRED to be safe.

Strict rules:
    * Safety-type knowledge uses stricter thresholds.
    * Candidates with UNSAFE_OUTCOME dominating evidence are not REJECTED
      outright — they may form valid negative/safety knowledge — but they
      require extra evidence count and confidence.
    * A single observation (valid_evidence_count = 1) is DEFERRED unless
      the minimum is 1 (configured explicitly).
    * INVALID outcomes do NOT count toward evidence thresholds.
    * This module never modifies the candidate; it only classifies it.
"""
from __future__ import annotations

import logging
from typing import List, Tuple

from .knowledge_types import (
    KnowledgeCandidate,
    KnowledgeType,
    ValidationStatus,
    AdaptiveKnowledgeConfig,
)

log = logging.getLogger(__name__)


class KnowledgeValidator:
    """
    Stateless validator for KnowledgeCandidate objects.

    Returns (ValidationStatus, reason: str, details: list[str]).
    """

    def __init__(self, config: AdaptiveKnowledgeConfig) -> None:
        self._config = config

    def validate(
        self, candidate: KnowledgeCandidate
    ) -> Tuple[ValidationStatus, str, List[str]]:
        """
        Validate candidate against all configured thresholds.

        Returns:
            (status, primary_reason, detail_list)
        """
        try:
            return self._validate_inner(candidate)
        except Exception as exc:  # noqa: BLE001
            log.exception("validate: unexpected error for %s: %s",
                          candidate.knowledge_id, exc)
            return (
                ValidationStatus.ERROR,
                f"Internal validation error: {exc}",
                [f"exception={type(exc).__name__}"],
            )

    def _validate_inner(
        self, candidate: KnowledgeCandidate
    ) -> Tuple[ValidationStatus, str, List[str]]:
        details: List[str] = []
        cfg = self._config

        # Select thresholds based on knowledge type
        is_safety = candidate.knowledge_type == KnowledgeType.SAFETY
        min_evidence = (
            cfg.safety_minimum_evidence_count if is_safety
            else cfg.minimum_evidence_count
        )
        min_confidence = (
            cfg.safety_minimum_confidence if is_safety
            else cfg.minimum_confidence
        )
        min_consistency = cfg.minimum_consistency
        min_success_ratio = cfg.minimum_success_ratio

        v = candidate.valid_evidence_count
        details.append(f"valid_evidence={v} (required≥{min_evidence})")
        details.append(f"confidence={candidate.confidence:.3f} (required≥{min_confidence:.3f})")
        details.append(f"consistency={candidate.consistency:.3f} (required≥{min_consistency:.3f})")

        # Check 1: minimum valid evidence
        if v < min_evidence:
            reason = (
                f"Insufficient evidence: {v} valid evaluations "
                f"(need ≥{min_evidence})"
            )
            # It may grow — defer, don't reject
            return ValidationStatus.DEFERRED, reason, details

        # Check 2: minimum confidence
        if candidate.confidence < min_confidence:
            reason = (
                f"Confidence too low: {candidate.confidence:.3f} "
                f"(need ≥{min_confidence:.3f})"
            )
            # Could improve with more positive evidence — defer
            return ValidationStatus.DEFERRED, reason, details

        # Check 3: minimum consistency
        if candidate.consistency < min_consistency:
            reason = (
                f"Consistency too low: {candidate.consistency:.3f} "
                f"(need ≥{min_consistency:.3f})"
            )
            details.append(
                f"failure_count={candidate.failure_evidence_count}, "
                f"unsafe_count={candidate.unsafe_evidence_count}"
            )
            # Contradictory evidence — defer; may resolve with more data
            return ValidationStatus.DEFERRED, reason, details

        # Check 4: minimum success ratio (if configured > 0)
        if min_success_ratio > 0.0 and v > 0:
            actual_ratio = candidate.success_evidence_count / v
            if actual_ratio < min_success_ratio:
                reason = (
                    f"Success ratio too low: {actual_ratio:.3f} "
                    f"(need ≥{min_success_ratio:.3f})"
                )
                details.append(f"success_count={candidate.success_evidence_count}")
                return ValidationStatus.DEFERRED, reason, details

        # Check 5: degraded evidence policy
        if not cfg.allow_degraded_evidence:
            # If the candidate's evidence is entirely from degraded experiences
            # (no non-degraded valid outcomes), reject
            non_degraded = sum(
                1 for ev in candidate.evidence
                if ev.is_valid_evidence
                and ev.outcome_class not in ("DEGRADED",)
            )
            if non_degraded == 0:
                reason = "All valid evidence is DEGRADED; allow_degraded_evidence=False"
                return ValidationStatus.REJECTED, reason, details

        # All checks passed
        details.append("All thresholds passed")
        reason = (
            f"Candidate accepted: evidence={v}, "
            f"confidence={candidate.confidence:.3f}, "
            f"consistency={candidate.consistency:.3f}"
        )
        return ValidationStatus.ACCEPTED, reason, details
