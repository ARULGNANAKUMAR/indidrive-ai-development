"""
IndiDrive AI — Phase 12.5 | Adaptive Knowledge Store
=====================================================
Versioned, bounded, auditable in-memory storage for KnowledgeEntry objects.

Responsibilities:
    - store active KnowledgeEntry by knowledge_id
    - maintain versioned history (previous versions kept as DEPRECATED)
    - maintain append-only KnowledgeUpdateRecord audit log
    - enforce capacity limits
    - support read-only context queries

This module is the ONLY subsystem allowed to mutate adaptive knowledge.

Failure isolation:
    - All mutations are guarded by try/except.
    - On any exception, the store remains consistent and reports the error.
    - The driving pipeline is never affected by store failures.
"""
from __future__ import annotations

import logging
import threading
import time
from typing import Dict, List, Optional, Tuple

from .knowledge_types import (
    NOT_AVAILABLE,
    KNOWLEDGE_SCHEMA_VERSION,
    KnowledgeEntry,
    KnowledgeEntrySnapshot,
    KnowledgeStatus,
    KnowledgeType,
    KnowledgeUpdateRecord,
    KnowledgeContext,
    KnowledgeStoreSnapshot,
    UpdateType,
    ValidationStatus,
    AdaptiveKnowledgeConfig,
)

log = logging.getLogger(__name__)


class KnowledgeStore:
    """
    Versioned, bounded, thread-safe adaptive knowledge store.

    Thread safety: a single RLock protects all state.  All public
    methods acquire the lock before touching internal collections.

    Capacity enforcement:
        maximum_entries (config) limits the total live KnowledgeEntry
        count across all statuses.  When the limit is reached, the
        oldest DEPRECATED or STALE entry is evicted before insertion.
        If no such entry exists, the new entry is rejected and an error
        is logged.  Audit records are never evicted.

    History management:
        Each knowledge_id keeps at most config.maximum_history_per_entry
        previous versions in _history.  Older versions are permanently
        dropped (audit records remain intact).

    This store does NOT:
        - change vehicle control
        - modify planner / MPC / tracking
        - write to SafetyGate
        - auto-generate policies
    """

    def __init__(self, config: Optional[AdaptiveKnowledgeConfig] = None) -> None:
        self._config = config or AdaptiveKnowledgeConfig.default()
        self._lock = threading.RLock()

        # knowledge_id → current active KnowledgeEntry
        self._entries: Dict[str, KnowledgeEntry] = {}

        # knowledge_id → list of previous KnowledgeEntry versions (DEPRECATED)
        # newest first
        self._history: Dict[str, List[KnowledgeEntry]] = {}

        # append-only audit log
        self._audit_log: List[KnowledgeUpdateRecord] = []

        log.debug("KnowledgeStore initialised (max_entries=%d)", self._config.maximum_entries)

    # ------------------------------------------------------------------
    # Write operations — used exclusively by KnowledgeUpdateEngine
    # ------------------------------------------------------------------

    def insert(self, entry: KnowledgeEntry, audit: KnowledgeUpdateRecord) -> bool:
        """
        Insert a new KnowledgeEntry that has no previous version.

        Returns True on success, False on capacity or duplicate error.
        Audit record is always appended on any return path.
        """
        with self._lock:
            self._audit_log.append(audit)
            try:
                if entry.knowledge_id in self._entries:
                    log.warning("insert: knowledge_id=%s already exists; use update()",
                                entry.knowledge_id)
                    return False
                if not self._has_capacity():
                    if not self._evict_one():
                        log.error("insert: capacity limit reached and no evictable entry")
                        return False
                self._entries[entry.knowledge_id] = entry
                self._history.setdefault(entry.knowledge_id, [])
                log.debug("insert: %s v%d status=%s",
                          entry.knowledge_id, entry.version, entry.status.value)
                return True
            except Exception as exc:  # noqa: BLE001
                log.exception("insert: unexpected error for %s: %s", entry.knowledge_id, exc)
                return False

    def update(self, new_entry: KnowledgeEntry, audit: KnowledgeUpdateRecord) -> bool:
        """
        Replace an existing KnowledgeEntry with a new version.

        The old version is moved to history with status DEPRECATED.
        Returns True on success.
        Audit record is always appended.
        """
        with self._lock:
            self._audit_log.append(audit)
            try:
                kid = new_entry.knowledge_id
                old = self._entries.get(kid)
                if old is None:
                    log.warning("update: knowledge_id=%s not found; use insert()", kid)
                    return False

                # Deprecate old version
                old.status = KnowledgeStatus.DEPRECATED
                old.updated_at = time.time()

                # Prepend to history, trim to limit
                hist = self._history.setdefault(kid, [])
                hist.insert(0, old)
                max_hist = max(1, self._config.maximum_history_per_entry)
                self._history[kid] = hist[:max_hist]

                # Install new version
                self._entries[kid] = new_entry
                log.debug("update: %s v%d→v%d status=%s",
                          kid, old.version, new_entry.version, new_entry.status.value)
                return True
            except Exception as exc:  # noqa: BLE001
                log.exception("update: unexpected error for %s: %s",
                              new_entry.knowledge_id, exc)
                return False

    def mark_stale(self, knowledge_id: str) -> bool:
        """Mark an ACTIVE entry as STALE (staleness check by engine)."""
        with self._lock:
            entry = self._entries.get(knowledge_id)
            if entry is None:
                return False
            if entry.status == KnowledgeStatus.ACTIVE:
                entry.status = KnowledgeStatus.STALE
                entry.updated_at = time.time()
                log.debug("mark_stale: %s v%d", knowledge_id, entry.version)
                return True
            return False

    # ------------------------------------------------------------------
    # Read operations — safe for any consumer
    # ------------------------------------------------------------------

    def get(self, knowledge_id: str) -> Optional[KnowledgeEntrySnapshot]:
        """Return the current version of a knowledge entry (read-only snapshot)."""
        with self._lock:
            entry = self._entries.get(knowledge_id)
            if entry is None:
                return None
            return entry.to_snapshot()

    def get_history(self, knowledge_id: str) -> Tuple[KnowledgeEntrySnapshot, ...]:
        """Return previous versions for a knowledge_id (oldest-first)."""
        with self._lock:
            hist = self._history.get(knowledge_id, [])
            # stored newest-first; return oldest-first for callers
            return tuple(e.to_snapshot() for e in reversed(hist))

    def list_active(self) -> Tuple[KnowledgeEntrySnapshot, ...]:
        """Return all ACTIVE knowledge entries."""
        with self._lock:
            return tuple(
                e.to_snapshot()
                for e in self._entries.values()
                if e.status == KnowledgeStatus.ACTIVE
            )

    def list_all(self) -> Tuple[KnowledgeEntrySnapshot, ...]:
        """Return all knowledge entries regardless of status."""
        with self._lock:
            return tuple(e.to_snapshot() for e in self._entries.values())

    def find_by_knowledge_id(self, knowledge_id: str) -> Optional[KnowledgeEntrySnapshot]:
        """Alias for get() — explicit lookup by ID."""
        return self.get(knowledge_id)

    def exists(self, knowledge_id: str) -> bool:
        """Return True if any version of this knowledge_id is present."""
        with self._lock:
            return knowledge_id in self._entries

    def get_knowledge_context(self, knowledge_id: str) -> Optional[KnowledgeContext]:
        """
        Return a read-only KnowledgeContext for external consumers.

        KnowledgeContext does NOT expose execute_action() or any mutable
        interface.  It is safe for reporting, human review, or Phase 12.6
        information queries.
        """
        with self._lock:
            entry = self._entries.get(knowledge_id)
            if entry is None:
                return None
            return KnowledgeContext(
                knowledge_id=entry.knowledge_id,
                knowledge_type=entry.knowledge_type,
                confidence=entry.confidence,
                confidence_class=entry.confidence_class,
                status=entry.status,
                evidence_count=entry.evidence_count,
                observed_relationship=entry.observed_relationship,
                uncertainty=entry.uncertainty,
                version=entry.version,
                updated_at=entry.updated_at,
                degraded=entry.degraded,
                supporting_experience_count=len(entry.supporting_experience_ids),
                supporting_evaluation_count=len(entry.supporting_evaluation_ids),
            )

    def list_contexts(self,
                      status_filter: Optional[KnowledgeStatus] = None,
                      ) -> Tuple[KnowledgeContext, ...]:
        """Return read-only contexts, optionally filtered by status."""
        with self._lock:
            contexts = []
            for entry in self._entries.values():
                if status_filter is not None and entry.status != status_filter:
                    continue
                ctx = KnowledgeContext(
                    knowledge_id=entry.knowledge_id,
                    knowledge_type=entry.knowledge_type,
                    confidence=entry.confidence,
                    confidence_class=entry.confidence_class,
                    status=entry.status,
                    evidence_count=entry.evidence_count,
                    observed_relationship=entry.observed_relationship,
                    uncertainty=entry.uncertainty,
                    version=entry.version,
                    updated_at=entry.updated_at,
                    degraded=entry.degraded,
                    supporting_experience_count=len(entry.supporting_experience_ids),
                    supporting_evaluation_count=len(entry.supporting_evaluation_ids),
                )
                contexts.append(ctx)
            return tuple(contexts)

    def get_audit_log(self) -> Tuple[KnowledgeUpdateRecord, ...]:
        """Return the complete append-only audit log."""
        with self._lock:
            return tuple(self._audit_log)

    def get_audit_for(self, knowledge_id: str) -> Tuple[KnowledgeUpdateRecord, ...]:
        """Return audit records for a specific knowledge_id."""
        with self._lock:
            return tuple(r for r in self._audit_log if r.knowledge_id == knowledge_id)

    def snapshot(self) -> KnowledgeStoreSnapshot:
        """Return an immutable summary of the current store state."""
        with self._lock:
            statuses = [e.status for e in self._entries.values()]
            return KnowledgeStoreSnapshot(
                schema_version=KNOWLEDGE_SCHEMA_VERSION,
                timestamp=time.time(),
                total_entries=len(self._entries),
                active_entries=sum(1 for s in statuses if s == KnowledgeStatus.ACTIVE),
                candidate_entries=sum(1 for s in statuses if s == KnowledgeStatus.CANDIDATE),
                deprecated_entries=sum(1 for s in statuses if s == KnowledgeStatus.DEPRECATED),
                rejected_entries=sum(1 for s in statuses if s == KnowledgeStatus.REJECTED),
                conflicting_entries=sum(1 for s in statuses if s == KnowledgeStatus.CONFLICTING),
                stale_entries=sum(1 for s in statuses if s == KnowledgeStatus.STALE),
                total_update_records=len(self._audit_log),
                store_healthy=True,
            )

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _has_capacity(self) -> bool:
        if self._config.maximum_entries <= 0:
            return True
        return len(self._entries) < self._config.maximum_entries

    def _evict_one(self) -> bool:
        """
        Attempt to evict the oldest DEPRECATED or STALE entry.
        Returns True if an entry was evicted.
        """
        candidates = [
            (kid, e) for kid, e in self._entries.items()
            if e.status in (KnowledgeStatus.DEPRECATED, KnowledgeStatus.STALE)
        ]
        if not candidates:
            return False
        # Evict the oldest by updated_at
        candidates.sort(key=lambda x: x[1].updated_at)
        evict_id = candidates[0][0]
        del self._entries[evict_id]
        log.debug("_evict_one: evicted %s", evict_id)
        return True
