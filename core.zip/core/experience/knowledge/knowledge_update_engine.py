"""
IndiDrive AI — Phase 12.5 | Knowledge Update Engine
====================================================
Orchestrates the complete Adaptive Knowledge Update pipeline:

    Evaluated Experiences
           ↓
    EvidenceAggregator  →  KnowledgeCandidate
           ↓
    KnowledgeValidator  →  ACCEPTED / DEFERRED / REJECTED
           ↓
    KnowledgeStore      →  CREATE / STRENGTHEN / WEAKEN / CONFIRM / …
           ↓
    KnowledgeUpdateResult

Strict boundaries:
    - Does NOT modify planner, MPC, tracking, vehicle commands.
    - Does NOT modify SafetyGate or safety thresholds.
    - Does NOT generate control policies.
    - All updates terminate at the KnowledgeStore.
    - On any failure, existing knowledge remains intact.
    - Driving pipeline is never blocked or affected.

Failure isolation:
    - Every public method is wrapped in try/except.
    - On unexpected exceptions, a REJECT result with error details is returned.
    - The KnowledgeStore's own insert/update are also guarded.

Atomicity:
    - A complete new KnowledgeEntry is constructed before any store mutation.
    - The store mutation is a single atomic call (insert or update).
    - There are no partial writes.

Staleness handling (if stale_after_seconds > 0):
    - check_staleness() may be called periodically by external infrastructure.
    - It marks ACTIVE entries STALE if they have received no evidence recently.
    - It never deletes entries.
"""
from __future__ import annotations

import logging
import time
from typing import Dict, List, Optional, Tuple

from .evidence_aggregator import EvidenceAggregator
from .knowledge_store import KnowledgeStore
from .knowledge_types import (
    NOT_AVAILABLE,
    KNOWLEDGE_SCHEMA_VERSION,
    KnowledgeCandidate,
    KnowledgeEntry,
    KnowledgeEntrySnapshot,
    KnowledgeStatus,
    KnowledgeType,
    KnowledgeUpdateRecord,
    KnowledgeUpdateResult,
    KnowledgeConfidenceClass,
    UpdateType,
    ValidationStatus,
    KnowledgeContextKey,
    AdaptiveKnowledgeConfig,
)
from .knowledge_validator import KnowledgeValidator

log = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _make_update_id(knowledge_id: str) -> str:
    ts_hex = hex(int(time.time() * 1000) & 0xFFFFFFFFFF)[2:].upper()
    return f"UPD-{knowledge_id}-{ts_hex}"


def _classify_confidence(confidence: float) -> KnowledgeConfidenceClass:
    from .evidence_aggregator import _classify_confidence as _c
    return _c(confidence)


def _determine_update_type(
    existing: Optional[KnowledgeEntrySnapshot],
    candidate: KnowledgeCandidate,
    validation_status: ValidationStatus,
) -> UpdateType:
    """
    Determine the UpdateType for this operation.

    Rules:
        No existing entry → CREATE (if ACCEPTED) or REJECT (otherwise)
        Existing entry + ACCEPTED:
            new_confidence > old + 0.05  → STRENGTHEN
            new_confidence < old - 0.05  → WEAKEN
            contradictory (consistency drops significantly) → CONTRADICT
            otherwise → CONFIRM (update evidence, minor change)
        Existing entry + DEFERRED/REJECTED → CONFIRM (no change to active entry)
    """
    if existing is None:
        if validation_status == ValidationStatus.ACCEPTED:
            return UpdateType.CREATE
        return UpdateType.REJECT

    if validation_status != ValidationStatus.ACCEPTED:
        return UpdateType.CONFIRM  # evidence acknowledged, no mutation

    delta = candidate.confidence - existing.confidence
    if delta > 0.05:
        return UpdateType.STRENGTHEN
    if delta < -0.05:
        # Check if this is primarily due to new contradictions
        old_cons = existing.consistency
        new_cons = candidate.consistency
        if new_cons < old_cons - 0.10:
            return UpdateType.CONTRADICT
        return UpdateType.WEAKEN

    # Small delta — check for evidence additions
    if candidate.valid_evidence_count > existing.valid_evidence_count:
        return UpdateType.CONFIRM  # more evidence, similar confidence
    return UpdateType.CONFIRM


def _build_entry_from_candidate(
    candidate: KnowledgeCandidate,
    version: int,
    parent_version: Optional[int],
) -> KnowledgeEntry:
    """Construct a KnowledgeEntry from a validated KnowledgeCandidate."""
    now = time.time()

    # Determine status from confidence class and consistency
    if candidate.consistency < 0.50:
        status = KnowledgeStatus.CONFLICTING
    elif candidate.confidence_class in (
        KnowledgeConfidenceClass.VERY_LOW, KnowledgeConfidenceClass.UNKNOWN
    ):
        status = KnowledgeStatus.WEAK
    elif candidate.unsafe_evidence_count > 0 and candidate.success_evidence_count == 0:
        status = KnowledgeStatus.WEAK  # pure negative knowledge — active but weak
    else:
        status = KnowledgeStatus.ACTIVE

    exp_ids = tuple(
        ev.experience_id for ev in candidate.evidence if ev.is_valid_evidence
    )
    eval_ids = tuple(
        ev.evaluation_id for ev in candidate.evidence if ev.is_valid_evidence
    )

    uncertainty = max(0.0, 1.0 - candidate.confidence * candidate.consistency)

    return KnowledgeEntry(
        knowledge_id=candidate.knowledge_id,
        schema_version=KNOWLEDGE_SCHEMA_VERSION,
        knowledge_type=candidate.knowledge_type,
        context_key=candidate.context_key,
        observed_relationship=candidate.observed_relationship,
        supporting_experience_ids=exp_ids,
        supporting_evaluation_ids=eval_ids,
        evidence_count=candidate.evidence_count,
        valid_evidence_count=candidate.valid_evidence_count,
        success_evidence_count=candidate.success_evidence_count,
        failure_evidence_count=candidate.failure_evidence_count,
        unsafe_evidence_count=candidate.unsafe_evidence_count,
        weighted_score=candidate.weighted_score,
        confidence=candidate.confidence,
        confidence_class=candidate.confidence_class,
        consistency=candidate.consistency,
        uncertainty=round(uncertainty, 6),
        status=status,
        created_at=now,
        updated_at=now,
        last_evidence_at=candidate.latest_evidence_at,
        source_phase="12.5",
        generation_method=candidate.generation_method,
        validation_method="threshold_validation",
        version=version,
        parent_version=parent_version,
        degraded=False,
    )


# ---------------------------------------------------------------------------
# Main engine
# ---------------------------------------------------------------------------

class KnowledgeUpdateEngine:
    """
    Orchestrates the Phase 12.5 Adaptive Knowledge Update pipeline.

    Usage:
        config = AdaptiveKnowledgeConfig.default()
        store = KnowledgeStore(config)
        engine = KnowledgeUpdateEngine(config, store)

        result = engine.process_experiences(
            context_key=KnowledgeContextKey(...),
            experience_records=[
                {
                    "experience_id": "...",
                    "evaluation_id": "...",
                    "session_id": "...",
                    "outcome_class": "SUCCESS",
                    "evaluation_confidence": "HIGH",
                    "experience_timestamp": 1234567890.0,
                },
                ...
            ],
        )

    The engine does NOT write to any vehicle control subsystem.
    All writes go exclusively to the KnowledgeStore.
    """

    def __init__(
        self,
        config: Optional[AdaptiveKnowledgeConfig] = None,
        store: Optional[KnowledgeStore] = None,
    ) -> None:
        self._config = config or AdaptiveKnowledgeConfig.default()
        self._store = store or KnowledgeStore(self._config)
        self._aggregator = EvidenceAggregator(self._config)
        self._validator = KnowledgeValidator(self._config)
        self._candidate_seq: int = 0

    @property
    def store(self) -> KnowledgeStore:
        """Read-only access to the knowledge store for external consumers."""
        return self._store

    @property
    def config(self) -> AdaptiveKnowledgeConfig:
        return self._config

    def process_experiences(
        self,
        context_key: KnowledgeContextKey,
        experience_records: List[dict],
    ) -> KnowledgeUpdateResult:
        """
        Full pipeline: aggregate → validate → update store.

        Parameters
        ----------
        context_key
            Normalized context that identifies this knowledge domain.
        experience_records
            List of evaluated experience dicts.  Each must have:
                experience_id, evaluation_id, session_id,
                outcome_class, evaluation_confidence, experience_timestamp.

        Returns
        -------
        KnowledgeUpdateResult
            Always returned — never raises.  On any error, success=False
            and the store remains consistent.
        """
        if not self._config.enabled:
            return KnowledgeUpdateResult(
                success=False,
                update_type=UpdateType.REJECT,
                reason="AdaptiveKnowledge disabled by configuration",
                validation_status=ValidationStatus.REJECTED,
            )

        try:
            return self._process_inner(context_key, experience_records)
        except Exception as exc:  # noqa: BLE001
            log.exception("process_experiences: unexpected error: %s", exc)
            return KnowledgeUpdateResult(
                success=False,
                update_type=UpdateType.REJECT,
                reason="Unexpected internal error",
                error=str(exc),
                validation_status=ValidationStatus.ERROR,
            )

    def _process_inner(
        self,
        context_key: KnowledgeContextKey,
        experience_records: List[dict],
    ) -> KnowledgeUpdateResult:
        # Step 1: aggregate evidence into a candidate
        self._candidate_seq += 1
        candidate = self._aggregator.aggregate(
            context_key, experience_records, self._candidate_seq
        )
        knowledge_id = candidate.knowledge_id

        log.debug(
            "process_inner: kid=%s valid_ev=%d confidence=%.3f consistency=%.3f",
            knowledge_id, candidate.valid_evidence_count,
            candidate.confidence, candidate.consistency,
        )

        # Step 2: check if we already have this knowledge
        existing = self._store.get(knowledge_id)

        # Step 3: validate
        val_status, val_reason, val_details = self._validator.validate(candidate)
        log.debug("validate: %s → %s | %s", knowledge_id, val_status.value, val_reason)

        # Step 4: determine update type
        update_type = _determine_update_type(existing, candidate, val_status)

        if val_status == ValidationStatus.DEFERRED:
            # Not enough evidence yet; acknowledge but don't store
            return KnowledgeUpdateResult(
                success=True,  # not an error — just deferred
                update_type=UpdateType.CONFIRM,
                knowledge_id=knowledge_id,
                validation_status=val_status,
                reason=val_reason,
            )

        if val_status == ValidationStatus.REJECTED:
            audit = KnowledgeUpdateRecord(
                update_id=_make_update_id(knowledge_id),
                knowledge_id=knowledge_id,
                update_type=UpdateType.REJECT,
                previous_version=existing.version if existing else None,
                new_version=existing.version if existing else 0,
                reason=val_reason,
                evidence_ids=tuple(ev.experience_id for ev in candidate.evidence),
                validation_status=val_status,
                notes="; ".join(val_details),
            )
            self._store._audit_log.append(audit)  # noqa: SLF001
            return KnowledgeUpdateResult(
                success=False,
                update_type=UpdateType.REJECT,
                knowledge_id=knowledge_id,
                validation_status=val_status,
                reason=val_reason,
            )

        if val_status == ValidationStatus.ERROR:
            return KnowledgeUpdateResult(
                success=False,
                update_type=UpdateType.REJECT,
                knowledge_id=knowledge_id,
                validation_status=val_status,
                reason=val_reason,
                error=val_reason,
            )

        # val_status == ACCEPTED — proceed with store mutation
        if update_type == UpdateType.CONFIRM and existing is not None:
            # Evidence noted; no meaningful change — skip store write
            audit = KnowledgeUpdateRecord(
                update_id=_make_update_id(knowledge_id),
                knowledge_id=knowledge_id,
                update_type=UpdateType.CONFIRM,
                previous_version=existing.version,
                new_version=existing.version,
                reason="Evidence confirmed existing knowledge; no significant change",
                evidence_ids=tuple(ev.experience_id for ev in candidate.evidence),
                validation_status=val_status,
                notes="; ".join(val_details),
            )
            self._store._audit_log.append(audit)  # noqa: SLF001
            return KnowledgeUpdateResult(
                success=True,
                update_type=UpdateType.CONFIRM,
                knowledge_id=knowledge_id,
                new_version=existing.version,
                previous_version=existing.version,
                validation_status=val_status,
                reason="Existing knowledge confirmed",
            )

        # Build the new KnowledgeEntry
        new_version = 1 if existing is None else existing.version + 1
        parent_version = existing.version if existing else None
        new_entry = _build_entry_from_candidate(candidate, new_version, parent_version)

        audit = KnowledgeUpdateRecord(
            update_id=_make_update_id(knowledge_id),
            knowledge_id=knowledge_id,
            update_type=update_type,
            previous_version=parent_version,
            new_version=new_version,
            reason=val_reason,
            evidence_ids=tuple(ev.experience_id for ev in candidate.evidence),
            validation_status=val_status,
            notes="; ".join(val_details),
        )

        # Atomic store operation
        if existing is None:
            ok = self._store.insert(new_entry, audit)
        else:
            ok = self._store.update(new_entry, audit)

        if not ok:
            return KnowledgeUpdateResult(
                success=False,
                update_type=update_type,
                knowledge_id=knowledge_id,
                new_version=new_version,
                previous_version=parent_version,
                validation_status=val_status,
                reason="Store operation failed (see store logs)",
                error="store_operation_failed",
            )

        log.info(
            "knowledge_update: %s type=%s v%s→v%s status=%s confidence=%.3f",
            knowledge_id, update_type.value,
            parent_version or "-", new_version,
            new_entry.status.value, new_entry.confidence,
        )

        return KnowledgeUpdateResult(
            success=True,
            update_type=update_type,
            knowledge_id=knowledge_id,
            new_version=new_version,
            previous_version=parent_version,
            validation_status=val_status,
            reason=val_reason,
        )

    def check_staleness(self) -> List[str]:
        """
        Mark ACTIVE entries as STALE if stale_after_seconds > 0 and
        they have received no evidence for that duration.

        Returns list of knowledge_ids marked stale.
        Never deletes entries.
        May be called periodically by external infrastructure.
        Not required in the hot driving path.
        """
        stale_after = self._config.stale_after_seconds
        if stale_after <= 0:
            return []

        now = time.time()
        marked: List[str] = []
        for snap in self._store.list_active():
            age = now - snap.last_evidence_at
            if snap.last_evidence_at > 0 and age > stale_after:
                if self._store.mark_stale(snap.knowledge_id):
                    marked.append(snap.knowledge_id)
                    log.debug("stale: %s (age=%.1fs)", snap.knowledge_id, age)
        return marked
