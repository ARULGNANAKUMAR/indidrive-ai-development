"""
IndiDrive AI — Phase 12.5 | Evidence Aggregator
================================================
Converts a set of evaluated experiences into a KnowledgeCandidate.

Responsibilities:
    - extract KnowledgeContextKey from experience/retrieval context
    - determine KnowledgeType from context
    - compute KnowledgeEvidence for each evaluated experience
    - aggregate weighted_score, confidence, consistency
    - classify confidence into KnowledgeConfidenceClass
    - produce a KnowledgeCandidate (not yet validated or inserted)

Design rules:
    * deterministic: same inputs → same candidate
    * no randomness
    * no policy generation
    * negative evidence (FAILURE, UNSAFE_OUTCOME) is preserved, not discarded
    * INVALID and NOT_EVALUATED outcomes contribute zero weight and are not
      counted as valid evidence
"""
from __future__ import annotations

import hashlib
import logging
import time
from typing import List, Sequence, Tuple

from .knowledge_types import (
    NOT_AVAILABLE,
    KNOWLEDGE_SCHEMA_VERSION,
    OUTCOME_WEIGHT,
    CONFIDENCE_MULTIPLIER,
    VALID_EVIDENCE_OUTCOMES,
    INVALID_EVIDENCE_OUTCOMES,
    KnowledgeCandidate,
    KnowledgeConfidenceClass,
    KnowledgeContextKey,
    KnowledgeEvidence,
    KnowledgeType,
    AdaptiveKnowledgeConfig,
)

log = logging.getLogger(__name__)


def _classify_confidence(confidence: float) -> KnowledgeConfidenceClass:
    """
    Deterministic classification of a numeric confidence value.

    Thresholds (documented in KnowledgeConfidenceClass):
        VERY_HIGH  ≥ 0.85
        HIGH       ≥ 0.70
        MODERATE   ≥ 0.50
        LOW        ≥ 0.30
        VERY_LOW   ≥ 0.10
        UNKNOWN    <  0.10
    """
    if confidence >= 0.85:
        return KnowledgeConfidenceClass.VERY_HIGH
    if confidence >= 0.70:
        return KnowledgeConfidenceClass.HIGH
    if confidence >= 0.50:
        return KnowledgeConfidenceClass.MODERATE
    if confidence >= 0.30:
        return KnowledgeConfidenceClass.LOW
    if confidence >= 0.10:
        return KnowledgeConfidenceClass.VERY_LOW
    return KnowledgeConfidenceClass.UNKNOWN


def _infer_knowledge_type(context_key: KnowledgeContextKey) -> KnowledgeType:
    """
    Infer KnowledgeType from the context features.

    Rules (in priority order):
        1. If safety_state signals non-nominal → SAFETY
        2. If hazard_level is HIGH/CRITICAL or dominant_hazard present → HAZARD
        3. If situation_type is non-trivial → SITUATIONAL
        4. Default → CONTEXTUAL
    """
    safety = context_key.safety_state.upper()
    if safety not in (NOT_AVAILABLE, "SAFE", "NOMINAL", ""):
        return KnowledgeType.SAFETY

    hazard = context_key.hazard_level.upper()
    if hazard in ("HIGH", "CRITICAL"):
        return KnowledgeType.HAZARD
    dominant = context_key.dominant_hazard.upper()
    if dominant not in (NOT_AVAILABLE, "NONE", ""):
        return KnowledgeType.HAZARD

    sit = context_key.situation_type.upper()
    if sit not in (NOT_AVAILABLE, "UNKNOWN", "NORMAL", ""):
        return KnowledgeType.SITUATIONAL

    return KnowledgeType.CONTEXTUAL


def _make_candidate_id(knowledge_id: str, seq: int) -> str:
    ts_hex = hex(int(time.time() * 1000) & 0xFFFFFFFF)[2:]
    return f"CAND-{knowledge_id}-{seq:04d}-{ts_hex.upper()}"


def _make_observed_relationship(
    context_key: KnowledgeContextKey,
    success_count: int,
    failure_count: int,
    unsafe_count: int,
    valid_count: int,
    knowledge_type: KnowledgeType,
) -> str:
    """
    Build a descriptive (NOT prescriptive) relationship summary.

    This answers: «"What was observed?"» not «"What should be done?"»
    """
    if valid_count == 0:
        return "No valid evidence for this context pattern."

    parts = []
    n = context_key.normalized()

    if n.road_type != NOT_AVAILABLE:
        parts.append(f"road={n.road_type}")
    if n.intersection_state not in (NOT_AVAILABLE, "NONE"):
        parts.append(f"intersection={n.intersection_state}")
    if n.hazard_level not in (NOT_AVAILABLE, "NONE"):
        parts.append(f"hazard={n.hazard_level}")
    if n.dominant_hazard not in (NOT_AVAILABLE, "NONE"):
        parts.append(f"dominant_hazard={n.dominant_hazard}")
    if n.traffic_density != NOT_AVAILABLE:
        parts.append(f"traffic={n.traffic_density}")
    if n.vulnerable_road_user_present:
        parts.append("vru=present")
    if n.situation_type not in (NOT_AVAILABLE, "UNKNOWN"):
        parts.append(f"situation={n.situation_type}")

    ctx_summary = ", ".join(parts) if parts else "mixed context"

    outcome_parts = []
    if success_count > 0:
        outcome_parts.append(f"{success_count} success")
    if failure_count > 0:
        outcome_parts.append(f"{failure_count} failure")
    if unsafe_count > 0:
        outcome_parts.append(f"{unsafe_count} unsafe")
    outcome_summary = ", ".join(outcome_parts) if outcome_parts else "mixed outcomes"

    return (
        f"In context [{ctx_summary}]: "
        f"observed {valid_count} valid experiences "
        f"({outcome_summary}). "
        f"Knowledge type: {knowledge_type.value}. "
        f"This is observational, not prescriptive."
    )


class EvidenceAggregator:
    """
    Converts evaluated experience data into a KnowledgeCandidate.

    Input:
        A list of dicts, each with keys:
            experience_id        str
            evaluation_id        str   (or NOT_AVAILABLE)
            session_id           str   (or NOT_AVAILABLE)
            outcome_class        str   (OutcomeClass.value)
            evaluation_confidence str  (EvaluationConfidence.value)
            experience_timestamp float

        And a KnowledgeContextKey describing the shared context.

    Output:
        KnowledgeCandidate (pre-validation; not yet inserted into the store)

    Confidence calculation (documented, deterministic):
        For each experience i with outcome class o_i and confidence c_i:
            evidence_weight_i = OUTCOME_WEIGHT[o_i] * CONFIDENCE_MULTIPLIER[c_i]

        weighted_score = sum(evidence_weight_i for valid evidence)
        max_possible   = sum(OUTCOME_WEIGHT['SUCCESS'] * CONFIDENCE_MULTIPLIER['HIGH']
                             for each valid evidence item)

        raw_ratio = weighted_score / max_possible   (clipped to [-1.0, 1.0])

        evidence_sufficiency = min(valid_count / minimum_evidence_count, 1.0)

        consistency = 1.0 - (negative_count / valid_count)
            where negative_count = failure + unsafe outcomes

        confidence = raw_ratio * evidence_sufficiency * consistency
            (clipped to [0.0, 1.0]; negative raw_ratio → confidence 0.0)
    """

    def __init__(self, config: AdaptiveKnowledgeConfig) -> None:
        self._config = config

    def aggregate(
        self,
        context_key: KnowledgeContextKey,
        experience_records: List[dict],
        candidate_seq: int = 0,
    ) -> KnowledgeCandidate:
        """
        Build a KnowledgeCandidate from the provided experience records.

        experience_records: list of dicts (see class docstring for keys).
        candidate_seq: monotonic sequence for unique candidate IDs.
        """
        knowledge_id = context_key.to_knowledge_id()
        candidate_id = _make_candidate_id(knowledge_id, candidate_seq)
        knowledge_type = _infer_knowledge_type(context_key)

        # Override type if the context key has an explicit knowledge_type
        if context_key.knowledge_type not in (NOT_AVAILABLE, ""):
            try:
                knowledge_type = KnowledgeType(context_key.knowledge_type)
            except ValueError:
                pass

        evidence_items: List[KnowledgeEvidence] = []
        ts_list: List[float] = []

        # Counters
        valid_count = 0
        success_count = 0
        failure_count = 0
        unsafe_count = 0
        weighted_sum = 0.0
        max_possible = 0.0

        for rec in experience_records:
            oc = str(rec.get("outcome_class", NOT_AVAILABLE))
            ec = str(rec.get("evaluation_confidence", "UNKNOWN"))
            try:
                ts = float(rec.get("experience_timestamp") or 0.0)
            except (TypeError, ValueError):
                ts = 0.0

            ow = OUTCOME_WEIGHT.get(oc, 0.0)
            cm = CONFIDENCE_MULTIPLIER.get(ec, CONFIDENCE_MULTIPLIER["UNKNOWN"])
            weight = ow * cm

            is_valid = oc in VALID_EVIDENCE_OUTCOMES
            is_negative = oc in ("FAILURE", "UNSAFE_OUTCOME")
            is_safety = oc == "UNSAFE_OUTCOME"
            is_invalid = oc in INVALID_EVIDENCE_OUTCOMES

            if is_invalid:
                # INVALID, NOT_EVALUATED, etc. — never count, never weight
                ev = KnowledgeEvidence(
                    experience_id=str(rec.get("experience_id", NOT_AVAILABLE)),
                    evaluation_id=str(rec.get("evaluation_id", NOT_AVAILABLE)),
                    session_id=str(rec.get("session_id", NOT_AVAILABLE)),
                    outcome_class=oc,
                    evaluation_confidence=ec,
                    experience_timestamp=ts,
                    weight=0.0,
                    is_valid_evidence=False,
                    is_negative_evidence=False,
                    is_safety_evidence=False,
                )
                evidence_items.append(ev)
                continue

            ev = KnowledgeEvidence(
                experience_id=str(rec.get("experience_id", NOT_AVAILABLE)),
                evaluation_id=str(rec.get("evaluation_id", NOT_AVAILABLE)),
                session_id=str(rec.get("session_id", NOT_AVAILABLE)),
                outcome_class=oc,
                evaluation_confidence=ec,
                experience_timestamp=ts,
                weight=weight,
                is_valid_evidence=is_valid,
                is_negative_evidence=is_negative,
                is_safety_evidence=is_safety,
            )
            evidence_items.append(ev)

            if is_valid:
                valid_count += 1
                ts_list.append(ts)
                if oc == "SUCCESS":
                    success_count += 1
                elif oc == "PARTIAL_SUCCESS":
                    success_count += 1  # counts toward success for threshold
                elif oc == "FAILURE":
                    failure_count += 1
                elif oc == "UNSAFE_OUTCOME":
                    unsafe_count += 1

                weighted_sum += weight
                # Maximum possible from this evidence item
                max_possible += (
                    OUTCOME_WEIGHT["SUCCESS"] * CONFIDENCE_MULTIPLIER["HIGH"]
                )

        # Confidence calculation
        if valid_count == 0 or max_possible <= 0.0:
            raw_ratio = 0.0
            evidence_sufficiency = 0.0
            consistency = 0.0
            confidence = 0.0
        else:
            raw_ratio = max(-1.0, min(1.0, weighted_sum / max_possible))
            min_ev = float(max(1, self._config.minimum_evidence_count))
            evidence_sufficiency = min(1.0, valid_count / min_ev)
            negative_count = failure_count + unsafe_count
            consistency = 1.0 - (negative_count / valid_count)
            # Only positive weighted_sum contributes to confidence
            if raw_ratio < 0.0:
                confidence = 0.0
            else:
                confidence = raw_ratio * evidence_sufficiency * consistency
            confidence = max(0.0, min(1.0, confidence))

        confidence_class = _classify_confidence(confidence)

        # Trim evidence to maximum_evidence_per_entry
        max_ev = max(1, self._config.maximum_evidence_per_entry)
        evidence_tuple = tuple(evidence_items[:max_ev])

        earliest = min(ts_list) if ts_list else 0.0
        latest = max(ts_list) if ts_list else 0.0

        relationship = _make_observed_relationship(
            context_key, success_count, failure_count, unsafe_count,
            valid_count, knowledge_type,
        )

        return KnowledgeCandidate(
            candidate_id=candidate_id,
            knowledge_id=knowledge_id,
            schema_version=KNOWLEDGE_SCHEMA_VERSION,
            context_key=context_key,
            knowledge_type=knowledge_type,
            observed_relationship=relationship,
            evidence=evidence_tuple,
            evidence_count=len(evidence_items),
            valid_evidence_count=valid_count,
            success_evidence_count=success_count,
            failure_evidence_count=failure_count,
            unsafe_evidence_count=unsafe_count,
            weighted_score=round(weighted_sum, 6),
            confidence=round(confidence, 6),
            confidence_class=confidence_class,
            consistency=round(consistency, 6),
            created_at=time.time(),
            earliest_evidence_at=earliest,
            latest_evidence_at=latest,
            source_phase="12.5",
            generation_method="evidence_aggregation",
        )
