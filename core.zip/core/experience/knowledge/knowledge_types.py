"""
IndiDrive AI — Phase 12.5 | Adaptive Knowledge Update Types
============================================================
Strongly-typed, compact containers for the Adaptive Knowledge layer.

Phase 12.5 answers ONLY:
    «"Across multiple validated driving experiences, what stable contextual
      pattern has been consistently observed?"»

Phase 12.5 does NOT:
    - change steering / throttle / braking          → pipeline
    - modify MPC / tracking / planner               → pipeline
    - change SafetyGate or safety thresholds        → safety subsystems
    - generate trajectories or policies             → planning
    - directly improve future runtime decisions     → Phase 12.6
    - use reinforcement learning / reward signals   → Phase 12.6
    - modify control policy                         → Phase 12.6
    - call external LLMs, cloud services, APIs

Design rules (consistent with all prior phases):
  * dataclasses — not raw dicts
  * explicit NOT_AVAILABLE / UNKNOWN — never fabricated
  * no hidden reasoning — every update is traceable to evidence
  * confidence ≠ uncertainty — kept separate
  * deterministic: same input → same output
  * immutable snapshots for external consumers
  * offline-first
  * versioned, provenance-aware, reversible, safety-aware

ID conventions (extend Phase 12.1–12.4):
    Record:      <session_id>-R<seq:06d>
    Evaluation:  <record_id>-EVAL
    Query:       <session_id>-Q<seq:06d>
    Knowledge:   K-<hash8>                    (stable, context-derived)
    Candidate:   CAND-<knowledge_id>-<seq>
    Update:      UPD-<knowledge_id>-<ts_hex>
"""
from __future__ import annotations

import hashlib
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import List, Optional, Tuple

NOT_AVAILABLE = "NOT_AVAILABLE"
KNOWLEDGE_SCHEMA_VERSION = "12.5"

# ---------------------------------------------------------------------------
# Knowledge lifecycle enums
# ---------------------------------------------------------------------------

class KnowledgeStatus(str, Enum):
    """
    Lifecycle state of a KnowledgeEntry.

    CANDIDATE    — generated from evidence but not yet validated.
    VALIDATED    — passed validation; ready to become ACTIVE.
    ACTIVE       — current best knowledge for this context pattern.
    WEAK         — evidence is thin or barely above thresholds.
    CONFLICTING  — evidence is contradictory; uncertain result.
    DEGRADED     — evidence quality was low; reliability reduced.
    STALE        — no supporting evidence for a configured time window.
    DEPRECATED   — superseded by a later version; kept for audit.
    REJECTED     — failed validation; must not be used.
    INVALID      — structurally invalid entry; ignored.
    """
    CANDIDATE   = "CANDIDATE"
    VALIDATED   = "VALIDATED"
    ACTIVE      = "ACTIVE"
    WEAK        = "WEAK"
    CONFLICTING = "CONFLICTING"
    DEGRADED    = "DEGRADED"
    STALE       = "STALE"
    DEPRECATED  = "DEPRECATED"
    REJECTED    = "REJECTED"
    INVALID     = "INVALID"


class KnowledgeType(str, Enum):
    """
    Semantic category of a KnowledgeEntry.

    Contextual — patterns derived from road/environment/traffic context.
    Situational — patterns derived from observed situation types.
    Hazard      — patterns involving hazard events and their outcomes.
    Safety      — patterns involving safety-critical observations.
                  Safety knowledge has stricter validation requirements.
    Temporal    — time-related patterns (repeated recurrence, session patterns).
    Reliability — patterns about evidence quality and stability.
    """
    CONTEXTUAL  = "CONTEXTUAL"
    SITUATIONAL = "SITUATIONAL"
    HAZARD      = "HAZARD"
    SAFETY      = "SAFETY"
    TEMPORAL    = "TEMPORAL"
    RELIABILITY = "RELIABILITY"


class KnowledgeConfidenceClass(str, Enum):
    """
    Categorical confidence band for a KnowledgeEntry.

    Derived deterministically from numeric confidence score:
        VERY_HIGH  ≥ 0.85
        HIGH       ≥ 0.70
        MODERATE   ≥ 0.50
        LOW        ≥ 0.30
        VERY_LOW   ≥ 0.10
        UNKNOWN    <  0.10 or evidence insufficient

    Confidence is based on:
        - number of supporting evaluations vs. configured minimum
        - success ratio among valid outcomes
        - consistency (absence of contradictions)
        - evidence quality (HIGH vs. LOW evaluation confidence)
    """
    VERY_HIGH = "VERY_HIGH"
    HIGH      = "HIGH"
    MODERATE  = "MODERATE"
    LOW       = "LOW"
    VERY_LOW  = "VERY_LOW"
    UNKNOWN   = "UNKNOWN"


class UpdateType(str, Enum):
    """
    Classification of a knowledge update operation.

    CREATE      — new KnowledgeEntry created from candidate.
    STRENGTHEN  — confidence increased by new supporting evidence.
    WEAKEN      — confidence reduced by contradictory evidence.
    CONFIRM     — evidence confirms existing knowledge; no change.
    CONTRADICT  — new evidence directly contradicts existing knowledge.
    REVISE      — knowledge pattern revised based on accumulated evidence.
    DEPRECATE   — existing entry deprecated; new version takes over.
    REJECT      — candidate rejected; does not become knowledge.
    """
    CREATE     = "CREATE"
    STRENGTHEN = "STRENGTHEN"
    WEAKEN     = "WEAKEN"
    CONFIRM    = "CONFIRM"
    CONTRADICT = "CONTRADICT"
    REVISE     = "REVISE"
    DEPRECATE  = "DEPRECATE"
    REJECT     = "REJECT"


class ValidationStatus(str, Enum):
    """
    Result of a knowledge candidate validation pass.

    ACCEPTED  — candidate met all configured thresholds.
    REJECTED  — candidate failed one or more required thresholds.
    DEFERRED  — candidate is below threshold; keep accumulating evidence.
    ERROR     — validation encountered an internal error.
    """
    ACCEPTED = "ACCEPTED"
    REJECTED = "REJECTED"
    DEFERRED = "DEFERRED"
    ERROR    = "ERROR"


# ---------------------------------------------------------------------------
# Evidence quality weight constants (deterministic, documented)
# ---------------------------------------------------------------------------

# Evidence weight by OutcomeClass.value
OUTCOME_WEIGHT: dict = {
    "SUCCESS":         1.0,
    "PARTIAL_SUCCESS": 0.6,
    "FAILURE":        -0.5,
    "UNSAFE_OUTCOME": -1.0,
    "DEGRADED":        0.2,
    "INCONCLUSIVE":    0.0,
    "NO_OUTCOME":      0.0,
    "INVALID":         0.0,   # never counted as evidence
    "PENDING":         0.0,
    "NOT_EVALUATED":   0.0,
    "EVALUATION_ERROR":0.0,
}

# Evidence quality multiplier by EvaluationConfidence.value
CONFIDENCE_MULTIPLIER: dict = {
    "HIGH":    1.0,
    "MEDIUM":  0.7,
    "LOW":     0.4,
    "UNKNOWN": 0.2,
}

# Outcomes that count as "valid" evidence (used for minimum_valid_evaluations)
VALID_EVIDENCE_OUTCOMES = frozenset({
    "SUCCESS", "PARTIAL_SUCCESS", "FAILURE", "UNSAFE_OUTCOME",
    "DEGRADED", "INCONCLUSIVE",
})

# Outcomes that never contribute positive evidence
INVALID_EVIDENCE_OUTCOMES = frozenset({
    "INVALID", "PENDING", "NOT_EVALUATED", "EVALUATION_ERROR",
})


# ---------------------------------------------------------------------------
# Context key used for knowledge identity
# ---------------------------------------------------------------------------

@dataclass
class KnowledgeContextKey:
    """
    Normalized feature set that identifies a knowledge entry uniquely.

    Two experiences are considered equivalent knowledge candidates if
    their KnowledgeContextKey hashes to the same value.

    All fields are normalized to uppercase stripped strings or NOT_AVAILABLE.
    knowledge_type is included in the hash so SAFETY vs. CONTEXTUAL for the
    same road context produce different knowledge IDs.
    """
    knowledge_type: str = NOT_AVAILABLE    # KnowledgeType.value
    road_type: str = NOT_AVAILABLE
    road_structure: str = NOT_AVAILABLE
    intersection_state: str = NOT_AVAILABLE
    hazard_level: str = NOT_AVAILABLE
    dominant_hazard: str = NOT_AVAILABLE
    traffic_density: str = NOT_AVAILABLE
    vulnerable_road_user_present: bool = False
    safety_state: str = NOT_AVAILABLE
    situation_type: str = NOT_AVAILABLE    # from ExperienceRecord

    @staticmethod
    def _n(v: str) -> str:
        """Normalize: strip, uppercase, replace empty with NOT_AVAILABLE."""
        if not isinstance(v, str):
            return NOT_AVAILABLE
        v = v.strip().upper()
        return v if v else NOT_AVAILABLE

    def normalized(self) -> "KnowledgeContextKey":
        return KnowledgeContextKey(
            knowledge_type=self._n(self.knowledge_type),
            road_type=self._n(self.road_type),
            road_structure=self._n(self.road_structure),
            intersection_state=self._n(self.intersection_state),
            hazard_level=self._n(self.hazard_level),
            dominant_hazard=self._n(self.dominant_hazard),
            traffic_density=self._n(self.traffic_density),
            vulnerable_road_user_present=bool(self.vulnerable_road_user_present),
            safety_state=self._n(self.safety_state),
            situation_type=self._n(self.situation_type),
        )

    def to_canonical_string(self) -> str:
        """Deterministic canonical representation for hashing."""
        n = self.normalized()
        parts = [
            f"kt={n.knowledge_type}",
            f"rt={n.road_type}",
            f"rs={n.road_structure}",
            f"is={n.intersection_state}",
            f"hl={n.hazard_level}",
            f"dh={n.dominant_hazard}",
            f"td={n.traffic_density}",
            f"vru={int(n.vulnerable_road_user_present)}",
            f"ss={n.safety_state}",
            f"sit={n.situation_type}",
        ]
        return "|".join(parts)

    def to_knowledge_id(self) -> str:
        """Stable, deterministic ID derived from the normalized context."""
        canonical = self.to_canonical_string()
        digest = hashlib.sha256(canonical.encode("utf-8")).hexdigest()[:8]
        return f"K-{digest.upper()}"

    def to_dict(self) -> dict:
        return {
            "knowledge_type": self.knowledge_type,
            "road_type": self.road_type,
            "road_structure": self.road_structure,
            "intersection_state": self.intersection_state,
            "hazard_level": self.hazard_level,
            "dominant_hazard": self.dominant_hazard,
            "traffic_density": self.traffic_density,
            "vulnerable_road_user_present": self.vulnerable_road_user_present,
            "safety_state": self.safety_state,
            "situation_type": self.situation_type,
        }


# ---------------------------------------------------------------------------
# Evidence item — one evaluated experience used as evidence
# ---------------------------------------------------------------------------

@dataclass
class KnowledgeEvidence:
    """
    One evaluated experience used as evidence for a KnowledgeEntry.

    Weight is computed deterministically:
        weight = OUTCOME_WEIGHT[outcome_class]
                 * CONFIDENCE_MULTIPLIER[evaluation_confidence]

    Negative weight = negative evidence (FAILURE, UNSAFE_OUTCOME).
    Zero weight     = no evidence contribution (INCONCLUSIVE, INVALID, …).
    """
    experience_id: str = NOT_AVAILABLE      # ExperienceRecord.record_id
    evaluation_id: str = NOT_AVAILABLE      # OutcomeEvaluation identifier
    session_id: str = NOT_AVAILABLE
    outcome_class: str = NOT_AVAILABLE      # OutcomeClass.value
    evaluation_confidence: str = NOT_AVAILABLE  # EvaluationConfidence.value
    experience_timestamp: float = 0.0
    weight: float = 0.0                     # deterministic; see formula above
    is_valid_evidence: bool = False         # True unless INVALID/NOT_EVALUATED/etc.
    is_negative_evidence: bool = False      # True if FAILURE or UNSAFE_OUTCOME
    is_safety_evidence: bool = False        # True if UNSAFE_OUTCOME or safety event


# ---------------------------------------------------------------------------
# Knowledge candidate — before validation
# ---------------------------------------------------------------------------

@dataclass
class KnowledgeCandidate:
    """
    Proposed knowledge, generated from accumulated evidence.

    A candidate must pass validation before becoming an active KnowledgeEntry.
    A single observation should generally not produce a high-confidence candidate.
    """
    candidate_id: str = NOT_AVAILABLE
    knowledge_id: str = NOT_AVAILABLE       # stable ID derived from context key
    schema_version: str = KNOWLEDGE_SCHEMA_VERSION

    # Context pattern this candidate describes
    context_key: KnowledgeContextKey = field(default_factory=KnowledgeContextKey)
    knowledge_type: KnowledgeType = KnowledgeType.CONTEXTUAL
    observed_relationship: str = NOT_AVAILABLE  # human-readable pattern summary

    # Evidence
    evidence: Tuple[KnowledgeEvidence, ...] = field(default_factory=tuple)
    evidence_count: int = 0
    valid_evidence_count: int = 0
    success_evidence_count: int = 0
    failure_evidence_count: int = 0
    unsafe_evidence_count: int = 0
    weighted_score: float = 0.0

    # Confidence
    confidence: float = 0.0
    confidence_class: KnowledgeConfidenceClass = KnowledgeConfidenceClass.UNKNOWN
    consistency: float = 0.0               # [0.0, 1.0]; 1.0 = no contradictions

    # Timestamps
    created_at: float = field(default_factory=time.time)
    earliest_evidence_at: float = 0.0
    latest_evidence_at: float = 0.0

    source_phase: str = "12.5"
    generation_method: str = "evidence_aggregation"


# ---------------------------------------------------------------------------
# Primary knowledge entry — versioned, provenance-aware
# ---------------------------------------------------------------------------

@dataclass
class KnowledgeEntry:
    """
    One unit of validated adaptive knowledge.

    Knowledge is NOT policy:
        «"Previous experiences in context X frequently produced outcome Y."»
    is allowed.

    But:
        «"When context X occurs, perform action Y."»
    is NOT allowed, and must never be stored here.

    Each update creates a new version; the previous version is DEPRECATED
    (status = DEPRECATED) and retained for audit. The new version has
    parent_version set to the previous version number.

    Safety knowledge (knowledge_type = SAFETY) requires stricter validation
    and must NEVER be used to reduce safety margins or bypass SafetyGate.
    """
    knowledge_id: str = NOT_AVAILABLE
    schema_version: str = KNOWLEDGE_SCHEMA_VERSION
    knowledge_type: KnowledgeType = KnowledgeType.CONTEXTUAL

    # Context this knowledge describes
    context_key: KnowledgeContextKey = field(default_factory=KnowledgeContextKey)
    observed_relationship: str = NOT_AVAILABLE  # descriptive, not prescriptive

    # Evidence summary (source IDs kept compact)
    supporting_experience_ids: Tuple[str, ...] = field(default_factory=tuple)
    supporting_evaluation_ids: Tuple[str, ...] = field(default_factory=tuple)
    evidence_count: int = 0
    valid_evidence_count: int = 0
    success_evidence_count: int = 0
    failure_evidence_count: int = 0
    unsafe_evidence_count: int = 0
    weighted_score: float = 0.0

    # Confidence
    confidence: float = 0.0                # [0.0, 1.0]; see KnowledgeConfidenceClass
    confidence_class: KnowledgeConfidenceClass = KnowledgeConfidenceClass.UNKNOWN
    consistency: float = 0.0              # [0.0, 1.0]; 1.0 = no contradictions
    uncertainty: float = 0.0              # explicit uncertainty estimate

    # Status
    status: KnowledgeStatus = KnowledgeStatus.CANDIDATE

    # Timestamps
    created_at: float = field(default_factory=time.time)
    updated_at: float = field(default_factory=time.time)
    last_evidence_at: float = 0.0

    # Provenance
    source_phase: str = "12.5"
    generation_method: str = "evidence_aggregation"
    validation_method: str = "threshold_validation"

    # Versioning
    version: int = 1
    parent_version: Optional[int] = None

    # Staleness flag (set by knowledge store, not by update engine)
    degraded: bool = False

    def to_snapshot(self) -> "KnowledgeEntrySnapshot":
        return KnowledgeEntrySnapshot(
            knowledge_id=self.knowledge_id,
            schema_version=self.schema_version,
            knowledge_type=self.knowledge_type,
            context_key=self.context_key,
            observed_relationship=self.observed_relationship,
            evidence_count=self.evidence_count,
            valid_evidence_count=self.valid_evidence_count,
            success_evidence_count=self.success_evidence_count,
            failure_evidence_count=self.failure_evidence_count,
            unsafe_evidence_count=self.unsafe_evidence_count,
            weighted_score=self.weighted_score,
            confidence=self.confidence,
            confidence_class=self.confidence_class,
            consistency=self.consistency,
            uncertainty=self.uncertainty,
            status=self.status,
            created_at=self.created_at,
            updated_at=self.updated_at,
            last_evidence_at=self.last_evidence_at,
            version=self.version,
            parent_version=self.parent_version,
            degraded=self.degraded,
            supporting_experience_ids=self.supporting_experience_ids,
            supporting_evaluation_ids=self.supporting_evaluation_ids,
        )


@dataclass
class KnowledgeEntrySnapshot:
    """
    Immutable read-only view of a KnowledgeEntry for external consumers.

    Does NOT expose mutable state.
    Does NOT provide a direct execute_action() or equivalent.
    """
    knowledge_id: str = NOT_AVAILABLE
    schema_version: str = KNOWLEDGE_SCHEMA_VERSION
    knowledge_type: KnowledgeType = KnowledgeType.CONTEXTUAL
    context_key: KnowledgeContextKey = field(default_factory=KnowledgeContextKey)
    observed_relationship: str = NOT_AVAILABLE
    evidence_count: int = 0
    valid_evidence_count: int = 0
    success_evidence_count: int = 0
    failure_evidence_count: int = 0
    unsafe_evidence_count: int = 0
    weighted_score: float = 0.0
    confidence: float = 0.0
    confidence_class: KnowledgeConfidenceClass = KnowledgeConfidenceClass.UNKNOWN
    consistency: float = 0.0
    uncertainty: float = 0.0
    status: KnowledgeStatus = KnowledgeStatus.CANDIDATE
    created_at: float = 0.0
    updated_at: float = 0.0
    last_evidence_at: float = 0.0
    version: int = 1
    parent_version: Optional[int] = None
    degraded: bool = False
    supporting_experience_ids: Tuple[str, ...] = field(default_factory=tuple)
    supporting_evaluation_ids: Tuple[str, ...] = field(default_factory=tuple)


# ---------------------------------------------------------------------------
# Audit record — one knowledge update event
# ---------------------------------------------------------------------------

@dataclass
class KnowledgeUpdateRecord:
    """
    Audit record for one knowledge update event.

    Every knowledge mutation produces one KnowledgeUpdateRecord.
    These records are append-only and never deleted.
    """
    update_id: str = NOT_AVAILABLE
    knowledge_id: str = NOT_AVAILABLE
    update_type: UpdateType = UpdateType.CREATE
    previous_version: Optional[int] = None
    new_version: int = 1
    reason: str = NOT_AVAILABLE
    evidence_ids: Tuple[str, ...] = field(default_factory=tuple)
    timestamp: float = field(default_factory=time.time)
    validation_status: ValidationStatus = ValidationStatus.ACCEPTED
    notes: str = NOT_AVAILABLE


# ---------------------------------------------------------------------------
# Knowledge update result — returned from knowledge engine
# ---------------------------------------------------------------------------

@dataclass
class KnowledgeUpdateResult:
    """
    Result of one knowledge update attempt.

    returned by KnowledgeUpdateEngine after processing a candidate.
    """
    success: bool = False
    update_type: UpdateType = UpdateType.REJECT
    knowledge_id: str = NOT_AVAILABLE
    new_version: Optional[int] = None
    previous_version: Optional[int] = None
    validation_status: ValidationStatus = ValidationStatus.REJECTED
    reason: str = NOT_AVAILABLE
    error: Optional[str] = None


# ---------------------------------------------------------------------------
# Knowledge store result — listing and lookup
# ---------------------------------------------------------------------------

@dataclass
class KnowledgeContext:
    """
    Read-only context view exposed to external subsystems.

    This is the ONLY interface through which adaptive knowledge may be
    observed by the rest of the system.

    It does NOT provide:
        - execute_action()
        - set_policy()
        - modify_parameter()
        - any method that changes system state

    External consumers may use this context to INFORM (not dictate)
    human review, reporting, or future Phase 12.6 decision improvement.
    """
    knowledge_id: str = NOT_AVAILABLE
    knowledge_type: KnowledgeType = KnowledgeType.CONTEXTUAL
    confidence: float = 0.0
    confidence_class: KnowledgeConfidenceClass = KnowledgeConfidenceClass.UNKNOWN
    status: KnowledgeStatus = KnowledgeStatus.CANDIDATE
    evidence_count: int = 0
    observed_relationship: str = NOT_AVAILABLE
    uncertainty: float = 0.0
    version: int = 1
    updated_at: float = 0.0
    degraded: bool = False
    # Provenance (read-only summary)
    supporting_experience_count: int = 0
    supporting_evaluation_count: int = 0


# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

@dataclass
class AdaptiveKnowledgeConfig:
    """
    Configuration for Phase 12.5 Adaptive Knowledge Update.

    All thresholds are configurable. No arbitrary values are hard-coded
    without documented justification.

    Evidence thresholds:
        minimum_evidence_count      — minimum valid evaluations before
                                      a candidate can become ACTIVE knowledge.
                                      Default 3 prevents single-observation
                                      knowledge (justified: one event is not a
                                      reliable pattern in a safety system).

        minimum_confidence          — minimum numeric confidence required.
                                      Default 0.40 is LOW-MODERATE boundary,
                                      chosen to avoid noise below 40%.

        minimum_consistency         — [0.0, 1.0] ratio of non-contradictory
                                      evidence. Default 0.60 allows some
                                      disagreement while requiring majority
                                      consistency.

        minimum_success_ratio       — ratio of success+partial_success among
                                      valid outcomes. Default 0.0 means
                                      knowledge can be formed from failure
                                      patterns (negative knowledge).

    Safety:
        safety_minimum_evidence_count — stricter minimum for SAFETY type.
                                        Default 5.

        safety_minimum_confidence     — stricter minimum for SAFETY type.
                                        Default 0.60.

    Staleness:
        stale_after_seconds         — mark ACTIVE knowledge STALE if it
                                      has received no evidence for this
                                      duration. 0 = disabled.
                                      Default 0 (disabled).

    Capacity:
        maximum_entries             — maximum live KnowledgeEntry objects
                                      (all statuses). 0 = unlimited.
                                      Default 500.

        maximum_history_per_entry   — maximum previous versions kept per
                                      knowledge_id. Default 10.

        maximum_evidence_per_entry  — maximum KnowledgeEvidence refs kept
                                      per entry version. Default 50.
    """
    enabled: bool = True

    # Evidence thresholds
    minimum_evidence_count: int = 3
    minimum_confidence: float = 0.40
    minimum_consistency: float = 0.60
    minimum_success_ratio: float = 0.0
    allow_partial_evidence: bool = True
    allow_degraded_evidence: bool = True
    allow_negative_evidence: bool = True

    # Safety-type stricter thresholds
    safety_minimum_evidence_count: int = 5
    safety_minimum_confidence: float = 0.60

    # Staleness (0 = disabled)
    stale_after_seconds: float = 0.0

    # Capacity
    maximum_entries: int = 500
    maximum_history_per_entry: int = 10
    maximum_evidence_per_entry: int = 50

    @staticmethod
    def default() -> "AdaptiveKnowledgeConfig":
        return AdaptiveKnowledgeConfig()

    @staticmethod
    def strict() -> "AdaptiveKnowledgeConfig":
        """Higher-bar thresholds for safety-critical environments."""
        return AdaptiveKnowledgeConfig(
            minimum_evidence_count=5,
            minimum_confidence=0.60,
            minimum_consistency=0.70,
            safety_minimum_evidence_count=8,
            safety_minimum_confidence=0.75,
        )


# ---------------------------------------------------------------------------
# Snapshot of the knowledge store state
# ---------------------------------------------------------------------------

@dataclass
class KnowledgeStoreSnapshot:
    """
    Point-in-time summary of the adaptive knowledge store.
    Immutable; safe for external consumers.
    """
    schema_version: str = KNOWLEDGE_SCHEMA_VERSION
    timestamp: float = field(default_factory=time.time)
    total_entries: int = 0
    active_entries: int = 0
    candidate_entries: int = 0
    deprecated_entries: int = 0
    rejected_entries: int = 0
    conflicting_entries: int = 0
    stale_entries: int = 0
    total_update_records: int = 0
    store_healthy: bool = True
    store_error: Optional[str] = None


__all__ = [
    "NOT_AVAILABLE",
    "KNOWLEDGE_SCHEMA_VERSION",
    "OUTCOME_WEIGHT",
    "CONFIDENCE_MULTIPLIER",
    "VALID_EVIDENCE_OUTCOMES",
    "INVALID_EVIDENCE_OUTCOMES",
    "KnowledgeStatus",
    "KnowledgeType",
    "KnowledgeConfidenceClass",
    "UpdateType",
    "ValidationStatus",
    "KnowledgeContextKey",
    "KnowledgeEvidence",
    "KnowledgeCandidate",
    "KnowledgeEntry",
    "KnowledgeEntrySnapshot",
    "KnowledgeUpdateRecord",
    "KnowledgeUpdateResult",
    "KnowledgeContext",
    "AdaptiveKnowledgeConfig",
    "KnowledgeStoreSnapshot",
]
