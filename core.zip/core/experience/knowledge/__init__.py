"""
IndiDrive AI — Phase 12.5 | Adaptive Knowledge Update
======================================================
Public API for the Phase 12.5 adaptive knowledge layer.

Phase 12.5 updates ONLY the knowledge store.
It does NOT:
    - change steering / throttle / braking          → pipeline
    - modify MPC / tracking / planner               → pipeline
    - change SafetyGate or safety thresholds        → safety subsystems
    - generate trajectories or control policies     → Phase 12.6
    - directly improve future runtime decisions     → Phase 12.6

Typical usage
-------------
from core.experience.knowledge import (
    KnowledgeUpdateEngine,
    KnowledgeStore,
    KnowledgeContextKey,
    AdaptiveKnowledgeConfig,
)

config = AdaptiveKnowledgeConfig.default()
store  = KnowledgeStore(config)
engine = KnowledgeUpdateEngine(config, store)

result = engine.process_experiences(
    context_key=KnowledgeContextKey(
        road_type="URBAN",
        intersection_state="ACTIVE",
        hazard_level="MEDIUM",
        situation_type="PEDESTRIAN_CROSSING",
    ),
    experience_records=[
        {
            "experience_id":         "sess1-R000001",
            "evaluation_id":         "sess1-R000001-EVAL",
            "session_id":            "sess1",
            "outcome_class":         "SUCCESS",
            "evaluation_confidence": "HIGH",
            "experience_timestamp":  1_700_000_000.0,
        },
        ...
    ],
)

# Read-only context for other subsystems (no execute_action())
ctx = store.get_knowledge_context(result.knowledge_id)
"""

from .knowledge_types import (
    NOT_AVAILABLE,
    KNOWLEDGE_SCHEMA_VERSION,
    OUTCOME_WEIGHT,
    CONFIDENCE_MULTIPLIER,
    VALID_EVIDENCE_OUTCOMES,
    INVALID_EVIDENCE_OUTCOMES,
    KnowledgeStatus,
    KnowledgeType,
    KnowledgeConfidenceClass,
    UpdateType,
    ValidationStatus,
    KnowledgeContextKey,
    KnowledgeEvidence,
    KnowledgeCandidate,
    KnowledgeEntry,
    KnowledgeEntrySnapshot,
    KnowledgeUpdateRecord,
    KnowledgeUpdateResult,
    KnowledgeContext,
    AdaptiveKnowledgeConfig,
    KnowledgeStoreSnapshot,
)
from .evidence_aggregator import EvidenceAggregator
from .knowledge_validator import KnowledgeValidator
from .knowledge_store import KnowledgeStore
from .knowledge_update_engine import KnowledgeUpdateEngine

__all__ = [
    "NOT_AVAILABLE",
    "KNOWLEDGE_SCHEMA_VERSION",
    "OUTCOME_WEIGHT",
    "CONFIDENCE_MULTIPLIER",
    "VALID_EVIDENCE_OUTCOMES",
    "INVALID_EVIDENCE_OUTCOMES",
    # Enums
    "KnowledgeStatus",
    "KnowledgeType",
    "KnowledgeConfidenceClass",
    "UpdateType",
    "ValidationStatus",
    # Domain models
    "KnowledgeContextKey",
    "KnowledgeEvidence",
    "KnowledgeCandidate",
    "KnowledgeEntry",
    "KnowledgeEntrySnapshot",
    "KnowledgeUpdateRecord",
    "KnowledgeUpdateResult",
    "KnowledgeContext",
    "KnowledgeStoreSnapshot",
    # Configuration
    "AdaptiveKnowledgeConfig",
    # Components
    "EvidenceAggregator",
    "KnowledgeValidator",
    "KnowledgeStore",
    "KnowledgeUpdateEngine",
]
