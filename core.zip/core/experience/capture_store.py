"""
IndiDrive AI — Phase 12.1 | Experience Capture Store
=====================================================
Lightweight, offline-first, bounded storage abstraction for
captured driving experience observations and events.

Design principles:
  * No external database (no MongoDB, Redis, FAISS, PostgreSQL, cloud).
  * Bounded memory — configurable per-session limits enforced strictly.
  * Retention policy applied deterministically when bounds are reached.
  * Thread-safe via a single threading.Lock (lock scope kept minimal).
  * Failure-isolated — storage failures do not propagate to the pipeline.
  * No raw sensor data stored — only compact structured observations/events.

This module does NOT:
  - perform learning, adaptation, or reward calculation.
  - retrieve similar experiences (→ Phase 12.4).
  - modify planning, control, or safety decisions.
"""
from __future__ import annotations

import threading
import time
from typing import List, Optional, Tuple

from .experience_types import (
    NOT_AVAILABLE,
    CaptureEvent,
    CaptureEventType,
    DrivingExperienceSession,
    ExperienceCaptureConfig,
    ExperienceCaptureSnapshot,
    ExperienceCaptureStatus,
    ExperienceObservation,
    RetentionPolicy,
    SessionStatus,
)

__all__ = ["ExperienceCaptureStore"]


class ExperienceCaptureStore:
    """
    Bounded in-memory store for one active driving experience session.

    One store manages one active session at a time.  When a new session
    is started, the previous session data is replaced.

    Thread safety
    -------------
    All public methods acquire self._lock (a reentrant lock).
    Snapshots return copies of collections — callers cannot mutate
    internal state through the snapshot.

    Memory bounds
    -------------
    Observations and events are bounded by ExperienceCaptureConfig.
    When the bound is reached, the retention policy is applied:
      BOUNDED_FIFO    — oldest item dropped (deque-like).
      EVENT_PRIORITY  — for observations: oldest dropped; for events: always kept.
    """

    def __init__(self, config: ExperienceCaptureConfig) -> None:
        if not isinstance(config, ExperienceCaptureConfig):
            raise TypeError(
                f"ExperienceCaptureStore requires ExperienceCaptureConfig, "
                f"got {type(config)}"
            )
        self._cfg = config
        self._lock = threading.Lock()
        self._session: Optional[DrivingExperienceSession] = None
        self._status: ExperienceCaptureStatus = ExperienceCaptureStatus.IDLE
        self._failure_reason: str = NOT_AVAILABLE
        self._total_observations: int = 0  # lifetime counter (not bounded by session)
        self._total_events: int = 0

    # ------------------------------------------------------------------
    # Session lifecycle

    def start_session(self, session_id: str, timestamp: Optional[float] = None) -> bool:
        """
        Start a new capture session.  Replaces any active session.

        Returns True on success, False on failure (failure reason stored).
        """
        if not session_id or session_id == NOT_AVAILABLE:
            self._record_failure("start_session: session_id is empty or NOT_AVAILABLE")
            return False

        ts = timestamp if timestamp is not None else time.time()
        with self._lock:
            self._session = DrivingExperienceSession(
                session_id=session_id,
                start_timestamp=ts,
                last_timestamp=ts,
                observation_count=0,
                event_count=0,
                status=SessionStatus.ACTIVE,
                _observations=[],
                _events=[],
            )
            self._status = ExperienceCaptureStatus.ACTIVE
            self._failure_reason = NOT_AVAILABLE
        return True

    def finalize_session(self, degraded: bool = False) -> bool:
        """
        Mark the active session as completed (or degraded if flagged).

        Returns True on success.
        """
        with self._lock:
            if self._session is None:
                return False
            self._session.status = (
                SessionStatus.DEGRADED if degraded else SessionStatus.COMPLETED
            )
            self._status = ExperienceCaptureStatus.IDLE
        return True

    def clear_session(self) -> None:
        """Drop all session data and reset to IDLE."""
        with self._lock:
            self._session = None
            self._status = ExperienceCaptureStatus.IDLE
            self._failure_reason = NOT_AVAILABLE

    # ------------------------------------------------------------------
    # Append operations

    def append_observation(
        self, obs: ExperienceObservation
    ) -> bool:
        """
        Append one observation to the active session.

        Applies the retention policy when bounds are reached.
        Returns True on success, False on failure.
        """
        if not self._cfg.observation_capture_enabled:
            return True  # silently skip — not a failure

        with self._lock:
            if self._session is None:
                self._record_failure("append_observation: no active session")
                return False
            if self._session.status != SessionStatus.ACTIVE:
                return False  # session not accepting observations

            obs_list = self._session._observations
            max_obs = self._cfg.max_observations_per_session

            if len(obs_list) >= max_obs:
                self._apply_retention_observations(obs_list, max_obs)
                self._status = ExperienceCaptureStatus.OVERFLOW

            obs_list.append(obs)
            self._session.observation_count = len(obs_list)
            self._session.last_timestamp = obs.timestamp if obs.timestamp > 0.0 else time.time()
            self._total_observations += 1

        return True

    def append_event(self, event: CaptureEvent) -> bool:
        """
        Append one event to the active session.

        Returns True on success, False on failure.
        """
        if not self._cfg.event_capture_enabled:
            return True  # silently skip — not a failure

        with self._lock:
            if self._session is None:
                self._record_failure("append_event: no active session")
                return False
            if self._session.status != SessionStatus.ACTIVE:
                return False

            ev_list = self._session._events
            max_ev = self._cfg.max_events_per_session

            if len(ev_list) >= max_ev:
                self._apply_retention_events(ev_list, max_ev)
                self._status = ExperienceCaptureStatus.OVERFLOW

            ev_list.append(event)
            self._session.event_count = len(ev_list)
            self._session.last_timestamp = event.timestamp if event.timestamp > 0.0 else time.time()
            self._total_events += 1

        return True

    # ------------------------------------------------------------------
    # Retrieval operations

    def get_recent_observations(
        self, n: Optional[int] = None
    ) -> Tuple[ExperienceObservation, ...]:
        """
        Return up to n most recent observations as an immutable tuple.

        n defaults to config.recent_window_observations.
        Never exposes internal mutable list.
        """
        window = n if n is not None else self._cfg.recent_window_observations
        with self._lock:
            if self._session is None:
                return ()
            obs = self._session._observations
            return tuple(obs[-window:])

    def get_recent_events(
        self, n: Optional[int] = None
    ) -> Tuple[CaptureEvent, ...]:
        """
        Return up to n most recent events as an immutable tuple.

        n defaults to config.recent_window_events.
        """
        window = n if n is not None else self._cfg.recent_window_events
        with self._lock:
            if self._session is None:
                return ()
            ev = self._session._events
            return tuple(ev[-window:])

    def get_session_snapshot(self) -> ExperienceCaptureSnapshot:
        """
        Return an immutable snapshot of the current capture state.

        Safe to call from any thread; does not expose mutable collections.
        """
        with self._lock:
            if self._session is None:
                return ExperienceCaptureSnapshot(
                    capture_status=self._status,
                    session_status=SessionStatus.UNKNOWN,
                    session_id=NOT_AVAILABLE,
                    capture_failed=(self._status == ExperienceCaptureStatus.FAILED),
                    failure_reason=self._failure_reason,
                )
            obs_window = self._cfg.recent_window_observations
            ev_window = self._cfg.recent_window_events
            recent_obs = tuple(self._session._observations[-obs_window:])
            recent_ev = tuple(self._session._events[-ev_window:])
            return ExperienceCaptureSnapshot(
                session_id=self._session.session_id,
                session_status=self._session.status,
                capture_status=self._status,
                observation_count=self._session.observation_count,
                event_count=self._session.event_count,
                recent_observations=recent_obs,
                recent_events=recent_ev,
                capture_failed=(self._status == ExperienceCaptureStatus.FAILED),
                failure_reason=self._failure_reason,
            )

    # ------------------------------------------------------------------
    # Status queries

    @property
    def is_active(self) -> bool:
        with self._lock:
            return self._status == ExperienceCaptureStatus.ACTIVE

    @property
    def has_session(self) -> bool:
        with self._lock:
            return self._session is not None

    @property
    def capture_status(self) -> ExperienceCaptureStatus:
        with self._lock:
            return self._status

    # ------------------------------------------------------------------
    # Internal helpers

    def _apply_retention_observations(
        self, obs_list: List[ExperienceObservation], max_count: int
    ) -> None:
        """Apply retention policy to observation list when at capacity."""
        policy = self._cfg.retention_policy
        if policy == RetentionPolicy.EVENT_PRIORITY:
            # For observations: same as BOUNDED_FIFO (events are separate).
            obs_list.pop(0)
        else:
            # BOUNDED_FIFO (default)
            obs_list.pop(0)

    def _apply_retention_events(
        self, ev_list: List[CaptureEvent], max_count: int
    ) -> None:
        """Apply retention policy to event list when at capacity."""
        policy = self._cfg.retention_policy
        if policy == RetentionPolicy.EVENT_PRIORITY:
            # Events are always kept; drop non-NORMAL_DRIVING items first.
            # If all are event-type, drop oldest.
            for i, e in enumerate(ev_list):
                if e.event_type == CaptureEventType.NORMAL_DRIVING:
                    ev_list.pop(i)
                    return
            ev_list.pop(0)
        else:
            ev_list.pop(0)

    def _record_failure(self, reason: str) -> None:
        """Record a capture failure without crashing the pipeline."""
        self._failure_reason = reason
        self._status = ExperienceCaptureStatus.FAILED
