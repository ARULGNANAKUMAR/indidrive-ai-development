"""
IndiDrive AI — Phase 12.1 | Driving Experience Capture Types
=============================================================
Strongly-typed, compact data containers for the Experience Capture layer.

Phase 12.1 answers ONLY:
    «"What happened during this driving cycle/session that may later
      become an experience?"»

Phase 12.1 does NOT answer:
    - "Was this experience successful?"       → Phase 12.3
    - "Have we seen a similar situation?"     → Phase 12.4
    - "How should the vehicle behave next?"   → Phase 12.5 / 12.6

Design rules (consistent with all prior phases):
  * dataclasses — not raw dicts
  * explicit NOT_AVAILABLE / UNKNOWN — never fabricated
  * no raw sensor frames, no point clouds, no video
  * confidence ≠ uncertainty — kept separate
  * deterministic: same input → same output
  * compact: bounded collections, summaries only
  * immutable snapshots (ExperienceCaptureSnapshot)
  * offline — no LLM, no cloud, no neural networks
  * no learning, no reward, no policy update

This module contains ONLY structural containers.
Computation lives in capture_engine.py.
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from enum import Enum
from typing import List, Optional, Tuple

__all__ = [
    # Sentinel / schema
    "NOT_AVAILABLE",
    "EXPERIENCE_SCHEMA_VERSION",
    # Enums
    "ExperienceCaptureStatus",
    "SessionStatus",
    "CaptureEventType",
    "CaptureDataValidity",
    "RetentionPolicy",
    # Sub-structures
    "EgoContextSummary",
    "EnvironmentSummary",
    "SituationSummary",
    "PlanningSummary",
    "ControlSummary",
    "SafetySummary",
    "CaptureEventEvidence",
    # Primary containers
    "CaptureEvent",
    "ExperienceObservation",
    "DrivingExperienceSession",
    "ExperienceCaptureSnapshot",
    "ExperienceCaptureConfig",
]

NOT_AVAILABLE = "NOT_AVAILABLE"

# Schema version — bump on backward-incompatible field changes.
EXPERIENCE_SCHEMA_VERSION = "12.1"


# ---------------------------------------------------------------------------
# Top-level status enums
# ---------------------------------------------------------------------------

class ExperienceCaptureStatus(str, Enum):
    """
    Overall operational status of the experience capture layer.

    ACTIVE      — capturing observations and events normally.
    PAUSED      — capture temporarily suspended (e.g. safety interlock).
    DEGRADED    — capture running but with reduced fidelity (upstream stale).
    OVERFLOW    — session bounds reached; retention policy applied.
    FAILED      — capture encountered an unrecoverable internal error.
                  Autonomous pipeline is NOT affected.
    IDLE        — capture initialised but no active session.
    UNKNOWN     — status cannot be determined.
    """
    ACTIVE   = "ACTIVE"
    PAUSED   = "PAUSED"
    DEGRADED = "DEGRADED"
    OVERFLOW = "OVERFLOW"
    FAILED   = "FAILED"
    IDLE     = "IDLE"
    UNKNOWN  = "UNKNOWN"


class SessionStatus(str, Enum):
    """
    State of a DrivingExperienceSession.

    ACTIVE    — session is open and accepting observations.
    PAUSED    — session is open but temporarily not accepting observations.
    COMPLETED — session was cleanly finalized.
    DEGRADED  — session finalized in a degraded state (some data missing/stale).
    INVALID   — session data is structurally invalid; not suitable for later use.
    UNKNOWN   — session state cannot be determined.
    """
    ACTIVE    = "ACTIVE"
    PAUSED    = "PAUSED"
    COMPLETED = "COMPLETED"
    DEGRADED  = "DEGRADED"
    INVALID   = "INVALID"
    UNKNOWN   = "UNKNOWN"


class CaptureEventType(str, Enum):
    """
    Classification of a notable driving event captured from existing pipeline state.

    Events are derived entirely from existing system evidence; no new algorithms.
    Use UNKNOWN_EVENT when no evidence supports a more specific classification.
    """
    NORMAL_DRIVING         = "NORMAL_DRIVING"
    HAZARD_DETECTED        = "HAZARD_DETECTED"
    PATH_RISK_INCREASED    = "PATH_RISK_INCREASED"
    REPLANNING_TRIGGERED   = "REPLANNING_TRIGGERED"
    REPLANNING_REQUIRED    = "REPLANNING_REQUIRED"
    EMERGENCY_DETECTED     = "EMERGENCY_DETECTED"
    SAFETY_RESTRICTION     = "SAFETY_RESTRICTION"
    CONTROL_DEGRADATION    = "CONTROL_DEGRADATION"
    SENSOR_DEGRADATION     = "SENSOR_DEGRADATION"
    TRACKING_DEGRADATION   = "TRACKING_DEGRADATION"
    PLANNING_DEGRADATION   = "PLANNING_DEGRADATION"
    MPC_DEGRADATION        = "MPC_DEGRADATION"
    FAIL_SAFE_EVENT        = "FAIL_SAFE_EVENT"
    ROAD_HAZARD_EVENT      = "ROAD_HAZARD_EVENT"
    VULNERABLE_USER_EVENT  = "VULNERABLE_USER_EVENT"
    CATTLE_EVENT           = "CATTLE_EVENT"
    INTERSECTION_EVENT     = "INTERSECTION_EVENT"
    HIGHWAY_MERGE_EVENT    = "HIGHWAY_MERGE_EVENT"
    UNMARKED_ROAD_EVENT    = "UNMARKED_ROAD_EVENT"
    NARROW_ROAD_EVENT      = "NARROW_ROAD_EVENT"
    MIXED_TRAFFIC_EVENT    = "MIXED_TRAFFIC_EVENT"
    UNKNOWN_EVENT          = "UNKNOWN_EVENT"


class CaptureDataValidity(str, Enum):
    """
    Validity / freshness state of one captured data item.

    VALID     — data is current and structurally correct.
    STALE     — data is older than the configured stale threshold.
    DEGRADED  — data is present but quality is below threshold.
    INVALID   — data is structurally incorrect or failed validation.
    UNKNOWN   — validity cannot be determined.
    """
    VALID    = "VALID"
    STALE    = "STALE"
    DEGRADED = "DEGRADED"
    INVALID  = "INVALID"
    UNKNOWN  = "UNKNOWN"


class RetentionPolicy(str, Enum):
    """
    Retention policy applied when session bounds are reached.

    BOUNDED_FIFO    — oldest observations/events are dropped when limit reached.
    EVENT_PRIORITY  — non-event observations are dropped first; events retained.
    """
    BOUNDED_FIFO   = "BOUNDED_FIFO"
    EVENT_PRIORITY = "EVENT_PRIORITY"


# ---------------------------------------------------------------------------
# Ego context summary — compact ego state at capture time
# ---------------------------------------------------------------------------

@dataclass
class EgoContextSummary:
    """
    Compact ego vehicle state captured from existing pipeline.

    Values are summaries only — no raw IMU, no point clouds.
    None = unavailable; NOT_AVAILABLE = field not applicable.
    """
    position_x: Optional[float] = None      # metres
    position_y: Optional[float] = None      # metres
    position_z: Optional[float] = None      # metres
    velocity_ms: Optional[float] = None     # speed magnitude (m/s)
    acceleration_ms2: Optional[float] = None  # longitudinal (m/s²)
    yaw_rad: Optional[float] = None          # heading (rad)
    yaw_rate_rads: Optional[float] = None    # yaw rate (rad/s)
    vehicle_state_validity: str = NOT_AVAILABLE  # VALID | STALE | DEGRADED | UNKNOWN

    def to_dict(self) -> dict:
        def _r(v):
            return round(v, 4) if v is not None else NOT_AVAILABLE
        return {
            "position_x": _r(self.position_x),
            "position_y": _r(self.position_y),
            "position_z": _r(self.position_z),
            "velocity_ms": _r(self.velocity_ms),
            "acceleration_ms2": _r(self.acceleration_ms2),
            "yaw_rad": _r(self.yaw_rad),
            "yaw_rate_rads": _r(self.yaw_rate_rads),
            "vehicle_state_validity": self.vehicle_state_validity,
        }


# ---------------------------------------------------------------------------
# Environment summary — compact ambient scene context
# ---------------------------------------------------------------------------

@dataclass
class EnvironmentSummary:
    """
    Compact environment snapshot derived from the World Model.

    Stores counts and flags — NOT full WorldObject lists.
    Relevant object IDs are stored as a bounded tuple for traceability.
    """
    nearby_object_count: int = 0
    relevant_object_ids: Tuple[str, ...] = field(default_factory=tuple)  # bounded
    object_type_summary: str = NOT_AVAILABLE   # e.g. "CAR:2,PEDESTRIAN:1"
    vulnerable_road_user_present: bool = False
    cattle_present: bool = False
    road_hazard_present: bool = False
    road_anomaly_summary: str = NOT_AVAILABLE  # e.g. "POTHOLE:1"
    road_type: str = NOT_AVAILABLE             # VILLAGE_ROAD | URBAN | HIGHWAY | ...
    road_structure: str = NOT_AVAILABLE        # e.g. marking_state
    lane_road_marking_state: str = NOT_AVAILABLE
    intersection_state: str = NOT_AVAILABLE
    traffic_density: str = NOT_AVAILABLE
    traffic_mix: str = NOT_AVAILABLE
    world_model_validity: str = NOT_AVAILABLE  # VALID | PARTIAL | DEGRADED | EMPTY

    def to_dict(self) -> dict:
        return {
            "nearby_object_count": self.nearby_object_count,
            "relevant_object_ids": list(self.relevant_object_ids),
            "object_type_summary": self.object_type_summary,
            "vulnerable_road_user_present": self.vulnerable_road_user_present,
            "cattle_present": self.cattle_present,
            "road_hazard_present": self.road_hazard_present,
            "road_anomaly_summary": self.road_anomaly_summary,
            "road_type": self.road_type,
            "road_structure": self.road_structure,
            "lane_road_marking_state": self.lane_road_marking_state,
            "intersection_state": self.intersection_state,
            "traffic_density": self.traffic_density,
            "traffic_mix": self.traffic_mix,
            "world_model_validity": self.world_model_validity,
        }


# ---------------------------------------------------------------------------
# Situation summary — compact reasoning output snapshot
# ---------------------------------------------------------------------------

@dataclass
class SituationSummary:
    """
    Compact situation/reasoning snapshot.

    Captures existing reasoning engine outputs only.
    No new situation analysis is performed here.
    """
    situation_type: str = NOT_AVAILABLE       # SituationCategory.value
    hazard_level: str = NOT_AVAILABLE         # RiskLevel.value
    dominant_hazard: str = NOT_AVAILABLE      # HazardCategory.value or NOT_AVAILABLE
    interaction_state: str = NOT_AVAILABLE    # interaction type or summary
    reasoning_uncertainty: float = 1.0        # [0, 1]
    reasoning_confidence: float = 0.0         # [0, 1]
    is_degraded: bool = False
    reason_codes: Tuple[str, ...] = field(default_factory=tuple)

    def to_dict(self) -> dict:
        return {
            "situation_type": self.situation_type,
            "hazard_level": self.hazard_level,
            "dominant_hazard": self.dominant_hazard,
            "interaction_state": self.interaction_state,
            "reasoning_uncertainty": round(self.reasoning_uncertainty, 3),
            "reasoning_confidence": round(self.reasoning_confidence, 3),
            "is_degraded": self.is_degraded,
            "reason_codes": list(self.reason_codes),
        }


# ---------------------------------------------------------------------------
# Planning summary — compact planner output snapshot
# ---------------------------------------------------------------------------

@dataclass
class PlanningSummary:
    """
    Compact planning state snapshot.

    Captures existing planner output only — no new paths generated.
    """
    planning_mode: str = NOT_AVAILABLE      # PlannerStatus.value
    planning_status: str = NOT_AVAILABLE    # PlannerState.value
    active_candidate_id: str = NOT_AVAILABLE  # identifier if available
    path_risk_summary: str = NOT_AVAILABLE    # e.g. risk level summary
    replanning_active: bool = False
    replanning_reason: str = NOT_AVAILABLE
    planning_is_degraded: bool = False

    def to_dict(self) -> dict:
        return {
            "planning_mode": self.planning_mode,
            "planning_status": self.planning_status,
            "active_candidate_id": self.active_candidate_id,
            "path_risk_summary": self.path_risk_summary,
            "replanning_active": self.replanning_active,
            "replanning_reason": self.replanning_reason,
            "planning_is_degraded": self.planning_is_degraded,
        }


# ---------------------------------------------------------------------------
# Control summary — compact control/MPC state snapshot
# ---------------------------------------------------------------------------

@dataclass
class ControlSummary:
    """
    Compact control state snapshot.

    Captures existing control/MPC state — no new commands generated.
    """
    tracking_quality: str = NOT_AVAILABLE  # GOOD | DEGRADED | FAILED | UNKNOWN
    mpc_status: str = NOT_AVAILABLE        # MPCStatus.value
    control_status: str = NOT_AVAILABLE    # ControlCommandStatus.value
    steering_status: str = NOT_AVAILABLE   # SteeringStatus.value
    speed_status: str = NOT_AVAILABLE      # LongitudinalStatus.value
    acceleration_state: str = NOT_AVAILABLE  # descriptive summary
    control_is_degraded: bool = False

    def to_dict(self) -> dict:
        return {
            "tracking_quality": self.tracking_quality,
            "mpc_status": self.mpc_status,
            "control_status": self.control_status,
            "steering_status": self.steering_status,
            "speed_status": self.speed_status,
            "acceleration_state": self.acceleration_state,
            "control_is_degraded": self.control_is_degraded,
        }


# ---------------------------------------------------------------------------
# Safety summary — compact safety/failsafe state snapshot
# ---------------------------------------------------------------------------

@dataclass
class SafetySummary:
    """
    Compact safety state snapshot.

    Captures existing safety monitor, supervisor, and failsafe outputs only.
    No safety decisions are modified.
    """
    safety_state: str = NOT_AVAILABLE           # SafetyState.value
    emergency_state: str = NOT_AVAILABLE        # emergency detection state
    supervisor_authority: str = NOT_AVAILABLE   # ControlAuthority.value
    failsafe_state: str = NOT_AVAILABLE         # FailSafeState.value
    active_degraded_sensors: Tuple[str, ...] = field(default_factory=tuple)
    active_degraded_subsystems: Tuple[str, ...] = field(default_factory=tuple)
    safety_is_degraded: bool = False

    def to_dict(self) -> dict:
        return {
            "safety_state": self.safety_state,
            "emergency_state": self.emergency_state,
            "supervisor_authority": self.supervisor_authority,
            "failsafe_state": self.failsafe_state,
            "active_degraded_sensors": list(self.active_degraded_sensors),
            "active_degraded_subsystems": list(self.active_degraded_subsystems),
            "safety_is_degraded": self.safety_is_degraded,
        }


# ---------------------------------------------------------------------------
# Capture event evidence — per-event diagnostic context
# ---------------------------------------------------------------------------

@dataclass
class CaptureEventEvidence:
    """
    Compact evidence/reason context for one captured event.

    All fields preserve existing pipeline evidence.
    Uncertainty is never collapsed into certainty.
    """
    event_type: CaptureEventType = CaptureEventType.UNKNOWN_EVENT
    reason_codes: Tuple[str, ...] = field(default_factory=tuple)
    source_subsystem: str = NOT_AVAILABLE        # e.g. "safety_monitor"
    related_object_ids: Tuple[str, ...] = field(default_factory=tuple)
    related_hazard_ids: Tuple[str, ...] = field(default_factory=tuple)
    related_path_id: str = NOT_AVAILABLE
    safety_state: str = NOT_AVAILABLE
    confidence: float = 0.0          # [0, 1]
    uncertainty: float = 1.0         # [0, 1]
    is_stale: bool = False
    is_degraded: bool = False
    timestamp: float = 0.0
    frame_id: int = 0

    def to_dict(self) -> dict:
        return {
            "event_type": self.event_type.value,
            "reason_codes": list(self.reason_codes),
            "source_subsystem": self.source_subsystem,
            "related_object_ids": list(self.related_object_ids),
            "related_hazard_ids": list(self.related_hazard_ids),
            "related_path_id": self.related_path_id,
            "safety_state": self.safety_state,
            "confidence": round(self.confidence, 3),
            "uncertainty": round(self.uncertainty, 3),
            "is_stale": self.is_stale,
            "is_degraded": self.is_degraded,
            "timestamp": self.timestamp,
            "frame_id": self.frame_id,
        }


# ---------------------------------------------------------------------------
# Capture event — one notable event record
# ---------------------------------------------------------------------------

@dataclass
class CaptureEvent:
    """
    One notable driving event captured from existing pipeline state.

    An event has a deterministic ID derived from session + sequence.
    event_id = "<session_id>-E<sequence_id:06d>"

    This is NOT a validated outcome. Outcome evaluation → Phase 12.3.
    """
    event_id: str = NOT_AVAILABLE
    session_id: str = NOT_AVAILABLE
    sequence_id: int = 0
    event_type: CaptureEventType = CaptureEventType.UNKNOWN_EVENT
    evidence: CaptureEventEvidence = field(default_factory=CaptureEventEvidence)
    timestamp: float = 0.0
    frame_id: int = 0
    schema_version: str = EXPERIENCE_SCHEMA_VERSION
    data_validity: CaptureDataValidity = CaptureDataValidity.UNKNOWN

    def to_dict(self) -> dict:
        return {
            "event_id": self.event_id,
            "session_id": self.session_id,
            "sequence_id": self.sequence_id,
            "event_type": self.event_type.value,
            "evidence": self.evidence.to_dict(),
            "timestamp": self.timestamp,
            "frame_id": self.frame_id,
            "schema_version": self.schema_version,
            "data_validity": self.data_validity.value,
        }


# ---------------------------------------------------------------------------
# Experience observation — one complete captured driving observation
# ---------------------------------------------------------------------------

@dataclass
class ExperienceObservation:
    """
    One captured driving experience observation.

    This is a structured observation of what happened during one pipeline
    cycle. It is NOT a validated successful experience (→ Phase 12.3) and
    NOT labelled with success, reward, or optimal action.

    ID scheme: "<session_id>-O<sequence_id:06d>"

    Fields that cannot be determined from existing pipeline state are
    explicitly set to NOT_AVAILABLE, CaptureDataValidity.UNKNOWN, or None.
    They are never fabricated.
    """
    # --- Identity ---
    experience_id: str = NOT_AVAILABLE       # deterministic: session+sequence
    session_id: str = NOT_AVAILABLE
    sequence_id: int = 0
    timestamp: float = 0.0
    frame_id: int = 0
    schema_version: str = EXPERIENCE_SCHEMA_VERSION
    data_validity: CaptureDataValidity = CaptureDataValidity.UNKNOWN

    # --- Summaries from existing pipeline modules ---
    ego_context: EgoContextSummary = field(default_factory=EgoContextSummary)
    environment: EnvironmentSummary = field(default_factory=EnvironmentSummary)
    situation: SituationSummary = field(default_factory=SituationSummary)
    planning: PlanningSummary = field(default_factory=PlanningSummary)
    control: ControlSummary = field(default_factory=ControlSummary)
    safety: SafetySummary = field(default_factory=SafetySummary)

    # Explicitly NOT present (Phase 12.3+):
    #   success: bool           — outcome evaluation → Phase 12.3
    #   reward: float           — RL reward → Phase 12.3
    #   optimal_action: str     — policy update → Phase 12.5
    #   learned_policy: object  — adaptive update → Phase 12.5

    def to_dict(self) -> dict:
        return {
            "experience_id": self.experience_id,
            "session_id": self.session_id,
            "sequence_id": self.sequence_id,
            "timestamp": self.timestamp,
            "frame_id": self.frame_id,
            "schema_version": self.schema_version,
            "data_validity": self.data_validity.value,
            "ego_context": self.ego_context.to_dict(),
            "environment": self.environment.to_dict(),
            "situation": self.situation.to_dict(),
            "planning": self.planning.to_dict(),
            "control": self.control.to_dict(),
            "safety": self.safety.to_dict(),
        }


# ---------------------------------------------------------------------------
# Driving experience session
# ---------------------------------------------------------------------------

@dataclass
class DrivingExperienceSession:
    """
    Lightweight session container tracking one driving session.

    Bounded: does NOT grow unboundedly — see ExperienceCaptureConfig.
    The observation and event collections here are mutable internal state.
    Callers receive ExperienceCaptureSnapshot (immutable) for inspection.
    """
    session_id: str = NOT_AVAILABLE
    start_timestamp: float = 0.0
    last_timestamp: float = 0.0
    observation_count: int = 0
    event_count: int = 0
    status: SessionStatus = SessionStatus.UNKNOWN
    schema_version: str = EXPERIENCE_SCHEMA_VERSION
    # Bounded internal lists — not exposed directly
    _observations: List[ExperienceObservation] = field(
        default_factory=list, repr=False
    )
    _events: List[CaptureEvent] = field(
        default_factory=list, repr=False
    )

    def to_dict(self) -> dict:
        return {
            "session_id": self.session_id,
            "start_timestamp": self.start_timestamp,
            "last_timestamp": self.last_timestamp,
            "observation_count": self.observation_count,
            "event_count": self.event_count,
            "status": self.status.value,
            "schema_version": self.schema_version,
        }


# ---------------------------------------------------------------------------
# Experience capture snapshot — immutable external view
# ---------------------------------------------------------------------------

@dataclass
class ExperienceCaptureSnapshot:
    """
    Immutable snapshot of the experience capture layer state.

    Consumers receive this and must not mutate it.
    Internal collections are exposed as tuples for immutability.
    """
    schema_version: str = EXPERIENCE_SCHEMA_VERSION
    timestamp: float = field(default_factory=time.time)
    session_id: str = NOT_AVAILABLE
    session_status: SessionStatus = SessionStatus.UNKNOWN
    capture_status: ExperienceCaptureStatus = ExperienceCaptureStatus.UNKNOWN
    observation_count: int = 0
    event_count: int = 0
    # Bounded immutable tuples
    recent_observations: Tuple[ExperienceObservation, ...] = field(
        default_factory=tuple
    )
    recent_events: Tuple[CaptureEvent, ...] = field(default_factory=tuple)
    # Failure context (if capture encountered an error)
    capture_failed: bool = False
    failure_reason: str = NOT_AVAILABLE

    def to_dict(self) -> dict:
        return {
            "schema_version": self.schema_version,
            "timestamp": self.timestamp,
            "session_id": self.session_id,
            "session_status": self.session_status.value,
            "capture_status": self.capture_status.value,
            "observation_count": self.observation_count,
            "event_count": self.event_count,
            "recent_observation_count": len(self.recent_observations),
            "recent_event_count": len(self.recent_events),
            "capture_failed": self.capture_failed,
            "failure_reason": self.failure_reason,
        }


# ---------------------------------------------------------------------------
# Capture configuration
# ---------------------------------------------------------------------------

@dataclass
class ExperienceCaptureConfig:
    """
    Conservative, deterministic configuration for the capture layer.

    Defaults are chosen to keep memory usage small and predictable.
    All bounds must be positive integers; thresholds must be > 0.
    """
    observation_capture_enabled: bool = True
    event_capture_enabled: bool = True
    max_observations_per_session: int = 2000
    max_events_per_session: int = 500
    # Snapshot exposes only the most recent N observations/events
    recent_window_observations: int = 50
    recent_window_events: int = 50
    stale_threshold_s: float = 2.0           # seconds
    session_auto_reset: bool = False
    retention_policy: RetentionPolicy = RetentionPolicy.BOUNDED_FIFO

    @staticmethod
    def default() -> "ExperienceCaptureConfig":
        """Return a conservative default configuration."""
        return ExperienceCaptureConfig()

    def to_dict(self) -> dict:
        return {
            "observation_capture_enabled": self.observation_capture_enabled,
            "event_capture_enabled": self.event_capture_enabled,
            "max_observations_per_session": self.max_observations_per_session,
            "max_events_per_session": self.max_events_per_session,
            "recent_window_observations": self.recent_window_observations,
            "recent_window_events": self.recent_window_events,
            "stale_threshold_s": self.stale_threshold_s,
            "session_auto_reset": self.session_auto_reset,
            "retention_policy": self.retention_policy.value,
        }
