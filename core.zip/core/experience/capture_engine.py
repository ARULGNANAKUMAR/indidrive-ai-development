"""
IndiDrive AI — Phase 12.1 | Experience Capture Engine
======================================================
Core orchestrator: reads existing pipeline state and produces
compact ExperienceObservation and CaptureEvent records.

Architectural position:
    World Model → Reasoning → Planning → Control → Safety
                                                       ↓
                                          ExperienceCaptureEngine  ← Phase 12.1

The capture engine:
  * Observes existing pipeline state (does NOT modify it).
  * Produces compact, typed observations and events.
  * Is failure-isolated: any internal error leaves autonomous driving
    unaffected — the pipeline continues with no dependency on capture.
  * Generates deterministic IDs from session + sequence numbers.

This engine does NOT:
  - train any model or update weights.
  - calculate reward or evaluate success (→ Phase 12.3).
  - retrieve similar experiences (→ Phase 12.4).
  - modify planner, MPC, control, or safety decisions.
  - generate new paths, trajectories, or control commands.
  - perform new perception, prediction, or sensor fusion.
  - call LLMs, cloud APIs, or any external service.
"""
from __future__ import annotations

import math
import threading
import time
from typing import Optional, Tuple

from .capture_store import ExperienceCaptureStore
from .capture_validator import CaptureValidator
from .experience_types import (
    NOT_AVAILABLE,
    CaptureDataValidity,
    CaptureEvent,
    CaptureEventEvidence,
    CaptureEventType,
    ControlSummary,
    EgoContextSummary,
    EnvironmentSummary,
    ExperienceCaptureConfig,
    ExperienceCaptureSnapshot,
    ExperienceCaptureStatus,
    ExperienceObservation,
    PlanningSummary,
    SafetySummary,
    SituationSummary,
)

__all__ = ["ExperienceCaptureEngine"]


class ExperienceCaptureEngine:
    """
    Stateful capture engine for Phase 12.1.

    Usage
    -----
    config = ExperienceCaptureConfig.default()
    engine = ExperienceCaptureEngine(config)
    engine.start_session("session-001")

    # Each pipeline cycle:
    snapshot = engine.capture_cycle(
        world_model_snapshot=wm_snapshot,
        reasoning_snapshot=r_snapshot,
        planner_snapshot=p_snapshot,
        control_snapshot=ctrl_snapshot,
        safety_state=safety_state_obj,
        frame_id=cycle_counter,
        timestamp=cycle_time,
    )

    # At end of driving session:
    engine.finalize_session()

    Thread safety
    -------------
    capture_cycle() acquires an internal lock for ID generation.
    The underlying store is independently thread-safe.
    All other state mutations are on the engine's own lock.
    """

    def __init__(self, config: ExperienceCaptureConfig) -> None:
        if not isinstance(config, ExperienceCaptureConfig):
            raise TypeError(
                f"ExperienceCaptureEngine requires ExperienceCaptureConfig, "
                f"got {type(config)}"
            )
        self._cfg = config
        self._store = ExperienceCaptureStore(config)
        self._validator = CaptureValidator(config)
        self._lock = threading.Lock()

        # Deterministic sequence counters (monotonically increasing)
        self._obs_seq: int = 0
        self._event_seq: int = 0
        self._session_id: str = NOT_AVAILABLE

    # ------------------------------------------------------------------
    # Session lifecycle

    def start_session(
        self, session_id: str, timestamp: Optional[float] = None
    ) -> bool:
        """
        Start a new capture session.

        Parameters
        ----------
        session_id : str
            Unique session identifier (provided by caller).
        timestamp  : float, optional
            Session start time. Defaults to time.time().

        Returns
        -------
        bool — True on success.
        """
        with self._lock:
            self._obs_seq = 0
            self._event_seq = 0
            self._session_id = session_id
        return self._store.start_session(session_id, timestamp)

    def finalize_session(self, degraded: bool = False) -> bool:
        """Finalize the active session."""
        return self._store.finalize_session(degraded=degraded)

    def reset(self) -> None:
        """Reset engine and clear all session data."""
        with self._lock:
            self._obs_seq = 0
            self._event_seq = 0
            self._session_id = NOT_AVAILABLE
        self._store.clear_session()

    # ------------------------------------------------------------------
    # Main capture cycle

    def capture_cycle(
        self,
        *,
        world_model_snapshot=None,
        reasoning_snapshot=None,
        planner_snapshot=None,
        pipeline_snapshot=None,
        control_snapshot=None,
        safety_state=None,
        failsafe_snapshot=None,
        supervisor_snapshot=None,
        frame_id: int = 0,
        timestamp: Optional[float] = None,
    ) -> ExperienceCaptureSnapshot:
        """
        Capture one pipeline cycle observation and any notable events.

        All arguments are optional — the capture layer gracefully handles
        None inputs (produces degraded/unknown summaries).

        Parameters
        ----------
        world_model_snapshot : WorldModelSnapshot or None
        reasoning_snapshot   : ReasoningSnapshot or None
        planner_snapshot     : PlannerSnapshot or None (Phase 9.6 PlannerOutput)
        pipeline_snapshot    : PipelineSnapshot or None (Phase 10.5)
        control_snapshot     : VehicleControlCommand or None (Phase 10.4)
        safety_state         : SafetyMonitorState or None (Phase 11.1)
        failsafe_snapshot    : FailSafeSnapshot or None (Phase 11.4)
        supervisor_snapshot  : SafetySupervisorDecision or None (Phase 11.3)
        frame_id             : int — pipeline cycle counter.
        timestamp            : float or None — defaults to time.time().

        Returns
        -------
        ExperienceCaptureSnapshot — immutable view of current capture state.
                                    Never raises; failures are recorded.
        """
        ts = timestamp if timestamp is not None else time.time()

        try:
            # Allocate deterministic IDs under lock
            with self._lock:
                session_id = self._session_id
                obs_seq = self._obs_seq
                self._obs_seq += 1

            if session_id == NOT_AVAILABLE:
                # No active session — return idle snapshot without failing
                return self._store.get_session_snapshot()

            obs_id = _make_observation_id(session_id, obs_seq)

            # Build compact summaries from existing pipeline state
            ego_ctx = _extract_ego_context(pipeline_snapshot, world_model_snapshot)
            env_summary = _extract_environment(world_model_snapshot)
            sit_summary = _extract_situation(reasoning_snapshot)
            plan_summary = _extract_planning(planner_snapshot, pipeline_snapshot)
            ctrl_summary = _extract_control(
                control_snapshot, pipeline_snapshot, planner_snapshot
            )
            safety_summary = _extract_safety(
                safety_state, failsafe_snapshot, supervisor_snapshot
            )

            # Determine overall observation validity
            data_validity = _assess_observation_validity(
                ego_ctx, env_summary, sit_summary, plan_summary,
                ctrl_summary, safety_summary,
                ts, self._cfg.stale_threshold_s,
            )

            obs = ExperienceObservation(
                experience_id=obs_id,
                session_id=session_id,
                sequence_id=obs_seq,
                timestamp=ts,
                frame_id=frame_id,
                data_validity=data_validity,
                ego_context=ego_ctx,
                environment=env_summary,
                situation=sit_summary,
                planning=plan_summary,
                control=ctrl_summary,
                safety=safety_summary,
            )

            ok, reason = self._validator.validate_observation(obs)
            if not ok:
                # Capture failure is isolated — does not affect pipeline
                self._store._record_failure(f"observation validation: {reason}")
            else:
                self._store.append_observation(obs)

            # Classify and capture notable events from this observation
            self._capture_events_from_observation(
                obs, session_id, frame_id, ts
            )

        except Exception as exc:  # pylint: disable=broad-except
            # Any capture error is isolated — record and continue
            self._store._record_failure(f"capture_cycle exception: {exc}")

        return self._store.get_session_snapshot()

    def get_snapshot(self) -> ExperienceCaptureSnapshot:
        """Return current capture state snapshot without triggering a capture."""
        return self._store.get_session_snapshot()

    # ------------------------------------------------------------------
    # Event capture

    def _capture_events_from_observation(
        self,
        obs: ExperienceObservation,
        session_id: str,
        frame_id: int,
        timestamp: float,
    ) -> None:
        """
        Classify and append notable events derived from one observation.

        Only events supported by existing pipeline evidence are produced.
        Events are NOT fabricated from assumptions.
        """
        classified = _classify_events(obs)
        for event_type, evidence in classified:
            with self._lock:
                ev_seq = self._event_seq
                self._event_seq += 1
            ev_id = _make_event_id(session_id, ev_seq)
            event = CaptureEvent(
                event_id=ev_id,
                session_id=session_id,
                sequence_id=ev_seq,
                event_type=event_type,
                evidence=evidence,
                timestamp=timestamp,
                frame_id=frame_id,
                data_validity=obs.data_validity,
            )
            ok, reason = self._validator.validate_event(event)
            if ok:
                self._store.append_event(event)
            else:
                self._store._record_failure(f"event validation: {reason}")

    @property
    def capture_status(self) -> ExperienceCaptureStatus:
        return self._store.capture_status


# ---------------------------------------------------------------------------
# Deterministic ID builders
# ---------------------------------------------------------------------------

def _make_observation_id(session_id: str, seq: int) -> str:
    """observation ID: "<session_id>-O<seq:06d>"""
    return f"{session_id}-O{seq:06d}"


def _make_event_id(session_id: str, seq: int) -> str:
    """event ID: "<session_id>-E<seq:06d>"""
    return f"{session_id}-E{seq:06d}"


# ---------------------------------------------------------------------------
# Compact extractors — read from existing pipeline state
# ---------------------------------------------------------------------------

def _extract_ego_context(
    pipeline_snapshot, world_model_snapshot
) -> EgoContextSummary:
    """Extract compact ego state from Phase 10.5 pipeline or world model."""
    # Try Phase 10.5 pipeline snapshot first (has next_vehicle_state)
    if pipeline_snapshot is not None:
        vs = getattr(pipeline_snapshot, "next_vehicle_state", None)
        if vs is None:
            # PipelineSnapshot.stage results — try to get from input
            vs = getattr(pipeline_snapshot, "input_vehicle_state", None)
        if vs is not None:
            return _ego_from_vehicle_state(vs)

    # Fallback: world model has no direct ego state — return unknown summary
    return EgoContextSummary(vehicle_state_validity="UNKNOWN")


def _ego_from_vehicle_state(vs) -> EgoContextSummary:
    """Build EgoContextSummary from a VehicleState-like object."""
    def _safe(attr, default=None):
        v = getattr(vs, attr, default)
        if v is not None and isinstance(v, (int, float)) and not math.isfinite(v):
            return None
        return v

    return EgoContextSummary(
        position_x=_safe("x"),
        position_y=_safe("y"),
        position_z=_safe("z"),
        velocity_ms=_safe("velocity"),
        acceleration_ms2=_safe("acceleration"),
        yaw_rad=_safe("yaw"),
        yaw_rate_rads=_safe("yaw_rate"),
        vehicle_state_validity="VALID",
    )


def _extract_environment(world_model_snapshot) -> EnvironmentSummary:
    """Extract compact environment summary from WorldModelSnapshot."""
    if world_model_snapshot is None:
        return EnvironmentSummary(world_model_validity="UNKNOWN")

    try:
        wm = world_model_snapshot
        objects = getattr(wm, "objects", ())
        n_obj = len(objects) if objects else 0

        # Build bounded relevant object IDs (at most 10)
        rel_ids = tuple(
            str(o.primary_id() or getattr(o, "object_id", NOT_AVAILABLE) or NOT_AVAILABLE)
            for o in list(objects)[:10]
        )

        # Object type summary: "CAR:2,PEDESTRIAN:1"
        type_counts: dict = {}
        vru_present = False
        cattle_present = False
        for o in objects:
            ot = getattr(o, "object_type", NOT_AVAILABLE)
            ost = getattr(o, "object_subtype", NOT_AVAILABLE)
            if ot not in (NOT_AVAILABLE, None):
                type_counts[ot] = type_counts.get(ot, 0) + 1
            if ot in ("PEDESTRIAN", "CYCLIST", "MOTORCYCLE", "SCOOTER"):
                vru_present = True
            if ost in ("COW", "CATTLE", "BUFFALO") or ot == "CATTLE":
                cattle_present = True

        type_summary = ",".join(
            f"{k}:{v}" for k, v in sorted(type_counts.items())
        ) or NOT_AVAILABLE

        # Road info
        road = getattr(wm, "road", None)
        road_hazard = False
        anomaly_summary = NOT_AVAILABLE
        road_type = NOT_AVAILABLE
        marking_state = NOT_AVAILABLE
        intersection_state = NOT_AVAILABLE

        if road is not None:
            anomalies = getattr(road, "anomalies", [])
            if anomalies:
                road_hazard = True
                sev_map: dict = {}
                for a in anomalies:
                    at = getattr(a, "anomaly_type", NOT_AVAILABLE)
                    sev_map[at] = sev_map.get(at, 0) + 1
                anomaly_summary = ",".join(
                    f"{k}:{v}" for k, v in sorted(sev_map.items())
                ) or NOT_AVAILABLE
            lane = getattr(road, "lane_info", None)
            if lane is not None:
                marking_state = getattr(lane, "marking_state", NOT_AVAILABLE) or NOT_AVAILABLE
                intersection_state = getattr(lane, "intersection_state", NOT_AVAILABLE) or NOT_AVAILABLE

        # Indian context
        indian = getattr(wm, "indian_context", None)
        traffic_density = NOT_AVAILABLE
        traffic_mix = NOT_AVAILABLE
        if indian is not None:
            road_type = getattr(indian, "road_type", NOT_AVAILABLE) or NOT_AVAILABLE
            traffic_density = getattr(indian, "traffic_density", NOT_AVAILABLE) or NOT_AVAILABLE
            traffic_mix = getattr(indian, "traffic_mix", NOT_AVAILABLE) or NOT_AVAILABLE
            if not cattle_present:
                cattle_present = bool(getattr(indian, "cattle_present", False))
            if not vru_present:
                vru_present = bool(getattr(indian, "vulnerable_road_users", False))

        # World model status
        status = getattr(wm, "status", None)
        wm_validity = status.value if status is not None else NOT_AVAILABLE

        return EnvironmentSummary(
            nearby_object_count=n_obj,
            relevant_object_ids=rel_ids,
            object_type_summary=type_summary,
            vulnerable_road_user_present=vru_present,
            cattle_present=cattle_present,
            road_hazard_present=road_hazard,
            road_anomaly_summary=anomaly_summary,
            road_type=road_type,
            road_structure=NOT_AVAILABLE,  # structural layout not directly available
            lane_road_marking_state=marking_state,
            intersection_state=intersection_state,
            traffic_density=traffic_density,
            traffic_mix=traffic_mix,
            world_model_validity=wm_validity,
        )
    except Exception:  # pylint: disable=broad-except
        return EnvironmentSummary(world_model_validity="DEGRADED")


def _extract_situation(reasoning_snapshot) -> SituationSummary:
    """Extract compact situation summary from ReasoningSnapshot."""
    if reasoning_snapshot is None:
        return SituationSummary()

    try:
        rs = reasoning_snapshot
        sit = getattr(rs, "situation", None)
        sit_type = NOT_AVAILABLE
        if sit is not None:
            cat = getattr(sit, "situation_category", None)
            sit_type = cat.value if cat is not None else NOT_AVAILABLE

        hazards = getattr(rs, "hazards", None)
        hazard_level = NOT_AVAILABLE
        dominant_hazard = NOT_AVAILABLE
        if hazards is not None:
            risk = getattr(hazards, "highest_risk_level", None)
            if risk is None:
                # Try risk sub-structure
                risk_struct = getattr(rs, "risk", None)
                if risk_struct is not None:
                    rl = getattr(risk_struct, "overall_risk_level", None)
                    hazard_level = rl.value if rl is not None else NOT_AVAILABLE
            else:
                hazard_level = risk.value if risk is not None else NOT_AVAILABLE
            top = getattr(hazards, "top_hazards", ())
            if top:
                hcat = getattr(top[0], "hazard_category", None)
                dominant_hazard = hcat.value if hcat is not None else NOT_AVAILABLE

        interaction_state = NOT_AVAILABLE
        interactions = getattr(rs, "interactions", None)
        if interactions is not None:
            itype = getattr(interactions, "dominant_interaction_type", None)
            interaction_state = itype.value if itype is not None else NOT_AVAILABLE

        uncertainty = getattr(rs, "uncertainty_info", None)
        reasoning_uncertainty = 1.0
        reasoning_confidence = 0.0
        is_degraded = False
        if uncertainty is not None:
            ov = getattr(uncertainty, "overall_uncertainty", 1.0)
            reasoning_uncertainty = float(ov) if ov is not None else 1.0
        conf = getattr(rs, "reasoning_confidence", 0.0)
        reasoning_confidence = float(conf) if conf is not None else 0.0

        state = getattr(rs, "reasoning_state", None)
        if state is not None and hasattr(state, "value"):
            is_degraded = state.value in ("DEGRADED", "UNKNOWN")

        return SituationSummary(
            situation_type=sit_type,
            hazard_level=hazard_level,
            dominant_hazard=dominant_hazard,
            interaction_state=interaction_state,
            reasoning_uncertainty=min(1.0, max(0.0, reasoning_uncertainty)),
            reasoning_confidence=min(1.0, max(0.0, reasoning_confidence)),
            is_degraded=is_degraded,
        )
    except Exception:  # pylint: disable=broad-except
        return SituationSummary(is_degraded=True)


def _extract_planning(planner_snapshot, pipeline_snapshot) -> PlanningSummary:
    """Extract compact planning summary from planner/pipeline snapshot."""
    # Try Phase 9.6 planner output first
    if planner_snapshot is not None:
        try:
            ps = planner_snapshot
            status = getattr(ps, "status", None)
            planning_mode = status.value if status is not None else NOT_AVAILABLE

            state = getattr(ps, "state", None)
            planning_status = state.value if state is not None else NOT_AVAILABLE

            candidates = getattr(ps, "candidates", None)
            active_id = NOT_AVAILABLE
            if candidates is not None:
                active_id = getattr(candidates, "generation_status", NOT_AVAILABLE)

            replan = getattr(ps, "replan", None)
            replanning_active = False
            replanning_reason = NOT_AVAILABLE
            if replan is not None:
                replanning_active = bool(getattr(replan, "replan_required", False))
                reason = getattr(replan, "trigger_reason", None)
                replanning_reason = reason.value if reason is not None else NOT_AVAILABLE

            risk = getattr(ps, "risk", None)
            path_risk_summary = NOT_AVAILABLE
            if risk is not None:
                rl = getattr(risk, "overall_risk_level", None)
                path_risk_summary = rl.value if rl is not None else NOT_AVAILABLE

            is_degraded = planning_mode in ("DEGRADED", "BLOCKED", "INVALID_INPUT",
                                            "STALE_INPUT", "UNKNOWN")

            return PlanningSummary(
                planning_mode=planning_mode,
                planning_status=planning_status,
                active_candidate_id=active_id,
                path_risk_summary=path_risk_summary,
                replanning_active=replanning_active,
                replanning_reason=replanning_reason,
                planning_is_degraded=is_degraded,
            )
        except Exception:  # pylint: disable=broad-except
            pass

    # Fallback: try pipeline snapshot's planning stage
    if pipeline_snapshot is not None:
        try:
            stage = getattr(pipeline_snapshot, "planning_stage", None)
            if stage is not None:
                st = getattr(stage, "status", None)
                return PlanningSummary(
                    planning_mode=st.value if st is not None else NOT_AVAILABLE,
                    planning_is_degraded=True,
                )
        except Exception:  # pylint: disable=broad-except
            pass

    return PlanningSummary()


def _extract_control(
    control_snapshot, pipeline_snapshot, planner_snapshot
) -> ControlSummary:
    """Extract compact control summary from Phase 10.4/10.5 snapshots."""
    # Try Phase 10.4 VehicleControlCommand
    if control_snapshot is not None:
        try:
            cs = control_snapshot
            cmd_status = getattr(cs, "status", None)
            control_status = cmd_status.value if cmd_status is not None else NOT_AVAILABLE

            steer = getattr(cs, "steering_status", None)
            steering_status = steer.value if steer is not None else NOT_AVAILABLE

            lon = getattr(cs, "longitudinal_status", None)
            speed_status = lon.value if lon is not None else NOT_AVAILABLE

            acc = getattr(cs, "commanded_acceleration_ms2", None)
            accel_state = f"{acc:.2f} m/s2" if acc is not None and math.isfinite(acc) else NOT_AVAILABLE

            is_degraded = control_status in ("DEGRADED", "FAILED", "INVALID_INPUT",
                                             "NO_MPC_SOLUTION", "STALE_MPC")

            return ControlSummary(
                tracking_quality=NOT_AVAILABLE,
                mpc_status=NOT_AVAILABLE,
                control_status=control_status,
                steering_status=steering_status,
                speed_status=speed_status,
                acceleration_state=accel_state,
                control_is_degraded=is_degraded,
            )
        except Exception:  # pylint: disable=broad-except
            pass

    # Try pipeline snapshot for MPC/tracking stage info
    if pipeline_snapshot is not None:
        try:
            mpc_stage = getattr(pipeline_snapshot, "mpc_stage", None)
            tracking_stage = getattr(pipeline_snapshot, "tracking_stage", None)
            mpc_status = NOT_AVAILABLE
            tracking_quality = NOT_AVAILABLE
            if mpc_stage is not None:
                st = getattr(mpc_stage, "status", None)
                mpc_status = st.value if st is not None else NOT_AVAILABLE
            if tracking_stage is not None:
                st = getattr(tracking_stage, "status", None)
                tracking_quality = st.value if st is not None else NOT_AVAILABLE
            return ControlSummary(
                tracking_quality=tracking_quality,
                mpc_status=mpc_status,
            )
        except Exception:  # pylint: disable=broad-except
            pass

    return ControlSummary()


def _extract_safety(
    safety_state, failsafe_snapshot, supervisor_snapshot
) -> SafetySummary:
    """Extract compact safety summary from Phase 11.x snapshots."""
    sstate = NOT_AVAILABLE
    emergency_state = NOT_AVAILABLE
    authority = NOT_AVAILABLE
    failsafe = NOT_AVAILABLE
    degraded_sensors: Tuple[str, ...] = ()
    degraded_subsystems: Tuple[str, ...] = ()
    is_degraded = False

    # Phase 11.1 SafetyMonitorState
    if safety_state is not None:
        try:
            ss = getattr(safety_state, "safety_state", None)
            sstate = ss.value if ss is not None else NOT_AVAILABLE
            is_degraded = sstate in ("DEGRADED", "HIGH_ALERT", "CRITICAL", "UNKNOWN")
        except Exception:  # pylint: disable=broad-except
            sstate = "UNKNOWN"

    # Phase 11.4 FailSafeSnapshot
    if failsafe_snapshot is not None:
        try:
            dec = getattr(failsafe_snapshot, "decision", failsafe_snapshot)
            fs = getattr(dec, "failsafe_state", None)
            failsafe = fs.value if fs is not None else NOT_AVAILABLE

            sensors = getattr(failsafe_snapshot, "active_sensor_failures", ())
            degraded_sensors = tuple(
                str(getattr(s, "sensor_type", NOT_AVAILABLE))
                for s in list(sensors)[:10]
            )

            subsystems = getattr(failsafe_snapshot, "active_subsystem_failures", ())
            degraded_subsystems = tuple(
                str(getattr(s, "subsystem_type", NOT_AVAILABLE))
                for s in list(subsystems)[:10]
            )
        except Exception:  # pylint: disable=broad-except
            failsafe = "UNKNOWN"

    # Phase 11.3 SafetySupervisorDecision
    if supervisor_snapshot is not None:
        try:
            auth = getattr(supervisor_snapshot, "control_authority", None)
            authority = auth.value if auth is not None else NOT_AVAILABLE
        except Exception:  # pylint: disable=broad-except
            authority = "UNKNOWN"

    return SafetySummary(
        safety_state=sstate,
        emergency_state=emergency_state,
        supervisor_authority=authority,
        failsafe_state=failsafe,
        active_degraded_sensors=degraded_sensors,
        active_degraded_subsystems=degraded_subsystems,
        safety_is_degraded=is_degraded,
    )


# ---------------------------------------------------------------------------
# Data validity assessment
# ---------------------------------------------------------------------------

def _assess_observation_validity(
    ego: EgoContextSummary,
    env: EnvironmentSummary,
    sit: SituationSummary,
    plan: PlanningSummary,
    ctrl: ControlSummary,
    safety: SafetySummary,
    timestamp: float,
    stale_threshold_s: float,
) -> CaptureDataValidity:
    """Determine overall data validity from summary components."""
    if not math.isfinite(timestamp) or timestamp <= 0:
        return CaptureDataValidity.INVALID

    now = time.time()
    age = abs(now - timestamp)
    if age > stale_threshold_s:
        return CaptureDataValidity.STALE

    # Check for multiple degraded subsystems
    degraded_count = 0
    if ego.vehicle_state_validity in ("UNKNOWN", "DEGRADED", "INVALID"):
        degraded_count += 1
    if env.world_model_validity in ("DEGRADED", "EMPTY", "INVALID"):
        degraded_count += 1
    if sit.is_degraded:
        degraded_count += 1
    if plan.planning_is_degraded:
        degraded_count += 1
    if ctrl.control_is_degraded:
        degraded_count += 1
    if safety.safety_is_degraded:
        degraded_count += 1

    if degraded_count >= 4:
        return CaptureDataValidity.DEGRADED

    return CaptureDataValidity.VALID


# ---------------------------------------------------------------------------
# Event classification — derived from existing observation state
# ---------------------------------------------------------------------------

def _classify_events(
    obs: ExperienceObservation,
) -> list:
    """
    Classify notable events from one observation.

    Returns a list of (CaptureEventType, CaptureEventEvidence) tuples.
    Only events supported by existing pipeline evidence are produced.
    NORMAL_DRIVING is emitted when no notable events are detected.
    """
    events = []

    sit = obs.situation
    env = obs.environment
    plan = obs.planning
    ctrl = obs.control
    safety = obs.safety

    # Safety-level events (highest priority)
    if safety.safety_state in ("CRITICAL", "HIGH_ALERT"):
        events.append(_make_event(
            CaptureEventType.EMERGENCY_DETECTED,
            source="safety_monitor",
            safety_state=safety.safety_state,
            confidence=0.9,
            uncertainty=0.1,
            obs=obs,
        ))

    if safety.supervisor_authority in (
        "SAFETY_CONTROL_REQUIRED", "OVERRIDE_REQUIRED", "CONTROL_WITHHELD"
    ):
        events.append(_make_event(
            CaptureEventType.SAFETY_RESTRICTION,
            source="safety_supervisor",
            safety_state=safety.supervisor_authority,
            confidence=0.9,
            uncertainty=0.1,
            obs=obs,
        ))

    if safety.failsafe_state not in (NOT_AVAILABLE, "NORMAL_OPERATION", "UNKNOWN"):
        events.append(_make_event(
            CaptureEventType.FAIL_SAFE_EVENT,
            source="failsafe_engine",
            safety_state=safety.failsafe_state,
            confidence=0.85,
            uncertainty=0.15,
            obs=obs,
        ))

    if safety.active_degraded_sensors:
        events.append(_make_event(
            CaptureEventType.SENSOR_DEGRADATION,
            source="failsafe_engine",
            reason_codes=tuple(safety.active_degraded_sensors),
            confidence=0.85,
            uncertainty=0.15,
            obs=obs,
        ))

    # Hazard-level events
    if sit.hazard_level in ("HIGH", "CRITICAL"):
        events.append(_make_event(
            CaptureEventType.HAZARD_DETECTED,
            source="reasoning_engine",
            reason_codes=(sit.dominant_hazard,) if sit.dominant_hazard != NOT_AVAILABLE else (),
            safety_state=sit.hazard_level,
            confidence=sit.reasoning_confidence,
            uncertainty=sit.reasoning_uncertainty,
            obs=obs,
        ))

    if sit.situation_type == "INTERSECTION_COMPLEXITY":
        events.append(_make_event(
            CaptureEventType.INTERSECTION_EVENT,
            source="reasoning_engine",
            confidence=sit.reasoning_confidence,
            uncertainty=sit.reasoning_uncertainty,
            obs=obs,
        ))

    if sit.situation_type == "MERGE_COMPLEXITY":
        events.append(_make_event(
            CaptureEventType.HIGHWAY_MERGE_EVENT,
            source="reasoning_engine",
            confidence=sit.reasoning_confidence,
            uncertainty=sit.reasoning_uncertainty,
            obs=obs,
        ))

    if sit.situation_type == "NARROW_ROAD":
        events.append(_make_event(
            CaptureEventType.NARROW_ROAD_EVENT,
            source="reasoning_engine",
            confidence=sit.reasoning_confidence,
            uncertainty=sit.reasoning_uncertainty,
            obs=obs,
        ))

    if sit.situation_type == "UNSTRUCTURED_ROAD":
        events.append(_make_event(
            CaptureEventType.UNMARKED_ROAD_EVENT,
            source="reasoning_engine",
            confidence=sit.reasoning_confidence,
            uncertainty=sit.reasoning_uncertainty,
            obs=obs,
        ))

    if sit.situation_type in ("DENSE_TRAFFIC", "COMPOUND_HAZARD") or (
        env.traffic_density in ("HIGH", "VERY_HIGH")
    ):
        events.append(_make_event(
            CaptureEventType.MIXED_TRAFFIC_EVENT,
            source="world_model",
            confidence=sit.reasoning_confidence,
            uncertainty=sit.reasoning_uncertainty,
            obs=obs,
        ))

    # Indian-road scenario events
    if env.cattle_present:
        events.append(_make_event(
            CaptureEventType.CATTLE_EVENT,
            source="world_model",
            confidence=0.8,
            uncertainty=0.2,
            obs=obs,
        ))

    if env.vulnerable_road_user_present:
        events.append(_make_event(
            CaptureEventType.VULNERABLE_USER_EVENT,
            source="world_model",
            confidence=0.8,
            uncertainty=0.2,
            obs=obs,
        ))

    if env.road_hazard_present:
        events.append(_make_event(
            CaptureEventType.ROAD_HAZARD_EVENT,
            source="world_model",
            reason_codes=(env.road_anomaly_summary,) if env.road_anomaly_summary != NOT_AVAILABLE else (),
            confidence=0.8,
            uncertainty=0.2,
            obs=obs,
        ))

    # Planning events
    if plan.replanning_active:
        reason_codes = (
            (plan.replanning_reason,)
            if plan.replanning_reason != NOT_AVAILABLE
            else ()
        )
        events.append(_make_event(
            CaptureEventType.REPLANNING_TRIGGERED,
            source="planner_engine",
            reason_codes=reason_codes,
            confidence=0.85,
            uncertainty=0.15,
            obs=obs,
        ))

    if plan.planning_mode == "REPLAN_REQUIRED":
        events.append(_make_event(
            CaptureEventType.REPLANNING_REQUIRED,
            source="planner_engine",
            confidence=0.85,
            uncertainty=0.15,
            obs=obs,
        ))

    if plan.path_risk_summary in ("HIGH", "CRITICAL"):
        events.append(_make_event(
            CaptureEventType.PATH_RISK_INCREASED,
            source="path_risk_engine",
            safety_state=plan.path_risk_summary,
            confidence=0.8,
            uncertainty=0.2,
            obs=obs,
        ))

    if plan.planning_is_degraded:
        events.append(_make_event(
            CaptureEventType.PLANNING_DEGRADATION,
            source="planner_engine",
            confidence=0.75,
            uncertainty=0.25,
            obs=obs,
        ))

    # Control events
    if ctrl.control_is_degraded:
        events.append(_make_event(
            CaptureEventType.CONTROL_DEGRADATION,
            source="control_manager",
            confidence=0.8,
            uncertainty=0.2,
            obs=obs,
        ))

    if ctrl.mpc_status not in (NOT_AVAILABLE, "SOLVED", "FEASIBLE", "OK"):
        events.append(_make_event(
            CaptureEventType.MPC_DEGRADATION,
            source="mpc_controller",
            reason_codes=(ctrl.mpc_status,) if ctrl.mpc_status != NOT_AVAILABLE else (),
            confidence=0.8,
            uncertainty=0.2,
            obs=obs,
        ))

    if ctrl.tracking_quality not in (NOT_AVAILABLE, "PASSED", "GOOD"):
        events.append(_make_event(
            CaptureEventType.TRACKING_DEGRADATION,
            source="tracking_engine",
            reason_codes=(ctrl.tracking_quality,) if ctrl.tracking_quality != NOT_AVAILABLE else (),
            confidence=0.75,
            uncertainty=0.25,
            obs=obs,
        ))

    # Fallback: normal driving
    if not events:
        events.append(_make_event(
            CaptureEventType.NORMAL_DRIVING,
            source="capture_engine",
            confidence=0.9,
            uncertainty=0.1,
            obs=obs,
        ))

    return events


def _make_event(
    event_type: CaptureEventType,
    *,
    source: str = NOT_AVAILABLE,
    reason_codes: Tuple[str, ...] = (),
    safety_state: str = NOT_AVAILABLE,
    confidence: float = 0.5,
    uncertainty: float = 0.5,
    obs: ExperienceObservation,
) -> Tuple[CaptureEventType, CaptureEventEvidence]:
    """Create (event_type, evidence) pair from observation context."""
    related_ids = obs.environment.relevant_object_ids[:5]  # bounded
    evidence = CaptureEventEvidence(
        event_type=event_type,
        reason_codes=tuple(str(r) for r in reason_codes if r and r != NOT_AVAILABLE),
        source_subsystem=source,
        related_object_ids=related_ids,
        safety_state=safety_state,
        confidence=min(1.0, max(0.0, confidence)),
        uncertainty=min(1.0, max(0.0, uncertainty)),
        is_stale=(obs.data_validity == CaptureDataValidity.STALE),
        is_degraded=(obs.data_validity == CaptureDataValidity.DEGRADED),
        timestamp=obs.timestamp,
        frame_id=obs.frame_id,
    )
    return event_type, evidence
