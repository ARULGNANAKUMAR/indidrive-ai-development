"""
IndiDrive AI — Phase 12.3 | Outcome Evaluation Types
=====================================================
Strongly-typed containers for the Outcome Evaluation layer.

Phase 12.3 answers ONLY:
    «"Given the recorded situation, action, and observed outcome,
      what was the result?"»

Phase 12.3 does NOT:
    - control the vehicle                       → pipeline
    - change steering / throttle / braking      → pipeline
    - modify MPC / tracking / planning          → pipeline
    - modify safety supervisor decisions        → safety subsystems
    - generate paths or trajectories            → planning
    - retrieve historical experiences           → Phase 12.4
    - update adaptive knowledge / models        → Phase 12.5
    - improve future decisions                  → Phase 12.6
    - assign RL reward / value functions        → Phase 12.6
    - call external language-model APIs or cloud services

Design rules (consistent with all prior phases):
  * dataclasses — not raw dicts
  * explicit NOT_AVAILABLE / UNKNOWN — never fabricated
  * deterministic: same input → same output
  * immutable snapshots (OutcomeEvaluationSnapshot)
  * no hidden reasoning — every classification is traceable to evidence
  * confidence ≠ uncertainty — kept separate
  * offline-first

ID conventions (extend Phase 12.1 / 12.2):
    Record:      <session_id>-R<seq:06d>
    Evaluation:  <record_id>-EVAL
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Optional, Tuple

# Re-export cross-module sentinel
NOT_AVAILABLE = "NOT_AVAILABLE"

# Schema version for Phase 12.3 evaluation structures
EVALUATION_SCHEMA_VERSION = "12.3"


# ---------------------------------------------------------------------------
# Outcome classification
# ---------------------------------------------------------------------------

class OutcomeClass(str, Enum):
    """
    Deterministic classification of a recorded driving experience outcome.

    Priority hierarchy (high → low):
        INVALID          — record itself is structurally invalid
        UNSAFE_OUTCOME   — confirmed safety-critical event
        FAILURE          — clear inability to achieve the intended response
        PARTIAL_SUCCESS  — safety maintained; partly achieved
        SUCCESS          — positive evidence of intended response
        DEGRADED         — outcome observed under degraded conditions;
                           safety maintained; unclear success
        INCONCLUSIVE     — conflicting or insufficient evidence
        NO_OUTCOME       — action exists; no usable outcome data
        PENDING          — outcome window not yet closed

    NOT_EVALUATED is the initial state before evaluation runs.
    EVALUATION_ERROR is set when the evaluator encounters an internal error.
    """
    SUCCESS          = "SUCCESS"
    PARTIAL_SUCCESS  = "PARTIAL_SUCCESS"
    FAILURE          = "FAILURE"
    UNSAFE_OUTCOME   = "UNSAFE_OUTCOME"
    NO_OUTCOME       = "NO_OUTCOME"
    INCONCLUSIVE     = "INCONCLUSIVE"
    DEGRADED         = "DEGRADED"
    INVALID          = "INVALID"
    PENDING          = "PENDING"
    NOT_EVALUATED    = "NOT_EVALUATED"
    EVALUATION_ERROR = "EVALUATION_ERROR"


class EvaluationConfidence(str, Enum):
    """
    Deterministic confidence level for an OutcomeEvaluation.

    HIGH    — strong, unambiguous evidence supporting the classification.
    MEDIUM  — adequate evidence; some uncertainty present.
    LOW     — evidence is weak, conflicting, or partially missing.
    UNKNOWN — confidence cannot be determined (e.g. INVALID, PENDING).
    """
    HIGH    = "HIGH"
    MEDIUM  = "MEDIUM"
    LOW     = "LOW"
    UNKNOWN = "UNKNOWN"


class EvaluationStatus(str, Enum):
    """
    Operational status of one evaluation attempt.

    COMPLETE  — evaluation ran to completion; OutcomeClass is set.
    PENDING   — observation window has not yet closed.
    ERROR     — evaluation encountered an internal error; record unaffected.
    """
    COMPLETE = "COMPLETE"
    PENDING  = "PENDING"
    ERROR    = "ERROR"


# ---------------------------------------------------------------------------
# Evidence keys — machine-readable reason codes
# ---------------------------------------------------------------------------

class EvidenceKey(str, Enum):
    """
    Machine-readable evidence/reason codes.

    Every OutcomeEvaluation must reference at least one code.
    Codes describe WHAT was observed — not the final verdict.

    Safety
    ------
    COLLISION_DETECTED          — collision_detected = True in OutcomeRecord
    NO_COLLISION_OBSERVED       — collision_detected = False (or absent → no evidence)
    EMERGENCY_TRIGGERED         — emergency_active_after = True
    EMERGENCY_CLEARED           — emergency_cleared = True
    EMERGENCY_UNRESOLVED        — emergency active and not cleared
    FAIL_SAFE_ACTIVE            — failsafe_state is ACTIVE/ENGAGED
    SAFETY_VIOLATION_OBSERVED   — safety_state_after signals a violation
    SAFETY_MAINTAINED           — safety_state_after is SAFE / nominal

    Vehicle
    -------
    VEHICLE_CONTROLLABLE        — control_state_after nominal
    VEHICLE_STOPPED             — ego_speed_after ≈ 0
    CONTROL_DEGRADED            — control_state_after degraded
    CONTROL_FAILED              — applied action or control state shows failure

    Planning / Path
    ---------------
    GOAL_PROGRESS_OBSERVED      — hazard_level reduced and/or path completed
    REPLANNING_OCCURRED         — replanning_occurred = True
    PLANNER_FAILED              — planning_status_after shows failure
    PATH_COMPLETED              — path_state_after completed / nominal
    PATH_INVALID_AFTER          — path_state_after shows invalid/failed
    HAZARD_RESOLVED             — hazard cleared from cleared_event_types
    HAZARD_REMAINED             — hazard in unresolved_event_types
    HAZARD_LEVEL_REDUCED        — hazard_level_after < hazard_level_before
    HAZARD_LEVEL_UNCHANGED      — hazard level did not improve

    Tracking / Control
    ------------------
    TRACKING_MAINTAINED         — tracking_quality GOOD
    TRACKING_DEGRADED           — tracking_quality DEGRADED/FAILED

    Environment
    -----------
    CATTLE_EVENT_CLEARED        — CATTLE_EVENT in cleared_event_types
    CATTLE_EVENT_UNRESOLVED     — CATTLE_EVENT in unresolved_event_types
    VRU_EVENT_CLEARED           — VULNERABLE_USER_EVENT in cleared_event_types
    VRU_EVENT_UNRESOLVED        — VULNERABLE_USER_EVENT in unresolved_event_types
    OBSTACLE_AVOIDED            — hazard cleared, no collision
    OBSTACLE_COLLISION          — collision_detected = True during obstacle event
    ROAD_ANOMALY_PERSISTED      — road_hazard_present still True in after-state

    Data quality / temporal
    -----------------------
    OUTCOME_MISSING             — OutcomeRecord is None / MISSING
    OBSERVATION_INCOMPLETE      — observation_state is INCOMPLETE/PARTIAL
    OBSERVATION_WINDOW_OPEN     — outcome window not yet closed
    CONFLICTING_EVIDENCE        — contradictory subsystem states
    DEGRADED_OBSERVATION        — observation_state is DEGRADED
    DEGRADED_SYSTEM_STATE       — situation or outcome is_degraded = True
    INVALID_RECORD              — structural validation failure
    INVALID_IDS                 — ID consistency check failed
    INVALID_TIMESTAMPS          — timestamp check failed
    INVALID_SCHEMA              — schema_version mismatch
    NO_ACTION_RECORD            — action is None in ExperienceRecord
    NO_SITUATION_RECORD         — situation is None in ExperienceRecord
    ACTION_NOT_EXECUTED         — applied.is_available = False
    OBSERVATION_STALE           — situation or outcome data is stale
    """
    # Safety
    COLLISION_DETECTED          = "COLLISION_DETECTED"
    NO_COLLISION_OBSERVED       = "NO_COLLISION_OBSERVED"
    EMERGENCY_TRIGGERED         = "EMERGENCY_TRIGGERED"
    EMERGENCY_CLEARED           = "EMERGENCY_CLEARED"
    EMERGENCY_UNRESOLVED        = "EMERGENCY_UNRESOLVED"
    FAIL_SAFE_ACTIVE            = "FAIL_SAFE_ACTIVE"
    SAFETY_VIOLATION_OBSERVED   = "SAFETY_VIOLATION_OBSERVED"
    SAFETY_MAINTAINED           = "SAFETY_MAINTAINED"

    # Vehicle
    VEHICLE_CONTROLLABLE        = "VEHICLE_CONTROLLABLE"
    VEHICLE_STOPPED             = "VEHICLE_STOPPED"
    CONTROL_DEGRADED            = "CONTROL_DEGRADED"
    CONTROL_FAILED              = "CONTROL_FAILED"

    # Planning / Path
    GOAL_PROGRESS_OBSERVED      = "GOAL_PROGRESS_OBSERVED"
    REPLANNING_OCCURRED         = "REPLANNING_OCCURRED"
    PLANNER_FAILED              = "PLANNER_FAILED"
    PATH_COMPLETED              = "PATH_COMPLETED"
    PATH_INVALID_AFTER          = "PATH_INVALID_AFTER"
    HAZARD_RESOLVED             = "HAZARD_RESOLVED"
    HAZARD_REMAINED             = "HAZARD_REMAINED"
    HAZARD_LEVEL_REDUCED        = "HAZARD_LEVEL_REDUCED"
    HAZARD_LEVEL_UNCHANGED      = "HAZARD_LEVEL_UNCHANGED"

    # Tracking
    TRACKING_MAINTAINED         = "TRACKING_MAINTAINED"
    TRACKING_DEGRADED           = "TRACKING_DEGRADED"

    # Environment
    CATTLE_EVENT_CLEARED        = "CATTLE_EVENT_CLEARED"
    CATTLE_EVENT_UNRESOLVED     = "CATTLE_EVENT_UNRESOLVED"
    VRU_EVENT_CLEARED           = "VRU_EVENT_CLEARED"
    VRU_EVENT_UNRESOLVED        = "VRU_EVENT_UNRESOLVED"
    OBSTACLE_AVOIDED            = "OBSTACLE_AVOIDED"
    OBSTACLE_COLLISION          = "OBSTACLE_COLLISION"
    ROAD_ANOMALY_PERSISTED      = "ROAD_ANOMALY_PERSISTED"

    # Data quality / temporal
    OUTCOME_MISSING             = "OUTCOME_MISSING"
    OBSERVATION_INCOMPLETE      = "OBSERVATION_INCOMPLETE"
    OBSERVATION_WINDOW_OPEN     = "OBSERVATION_WINDOW_OPEN"
    CONFLICTING_EVIDENCE        = "CONFLICTING_EVIDENCE"
    DEGRADED_OBSERVATION        = "DEGRADED_OBSERVATION"
    DEGRADED_SYSTEM_STATE       = "DEGRADED_SYSTEM_STATE"
    INVALID_RECORD              = "INVALID_RECORD"
    INVALID_IDS                 = "INVALID_IDS"
    INVALID_TIMESTAMPS          = "INVALID_TIMESTAMPS"
    INVALID_SCHEMA              = "INVALID_SCHEMA"
    NO_ACTION_RECORD            = "NO_ACTION_RECORD"
    NO_SITUATION_RECORD         = "NO_SITUATION_RECORD"
    ACTION_NOT_EXECUTED         = "ACTION_NOT_EXECUTED"
    OBSERVATION_STALE           = "OBSERVATION_STALE"


# ---------------------------------------------------------------------------
# Outcome evaluation — the primary Phase 12.3 output
# ---------------------------------------------------------------------------

@dataclass
class OutcomeEvaluation:
    """
    Structured evaluation of one ExperienceRecord outcome.

    Every classification must be traceable to evidence stored here.
    No classification without evidence.
    No hidden reasoning.

    ID: <record_id>-EVAL

    Lifecycle:
        outcome_class = NOT_EVALUATED   → before evaluator runs
        evaluation_status = PENDING     → window still open
        evaluation_status = COMPLETE    → evaluation finished
        evaluation_status = ERROR       → evaluator internal error
    """
    # --- Identity ---
    evaluation_id: str = NOT_AVAILABLE           # <record_id>-EVAL
    experience_id: str = NOT_AVAILABLE           # ExperienceRecord.record_id
    session_id: str = NOT_AVAILABLE
    schema_version: str = EVALUATION_SCHEMA_VERSION
    evaluation_timestamp: float = 0.0           # when evaluation ran

    # --- Primary outputs ---
    evaluation_status: EvaluationStatus = EvaluationStatus.PENDING
    outcome_class: OutcomeClass = OutcomeClass.NOT_EVALUATED
    confidence: EvaluationConfidence = EvaluationConfidence.UNKNOWN

    # --- Evidence (machine-readable) ---
    # Ordered tuple of EvidenceKey.value strings — the basis for the verdict
    evidence: Tuple[str, ...] = field(default_factory=tuple)
    # Reason codes — subset of EvidenceKey values; the decisive factors
    reason_codes: Tuple[str, ...] = field(default_factory=tuple)

    # --- Uncertainty and degraded state ---
    uncertainty: float = 1.0       # [0.0, 1.0]; 1.0 = maximally uncertain
    is_degraded: bool = False       # True if evaluated under degraded conditions

    # --- Inconclusive / pending detail ---
    inconclusive_reason: str = NOT_AVAILABLE   # human-readable; for INCONCLUSIVE

    # --- Error context (only set when evaluation_status = ERROR) ---
    evaluation_error: str = NOT_AVAILABLE

    def to_dict(self) -> dict:
        return {
            "evaluation_id": self.evaluation_id,
            "experience_id": self.experience_id,
            "session_id": self.session_id,
            "schema_version": self.schema_version,
            "evaluation_timestamp": self.evaluation_timestamp,
            "evaluation_status": self.evaluation_status.value,
            "outcome_class": self.outcome_class.value,
            "confidence": self.confidence.value,
            "evidence": list(self.evidence),
            "reason_codes": list(self.reason_codes),
            "uncertainty": round(self.uncertainty, 3),
            "is_degraded": self.is_degraded,
            "inconclusive_reason": self.inconclusive_reason,
            "evaluation_error": self.evaluation_error,
        }


# ---------------------------------------------------------------------------
# Immutable snapshot — external-facing view
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class OutcomeEvaluationSnapshot:
    """
    Immutable snapshot of one OutcomeEvaluation.

    Consumers receive this; they must NOT mutate it.
    Prevents post-evaluation tampering with evidence or classification.
    """
    evaluation_id: str = NOT_AVAILABLE
    experience_id: str = NOT_AVAILABLE
    session_id: str = NOT_AVAILABLE
    schema_version: str = EVALUATION_SCHEMA_VERSION
    evaluation_timestamp: float = 0.0
    evaluation_status: EvaluationStatus = EvaluationStatus.PENDING
    outcome_class: OutcomeClass = OutcomeClass.NOT_EVALUATED
    confidence: EvaluationConfidence = EvaluationConfidence.UNKNOWN
    evidence: Tuple[str, ...] = field(default_factory=tuple)
    reason_codes: Tuple[str, ...] = field(default_factory=tuple)
    uncertainty: float = 1.0
    is_degraded: bool = False
    inconclusive_reason: str = NOT_AVAILABLE
    evaluation_error: str = NOT_AVAILABLE

    def to_dict(self) -> dict:
        return {
            "evaluation_id": self.evaluation_id,
            "experience_id": self.experience_id,
            "session_id": self.session_id,
            "schema_version": self.schema_version,
            "evaluation_timestamp": self.evaluation_timestamp,
            "evaluation_status": self.evaluation_status.value,
            "outcome_class": self.outcome_class.value,
            "confidence": self.confidence.value,
            "evidence": list(self.evidence),
            "reason_codes": list(self.reason_codes),
            "uncertainty": round(self.uncertainty, 3),
            "is_degraded": self.is_degraded,
            "inconclusive_reason": self.inconclusive_reason,
            "evaluation_error": self.evaluation_error,
        }


# ---------------------------------------------------------------------------
# Evaluator configuration
# ---------------------------------------------------------------------------

@dataclass
class OutcomeEvaluatorConfig:
    """
    Conservative, deterministic configuration for the OutcomeEvaluator.

    All thresholds must be explicitly set; no hidden magic numbers.
    """
    # Allow evaluation before the outcome window is fully closed?
    # When False (default), PENDING is returned for incomplete windows.
    allow_early_evaluation: bool = False

    # Minimum ego speed (m/s) to consider vehicle "stopped"
    stopped_speed_threshold_ms: float = 0.5

    # Hazard level values considered "safe" (post-action)
    safe_hazard_levels: Tuple[str, ...] = field(
        default_factory=lambda: ("NONE", "LOW", "CLEAR", "SAFE", "NOT_AVAILABLE")
    )

    # Control state strings that indicate nominal operation
    nominal_control_states: Tuple[str, ...] = field(
        default_factory=lambda: ("ACTIVE", "OK", "NOMINAL", "GOOD", "SUCCESS", "RUNNING")
    )

    # Safety state strings that indicate a safe outcome
    safe_safety_states: Tuple[str, ...] = field(
        default_factory=lambda: ("SAFE", "NOMINAL", "OK", "NORMAL", "ACTIVE")
    )

    # Tracking quality strings indicating degraded tracking
    degraded_tracking_states: Tuple[str, ...] = field(
        default_factory=lambda: ("DEGRADED", "FAILED", "POOR", "LOST")
    )

    # Planning status strings indicating planner failure
    failed_planning_statuses: Tuple[str, ...] = field(
        default_factory=lambda: ("FAILED", "ERROR", "INVALID", "UNAVAILABLE")
    )

    # Fail-safe states that confirm fail-safe was active
    active_failsafe_states: Tuple[str, ...] = field(
        default_factory=lambda: ("ACTIVE", "ENGAGED", "TRIGGERED", "EMERGENCY_BRAKE",
                                 "COAST_TO_STOP")
    )

    @staticmethod
    def default() -> "OutcomeEvaluatorConfig":
        return OutcomeEvaluatorConfig()

    def to_dict(self) -> dict:
        return {
            "allow_early_evaluation": self.allow_early_evaluation,
            "stopped_speed_threshold_ms": self.stopped_speed_threshold_ms,
            "safe_hazard_levels": list(self.safe_hazard_levels),
            "nominal_control_states": list(self.nominal_control_states),
            "safe_safety_states": list(self.safe_safety_states),
            "degraded_tracking_states": list(self.degraded_tracking_states),
            "failed_planning_statuses": list(self.failed_planning_statuses),
            "active_failsafe_states": list(self.active_failsafe_states),
        }


__all__ = [
    "NOT_AVAILABLE",
    "EVALUATION_SCHEMA_VERSION",
    "OutcomeClass",
    "EvaluationConfidence",
    "EvaluationStatus",
    "EvidenceKey",
    "OutcomeEvaluation",
    "OutcomeEvaluationSnapshot",
    "OutcomeEvaluatorConfig",
]
