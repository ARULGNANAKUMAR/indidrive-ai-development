"""
IndiDrive AI — Phase 12.3 | Outcome Evaluation Rules
=====================================================
Explicit, inspectable evaluation rule definitions.

All classification logic is expressed through named rule functions here.
No hidden heuristics, no scattered conditions, no magic numbers.

Priority hierarchy (applied in order by OutcomeEvaluator):

    1. INVALID          — structural / schema failure in input records
    2. UNSAFE_OUTCOME   — confirmed collision / safety violation
    3. NO_OUTCOME       — action present but no usable outcome data
    4. PENDING          — outcome window not closed yet
    5. FAILURE          — clear inability to achieve intended response
    6. PARTIAL_SUCCESS  — safety maintained; partial achievement
    7. SUCCESS          — positive evidence of intended response
    8. DEGRADED         — outcome under degraded conditions; ambiguous
    9. INCONCLUSIVE     — conflicting or insufficient evidence

Each rule returns (matched: bool, evidence: list[str], reason_codes: list[str]).
Rules only inspect data — they do NOT modify any pipeline state.
"""
from __future__ import annotations

from typing import List, Optional, Tuple

from core.experience.record.record_types import (
    NOT_AVAILABLE,
    ActionRecord,
    ActionType,
    ExperienceRecord,
    OutcomeObservationState,
    OutcomeRecord,
    RecordCompleteness,
    SituationRecord,
)

from .evaluation_types import EvidenceKey, OutcomeEvaluatorConfig

_EV = EvidenceKey  # alias

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _ev(*keys: EvidenceKey) -> List[str]:
    return [k.value for k in keys]


def _upper(v: Optional[str]) -> str:
    if v is None or v == NOT_AVAILABLE:
        return ""
    return str(v).upper()


def _contains_upper(v: Optional[str], fragment: str) -> bool:
    return fragment.upper() in _upper(v)


# ---------------------------------------------------------------------------
# Structural / ID validity rules
# ---------------------------------------------------------------------------

def rule_invalid_record(
    record: ExperienceRecord,
    cfg: OutcomeEvaluatorConfig,
) -> Tuple[bool, List[str], List[str]]:
    """
    Return INVALID when the ExperienceRecord is structurally unsound.

    Checks:
      - record is not None
      - record_id and session_id are present
      - schema_version matches expected "12.2"
      - completeness is not INVALID
      - ID cross-consistency between situation, action, outcome (if present)
      - timestamps are non-negative
    """
    ev: List[str] = []
    rc: List[str] = []

    if record is None:
        ev.append(_EV.INVALID_RECORD.value)
        rc.append(_EV.INVALID_RECORD.value)
        return True, ev, rc

    if not record.record_id or record.record_id == NOT_AVAILABLE:
        ev.append(_EV.INVALID_IDS.value)
        rc.append(_EV.INVALID_IDS.value)
        return True, ev, rc

    if not record.session_id or record.session_id == NOT_AVAILABLE:
        ev.append(_EV.INVALID_IDS.value)
        rc.append(_EV.INVALID_IDS.value)
        return True, ev, rc

    # Schema version tolerance: accept 12.2 (Phase 12.2 records)
    if record.schema_version not in ("12.2",):
        ev.append(_EV.INVALID_SCHEMA.value)
        rc.append(_EV.INVALID_SCHEMA.value)
        return True, ev, rc

    if record.completeness == RecordCompleteness.INVALID:
        ev.append(_EV.INVALID_RECORD.value)
        rc.append(_EV.INVALID_RECORD.value)
        return True, ev, rc

    if record.created_timestamp < 0:
        ev.append(_EV.INVALID_TIMESTAMPS.value)
        rc.append(_EV.INVALID_TIMESTAMPS.value)
        return True, ev, rc

    # Cross-ID checks for sub-records
    sit = record.situation
    if sit is not None:
        if sit.record_id != record.record_id:
            ev.append(_EV.INVALID_IDS.value)
            rc.append(_EV.INVALID_IDS.value)
            return True, ev, rc
        if sit.timestamp < 0:
            ev.append(_EV.INVALID_TIMESTAMPS.value)
            rc.append(_EV.INVALID_TIMESTAMPS.value)
            return True, ev, rc

    act = record.action
    if act is not None:
        if act.record_id != record.record_id:
            ev.append(_EV.INVALID_IDS.value)
            rc.append(_EV.INVALID_IDS.value)
            return True, ev, rc
        if act.timestamp < 0:
            ev.append(_EV.INVALID_TIMESTAMPS.value)
            rc.append(_EV.INVALID_TIMESTAMPS.value)
            return True, ev, rc

    out = record.outcome
    if out is not None:
        if out.record_id != record.record_id:
            ev.append(_EV.INVALID_IDS.value)
            rc.append(_EV.INVALID_IDS.value)
            return True, ev, rc
        if out.action_timestamp < 0 or out.outcome_start_timestamp < 0:
            ev.append(_EV.INVALID_TIMESTAMPS.value)
            rc.append(_EV.INVALID_TIMESTAMPS.value)
            return True, ev, rc
        if out.outcome_end_timestamp < out.outcome_start_timestamp:
            ev.append(_EV.INVALID_TIMESTAMPS.value)
            rc.append(_EV.INVALID_TIMESTAMPS.value)
            return True, ev, rc

    return False, [], []


# ---------------------------------------------------------------------------
# Safety / unsafe-outcome rules
# ---------------------------------------------------------------------------

def rule_unsafe_outcome(
    record: ExperienceRecord,
    cfg: OutcomeEvaluatorConfig,
) -> Tuple[bool, List[str], List[str]]:
    """
    Return UNSAFE_OUTCOME when confirmed safety-critical evidence exists.

    Priority evidence (any one is sufficient):
      - collision_detected = True
      - safety_state_after contains VIOLATION / UNSAFE / CRITICAL
      - emergency_active_after = True AND emergency_cleared = False
        (i.e. emergency unresolved at window end)

    Safety authority is preserved: if the existing safety subsystem
    recorded a confirmed unsafe event, this classification is returned
    regardless of other positive evidence.
    """
    out = record.outcome
    if out is None:
        return False, [], []

    ev: List[str] = []
    rc: List[str] = []

    # Collision
    if out.collision_detected is True:
        ev.append(_EV.COLLISION_DETECTED.value)
        rc.append(_EV.COLLISION_DETECTED.value)
        # Also note any obstacle collision context
        if record.situation and record.situation.road_hazard_present:
            ev.append(_EV.OBSTACLE_COLLISION.value)
        return True, ev, rc

    # Safety state violation
    saf = _upper(out.safety_state_after)
    if saf and any(kw in saf for kw in ("VIOLATION", "UNSAFE", "CRITICAL", "DANGER")):
        ev.append(_EV.SAFETY_VIOLATION_OBSERVED.value)
        rc.append(_EV.SAFETY_VIOLATION_OBSERVED.value)
        return True, ev, rc

    # Emergency unresolved at window end
    if (out.emergency_active_after is True
            and out.emergency_cleared is not True):
        ev.append(_EV.EMERGENCY_TRIGGERED.value)
        ev.append(_EV.EMERGENCY_UNRESOLVED.value)
        rc.append(_EV.EMERGENCY_UNRESOLVED.value)
        return True, ev, rc

    return False, [], []


# ---------------------------------------------------------------------------
# No-outcome rule
# ---------------------------------------------------------------------------

def rule_no_outcome(
    record: ExperienceRecord,
    cfg: OutcomeEvaluatorConfig,
) -> Tuple[bool, List[str], List[str]]:
    """
    Return NO_OUTCOME when an action exists but no usable outcome is recorded.

    Conditions:
      - outcome is None
      - OR observation_state is MISSING
    """
    out = record.outcome
    act = record.action

    if act is None:
        # No action either — we can't classify as NO_OUTCOME
        return False, [], []

    if out is None:
        ev = [_EV.OUTCOME_MISSING.value]
        rc = [_EV.OUTCOME_MISSING.value]
        return True, ev, rc

    if out.observation_state == OutcomeObservationState.MISSING:
        ev = [_EV.OUTCOME_MISSING.value]
        rc = [_EV.OUTCOME_MISSING.value]
        return True, ev, rc

    return False, [], []


# ---------------------------------------------------------------------------
# Pending rule (outcome window not closed)
# ---------------------------------------------------------------------------

def rule_pending(
    record: ExperienceRecord,
    cfg: OutcomeEvaluatorConfig,
) -> Tuple[bool, List[str], List[str]]:
    """
    Return PENDING when the outcome observation window has not yet closed.

    Conditions:
      - record.completeness in (CAPTURING, ACTION_ATTACHED, OUTCOME_OBSERVING)
      - AND cfg.allow_early_evaluation is False

    When allow_early_evaluation is True, evaluation proceeds on partial data.
    """
    if cfg.allow_early_evaluation:
        return False, [], []

    open_states = (
        RecordCompleteness.CAPTURING,
        RecordCompleteness.ACTION_ATTACHED,
        RecordCompleteness.OUTCOME_OBSERVING,
    )
    if record.completeness in open_states:
        ev = [_EV.OBSERVATION_WINDOW_OPEN.value]
        rc = [_EV.OBSERVATION_WINDOW_OPEN.value]
        return True, ev, rc

    return False, [], []


# ---------------------------------------------------------------------------
# Failure rule
# ---------------------------------------------------------------------------

def rule_failure(
    record: ExperienceRecord,
    cfg: OutcomeEvaluatorConfig,
) -> Tuple[bool, List[str], List[str]]:
    """
    Return FAILURE when clear evidence shows the intended response could not
    be achieved.

    Decisive evidence (any one triggers FAILURE):
      - applied.is_available = False (action not executed)
      - control_state_after contains FAILED / ERROR
      - planning_status_after is in failed states AND hazard remained
      - path_state_after is INVALID / FAILED
      - unresolved_event_types non-empty AND safety not maintained

    Missing data alone does NOT trigger FAILURE — use NO_OUTCOME / INCONCLUSIVE.
    """
    out = record.outcome
    act = record.action
    if out is None or act is None:
        return False, [], []

    ev: List[str] = []
    rc: List[str] = []

    # Action not executed
    if act.applied is not None and act.applied.is_available is False:
        ev.append(_EV.ACTION_NOT_EXECUTED.value)
        rc.append(_EV.ACTION_NOT_EXECUTED.value)

    # Control failed
    ctrl = _upper(out.control_state_after)
    if ctrl and any(kw in ctrl for kw in ("FAILED", "ERROR", "FAULT")):
        ev.append(_EV.CONTROL_FAILED.value)
        rc.append(_EV.CONTROL_FAILED.value)

    # Planning failed AND hazard remained
    plan = _upper(out.planning_status_after)
    plan_failed = plan and any(
        _upper(s) in plan for s in cfg.failed_planning_statuses
    )
    hazard_remained = bool(out.unresolved_event_types)

    if plan_failed:
        ev.append(_EV.PLANNER_FAILED.value)
        if hazard_remained:
            ev.append(_EV.HAZARD_REMAINED.value)
            rc.append(_EV.PLANNER_FAILED.value)

    # Path invalid
    path = _upper(out.path_state_after)
    if path and any(kw in path for kw in ("INVALID", "FAILED", "UNAVAILABLE")):
        ev.append(_EV.PATH_INVALID_AFTER.value)
        rc.append(_EV.PATH_INVALID_AFTER.value)

    if rc:
        return True, ev, rc

    return False, [], []


# ---------------------------------------------------------------------------
# Partial success rule
# ---------------------------------------------------------------------------

def rule_partial_success(
    record: ExperienceRecord,
    cfg: OutcomeEvaluatorConfig,
) -> Tuple[bool, List[str], List[str]]:
    """
    Return PARTIAL_SUCCESS when safety was maintained but the action was only
    partly successful.

    Conditions (require safety maintained AND at least one partial indicator):
      - replanning_occurred = True (action adapted; original path not followed)
      - hazard_level_after exists but is not CLEAR/NONE (improved but not gone)
      - emergency_cleared = True (emergency resolved, but was triggered)
      - vehicle_stopped + hazard_remained (safe stop; hazard still present)
      - observation_state is PARTIAL/INCOMPLETE (limited evidence, but safe)
      - action is EMERGENCY_RESPONSE_STATE AND vehicle_stopped

    Safety maintained = no collision AND no safety violation signal.
    """
    out = record.outcome
    sit = record.situation
    act = record.action
    if out is None or sit is None:
        return False, [], []

    ev: List[str] = []
    rc: List[str] = []

    # Check safety maintained (prerequisite)
    if out.collision_detected is True:
        return False, [], []
    saf = _upper(out.safety_state_after)
    if saf and any(kw in saf for kw in ("VIOLATION", "UNSAFE", "CRITICAL")):
        return False, [], []

    # Safety maintained signal
    if not saf or saf in [s.upper() for s in cfg.safe_safety_states]:
        ev.append(_EV.SAFETY_MAINTAINED.value)

    partial_signals: List[str] = []

    # Emergency was triggered but cleared
    if out.emergency_cleared is True:
        ev.append(_EV.EMERGENCY_CLEARED.value)
        partial_signals.append(_EV.EMERGENCY_CLEARED.value)

    # Replanning occurred (adapted but not original plan)
    if out.replanning_occurred is True:
        ev.append(_EV.REPLANNING_OCCURRED.value)
        partial_signals.append(_EV.REPLANNING_OCCURRED.value)

    # Hazard level reduced but not gone
    if sit is not None and out.hazard_level_after not in (None, NOT_AVAILABLE):
        before = _upper(sit.hazard_level)
        after = _upper(out.hazard_level_after)
        safe_afters = [s.upper() for s in cfg.safe_hazard_levels]
        if before and after and before != after and after not in safe_afters:
            ev.append(_EV.HAZARD_LEVEL_REDUCED.value)
            partial_signals.append(_EV.HAZARD_LEVEL_REDUCED.value)

    # Vehicle stopped safely with hazard still present
    speed = out.ego_speed_after_ms
    is_stopped = speed is not None and speed <= cfg.stopped_speed_threshold_ms
    hazard_remained = bool(out.unresolved_event_types)
    if is_stopped and hazard_remained:
        ev.append(_EV.VEHICLE_STOPPED.value)
        ev.append(_EV.HAZARD_REMAINED.value)
        partial_signals.append(_EV.VEHICLE_STOPPED.value)

    # Observation incomplete but no failure signals
    if out.observation_state in (
        OutcomeObservationState.PARTIAL,
        OutcomeObservationState.INCOMPLETE,
    ):
        ev.append(_EV.OBSERVATION_INCOMPLETE.value)
        partial_signals.append(_EV.OBSERVATION_INCOMPLETE.value)

    # Emergency response + vehicle stopped = partial (safe stop)
    if (act is not None
            and act.requested is not None
            and act.requested.action_type == ActionType.EMERGENCY_RESPONSE_STATE
            and is_stopped):
        ev.append(_EV.VEHICLE_STOPPED.value)
        partial_signals.append(_EV.VEHICLE_STOPPED.value)

    if partial_signals:
        rc.extend(partial_signals[:3])  # bounded: top 3 signals
        return True, ev, rc

    return False, [], []


# ---------------------------------------------------------------------------
# Success rule
# ---------------------------------------------------------------------------

def rule_success(
    record: ExperienceRecord,
    cfg: OutcomeEvaluatorConfig,
) -> Tuple[bool, List[str], List[str]]:
    """
    Return SUCCESS when sufficient positive evidence exists.

    Required (all must hold):
      - no collision
      - no safety violation
      - at least one positive progress indicator

    Positive progress indicators:
      - hazard cleared (cleared_event_types non-empty)
      - hazard_level_after is NONE / LOW / CLEAR / SAFE
      - safety_state_after is nominal
      - vehicle controllable (control_state_after nominal)
      - path nominal / completed (path_state_after not failed)
      - no unresolved events

    Success is CONTEXT-SENSITIVE:
      - STOP with cattle cleared → SUCCESS
      - STOP without any hazard → SUCCESS (normal stop)
      - SLOW_DOWN with hazard resolved → SUCCESS

    «No collision = success» is NOT applied. Positive evidence is required.
    """
    out = record.outcome
    sit = record.situation
    act = record.action
    if out is None:
        return False, [], []

    # Prerequisite: situation must be present for context-sensitive success
    if sit is None:
        return False, [], []

    # Prerequisite: observation state must be usable — not UNKNOWN/MISSING
    if out.observation_state in (
        OutcomeObservationState.UNKNOWN,
        OutcomeObservationState.MISSING,
    ):
        return False, [], []

    ev: List[str] = []
    rc: List[str] = []

    # Prerequisite: no collision
    if out.collision_detected is True:
        return False, [], []

    # Prerequisite: no safety violation
    saf = _upper(out.safety_state_after)
    if saf and any(kw in saf for kw in ("VIOLATION", "UNSAFE", "CRITICAL", "DANGER")):
        return False, [], []

    ev.append(_EV.NO_COLLISION_OBSERVED.value)

    # Positive signals
    positive_count = 0

    # Safety maintained
    if saf and any(saf == s.upper() for s in cfg.safe_safety_states):
        ev.append(_EV.SAFETY_MAINTAINED.value)
        positive_count += 1

    # Hazard cleared
    if out.cleared_event_types:
        ev.append(_EV.HAZARD_RESOLVED.value)
        rc.append(_EV.HAZARD_RESOLVED.value)
        positive_count += 1

        # Specific hazard types
        if "CATTLE_EVENT" in out.cleared_event_types:
            ev.append(_EV.CATTLE_EVENT_CLEARED.value)
        if "VULNERABLE_USER_EVENT" in out.cleared_event_types:
            ev.append(_EV.VRU_EVENT_CLEARED.value)
        if any("HAZARD" in e or "OBSTACLE" in e for e in out.cleared_event_types):
            ev.append(_EV.OBSTACLE_AVOIDED.value)

    # Hazard level safe after
    after_hazard = _upper(out.hazard_level_after)
    safe_afters = [s.upper() for s in cfg.safe_hazard_levels]
    if after_hazard and after_hazard in safe_afters:
        ev.append(_EV.GOAL_PROGRESS_OBSERVED.value)
        rc.append(_EV.GOAL_PROGRESS_OBSERVED.value)
        positive_count += 1

    # Vehicle controllable
    ctrl = _upper(out.control_state_after)
    if ctrl and any(n.upper() in ctrl for n in cfg.nominal_control_states):
        ev.append(_EV.VEHICLE_CONTROLLABLE.value)
        positive_count += 1

    # Path nominal
    path = _upper(out.path_state_after)
    if path and not any(kw in path for kw in ("FAILED", "INVALID", "UNAVAILABLE")):
        ev.append(_EV.PATH_COMPLETED.value)
        positive_count += 1

    # No unresolved events
    if not out.unresolved_event_types:
        positive_count += 1

    # Observation complete
    if out.observation_state == OutcomeObservationState.OBSERVED:
        positive_count += 1

    if positive_count >= 2:
        if not rc:
            rc.append(_EV.NO_COLLISION_OBSERVED.value)
        return True, ev, rc

    return False, [], []


# ---------------------------------------------------------------------------
# Degraded rule
# ---------------------------------------------------------------------------

def rule_degraded(
    record: ExperienceRecord,
    cfg: OutcomeEvaluatorConfig,
) -> Tuple[bool, List[str], List[str]]:
    """
    Return DEGRADED when the outcome was observed under significantly degraded
    conditions and cannot be clearly classified as success or failure.

    Conditions:
      - situation.is_degraded or outcome.is_degraded
      - observation_state is DEGRADED
      - failsafe active in situation safety context
      - tracking heavily degraded
    """
    out = record.outcome
    sit = record.situation
    if out is None:
        return False, [], []

    ev: List[str] = []
    rc: List[str] = []

    # Observation degraded
    if out.observation_state == OutcomeObservationState.DEGRADED:
        ev.append(_EV.DEGRADED_OBSERVATION.value)
        rc.append(_EV.DEGRADED_OBSERVATION.value)

    # Situation or outcome data degraded
    if (sit is not None and sit.is_degraded) or out.is_degraded:
        ev.append(_EV.DEGRADED_SYSTEM_STATE.value)
        if _EV.DEGRADED_SYSTEM_STATE.value not in rc:
            rc.append(_EV.DEGRADED_SYSTEM_STATE.value)

    # Fail-safe active in situation
    if sit is not None:
        fs = _upper(sit.failsafe_state)
        if fs and any(n.upper() in fs for n in cfg.active_failsafe_states):
            ev.append(_EV.FAIL_SAFE_ACTIVE.value)
            if _EV.FAIL_SAFE_ACTIVE.value not in rc:
                rc.append(_EV.FAIL_SAFE_ACTIVE.value)

    # Tracking degraded
    ctrl_after = _upper(out.control_state_after)
    if ctrl_after and any(d.upper() in ctrl_after for d in cfg.degraded_tracking_states):
        ev.append(_EV.TRACKING_DEGRADED.value)
        if _EV.TRACKING_DEGRADED.value not in rc:
            rc.append(_EV.TRACKING_DEGRADED.value)

    if rc:
        return True, ev, rc

    return False, [], []


# ---------------------------------------------------------------------------
# Inconclusive rule
# ---------------------------------------------------------------------------

def rule_inconclusive(
    record: ExperienceRecord,
    cfg: OutcomeEvaluatorConfig,
) -> Tuple[bool, List[str], List[str]]:
    """
    Return INCONCLUSIVE when evidence is present but contradictory or
    insufficient for a reliable classification.

    Conditions:
      - conflicting success / failure signals across subsystems
      - observation_state is UNKNOWN
      - action missing (no situation or action record)
      - none of the higher-priority rules matched
    """
    out = record.outcome
    sit = record.situation
    act = record.action

    ev: List[str] = []
    rc: List[str] = []

    if sit is None:
        ev.append(_EV.NO_SITUATION_RECORD.value)
        rc.append(_EV.NO_SITUATION_RECORD.value)
        return True, ev, rc

    if act is None:
        ev.append(_EV.NO_ACTION_RECORD.value)
        rc.append(_EV.NO_ACTION_RECORD.value)
        return True, ev, rc

    if out is not None and out.observation_state == OutcomeObservationState.UNKNOWN:
        ev.append(_EV.CONFLICTING_EVIDENCE.value)
        rc.append(_EV.CONFLICTING_EVIDENCE.value)
        return True, ev, rc

    # Conflicting: planner says ok but control says degraded (or vice versa)
    if out is not None:
        plan = _upper(out.planning_status_after)
        ctrl = _upper(out.control_state_after)
        plan_ok = plan and not any(
            _upper(s) in plan for s in cfg.failed_planning_statuses
        )
        ctrl_deg = ctrl and any(d.upper() in ctrl for d in cfg.degraded_tracking_states)
        if plan_ok and ctrl_deg:
            ev.append(_EV.CONFLICTING_EVIDENCE.value)
            rc.append(_EV.CONFLICTING_EVIDENCE.value)
            return True, ev, rc

    # Stale data
    if (sit is not None and sit.is_stale):
        ev.append(_EV.OBSERVATION_STALE.value)
        rc.append(_EV.OBSERVATION_STALE.value)
        return True, ev, rc

    # Fallback for any remaining uncategorised state
    ev.append(_EV.CONFLICTING_EVIDENCE.value)
    rc.append(_EV.CONFLICTING_EVIDENCE.value)
    return True, ev, rc


# ---------------------------------------------------------------------------
# Confidence assignment
# ---------------------------------------------------------------------------

def assign_confidence(
    evidence: List[str],
    reason_codes: List[str],
    is_degraded: bool,
) -> Tuple["EvaluationConfidence", float]:
    """
    Assign deterministic confidence and uncertainty based on evidence breadth.

    HIGH   → 3+ evidence items, no degraded, no CONFLICTING/INCOMPLETE
    MEDIUM → 1-2 evidence items, or DEGRADED / INCOMPLETE codes present
    LOW    → CONFLICTING_EVIDENCE present, or very few evidence items
    UNKNOWN → no evidence at all
    """
    from .evaluation_types import EvaluationConfidence as EC

    if not evidence:
        return EC.UNKNOWN, 1.0

    conflict_keys = {
        _EV.CONFLICTING_EVIDENCE.value,
        _EV.OBSERVATION_STALE.value,
        _EV.INVALID_RECORD.value,
        _EV.INVALID_IDS.value,
        _EV.INVALID_SCHEMA.value,
        _EV.INVALID_TIMESTAMPS.value,
    }
    degraded_keys = {
        _EV.DEGRADED_OBSERVATION.value,
        _EV.DEGRADED_SYSTEM_STATE.value,
        _EV.OBSERVATION_INCOMPLETE.value,
        _EV.OUTCOME_MISSING.value,
    }

    has_conflict = bool(set(evidence) & conflict_keys)
    has_degraded = is_degraded or bool(set(evidence) & degraded_keys)

    n = len(evidence)

    if has_conflict:
        return EC.LOW, 0.8
    if has_degraded:
        return EC.MEDIUM if n >= 2 else EC.LOW, 0.5
    if n >= 3:
        return EC.HIGH, 0.1
    if n >= 1:
        return EC.MEDIUM, 0.35
    return EC.UNKNOWN, 1.0


__all__ = [
    "rule_invalid_record",
    "rule_unsafe_outcome",
    "rule_no_outcome",
    "rule_pending",
    "rule_failure",
    "rule_partial_success",
    "rule_success",
    "rule_degraded",
    "rule_inconclusive",
    "assign_confidence",
]
