"""
IndiDrive AI — Phase 12.3 | Outcome Evaluator
==============================================
Deterministic, evidence-based evaluation of recorded driving experiences.

Consumes:   ExperienceRecord (SituationRecord + ActionRecord + OutcomeRecord)
Produces:   OutcomeEvaluation

Architecture:

    SituationRecord  ─┐
    ActionRecord     ─┼──► OutcomeEvaluator ──► OutcomeEvaluation
    OutcomeRecord    ─┘

Evaluation hierarchy (applied in strict priority order):

    1. INVALID          — structural / schema failure
    2. UNSAFE_OUTCOME   — confirmed collision / safety violation
    3. NO_OUTCOME       — no usable outcome data
    4. PENDING          — window not yet closed
    5. FAILURE          — clear inability to achieve intended response
    6. DEGRADED         — degraded-condition observation; ambiguous
    7. PARTIAL_SUCCESS  — safety maintained; partial achievement
    8. SUCCESS          — positive evidence of intended response
    9. INCONCLUSIVE     — conflicting or insufficient evidence (fallback)

Design invariants:
  * Deterministic: same record → same evaluation (no randomness, no time)
  * No vehicle control: evaluation NEVER touches steering/throttle/brake/MPC
  * No safety override: safety subsystem authority is preserved
  * No external calls: offline-only, no cloud, no language-model calls
  * Failure-isolated: exceptions → EVALUATION_ERROR (pipeline unaffected)
  * No experience retrieval (→ Phase 12.4)
  * No knowledge update (→ Phase 12.5)
  * No reinforcement-learning signal (→ Phase 12.6)
"""
from __future__ import annotations

import time
from typing import List, Optional

from core.experience.record.record_types import ExperienceRecord

from .evaluation_types import (
    EVALUATION_SCHEMA_VERSION,
    NOT_AVAILABLE,
    EvaluationConfidence,
    EvaluationStatus,
    EvidenceKey,
    OutcomeClass,
    OutcomeEvaluation,
    OutcomeEvaluationSnapshot,
    OutcomeEvaluatorConfig,
)
from .evaluation_rules import (
    assign_confidence,
    rule_degraded,
    rule_failure,
    rule_inconclusive,
    rule_invalid_record,
    rule_no_outcome,
    rule_partial_success,
    rule_pending,
    rule_success,
    rule_unsafe_outcome,
)

__all__ = ["OutcomeEvaluator"]

_EV = EvidenceKey


def _make_evaluation_id(record_id: str) -> str:
    """Deterministic evaluation ID: <record_id>-EVAL."""
    return f"{record_id}-EVAL"


class OutcomeEvaluator:
    """
    Deterministic, evidence-based outcome evaluator for Phase 12.3.

    One evaluator instance can evaluate many records.
    It holds no per-evaluation mutable state.

    Usage
    -----
    evaluator = OutcomeEvaluator(config)
    evaluation = evaluator.evaluate(record)
    snapshot   = evaluator.evaluate_to_snapshot(record)

    Thread-safety
    -------------
    evaluate() is thread-safe: all state is local to each call.
    """

    def __init__(self, config: Optional[OutcomeEvaluatorConfig] = None) -> None:
        if config is None:
            config = OutcomeEvaluatorConfig.default()
        if not isinstance(config, OutcomeEvaluatorConfig):
            raise TypeError(
                f"OutcomeEvaluator requires OutcomeEvaluatorConfig, "
                f"got {type(config).__name__}"
            )
        self._cfg = config

    @property
    def config(self) -> OutcomeEvaluatorConfig:
        return self._cfg

    # ------------------------------------------------------------------
    # Primary evaluation entry point

    def evaluate(self, record: ExperienceRecord) -> OutcomeEvaluation:
        """
        Evaluate one ExperienceRecord and return an OutcomeEvaluation.

        Returns an EVALUATION_ERROR evaluation if an unexpected exception
        occurs, so the calling pipeline is never disrupted.

        The evaluation timestamp is the only non-deterministic element —
        it records WHEN evaluation ran, not the driving outcome itself.
        """
        try:
            return self._evaluate_internal(record)
        except Exception as exc:  # pylint: disable=broad-except
            record_id = getattr(record, "record_id", NOT_AVAILABLE) or NOT_AVAILABLE
            return OutcomeEvaluation(
                evaluation_id=_make_evaluation_id(record_id),
                experience_id=record_id,
                session_id=getattr(record, "session_id", NOT_AVAILABLE) or NOT_AVAILABLE,
                schema_version=EVALUATION_SCHEMA_VERSION,
                evaluation_timestamp=time.time(),
                evaluation_status=EvaluationStatus.ERROR,
                outcome_class=OutcomeClass.EVALUATION_ERROR,
                confidence=EvaluationConfidence.UNKNOWN,
                evidence=(_EV.INVALID_RECORD.value,),
                reason_codes=(_EV.INVALID_RECORD.value,),
                uncertainty=1.0,
                is_degraded=False,
                inconclusive_reason=NOT_AVAILABLE,
                evaluation_error=str(exc),
            )

    def evaluate_to_snapshot(self, record: ExperienceRecord) -> OutcomeEvaluationSnapshot:
        """
        Evaluate one ExperienceRecord and return an immutable snapshot.

        Convenience wrapper; equivalent to evaluate() + snapshot().
        """
        ev = self.evaluate(record)
        return self._to_snapshot(ev)

    # ------------------------------------------------------------------
    # Internal evaluation pipeline

    def _evaluate_internal(self, record: ExperienceRecord) -> OutcomeEvaluation:
        if record is None:
            raise TypeError("ExperienceRecord is None")
        record_id = getattr(record, "record_id", NOT_AVAILABLE) or NOT_AVAILABLE
        session_id = getattr(record, "session_id", NOT_AVAILABLE) or NOT_AVAILABLE
        cfg = self._cfg

        evidence: List[str] = []
        reason_codes: List[str] = []
        outcome_class: OutcomeClass
        is_degraded = False

        # ------ PRIORITY 1: INVALID ------
        matched, ev, rc = rule_invalid_record(record, cfg)
        if matched:
            evidence.extend(ev)
            reason_codes.extend(rc)
            confidence, uncertainty = assign_confidence(evidence, reason_codes, False)
            return self._build(
                record_id, session_id,
                OutcomeClass.INVALID, EvaluationStatus.COMPLETE,
                evidence, reason_codes, confidence, uncertainty,
                False, NOT_AVAILABLE,
            )

        # ------ PRIORITY 2: UNSAFE_OUTCOME ------
        matched, ev, rc = rule_unsafe_outcome(record, cfg)
        if matched:
            evidence.extend(ev)
            reason_codes.extend(rc)
            confidence, uncertainty = assign_confidence(evidence, reason_codes, False)
            return self._build(
                record_id, session_id,
                OutcomeClass.UNSAFE_OUTCOME, EvaluationStatus.COMPLETE,
                evidence, reason_codes, confidence, uncertainty,
                False, NOT_AVAILABLE,
            )

        # ------ PRIORITY 3: NO_OUTCOME ------
        matched, ev, rc = rule_no_outcome(record, cfg)
        if matched:
            evidence.extend(ev)
            reason_codes.extend(rc)
            confidence, uncertainty = assign_confidence(evidence, reason_codes, False)
            return self._build(
                record_id, session_id,
                OutcomeClass.NO_OUTCOME, EvaluationStatus.COMPLETE,
                evidence, reason_codes, confidence, uncertainty,
                False, NOT_AVAILABLE,
            )

        # ------ PRIORITY 4: PENDING ------
        matched, ev, rc = rule_pending(record, cfg)
        if matched:
            evidence.extend(ev)
            reason_codes.extend(rc)
            return self._build(
                record_id, session_id,
                OutcomeClass.PENDING, EvaluationStatus.PENDING,
                evidence, reason_codes, EvaluationConfidence.UNKNOWN, 1.0,
                False, "observation window not yet closed",
            )

        # From here: record is structurally valid with an outcome present.
        # Determine if system was degraded (affects confidence later).
        out = record.outcome
        sit = record.situation
        if (out is not None and out.is_degraded) or (sit is not None and sit.is_degraded):
            is_degraded = True

        # ------ PRIORITY 5: FAILURE ------
        matched, ev, rc = rule_failure(record, cfg)
        if matched:
            evidence.extend(ev)
            reason_codes.extend(rc)
            confidence, uncertainty = assign_confidence(evidence, reason_codes, is_degraded)
            return self._build(
                record_id, session_id,
                OutcomeClass.FAILURE, EvaluationStatus.COMPLETE,
                evidence, reason_codes, confidence, uncertainty,
                is_degraded, NOT_AVAILABLE,
            )

        # ------ PRIORITY 6: DEGRADED (before PARTIAL/SUCCESS) ------
        # Degraded observations cannot reliably be classified as success/partial.
        matched, ev, rc = rule_degraded(record, cfg)
        if matched:
            is_degraded = True
            evidence.extend(ev)
            reason_codes.extend(rc)
            confidence, uncertainty = assign_confidence(evidence, reason_codes, True)
            return self._build(
                record_id, session_id,
                OutcomeClass.DEGRADED, EvaluationStatus.COMPLETE,
                evidence, reason_codes, confidence, uncertainty,
                True, NOT_AVAILABLE,
            )

        # ------ PRIORITY 7: PARTIAL_SUCCESS ------
        matched, ev, rc = rule_partial_success(record, cfg)
        if matched:
            evidence.extend(ev)
            reason_codes.extend(rc)
            confidence, uncertainty = assign_confidence(evidence, reason_codes, is_degraded)
            return self._build(
                record_id, session_id,
                OutcomeClass.PARTIAL_SUCCESS, EvaluationStatus.COMPLETE,
                evidence, reason_codes, confidence, uncertainty,
                is_degraded, NOT_AVAILABLE,
            )

        # ------ PRIORITY 8: SUCCESS ------
        matched, ev, rc = rule_success(record, cfg)
        if matched:
            evidence.extend(ev)
            reason_codes.extend(rc)
            confidence, uncertainty = assign_confidence(evidence, reason_codes, is_degraded)
            return self._build(
                record_id, session_id,
                OutcomeClass.SUCCESS, EvaluationStatus.COMPLETE,
                evidence, reason_codes, confidence, uncertainty,
                is_degraded, NOT_AVAILABLE,
            )

        # ------ PRIORITY 9: INCONCLUSIVE (fallback) ------
        matched, ev, rc = rule_inconclusive(record, cfg)
        evidence.extend(ev)
        reason_codes.extend(rc)
        inconcl_reason = (
            "insufficient or conflicting evidence for classification"
        )
        confidence, uncertainty = assign_confidence(evidence, reason_codes, is_degraded)
        return self._build(
            record_id, session_id,
            OutcomeClass.INCONCLUSIVE, EvaluationStatus.COMPLETE,
            evidence, reason_codes, confidence, uncertainty,
            is_degraded, inconcl_reason,
        )

    # ------------------------------------------------------------------
    # Builders

    def _build(
        self,
        record_id: str,
        session_id: str,
        outcome_class: OutcomeClass,
        status: EvaluationStatus,
        evidence: List[str],
        reason_codes: List[str],
        confidence: EvaluationConfidence,
        uncertainty: float,
        is_degraded: bool,
        inconclusive_reason: str,
    ) -> OutcomeEvaluation:
        return OutcomeEvaluation(
            evaluation_id=_make_evaluation_id(record_id),
            experience_id=record_id,
            session_id=session_id,
            schema_version=EVALUATION_SCHEMA_VERSION,
            evaluation_timestamp=time.time(),
            evaluation_status=status,
            outcome_class=outcome_class,
            confidence=confidence,
            evidence=tuple(evidence),
            reason_codes=tuple(reason_codes),
            uncertainty=round(uncertainty, 3),
            is_degraded=is_degraded,
            inconclusive_reason=inconclusive_reason,
            evaluation_error=NOT_AVAILABLE,
        )

    @staticmethod
    def _to_snapshot(ev: OutcomeEvaluation) -> OutcomeEvaluationSnapshot:
        return OutcomeEvaluationSnapshot(
            evaluation_id=ev.evaluation_id,
            experience_id=ev.experience_id,
            session_id=ev.session_id,
            schema_version=ev.schema_version,
            evaluation_timestamp=ev.evaluation_timestamp,
            evaluation_status=ev.evaluation_status,
            outcome_class=ev.outcome_class,
            confidence=ev.confidence,
            evidence=ev.evidence,
            reason_codes=ev.reason_codes,
            uncertainty=ev.uncertainty,
            is_degraded=ev.is_degraded,
            inconclusive_reason=ev.inconclusive_reason,
            evaluation_error=ev.evaluation_error,
        )
