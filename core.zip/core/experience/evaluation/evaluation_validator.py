"""
IndiDrive AI — Phase 12.3 | Evaluation Validator
=================================================
Validates OutcomeEvaluation structures.

Design rules:
  * Returns (is_valid: bool, reason: str) — no exceptions for validation.
  * Does NOT silently correct corrupted evaluation data.
  * Does NOT evaluate success/failure — only structural validation.
  * Deterministic.
"""
from __future__ import annotations

import math
from typing import Tuple

from .evaluation_types import (
    EVALUATION_SCHEMA_VERSION,
    NOT_AVAILABLE,
    EvaluationConfidence,
    EvaluationStatus,
    EvidenceKey,
    OutcomeClass,
    OutcomeEvaluation,
    OutcomeEvaluationSnapshot,
)

__all__ = ["EvaluationValidator"]

_ValidationResult = Tuple[bool, str]
_KNOWN_EVIDENCE_KEYS = {e.value for e in EvidenceKey}


class EvaluationValidator:
    """
    Validates Phase 12.3 OutcomeEvaluation and OutcomeEvaluationSnapshot objects.

    Usage
    -----
    v = EvaluationValidator()
    ok, reason = v.validate_evaluation(ev)
    ok, reason = v.validate_snapshot(snap)
    """

    # ------------------------------------------------------------------
    # OutcomeEvaluation validation

    def validate_evaluation(self, ev: OutcomeEvaluation) -> _ValidationResult:
        if ev is None:
            return False, "evaluation is None"

        if ev.schema_version != EVALUATION_SCHEMA_VERSION:
            return False, f"schema_version mismatch: {ev.schema_version!r}"

        if not ev.evaluation_id or ev.evaluation_id == NOT_AVAILABLE:
            return False, "evaluation_id missing"

        if not ev.experience_id or ev.experience_id == NOT_AVAILABLE:
            return False, "experience_id missing"

        if not ev.session_id or ev.session_id == NOT_AVAILABLE:
            return False, "session_id missing"

        # evaluation_id format check
        expected_suffix = f"{ev.experience_id}-EVAL"
        if ev.evaluation_id != expected_suffix:
            return False, (
                f"evaluation_id {ev.evaluation_id!r} "
                f"does not match expected {expected_suffix!r}"
            )

        if ev.evaluation_timestamp < 0:
            return False, f"evaluation_timestamp < 0: {ev.evaluation_timestamp}"

        if not isinstance(ev.evaluation_status, EvaluationStatus):
            return False, f"evaluation_status is not EvaluationStatus: {ev.evaluation_status!r}"

        if not isinstance(ev.outcome_class, OutcomeClass):
            return False, f"outcome_class is not OutcomeClass: {ev.outcome_class!r}"

        if not isinstance(ev.confidence, EvaluationConfidence):
            return False, f"confidence is not EvaluationConfidence: {ev.confidence!r}"

        ok, reason = self._check_uncertainty(ev.uncertainty)
        if not ok:
            return False, reason

        if not isinstance(ev.evidence, tuple):
            return False, f"evidence must be tuple, got {type(ev.evidence).__name__}"

        if not isinstance(ev.reason_codes, tuple):
            return False, f"reason_codes must be tuple, got {type(ev.reason_codes).__name__}"

        # Evidence must not be empty for COMPLETE evaluations
        if (ev.evaluation_status == EvaluationStatus.COMPLETE
                and not ev.evidence):
            return False, "COMPLETE evaluation has no evidence"

        # reason_codes must be a subset of evidence
        ev_set = set(ev.evidence)
        for rc in ev.reason_codes:
            if rc not in ev_set:
                return False, (
                    f"reason_code {rc!r} not in evidence set {ev_set!r}"
                )

        # Evidence keys should be known strings
        for e in ev.evidence:
            if not isinstance(e, str):
                return False, f"evidence entry {e!r} is not a string"

        return True, "ok"

    # ------------------------------------------------------------------
    # OutcomeEvaluationSnapshot validation

    def validate_snapshot(self, snap: OutcomeEvaluationSnapshot) -> _ValidationResult:
        if snap is None:
            return False, "snapshot is None"

        if snap.schema_version != EVALUATION_SCHEMA_VERSION:
            return False, f"schema_version mismatch: {snap.schema_version!r}"

        if not snap.evaluation_id or snap.evaluation_id == NOT_AVAILABLE:
            return False, "evaluation_id missing"

        if not snap.experience_id or snap.experience_id == NOT_AVAILABLE:
            return False, "experience_id missing"

        expected = f"{snap.experience_id}-EVAL"
        if snap.evaluation_id != expected:
            return False, (
                f"evaluation_id {snap.evaluation_id!r} "
                f"!= expected {expected!r}"
            )

        if snap.evaluation_timestamp < 0:
            return False, f"evaluation_timestamp < 0"

        if not isinstance(snap.evaluation_status, EvaluationStatus):
            return False, "evaluation_status invalid type"

        if not isinstance(snap.outcome_class, OutcomeClass):
            return False, "outcome_class invalid type"

        ok, reason = self._check_uncertainty(snap.uncertainty)
        if not ok:
            return False, reason

        return True, "ok"

    # ------------------------------------------------------------------
    # Helpers

    @staticmethod
    def _check_uncertainty(u: float) -> _ValidationResult:
        if not isinstance(u, (int, float)):
            return False, f"uncertainty must be numeric, got {type(u).__name__}"
        if math.isnan(u) or math.isinf(u):
            return False, f"uncertainty is NaN or infinite: {u}"
        if not (0.0 <= u <= 1.0):
            return False, f"uncertainty {u} out of [0.0, 1.0]"
        return True, "ok"
