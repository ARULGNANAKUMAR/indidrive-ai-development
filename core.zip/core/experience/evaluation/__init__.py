"""
IndiDrive AI — Phase 12.3 | Outcome Evaluation
===============================================
Public API for the Phase 12.3 outcome evaluation layer.

Phase 12.3 evaluates what happened — it does NOT:
  - control the vehicle
  - modify planning, MPC, or tracking
  - override safety decisions
  - retrieve historical experiences (→ Phase 12.4)
  - update knowledge or models (→ Phase 12.5)
  - generate RL reward (→ Phase 12.6)
"""

from .evaluation_types import (
    NOT_AVAILABLE,
    EVALUATION_SCHEMA_VERSION,
    OutcomeClass,
    EvaluationConfidence,
    EvaluationStatus,
    EvidenceKey,
    OutcomeEvaluation,
    OutcomeEvaluationSnapshot,
    OutcomeEvaluatorConfig,
)
from .evaluation_validator import EvaluationValidator
from .outcome_evaluator import OutcomeEvaluator
from .evaluation_store import EvaluationStore, EvaluationStoreSnapshot

__all__ = [
    "NOT_AVAILABLE",
    "EVALUATION_SCHEMA_VERSION",
    "OutcomeClass",
    "EvaluationConfidence",
    "EvaluationStatus",
    "EvidenceKey",
    "OutcomeEvaluation",
    "OutcomeEvaluationSnapshot",
    "OutcomeEvaluatorConfig",
    "EvaluationValidator",
    "OutcomeEvaluator",
    "EvaluationStore",
    "EvaluationStoreSnapshot",
]
