"""
IndiDrive AI — Phase 12.3 | Evaluation Store
============================================
Bounded, offline-first, thread-safe store for OutcomeEvaluation objects.

Design:
  * Reuses the Phase 12.1/12.2 session concept — one store per session.
  * In-memory only; no external database.
  * Bounded by max_evaluations; FIFO eviction on overflow.
  * Thread-safe via threading.Lock.
  * Failure-isolated: store failures do NOT affect the pipeline.
  * No similarity search (→ Phase 12.4).
  * No knowledge update (→ Phase 12.5).
"""
from __future__ import annotations

import threading
from typing import Dict, List, Optional, Tuple

from .evaluation_types import (
    NOT_AVAILABLE,
    EVALUATION_SCHEMA_VERSION,
    OutcomeClass,
    OutcomeEvaluation,
    OutcomeEvaluationSnapshot,
)

__all__ = ["EvaluationStore", "EvaluationStoreSnapshot"]


# ---------------------------------------------------------------------------
# Store snapshot
# ---------------------------------------------------------------------------

from dataclasses import dataclass, field

@dataclass
class EvaluationStoreSnapshot:
    """Immutable session-level view of the EvaluationStore."""
    schema_version: str = EVALUATION_SCHEMA_VERSION
    session_id: str = NOT_AVAILABLE
    total_evaluations: int = 0
    complete_evaluations: int = 0
    pending_evaluations: int = 0
    error_evaluations: int = 0
    # Bounded tuple of recent snapshots
    recent_evaluations: Tuple[OutcomeEvaluationSnapshot, ...] = field(
        default_factory=tuple
    )
    store_failed: bool = False
    failure_reason: str = NOT_AVAILABLE

    def to_dict(self) -> dict:
        return {
            "schema_version": self.schema_version,
            "session_id": self.session_id,
            "total_evaluations": self.total_evaluations,
            "complete_evaluations": self.complete_evaluations,
            "pending_evaluations": self.pending_evaluations,
            "error_evaluations": self.error_evaluations,
            "recent_evaluation_count": len(self.recent_evaluations),
            "store_failed": self.store_failed,
            "failure_reason": self.failure_reason,
        }


# ---------------------------------------------------------------------------
# Store
# ---------------------------------------------------------------------------

class EvaluationStore:
    """
    Bounded in-memory store for OutcomeEvaluation objects.

    One store manages one active session.
    Thread-safe: all public methods protected by self._lock.

    Lifecycle
    ---------
    store = EvaluationStore(max_evaluations=500)
    store.start_session("session-001")
    store.add_evaluation(evaluation)         # after OutcomeEvaluator runs
    eval  = store.get_evaluation(record_id)
    snap  = store.get_store_snapshot()
    store.finalize_session()
    """

    def __init__(
        self,
        max_evaluations: int = 500,
        recent_window: int = 20,
    ) -> None:
        if max_evaluations < 1:
            raise ValueError(f"max_evaluations must be >=1, got {max_evaluations}")
        if recent_window < 1:
            raise ValueError(f"recent_window must be >=1, got {recent_window}")
        self._max = max_evaluations
        self._window = recent_window
        self._lock = threading.Lock()
        self._session_id: str = NOT_AVAILABLE
        self._evaluations: Dict[str, OutcomeEvaluation] = {}  # keyed by experience_id
        self._order: List[str] = []   # insertion order for FIFO eviction
        self._is_active: bool = False

    # ------------------------------------------------------------------
    # Session management

    def start_session(self, session_id: str) -> None:
        with self._lock:
            self._session_id = session_id
            self._evaluations.clear()
            self._order.clear()
            self._is_active = True

    def finalize_session(self) -> None:
        with self._lock:
            self._is_active = False

    # ------------------------------------------------------------------
    # Write

    def add_evaluation(self, evaluation: OutcomeEvaluation) -> bool:
        """
        Add or overwrite an evaluation.

        Returns True on success, False on internal error.
        Storage errors do NOT propagate — failure-isolated.
        """
        try:
            with self._lock:
                exp_id = evaluation.experience_id
                # Evict oldest if at capacity (FIFO)
                if (exp_id not in self._evaluations
                        and len(self._evaluations) >= self._max):
                    oldest = self._order.pop(0)
                    self._evaluations.pop(oldest, None)
                if exp_id not in self._evaluations:
                    self._order.append(exp_id)
                self._evaluations[exp_id] = evaluation
                return True
        except Exception:  # pylint: disable=broad-except
            return False

    # ------------------------------------------------------------------
    # Read

    def get_evaluation(
        self, experience_id: str
    ) -> Optional[OutcomeEvaluation]:
        """Return the evaluation for a given experience/record ID, or None."""
        with self._lock:
            return self._evaluations.get(experience_id)

    def get_evaluation_snapshot(
        self, experience_id: str
    ) -> Optional[OutcomeEvaluationSnapshot]:
        """Return an immutable snapshot for a given experience ID, or None."""
        with self._lock:
            ev = self._evaluations.get(experience_id)
        if ev is None:
            return None
        return self._to_snapshot(ev)

    def get_all_snapshots(self) -> Tuple[OutcomeEvaluationSnapshot, ...]:
        """Return all stored evaluations as immutable snapshots (insertion order)."""
        with self._lock:
            order_copy = list(self._order)
            evals_copy = dict(self._evaluations)
        snaps = []
        for eid in order_copy:
            ev = evals_copy.get(eid)
            if ev is not None:
                snaps.append(self._to_snapshot(ev))
        return tuple(snaps)

    def get_unevaluated_ids(
        self,
        all_record_ids: Tuple[str, ...],
    ) -> Tuple[str, ...]:
        """
        Return record IDs from all_record_ids that have no stored evaluation.
        """
        with self._lock:
            evaluated = set(self._evaluations.keys())
        return tuple(rid for rid in all_record_ids if rid not in evaluated)

    def get_evaluated_by_class(
        self,
        outcome_class: OutcomeClass,
    ) -> Tuple[OutcomeEvaluationSnapshot, ...]:
        """Return snapshots where outcome_class matches."""
        with self._lock:
            order_copy = list(self._order)
            evals_copy = dict(self._evaluations)
        result = []
        for eid in order_copy:
            ev = evals_copy.get(eid)
            if ev is not None and ev.outcome_class == outcome_class:
                result.append(self._to_snapshot(ev))
        return tuple(result)

    # ------------------------------------------------------------------
    # Store snapshot

    def get_store_snapshot(self) -> EvaluationStoreSnapshot:
        """Return an immutable session-level summary."""
        try:
            with self._lock:
                total = len(self._evaluations)
                complete = sum(
                    1 for ev in self._evaluations.values()
                    if ev.evaluation_status.value == "COMPLETE"
                )
                pending = sum(
                    1 for ev in self._evaluations.values()
                    if ev.evaluation_status.value == "PENDING"
                )
                error = sum(
                    1 for ev in self._evaluations.values()
                    if ev.evaluation_status.value == "ERROR"
                )
                recent_ids = self._order[-self._window:]
                recent = tuple(
                    self._to_snapshot(self._evaluations[eid])
                    for eid in recent_ids
                    if eid in self._evaluations
                )
                session_id = self._session_id
            return EvaluationStoreSnapshot(
                schema_version=EVALUATION_SCHEMA_VERSION,
                session_id=session_id,
                total_evaluations=total,
                complete_evaluations=complete,
                pending_evaluations=pending,
                error_evaluations=error,
                recent_evaluations=recent,
                store_failed=False,
                failure_reason=NOT_AVAILABLE,
            )
        except Exception as exc:  # pylint: disable=broad-except
            return EvaluationStoreSnapshot(
                store_failed=True,
                failure_reason=str(exc),
            )

    # ------------------------------------------------------------------
    # Internal

    @staticmethod
    def _to_snapshot(ev: OutcomeEvaluation) -> OutcomeEvaluationSnapshot:
        from .evaluation_types import (
            EvaluationStatus, OutcomeClass, EvaluationConfidence,
        )
        return OutcomeEvaluationSnapshot(
            evaluation_id=ev.evaluation_id,
            experience_id=ev.experience_id,
            session_id=ev.session_id,
            schema_version=ev.schema_version,
            evaluation_timestamp=ev.evaluation_timestamp,
            evaluation_status=ev.evaluation_status,
            outcome_class=ev.outcome_class,
            confidence=ev.confidence,
            evidence=ev.evidence,
            reason_codes=ev.reason_codes,
            uncertainty=ev.uncertainty,
            is_degraded=ev.is_degraded,
            inconclusive_reason=ev.inconclusive_reason,
            evaluation_error=ev.evaluation_error,
        )
