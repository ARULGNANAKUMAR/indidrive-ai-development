"""
IndiDrive AI — Phase 5.1 | Object Memory Entry Validation
===========================================================
Validates ObjectMemoryEntry before it enters the store.  Returns a
structured result so callers can log and skip invalid entries without
crashing the pipeline.

All validation is deterministic: same input → same verdict every time.
"""
from __future__ import annotations

import math
from typing import Optional

from .memory_types import (
    ObjectMemoryEntry,
    MemoryOperationResult,
    NOT_AVAILABLE,  # re-exported from core.perception via memory_types
)

# Import the sentinel directly to avoid circular chains
from core.perception.perception_types import NOT_AVAILABLE as _NA

__all__ = ["validate_entry"]


def _is_valid_id(v) -> bool:
    return isinstance(v, str) and len(v.strip()) > 0


def _is_valid_confidence(v) -> bool:
    return isinstance(v, (int, float)) and math.isfinite(v) and 0.0 <= v <= 1.0


def _is_valid_timestamp(v) -> bool:
    return isinstance(v, (int, float)) and math.isfinite(v) and v >= 0.0


def validate_entry(entry: ObjectMemoryEntry) -> MemoryOperationResult:
    """Return MemoryOperationResult(ok=True) if entry is storable,
    or MemoryOperationResult(ok=False, reason=...) with a clear message.

    Rules:
    - memory_id must be a non-empty string
    - object_type must not be empty or NOT_AVAILABLE
    - confidence must be in [0.0, 1.0] and finite
    - timestamps (observed_at, created_at, updated_at) must be finite >= 0
    - If position is present its fields must be finite (None is allowed)
    - If dimensions are present, numeric fields must be finite and >= 0
    - If motion is present, speed/acceleration must be >= 0 and finite
    """
    mid = getattr(entry, "memory_id", None)
    if not _is_valid_id(mid):
        return MemoryOperationResult.failure("memory_id is missing or empty")

    obj_type = getattr(entry, "object_type", None)
    if not isinstance(obj_type, str) or obj_type.strip() in ("", _NA, "NOT_AVAILABLE"):
        return MemoryOperationResult.failure(
            "object_type is missing or NOT_AVAILABLE", memory_id=mid
        )

    if not _is_valid_confidence(entry.confidence):
        return MemoryOperationResult.failure(
            f"confidence={entry.confidence!r} is not in [0.0, 1.0] or is NaN/Inf",
            memory_id=mid,
        )

    for ts_name in ("observed_at", "created_at", "updated_at"):
        ts_val = getattr(entry, ts_name, None)
        if not _is_valid_timestamp(ts_val):
            return MemoryOperationResult.failure(
                f"{ts_name}={ts_val!r} is invalid (NaN, Inf, or negative)", memory_id=mid
            )

    if entry.position is not None and not entry.position.is_valid():
        return MemoryOperationResult.failure(
            "position contains NaN or Inf values", memory_id=mid
        )

    if entry.dimensions is not None and not entry.dimensions.is_valid():
        return MemoryOperationResult.failure(
            "dimensions contain NaN, Inf, or negative values", memory_id=mid
        )

    if entry.motion is not None and not entry.motion.is_valid():
        return MemoryOperationResult.failure(
            "motion contains NaN, Inf, or negative speed/acceleration", memory_id=mid
        )

    return MemoryOperationResult.success(mid)
