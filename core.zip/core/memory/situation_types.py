"""
IndiDrive AI — Phase 5.3A | Situation Representation
======================================================
Lightweight, structured representation of the *current driving situation*
for one observed object, ready to be compared against stored prototypes.

Pipeline context:

    Raw Sensor Data → Perception → Fusion → Tracking/Prediction
        → Phase 5.1 ObjectMemoryEntry  (individual instance store)
        → Phase 5.2 ObjectFeatureSet / ObjectPrototype  (compact typed features)
        → Phase 5.3A CurrentSituation  (normalised snapshot for similarity)
        → Phase 5.3B Experience Retrieval (NOT YET — future phase)

Design rules (same as Phases 5.1 and 5.2):
  * compact, deterministic, serialisable, validated
  * offline-first — no raw sensor data, no cloud, no LLM, no vector DB
  * optional fields are None, never fabricated
  * same input → same output (no randomness, no timestamps as noise)
  * missing features are skipped during similarity, not penalised as zero

Phase boundary: 5.3A only.
  - Does NOT perform top-K retrieval, ranking, search, planning, control,
    or any decision-making — those belong to Phase 5.3B and later.
"""
from __future__ import annotations

import json
import math
from dataclasses import dataclass, field
from typing import Optional

from core.perception.perception_types import NOT_AVAILABLE
from .feature_types import (
    GeometryFeature,
    ShapeFeature,
    AppearanceFeature,
    MotionFeature,
    _finite,
    _finite_nonneg_or_none,
    _valid_descriptor,
    DEFAULT_MAX_DESCRIPTOR_DIM,
)

__all__ = [
    "SITUATION_SCHEMA_VERSION",
    "CurrentSituation",
    "SituationValidationResult",
    "validate_situation",
]

# Increment when the serialised schema changes in a breaking way.
SITUATION_SCHEMA_VERSION: int = 1


def _opt_float(v) -> Optional[float]:
    return float(v) if v not in (None, NOT_AVAILABLE) else None


def _dict_or_na(v):
    return v if v is not None else NOT_AVAILABLE


# ---------------------------------------------------------------------------
# Validation result (reuses the same pattern as Phase 5.1/5.2)
# ---------------------------------------------------------------------------

@dataclass
class SituationValidationResult:
    """Structured result for a CurrentSituation validation pass.

    Never raises silently — callers check ok / reason.
    """
    ok: bool
    reason: str = ""

    @staticmethod
    def success() -> "SituationValidationResult":
        return SituationValidationResult(ok=True)

    @staticmethod
    def failure(reason: str) -> "SituationValidationResult":
        return SituationValidationResult(ok=False, reason=reason)


# ---------------------------------------------------------------------------
# Current Situation
# ---------------------------------------------------------------------------

@dataclass
class CurrentSituation:
    """Compact, normalised snapshot of one observed object in the current
    driving scene.

    Fields mirror the Phase 5.2 ObjectFeatureSet so comparisons are
    structurally aligned. Only information already present in the Phase 5.1
    and 5.2 schemas is included — nothing is invented beyond those bounds.

    All feature sub-structs are optional: a situation observed purely from
    radar may have motion but no appearance; one from LiDAR may have geometry
    but no appearance. Missing fields are represented as None rather than
    being filled with sentinel zeros, so the similarity engine can skip them
    rather than being misled by fabricated values.

    Parameters
    ----------
    object_type:
        Matches the object_type field in ObjectFeatureSet (e.g. "CAR",
        "PEDESTRIAN"). Required; must not be NOT_AVAILABLE or empty.
    geometry:
        Bounding-box geometry taken directly from the Phase 5.2
        GeometryFeature type.
    shape:
        Shape descriptor taken from Phase 5.2 ShapeFeature.
    appearance:
        Appearance descriptor from Phase 5.2 AppearanceFeature.
    motion:
        Motion descriptor from Phase 5.2 MotionFeature.
    confidence:
        Observation confidence in [0.0, 1.0]. Carried through from the
        upstream perception/fusion pipeline; not used in the similarity
        score itself but useful for callers evaluating result quality.
    source:
        Short tag identifying the originating pipeline step
        (e.g. "camera", "lidar", "fusion"). Informational only.
    timestamp:
        Wall-clock time (seconds since epoch) of the observation. Used
        for logging / debugging only — never as a scoring factor.
    situation_schema_version:
        Schema version for future-proof serialisation.
    """

    # --- Required ---
    object_type: str = NOT_AVAILABLE

    # --- Optional feature groups (exactly matching Phase 5.2 types) ---
    geometry: Optional[GeometryFeature] = None
    shape: Optional[ShapeFeature] = None
    appearance: Optional[AppearanceFeature] = None
    motion: Optional[MotionFeature] = None

    # --- Metadata ---
    confidence: float = 0.0
    source: str = NOT_AVAILABLE
    timestamp: Optional[float] = None

    # --- Schema ---
    situation_schema_version: int = SITUATION_SCHEMA_VERSION

    # ---------------------------------------------------------------
    # Serialisation
    # ---------------------------------------------------------------

    def to_dict(self) -> dict:
        return {
            "situation_schema_version": self.situation_schema_version,
            "object_type": self.object_type,
            "geometry": self.geometry.to_dict() if self.geometry else NOT_AVAILABLE,
            "shape": self.shape.to_dict() if self.shape else NOT_AVAILABLE,
            "appearance": self.appearance.to_dict() if self.appearance else NOT_AVAILABLE,
            "motion": self.motion.to_dict() if self.motion else NOT_AVAILABLE,
            "confidence": round(self.confidence, 6),
            "source": self.source,
            "timestamp": self.timestamp if self.timestamp is not None else NOT_AVAILABLE,
        }

    def to_json(self) -> str:
        """Deterministic JSON serialisation (sorted keys)."""
        return json.dumps(self.to_dict(), sort_keys=True)

    @staticmethod
    def from_dict(d: dict) -> "CurrentSituation":
        """Deserialise from a dict produced by to_dict().

        Raises ValueError on schema version mismatch or missing
        required fields. Permissive on optional feature fields: if a
        feature block is absent or NOT_AVAILABLE it becomes None.
        """
        schema_ver = int(d.get("situation_schema_version", 0))
        if schema_ver != SITUATION_SCHEMA_VERSION:
            raise ValueError(
                f"Unsupported situation_schema_version={schema_ver}; "
                f"expected {SITUATION_SCHEMA_VERSION}"
            )

        def _geo(v):
            return GeometryFeature.from_dict(v) if isinstance(v, dict) else None

        def _shp(v):
            return ShapeFeature.from_dict(v) if isinstance(v, dict) else None

        def _app(v):
            return AppearanceFeature.from_dict(v) if isinstance(v, dict) else None

        def _mot(v):
            return MotionFeature.from_dict(v) if isinstance(v, dict) else None

        def _opt_str(v):
            return v if (isinstance(v, str) and v != NOT_AVAILABLE) else NOT_AVAILABLE

        ts_raw = d.get("timestamp")
        timestamp = _opt_float(ts_raw)

        return CurrentSituation(
            object_type=d.get("object_type", NOT_AVAILABLE),
            geometry=_geo(d.get("geometry")),
            shape=_shp(d.get("shape")),
            appearance=_app(d.get("appearance")),
            motion=_mot(d.get("motion")),
            confidence=float(d.get("confidence", 0.0)),
            source=_opt_str(d.get("source")),
            timestamp=timestamp,
            situation_schema_version=schema_ver,
        )

    @staticmethod
    def from_json(s: str) -> "CurrentSituation":
        try:
            d = json.loads(s)
        except json.JSONDecodeError as e:
            raise ValueError(f"Invalid JSON: {e}") from e
        return CurrentSituation.from_dict(d)


# ---------------------------------------------------------------------------
# Validation
# ---------------------------------------------------------------------------

def validate_situation(
    s: CurrentSituation,
    max_descriptor_dim: int = DEFAULT_MAX_DESCRIPTOR_DIM,
) -> SituationValidationResult:
    """Validate a CurrentSituation before feeding it to the similarity engine.

    Deterministic: same input → same verdict. Never raises; returns a
    SituationValidationResult so callers can log and skip without crashing.

    Reuses the same validation philosophy as Phase 5.2's validate_feature_set().
    """
    if not isinstance(s.object_type, str) or s.object_type.strip() in ("", NOT_AVAILABLE):
        return SituationValidationResult.failure(
            "object_type is missing or NOT_AVAILABLE"
        )

    if not (_finite(s.confidence) and 0.0 <= s.confidence <= 1.0):
        return SituationValidationResult.failure(
            f"confidence={s.confidence!r} is not in [0.0, 1.0] or is NaN/Inf"
        )

    if s.timestamp is not None:
        if not isinstance(s.timestamp, (int, float)) or not math.isfinite(s.timestamp):
            return SituationValidationResult.failure(
                f"timestamp={s.timestamp!r} is NaN or Inf"
            )

    if s.geometry is not None and not s.geometry.is_valid():
        return SituationValidationResult.failure(
            "geometry contains NaN, Inf, or negative values"
        )

    if s.shape is not None and not s.shape.is_valid(max_descriptor_dim):
        return SituationValidationResult.failure(
            "shape descriptor is invalid, malformed, or exceeds max_descriptor_dim"
        )

    if s.appearance is not None and not s.appearance.is_valid(max_descriptor_dim):
        return SituationValidationResult.failure(
            "appearance descriptor is invalid, malformed, or exceeds max_descriptor_dim"
        )

    if s.motion is not None and not s.motion.is_valid():
        return SituationValidationResult.failure(
            "motion contains NaN, Inf, invalid speed range, or invalid motion_class"
        )

    return SituationValidationResult.success()
