"""
IndiDrive AI — Phase 8.3 | Feature Normalization Layer
========================================================
Deterministic, NaN/Inf-safe normalization of feature values before
they are compared or stored in the prototype memory.

Purpose
-------
Raw feature values from sensor fusion have heterogeneous scales:
  * distance_m  — 0 to ~150 m
  * speed_ms    — 0 to ~40 m/s
  * road_width  — 0 to ~30 m
  * TTC         — 0 to ~60 s
  * count fields — 0 to ~50

Prototype similarity requires all numeric values to live in [0, 1] so
that no single feature dominates due to scale.

Design guarantees
-----------------
* Deterministic: same inputs → same normalized vector.
* Missing-value safe: None / NOT_AVAILABLE → NaN sentinel in the
  normalized vector, then callers can detect and skip them.
* NaN / Inf guard: any non-finite input is treated as missing.
* Versioned: NORMALIZER_VERSION in every SituationFeatureVector so
  that saved memories can be validated against the producing version.
* No ML, no cloud, no database.

SituationFeatureVector layout
------------------------------
A compact fixed-order NumPy-free list of floats (or None for missing):

Index  Field               Range after norm    Source
-----  ----------------    ----------------    --------
0      geometry.length     [0, 1]              ObjectFeatureSet.geometry
1      geometry.width      [0, 1]              ObjectFeatureSet.geometry
2      geometry.height     [0, 1]              ObjectFeatureSet.geometry
3      geometry.aspect_ratio [0, 1]            ObjectFeatureSet.geometry
4      motion.speed_ms     [0, 1]              ObjectFeatureSet.motion
5      motion.heading_rad  [0, 1] (circular)   ObjectFeatureSet.motion
6      motion.accel        [0, 1] (clamped)    ObjectFeatureSet.motion
7      motion.motion_class [0, 1] (ordinal)    ObjectFeatureSet.motion (MotionClass)
8      context.road_type   [0, 1] (ordinal)    ContextFeature
9      context.traffic_density [0, 1]          ContextFeature
10     context.road_marking [0, 1]             ContextFeature
11     context.road_damage  [0, 1]             ContextFeature
12     context.intersection [0, 1]             ContextFeature
13     context.road_width_m [0, 1]             ContextFeature
14     context.object_count [0, 1]             ContextFeature
15     context.mixed_traffic [0, 1] (bool)     ContextFeature
16     context.animal_present [0, 1] (bool)    ContextFeature
17     risk.overall_risk   [0, 1] (ordinal)    RiskFeature
18     risk.object_risk    [0, 1] (ordinal)    RiskFeature
19     risk.ttc_band       [0, 1] (ordinal)    RiskFeature
20     risk.collision_likelihood [0, 1]         RiskFeature
21     risk.closing_speed  [0, 1]              RiskFeature
22     risk.distance_m     [0, 1]              RiskFeature

VECTOR_DIM = 23  (bounded, fixed for this schema version)

Phase boundary: Phase 8.3 only.
Does NOT implement retrieval, reasoning, path planning, or control.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import List, Optional

from .context_feature_types import (
    ContextFeature,
    RiskFeature,
    RoadTypeClass,
    TrafficDensityClass,
    RoadMarkingClass,
    IntersectionClass,
    RoadDamageClass,
    RiskLevelClass,
    TtcBandClass,
)
from .feature_types import (
    ObjectFeatureSet,
    MotionClass,
    _finite,
)

__all__ = [
    "NORMALIZER_VERSION",
    "VECTOR_DIM",
    "FEATURE_NAMES",
    "SituationFeatureVector",
    "FeatureNormalizer",
    "NormalizerConfig",
]

NORMALIZER_VERSION: int = 1

# Fixed vector length — must match the table in the module docstring.
VECTOR_DIM: int = 23

FEATURE_NAMES: List[str] = [
    "geo.length",
    "geo.width",
    "geo.height",
    "geo.aspect_ratio",
    "mot.speed",
    "mot.heading",
    "mot.accel",
    "mot.motion_class",
    "ctx.road_type",
    "ctx.traffic_density",
    "ctx.road_marking",
    "ctx.road_damage",
    "ctx.intersection",
    "ctx.road_width",
    "ctx.object_count",
    "ctx.mixed_traffic",
    "ctx.animal_present",
    "risk.overall",
    "risk.object",
    "risk.ttc_band",
    "risk.collision_likelihood",
    "risk.closing_speed",
    "risk.distance",
]

assert len(FEATURE_NAMES) == VECTOR_DIM, "FEATURE_NAMES must match VECTOR_DIM"


# ---------------------------------------------------------------------------
# Config (reference ranges for normalisation)
# ---------------------------------------------------------------------------

@dataclass
class NormalizerConfig:
    """Reference ranges used to normalise each continuous field.

    Ranges are loaded from config/feature_memory_config.yaml section
    'normalizer' if available; these defaults apply otherwise.

    Changing these changes the stored vector representation — increment
    NORMALIZER_VERSION if defaults are modified in a breaking way.
    """
    # Geometry (metres)
    max_length_m: float = 20.0        # ~bus length
    max_width_m: float = 5.0          # ~wide truck
    max_height_m: float = 5.0         # ~bus height
    max_aspect_ratio: float = 10.0    # length/width upper bound

    # Motion
    max_speed_ms: float = 40.0        # ~144 km/h — outer plausible bound
    max_accel_ms2: float = 8.0        # clamped ±8 m/s²

    # Context
    max_road_width_m: float = 30.0    # wide Indian highway
    max_object_count: int = 60        # bounded scene cap

    # Risk
    max_ttc_s: float = 12.0           # TTC > 12s treated as no-threat
    max_distance_m: float = 100.0     # beyond 100m risk is near-zero
    max_closing_speed_ms: float = 30.0  # m/s


# ---------------------------------------------------------------------------
# SituationFeatureVector
# ---------------------------------------------------------------------------

@dataclass
class SituationFeatureVector:
    """Compact normalised feature vector for one scene observation.

    ``values`` is a fixed-length list of length VECTOR_DIM.
    Each entry is a float in [0.0, 1.0], or ``None`` for missing/unavailable.

    Serialisable to/from a dict so it can be stored in prototype memory
    or checkpointed to disk.
    """
    values: List[Optional[float]] = field(default_factory=lambda: [None] * VECTOR_DIM)
    normalizer_version: int = NORMALIZER_VERSION
    available_count: int = 0     # number of non-None slots (filled at build time)
    object_type: str = ""        # carried for prototype routing

    def __post_init__(self) -> None:
        # Defensive: ensure list is exactly VECTOR_DIM long.
        if len(self.values) != VECTOR_DIM:
            self.values = (list(self.values) + [None] * VECTOR_DIM)[:VECTOR_DIM]
        self.available_count = sum(1 for v in self.values if v is not None)

    def is_usable(self) -> bool:
        """At least 3 features must be available to be meaningful."""
        return self.available_count >= 3

    def distance_to(self, other: "SituationFeatureVector") -> float:
        """Deterministic Euclidean distance over the mutually available
        subset, normalised to [0.0, 1.0].

        Only positions where BOTH vectors have a non-None value
        contribute to the distance. Returns 1.0 when no position is
        mutually available (maximally dissimilar).
        """
        diffs = []
        for a, b in zip(self.values, other.values):
            if a is None or b is None:
                continue
            if not (_finite(a) and _finite(b)):
                continue
            diffs.append((a - b) ** 2)
        if not diffs:
            return 1.0
        rmse = math.sqrt(sum(diffs) / len(diffs))
        return min(1.0, rmse)

    def similarity_to(self, other: "SituationFeatureVector") -> float:
        """Similarity in [0.0, 1.0] (1.0 = identical)."""
        return max(0.0, 1.0 - self.distance_to(other))

    def to_dict(self) -> dict:
        return {
            "normalizer_version": self.normalizer_version,
            "object_type": self.object_type,
            "available_count": self.available_count,
            "values": [
                round(v, 8) if v is not None else None
                for v in self.values
            ],
        }

    @staticmethod
    def from_dict(d: dict) -> "SituationFeatureVector":
        raw = d.get("values", [])
        values = []
        for v in raw:
            if v is None:
                values.append(None)
            else:
                try:
                    f = float(v)
                    values.append(f if math.isfinite(f) else None)
                except (TypeError, ValueError):
                    values.append(None)
        # Pad / truncate to VECTOR_DIM
        values = (values + [None] * VECTOR_DIM)[:VECTOR_DIM]
        return SituationFeatureVector(
            values=values,
            normalizer_version=int(d.get("normalizer_version", NORMALIZER_VERSION)),
            object_type=str(d.get("object_type", "")),
        )


# ---------------------------------------------------------------------------
# Ordinal mappings (deterministic — never random)
# ---------------------------------------------------------------------------

_ROAD_TYPE_ORD: dict = {
    RoadTypeClass.HIGHWAY: 1.0,
    RoadTypeClass.ARTERIAL: 0.75,
    RoadTypeClass.LOCAL: 0.5,
    RoadTypeClass.RURAL: 0.25,
    RoadTypeClass.UNPAVED: 0.0,
    RoadTypeClass.UNKNOWN: None,
}

_TRAFFIC_ORD: dict = {
    TrafficDensityClass.EMPTY: 0.0,
    TrafficDensityClass.LIGHT: 0.25,
    TrafficDensityClass.MODERATE: 0.5,
    TrafficDensityClass.DENSE: 0.75,
    TrafficDensityClass.GRIDLOCK: 1.0,
    TrafficDensityClass.UNKNOWN: None,
}

_MARKING_ORD: dict = {
    RoadMarkingClass.NONE: 0.0,
    RoadMarkingClass.FADED: 0.5,
    RoadMarkingClass.CLEAR: 1.0,
    RoadMarkingClass.UNKNOWN: None,
}

_DAMAGE_ORD: dict = {
    RoadDamageClass.NONE: 0.0,
    RoadDamageClass.MINOR: 0.33,
    RoadDamageClass.MODERATE: 0.67,
    RoadDamageClass.SEVERE: 1.0,
    RoadDamageClass.UNKNOWN: None,
}

_INTERSECTION_ORD: dict = {
    IntersectionClass.STRAIGHT: 0.0,
    IntersectionClass.CURVE: 0.25,
    IntersectionClass.T_JUNCTION: 0.6,
    IntersectionClass.CROSSROADS: 0.8,
    IntersectionClass.ROUNDABOUT: 1.0,
    IntersectionClass.UNKNOWN: None,
}

_RISK_ORD: dict = {
    RiskLevelClass.NONE: 0.0,
    RiskLevelClass.LOW: 0.25,
    RiskLevelClass.MEDIUM: 0.5,
    RiskLevelClass.HIGH: 0.75,
    RiskLevelClass.CRITICAL: 1.0,
    RiskLevelClass.UNKNOWN: None,
}

_TTC_ORD: dict = {
    TtcBandClass.NOT_THREAT: 0.0,
    TtcBandClass.FAR: 0.25,
    TtcBandClass.MODERATE: 0.5,
    TtcBandClass.NEAR: 0.75,
    TtcBandClass.IMMEDIATE: 1.0,
    TtcBandClass.UNKNOWN: None,
}

_MOTION_CLASS_ORD: dict = {
    MotionClass.STATIONARY: 0.0,
    MotionClass.SLOW: 0.2,
    MotionClass.CROSSING: 0.4,
    MotionClass.TURNING: 0.5,
    MotionClass.NORMAL: 0.6,
    MotionClass.APPROACHING: 0.8,
    MotionClass.FAST: 1.0,
    MotionClass.UNKNOWN: None,
}


# ---------------------------------------------------------------------------
# FeatureNormalizer
# ---------------------------------------------------------------------------

class FeatureNormalizer:
    """Deterministic, stateless feature normalizer.

    Converts ObjectFeatureSet + ContextFeature + RiskFeature into a
    fixed-length SituationFeatureVector in [0, 1] per slot.

    Thread-safe: no shared mutable state.

    Parameters
    ----------
    config:
        NormalizerConfig with reference ranges.  If None, uses defaults.
    """

    def __init__(self, config: Optional[NormalizerConfig] = None) -> None:
        self._cfg = config or NormalizerConfig()

    @property
    def config(self) -> NormalizerConfig:
        return self._cfg

    def normalize(
        self,
        feature_set: Optional[ObjectFeatureSet],
        context: Optional[ContextFeature],
        risk: Optional[RiskFeature],
    ) -> SituationFeatureVector:
        """Build a SituationFeatureVector from the three feature groups.

        Any group can be None; its slots will be None in the output.
        NaN / Inf values are treated as missing (None in output) — they
        are never propagated into the vector.

        Returns a SituationFeatureVector. Never raises.
        """
        v: List[Optional[float]] = [None] * VECTOR_DIM
        cfg = self._cfg

        # --- Geometry (indices 0-3) ---
        if feature_set is not None and feature_set.geometry is not None:
            geo = feature_set.geometry
            v[0] = self._norm(geo.length, 0.0, cfg.max_length_m)
            v[1] = self._norm(geo.width, 0.0, cfg.max_width_m)
            v[2] = self._norm(geo.height, 0.0, cfg.max_height_m)
            v[3] = self._norm(geo.aspect_ratio, 0.0, cfg.max_aspect_ratio)

        # --- Motion (indices 4-7) ---
        if feature_set is not None and feature_set.motion is not None:
            mot = feature_set.motion
            v[4] = self._norm(mot.typical_speed_ms, 0.0, cfg.max_speed_ms)
            v[5] = self._heading_norm(mot.heading_rad)
            v[6] = self._accel_norm(mot.acceleration_tendency_ms2, cfg.max_accel_ms2)
            v[7] = _MOTION_CLASS_ORD.get(mot.motion_class)

        # --- Context (indices 8-16) ---
        if context is not None:
            v[8]  = _ROAD_TYPE_ORD.get(context.road_type)
            v[9]  = _TRAFFIC_ORD.get(context.traffic_density)
            v[10] = _MARKING_ORD.get(context.road_marking)
            v[11] = _DAMAGE_ORD.get(context.road_damage)
            v[12] = _INTERSECTION_ORD.get(context.intersection_context)
            v[13] = self._norm(context.road_width_m, 0.0, cfg.max_road_width_m)
            v[14] = self._norm_int(context.object_count, 0, cfg.max_object_count)
            v[15] = 1.0 if context.mixed_traffic else 0.0
            v[16] = 1.0 if context.animal_present else 0.0

        # --- Risk (indices 17-22) ---
        if risk is not None:
            v[17] = _RISK_ORD.get(risk.overall_risk)
            v[18] = _RISK_ORD.get(risk.object_risk)
            v[19] = _TTC_ORD.get(risk.ttc_band)
            v[20] = self._clamp_unit(risk.collision_likelihood)
            # Closing speed: 0 → moving away, 0.5 → stationary, 1.0 → max approach
            v[21] = self._closing_speed_norm(risk.closing_speed_ms, cfg.max_closing_speed_ms)
            # Distance: invert so closer = higher value
            v[22] = self._distance_norm(risk.distance_m, cfg.max_distance_m)

        obj_type = (feature_set.object_type if feature_set is not None else "")

        return SituationFeatureVector(
            values=v,
            normalizer_version=NORMALIZER_VERSION,
            object_type=obj_type,
        )

    # -----------------------------------------------------------------------
    # Internal helpers — all return Optional[float] in [0.0, 1.0] or None
    # -----------------------------------------------------------------------

    @staticmethod
    def _clamp_unit(v: Optional[float]) -> Optional[float]:
        if v is None or not _finite(v):
            return None
        return max(0.0, min(1.0, v))

    @staticmethod
    def _norm(v: Optional[float], lo: float, hi: float) -> Optional[float]:
        """Linear normalisation to [0, 1]. Returns None for missing/non-finite."""
        if v is None or not _finite(v):
            return None
        if hi <= lo:
            return None
        return max(0.0, min(1.0, (v - lo) / (hi - lo)))

    @staticmethod
    def _norm_int(v: Optional[int], lo: int, hi: int) -> Optional[float]:
        if v is None:
            return None
        if not isinstance(v, int):
            return None
        if hi <= lo:
            return None
        return max(0.0, min(1.0, (v - lo) / (hi - lo)))

    @staticmethod
    def _heading_norm(heading_rad: Optional[float]) -> Optional[float]:
        """Circular heading [−π, π] → [0, 1] (0 = North, 0.5 = South)."""
        if heading_rad is None or not _finite(heading_rad):
            return None
        # Map to [0, 2π] then normalise to [0, 1]
        h = heading_rad % (2.0 * math.pi)
        return h / (2.0 * math.pi)

    @staticmethod
    def _accel_norm(accel: Optional[float], max_accel: float) -> Optional[float]:
        """Signed acceleration → [0, 1] (0.5 = zero accel)."""
        if accel is None or not _finite(accel):
            return None
        clamped = max(-max_accel, min(max_accel, accel))
        return (clamped + max_accel) / (2.0 * max_accel)

    @staticmethod
    def _closing_speed_norm(closing_ms: Optional[float], max_cs: float) -> Optional[float]:
        """Signed closing speed → [0, 1]:
        Negative (receding) → < 0.5, zero → 0.5, positive (approaching) → > 0.5.
        """
        if closing_ms is None or not _finite(closing_ms):
            return None
        clamped = max(-max_cs, min(max_cs, closing_ms))
        return (clamped + max_cs) / (2.0 * max_cs)

    @staticmethod
    def _distance_norm(dist: Optional[float], max_d: float) -> Optional[float]:
        """Distance → [0, 1] inverted: close = 1.0, far = 0.0."""
        if dist is None or not _finite(dist) or dist < 0.0:
            return None
        clamped = min(dist, max_d)
        return 1.0 - (clamped / max_d)
