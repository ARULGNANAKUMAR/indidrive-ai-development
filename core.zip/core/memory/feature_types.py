"""
IndiDrive AI — Phase 5.2 | Feature / Prototype Memory: Feature Contracts
==========================================================================
Compact, structured object-feature representation that sits between the
Phase 5.1 Object Memory Core and future retrieval/reasoning phases.

    Raw Sensor Data → Perception → Fusion → Object characteristics
        → Compact Feature Representation → Object Prototype Memory (5.2)
        → Experience Retrieval (5.3, future)

This module deliberately stores NONE of the following:
  * raw camera frames / RGB images
  * raw LiDAR point clouds
  * full video
  * large learned embedding tensors

Only small, bounded, structured descriptors derived from values the
upstream pipeline has already computed. Nothing here fabricates a
value: every optional field is `None` unless a real observation
supplied it.

Follows the exact design philosophy of Phase 5.1 (core/memory/memory_types.py):
dataclasses, explicit sentinel-free optionals, deterministic to_dict(),
schema versioning, and no reasoning/retrieval/learning.

Phase boundary: Phase 5.2 only. No top-K search, no nearest-neighbour
database, no learned embeddings, no experience retrieval — see
feature_distance() docstring for the one narrow exception permitted
(a single pairwise distance primitive for a future phase to consume).
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from enum import Enum
from typing import List, Optional

from core.perception.perception_types import NOT_AVAILABLE
from .memory_types import MemoryOperationResult

__all__ = [
    "FEATURE_SCHEMA_VERSION",
    "MotionClass",
    "GeometryFeature",
    "ShapeFeature",
    "AppearanceFeature",
    "MotionFeature",
    "ObjectFeatureSet",
    "validate_feature_set",
    "feature_distance",
    "DEFAULT_MAX_DESCRIPTOR_DIM",
]

# Increment when the serialised feature schema changes in a breaking way.
FEATURE_SCHEMA_VERSION: int = 1

# Bounded default cap for descriptor-style vectors (shape / appearance).
# Real value can be overridden via config (feature_memory.max_feature_dimension);
# this is only the hard fallback used when nothing else is supplied.
DEFAULT_MAX_DESCRIPTOR_DIM: int = 64


class MotionClass(str, Enum):
    """Coarse, deterministic motion bucket. Not a replacement for the
    Phase 4 prediction/behaviour engine — a compact reusable summary."""
    STATIONARY = "STATIONARY"
    SLOW = "SLOW"
    NORMAL = "NORMAL"
    FAST = "FAST"
    APPROACHING = "APPROACHING"
    CROSSING = "CROSSING"
    TURNING = "TURNING"
    UNKNOWN = "UNKNOWN"


# ---------------------------------------------------------------------------
# Small numeric helpers (shared by is_valid()/to_dict() below)
# ---------------------------------------------------------------------------

def _finite(v) -> bool:
    return isinstance(v, (int, float)) and not isinstance(v, bool) and math.isfinite(v)


def _finite_or_none(v) -> bool:
    return v is None or _finite(v)


def _finite_nonneg_or_none(v) -> bool:
    return v is None or (_finite(v) and v >= 0.0)


def _valid_descriptor(v, max_dim: int) -> bool:
    """A descriptor is either None/empty, or a bounded list of finite floats."""
    if v is None:
        return True
    if not isinstance(v, (list, tuple)):
        return False
    if len(v) > max_dim:
        return False
    for x in v:
        if not _finite(x):
            return False
    return True


def _opt_float(v):
    return float(v) if v not in (None, NOT_AVAILABLE) else None


def _dict_or_na(v) -> object:
    return v if v is not None else NOT_AVAILABLE


# ---------------------------------------------------------------------------
# Geometry feature
# ---------------------------------------------------------------------------

@dataclass
class GeometryFeature:
    """Compact bounding-box geometry. Physical values keep SI units
    (metres); `aspect_ratio` is an explicit position-independent
    descriptor computed from those values — never fabricated."""
    length: Optional[float] = None   # metres
    width: Optional[float] = None    # metres
    height: Optional[float] = None   # metres
    aspect_ratio: Optional[float] = None  # length / width, unitless descriptor

    def is_valid(self) -> bool:
        for v in (self.length, self.width, self.height):
            if not _finite_nonneg_or_none(v):
                return False
        if not _finite_nonneg_or_none(self.aspect_ratio):
            return False
        return True

    def to_dict(self) -> dict:
        return {
            "length": _dict_or_na(self.length),
            "width": _dict_or_na(self.width),
            "height": _dict_or_na(self.height),
            "aspect_ratio": _dict_or_na(self.aspect_ratio),
        }

    @staticmethod
    def from_dict(d: dict) -> "GeometryFeature":
        return GeometryFeature(
            length=_opt_float(d.get("length")),
            width=_opt_float(d.get("width")),
            height=_opt_float(d.get("height")),
            aspect_ratio=_opt_float(d.get("aspect_ratio")),
        )

    @staticmethod
    def derive(length: Optional[float], width: Optional[float],
               height: Optional[float] = None) -> "GeometryFeature":
        """Build a GeometryFeature from raw dimensions, computing the
        aspect_ratio descriptor only when both length and width are
        real (never fabricated when either is missing/zero)."""
        ratio = None
        if length is not None and width is not None and width > 0:
            ratio = length / width
        return GeometryFeature(length=length, width=width, height=height, aspect_ratio=ratio)


# ---------------------------------------------------------------------------
# Shape feature
# ---------------------------------------------------------------------------

@dataclass
class ShapeFeature:
    """Compact shape descriptor. `descriptor` is an optional bounded
    vector of normalized ratios/summary values — never a raw contour,
    mask, or image. Extensible: if the perception stack does not
    currently supply shape descriptors, leave `descriptor` empty
    rather than fabricating one."""
    aspect_ratio: Optional[float] = None
    descriptor: List[float] = field(default_factory=list)

    def is_valid(self, max_dim: int = DEFAULT_MAX_DESCRIPTOR_DIM) -> bool:
        if not _finite_nonneg_or_none(self.aspect_ratio):
            return False
        if not _valid_descriptor(self.descriptor, max_dim):
            return False
        return True

    def to_dict(self) -> dict:
        return {
            "aspect_ratio": _dict_or_na(self.aspect_ratio),
            "descriptor": list(self.descriptor) if self.descriptor else [],
        }

    @staticmethod
    def from_dict(d: dict) -> "ShapeFeature":
        raw_desc = d.get("descriptor", [])
        desc = [float(x) for x in raw_desc] if isinstance(raw_desc, (list, tuple)) else []
        return ShapeFeature(aspect_ratio=_opt_float(d.get("aspect_ratio")), descriptor=desc)


# ---------------------------------------------------------------------------
# Appearance feature
# ---------------------------------------------------------------------------

@dataclass
class AppearanceFeature:
    """Lightweight, optional appearance characteristics.

    `dominant_color` is a short string label (e.g. "white"), never
    pixel data. `color_histogram` / `descriptor` are small bounded
    vectors summarising appearance — not raw images, not full-frame
    tensors. If the perception stack does not provide appearance
    information, leave every field None/empty; do not invent values.
    """
    dominant_color: Optional[str] = None
    color_histogram: List[float] = field(default_factory=list)
    descriptor: List[float] = field(default_factory=list)

    def is_valid(self, max_dim: int = DEFAULT_MAX_DESCRIPTOR_DIM) -> bool:
        if self.dominant_color is not None and not isinstance(self.dominant_color, str):
            return False
        if not _valid_descriptor(self.color_histogram, max_dim):
            return False
        if not _valid_descriptor(self.descriptor, max_dim):
            return False
        return True

    def to_dict(self) -> dict:
        return {
            "dominant_color": _dict_or_na(self.dominant_color),
            "color_histogram": list(self.color_histogram) if self.color_histogram else [],
            "descriptor": list(self.descriptor) if self.descriptor else [],
        }

    @staticmethod
    def from_dict(d: dict) -> "AppearanceFeature":
        def _vec(key):
            raw = d.get(key, [])
            return [float(x) for x in raw] if isinstance(raw, (list, tuple)) else []

        color = d.get("dominant_color")
        return AppearanceFeature(
            dominant_color=color if (isinstance(color, str) and color != NOT_AVAILABLE) else None,
            color_histogram=_vec("color_histogram"),
            descriptor=_vec("descriptor"),
        )


# ---------------------------------------------------------------------------
# Motion feature
# ---------------------------------------------------------------------------

@dataclass
class MotionFeature:
    """Compact motion characteristics reduced from Phase 4 prediction
    output. This does NOT replace or recompute Phase 4 prediction —
    it only stores a reusable summary for memory purposes."""
    typical_speed_ms: Optional[float] = None   # metres/second
    speed_min_ms: Optional[float] = None
    speed_max_ms: Optional[float] = None
    heading_rad: Optional[float] = None
    acceleration_tendency_ms2: Optional[float] = None  # signed mean, m/s^2
    turning_tendency: Optional[float] = None            # unitless magnitude, >= 0
    lateral_movement_tendency: Optional[float] = None   # unitless magnitude, >= 0
    motion_class: MotionClass = MotionClass.UNKNOWN

    def is_valid(self) -> bool:
        if not _finite_nonneg_or_none(self.typical_speed_ms):
            return False
        if not _finite_nonneg_or_none(self.speed_min_ms):
            return False
        if not _finite_nonneg_or_none(self.speed_max_ms):
            return False
        if (self.speed_min_ms is not None and self.speed_max_ms is not None
                and self.speed_min_ms > self.speed_max_ms):
            return False
        if not _finite_or_none(self.heading_rad):
            return False
        if not _finite_or_none(self.acceleration_tendency_ms2):
            return False
        if not _finite_nonneg_or_none(self.turning_tendency):
            return False
        if not _finite_nonneg_or_none(self.lateral_movement_tendency):
            return False
        if not isinstance(self.motion_class, MotionClass):
            return False
        return True

    def to_dict(self) -> dict:
        return {
            "typical_speed_ms": _dict_or_na(self.typical_speed_ms),
            "speed_min_ms": _dict_or_na(self.speed_min_ms),
            "speed_max_ms": _dict_or_na(self.speed_max_ms),
            "heading_rad": _dict_or_na(self.heading_rad),
            "acceleration_tendency_ms2": _dict_or_na(self.acceleration_tendency_ms2),
            "turning_tendency": _dict_or_na(self.turning_tendency),
            "lateral_movement_tendency": _dict_or_na(self.lateral_movement_tendency),
            "motion_class": self.motion_class.value,
        }

    @staticmethod
    def from_dict(d: dict) -> "MotionFeature":
        raw_class = d.get("motion_class", MotionClass.UNKNOWN.value)
        try:
            mclass = MotionClass(raw_class)
        except ValueError:
            mclass = MotionClass.UNKNOWN
        return MotionFeature(
            typical_speed_ms=_opt_float(d.get("typical_speed_ms")),
            speed_min_ms=_opt_float(d.get("speed_min_ms")),
            speed_max_ms=_opt_float(d.get("speed_max_ms")),
            heading_rad=_opt_float(d.get("heading_rad")),
            acceleration_tendency_ms2=_opt_float(d.get("acceleration_tendency_ms2")),
            turning_tendency=_opt_float(d.get("turning_tendency")),
            lateral_movement_tendency=_opt_float(d.get("lateral_movement_tendency")),
            motion_class=mclass,
        )


# ---------------------------------------------------------------------------
# Composite feature set
# ---------------------------------------------------------------------------

@dataclass
class ObjectFeatureSet:
    """Compact structured feature representation of one observation of
    an object. This is what gets folded into an ObjectPrototype — it is
    NOT itself persisted as a growing history; callers use it once per
    observation to update a prototype (see prototype_types.py)."""
    object_type: str = NOT_AVAILABLE
    semantic_category: Optional[str] = None
    subtype: Optional[str] = None

    geometry: Optional[GeometryFeature] = None
    shape: Optional[ShapeFeature] = None
    appearance: Optional[AppearanceFeature] = None
    motion: Optional[MotionFeature] = None

    confidence: float = 0.0

    feature_schema_version: int = FEATURE_SCHEMA_VERSION

    def to_dict(self) -> dict:
        return {
            "feature_schema_version": self.feature_schema_version,
            "object_type": self.object_type,
            "semantic_category": _dict_or_na(self.semantic_category),
            "subtype": _dict_or_na(self.subtype),
            "geometry": self.geometry.to_dict() if self.geometry else NOT_AVAILABLE,
            "shape": self.shape.to_dict() if self.shape else NOT_AVAILABLE,
            "appearance": self.appearance.to_dict() if self.appearance else NOT_AVAILABLE,
            "motion": self.motion.to_dict() if self.motion else NOT_AVAILABLE,
            "confidence": round(self.confidence, 6),
        }

    def to_json(self) -> str:
        import json
        return json.dumps(self.to_dict(), sort_keys=True)

    @staticmethod
    def from_dict(d: dict) -> "ObjectFeatureSet":
        def _opt_str(v):
            return v if (isinstance(v, str) and v != NOT_AVAILABLE) else None

        def _geo(v):
            return GeometryFeature.from_dict(v) if isinstance(v, dict) else None

        def _shp(v):
            return ShapeFeature.from_dict(v) if isinstance(v, dict) else None

        def _app(v):
            return AppearanceFeature.from_dict(v) if isinstance(v, dict) else None

        def _mot(v):
            return MotionFeature.from_dict(v) if isinstance(v, dict) else None

        return ObjectFeatureSet(
            object_type=d.get("object_type", NOT_AVAILABLE),
            semantic_category=_opt_str(d.get("semantic_category")),
            subtype=_opt_str(d.get("subtype")),
            geometry=_geo(d.get("geometry")),
            shape=_shp(d.get("shape")),
            appearance=_app(d.get("appearance")),
            motion=_mot(d.get("motion")),
            confidence=float(d.get("confidence", 0.0)),
            feature_schema_version=int(d.get("feature_schema_version", FEATURE_SCHEMA_VERSION)),
        )

    @staticmethod
    def from_json(s: str) -> "ObjectFeatureSet":
        import json
        try:
            d = json.loads(s)
        except json.JSONDecodeError as e:
            raise ValueError(f"Invalid JSON: {e}") from e
        return ObjectFeatureSet.from_dict(d)


# ---------------------------------------------------------------------------
# Validation
# ---------------------------------------------------------------------------

def validate_feature_set(
    fs: ObjectFeatureSet, max_descriptor_dim: int = DEFAULT_MAX_DESCRIPTOR_DIM
) -> MemoryOperationResult:
    """Validate an ObjectFeatureSet before it is folded into a prototype.

    Deterministic: same input -> same verdict. Never raises; returns a
    MemoryOperationResult (reusing the Phase 5.1 result type) so callers
    can log and skip malformed features without crashing the pipeline.
    """
    if not isinstance(fs.object_type, str) or fs.object_type.strip() in ("", NOT_AVAILABLE):
        return MemoryOperationResult.failure("object_type is missing or NOT_AVAILABLE")

    if not (_finite(fs.confidence) and 0.0 <= fs.confidence <= 1.0):
        return MemoryOperationResult.failure(
            f"confidence={fs.confidence!r} is not in [0.0, 1.0] or is NaN/Inf"
        )

    if fs.geometry is not None and not fs.geometry.is_valid():
        return MemoryOperationResult.failure("geometry contains NaN, Inf, or negative values")

    if fs.shape is not None and not fs.shape.is_valid(max_descriptor_dim):
        return MemoryOperationResult.failure(
            "shape descriptor is invalid, malformed, or exceeds max_feature_dimension"
        )

    if fs.appearance is not None and not fs.appearance.is_valid(max_descriptor_dim):
        return MemoryOperationResult.failure(
            "appearance descriptor is invalid, malformed, or exceeds max_feature_dimension"
        )

    if fs.motion is not None and not fs.motion.is_valid():
        return MemoryOperationResult.failure(
            "motion contains NaN, Inf, invalid speed range, or invalid motion_class"
        )

    return MemoryOperationResult(ok=True)


# ---------------------------------------------------------------------------
# Feature distance — a single narrow primitive, not retrieval (Phase 5.3)
# ---------------------------------------------------------------------------
#
# This function computes ONE deterministic, bounded pairwise distance
# between two feature sets. It does NOT implement top-K search, a
# nearest-neighbour database, or any retrieval/decision logic — those
# are explicitly out of scope for Phase 5.2 and belong to Phase 5.3.

def _scalar_distance(a: Optional[float], b: Optional[float]) -> Optional[float]:
    """Bounded relative distance in [0, 1], or None if not comparable."""
    if a is None or b is None or not _finite(a) or not _finite(b):
        return None
    denom = max(abs(a), abs(b), 1e-6)
    return min(1.0, abs(a - b) / denom)


def _heading_distance(a: Optional[float], b: Optional[float]) -> Optional[float]:
    """Circular distance for radians, normalised to [0, 1]."""
    if a is None or b is None or not _finite(a) or not _finite(b):
        return None
    diff = abs(a - b) % (2.0 * math.pi)
    if diff > math.pi:
        diff = 2.0 * math.pi - diff
    return diff / math.pi


def _vector_distance(a, b) -> Optional[float]:
    """Elementwise bounded distance over the overlapping prefix of two
    vectors, or None if either is empty/unusable."""
    if not a or not b:
        return None
    n = min(len(a), len(b))
    diffs = []
    for i in range(n):
        x, y = a[i], b[i]
        if not (_finite(x) and _finite(y)):
            continue
        diffs.append(min(1.0, abs(x - y)))
    if not diffs:
        return None
    return sum(diffs) / len(diffs)


def _label_distance(a: Optional[str], b: Optional[str]) -> Optional[float]:
    if a is None or b is None:
        return None
    return 0.0 if a == b else 1.0


def feature_distance(a: ObjectFeatureSet, b: ObjectFeatureSet) -> float:
    """Deterministic, bounded [0.0, 1.0] pairwise distance between two
    feature sets.

    Semantics:
      * 0.0  = identical on every comparable component
      * 1.0  = maximally different, or nothing was comparable
      * Missing components on either side are skipped, not fabricated
      * NaN/Inf inputs are treated as missing (skipped), never propagated

    Component distances (geometry, shape, appearance, motion) are each
    averaged internally, then averaged across the components that were
    actually comparable. This is a plain mathematical primitive for a
    future phase to build retrieval on top of — it performs no lookup,
    ranking, or decision-making itself.
    """
    components: List[float] = []

    # --- geometry -----------------------------------------------------
    if a.geometry is not None and b.geometry is not None:
        parts = [
            _scalar_distance(a.geometry.length, b.geometry.length),
            _scalar_distance(a.geometry.width, b.geometry.width),
            _scalar_distance(a.geometry.height, b.geometry.height),
        ]
        parts = [p for p in parts if p is not None]
        if parts:
            components.append(sum(parts) / len(parts))

    # --- shape ----------------------------------------------------------
    if a.shape is not None and b.shape is not None:
        parts = [
            _scalar_distance(a.shape.aspect_ratio, b.shape.aspect_ratio),
            _vector_distance(a.shape.descriptor, b.shape.descriptor),
        ]
        parts = [p for p in parts if p is not None]
        if parts:
            components.append(sum(parts) / len(parts))

    # --- appearance -------------------------------------------------------
    if a.appearance is not None and b.appearance is not None:
        parts = [
            _label_distance(a.appearance.dominant_color, b.appearance.dominant_color),
            _vector_distance(a.appearance.color_histogram, b.appearance.color_histogram),
            _vector_distance(a.appearance.descriptor, b.appearance.descriptor),
        ]
        parts = [p for p in parts if p is not None]
        if parts:
            components.append(sum(parts) / len(parts))

    # --- motion -----------------------------------------------------------
    if a.motion is not None and b.motion is not None:
        parts = [
            _scalar_distance(a.motion.typical_speed_ms, b.motion.typical_speed_ms),
            _heading_distance(a.motion.heading_rad, b.motion.heading_rad),
            (0.0 if a.motion.motion_class == b.motion.motion_class else 1.0)
            if (a.motion.motion_class != MotionClass.UNKNOWN
                and b.motion.motion_class != MotionClass.UNKNOWN)
            else None,
        ]
        parts = [p for p in parts if p is not None]
        if parts:
            components.append(sum(parts) / len(parts))

    if not components:
        return 1.0

    result = sum(components) / len(components)
    # Defensive clamp — should already be in range given bounded parts.
    if not _finite(result):
        return 1.0
    return max(0.0, min(1.0, result))
