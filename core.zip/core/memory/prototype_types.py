"""
IndiDrive AI — Phase 5.2 | Object Prototype Data Contract
============================================================
An ObjectPrototype is compact, reusable knowledge about a *category*
of object (e.g. "what a motorcycle typically looks like / moves
like"), distinct from an individual tracked object:

    Individual object memory (Phase 5.1 ObjectMemoryEntry)
        -> one specific tracked/observed object (memory_id, track_id)

    Object prototype (Phase 5.2 ObjectPrototype)
        -> general compact characteristics shared by a class of object
           (prototype_key, e.g. "MOTORCYCLE")

A prototype is updated incrementally from each new ObjectFeatureSet
observation using deterministic running statistics (arithmetic mean
via Welford's incremental-mean update). It never stores the full
observation history — only bounded summary statistics.

Phase boundary: Phase 5.2 only. No clustering, no nearest-neighbour
search, no learned embeddings.
"""
from __future__ import annotations

import math
import time
from dataclasses import dataclass, field
from typing import Optional

from core.perception.perception_types import NOT_AVAILABLE

from .feature_types import (
    ObjectFeatureSet,
    GeometryFeature,
    ShapeFeature,
    AppearanceFeature,
    MotionFeature,
    MotionClass,
)

__all__ = [
    "PROTOTYPE_SCHEMA_VERSION",
    "ObjectPrototype",
    "prototype_key_for",
    "update_prototype",
]

# Increment when the serialised prototype schema changes in a breaking way.
PROTOTYPE_SCHEMA_VERSION: int = 1


def _finite(v) -> bool:
    return isinstance(v, (int, float)) and not isinstance(v, bool) and math.isfinite(v)


def _dict_or_na(v):
    return v if v is not None else NOT_AVAILABLE


def _opt_float(v):
    return float(v) if v not in (None, NOT_AVAILABLE) else None


# ---------------------------------------------------------------------------
# Identity
# ---------------------------------------------------------------------------

def prototype_key_for(object_type: str, subtype: Optional[str] = None) -> str:
    """Deterministic prototype identity — NOT a random ID.

    Same (object_type, subtype) always yields the same key so repeated
    observations of the same category accumulate into one prototype.
    """
    base = (object_type or NOT_AVAILABLE).strip().upper() or NOT_AVAILABLE
    if subtype:
        sub = subtype.strip().upper()
        if sub:
            return f"{base}::{sub}"
    return base


# ---------------------------------------------------------------------------
# Prototype
# ---------------------------------------------------------------------------

@dataclass
class ObjectPrototype:
    """Compact, reusable characteristics of an object category.

    Geometry/shape/appearance/motion fields hold *running mean*
    representations built up from every folded-in observation — not a
    snapshot of the most recent observation (with the deliberate
    exception of `motion_class`, `dominant_color`, and descriptor
    vectors, which are categorical/positional rather than continuous
    and are simply carried forward from the latest informative
    observation; see update_prototype()).
    """
    prototype_key: str
    object_type: str = NOT_AVAILABLE
    subtype: Optional[str] = None
    semantic_category: Optional[str] = None

    geometry: Optional[GeometryFeature] = None
    shape: Optional[ShapeFeature] = None
    appearance: Optional[AppearanceFeature] = None
    motion: Optional[MotionFeature] = None

    # --- observation statistics ---
    observation_count: int = 0
    first_seen: Optional[float] = None
    last_seen: Optional[float] = None

    confidence: float = 0.0            # running mean confidence
    confidence_min: Optional[float] = None
    confidence_max: Optional[float] = None

    speed_min_ms: Optional[float] = None   # observed speed range (running)
    speed_max_ms: Optional[float] = None

    created_at: float = field(default_factory=time.time)
    updated_at: float = field(default_factory=time.time)

    prototype_schema_version: int = PROTOTYPE_SCHEMA_VERSION
    metadata: dict = field(default_factory=dict)

    # -----------------------------------------------------------------
    def to_dict(self) -> dict:
        return {
            "prototype_schema_version": self.prototype_schema_version,
            "prototype_key": self.prototype_key,
            "object_type": self.object_type,
            "subtype": _dict_or_na(self.subtype),
            "semantic_category": _dict_or_na(self.semantic_category),
            "geometry": self.geometry.to_dict() if self.geometry else NOT_AVAILABLE,
            "shape": self.shape.to_dict() if self.shape else NOT_AVAILABLE,
            "appearance": self.appearance.to_dict() if self.appearance else NOT_AVAILABLE,
            "motion": self.motion.to_dict() if self.motion else NOT_AVAILABLE,
            "observation_count": self.observation_count,
            "first_seen": _dict_or_na(self.first_seen),
            "last_seen": _dict_or_na(self.last_seen),
            "confidence": round(self.confidence, 6),
            "confidence_min": _dict_or_na(self.confidence_min),
            "confidence_max": _dict_or_na(self.confidence_max),
            "speed_min_ms": _dict_or_na(self.speed_min_ms),
            "speed_max_ms": _dict_or_na(self.speed_max_ms),
            "created_at": self.created_at,
            "updated_at": self.updated_at,
            "metadata": self.metadata,
        }

    def to_json(self) -> str:
        import json
        return json.dumps(self.to_dict(), sort_keys=True)

    @staticmethod
    def from_dict(d: dict) -> "ObjectPrototype":
        schema_ver = int(d.get("prototype_schema_version", 0))
        if schema_ver != PROTOTYPE_SCHEMA_VERSION:
            raise ValueError(
                f"Unsupported prototype_schema_version={schema_ver}; "
                f"expected {PROTOTYPE_SCHEMA_VERSION}"
            )
        key = d.get("prototype_key")
        if not key or not isinstance(key, str):
            raise ValueError("prototype_key is missing or not a string")

        def _opt_str(v):
            return v if (isinstance(v, str) and v != NOT_AVAILABLE) else None

        def _geo(v):
            return GeometryFeature.from_dict(v) if isinstance(v, dict) else None

        def _shp(v):
            return ShapeFeature.from_dict(v) if isinstance(v, dict) else None

        def _app(v):
            return AppearanceFeature.from_dict(v) if isinstance(v, dict) else None

        def _mot(v):
            return MotionFeature.from_dict(v) if isinstance(v, dict) else None

        return ObjectPrototype(
            prototype_key=key,
            object_type=d.get("object_type", NOT_AVAILABLE),
            subtype=_opt_str(d.get("subtype")),
            semantic_category=_opt_str(d.get("semantic_category")),
            geometry=_geo(d.get("geometry")),
            shape=_shp(d.get("shape")),
            appearance=_app(d.get("appearance")),
            motion=_mot(d.get("motion")),
            observation_count=int(d.get("observation_count", 0)),
            first_seen=_opt_float(d.get("first_seen")),
            last_seen=_opt_float(d.get("last_seen")),
            confidence=float(d.get("confidence", 0.0)),
            confidence_min=_opt_float(d.get("confidence_min")),
            confidence_max=_opt_float(d.get("confidence_max")),
            speed_min_ms=_opt_float(d.get("speed_min_ms")),
            speed_max_ms=_opt_float(d.get("speed_max_ms")),
            created_at=float(d.get("created_at", 0.0)),
            updated_at=float(d.get("updated_at", 0.0)),
            prototype_schema_version=schema_ver,
            metadata=d.get("metadata", {}),
        )

    @staticmethod
    def from_json(s: str) -> "ObjectPrototype":
        import json
        try:
            d = json.loads(s)
        except json.JSONDecodeError as e:
            raise ValueError(f"Invalid JSON: {e}") from e
        return ObjectPrototype.from_dict(d)


# ---------------------------------------------------------------------------
# Incremental update (Welford-style running mean — deterministic)
# ---------------------------------------------------------------------------

def _mean_update(old_mean: Optional[float], new_value: Optional[float], new_count: int) -> Optional[float]:
    """Deterministic incremental mean. If old_mean is None, adopt new_value
    directly (first real observation of that field). If new_value is
    None, keep old_mean unchanged (this observation didn't supply it)."""
    if new_value is None:
        return old_mean
    if old_mean is None or new_count <= 1:
        return new_value
    return old_mean + (new_value - old_mean) / new_count


def _range_update(old_min, old_max, new_value):
    if new_value is None:
        return old_min, old_max
    new_min = new_value if old_min is None else min(old_min, new_value)
    new_max = new_value if old_max is None else max(old_max, new_value)
    return new_min, new_max


def _updated_geometry(old: Optional[GeometryFeature], obs: Optional[GeometryFeature],
                       new_count: int) -> Optional[GeometryFeature]:
    if obs is None:
        return old
    base = old or GeometryFeature()
    length = _mean_update(base.length, obs.length, new_count)
    width = _mean_update(base.width, obs.width, new_count)
    height = _mean_update(base.height, obs.height, new_count)
    aspect_ratio = _mean_update(base.aspect_ratio, obs.aspect_ratio, new_count)
    return GeometryFeature(length=length, width=width, height=height, aspect_ratio=aspect_ratio)


def _updated_shape(old: Optional[ShapeFeature], obs: Optional[ShapeFeature],
                    new_count: int) -> Optional[ShapeFeature]:
    if obs is None:
        return old
    base = old or ShapeFeature()
    aspect_ratio = _mean_update(base.aspect_ratio, obs.aspect_ratio, new_count)
    # Descriptor vectors are positional summaries, not scalars we can
    # meaningfully average without a fixed schema per index; carry
    # forward the latest non-empty descriptor deterministically.
    descriptor = list(obs.descriptor) if obs.descriptor else list(base.descriptor)
    return ShapeFeature(aspect_ratio=aspect_ratio, descriptor=descriptor)


def _updated_appearance(old: Optional[AppearanceFeature], obs: Optional[AppearanceFeature]
                         ) -> Optional[AppearanceFeature]:
    if obs is None:
        return old
    base = old or AppearanceFeature()
    dominant_color = obs.dominant_color if obs.dominant_color is not None else base.dominant_color
    color_histogram = list(obs.color_histogram) if obs.color_histogram else list(base.color_histogram)
    descriptor = list(obs.descriptor) if obs.descriptor else list(base.descriptor)
    return AppearanceFeature(
        dominant_color=dominant_color, color_histogram=color_histogram, descriptor=descriptor
    )


def _updated_motion(old: Optional[MotionFeature], obs: Optional[MotionFeature],
                     new_count: int) -> Optional[MotionFeature]:
    if obs is None:
        return old
    base = old or MotionFeature()
    typical_speed = _mean_update(base.typical_speed_ms, obs.typical_speed_ms, new_count)
    speed_min, speed_max = _range_update(base.speed_min_ms, base.speed_max_ms, obs.typical_speed_ms)
    # Explicit ranges reported by the observation itself widen the range too.
    speed_min, speed_max = _range_update(speed_min, speed_max, obs.speed_min_ms)
    speed_min, speed_max = _range_update(speed_min, speed_max, obs.speed_max_ms)
    heading = _mean_update(base.heading_rad, obs.heading_rad, new_count)
    accel = _mean_update(base.acceleration_tendency_ms2, obs.acceleration_tendency_ms2, new_count)
    turning = _mean_update(base.turning_tendency, obs.turning_tendency, new_count)
    lateral = _mean_update(base.lateral_movement_tendency, obs.lateral_movement_tendency, new_count)
    # Categorical: carry forward the latest known (non-UNKNOWN) class.
    motion_class = (
        obs.motion_class if obs.motion_class != MotionClass.UNKNOWN else base.motion_class
    )
    return MotionFeature(
        typical_speed_ms=typical_speed,
        speed_min_ms=speed_min,
        speed_max_ms=speed_max,
        heading_rad=heading,
        acceleration_tendency_ms2=accel,
        turning_tendency=turning,
        lateral_movement_tendency=lateral,
        motion_class=motion_class,
    )


def update_prototype(
    prototype: Optional[ObjectPrototype],
    feature: ObjectFeatureSet,
    *,
    prototype_key: Optional[str] = None,
    observed_at: Optional[float] = None,
) -> ObjectPrototype:
    """Fold one new ObjectFeatureSet observation into a prototype.

    Pure function: returns a new ObjectPrototype, never mutates the
    input. If `prototype` is None, creates a fresh prototype from this
    single observation (observation_count becomes 1).

    Uses deterministic incremental (Welford) mean updates — no
    retraining, no full-history recomputation, no randomness.
    """
    now = observed_at if observed_at is not None else time.time()
    key = prototype_key or prototype_key_for(feature.object_type, feature.subtype)

    if prototype is None:
        new_count = 1
        created_at = now
        first_seen = now
        old_conf_min = old_conf_max = None
        base_confidence = None
        base_geometry = base_shape = base_appearance = base_motion = None
        metadata: dict = {}
    else:
        new_count = prototype.observation_count + 1
        created_at = prototype.created_at
        first_seen = prototype.first_seen if prototype.first_seen is not None else now
        old_conf_min = prototype.confidence_min
        old_conf_max = prototype.confidence_max
        base_confidence = prototype.confidence if prototype.observation_count > 0 else None
        base_geometry = prototype.geometry
        base_shape = prototype.shape
        base_appearance = prototype.appearance
        base_motion = prototype.motion
        metadata = dict(prototype.metadata)

    confidence = _mean_update(base_confidence, feature.confidence, new_count)
    if confidence is None:
        confidence = feature.confidence
    conf_min, conf_max = _range_update(old_conf_min, old_conf_max, feature.confidence)

    geometry = _updated_geometry(base_geometry, feature.geometry, new_count)
    shape = _updated_shape(base_shape, feature.shape, new_count)
    appearance = _updated_appearance(base_appearance, feature.appearance)
    motion = _updated_motion(base_motion, feature.motion, new_count)

    speed_min = prototype.speed_min_ms if prototype is not None else None
    speed_max = prototype.speed_max_ms if prototype is not None else None
    if feature.motion is not None:
        speed_min, speed_max = _range_update(speed_min, speed_max, feature.motion.typical_speed_ms)
        speed_min, speed_max = _range_update(speed_min, speed_max, feature.motion.speed_min_ms)
        speed_min, speed_max = _range_update(speed_min, speed_max, feature.motion.speed_max_ms)

    semantic_category = (
        feature.semantic_category
        if feature.semantic_category is not None
        else (prototype.semantic_category if prototype is not None else None)
    )
    subtype = (
        feature.subtype if feature.subtype is not None
        else (prototype.subtype if prototype is not None else None)
    )

    return ObjectPrototype(
        prototype_key=key,
        object_type=feature.object_type,
        subtype=subtype,
        semantic_category=semantic_category,
        geometry=geometry,
        shape=shape,
        appearance=appearance,
        motion=motion,
        observation_count=new_count,
        first_seen=first_seen,
        last_seen=now,
        confidence=confidence,
        confidence_min=conf_min,
        confidence_max=conf_max,
        speed_min_ms=speed_min,
        speed_max_ms=speed_max,
        created_at=created_at,
        updated_at=now,
        metadata=metadata,
    )
