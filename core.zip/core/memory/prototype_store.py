"""
IndiDrive AI — Phase 5.2 | Prototype Store
=============================================
Thread-safe, bounded, offline-first store for ObjectPrototype records,
keyed by the deterministic prototype_key (not the per-object memory_id
used by Phase 5.1's MemoryStore).

Mirrors the exact design of core/memory/memory_store.py: an abstract
interface plus one concrete dict-based, RLock-protected implementation.
Kept as a separate store (not merged into InMemoryStore) because
prototypes are a different keyspace/concept from individual object
memory entries — see prototype_types.py module docstring.

No network, no database, no cloud.
"""
from __future__ import annotations

import abc
import threading
import time
from typing import Dict, List, Optional

from .memory_types import MemoryOperationResult, MemoryCleanupPolicy
from .prototype_types import ObjectPrototype

__all__ = ["PrototypeStore", "InMemoryPrototypeStore"]


# ---------------------------------------------------------------------------
# Abstract interface
# ---------------------------------------------------------------------------

class PrototypeStore(abc.ABC):
    """Abstract interface every concrete prototype store must implement."""

    @abc.abstractmethod
    def add(self, prototype: ObjectPrototype) -> MemoryOperationResult:
        """Store a new prototype. Fails if prototype_key already exists."""

    @abc.abstractmethod
    def get(self, prototype_key: str) -> Optional[ObjectPrototype]:
        """Return the prototype for prototype_key, or None."""

    @abc.abstractmethod
    def put(self, prototype: ObjectPrototype) -> MemoryOperationResult:
        """Insert or replace — used by incremental update, which always
        knows the correct full replacement state ahead of time."""

    @abc.abstractmethod
    def remove(self, prototype_key: str) -> MemoryOperationResult:
        """Delete the prototype for prototype_key."""

    @abc.abstractmethod
    def exists(self, prototype_key: str) -> bool:
        """True iff prototype_key is currently stored."""

    @abc.abstractmethod
    def list_keys(self) -> List[str]:
        """Return all current prototype_keys (stable/sorted order)."""

    @abc.abstractmethod
    def list_prototypes(self) -> List[ObjectPrototype]:
        """Return a snapshot list of all prototypes."""

    @abc.abstractmethod
    def clear(self) -> int:
        """Remove all prototypes. Returns count removed."""

    @abc.abstractmethod
    def cleanup(
        self,
        policy: MemoryCleanupPolicy,
        max_prototypes: int,
        now: Optional[float] = None,
    ) -> int:
        """Evict prototypes to satisfy the capacity constraint.
        Returns number of prototypes removed."""


# ---------------------------------------------------------------------------
# In-memory implementation
# ---------------------------------------------------------------------------

class InMemoryPrototypeStore(PrototypeStore):
    """Thread-safe dict-backed store. All operations take an RLock."""

    def __init__(self) -> None:
        self._lock: threading.RLock = threading.RLock()
        self._data: Dict[str, ObjectPrototype] = {}

    def add(self, prototype: ObjectPrototype) -> MemoryOperationResult:
        with self._lock:
            if prototype.prototype_key in self._data:
                return MemoryOperationResult.failure(
                    f"prototype_key={prototype.prototype_key!r} already exists; use put()",
                    memory_id=prototype.prototype_key,
                )
            self._data[prototype.prototype_key] = prototype
        return MemoryOperationResult.success(prototype.prototype_key)

    def get(self, prototype_key: str) -> Optional[ObjectPrototype]:
        with self._lock:
            return self._data.get(prototype_key)

    def put(self, prototype: ObjectPrototype) -> MemoryOperationResult:
        with self._lock:
            self._data[prototype.prototype_key] = prototype
        return MemoryOperationResult.success(prototype.prototype_key)

    def remove(self, prototype_key: str) -> MemoryOperationResult:
        with self._lock:
            if prototype_key not in self._data:
                return MemoryOperationResult.failure(
                    f"prototype_key={prototype_key!r} not found", memory_id=prototype_key
                )
            del self._data[prototype_key]
        return MemoryOperationResult.success(prototype_key)

    def exists(self, prototype_key: str) -> bool:
        with self._lock:
            return prototype_key in self._data

    def list_keys(self) -> List[str]:
        with self._lock:
            return sorted(self._data.keys())

    def list_prototypes(self) -> List[ObjectPrototype]:
        with self._lock:
            return list(self._data.values())

    def clear(self) -> int:
        with self._lock:
            n = len(self._data)
            self._data.clear()
        return n

    def cleanup(
        self,
        policy: MemoryCleanupPolicy,
        max_prototypes: int,
        now: Optional[float] = None,
    ) -> int:
        """Deterministic eviction to satisfy max_prototypes.

        Reuses the same MemoryCleanupPolicy enum as Phase 5.1 for a
        consistent mental model, adapted to prototype fields
        (created_at / confidence — prototypes have no lifecycle
        state, so STALE_FIRST degrades to OLDEST_FIRST).
        """
        if now is None:
            now = time.time()
        removed = 0
        with self._lock:
            overflow = len(self._data) - max_prototypes
            if overflow <= 0:
                return 0

            candidates = list(self._data.values())
            if policy == MemoryCleanupPolicy.LOWEST_CONFIDENCE:
                candidates.sort(key=lambda p: (p.confidence, p.created_at))
            else:
                # OLDEST_FIRST and STALE_FIRST (no lifecycle concept here)
                # both fall back to oldest-first eviction, deterministically.
                candidates.sort(key=lambda p: p.created_at)

            to_evict = candidates[:overflow]
            for proto in to_evict:
                if proto.prototype_key in self._data:
                    del self._data[proto.prototype_key]
                    removed += 1
        return removed
