"""
IndiDrive AI — Phase 5.3A | Situation Similarity Engine
=========================================================
Deterministic, offline-first feature-wise similarity between a
CurrentSituation and an ObjectPrototype (or ObjectFeatureSet).

Pipeline context:

    CurrentSituation  (this phase — situation_types.py)
            ↓
    Feature Normalization  (internal to this module)
            ↓
    Feature-wise Similarity  (per feature group)
            ↓
    Weighted Similarity  (configurable, renormalised over available features)
            ↓
    SimilarityResult  (score + per-component breakdown)

Design guarantees
-----------------
* Deterministic: same inputs → same score, always.
* Offline-first: no PyTorch, no FAISS, no cloud API, no LLM.
* Missing-feature safe: features absent on either side are skipped, not
  penalised as zero.  The weighted sum is renormalised over available
  features so a camera-only observation is not unfairly downgraded
  against a LiDAR+camera observation.
* Circular heading: 359° vs 1° is treated as 2° apart, not 358°.
* Clamped output: 0.0 ≤ score ≤ 1.0.
* Thread-safe: the engine is stateless; it holds no mutable shared state.
* Reuses Phase 5.2 distance primitives where they already exist
  (_scalar_distance, _heading_distance, _vector_distance, _label_distance)
  rather than duplicating logic.

What this module does NOT do (Phase 5.3B and later):
  * top-K retrieval
  * memory searching
  * ranking multiple experiences
  * planning, reasoning, decision-making, control

Score semantics:
  * 1.0 → highly similar / equivalent representation
  * 0.0 → completely dissimilar
  * This is a SIMILARITY score, not a probability, not a confidence,
    not a collision risk.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Dict, Optional, Tuple

from core.perception.perception_types import NOT_AVAILABLE

from .feature_types import (
    GeometryFeature,
    ShapeFeature,
    AppearanceFeature,
    MotionFeature,
    MotionClass,
    ObjectFeatureSet,
    _finite,
    _finite_nonneg_or_none,
)
from .prototype_types import ObjectPrototype
from .situation_types import CurrentSituation

__all__ = [
    "SimilarityWeights",
    "DEFAULT_SIMILARITY_WEIGHTS",
    "SimilarityResult",
    "SimilarityEngine",
    "compute_similarity",
]

# ---------------------------------------------------------------------------
# Unavailability sentinel
# ---------------------------------------------------------------------------

_UNAVAILABLE = "unavailable"


# ---------------------------------------------------------------------------
# Configurable weights
# ---------------------------------------------------------------------------

@dataclass
class SimilarityWeights:
    """Configurable per-feature-group weights for weighted similarity.

    Weights must be non-negative finite numbers; they are automatically
    renormalised at runtime over whichever features are available.
    Setting a weight to 0.0 disables a feature group entirely.

    The absolute magnitudes do not matter — only their ratios.
    """
    object_type: float = 2.0   # higher weight: type mismatch is very penalising
    geometry: float = 1.0
    shape: float = 0.8
    appearance: float = 0.6
    motion: float = 1.2

    def validate(self) -> None:
        """Raise ValueError if any weight is invalid."""
        for name in ("object_type", "geometry", "shape", "appearance", "motion"):
            v = getattr(self, name)
            if not isinstance(v, (int, float)) or isinstance(v, bool):
                raise ValueError(f"weight '{name}' must be a number, got {v!r}")
            if not math.isfinite(v):
                raise ValueError(f"weight '{name}'={v!r} is NaN or Inf")
            if v < 0.0:
                raise ValueError(f"weight '{name}'={v!r} is negative")

    @staticmethod
    def from_dict(d: dict) -> "SimilarityWeights":
        """Build from a config dict (e.g. loaded from similarity_config.yaml)."""
        return SimilarityWeights(
            object_type=float(d.get("object_type", 2.0)),
            geometry=float(d.get("geometry", 1.0)),
            shape=float(d.get("shape", 0.8)),
            appearance=float(d.get("appearance", 0.6)),
            motion=float(d.get("motion", 1.2)),
        )

    def to_dict(self) -> dict:
        return {
            "object_type": self.object_type,
            "geometry": self.geometry,
            "shape": self.shape,
            "appearance": self.appearance,
            "motion": self.motion,
        }


DEFAULT_SIMILARITY_WEIGHTS = SimilarityWeights()


# ---------------------------------------------------------------------------
# Result
# ---------------------------------------------------------------------------

@dataclass
class SimilarityResult:
    """Structured output of one similarity computation.

    ``overall_similarity`` is clamped to [0.0, 1.0].

    ``components`` is a dict mapping feature-group names to either:
      - a float in [0.0, 1.0]  (similarity for that group)
      - the string ``"unavailable"``  (feature absent on at least one side)

    Example:
        overall_similarity: 0.82
        components: {
            "object_type": 1.00,
            "geometry":    0.87,
            "shape":       0.75,
            "appearance":  "unavailable",
            "motion":      0.81,
        }
    """
    overall_similarity: float
    components: Dict[str, object] = field(default_factory=dict)

    def to_dict(self) -> dict:
        return {
            "overall_similarity": round(self.overall_similarity, 6),
            "components": {
                k: (round(v, 6) if isinstance(v, float) else v)
                for k, v in self.components.items()
            },
        }

    def __repr__(self) -> str:
        comps = ", ".join(
            f"{k}={round(v,4) if isinstance(v, float) else v}"
            for k, v in self.components.items()
        )
        return (
            f"SimilarityResult(overall={self.overall_similarity:.4f}, "
            f"components={{{comps}}})"
        )


# ---------------------------------------------------------------------------
# Low-level similarity primitives
# (parallel to Phase 5.2 distance primitives, but returning similarity
#  in [0,1] rather than distance — similarity = 1 - distance)
# ---------------------------------------------------------------------------

def _scalar_sim(a: Optional[float], b: Optional[float]) -> Optional[float]:
    """Bounded relative similarity in [0, 1], or None if not comparable."""
    if a is None or b is None or not _finite(a) or not _finite(b):
        return None
    denom = max(abs(a), abs(b), 1e-6)
    dist = min(1.0, abs(a - b) / denom)
    return 1.0 - dist


def _angular_sim_rad(a: Optional[float], b: Optional[float]) -> Optional[float]:
    """Circular similarity for two angles in radians, in [0, 1].

    Treats 359° and 1° as very close (2° apart → high similarity).
    Treats 0° and 180° as maximally different.
    """
    if a is None or b is None or not _finite(a) or not _finite(b):
        return None
    diff = abs(a - b) % (2.0 * math.pi)
    if diff > math.pi:
        diff = 2.0 * math.pi - diff
    # diff is now in [0, π]; π → distance=1.0 → similarity=0.0
    return 1.0 - (diff / math.pi)


def _vector_sim(a, b) -> Optional[float]:
    """Element-wise similarity over the overlapping prefix of two vectors.

    Each element difference is bounded by 1.0 so that one large outlier
    element cannot dominate the whole vector.  Returns None when either
    vector is empty or there are no finite comparable pairs.
    """
    if not a or not b:
        return None
    n = min(len(a), len(b))
    sims = []
    for i in range(n):
        x, y = a[i], b[i]
        if not (_finite(x) and _finite(y)):
            continue
        # Bounded element similarity
        sims.append(max(0.0, 1.0 - min(1.0, abs(x - y))))
    if not sims:
        return None
    return sum(sims) / len(sims)


def _label_sim(a: Optional[str], b: Optional[str]) -> Optional[float]:
    """1.0 for equal labels, 0.0 for different, None if either is absent."""
    if a is None or b is None:
        return None
    return 1.0 if a == b else 0.0


def _speed_sim(a: Optional[float], b: Optional[float]) -> Optional[float]:
    """Speed similarity using an absolute-difference approach capped at
    a reference maximum speed (30 m/s ≈ 108 km/h) so that two very high
    speeds at similar magnitudes score well without wrapping.

    Falls back to _scalar_sim when both are below the reference."""
    if a is None or b is None or not _finite(a) or not _finite(b):
        return None
    # Use relative distance anchored on the larger of the two or the ref.
    ref = max(abs(a), abs(b), 1.0)   # avoid division by zero
    dist = min(1.0, abs(a - b) / ref)
    return 1.0 - dist


# ---------------------------------------------------------------------------
# Per-feature-group similarity functions
# ---------------------------------------------------------------------------

def _object_type_sim(sit_type: str, ref_type: str) -> Optional[float]:
    """1.0 if types are identical (case-insensitive), 0.0 otherwise.

    Returns None only if either value is NOT_AVAILABLE or empty.  The
    decision NOT to invent partial credit for semantically related types
    (e.g. "car" vs "truck") is deliberate: the prototype already captures
    that relationship via its geometry/motion features; the type label is
    treated as a hard categorical discriminator here.
    """
    a = (sit_type or "").strip().upper()
    b = (ref_type or "").strip().upper()
    if not a or a == NOT_AVAILABLE or not b or b == NOT_AVAILABLE:
        return None
    return 1.0 if a == b else 0.0


def _geometry_sim(
    sit_geo: Optional[GeometryFeature],
    ref_geo: Optional[GeometryFeature],
) -> Optional[float]:
    """Similarity for the geometry feature group."""
    if sit_geo is None or ref_geo is None:
        return None

    parts = [
        _scalar_sim(sit_geo.length, ref_geo.length),
        _scalar_sim(sit_geo.width, ref_geo.width),
        _scalar_sim(sit_geo.height, ref_geo.height),
    ]
    valid = [p for p in parts if p is not None]
    if not valid:
        return None
    return sum(valid) / len(valid)


def _shape_sim(
    sit_shp: Optional[ShapeFeature],
    ref_shp: Optional[ShapeFeature],
) -> Optional[float]:
    """Similarity for the shape feature group."""
    if sit_shp is None or ref_shp is None:
        return None

    parts = [
        _scalar_sim(sit_shp.aspect_ratio, ref_shp.aspect_ratio),
        _vector_sim(sit_shp.descriptor, ref_shp.descriptor),
    ]
    valid = [p for p in parts if p is not None]
    if not valid:
        return None
    return sum(valid) / len(valid)


def _appearance_sim(
    sit_app: Optional[AppearanceFeature],
    ref_app: Optional[AppearanceFeature],
) -> Optional[float]:
    """Similarity for the appearance feature group."""
    if sit_app is None or ref_app is None:
        return None

    parts = [
        _label_sim(sit_app.dominant_color, ref_app.dominant_color),
        _vector_sim(sit_app.color_histogram, ref_app.color_histogram),
        _vector_sim(sit_app.descriptor, ref_app.descriptor),
    ]
    valid = [p for p in parts if p is not None]
    if not valid:
        return None
    return sum(valid) / len(valid)


def _motion_sim(
    sit_mot: Optional[MotionFeature],
    ref_mot: Optional[MotionFeature],
) -> Optional[float]:
    """Similarity for the motion feature group.

    Heading uses circular angular distance so 359° vs 1° scores high.
    Motion class is categorical — matched only when both are non-UNKNOWN.
    """
    if sit_mot is None or ref_mot is None:
        return None

    parts: list = [
        _speed_sim(sit_mot.typical_speed_ms, ref_mot.typical_speed_ms),
        _angular_sim_rad(sit_mot.heading_rad, ref_mot.heading_rad),
    ]

    # Motion class: skip if either is UNKNOWN (avoids fabricating a penalised
    # comparison against a default placeholder).
    if (sit_mot.motion_class != MotionClass.UNKNOWN
            and ref_mot.motion_class != MotionClass.UNKNOWN):
        parts.append(1.0 if sit_mot.motion_class == ref_mot.motion_class else 0.0)

    valid = [p for p in parts if p is not None]
    if not valid:
        return None
    return sum(valid) / len(valid)


# ---------------------------------------------------------------------------
# Weighted aggregation
# ---------------------------------------------------------------------------

def _weighted_aggregate(
    sims: Dict[str, Optional[float]],
    weights: SimilarityWeights,
) -> Tuple[float, Dict[str, object]]:
    """Weighted mean over *available* feature similarities.

    Components whose similarity is None (unavailable) contribute neither
    numerator nor denominator — they are fully excluded so the result is
    not penalised for missing sensor modalities.

    Returns (overall_similarity, component_breakdown_dict).
    """
    weight_map = {
        "object_type": weights.object_type,
        "geometry": weights.geometry,
        "shape": weights.shape,
        "appearance": weights.appearance,
        "motion": weights.motion,
    }

    numerator = 0.0
    denominator = 0.0
    breakdown: Dict[str, object] = {}

    for key in ("object_type", "geometry", "shape", "appearance", "motion"):
        sim = sims.get(key)
        if sim is None:
            breakdown[key] = _UNAVAILABLE
            continue
        # Clamp each component individually (defensive)
        sim_clamped = max(0.0, min(1.0, sim))
        w = weight_map[key]
        numerator += w * sim_clamped
        denominator += w
        breakdown[key] = sim_clamped

    if denominator == 0.0:
        # Nothing was comparable — return 0.0 overall (maximally dissimilar)
        overall = 0.0
    else:
        overall = numerator / denominator

    # Final defensive clamp
    overall = max(0.0, min(1.0, overall))
    if not math.isfinite(overall):
        overall = 0.0

    return overall, breakdown


# ---------------------------------------------------------------------------
# Public engine
# ---------------------------------------------------------------------------

class SimilarityEngine:
    """Stateless similarity engine for Phase 5.3A.

    Compares a CurrentSituation against either an ObjectPrototype (the
    common case) or an ObjectFeatureSet (useful for unit tests and
    one-off comparisons).

    Thread-safe: no shared mutable state.

    Parameters
    ----------
    weights:
        Feature-group weights.  Validated on construction.
    """

    def __init__(self, weights: Optional[SimilarityWeights] = None) -> None:
        self._weights = weights if weights is not None else SimilarityWeights()
        self._weights.validate()

    @property
    def weights(self) -> SimilarityWeights:
        return self._weights

    # ------------------------------------------------------------------
    # Primary API: compare against a stored prototype
    # ------------------------------------------------------------------

    def compare_to_prototype(
        self,
        situation: CurrentSituation,
        prototype: ObjectPrototype,
    ) -> SimilarityResult:
        """Compute similarity between a CurrentSituation and an ObjectPrototype.

        The prototype's aggregated feature fields (geometry, shape, appearance,
        motion) are compared directly against the situation's features; they
        are already in the same Phase 5.2 GeometryFeature / MotionFeature /
        etc. type hierarchy, so no conversion is needed.

        Returns a SimilarityResult with the overall score and per-component
        breakdown.
        """
        sims: Dict[str, Optional[float]] = {
            "object_type": _object_type_sim(situation.object_type, prototype.object_type),
            "geometry": _geometry_sim(situation.geometry, prototype.geometry),
            "shape": _shape_sim(situation.shape, prototype.shape),
            "appearance": _appearance_sim(situation.appearance, prototype.appearance),
            "motion": _motion_sim(situation.motion, prototype.motion),
        }
        overall, breakdown = _weighted_aggregate(sims, self._weights)
        return SimilarityResult(overall_similarity=overall, components=breakdown)

    # ------------------------------------------------------------------
    # Secondary API: compare against a feature set
    # ------------------------------------------------------------------

    def compare_to_feature_set(
        self,
        situation: CurrentSituation,
        feature_set: ObjectFeatureSet,
    ) -> SimilarityResult:
        """Compute similarity between a CurrentSituation and an ObjectFeatureSet.

        Equivalent to compare_to_prototype() but works directly with the
        Phase 5.2 ObjectFeatureSet — useful when a prototype has not yet
        been built from accumulated observations.
        """
        sims: Dict[str, Optional[float]] = {
            "object_type": _object_type_sim(situation.object_type, feature_set.object_type),
            "geometry": _geometry_sim(situation.geometry, feature_set.geometry),
            "shape": _shape_sim(situation.shape, feature_set.shape),
            "appearance": _appearance_sim(situation.appearance, feature_set.appearance),
            "motion": _motion_sim(situation.motion, feature_set.motion),
        }
        overall, breakdown = _weighted_aggregate(sims, self._weights)
        return SimilarityResult(overall_similarity=overall, components=breakdown)


# ---------------------------------------------------------------------------
# Convenience function
# ---------------------------------------------------------------------------

def compute_similarity(
    situation: CurrentSituation,
    prototype: ObjectPrototype,
    weights: Optional[SimilarityWeights] = None,
) -> SimilarityResult:
    """Top-level convenience function — creates a SimilarityEngine and runs
    compare_to_prototype() in one call.

    Suitable for callers that do not need to reuse the engine across
    many comparisons (e.g. unit tests, one-shot scripts).  For
    high-throughput use, prefer constructing a SimilarityEngine once
    and calling compare_to_prototype() in a loop.
    """
    engine = SimilarityEngine(weights=weights)
    return engine.compare_to_prototype(situation, prototype)
