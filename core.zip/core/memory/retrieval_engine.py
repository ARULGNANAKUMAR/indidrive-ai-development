"""
IndiDrive AI — Phase 5.3B | Experience Retrieval Engine
=========================================================
Retrieves the most similar stored experiences for a given CurrentSituation.

Pipeline context:

    CurrentSituation  (Phase 5.3A situation_types.py)
            ↓
    ExperienceRetriever.retrieve()
            ↓
    Candidate scan over ObjectMemory (Phase 5.1)
    + Prototype lookup via PrototypeMemory (Phase 5.2)
            ↓
    Phase 5.3A SimilarityEngine.compare_to_prototype()
            ↓
    Minimum similarity threshold filter
            ↓
    Deterministic ranking (similarity ↓, confidence ↓, memory_id ↑)
            ↓
    Top-K RetrievalResult list

Design rules
------------
* Uses Phase 5.3A SimilarityEngine — does NOT duplicate similarity logic.
* Read-only: retrieve() never modifies stored memories.
* Deterministic: same inputs → same output order, always.
* Offline-first: no FAISS, no cloud, no LLM, no GPU, no embedding server.
* Stateless apart from immutable configuration and injected stores.
* Thread-safe: delegates to the thread-safe stores; adds no shared mutable
  state of its own.
* Missing features are handled by Phase 5.3A (skipped, not penalised).
* Expired / invalid experiences are excluded without crashing.

What this module does NOT do:
  * Phase 5.4 Memory Integration
  * Reasoning / planning / path planning
  * Decision making / collision avoidance
  * Online learning / model training
  * Any network or cloud access
"""
from __future__ import annotations

import logging
import math
from typing import List, Optional

from core.config_loader import get as _cfg_get
from core.logging_system import get_logger as _get_logger
from core.perception.perception_types import NOT_AVAILABLE

from .memory_types import MemoryLifecycleState, ObjectMemoryEntry
from .object_memory import ObjectMemory
from .prototype_memory import PrototypeMemory
from .prototype_types import prototype_key_for
from .retrieval_types import RetrievalResult
from .similarity_engine import SimilarityEngine, SimilarityWeights, DEFAULT_SIMILARITY_WEIGHTS
from .situation_types import CurrentSituation

__all__ = ["ExperienceRetriever"]

# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------

_LOG_CAT = "system"


def _log() -> logging.Logger:
    try:
        return _get_logger(_LOG_CAT)
    except Exception:
        return logging.getLogger("indidrive.memory.retrieval")


# ---------------------------------------------------------------------------
# Configuration defaults
# ---------------------------------------------------------------------------

_DEFAULT_TOP_K: int = 5
_DEFAULT_MINIMUM_SIMILARITY: float = 0.60

# Lifecycle states considered valid for retrieval.
# EXPIRED entries are always excluded.
_RETRIEVABLE_STATES = frozenset({
    MemoryLifecycleState.NEW,
    MemoryLifecycleState.ACTIVE,
    MemoryLifecycleState.STALE,
})


def _load_retrieval_config() -> dict:
    """Load experience_retrieval section from similarity_config.yaml.

    Degrades gracefully — returns {} if the key is absent or the file
    cannot be read.  This keeps the retriever usable even if the config
    file is missing.
    """
    try:
        raw = _cfg_get("similarity", "experience_retrieval")
        if isinstance(raw, dict):
            return raw
    except Exception:
        pass
    return {}


def _validate_top_k(top_k: int) -> int:
    if not isinstance(top_k, int) or isinstance(top_k, bool):
        raise ValueError(f"top_k must be an integer, got {top_k!r}")
    if top_k < 1:
        raise ValueError(f"top_k must be >= 1, got {top_k!r}")
    return top_k


def _validate_minimum_similarity(threshold: float) -> float:
    if not isinstance(threshold, (int, float)) or isinstance(threshold, bool):
        raise ValueError(
            f"minimum_similarity must be a number, got {threshold!r}"
        )
    if not math.isfinite(threshold):
        raise ValueError(
            f"minimum_similarity={threshold!r} is NaN or Inf"
        )
    if not 0.0 <= threshold <= 1.0:
        raise ValueError(
            f"minimum_similarity={threshold!r} must be in [0.0, 1.0]"
        )
    return float(threshold)


# ---------------------------------------------------------------------------
# Retriever
# ---------------------------------------------------------------------------

class ExperienceRetriever:
    """Stateless-ish retriever that finds the top-K most similar experiences.

    Parameters
    ----------
    object_memory:
        Phase 5.1 store.  Provides the candidate pool (ObjectMemoryEntry
        instances).  If None, an empty ObjectMemory is used (results will
        always be empty — useful for isolated unit tests).
    prototype_memory:
        Phase 5.2 store.  Used to look up the ObjectPrototype for each
        candidate's object_type so the Phase 5.3A engine can compare
        against the category-level feature representation.  If None, an
        empty PrototypeMemory is used; candidates whose object_type has
        no prototype will fall back to type-only similarity.
    similarity_engine:
        Phase 5.3A engine.  If None, a default engine is constructed
        (uses DEFAULT_SIMILARITY_WEIGHTS).
    top_k:
        Maximum number of results to return.  Overrides config if given.
    minimum_similarity:
        Minimum similarity threshold in [0.0, 1.0].  Candidates below
        this score are excluded.  Overrides config if given.
    """

    def __init__(
        self,
        object_memory: Optional[ObjectMemory] = None,
        prototype_memory: Optional[PrototypeMemory] = None,
        similarity_engine: Optional[SimilarityEngine] = None,
        top_k: Optional[int] = None,
        minimum_similarity: Optional[float] = None,
    ) -> None:
        cfg = _load_retrieval_config()

        self._object_memory: ObjectMemory = (
            object_memory if object_memory is not None else ObjectMemory()
        )
        self._prototype_memory: PrototypeMemory = (
            prototype_memory if prototype_memory is not None else PrototypeMemory()
        )
        self._engine: SimilarityEngine = (
            similarity_engine if similarity_engine is not None
            else SimilarityEngine()
        )

        self._top_k: int = _validate_top_k(
            top_k if top_k is not None
            else int(cfg.get("top_k", _DEFAULT_TOP_K))
        )
        self._minimum_similarity: float = _validate_minimum_similarity(
            minimum_similarity if minimum_similarity is not None
            else float(cfg.get("minimum_similarity", _DEFAULT_MINIMUM_SIMILARITY))
        )

    # -----------------------------------------------------------------------
    # Properties (read-only access to config)
    # -----------------------------------------------------------------------

    @property
    def top_k(self) -> int:
        return self._top_k

    @property
    def minimum_similarity(self) -> float:
        return self._minimum_similarity

    # -----------------------------------------------------------------------
    # Primary API
    # -----------------------------------------------------------------------

    def retrieve(
        self,
        current_situation: CurrentSituation,
        top_k: Optional[int] = None,
        minimum_similarity: Optional[float] = None,
    ) -> List[RetrievalResult]:
        """Retrieve the most similar stored experiences for the given situation.

        Parameters
        ----------
        current_situation:
            The current driving situation (Phase 5.3A CurrentSituation).
            Must have a valid object_type; feature groups are optional.
        top_k:
            Override the instance-level top_k for this call only.
            Must be >= 1 if provided.
        minimum_similarity:
            Override the instance-level threshold for this call only.
            Must be in [0.0, 1.0] if provided.

        Returns
        -------
        List[RetrievalResult]:
            Ranked list of up to top_k results, sorted by similarity
            descending (ties broken by confidence descending, then
            memory_id ascending for determinism).  Returns an empty list
            when the memory is empty or no candidate exceeds the
            threshold.  Never raises for missing/malformed stored data.
        """
        effective_top_k = (
            _validate_top_k(top_k) if top_k is not None else self._top_k
        )
        effective_threshold = (
            _validate_minimum_similarity(minimum_similarity)
            if minimum_similarity is not None
            else self._minimum_similarity
        )

        # --- Step 1: collect candidate entries --------------------------------
        try:
            candidates: List[ObjectMemoryEntry] = self._object_memory.list()
        except Exception as exc:
            _log().error("retrieve(): failed to list object memory: %s", exc)
            return []

        if not candidates:
            return []

        # --- Step 2: score each candidate ------------------------------------
        results: List[RetrievalResult] = []

        for entry in candidates:
            try:
                result = self._score_candidate(entry, current_situation)
            except Exception as exc:  # noqa: BLE001
                _log().warning(
                    "retrieve(): skipping malformed entry %s: %s",
                    getattr(entry, "memory_id", "<unknown>"),
                    exc,
                )
                continue

            if result is None:
                # Entry excluded (expired, invalid, below threshold, etc.)
                continue

            results.append(result)

        # --- Step 3: sort deterministically ----------------------------------
        # Primary:   similarity descending (higher = more relevant)
        # Secondary: confidence descending (higher confidence first for ties)
        # Tertiary:  memory_id ascending   (stable lexicographic tie-break)
        results.sort(
            key=lambda r: (
                -r.similarity,
                -(r.confidence if r.confidence is not None else 0.0),
                r.memory_id,
            )
        )

        # --- Step 4: return top-K -------------------------------------------
        return results[:effective_top_k]

    # -----------------------------------------------------------------------
    # Internal helpers
    # -----------------------------------------------------------------------

    def _score_candidate(
        self,
        entry: ObjectMemoryEntry,
        current_situation: CurrentSituation,
    ) -> Optional[RetrievalResult]:
        """Score one candidate entry against the current situation.

        Returns a RetrievalResult if the candidate is valid and above
        threshold, or None if it should be excluded.

        This method never modifies the stored entry.
        """
        # --- Validate memory_id ---
        memory_id = getattr(entry, "memory_id", None)
        if not memory_id or not isinstance(memory_id, str):
            _log().debug("_score_candidate: skipping entry with invalid memory_id")
            return None

        # --- Respect lifecycle (Phase 5.1 rules) ----------------------------
        lc = getattr(entry, "lifecycle_state", None)
        if lc not in _RETRIEVABLE_STATES:
            # EXPIRED or unknown lifecycle — exclude silently
            return None

        # --- Extract object_type from entry ----------------------------------
        entry_object_type = getattr(entry, "object_type", NOT_AVAILABLE) or NOT_AVAILABLE

        # --- Look up prototype for this object_type (Phase 5.2) --------------
        prototype_key: Optional[str] = None
        prototype = None
        if entry_object_type != NOT_AVAILABLE:
            try:
                pk = prototype_key_for(entry_object_type)
                candidate_proto = self._prototype_memory.get(pk)
                if candidate_proto is not None:
                    prototype = candidate_proto
                    prototype_key = pk
            except Exception as exc:
                _log().debug(
                    "_score_candidate: prototype lookup failed for %r: %s",
                    entry_object_type,
                    exc,
                )

        # --- Compute similarity via Phase 5.3A -------------------------------
        if prototype is not None:
            # Full prototype comparison (the common case)
            sim_result = self._engine.compare_to_prototype(current_situation, prototype)
        else:
            # No prototype available — build a minimal CurrentSituation from
            # the entry's compact fields so we can still compare object_type
            # and motion at minimum.
            from .situation_types import CurrentSituation as _CS
            from .feature_types import GeometryFeature, MotionFeature, MotionClass

            # Build a minimal situation from what is stored in the entry
            ref_geo: Optional[GeometryFeature] = None
            if entry.dimensions is not None and entry.dimensions.is_valid():
                d = entry.dimensions
                ref_geo = GeometryFeature(
                    length=d.length,
                    width=d.width,
                    height=d.height,
                )

            ref_mot: Optional[MotionFeature] = None
            if entry.motion is not None and entry.motion.is_valid():
                m = entry.motion
                ref_mot = MotionFeature(
                    typical_speed_ms=m.speed_ms,
                    heading_rad=m.heading_rad,
                    motion_class=MotionClass.UNKNOWN,
                )

            ref_situation = _CS(
                object_type=entry_object_type,
                geometry=ref_geo,
                motion=ref_mot,
            )

            # Use compare_to_feature_set equivalent — compare situation to
            # another situation by constructing a transient ObjectFeatureSet.
            from .feature_types import ObjectFeatureSet as _OFS
            ref_fs = _OFS(
                object_type=entry_object_type,
                geometry=ref_geo,
                motion=ref_mot,
            )
            sim_result = self._engine.compare_to_feature_set(current_situation, ref_fs)

        # --- Validate similarity score ----------------------------------------
        score = sim_result.overall_similarity
        if not isinstance(score, (int, float)) or not math.isfinite(score):
            _log().debug(
                "_score_candidate: non-finite score %r for entry %s",
                score,
                memory_id,
            )
            return None

        # --- Apply threshold -------------------------------------------------
        if score < self._minimum_similarity:
            return None

        # --- Extract optional metadata safely --------------------------------
        confidence: Optional[float] = None
        raw_conf = getattr(entry, "confidence", None)
        if raw_conf is not None:
            try:
                cf = float(raw_conf)
                if math.isfinite(cf) and 0.0 <= cf <= 1.0:
                    confidence = cf
            except (TypeError, ValueError):
                pass

        timestamp: Optional[float] = None
        raw_ts = getattr(entry, "observed_at", None)
        if raw_ts is not None:
            try:
                ts = float(raw_ts)
                if math.isfinite(ts):
                    timestamp = ts
            except (TypeError, ValueError):
                pass

        return RetrievalResult(
            memory_id=memory_id,
            similarity=float(score),
            prototype_key=prototype_key,
            object_type=entry_object_type,
            matched_features=dict(sim_result.components),
            confidence=confidence,
            timestamp=timestamp,
        )
