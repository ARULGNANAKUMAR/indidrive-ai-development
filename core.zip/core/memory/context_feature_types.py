"""
IndiDrive AI — Phase 8.3 | Context & Risk Feature Types
=========================================================
Extends the Phase 5.2 feature schema with two new feature groups:

    ContextFeature  — road environment context
    RiskFeature     — collision/hazard risk attributes
    SituationFeatureVector — normalised compact numeric vector derived
                             from a complete scene observation

Pipeline context:

    ReasoningSnapshot / WorldModelSnapshot / IndianRoadContextState
            ↓
    SceneFeatureMemory.add_observation()
            ↓
    ContextFeature + RiskFeature extracted here
            ↓
    feature_normalizer.py
            ↓
    Phase 5.2 ObjectFeatureSet (geometry / motion) + these new groups
            ↓
    SituationPrototype / PrototypeMemory

Design rules (same as all prior phases):
  * compact — no raw sensor frames, no large tensors
  * deterministic — same input → same output
  * serialisable — to_dict() / from_dict()
  * offline-first — no cloud, no LLM, no external DB
  * optional fields are None, not fabricated
  * NaN/Inf safe — every numeric field validated before use
  * missing values represented explicitly, never masked by fake data

Phase boundary: Phase 8.3 only.
Does NOT implement retrieval, reasoning, path planning, or control.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from enum import Enum
from typing import List, Optional

from core.perception.perception_types import NOT_AVAILABLE

__all__ = [
    "CONTEXT_RISK_SCHEMA_VERSION",
    # Enums
    "RoadTypeClass",
    "TrafficDensityClass",
    "RoadMarkingClass",
    "IntersectionClass",
    "RoadDamageClass",
    "RiskLevelClass",
    "TtcBandClass",
    # Feature dataclasses
    "ContextFeature",
    "RiskFeature",
    # Validation
    "validate_context_feature",
    "validate_risk_feature",
]

# Increment when the serialised schema changes in a breaking way.
CONTEXT_RISK_SCHEMA_VERSION: int = 1


# ---------------------------------------------------------------------------
# Small numeric helpers
# ---------------------------------------------------------------------------

def _finite(v) -> bool:
    return isinstance(v, (int, float)) and not isinstance(v, bool) and math.isfinite(v)


def _finite_or_none(v) -> bool:
    return v is None or _finite(v)


def _finite_nonneg_or_none(v) -> bool:
    return v is None or (_finite(v) and v >= 0.0)


def _in_unit_or_none(v) -> bool:
    """Value in [0.0, 1.0] or None."""
    return v is None or (_finite(v) and 0.0 <= v <= 1.0)


def _dict_or_na(v):
    return v if v is not None else NOT_AVAILABLE


def _opt_float(v):
    return float(v) if v not in (None, NOT_AVAILABLE) else None


def _opt_str(v):
    return v if (isinstance(v, str) and v != NOT_AVAILABLE) else None


# ---------------------------------------------------------------------------
# Compact enums — one value per concept
# ---------------------------------------------------------------------------

class RoadTypeClass(str, Enum):
    """Coarse road type category distilled from IndianRoadContextState."""
    HIGHWAY    = "HIGHWAY"
    ARTERIAL   = "ARTERIAL"
    LOCAL      = "LOCAL"
    RURAL      = "RURAL"
    UNPAVED    = "UNPAVED"
    UNKNOWN    = "UNKNOWN"


class TrafficDensityClass(str, Enum):
    """Coarse traffic density bucket."""
    EMPTY       = "EMPTY"
    LIGHT       = "LIGHT"
    MODERATE    = "MODERATE"
    DENSE       = "DENSE"
    GRIDLOCK    = "GRIDLOCK"
    UNKNOWN     = "UNKNOWN"


class RoadMarkingClass(str, Enum):
    """Lane marking availability."""
    CLEAR       = "CLEAR"
    FADED       = "FADED"
    NONE        = "NONE"
    UNKNOWN     = "UNKNOWN"


class IntersectionClass(str, Enum):
    """Intersection or road-geometry context."""
    STRAIGHT    = "STRAIGHT"
    CURVE       = "CURVE"
    T_JUNCTION  = "T_JUNCTION"
    CROSSROADS  = "CROSSROADS"
    ROUNDABOUT  = "ROUNDABOUT"
    UNKNOWN     = "UNKNOWN"


class RoadDamageClass(str, Enum):
    """Severity of road surface damage."""
    NONE        = "NONE"
    MINOR       = "MINOR"
    MODERATE    = "MODERATE"
    SEVERE      = "SEVERE"
    UNKNOWN     = "UNKNOWN"


class RiskLevelClass(str, Enum):
    """Overall risk level for one hazard / scene."""
    NONE        = "NONE"
    LOW         = "LOW"
    MEDIUM      = "MEDIUM"
    HIGH        = "HIGH"
    CRITICAL    = "CRITICAL"
    UNKNOWN     = "UNKNOWN"


class TtcBandClass(str, Enum):
    """Time-to-collision band for one hazard."""
    IMMEDIATE   = "IMMEDIATE"    # TTC < 1 s
    NEAR        = "NEAR"         # 1–3 s
    MODERATE    = "MODERATE"     # 3–6 s
    FAR         = "FAR"          # > 6 s
    NOT_THREAT  = "NOT_THREAT"
    UNKNOWN     = "UNKNOWN"


# ---------------------------------------------------------------------------
# ContextFeature
# ---------------------------------------------------------------------------

@dataclass
class ContextFeature:
    """Compact road-environment context representation.

    Derived from IndianRoadContextState and EnvironmentInfo — NOT raw
    sensor frames. Every field has a safe default; unknown/unavailable
    values are represented explicitly (enum UNKNOWN or None), never
    fabricated.

    For numeric ranges (road_width_m, object_count) None means the
    sensor/processing pipeline did not produce a reliable value.
    """

    # Road type and structure
    road_type: RoadTypeClass = RoadTypeClass.UNKNOWN
    road_marking: RoadMarkingClass = RoadMarkingClass.UNKNOWN
    intersection_context: IntersectionClass = IntersectionClass.UNKNOWN
    road_damage: RoadDamageClass = RoadDamageClass.UNKNOWN

    # Quantitative road properties
    road_width_m: Optional[float] = None        # estimated road width in metres
    lane_count: Optional[int] = None             # estimated number of lanes

    # Traffic / scene density
    traffic_density: TrafficDensityClass = TrafficDensityClass.UNKNOWN
    object_count: Optional[int] = None           # total objects in scene (bounded)
    pedestrian_count: Optional[int] = None       # pedestrian / VRU count
    animal_present: bool = False
    mixed_traffic: bool = False                  # heterogeneous vehicle types present
    wrong_side_traffic: bool = False

    # Feature completeness metadata
    context_confidence: float = 0.0             # [0, 1] confidence in this context
    schema_version: int = CONTEXT_RISK_SCHEMA_VERSION

    # ------------------------------------------------------------------
    def is_valid(self) -> bool:
        """Deterministic validity check. Never raises."""
        if not _in_unit_or_none(self.context_confidence):
            return False
        if not isinstance(self.context_confidence, float):
            try:
                float(self.context_confidence)
            except (TypeError, ValueError):
                return False
        if self.road_width_m is not None and not _finite_nonneg_or_none(self.road_width_m):
            return False
        if self.lane_count is not None and (not isinstance(self.lane_count, int)
                                             or self.lane_count < 0):
            return False
        if self.object_count is not None and (not isinstance(self.object_count, int)
                                               or self.object_count < 0):
            return False
        if self.pedestrian_count is not None and (not isinstance(self.pedestrian_count, int)
                                                   or self.pedestrian_count < 0):
            return False
        return True

    def to_dict(self) -> dict:
        return {
            "schema_version": self.schema_version,
            "road_type": self.road_type.value,
            "road_marking": self.road_marking.value,
            "intersection_context": self.intersection_context.value,
            "road_damage": self.road_damage.value,
            "road_width_m": _dict_or_na(self.road_width_m),
            "lane_count": _dict_or_na(self.lane_count),
            "traffic_density": self.traffic_density.value,
            "object_count": _dict_or_na(self.object_count),
            "pedestrian_count": _dict_or_na(self.pedestrian_count),
            "animal_present": self.animal_present,
            "mixed_traffic": self.mixed_traffic,
            "wrong_side_traffic": self.wrong_side_traffic,
            "context_confidence": round(self.context_confidence, 6),
        }

    @staticmethod
    def from_dict(d: dict) -> "ContextFeature":
        def _enum(cls, key, default):
            raw = d.get(key)
            if raw is None or raw == NOT_AVAILABLE:
                return default
            try:
                return cls(raw)
            except ValueError:
                return default

        return ContextFeature(
            road_type=_enum(RoadTypeClass, "road_type", RoadTypeClass.UNKNOWN),
            road_marking=_enum(RoadMarkingClass, "road_marking", RoadMarkingClass.UNKNOWN),
            intersection_context=_enum(IntersectionClass, "intersection_context", IntersectionClass.UNKNOWN),
            road_damage=_enum(RoadDamageClass, "road_damage", RoadDamageClass.UNKNOWN),
            road_width_m=_opt_float(d.get("road_width_m")),
            lane_count=int(d["lane_count"]) if d.get("lane_count") not in (None, NOT_AVAILABLE) else None,
            traffic_density=_enum(TrafficDensityClass, "traffic_density", TrafficDensityClass.UNKNOWN),
            object_count=int(d["object_count"]) if d.get("object_count") not in (None, NOT_AVAILABLE) else None,
            pedestrian_count=int(d["pedestrian_count"]) if d.get("pedestrian_count") not in (None, NOT_AVAILABLE) else None,
            animal_present=bool(d.get("animal_present", False)),
            mixed_traffic=bool(d.get("mixed_traffic", False)),
            wrong_side_traffic=bool(d.get("wrong_side_traffic", False)),
            context_confidence=float(d.get("context_confidence", 0.0)),
            schema_version=int(d.get("schema_version", CONTEXT_RISK_SCHEMA_VERSION)),
        )


# ---------------------------------------------------------------------------
# RiskFeature
# ---------------------------------------------------------------------------

@dataclass
class RiskFeature:
    """Compact collision/hazard risk representation for a scene or object.

    Derived from ReasoningSnapshot, WorldObject collision info, and Phase 4D
    prediction output — NOT recomputed here. Stored as a compact summary
    for prototype memory purposes.

    All numeric fields are optional; None means the upstream pipeline
    did not produce a reliable value (sensor degraded, no TTC computed, etc.).
    """

    # Overall scene-level risk
    overall_risk: RiskLevelClass = RiskLevelClass.UNKNOWN
    critical_hazard_count: int = 0
    total_hazard_count: int = 0

    # Per-object risk attributes (for object-level prototypes)
    object_risk: RiskLevelClass = RiskLevelClass.UNKNOWN
    ttc_band: TtcBandClass = TtcBandClass.UNKNOWN
    ttc_s: Optional[float] = None                     # raw TTC in seconds
    distance_m: Optional[float] = None                # distance to object/hazard
    closing_speed_ms: Optional[float] = None          # approach rate (positive = closing)
    collision_likelihood: Optional[float] = None      # [0, 1] from Phase 4D

    # Contextual risk indicators
    collision_threat_present: bool = False
    has_vulnerable_road_users: bool = False
    has_wrong_side_threat: bool = False

    # Confidence in risk assessment
    risk_confidence: float = 0.0                      # [0, 1]

    schema_version: int = CONTEXT_RISK_SCHEMA_VERSION

    # ------------------------------------------------------------------
    def is_valid(self) -> bool:
        """Deterministic validity check. Never raises."""
        if not isinstance(self.critical_hazard_count, int) or self.critical_hazard_count < 0:
            return False
        if not isinstance(self.total_hazard_count, int) or self.total_hazard_count < 0:
            return False
        if not _in_unit_or_none(self.risk_confidence):
            return False
        if not _finite_nonneg_or_none(self.ttc_s):
            return False
        if not _finite_nonneg_or_none(self.distance_m):
            return False
        if not _finite_or_none(self.closing_speed_ms):
            return False
        if not _in_unit_or_none(self.collision_likelihood):
            return False
        return True

    def to_dict(self) -> dict:
        return {
            "schema_version": self.schema_version,
            "overall_risk": self.overall_risk.value,
            "critical_hazard_count": self.critical_hazard_count,
            "total_hazard_count": self.total_hazard_count,
            "object_risk": self.object_risk.value,
            "ttc_band": self.ttc_band.value,
            "ttc_s": _dict_or_na(self.ttc_s),
            "distance_m": _dict_or_na(self.distance_m),
            "closing_speed_ms": _dict_or_na(self.closing_speed_ms),
            "collision_likelihood": (round(self.collision_likelihood, 6)
                                     if self.collision_likelihood is not None else NOT_AVAILABLE),
            "collision_threat_present": self.collision_threat_present,
            "has_vulnerable_road_users": self.has_vulnerable_road_users,
            "has_wrong_side_threat": self.has_wrong_side_threat,
            "risk_confidence": round(self.risk_confidence, 6),
        }

    @staticmethod
    def from_dict(d: dict) -> "RiskFeature":
        def _enum(cls, key, default):
            raw = d.get(key)
            if raw is None or raw == NOT_AVAILABLE:
                return default
            try:
                return cls(raw)
            except ValueError:
                return default

        return RiskFeature(
            overall_risk=_enum(RiskLevelClass, "overall_risk", RiskLevelClass.UNKNOWN),
            critical_hazard_count=int(d.get("critical_hazard_count", 0)),
            total_hazard_count=int(d.get("total_hazard_count", 0)),
            object_risk=_enum(RiskLevelClass, "object_risk", RiskLevelClass.UNKNOWN),
            ttc_band=_enum(TtcBandClass, "ttc_band", TtcBandClass.UNKNOWN),
            ttc_s=_opt_float(d.get("ttc_s")),
            distance_m=_opt_float(d.get("distance_m")),
            closing_speed_ms=_opt_float(d.get("closing_speed_ms")),
            collision_likelihood=_opt_float(d.get("collision_likelihood")),
            collision_threat_present=bool(d.get("collision_threat_present", False)),
            has_vulnerable_road_users=bool(d.get("has_vulnerable_road_users", False)),
            has_wrong_side_threat=bool(d.get("has_wrong_side_threat", False)),
            risk_confidence=float(d.get("risk_confidence", 0.0)),
            schema_version=int(d.get("schema_version", CONTEXT_RISK_SCHEMA_VERSION)),
        )


# ---------------------------------------------------------------------------
# Validation helpers
# ---------------------------------------------------------------------------

def validate_context_feature(ctx: ContextFeature) -> tuple[bool, str]:
    """Validate a ContextFeature. Returns (ok, reason)."""
    if not isinstance(ctx, ContextFeature):
        return False, f"Expected ContextFeature, got {type(ctx).__name__}"
    if not ctx.is_valid():
        return False, "ContextFeature failed internal validity check (NaN/Inf/negative/out-of-range)"
    return True, ""


def validate_risk_feature(risk: RiskFeature) -> tuple[bool, str]:
    """Validate a RiskFeature. Returns (ok, reason)."""
    if not isinstance(risk, RiskFeature):
        return False, f"Expected RiskFeature, got {type(risk).__name__}"
    if not risk.is_valid():
        return False, "RiskFeature failed internal validity check (NaN/Inf/negative/out-of-range)"
    return True, ""
