"""
IndiDrive AI — Phase 5.1 | Object Memory Data Contracts
=========================================================
Strongly-typed containers for the Object Memory layer. Follows the
same design philosophy as Phase 2/3/4 data contracts: dataclasses,
explicit sentinel values, deterministic to_dict(), and no fabricated
values.

These types sit downstream of the full prediction pipeline:

    Raw Sensor Data → Perception → Fusion → Tracking/Prediction
        → Compact Object Representation → Object Memory

Nothing here performs reasoning, retrieval, or learning — those belong
to later phases (5.2, 5.3, 5.4 …).
"""
from __future__ import annotations

import json
import math
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Optional

from core.perception.perception_types import NOT_AVAILABLE

__all__ = [
    "MemoryLifecycleState",
    "MemoryCleanupPolicy",
    "MemoryPositionSummary",
    "MemoryDimensions",
    "MemoryMotionSummary",
    "ObjectMemoryEntry",
    "MemoryOperationResult",
    "MemoryStoreStats",
    "MEMORY_SCHEMA_VERSION",
]

# Increment when the serialised schema changes in a breaking way.
MEMORY_SCHEMA_VERSION: int = 1


class MemoryLifecycleState(str, Enum):
    """Lifecycle of a memory entry — independent of the track lifecycle.

    An object disappearing from the current sensor frame does NOT
    immediately expire its memory; memory persists beyond active tracking.
    """
    NEW = "NEW"       # just stored, not yet confirmed by a second observation
    ACTIVE = "ACTIVE" # observed recently, confidence is healthy
    STALE = "STALE"   # not observed for a while, but within max_age
    EXPIRED = "EXPIRED"  # exceeded max_age; eligible for cleanup


class MemoryCleanupPolicy(str, Enum):
    """Determines which entries are evicted when capacity is reached."""
    OLDEST_FIRST = "OLDEST_FIRST"      # evict by created_at (ascending)
    STALE_FIRST = "STALE_FIRST"        # evict STALE/EXPIRED before ACTIVE
    LOWEST_CONFIDENCE = "LOWEST_CONFIDENCE"  # evict lowest confidence first


@dataclass
class MemoryPositionSummary:
    """Last known spatial position (vehicle frame, metres). All optional —
    unavailable positions are represented as None, not fabricated."""
    x: Optional[float] = None
    y: Optional[float] = None
    z: Optional[float] = None

    def is_valid(self) -> bool:
        for v in (self.x, self.y, self.z):
            if v is not None and (not isinstance(v, (int, float)) or not math.isfinite(v)):
                return False
        return True

    def to_dict(self) -> dict:
        return {
            "x": self.x if self.x is not None else NOT_AVAILABLE,
            "y": self.y if self.y is not None else NOT_AVAILABLE,
            "z": self.z if self.z is not None else NOT_AVAILABLE,
        }

    @staticmethod
    def from_dict(d: dict) -> "MemoryPositionSummary":
        def _f(v):
            return float(v) if v not in (None, NOT_AVAILABLE) else None
        return MemoryPositionSummary(x=_f(d.get("x")), y=_f(d.get("y")), z=_f(d.get("z")))


@dataclass
class MemoryDimensions:
    """Compact bounding-box dimensions (metres). All optional."""
    length: Optional[float] = None
    width: Optional[float] = None
    height: Optional[float] = None

    def is_valid(self) -> bool:
        for v in (self.length, self.width, self.height):
            if v is not None:
                if not isinstance(v, (int, float)) or not math.isfinite(v) or v < 0:
                    return False
        return True

    def to_dict(self) -> dict:
        return {
            "length": self.length if self.length is not None else NOT_AVAILABLE,
            "width": self.width if self.width is not None else NOT_AVAILABLE,
            "height": self.height if self.height is not None else NOT_AVAILABLE,
        }

    @staticmethod
    def from_dict(d: dict) -> "MemoryDimensions":
        def _f(v):
            return float(v) if v not in (None, NOT_AVAILABLE) else None
        return MemoryDimensions(
            length=_f(d.get("length")),
            width=_f(d.get("width")),
            height=_f(d.get("height")),
        )


@dataclass
class MemoryMotionSummary:
    """Compact kinematic summary at the time of observation. All optional."""
    speed_ms: Optional[float] = None      # metres / second
    heading_rad: Optional[float] = None   # radians, same frame as prediction layer
    acceleration_ms2: Optional[float] = None  # scalar magnitude, m/s²

    def is_valid(self) -> bool:
        for v in (self.speed_ms, self.heading_rad, self.acceleration_ms2):
            if v is not None:
                if not isinstance(v, (int, float)) or not math.isfinite(v):
                    return False
        if self.speed_ms is not None and self.speed_ms < 0:
            return False
        if self.acceleration_ms2 is not None and self.acceleration_ms2 < 0:
            return False
        return True

    def to_dict(self) -> dict:
        return {
            "speed_ms": self.speed_ms if self.speed_ms is not None else NOT_AVAILABLE,
            "heading_rad": self.heading_rad if self.heading_rad is not None else NOT_AVAILABLE,
            "acceleration_ms2": (
                self.acceleration_ms2 if self.acceleration_ms2 is not None else NOT_AVAILABLE
            ),
        }

    @staticmethod
    def from_dict(d: dict) -> "MemoryMotionSummary":
        def _f(v):
            return float(v) if v not in (None, NOT_AVAILABLE) else None
        return MemoryMotionSummary(
            speed_ms=_f(d.get("speed_ms")),
            heading_rad=_f(d.get("heading_rad")),
            acceleration_ms2=_f(d.get("acceleration_ms2")),
        )


@dataclass
class ObjectMemoryEntry:
    """A single compact memory record for one observed object.

    Separates persistent memory identity (memory_id) from the
    short-lived track ID that the prediction layer assigns. The
    memory can survive track resets, sensor gaps, and system restarts.

    Schema is versioned via memory_schema_version so future phases can
    evolve the representation without silently breaking stored records.
    """
    # --- Identity ---
    memory_id: str                         # stable persistent ID
    track_id: Optional[str] = None         # associated prediction-layer track (may change)
    source: str = NOT_AVAILABLE            # e.g. "phase4d_pipeline", "fusion_engine"

    # --- Classification ---
    object_type: str = NOT_AVAILABLE       # from ObjectBehaviourClass or perception label
    confidence: float = 0.0               # [0.0, 1.0] — stored as-is, not invented

    # --- Geometry (compact) ---
    position: Optional[MemoryPositionSummary] = None
    dimensions: Optional[MemoryDimensions] = None

    # --- Motion (compact) ---
    motion: Optional[MemoryMotionSummary] = None

    # --- Appearance (optional compact descriptor) ---
    # Intentionally lightweight: a short string tag, not raw image data.
    appearance_label: Optional[str] = None

    # --- Timestamps ---
    observed_at: float = field(default_factory=time.time)  # when the object was seen
    created_at: float = field(default_factory=time.time)   # when memory was first stored
    updated_at: float = field(default_factory=time.time)   # last modification

    # --- Lifecycle ---
    lifecycle_state: MemoryLifecycleState = MemoryLifecycleState.NEW

    # --- Schema ---
    memory_schema_version: int = MEMORY_SCHEMA_VERSION

    # --- Misc ---
    metadata: dict = field(default_factory=dict)  # caller-supplied key-value pairs
    warnings: list = field(default_factory=list)

    # ---------------------------------------------------------------
    def to_dict(self) -> dict:
        return {
            "memory_schema_version": self.memory_schema_version,
            "memory_id": self.memory_id,
            "track_id": self.track_id if self.track_id is not None else NOT_AVAILABLE,
            "source": self.source,
            "object_type": self.object_type,
            "confidence": round(self.confidence, 6),
            "position": self.position.to_dict() if self.position else NOT_AVAILABLE,
            "dimensions": self.dimensions.to_dict() if self.dimensions else NOT_AVAILABLE,
            "motion": self.motion.to_dict() if self.motion else NOT_AVAILABLE,
            "appearance_label": (
                self.appearance_label if self.appearance_label is not None else NOT_AVAILABLE
            ),
            "observed_at": self.observed_at,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
            "lifecycle_state": self.lifecycle_state.value,
            "metadata": self.metadata,
            "warnings": self.warnings,
        }

    def to_json(self) -> str:
        """Deterministic JSON serialization (sorted keys)."""
        return json.dumps(self.to_dict(), sort_keys=True)

    @staticmethod
    def from_dict(d: dict) -> "ObjectMemoryEntry":
        """Deserialize from a dict produced by to_dict(). Raises ValueError
        on schema version mismatch or missing required fields."""
        schema_ver = d.get("memory_schema_version", 0)
        if schema_ver != MEMORY_SCHEMA_VERSION:
            raise ValueError(
                f"Unsupported memory_schema_version={schema_ver}; "
                f"expected {MEMORY_SCHEMA_VERSION}"
            )
        memory_id = d.get("memory_id")
        if not memory_id or not isinstance(memory_id, str):
            raise ValueError("memory_id is missing or not a string")

        def _pos(v):
            return MemoryPositionSummary.from_dict(v) if isinstance(v, dict) else None

        def _dim(v):
            return MemoryDimensions.from_dict(v) if isinstance(v, dict) else None

        def _mot(v):
            return MemoryMotionSummary.from_dict(v) if isinstance(v, dict) else None

        def _opt_str(v):
            return v if (isinstance(v, str) and v != NOT_AVAILABLE) else None

        raw_state = d.get("lifecycle_state", MemoryLifecycleState.NEW.value)
        try:
            lc = MemoryLifecycleState(raw_state)
        except ValueError:
            lc = MemoryLifecycleState.NEW

        return ObjectMemoryEntry(
            memory_id=memory_id,
            track_id=_opt_str(d.get("track_id")),
            source=d.get("source", NOT_AVAILABLE),
            object_type=d.get("object_type", NOT_AVAILABLE),
            confidence=float(d.get("confidence", 0.0)),
            position=_pos(d.get("position")),
            dimensions=_dim(d.get("dimensions")),
            motion=_mot(d.get("motion")),
            appearance_label=_opt_str(d.get("appearance_label")),
            observed_at=float(d.get("observed_at", 0.0)),
            created_at=float(d.get("created_at", 0.0)),
            updated_at=float(d.get("updated_at", 0.0)),
            lifecycle_state=lc,
            memory_schema_version=schema_ver,
            metadata=d.get("metadata", {}),
            warnings=d.get("warnings", []),
        )

    @staticmethod
    def from_json(s: str) -> "ObjectMemoryEntry":
        try:
            d = json.loads(s)
        except json.JSONDecodeError as e:
            raise ValueError(f"Invalid JSON: {e}") from e
        return ObjectMemoryEntry.from_dict(d)


@dataclass
class MemoryOperationResult:
    """Structured result for every memory store operation.
    Never raises silently — callers check ok / reason."""
    ok: bool
    memory_id: Optional[str] = None
    reason: str = ""

    @staticmethod
    def success(memory_id: str) -> "MemoryOperationResult":
        return MemoryOperationResult(ok=True, memory_id=memory_id)

    @staticmethod
    def failure(reason: str, memory_id: Optional[str] = None) -> "MemoryOperationResult":
        return MemoryOperationResult(ok=False, memory_id=memory_id, reason=reason)


@dataclass
class MemoryStoreStats:
    """Snapshot of current memory store usage."""
    total_entries: int = 0
    new_entries: int = 0
    active_entries: int = 0
    stale_entries: int = 0
    expired_entries: int = 0
    max_capacity: int = 0
    utilization_fraction: float = 0.0

    def to_dict(self) -> dict:
        return {
            "total_entries": self.total_entries,
            "new_entries": self.new_entries,
            "active_entries": self.active_entries,
            "stale_entries": self.stale_entries,
            "expired_entries": self.expired_entries,
            "max_capacity": self.max_capacity,
            "utilization_fraction": round(self.utilization_fraction, 4),
        }
