"""
IndiDrive AI — Phase 5.4 | Memory Integration Layer
=====================================================
Connects the completed Phase 5 memory components into the existing
IndiDrive AI runtime pipeline.

Pipeline this module bridges:

    Phase 2 Perception
          ↓
    Phase 3 Sensor Fusion (FusedWorldState)
          ↓
    Phase 4 Prediction / Risk (Phase4DWorldState)
          ↓
    MemoryIntegration.process(world_state)  ← THIS MODULE
         ↙           ↓              ↘
   ObjectMemory  PrototypeMemory  ExperienceRetriever
         ↓           ↓              ↓
              MemoryContext
                    ↓
        Future Reasoning / AI Brain

Primary input accepted:
    FusedWorldState  (Phase 3)  — carries FusedObject list with
        fused_object_id, track_id, object_class, position_3d, velocity,
        dimensions, heading, class_confidence.

    Phase4DWorldState (Phase 4D) — carries Phase4DObject list (wraps
        Phase4CObject/PredictedObject) with richer motion prediction.
        Optional: accepted if available, not required.

The integration accepts either.  When only FusedWorldState is supplied it
extracts compact object descriptors from the fused objects directly.  When
Phase4DWorldState is supplied it additionally uses prediction-layer motion
(speed, heading from MotionState) and behaviour class.

Design guarantees
-----------------
* Offline-first — no network, no cloud, no LLM, no vector DB.
* Failure-isolated — if any memory subsystem fails the pipeline
  continues; a degraded MemoryContext is returned.
* Read-only context — downstream consumers receive a snapshot;
  they cannot accidentally mutate the stores.
* Thread-safe — uses existing thread-safe stores; adds no unsafe
  global state.
* Deterministic — same inputs under the same memory state → same
  MemoryContext (ordering of objects follows fused_object_id sort).
* Does NOT control the vehicle — MemoryContext is read-only context
  for a future reasoning layer, not a control output.

Phase boundary: Phase 5.4 only.
Does NOT:
  * Implement reasoning, path planning, steering, braking, collision
    avoidance, or any control action.
  * Duplicate ObjectMemory, PrototypeMemory, or ExperienceRetriever logic.
  * Perform online learning or model training.
  * Create experiences automatically every frame.
"""
from __future__ import annotations

import logging
import math
import threading
import time
from typing import Dict, List, Optional, Sequence, Union

from core.config_loader import get as _cfg_get
from core.logging_system import get_logger as _get_logger
from core.perception.perception_types import NOT_AVAILABLE

from .memory_types import (
    ObjectMemoryEntry,
    MemoryPositionSummary,
    MemoryDimensions,
    MemoryMotionSummary,
    MemoryLifecycleState,
    MemoryOperationResult,
)
from .object_memory import ObjectMemory
from .prototype_memory import PrototypeMemory
from .feature_types import (
    ObjectFeatureSet,
    GeometryFeature,
    MotionFeature,
    MotionClass,
)
from .situation_types import CurrentSituation
from .retrieval_engine import ExperienceRetriever
from .retrieval_types import RetrievalResult
from .integration_types import (
    INTEGRATION_SCHEMA_VERSION,
    MemoryContext,
    MemoryContextStatus,
    MemoryContextMetadata,
    ObjectMemoryRef,
    PrototypeRef,
    MemoryIntegrationStats,
)

__all__ = ["MemoryIntegration", "MemoryIntegrationConfig"]

# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------

_LOG_CAT = "system"


def _log() -> logging.Logger:
    try:
        return _get_logger(_LOG_CAT)
    except Exception:
        return logging.getLogger("indidrive.memory.integration")


# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

_DEFAULT_ENABLED: bool = True
_DEFAULT_RETRIEVAL_ENABLED: bool = True
_DEFAULT_SOURCE_TAG: str = "memory_integration_5_4"


def _load_integration_config() -> dict:
    """Load memory_integration section from prediction_config.yaml, or
    return empty dict (all defaults apply).  Degrades gracefully."""
    try:
        raw = _cfg_get("prediction", "memory_integration")
        if isinstance(raw, dict):
            return raw
    except Exception:
        pass
    return {}


class MemoryIntegrationConfig:
    """Runtime configuration for MemoryIntegration.

    Parameters
    ----------
    enabled:
        When False the integration is a pass-through — process() returns
        an empty/disabled MemoryContext without touching any memory store.
    retrieval_enabled:
        When False experience retrieval is skipped; ObjectMemory and
        PrototypeMemory are still updated.
    source_tag:
        Short string recorded in ObjectMemoryEntry.source for entries
        created by this integration layer.
    """

    def __init__(
        self,
        *,
        enabled: Optional[bool] = None,
        retrieval_enabled: Optional[bool] = None,
        source_tag: Optional[str] = None,
    ) -> None:
        cfg = _load_integration_config()
        self.enabled: bool = (
            enabled if enabled is not None else bool(cfg.get("enabled", _DEFAULT_ENABLED))
        )
        self.retrieval_enabled: bool = (
            retrieval_enabled if retrieval_enabled is not None
            else bool(cfg.get("retrieval", {}).get("enabled", _DEFAULT_RETRIEVAL_ENABLED)
                      if isinstance(cfg.get("retrieval"), dict)
                      else _DEFAULT_RETRIEVAL_ENABLED)
        )
        self.source_tag: str = source_tag or str(
            cfg.get("source_tag", _DEFAULT_SOURCE_TAG)
        )


# ---------------------------------------------------------------------------
# Track-to-memory identity index
# ---------------------------------------------------------------------------

class _TrackIndex:
    """Thread-safe mapping from track_id → memory_id.

    Prevents creating a new memory entry every frame for the same tracked
    object.  Kept internal to MemoryIntegration; not part of the public API.
    """

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._map: Dict[str, str] = {}   # track_id → memory_id

    def get(self, track_id: str) -> Optional[str]:
        with self._lock:
            return self._map.get(track_id)

    def set(self, track_id: str, memory_id: str) -> None:
        with self._lock:
            self._map[track_id] = memory_id

    def remove(self, track_id: str) -> None:
        with self._lock:
            self._map.pop(track_id, None)

    def snapshot(self) -> Dict[str, str]:
        with self._lock:
            return dict(self._map)


# ---------------------------------------------------------------------------
# Object descriptor — normalised internal representation
# ---------------------------------------------------------------------------

class _ObjectDescriptor:
    """Internal compact representation of one observed object extracted
    from a FusedObject or Phase4DObject.

    Only holds what is needed to create/update ObjectMemoryEntry and
    ObjectFeatureSet.  No raw sensor data.
    """
    __slots__ = (
        "track_id", "fused_id", "object_type", "confidence",
        "pos_x", "pos_y", "pos_z",
        "length", "width", "height",
        "speed_ms", "heading_rad",
        "appearance_label",
        "timestamp",
    )

    def __init__(
        self,
        *,
        track_id: Optional[str],
        fused_id: str,
        object_type: str,
        confidence: float,
        pos_x: Optional[float],
        pos_y: Optional[float],
        pos_z: Optional[float],
        length: Optional[float],
        width: Optional[float],
        height: Optional[float],
        speed_ms: Optional[float],
        heading_rad: Optional[float],
        appearance_label: Optional[str],
        timestamp: float,
    ) -> None:
        self.track_id = track_id
        self.fused_id = fused_id
        self.object_type = object_type
        self.confidence = confidence
        self.pos_x = pos_x
        self.pos_y = pos_y
        self.pos_z = pos_z
        self.length = length
        self.width = width
        self.height = height
        self.speed_ms = speed_ms
        self.heading_rad = heading_rad
        self.appearance_label = appearance_label
        self.timestamp = timestamp

    @property
    def identity_key(self) -> str:
        """Key used for track→memory identity lookup."""
        return self.track_id if self.track_id else self.fused_id


# ---------------------------------------------------------------------------
# Helper: extract _ObjectDescriptor from a FusedObject
# ---------------------------------------------------------------------------

def _descriptor_from_fused(fused_obj) -> Optional["_ObjectDescriptor"]:
    """Extract a compact _ObjectDescriptor from a FusedObject (Phase 3).

    Returns None if the object lacks a valid position (required minimum).
    Never raises.
    """
    try:
        pos_x = pos_y = pos_z = None
        if fused_obj.position_3d is not None:
            p = fused_obj.position_3d
            pos_x = p.x if _fin(p.x) else None
            pos_y = p.y if _fin(p.y) else None
            pos_z = p.z if _fin(p.z) else None

        if pos_x is None or pos_y is None:
            return None  # need at least x, y

        length = width = height = None
        if fused_obj.dimensions is not None:
            d = fused_obj.dimensions
            length = d.length if _fin_nonneg(d.length) else None
            width = d.width if _fin_nonneg(d.width) else None
            height = d.height if _fin_nonneg(d.height) else None

        speed_ms = None
        if fused_obj.velocity is not None and len(fused_obj.velocity) >= 2:
            vx, vy = fused_obj.velocity[0], fused_obj.velocity[1]
            if _fin(vx) and _fin(vy):
                speed_ms = math.hypot(vx, vy)

        heading_rad = None
        h = getattr(fused_obj, "heading", None)
        if h is not None and _fin(h):
            heading_rad = float(h)

        track_id = getattr(fused_obj, "track_id", None)
        track_id = str(track_id) if track_id is not None else None

        return _ObjectDescriptor(
            track_id=track_id,
            fused_id=str(fused_obj.fused_object_id),
            object_type=str(fused_obj.object_class or NOT_AVAILABLE),
            confidence=float(fused_obj.class_confidence or 0.0),
            pos_x=pos_x,
            pos_y=pos_y,
            pos_z=pos_z,
            length=length,
            width=width,
            height=height,
            speed_ms=speed_ms,
            heading_rad=heading_rad,
            appearance_label=None,
            timestamp=float(fused_obj.timestamp or time.time()),
        )
    except Exception as exc:
        _log().debug("_descriptor_from_fused: skipped object: %s", exc)
        return None


def _descriptor_from_phase4d_object(obj4d) -> Optional["_ObjectDescriptor"]:
    """Extract a compact _ObjectDescriptor from a Phase4DObject.

    Uses the richer prediction-layer motion (MotionState.speed,
    MotionState.heading) and behaviour class when available.  Falls
    back to FusedObject fields for geometry.

    Never raises.
    """
    try:
        phase4c = obj4d.phase4c
        predicted = phase4c.predicted
        current_state = predicted.current_state

        pos_x = pos_y = pos_z = None
        if _fin(current_state.x) and _fin(current_state.y):
            pos_x = current_state.x
            pos_y = current_state.y
            pos_z = current_state.z if _fin(current_state.z) else None
        else:
            return None

        speed_ms = None
        if _fin(current_state.speed) and current_state.speed >= 0:
            speed_ms = current_state.speed

        heading_rad = None
        if _fin(current_state.heading):
            heading_rad = current_state.heading

        # Object type: prefer behaviour_class (more specific) then predicted type
        behaviour_class = getattr(phase4c, "behaviour_class", None)
        if behaviour_class is not None:
            object_type = str(behaviour_class.value)
        else:
            object_type = str(predicted.object_type or NOT_AVAILABLE)

        confidence = float(predicted.prediction_confidence or 0.0)

        # Geometry: not directly on Phase4DObject, use None (no fused dims here)
        # (Phase4D does not carry a FusedObject reference by default)
        length = width = height = None

        track_id = str(predicted.track_id) if predicted.track_id else None

        return _ObjectDescriptor(
            track_id=track_id,
            fused_id=track_id or f"p4d_{id(obj4d)}",
            object_type=object_type,
            confidence=confidence,
            pos_x=pos_x,
            pos_y=pos_y,
            pos_z=pos_z,
            length=length,
            width=width,
            height=height,
            speed_ms=speed_ms,
            heading_rad=heading_rad,
            appearance_label=None,
            timestamp=float(current_state.timestamp or time.time()),
        )
    except Exception as exc:
        _log().debug("_descriptor_from_phase4d_object: skipped object: %s", exc)
        return None


# ---------------------------------------------------------------------------
# Numeric helpers
# ---------------------------------------------------------------------------

def _fin(v) -> bool:
    """True iff v is a finite real number."""
    return isinstance(v, (int, float)) and not isinstance(v, bool) and math.isfinite(v)


def _fin_nonneg(v) -> bool:
    return _fin(v) and v >= 0.0


# ---------------------------------------------------------------------------
# MemoryIntegration
# ---------------------------------------------------------------------------

class MemoryIntegration:
    """Phase 5.4 Memory Integration Layer.

    Orchestrates ObjectMemory (Phase 5.1), PrototypeMemory (Phase 5.2),
    and ExperienceRetriever (Phase 5.3B) using the current fused/predicted
    world state.

    Parameters
    ----------
    object_memory:
        Injected Phase 5.1 ObjectMemory.  A fresh default instance is
        created if None.
    prototype_memory:
        Injected Phase 5.2 PrototypeMemory.  A fresh default instance is
        created if None.
    retriever:
        Injected Phase 5.3B ExperienceRetriever.  A default retriever
        (sharing the same object/prototype memory instances) is created
        if None.
    config:
        MemoryIntegrationConfig (or None → load from config file).
    """

    def __init__(
        self,
        *,
        object_memory: Optional[ObjectMemory] = None,
        prototype_memory: Optional[PrototypeMemory] = None,
        retriever: Optional[ExperienceRetriever] = None,
        config: Optional[MemoryIntegrationConfig] = None,
    ) -> None:
        self._config = config if config is not None else MemoryIntegrationConfig()

        # Instantiate or accept injected subsystems
        self._object_memory: ObjectMemory = (
            object_memory if object_memory is not None else ObjectMemory()
        )
        self._prototype_memory: PrototypeMemory = (
            prototype_memory if prototype_memory is not None else PrototypeMemory()
        )
        # The retriever shares the same stores so it sees the same data
        self._retriever: ExperienceRetriever = (
            retriever if retriever is not None
            else ExperienceRetriever(
                object_memory=self._object_memory,
                prototype_memory=self._prototype_memory,
            )
        )

        # Track → memory identity index (prevents duplicate entries per frame)
        self._track_index = _TrackIndex()

        # Cumulative runtime stats
        self._stats = MemoryIntegrationStats()
        self._stats_lock = threading.Lock()

        _log().debug(
            "MemoryIntegration initialised — enabled=%s retrieval=%s",
            self._config.enabled,
            self._config.retrieval_enabled,
        )

    # ------------------------------------------------------------------
    # Primary API
    # ------------------------------------------------------------------

    def process(
        self,
        world_state,
        *,
        now: Optional[float] = None,
    ) -> MemoryContext:
        """Process one world-state cycle and return a read-only MemoryContext.

        Accepts either:
          * FusedWorldState (Phase 3) — ``world_state.objects`` contains
            FusedObject instances.
          * Phase4DWorldState (Phase 4D) — ``world_state.objects`` contains
            Phase4DObject instances.

        The method is deterministic for a given memory state: same
        world_state input → same MemoryContext output (object ordering
        follows identity key sort).

        Parameters
        ----------
        world_state:
            FusedWorldState or Phase4DWorldState (or any object with a
            ``.timestamp``, ``.frame_id``, and ``.objects`` list).
        now:
            Override wall-clock time for deterministic testing.

        Returns
        -------
        MemoryContext:
            Always returns a MemoryContext — never raises.  Returns a
            degraded / empty context if memory is disabled or fails.
        """
        t_start = time.perf_counter()
        cycle_ts = now if now is not None else time.time()

        frame_id = int(getattr(world_state, "frame_id", 0))
        ws_timestamp = float(getattr(world_state, "timestamp", cycle_ts))

        if not self._config.enabled:
            return MemoryContext.empty(
                timestamp=ws_timestamp,
                frame_id=frame_id,
                status=MemoryContextStatus.DISABLED,
                reason="memory integration disabled",
            )

        # --- Step 1: extract object descriptors --------------------------------
        descriptors = self._extract_descriptors(world_state)

        # --- Step 2: update Object Memory (Phase 5.1) -------------------------
        obj_refs, obj_status = self._update_object_memory(descriptors, cycle_ts)

        # --- Step 3: update Prototype Memory (Phase 5.2) ----------------------
        proto_status = self._update_prototype_memory(descriptors, cycle_ts)

        # --- Step 4: build current situation (Phase 5.3A) ---------------------
        # Build one current situation per descriptor, then pick the one
        # most likely to produce useful retrievals.  For now we retrieve
        # once per cycle using the object with highest confidence in the
        # current world state (representative situation).
        situations = self._build_situations(descriptors, ws_timestamp)

        # --- Step 5: experience retrieval (Phase 5.3B) ------------------------
        retrieved, ret_status, ret_candidate_count = self._retrieve_experiences(
            situations, descriptors
        )

        # --- Step 6: build prototype refs (from current prototype store) ------
        proto_refs = self._collect_prototype_refs(descriptors)

        # --- Step 7: tick object memory lifecycle (non-blocking) --------------
        try:
            self._object_memory.tick(now=cycle_ts)
        except Exception as exc:
            _log().debug("object_memory.tick() failed: %s", exc)

        # --- Step 8: assemble metadata & context ------------------------------
        t_end = time.perf_counter()
        duration = t_end - t_start

        # Determine overall status
        object_count = self._safe_object_count()
        proto_count = self._safe_proto_count()

        subsystem_statuses = [obj_status, proto_status, ret_status]
        if all(s == "AVAILABLE" for s in subsystem_statuses):
            if object_count == 0 and proto_count == 0 and len(retrieved) == 0:
                ctx_status = MemoryContextStatus.EMPTY
            else:
                ctx_status = MemoryContextStatus.AVAILABLE
        elif any(s == "FAILED" for s in subsystem_statuses):
            ctx_status = MemoryContextStatus.PARTIAL
        else:
            ctx_status = MemoryContextStatus.AVAILABLE

        meta = MemoryContextMetadata(
            object_memory_count=object_count,
            prototype_count=proto_count,
            retrieval_candidate_count=ret_candidate_count,
            retrieval_result_count=len(retrieved),
            object_memory_status=obj_status,
            prototype_memory_status=proto_status,
            retrieval_status=ret_status,
            context_status=ctx_status,
            integration_duration_s=duration,
        )

        # Update cumulative stats
        with self._stats_lock:
            self._stats.cycles_processed += 1
            self._stats.objects_processed += len(descriptors)
            if ctx_status == MemoryContextStatus.PARTIAL:
                self._stats.degraded_cycles += 1

        ctx = MemoryContext(
            timestamp=ws_timestamp,
            frame_id=frame_id,
            objects=obj_refs,
            prototypes=proto_refs,
            similar_experiences=retrieved,
            metadata=meta,
            integration_schema_version=INTEGRATION_SCHEMA_VERSION,
        )
        return ctx

    # ------------------------------------------------------------------
    # Step 1: extract object descriptors
    # ------------------------------------------------------------------

    def _extract_descriptors(self, world_state) -> List[_ObjectDescriptor]:
        """Extract compact descriptors from the world state's object list.

        Tries Phase4DObject extraction first (richer motion), then falls
        back to FusedObject extraction.  Invalid or position-less objects
        are silently skipped.  Results are sorted by identity_key for
        determinism.
        """
        raw_objects = getattr(world_state, "objects", []) or []
        descriptors: List[_ObjectDescriptor] = []

        for obj in raw_objects:
            desc = None
            # Phase4DObject has a .phase4c attribute
            if hasattr(obj, "phase4c"):
                desc = _descriptor_from_phase4d_object(obj)
            # FusedObject has .fused_object_id
            elif hasattr(obj, "fused_object_id"):
                desc = _descriptor_from_fused(obj)
            # Fallback: unknown object type — skip
            else:
                _log().debug("_extract_descriptors: unknown object type %s", type(obj).__name__)

            if desc is not None:
                descriptors.append(desc)

        # Sort deterministically
        descriptors.sort(key=lambda d: d.identity_key)
        return descriptors

    # ------------------------------------------------------------------
    # Step 2: Object Memory update
    # ------------------------------------------------------------------

    def _update_object_memory(
        self,
        descriptors: List[_ObjectDescriptor],
        now: float,
    ) -> tuple[List[ObjectMemoryRef], str]:
        """Add or update ObjectMemoryEntry for each descriptor.

        Returns (list of ObjectMemoryRef, status_string).
        """
        obj_refs: List[ObjectMemoryRef] = []
        status = "AVAILABLE"

        for desc in descriptors:
            try:
                ref = self._process_one_object(desc, now)
                if ref is not None:
                    obj_refs.append(ref)
            except Exception as exc:
                _log().warning("object memory update failed for %s: %s", desc.fused_id, exc)
                with self._stats_lock:
                    self._stats.object_memory_failures += 1
                status = "DEGRADED"

        # Also collect existing memory refs for objects not in this frame
        # (they remain in memory until lifecycle expiry)
        try:
            all_entries = self._object_memory.list()
            existing_ids = {r.memory_id for r in obj_refs}
            for entry in all_entries:
                if entry.memory_id not in existing_ids:
                    if entry.lifecycle_state != MemoryLifecycleState.EXPIRED:
                        ref = ObjectMemoryRef.from_entry(entry)
                        obj_refs.append(ref)
        except Exception as exc:
            _log().debug("listing existing object memory failed: %s", exc)
            status = "DEGRADED"

        return obj_refs, status

    def _process_one_object(
        self,
        desc: _ObjectDescriptor,
        now: float,
    ) -> Optional[ObjectMemoryRef]:
        """Create or update one ObjectMemoryEntry for a descriptor.

        Uses track_id (from track_index) to prevent duplicate entries
        for repeatedly observed objects.  Returns a compact ref.
        """
        identity_key = desc.identity_key
        existing_memory_id = self._track_index.get(identity_key)

        position = MemoryPositionSummary(
            x=desc.pos_x,
            y=desc.pos_y,
            z=desc.pos_z,
        )
        dimensions = None
        if desc.length is not None or desc.width is not None or desc.height is not None:
            dimensions = MemoryDimensions(
                length=desc.length,
                width=desc.width,
                height=desc.height,
            )
        motion = None
        if desc.speed_ms is not None or desc.heading_rad is not None:
            motion = MemoryMotionSummary(
                speed_ms=desc.speed_ms,
                heading_rad=desc.heading_rad,
                acceleration_ms2=None,
            )

        if existing_memory_id and self._object_memory.exists(existing_memory_id):
            # --- UPDATE existing entry ---
            existing = self._object_memory.get(existing_memory_id)
            if existing is None:
                # Race: entry was removed between exists() and get()
                existing_memory_id = None
            else:
                import dataclasses
                updated = dataclasses.replace(
                    existing,
                    confidence=desc.confidence,
                    object_type=desc.object_type,
                    position=position,
                    dimensions=dimensions if dimensions is not None else existing.dimensions,
                    motion=motion if motion is not None else existing.motion,
                    appearance_label=(
                        desc.appearance_label if desc.appearance_label is not None
                        else existing.appearance_label
                    ),
                    observed_at=desc.timestamp,
                    updated_at=now,
                    lifecycle_state=MemoryLifecycleState.ACTIVE,
                )
                op = self._object_memory.update(existing_memory_id, updated)
                if op.ok:
                    with self._stats_lock:
                        self._stats.object_memory_updates += 1
                    return ObjectMemoryRef.from_entry(updated)
                else:
                    _log().debug("object_memory.update() failed: %s", op.reason)
                    # Fall through to add as new
                    existing_memory_id = None

        if not existing_memory_id:
            # --- ADD new entry ---
            new_id = self._object_memory.new_id(hint=identity_key)
            entry = ObjectMemoryEntry(
                memory_id=new_id,
                track_id=desc.track_id,
                source=self._config.source_tag,
                object_type=desc.object_type,
                confidence=desc.confidence,
                position=position,
                dimensions=dimensions,
                motion=motion,
                appearance_label=desc.appearance_label,
                observed_at=desc.timestamp,
            )
            op = self._object_memory.add(entry)
            if op.ok:
                self._track_index.set(identity_key, new_id)
                with self._stats_lock:
                    self._stats.object_memory_adds += 1
                return ObjectMemoryRef.from_entry(entry)
            else:
                _log().debug("object_memory.add() failed: %s", op.reason)

        return None

    # ------------------------------------------------------------------
    # Step 3: Prototype Memory update
    # ------------------------------------------------------------------

    def _update_prototype_memory(
        self,
        descriptors: List[_ObjectDescriptor],
        now: float,
    ) -> str:
        """Update PrototypeMemory for each descriptor.

        Returns status string: "AVAILABLE" | "DEGRADED" | "FAILED".
        """
        status = "AVAILABLE"
        for desc in descriptors:
            try:
                feature = self._build_feature_set(desc)
                if feature is None:
                    continue
                op = self._prototype_memory.observe(feature, observed_at=now)
                with self._stats_lock:
                    if op.ok:
                        self._stats.prototype_observations += 1
                    else:
                        self._stats.prototype_failures += 1
            except Exception as exc:
                _log().warning(
                    "prototype memory update failed for %s: %s", desc.fused_id, exc
                )
                with self._stats_lock:
                    self._stats.prototype_failures += 1
                status = "DEGRADED"
        return status

    def _build_feature_set(
        self, desc: _ObjectDescriptor
    ) -> Optional[ObjectFeatureSet]:
        """Build an ObjectFeatureSet from a descriptor.

        Returns None if the descriptor lacks enough information to form
        a meaningful feature observation.
        """
        if desc.object_type in (NOT_AVAILABLE, "", None):
            return None

        geometry: Optional[GeometryFeature] = None
        if any(v is not None for v in (desc.length, desc.width, desc.height)):
            ar = None
            if desc.length is not None and desc.width is not None and desc.width > 0:
                ar = desc.length / desc.width
            geometry = GeometryFeature(
                length=desc.length,
                width=desc.width,
                height=desc.height,
                aspect_ratio=ar,
            )

        motion: Optional[MotionFeature] = None
        if desc.speed_ms is not None or desc.heading_rad is not None:
            mc = MotionClass.UNKNOWN
            if desc.speed_ms is not None and _fin_nonneg(desc.speed_ms):
                if desc.speed_ms < 0.5:
                    mc = MotionClass.STATIONARY
                elif desc.speed_ms < 3.0:
                    mc = MotionClass.SLOW
                elif desc.speed_ms < 15.0:
                    mc = MotionClass.NORMAL
                else:
                    mc = MotionClass.FAST
            motion = MotionFeature(
                typical_speed_ms=desc.speed_ms,
                heading_rad=desc.heading_rad,
                motion_class=mc,
            )

        # Need at least geometry or motion to form a useful prototype obs
        if geometry is None and motion is None:
            return None

        return ObjectFeatureSet(
            object_type=desc.object_type,
            geometry=geometry,
            motion=motion,
            confidence=desc.confidence,
        )

    # ------------------------------------------------------------------
    # Step 4: build current situations
    # ------------------------------------------------------------------

    def _build_situations(
        self,
        descriptors: List[_ObjectDescriptor],
        timestamp: float,
    ) -> List[CurrentSituation]:
        """Build CurrentSituation instances for each descriptor.

        Uses existing Phase 5.3A types directly — no duplication.
        """
        situations: List[CurrentSituation] = []
        for desc in descriptors:
            if desc.object_type in (NOT_AVAILABLE, "", None):
                continue
            geometry: Optional[GeometryFeature] = None
            if any(v is not None for v in (desc.length, desc.width, desc.height)):
                ar = None
                if desc.length is not None and desc.width is not None and desc.width > 0:
                    ar = desc.length / desc.width
                geometry = GeometryFeature(
                    length=desc.length,
                    width=desc.width,
                    height=desc.height,
                    aspect_ratio=ar,
                )
            motion: Optional[MotionFeature] = None
            if desc.speed_ms is not None or desc.heading_rad is not None:
                mc = MotionClass.UNKNOWN
                if desc.speed_ms is not None and _fin_nonneg(desc.speed_ms):
                    if desc.speed_ms < 0.5:
                        mc = MotionClass.STATIONARY
                    elif desc.speed_ms < 3.0:
                        mc = MotionClass.SLOW
                    elif desc.speed_ms < 15.0:
                        mc = MotionClass.NORMAL
                    else:
                        mc = MotionClass.FAST
                motion = MotionFeature(
                    typical_speed_ms=desc.speed_ms,
                    heading_rad=desc.heading_rad,
                    motion_class=mc,
                )
            sit = CurrentSituation(
                object_type=desc.object_type,
                geometry=geometry,
                motion=motion,
                confidence=desc.confidence,
                source=self._config.source_tag,
                timestamp=timestamp,
            )
            situations.append(sit)
        return situations

    # ------------------------------------------------------------------
    # Step 5: experience retrieval
    # ------------------------------------------------------------------

    def _retrieve_experiences(
        self,
        situations: List[CurrentSituation],
        descriptors: List[_ObjectDescriptor],
    ) -> tuple[List[RetrievalResult], str, int]:
        """Retrieve similar experiences for the current situation.

        For the current cycle we retrieve using the highest-confidence
        situation (representative of the most certain observation).

        Returns (results, status_string, candidate_count).
        """
        if not self._config.retrieval_enabled:
            return [], "DISABLED", 0

        if not situations:
            return [], "AVAILABLE", 0

        # Pick the representative situation: highest confidence, then first
        rep_situation = max(situations, key=lambda s: s.confidence)

        try:
            # candidate_count is the total object memory size before filtering
            candidate_count = len(self._object_memory.list_ids())
            results = self._retriever.retrieve(rep_situation)
            with self._stats_lock:
                self._stats.retrieval_calls += 1
                self._stats.retrieval_results += len(results)
            return results, "AVAILABLE", candidate_count
        except Exception as exc:
            _log().warning("experience retrieval failed: %s", exc)
            with self._stats_lock:
                self._stats.retrieval_failures += 1
            return [], "FAILED", 0

    # ------------------------------------------------------------------
    # Collect prototype refs for current object types
    # ------------------------------------------------------------------

    def _collect_prototype_refs(
        self, descriptors: List[_ObjectDescriptor]
    ) -> List[PrototypeRef]:
        """Return PrototypeRef for each distinct object_type in this cycle."""
        seen_types: set = set()
        refs: List[PrototypeRef] = []
        for desc in descriptors:
            ot = desc.object_type
            if not ot or ot == NOT_AVAILABLE or ot in seen_types:
                continue
            seen_types.add(ot)
            try:
                proto = self._prototype_memory.get_for(ot)
                if proto is not None:
                    refs.append(PrototypeRef.from_prototype(proto))
            except Exception as exc:
                _log().debug("prototype lookup failed for %s: %s", ot, exc)
        return refs

    # ------------------------------------------------------------------
    # Safe count helpers (never raise)
    # ------------------------------------------------------------------

    def _safe_object_count(self) -> int:
        try:
            return len(self._object_memory.list_ids())
        except Exception:
            return 0

    def _safe_proto_count(self) -> int:
        try:
            return len(self._prototype_memory.list_keys())
        except Exception:
            return 0

    # ------------------------------------------------------------------
    # Read-only properties
    # ------------------------------------------------------------------

    @property
    def config(self) -> MemoryIntegrationConfig:
        return self._config

    @property
    def object_memory(self) -> ObjectMemory:
        """Direct access to the underlying ObjectMemory (read-only intent)."""
        return self._object_memory

    @property
    def prototype_memory(self) -> PrototypeMemory:
        """Direct access to the underlying PrototypeMemory (read-only intent)."""
        return self._prototype_memory

    @property
    def retriever(self) -> ExperienceRetriever:
        """Direct access to the ExperienceRetriever."""
        return self._retriever

    @property
    def enabled(self) -> bool:
        return self._config.enabled

    # ------------------------------------------------------------------
    # Runtime stats
    # ------------------------------------------------------------------

    def stats(self) -> MemoryIntegrationStats:
        """Return a snapshot copy of cumulative runtime statistics."""
        with self._stats_lock:
            import copy
            return copy.copy(self._stats)

    # ------------------------------------------------------------------
    # Observability summary (for health endpoints)
    # ------------------------------------------------------------------

    def observability(self) -> dict:
        """Return a lightweight dict suitable for a health/observability
        endpoint.  No invented values."""
        s = self.stats()
        return {
            "memory_enabled": self._config.enabled,
            "retrieval_enabled": self._config.retrieval_enabled,
            "object_memory_count": self._safe_object_count(),
            "prototype_count": self._safe_proto_count(),
            "cycles_processed": s.cycles_processed,
            "objects_processed": s.objects_processed,
            "retrieval_calls": s.retrieval_calls,
            "retrieval_results": s.retrieval_results,
            "degraded_cycles": s.degraded_cycles,
        }
