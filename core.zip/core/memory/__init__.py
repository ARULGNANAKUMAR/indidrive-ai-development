"""
IndiDrive AI — Phase 5.1 / 5.2 | Object Memory Package
=========================================================
Public surface of the core.memory package.

Phase 5.1 exports the individual Object Memory Core. Phase 5.2 adds
the Feature / Prototype Memory layer on top, in its own submodules
(feature_types, prototype_types, prototype_store, prototype_memory)
without modifying any Phase 5.1 file. Later phases (5.3 …) will add
their own submodules without changing this file.
"""
from .memory_types import (
    MEMORY_SCHEMA_VERSION,
    MemoryLifecycleState,
    MemoryCleanupPolicy,
    MemoryPositionSummary,
    MemoryDimensions,
    MemoryMotionSummary,
    ObjectMemoryEntry,
    MemoryOperationResult,
    MemoryStoreStats,
)
from .memory_store import MemoryStore, InMemoryStore
from .memory_validation import validate_entry
from .object_memory import ObjectMemory

# --- Phase 5.2 ---------------------------------------------------------
from .feature_types import (
    FEATURE_SCHEMA_VERSION,
    DEFAULT_MAX_DESCRIPTOR_DIM,
    MotionClass,
    GeometryFeature,
    ShapeFeature,
    AppearanceFeature,
    MotionFeature,
    ObjectFeatureSet,
    validate_feature_set,
    feature_distance,
)
from .prototype_types import (
    PROTOTYPE_SCHEMA_VERSION,
    ObjectPrototype,
    prototype_key_for,
    update_prototype,
)
from .prototype_store import PrototypeStore, InMemoryPrototypeStore
from .prototype_memory import PrototypeMemory

# --- Phase 5.3A ---------------------------------------------------------
from .situation_types import (
    SITUATION_SCHEMA_VERSION,
    CurrentSituation,
    SituationValidationResult,
    validate_situation,
)
from .similarity_engine import (
    SimilarityWeights,
    DEFAULT_SIMILARITY_WEIGHTS,
    SimilarityResult,
    SimilarityEngine,
    compute_similarity,
)

# --- Phase 5.3B ---------------------------------------------------------
from .retrieval_types import (
    RETRIEVAL_SCHEMA_VERSION,
    RetrievalResult,
)
from .retrieval_engine import ExperienceRetriever

# --- Phase 5.4 ----------------------------------------------------------
from .integration_types import (
    INTEGRATION_SCHEMA_VERSION,
    MemoryContextStatus,
    ObjectMemoryRef,
    PrototypeRef,
    MemoryContextMetadata,
    MemoryContext,
    MemoryIntegrationStats,
)
from .memory_integration import MemoryIntegration, MemoryIntegrationConfig

# --- Phase 8.3 ---------------------------------------------------------
from .context_feature_types import (
    CONTEXT_RISK_SCHEMA_VERSION,
    RoadTypeClass,
    TrafficDensityClass,
    RoadMarkingClass,
    IntersectionClass,
    RoadDamageClass,
    RiskLevelClass,
    TtcBandClass,
    ContextFeature,
    RiskFeature,
    validate_context_feature,
    validate_risk_feature,
)
from .feature_normalizer import (
    NORMALIZER_VERSION,
    VECTOR_DIM,
    FEATURE_NAMES,
    SituationFeatureVector,
    FeatureNormalizer,
    NormalizerConfig,
)
from .scene_feature_memory import (
    SCENE_MEMORY_SCHEMA_VERSION,
    ScenePrototype,
    SimilarityMatch,
    SceneMemoryStats,
    SceneFeatureMemory,
)

__all__ = [
    # Phase 5.1
    "MEMORY_SCHEMA_VERSION",
    "MemoryLifecycleState",
    "MemoryCleanupPolicy",
    "MemoryPositionSummary",
    "MemoryDimensions",
    "MemoryMotionSummary",
    "ObjectMemoryEntry",
    "MemoryOperationResult",
    "MemoryStoreStats",
    "MemoryStore",
    "InMemoryStore",
    "validate_entry",
    "ObjectMemory",
    # Phase 5.2
    "FEATURE_SCHEMA_VERSION",
    "DEFAULT_MAX_DESCRIPTOR_DIM",
    "MotionClass",
    "GeometryFeature",
    "ShapeFeature",
    "AppearanceFeature",
    "MotionFeature",
    "ObjectFeatureSet",
    "validate_feature_set",
    "feature_distance",
    "PROTOTYPE_SCHEMA_VERSION",
    "ObjectPrototype",
    "prototype_key_for",
    "update_prototype",
    "PrototypeStore",
    "InMemoryPrototypeStore",
    "PrototypeMemory",
    # Phase 5.3A
    "SITUATION_SCHEMA_VERSION",
    "CurrentSituation",
    "SituationValidationResult",
    "validate_situation",
    "SimilarityWeights",
    "DEFAULT_SIMILARITY_WEIGHTS",
    "SimilarityResult",
    "SimilarityEngine",
    "compute_similarity",
    # Phase 5.3B
    "RETRIEVAL_SCHEMA_VERSION",
    "RetrievalResult",
    "ExperienceRetriever",
    # Phase 5.4
    "INTEGRATION_SCHEMA_VERSION",
    "MemoryContextStatus",
    "ObjectMemoryRef",
    "PrototypeRef",
    "MemoryContextMetadata",
    "MemoryContext",
    "MemoryIntegrationStats",
    "MemoryIntegration",
    "MemoryIntegrationConfig",
    # Phase 8.3
    "CONTEXT_RISK_SCHEMA_VERSION",
    "RoadTypeClass",
    "TrafficDensityClass",
    "RoadMarkingClass",
    "IntersectionClass",
    "RoadDamageClass",
    "RiskLevelClass",
    "TtcBandClass",
    "ContextFeature",
    "RiskFeature",
    "validate_context_feature",
    "validate_risk_feature",
    "NORMALIZER_VERSION",
    "VECTOR_DIM",
    "FEATURE_NAMES",
    "SituationFeatureVector",
    "FeatureNormalizer",
    "NormalizerConfig",
    "SCENE_MEMORY_SCHEMA_VERSION",
    "ScenePrototype",
    "SimilarityMatch",
    "SceneMemoryStats",
    "SceneFeatureMemory",
]
