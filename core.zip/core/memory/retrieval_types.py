"""
IndiDrive AI — Phase 5.3B | Experience Retrieval Types
========================================================
Compact data contracts for the experience retrieval layer.

Pipeline context:

    CurrentSituation  (Phase 5.3A)
        ↓
    ExperienceRetriever  (this phase — retrieval_engine.py)
        ↓
    RetrievalResult  (this module)
        ↓
    Phase 5.4 Memory Integration  (future)

Design rules (same as all prior phases):
  * compact — no raw sensor data, no large tensors
  * deterministic — same input → same output
  * serialisable — to_dict() / from_dict()
  * offline-first — no cloud, no LLM, no vector DB
  * optional fields are None, not fabricated
"""
from __future__ import annotations

import json
import math
from dataclasses import dataclass, field
from typing import Any, Dict, Optional

from core.perception.perception_types import NOT_AVAILABLE

__all__ = [
    "RETRIEVAL_SCHEMA_VERSION",
    "RetrievalResult",
]

# Increment when the serialised schema changes in a breaking way.
RETRIEVAL_SCHEMA_VERSION: int = 1


@dataclass
class RetrievalResult:
    """Compact result for one retrieved experience.

    Contains only the information downstream systems need — no raw
    camera frames, no raw LiDAR, no large tensors.

    Fields
    ------
    memory_id:
        Stable persistent ID of the retrieved ObjectMemoryEntry.
    prototype_key:
        Prototype key (object_type or object_type::subtype) of the
        matched ObjectPrototype.  None if the match was against a
        raw ObjectFeatureSet.
    object_type:
        Object type string (e.g. "CAR", "PEDESTRIAN") from the
        retrieved experience.
    similarity:
        Overall similarity score in [0.0, 1.0] from Phase 5.3A.
    matched_features:
        Per-component similarity breakdown from Phase 5.3A
        (e.g. {"object_type": 1.0, "geometry": 0.87, "motion": "unavailable"}).
        Useful for explainability / debugging.
    confidence:
        Observation confidence of the retrieved experience in [0.0, 1.0].
        None if not available.
    timestamp:
        Wall-clock time (seconds since epoch) of the original observation.
        None if not available.
    retrieval_schema_version:
        Schema version for forward compatibility.
    """

    # Required — set by the retriever
    memory_id: str
    similarity: float

    # Optional — filled from stored experience where available
    prototype_key: Optional[str] = None
    object_type: str = NOT_AVAILABLE
    matched_features: Dict[str, Any] = field(default_factory=dict)
    confidence: Optional[float] = None
    timestamp: Optional[float] = None

    # Schema
    retrieval_schema_version: int = RETRIEVAL_SCHEMA_VERSION

    # -----------------------------------------------------------------------
    # Validation helpers
    # -----------------------------------------------------------------------

    def is_valid_similarity(self) -> bool:
        return (
            isinstance(self.similarity, (int, float))
            and not isinstance(self.similarity, bool)
            and math.isfinite(self.similarity)
            and 0.0 <= self.similarity <= 1.0
        )

    # -----------------------------------------------------------------------
    # Serialisation
    # -----------------------------------------------------------------------

    def to_dict(self) -> dict:
        return {
            "retrieval_schema_version": self.retrieval_schema_version,
            "memory_id": self.memory_id,
            "prototype_key": (
                self.prototype_key if self.prototype_key is not None else NOT_AVAILABLE
            ),
            "object_type": self.object_type,
            "similarity": round(self.similarity, 6),
            "matched_features": {
                k: (round(v, 6) if isinstance(v, float) else v)
                for k, v in self.matched_features.items()
            },
            "confidence": (
                round(self.confidence, 6) if self.confidence is not None else NOT_AVAILABLE
            ),
            "timestamp": (
                self.timestamp if self.timestamp is not None else NOT_AVAILABLE
            ),
        }

    def to_json(self) -> str:
        """Deterministic JSON serialisation (sorted keys)."""
        return json.dumps(self.to_dict(), sort_keys=True)

    @staticmethod
    def from_dict(d: dict) -> "RetrievalResult":
        """Deserialise from a dict produced by to_dict()."""
        schema_ver = int(d.get("retrieval_schema_version", 0))
        if schema_ver != RETRIEVAL_SCHEMA_VERSION:
            raise ValueError(
                f"Unsupported retrieval_schema_version={schema_ver}; "
                f"expected {RETRIEVAL_SCHEMA_VERSION}"
            )
        memory_id = d.get("memory_id", "")
        if not memory_id or not isinstance(memory_id, str):
            raise ValueError("memory_id is missing or not a string")

        def _opt_str(v):
            return v if (isinstance(v, str) and v != NOT_AVAILABLE) else None

        def _opt_float(v):
            if v in (None, NOT_AVAILABLE):
                return None
            try:
                f = float(v)
                return f if math.isfinite(f) else None
            except (TypeError, ValueError):
                return None

        return RetrievalResult(
            memory_id=memory_id,
            similarity=float(d.get("similarity", 0.0)),
            prototype_key=_opt_str(d.get("prototype_key")),
            object_type=d.get("object_type", NOT_AVAILABLE),
            matched_features=dict(d.get("matched_features", {})),
            confidence=_opt_float(d.get("confidence")),
            timestamp=_opt_float(d.get("timestamp")),
            retrieval_schema_version=schema_ver,
        )

    def __repr__(self) -> str:
        return (
            f"RetrievalResult(memory_id={self.memory_id!r}, "
            f"similarity={self.similarity:.4f}, "
            f"object_type={self.object_type!r})"
        )
