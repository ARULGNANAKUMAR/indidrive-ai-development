"""
IndiDrive AI — Phase 5.1 | Object Memory Core
==============================================
The main public API for the Object Memory layer.  ObjectMemory wraps a
MemoryStore and adds:

  * identity generation (deterministic, unique memory IDs)
  * lifecycle management (NEW → ACTIVE → STALE → EXPIRED)
  * bounded capacity with a configurable cleanup policy
  * configuration integration (uses existing core.config_loader)
  * structured logging via existing core.logging_system
  * thread safety (delegated to InMemoryStore)

Usage::

    from core.memory.object_memory import ObjectMemory
    from core.memory.memory_types import ObjectMemoryEntry

    mem = ObjectMemory()
    entry = ObjectMemoryEntry(memory_id=mem.new_id(), object_type="CAR", ...)
    result = mem.add(entry)
    entry = mem.get(result.memory_id)
    mem.cleanup()

This is OFFLINE-FIRST — no network, no cloud, no external database.

Phase boundary:  Phase 5.1 only.
Do NOT add retrieval, similarity, prototypes, or learning here.
"""
from __future__ import annotations

import hashlib
import logging
import threading
import time
import uuid
from typing import Dict, List, Optional

from core.config_loader import get as _cfg_get
from core.logging_system import get_logger as _get_logger

from .memory_types import (
    ObjectMemoryEntry,
    MemoryLifecycleState,
    MemoryCleanupPolicy,
    MemoryOperationResult,
    MemoryStoreStats,
    MEMORY_SCHEMA_VERSION,
)
from .memory_store import MemoryStore, InMemoryStore
from .memory_validation import validate_entry

__all__ = ["ObjectMemory"]

# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------

_LOG_CAT = "system"  # reuse existing log category for now


def _log() -> logging.Logger:
    try:
        return _get_logger(_LOG_CAT)
    except Exception:
        return logging.getLogger("indidrive.memory")


# ---------------------------------------------------------------------------
# Config helpers
# ---------------------------------------------------------------------------

_DEFAULT_MAX_ENTRIES: int = 10_000
_DEFAULT_MAX_AGE_S: Optional[float] = 600.0   # 10 minutes; None = unlimited
_DEFAULT_CLEANUP_POLICY: MemoryCleanupPolicy = MemoryCleanupPolicy.STALE_FIRST
_DEFAULT_STALE_AFTER_S: float = 30.0
_DEFAULT_ENABLED: bool = True


def _load_config() -> Dict:
    """Load object_memory section from prediction_config.yaml, or use defaults.
    Does not raise — degrades gracefully to defaults if config is absent."""
    try:
        raw = _cfg_get("prediction", "object_memory")
        if isinstance(raw, dict):
            return raw
    except Exception:
        pass
    return {}


def _resolve_policy(name: str) -> MemoryCleanupPolicy:
    try:
        return MemoryCleanupPolicy(name.upper())
    except (AttributeError, ValueError):
        return _DEFAULT_CLEANUP_POLICY


# ---------------------------------------------------------------------------
# ObjectMemory
# ---------------------------------------------------------------------------

class ObjectMemory:
    """Bounded, thread-safe, offline-first Object Memory.

    Parameters
    ----------
    store : MemoryStore, optional
        Inject a custom store (useful for testing).  Defaults to a
        fresh InMemoryStore.
    max_entries : int, optional
        Maximum number of entries before cleanup.  Overrides config.
    max_age_s : float | None, optional
        Maximum age (seconds) before an entry is expired.  Overrides config.
    cleanup_policy : MemoryCleanupPolicy, optional
        Eviction strategy.  Overrides config.
    stale_after_s : float, optional
        Seconds without update before an entry transitions to STALE.
    enabled : bool, optional
        When False, all mutating operations are no-ops.  Useful for
        disabling memory during tests of other phases.
    """

    def __init__(
        self,
        *,
        store: Optional[MemoryStore] = None,
        max_entries: Optional[int] = None,
        max_age_s: Optional[float] = _DEFAULT_MAX_AGE_S,
        cleanup_policy: Optional[MemoryCleanupPolicy] = None,
        stale_after_s: Optional[float] = None,
        enabled: Optional[bool] = None,
    ) -> None:
        cfg = _load_config()

        self._enabled: bool = (
            enabled if enabled is not None else cfg.get("enabled", _DEFAULT_ENABLED)
        )
        self._max_entries: int = (
            max_entries if max_entries is not None
            else int(cfg.get("max_entries", _DEFAULT_MAX_ENTRIES))
        )
        # None means unlimited age; explicit 0 is treated as unlimited
        raw_age = cfg.get("max_age_seconds", _DEFAULT_MAX_AGE_S)
        if max_age_s is not _DEFAULT_MAX_AGE_S:
            # caller explicitly passed a value (including None)
            self._max_age_s: Optional[float] = max_age_s
        else:
            self._max_age_s = float(raw_age) if raw_age else None

        if cleanup_policy is not None:
            self._cleanup_policy = cleanup_policy
        else:
            raw_policy = cfg.get("cleanup_policy", _DEFAULT_CLEANUP_POLICY.value)
            self._cleanup_policy = _resolve_policy(str(raw_policy))

        self._stale_after_s: float = (
            stale_after_s if stale_after_s is not None
            else float(cfg.get("stale_after_seconds", _DEFAULT_STALE_AFTER_S))
        )

        self._store: MemoryStore = store if store is not None else InMemoryStore()
        # Counter for ID generation (monotonic, thread-safe via _id_lock)
        self._id_counter: int = 0
        self._id_lock: threading.Lock = threading.Lock()

        _log().debug(
            "ObjectMemory initialised",
            extra={
                "max_entries": self._max_entries,
                "max_age_s": self._max_age_s,
                "cleanup_policy": self._cleanup_policy.value,
                "enabled": self._enabled,
                "schema_version": MEMORY_SCHEMA_VERSION,
            } if hasattr(_log(), "debug") else {},
        )

    # -----------------------------------------------------------------------
    # Identity generation
    # -----------------------------------------------------------------------

    def new_id(self, hint: Optional[str] = None) -> str:
        """Generate a unique, deterministic-enough persistent memory ID.

        The ID is based on a UUID4 hex so it is unique across restarts.
        If a hint (e.g. a stable track_id or fused_object_id) is provided,
        it is hashed and incorporated so the caller can derive a stable ID
        from a stable upstream key — useful when the same real-world object
        re-appears after a short gap.

        In Phase 5.1 we do NOT attempt advanced re-identification.  The
        caller decides whether to reuse an existing memory_id or create a
        new one.
        """
        with self._id_lock:
            self._id_counter += 1
            counter = self._id_counter

        if hint:
            # Deterministic from hint + counter so repeated calls with the
            # same hint still produce unique IDs.
            raw = f"{hint}:{counter}"
            digest = hashlib.sha1(raw.encode(), usedforsecurity=False).hexdigest()[:16]
            return f"mem_{digest}"
        else:
            return f"mem_{uuid.uuid4().hex[:16]}"

    # -----------------------------------------------------------------------
    # Core CRUD
    # -----------------------------------------------------------------------

    def add(self, entry: ObjectMemoryEntry) -> MemoryOperationResult:
        """Store a new entry.  Auto-runs cleanup if at capacity first.

        Returns MemoryOperationResult — never raises for invalid input.
        """
        if not self._enabled:
            return MemoryOperationResult.failure("ObjectMemory is disabled")

        result = validate_entry(entry)
        if not result.ok:
            _log().warning("ObjectMemory.add() rejected entry: %s", result.reason)
            return result

        # Enforce capacity before adding
        current = len(self._store.list_ids())
        if current >= self._max_entries:
            removed = self._store.cleanup(
                policy=self._cleanup_policy,
                max_entries=self._max_entries - 1,
                max_age_s=self._max_age_s,
            )
            _log().debug("ObjectMemory capacity cleanup removed %d entries", removed)

        op = self._store.add(entry)
        if op.ok:
            _log().debug("ObjectMemory.add() stored memory_id=%s", entry.memory_id)
        else:
            _log().warning("ObjectMemory.add() failed: %s", op.reason)
        return op

    def get(self, memory_id: str) -> Optional[ObjectMemoryEntry]:
        """Return entry or None."""
        return self._store.get(memory_id)

    def update(
        self, memory_id: str, updated_entry: ObjectMemoryEntry
    ) -> MemoryOperationResult:
        """Replace an existing entry with an updated version.

        The updated_entry must pass validation and its memory_id must
        match the given key.  Callers should set updated_at = time.time()
        before calling this.
        """
        if not self._enabled:
            return MemoryOperationResult.failure("ObjectMemory is disabled")

        result = validate_entry(updated_entry)
        if not result.ok:
            _log().warning("ObjectMemory.update() rejected entry: %s", result.reason)
            return result

        op = self._store.update(memory_id, updated_entry)
        if not op.ok:
            _log().warning("ObjectMemory.update() failed: %s", op.reason)
        return op

    def remove(self, memory_id: str) -> MemoryOperationResult:
        """Delete a memory entry."""
        if not self._enabled:
            return MemoryOperationResult.failure("ObjectMemory is disabled")
        return self._store.remove(memory_id)

    def exists(self, memory_id: str) -> bool:
        """True iff memory_id is currently stored."""
        return self._store.exists(memory_id)

    # -----------------------------------------------------------------------
    # List / inspect
    # -----------------------------------------------------------------------

    def list(self) -> List[ObjectMemoryEntry]:
        """Return a snapshot of all current entries."""
        return self._store.list_entries()

    def list_ids(self) -> List[str]:
        """Return all current memory_ids (sorted)."""
        return self._store.list_ids()

    def stats(self) -> MemoryStoreStats:
        """Return current usage statistics."""
        s = self._store.stats()
        total = s.total_entries
        s.max_capacity = self._max_entries
        s.utilization_fraction = total / self._max_entries if self._max_entries > 0 else 0.0
        return s

    # -----------------------------------------------------------------------
    # Clear (for tests / reset)
    # -----------------------------------------------------------------------

    def clear(self) -> int:
        """Remove all entries.  Returns count removed.
        Safe to call regardless of _enabled flag."""
        return self._store.clear()

    # -----------------------------------------------------------------------
    # Lifecycle management
    # -----------------------------------------------------------------------

    def tick(self, now: Optional[float] = None) -> Dict[str, int]:
        """Advance lifecycle states for all entries.

        Call this once per processing cycle to transition entries:
        - NEW/ACTIVE entries not updated for > stale_after_s → STALE
        - Entries exceeding max_age_s → EXPIRED

        Does NOT delete entries — that is left to cleanup().

        Returns counts of transitions made.
        """
        if now is None:
            now = time.time()

        transitions: Dict[str, int] = {"to_stale": 0, "to_expired": 0}
        entries = self._store.list_entries()

        for entry in entries:
            age = now - entry.observed_at
            new_state = entry.lifecycle_state

            if self._max_age_s is not None and age > self._max_age_s:
                new_state = MemoryLifecycleState.EXPIRED
            elif age > self._stale_after_s and entry.lifecycle_state in (
                MemoryLifecycleState.NEW,
                MemoryLifecycleState.ACTIVE,
            ):
                new_state = MemoryLifecycleState.STALE

            if new_state != entry.lifecycle_state:
                key = "to_expired" if new_state == MemoryLifecycleState.EXPIRED else "to_stale"
                transitions[key] += 1
                # Mutate the entry in-place for the lifecycle field only.
                # We re-validate and update to keep the store consistent.
                import dataclasses
                updated = dataclasses.replace(
                    entry,
                    lifecycle_state=new_state,
                    updated_at=now,
                )
                self._store.update(entry.memory_id, updated)

        return transitions

    # -----------------------------------------------------------------------
    # Cleanup
    # -----------------------------------------------------------------------

    def cleanup(self, now: Optional[float] = None) -> int:
        """Remove expired entries and enforce capacity.

        Runs the configured cleanup_policy.  Returns count removed.
        Should be called periodically (e.g. once per processing cycle).
        """
        if not self._enabled:
            return 0
        return self._store.cleanup(
            policy=self._cleanup_policy,
            max_entries=self._max_entries,
            max_age_s=self._max_age_s,
            now=now,
        )

    # -----------------------------------------------------------------------
    # Properties (read-only access to config)
    # -----------------------------------------------------------------------

    @property
    def max_entries(self) -> int:
        return self._max_entries

    @property
    def max_age_s(self) -> Optional[float]:
        return self._max_age_s

    @property
    def cleanup_policy(self) -> MemoryCleanupPolicy:
        return self._cleanup_policy

    @property
    def enabled(self) -> bool:
        return self._enabled

    @property
    def schema_version(self) -> int:
        return MEMORY_SCHEMA_VERSION
