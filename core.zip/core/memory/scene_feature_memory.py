"""
IndiDrive AI — Phase 8.3 | Scene Feature / Prototype Memory
=============================================================
Top-level Phase 8.3 memory layer. Accepts structured observations
(ObjectFeatureSet + ContextFeature + RiskFeature) and routes them
into prototype memory using *similarity-based routing* rather than the
exact prototype_key match used by Phase 5.2.

Pipeline context:

    ReasoningSnapshot / WorldModelSnapshot
            ↓
    SceneFeatureMemory.add_observation(feature_set, context, risk)
            ↓
    Feature validation & NaN/Inf sanitisation
            ↓
    FeatureNormalizer  →  SituationFeatureVector
            ↓
    Similarity search over existing ScenePrototypes
            ↓
    Similarity ≥ threshold?
           /           \\
         YES            NO
          ↓              ↓
      Update         Create new
     ScenePrototype  ScenePrototype
          ↓              ↓
      Compact prototype memory
            ↓
    SceneFeatureMemory.find_similar(situation_vector)
            ↓
    Ranked results → Situation Representation / Reasoning

Key differences from Phase 5.2 PrototypeMemory
-----------------------------------------------
Phase 5.2 PrototypeMemory groups observations by *exact prototype_key*
(object_type or object_type::subtype).  This works for category-level
aggregation but misses intra-category variation — e.g. a slow crossing
motorcycle vs a fast approaching motorcycle deserve different prototypes.

Phase 8.3 SceneFeatureMemory routes by *similarity in feature space*:
  1. Compute a normalized SituationFeatureVector for the observation.
  2. Search the existing ScenePrototypes for the nearest one in the
     same object_type bucket (controlled by object_type_strict flag).
  3. If similarity ≥ similarity_threshold → update that prototype.
  4. Otherwise → create a new ScenePrototype.

This is the pattern described in the Phase 8.3 spec:

    Observation → feature representation → similarity/distance check
        → existing prototype? YES: update / NO: create new

Design guarantees
-----------------
* Deterministic: same inputs → same prototype routing.
* Offline-first: no cloud, no LLM, no external DB, no network.
* Bounded memory: max_prototypes cap with configurable eviction.
* NaN/Inf safe: all inputs validated before touching memory.
* Thread-safe: RLock over all mutable state.
* Persistence: save() / load() with JSON + schema version.
* Reuses Phase 5.2 feature_types.py, prototype_types.py,
  feature_normalizer.py, context_feature_types.py.
  Does NOT rewrite or duplicate those modules.

Phase boundary: Phase 8.3 only.
Does NOT implement reasoning, path planning, steering, or control.
"""
from __future__ import annotations

import json
import logging
import math
import threading
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from core.config_loader import get as _cfg_get
from core.logging_system import get_logger as _get_logger
from core.perception.perception_types import NOT_AVAILABLE

from .memory_types import MemoryOperationResult, MemoryCleanupPolicy
from .feature_types import (
    ObjectFeatureSet,
    validate_feature_set,
    DEFAULT_MAX_DESCRIPTOR_DIM,
)
from .context_feature_types import (
    ContextFeature,
    RiskFeature,
    RiskLevelClass,
    validate_context_feature,
    validate_risk_feature,
    CONTEXT_RISK_SCHEMA_VERSION,
)
from .feature_normalizer import (
    FeatureNormalizer,
    NormalizerConfig,
    SituationFeatureVector,
    NORMALIZER_VERSION,
    VECTOR_DIM,
)

__all__ = [
    "SCENE_MEMORY_SCHEMA_VERSION",
    "ScenePrototype",
    "SimilarityMatch",
    "SceneMemoryStats",
    "SceneFeatureMemory",
]

SCENE_MEMORY_SCHEMA_VERSION: int = 1

_LOG_CAT = "system"


def _log() -> logging.Logger:
    try:
        return _get_logger(_LOG_CAT)
    except Exception:
        return logging.getLogger("indidrive.memory.scene_feature")


def _finite(v) -> bool:
    return isinstance(v, (int, float)) and not isinstance(v, bool) and math.isfinite(v)


# ---------------------------------------------------------------------------
# Config helpers
# ---------------------------------------------------------------------------

_DEFAULT_MAX_PROTOTYPES: int = 500
_DEFAULT_SIMILARITY_THRESHOLD: float = 0.80
_DEFAULT_UPDATE_ALPHA: float = 0.10   # weight of new observation in incremental update
_DEFAULT_MIN_CONFIDENCE: float = 0.0
_DEFAULT_OBJECT_TYPE_STRICT: bool = True
_DEFAULT_MAX_MERGE_SIMILARITY: float = 0.97  # merge if similarity this high


def _load_scene_memory_config() -> dict:
    """Load scene_feature_memory section from prediction_config.yaml."""
    try:
        raw = _cfg_get("prediction", "scene_feature_memory")
        if isinstance(raw, dict):
            return raw
    except Exception:
        pass
    return {}


# ---------------------------------------------------------------------------
# ScenePrototype
# ---------------------------------------------------------------------------

@dataclass
class ScenePrototype:
    """Compact, incrementally updated representation of one scene pattern.

    Unlike Phase 5.2 ObjectPrototype (keyed by exact object_type::subtype),
    a ScenePrototype is keyed by a generated UUID-style ID and located
    in feature space by its representative SituationFeatureVector.

    The representative vector is updated with exponential moving average
    (alpha * new + (1-alpha) * old) — deterministic, numerically stable,
    no full-history recomputation.

    Fields
    ------
    prototype_id: str
        Stable generated ID (format: "SP-{n:05d}").
    object_type: str
        Object type this prototype represents (e.g. "MOTORCYCLE").
    representative: SituationFeatureVector
        Current EMA-updated representative vector.
    feature_set_summary: dict
        Last ObjectFeatureSet geometry/motion snapshot (human-readable).
    context_summary: dict
        Last ContextFeature snapshot (human-readable).
    risk_summary: dict
        Last RiskFeature snapshot (human-readable).
    confidence: float
        Running mean confidence.
    observation_count: int
        Total observations folded into this prototype.
    created_at: float
        Wall-clock seconds at creation.
    updated_at: float
        Wall-clock seconds at last update.
    """
    prototype_id: str
    object_type: str = NOT_AVAILABLE
    representative: SituationFeatureVector = field(
        default_factory=SituationFeatureVector
    )
    feature_set_summary: dict = field(default_factory=dict)
    context_summary: dict = field(default_factory=dict)
    risk_summary: dict = field(default_factory=dict)
    confidence: float = 0.0
    observation_count: int = 0
    created_at: float = 0.0
    updated_at: float = 0.0
    schema_version: int = SCENE_MEMORY_SCHEMA_VERSION

    def to_dict(self) -> dict:
        return {
            "schema_version": self.schema_version,
            "prototype_id": self.prototype_id,
            "object_type": self.object_type,
            "representative": self.representative.to_dict(),
            "feature_set_summary": self.feature_set_summary,
            "context_summary": self.context_summary,
            "risk_summary": self.risk_summary,
            "confidence": round(self.confidence, 6),
            "observation_count": self.observation_count,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
        }

    @staticmethod
    def from_dict(d: dict) -> "ScenePrototype":
        sv = d.get("schema_version", SCENE_MEMORY_SCHEMA_VERSION)
        if sv != SCENE_MEMORY_SCHEMA_VERSION:
            raise ValueError(
                f"Unsupported ScenePrototype schema_version={sv}; "
                f"expected {SCENE_MEMORY_SCHEMA_VERSION}"
            )
        pid = d.get("prototype_id", "")
        if not pid:
            raise ValueError("prototype_id is missing or empty")
        rep_dict = d.get("representative", {})
        rep = (
            SituationFeatureVector.from_dict(rep_dict)
            if isinstance(rep_dict, dict)
            else SituationFeatureVector()
        )
        return ScenePrototype(
            prototype_id=pid,
            object_type=d.get("object_type", NOT_AVAILABLE),
            representative=rep,
            feature_set_summary=d.get("feature_set_summary", {}),
            context_summary=d.get("context_summary", {}),
            risk_summary=d.get("risk_summary", {}),
            confidence=float(d.get("confidence", 0.0)),
            observation_count=int(d.get("observation_count", 0)),
            created_at=float(d.get("created_at", 0.0)),
            updated_at=float(d.get("updated_at", 0.0)),
            schema_version=int(sv),
        )


# ---------------------------------------------------------------------------
# SimilarityMatch
# ---------------------------------------------------------------------------

@dataclass
class SimilarityMatch:
    """Structured result of one similarity lookup."""
    prototype_id: str
    object_type: str
    similarity: float        # [0.0, 1.0]
    confidence: float        # prototype confidence
    observation_count: int
    prototype: ScenePrototype

    def to_dict(self) -> dict:
        return {
            "prototype_id": self.prototype_id,
            "object_type": self.object_type,
            "similarity": round(self.similarity, 6),
            "confidence": round(self.confidence, 6),
            "observation_count": self.observation_count,
        }


# ---------------------------------------------------------------------------
# SceneMemoryStats
# ---------------------------------------------------------------------------

@dataclass
class SceneMemoryStats:
    """Compact stats returned by .stats()."""
    total_prototypes: int = 0
    total_observations: int = 0
    prototypes_by_type: Dict[str, int] = field(default_factory=dict)
    avg_confidence: float = 0.0
    max_observations: int = 0
    normalizer_version: int = NORMALIZER_VERSION
    schema_version: int = SCENE_MEMORY_SCHEMA_VERSION

    def to_dict(self) -> dict:
        return {
            "total_prototypes": self.total_prototypes,
            "total_observations": self.total_observations,
            "prototypes_by_type": dict(self.prototypes_by_type),
            "avg_confidence": round(self.avg_confidence, 4),
            "max_observations": self.max_observations,
            "normalizer_version": self.normalizer_version,
            "schema_version": self.schema_version,
        }


# ---------------------------------------------------------------------------
# SceneFeatureMemory
# ---------------------------------------------------------------------------

class SceneFeatureMemory:
    """Bounded, offline-first, similarity-routed scene prototype memory.

    Parameters
    ----------
    max_prototypes : int, optional
        Maximum number of ScenePrototypes stored. Overrides config.
    similarity_threshold : float, optional
        Minimum similarity [0, 1] to route an observation into an
        existing prototype.  Below this → new prototype is created.
        Overrides config.
    update_alpha : float, optional
        EMA weight for new observation in prototype update.
        new_rep = alpha * new + (1 - alpha) * old.
        Overrides config.
    minimum_confidence : float, optional
        Observations with confidence below this threshold are rejected.
        Overrides config.
    object_type_strict : bool, optional
        When True (default), similarity search only considers prototypes
        with the same object_type as the observation, preventing a
        motorcycle observation from updating a car prototype even if
        geometry happens to be similar.
    normalizer_config : NormalizerConfig, optional
        Custom normalizer ranges. Overrides defaults.
    max_feature_dimension : int, optional
        Passed to ObjectFeatureSet validation.
    """

    def __init__(
        self,
        *,
        max_prototypes: Optional[int] = None,
        similarity_threshold: Optional[float] = None,
        update_alpha: Optional[float] = None,
        minimum_confidence: Optional[float] = None,
        object_type_strict: Optional[bool] = None,
        max_merge_similarity: Optional[float] = None,
        normalizer_config: Optional[NormalizerConfig] = None,
        max_feature_dimension: Optional[int] = None,
    ) -> None:
        cfg = _load_scene_memory_config()

        self._max_prototypes: int = (
            max_prototypes if max_prototypes is not None
            else int(cfg.get("max_prototypes", _DEFAULT_MAX_PROTOTYPES))
        )
        self._similarity_threshold: float = (
            similarity_threshold if similarity_threshold is not None
            else float(cfg.get("similarity_threshold", _DEFAULT_SIMILARITY_THRESHOLD))
        )
        self._update_alpha: float = (
            update_alpha if update_alpha is not None
            else float(cfg.get("update_alpha", _DEFAULT_UPDATE_ALPHA))
        )
        self._minimum_confidence: float = (
            minimum_confidence if minimum_confidence is not None
            else float(cfg.get("minimum_confidence", _DEFAULT_MIN_CONFIDENCE))
        )
        self._object_type_strict: bool = (
            object_type_strict if object_type_strict is not None
            else bool(cfg.get("object_type_strict", _DEFAULT_OBJECT_TYPE_STRICT))
        )
        self._max_merge_similarity: float = (
            max_merge_similarity if max_merge_similarity is not None
            else float(cfg.get("max_merge_similarity", _DEFAULT_MAX_MERGE_SIMILARITY))
        )
        self._max_feature_dimension: int = (
            max_feature_dimension if max_feature_dimension is not None
            else int(cfg.get("max_feature_dimension", DEFAULT_MAX_DESCRIPTOR_DIM))
        )

        norm_cfg = normalizer_config or NormalizerConfig()
        self._normalizer = FeatureNormalizer(config=norm_cfg)

        # Thread-safe prototype store: {prototype_id: ScenePrototype}
        self._prototypes: Dict[str, ScenePrototype] = {}
        self._lock: threading.RLock = threading.RLock()
        self._next_id: int = 1  # monotonically increasing prototype counter

        _log().debug(f"[MEMORY] SceneFeatureMemory init: max_prototypes={self._max_prototypes} threshold={self._similarity_threshold:.3f} alpha={self._update_alpha:.3f}")

    # -----------------------------------------------------------------------
    # Primary API: add_observation
    # -----------------------------------------------------------------------

    def add_observation(
        self,
        feature_set: ObjectFeatureSet,
        context: Optional[ContextFeature] = None,
        risk: Optional[RiskFeature] = None,
        observed_at: Optional[float] = None,
    ) -> MemoryOperationResult:
        """Validate, normalise, and route an observation into prototype memory.

        Returns MemoryOperationResult. Never raises for invalid input —
        returns a failure result instead so the pipeline can log and continue.

        Action logged:
            [MEMORY] Observation received — object_type, feature groups present
            [MEMORY] Nearest prototype: SP-XXXXX, Similarity: 0.NN
            [MEMORY] Action: UPDATE / CREATE
            [MEMORY] Confidence: X.XX, Prototype count: NN
        """
        now = observed_at if (observed_at is not None and _finite(observed_at)) else time.time()

        # --- Step 1: validate inputs ----------------------------------------
        fs_result = validate_feature_set(feature_set, self._max_feature_dimension)
        if not fs_result.ok:
            _log().warning(f"[MEMORY] Observation rejected (feature_set): {fs_result.reason}")
            return MemoryOperationResult.failure(
                f"feature_set invalid: {fs_result.reason}"
            )

        if feature_set.confidence < self._minimum_confidence:
            reason = (
                f"confidence {feature_set.confidence:.3f} < "
                f"minimum {self._minimum_confidence:.3f}"
            )
            _log().debug(f"[MEMORY] Observation skipped: {reason}")
            return MemoryOperationResult.failure(reason)

        if context is not None:
            ctx_ok, ctx_reason = validate_context_feature(context)
            if not ctx_ok:
                _log().warning(f"[MEMORY] context_feature invalid: {ctx_reason} — ignoring context")
                context = None   # degrade gracefully; don't abort

        if risk is not None:
            risk_ok, risk_reason = validate_risk_feature(risk)
            if not risk_ok:
                _log().warning(f"[MEMORY] risk_feature invalid: {risk_reason} — ignoring risk")
                risk = None

        _log().debug(f"[MEMORY] Observation received — object_type={feature_set.object_type} geo={'present' if feature_set.geometry else 'absent'} mot={'present' if feature_set.motion else 'absent'} ctx={'present' if context else 'absent'} risk={'present' if risk else 'absent'}")

        # --- Step 2: normalise to feature vector ----------------------------
        fvec = self._normalizer.normalize(feature_set, context, risk)
        if not fvec.is_usable():
            reason = (
                f"normalized vector has only {fvec.available_count} available "
                f"features (minimum 3 required)"
            )
            _log().debug(f"[MEMORY] Observation skipped: {reason}")
            return MemoryOperationResult.failure(reason)

        # --- Step 3: find nearest prototype ---------------------------------
        with self._lock:
            nearest_id, nearest_sim = self._find_nearest(fvec, feature_set.object_type)

            if nearest_id is not None and nearest_sim >= self._similarity_threshold:
                # UPDATE existing prototype
                _log().debug(f"[MEMORY] Nearest prototype: {nearest_id}  Similarity: {nearest_sim:.4f}  Action: UPDATE")
                proto = self._prototypes[nearest_id]
                updated = self._update_prototype(proto, fvec, feature_set, context, risk, now)
                self._prototypes[nearest_id] = updated
                _log().debug(f"[MEMORY] Confidence: {updated.confidence:.4f}  Prototype count: {len(self._prototypes)}")
                return MemoryOperationResult.success(nearest_id)

            else:
                # CREATE new prototype — check capacity first
                if len(self._prototypes) >= self._max_prototypes:
                    removed = self._evict_one()
                    _log().debug(f"[MEMORY] Capacity reached — evicted prototype {removed}")

                new_id = self._make_id()
                new_proto = ScenePrototype(
                    prototype_id=new_id,
                    object_type=feature_set.object_type,
                    representative=fvec,
                    feature_set_summary=self._summarize_feature_set(feature_set),
                    context_summary=context.to_dict() if context else {},
                    risk_summary=risk.to_dict() if risk else {},
                    confidence=feature_set.confidence,
                    observation_count=1,
                    created_at=now,
                    updated_at=now,
                )
                self._prototypes[new_id] = new_proto
                _log().debug(f"[MEMORY] Action: CREATE  Prototype ID: {new_id}  Confidence: {feature_set.confidence:.4f}  Prototype count: {len(self._prototypes)}")
                return MemoryOperationResult.success(new_id)

    # -----------------------------------------------------------------------
    # API: find_similar
    # -----------------------------------------------------------------------

    def find_similar(
        self,
        query_vector: SituationFeatureVector,
        top_k: int = 5,
        minimum_similarity: float = 0.0,
        object_type: Optional[str] = None,
    ) -> List[SimilarityMatch]:
        """Find the top-K most similar prototypes for a query vector.

        Parameters
        ----------
        query_vector:
            Normalized SituationFeatureVector (from FeatureNormalizer).
        top_k:
            Maximum results to return. Must be >= 1.
        minimum_similarity:
            Filter out results below this threshold.
        object_type:
            If given and object_type_strict is True, only search
            prototypes with this object_type.

        Returns
        -------
        List[SimilarityMatch] sorted by similarity descending.
        Never raises — returns empty list on error.
        """
        top_k = max(1, int(top_k))
        minimum_similarity = max(0.0, min(1.0, float(minimum_similarity)))

        with self._lock:
            candidates = list(self._prototypes.values())

        if not candidates:
            return []

        results: List[SimilarityMatch] = []
        for proto in candidates:
            # Object-type filter
            if (object_type is not None and self._object_type_strict
                    and proto.object_type != object_type):
                continue
            try:
                sim = query_vector.similarity_to(proto.representative)
            except Exception:
                continue
            if not _finite(sim) or sim < minimum_similarity:
                continue
            results.append(SimilarityMatch(
                prototype_id=proto.prototype_id,
                object_type=proto.object_type,
                similarity=sim,
                confidence=proto.confidence,
                observation_count=proto.observation_count,
                prototype=proto,
            ))

        # Sort: similarity desc, then confidence desc, then id asc (deterministic)
        results.sort(key=lambda m: (-m.similarity, -m.confidence, m.prototype_id))
        return results[:top_k]

    def get_nearest_prototype(
        self,
        query_vector: SituationFeatureVector,
        object_type: Optional[str] = None,
    ) -> Optional[SimilarityMatch]:
        """Return the single nearest prototype, or None if memory is empty."""
        results = self.find_similar(query_vector, top_k=1, object_type=object_type)
        return results[0] if results else None

    # -----------------------------------------------------------------------
    # API: merge_prototypes
    # -----------------------------------------------------------------------

    def merge_prototypes(
        self, prototype_id_a: str, prototype_id_b: str
    ) -> MemoryOperationResult:
        """Merge prototype B into prototype A, then remove B.

        The merged prototype uses a weighted average of the two
        representative vectors (weighted by observation count) and sums
        their observation counts and updates confidence.

        Returns MemoryOperationResult. Never raises.
        """
        with self._lock:
            pa = self._prototypes.get(prototype_id_a)
            pb = self._prototypes.get(prototype_id_b)
            if pa is None:
                return MemoryOperationResult.failure(
                    f"prototype_id_a={prototype_id_a!r} not found"
                )
            if pb is None:
                return MemoryOperationResult.failure(
                    f"prototype_id_b={prototype_id_b!r} not found"
                )
            if prototype_id_a == prototype_id_b:
                return MemoryOperationResult.failure("Cannot merge a prototype with itself")

            wa = pa.observation_count
            wb = pb.observation_count
            total = wa + wb
            if total == 0:
                weight_a = 0.5
            else:
                weight_a = wa / total

            merged_values = self._weighted_vector(
                pa.representative.values,
                pb.representative.values,
                weight_a,
            )
            merged_vec = SituationFeatureVector(
                values=merged_values,
                normalizer_version=NORMALIZER_VERSION,
                object_type=pa.object_type,
            )
            merged_conf = weight_a * pa.confidence + (1.0 - weight_a) * pb.confidence
            merged = ScenePrototype(
                prototype_id=prototype_id_a,
                object_type=pa.object_type,
                representative=merged_vec,
                feature_set_summary=pa.feature_set_summary,
                context_summary=pa.context_summary,
                risk_summary=pa.risk_summary,
                confidence=merged_conf,
                observation_count=total,
                created_at=pa.created_at,
                updated_at=time.time(),
            )
            self._prototypes[prototype_id_a] = merged
            del self._prototypes[prototype_id_b]
            _log().debug(f"[MEMORY] Merged {prototype_id_a} ← {prototype_id_b}  new_count={total}  conf={merged_conf:.4f}")
        return MemoryOperationResult.success(prototype_id_a)

    # -----------------------------------------------------------------------
    # API: compact_memory
    # -----------------------------------------------------------------------

    def compact_memory(self, max_merge_similarity: Optional[float] = None) -> int:
        """Merge sufficiently similar prototypes to reduce memory footprint.

        Scans all prototype pairs and merges those with mutual similarity
        ≥ max_merge_similarity (within the same object_type bucket).

        Parameters
        ----------
        max_merge_similarity:
            Override the instance-level max_merge_similarity for this call.
            Pairs with similarity ≥ this threshold are merged.

        Returns
        -------
        Number of prototypes removed (= number of merges performed).
        """
        threshold = (
            float(max_merge_similarity)
            if max_merge_similarity is not None
            else self._max_merge_similarity
        )
        removed = 0
        with self._lock:
            keys = list(self._prototypes.keys())
            # Iterate over pairs deterministically (sorted keys)
            merged_away: set = set()
            for i, id_a in enumerate(keys):
                if id_a in merged_away:
                    continue
                pa = self._prototypes.get(id_a)
                if pa is None:
                    continue
                for id_b in keys[i + 1:]:
                    if id_b in merged_away:
                        continue
                    pb = self._prototypes.get(id_b)
                    if pb is None:
                        continue
                    # Only merge same object_type
                    if pa.object_type != pb.object_type:
                        continue
                    sim = pa.representative.similarity_to(pb.representative)
                    if _finite(sim) and sim >= threshold:
                        # Merge: keep the one with more observations
                        if pb.observation_count > pa.observation_count:
                            id_a, id_b = id_b, id_a
                            pa, pb = pb, pa
                        result = self.merge_prototypes(id_a, id_b)
                        if result.ok:
                            merged_away.add(id_b)
                            pa = self._prototypes.get(id_a)  # refresh after merge
                            removed += 1
        _log().debug(f"[MEMORY] compact_memory: removed {removed} prototypes")
        return removed

    # -----------------------------------------------------------------------
    # API: persistence (save / load)
    # -----------------------------------------------------------------------

    def save(self, path: str) -> MemoryOperationResult:
        """Serialise the entire memory to a JSON file at ``path``.

        File format:
        {
            "schema_version": 1,
            "normalizer_version": 1,
            "saved_at": <timestamp>,
            "prototype_count": <n>,
            "prototypes": [ ... ]
        }

        Returns MemoryOperationResult. Never raises.
        """
        try:
            with self._lock:
                protos = [p.to_dict() for p in self._prototypes.values()]
            payload = {
                "schema_version": SCENE_MEMORY_SCHEMA_VERSION,
                "normalizer_version": NORMALIZER_VERSION,
                "saved_at": time.time(),
                "prototype_count": len(protos),
                "prototypes": protos,
            }
            p = Path(path)
            p.parent.mkdir(parents=True, exist_ok=True)
            with open(p, "w", encoding="utf-8") as f:
                json.dump(payload, f, indent=2, sort_keys=True)
            _log().debug(f"[MEMORY] save(): wrote {len(protos)} prototypes to {path}")
            return MemoryOperationResult.success(path)
        except Exception as exc:
            _log().error(f"[MEMORY] save() failed: {exc}")
            return MemoryOperationResult.failure(f"save failed: {exc}")

    def load(self, path: str) -> MemoryOperationResult:
        """Load memory from a JSON file produced by save().

        This REPLACES the current in-memory state.
        Validates schema_version before loading. Handles:
          * file not found
          * corrupted JSON
          * wrong schema version
          * individual malformed prototypes (skipped, not aborting)

        Returns MemoryOperationResult. Never raises.
        """
        try:
            p = Path(path)
            if not p.exists():
                return MemoryOperationResult.failure(f"File not found: {path}")
            with open(p, "r", encoding="utf-8") as f:
                raw = f.read().strip()
            if not raw:
                return MemoryOperationResult.failure(f"File is empty: {path}")
            try:
                payload = json.loads(raw)
            except json.JSONDecodeError as e:
                return MemoryOperationResult.failure(f"Corrupted JSON: {e}")

            if not isinstance(payload, dict):
                return MemoryOperationResult.failure("Top-level value is not a dict")

            sv = int(payload.get("schema_version", 0))
            if sv != SCENE_MEMORY_SCHEMA_VERSION:
                return MemoryOperationResult.failure(
                    f"Unsupported schema_version={sv}; expected {SCENE_MEMORY_SCHEMA_VERSION}"
                )

            proto_list = payload.get("prototypes", [])
            if not isinstance(proto_list, list):
                return MemoryOperationResult.failure("'prototypes' field is not a list")

            loaded: Dict[str, ScenePrototype] = {}
            errors = 0
            for item in proto_list:
                if not isinstance(item, dict):
                    errors += 1
                    continue
                try:
                    proto = ScenePrototype.from_dict(item)
                    loaded[proto.prototype_id] = proto
                except Exception as exc:
                    _log().warning(f"[MEMORY] load(): skipping malformed prototype: {exc}")
                    errors += 1

            with self._lock:
                self._prototypes = loaded
                # Advance the ID counter past any loaded IDs
                for pid in loaded:
                    if pid.startswith("SP-"):
                        try:
                            n = int(pid[3:])
                            if n >= self._next_id:
                                self._next_id = n + 1
                        except ValueError:
                            pass

            _log().debug(f"[MEMORY] load(): loaded {len(loaded)} prototypes ({errors} errors) from {path}")
            if errors > 0:
                return MemoryOperationResult.failure(
                    f"Loaded {len(loaded)} prototypes but skipped {errors} malformed entries",
                    memory_id=str(len(loaded)),
                )
            return MemoryOperationResult.success(str(len(loaded)))

        except Exception as exc:
            _log().error(f"[MEMORY] load() failed: {exc}")
            return MemoryOperationResult.failure(f"load failed: {exc}")

    # -----------------------------------------------------------------------
    # API: stats / introspection
    # -----------------------------------------------------------------------

    def stats(self) -> SceneMemoryStats:
        """Return compact memory statistics. Never raises."""
        with self._lock:
            protos = list(self._prototypes.values())
        if not protos:
            return SceneMemoryStats()

        by_type: Dict[str, int] = {}
        total_conf = 0.0
        total_obs = 0
        max_obs = 0
        for p in protos:
            by_type[p.object_type] = by_type.get(p.object_type, 0) + 1
            total_conf += p.confidence
            total_obs += p.observation_count
            if p.observation_count > max_obs:
                max_obs = p.observation_count

        return SceneMemoryStats(
            total_prototypes=len(protos),
            total_observations=total_obs,
            prototypes_by_type=by_type,
            avg_confidence=total_conf / len(protos) if protos else 0.0,
            max_observations=max_obs,
        )

    def list_prototypes(self) -> List[ScenePrototype]:
        """Return a snapshot list of all current prototypes."""
        with self._lock:
            return list(self._prototypes.values())

    def get_prototype(self, prototype_id: str) -> Optional[ScenePrototype]:
        """Return a specific prototype by ID, or None."""
        with self._lock:
            return self._prototypes.get(prototype_id)

    def remove_prototype(self, prototype_id: str) -> MemoryOperationResult:
        """Remove a specific prototype by ID."""
        with self._lock:
            if prototype_id not in self._prototypes:
                return MemoryOperationResult.failure(f"{prototype_id!r} not found")
            del self._prototypes[prototype_id]
        return MemoryOperationResult.success(prototype_id)

    def clear(self) -> int:
        """Remove all prototypes. Returns count removed."""
        with self._lock:
            n = len(self._prototypes)
            self._prototypes.clear()
            self._next_id = 1
        return n

    @property
    def prototype_count(self) -> int:
        with self._lock:
            return len(self._prototypes)

    @property
    def similarity_threshold(self) -> float:
        return self._similarity_threshold

    @property
    def max_prototypes(self) -> int:
        return self._max_prototypes

    # -----------------------------------------------------------------------
    # Internal helpers
    # -----------------------------------------------------------------------

    def _make_id(self) -> str:
        """Generate a deterministic, monotonic prototype ID."""
        pid = f"SP-{self._next_id:05d}"
        self._next_id += 1
        return pid

    def _find_nearest(
        self, fvec: SituationFeatureVector, object_type: str
    ) -> Tuple[Optional[str], float]:
        """Find the nearest prototype ID and similarity.

        Called with self._lock already held.
        Returns (None, 0.0) when no candidates exist.
        """
        best_id = None
        best_sim = -1.0
        for pid, proto in self._prototypes.items():
            if self._object_type_strict and proto.object_type != object_type:
                continue
            try:
                sim = fvec.similarity_to(proto.representative)
            except Exception:
                continue
            if not _finite(sim):
                continue
            if sim > best_sim:
                best_sim = sim
                best_id = pid
        return best_id, max(0.0, best_sim)

    def _update_prototype(
        self,
        proto: ScenePrototype,
        new_vec: SituationFeatureVector,
        feature_set: ObjectFeatureSet,
        context: Optional[ContextFeature],
        risk: Optional[RiskFeature],
        now: float,
    ) -> ScenePrototype:
        """Create an updated ScenePrototype using EMA. Pure function."""
        alpha = self._update_alpha
        old_vals = proto.representative.values
        new_vals = new_vec.values
        merged = self._ema_vector(old_vals, new_vals, alpha)
        merged_vec = SituationFeatureVector(
            values=merged,
            normalizer_version=NORMALIZER_VERSION,
            object_type=proto.object_type,
        )
        # Running mean confidence
        n = proto.observation_count + 1
        new_conf = proto.confidence + (feature_set.confidence - proto.confidence) / n
        return ScenePrototype(
            prototype_id=proto.prototype_id,
            object_type=proto.object_type,
            representative=merged_vec,
            feature_set_summary=self._summarize_feature_set(feature_set),
            context_summary=context.to_dict() if context else proto.context_summary,
            risk_summary=risk.to_dict() if risk else proto.risk_summary,
            confidence=new_conf,
            observation_count=n,
            created_at=proto.created_at,
            updated_at=now,
        )

    @staticmethod
    def _ema_vector(
        old: List[Optional[float]],
        new: List[Optional[float]],
        alpha: float,
    ) -> List[Optional[float]]:
        """Element-wise EMA: alpha*new + (1-alpha)*old.

        If either slot is None, keep the other; if both are None, keep None.
        """
        result = []
        for o, n in zip(old, new):
            if o is None and n is None:
                result.append(None)
            elif o is None:
                result.append(n)
            elif n is None:
                result.append(o)
            else:
                merged = alpha * n + (1.0 - alpha) * o
                if not _finite(merged):
                    result.append(o)
                else:
                    result.append(max(0.0, min(1.0, merged)))
        return result

    @staticmethod
    def _weighted_vector(
        a: List[Optional[float]],
        b: List[Optional[float]],
        weight_a: float,
    ) -> List[Optional[float]]:
        """Weighted average: weight_a * a + (1 - weight_a) * b."""
        weight_b = 1.0 - weight_a
        result = []
        for va, vb in zip(a, b):
            if va is None and vb is None:
                result.append(None)
            elif va is None:
                result.append(vb)
            elif vb is None:
                result.append(va)
            else:
                v = weight_a * va + weight_b * vb
                result.append(max(0.0, min(1.0, v)) if _finite(v) else va)
        return result

    def _evict_one(self) -> str:
        """Evict the prototype with the fewest observations (oldest for ties).

        Called with self._lock already held.
        Returns the evicted prototype_id.
        """
        if not self._prototypes:
            return ""
        victim = min(
            self._prototypes.values(),
            key=lambda p: (p.observation_count, p.created_at),
        )
        del self._prototypes[victim.prototype_id]
        return victim.prototype_id

    @staticmethod
    def _summarize_feature_set(fs: ObjectFeatureSet) -> dict:
        """Build a compact human-readable snapshot of a feature set."""
        summary: dict = {"object_type": fs.object_type}
        if fs.geometry:
            g = fs.geometry
            summary["geometry"] = {
                k: round(v, 3) for k, v in [
                    ("length", g.length), ("width", g.width), ("height", g.height)
                ] if v is not None
            }
        if fs.motion:
            m = fs.motion
            summary["motion"] = {"motion_class": m.motion_class.value}
            if m.typical_speed_ms is not None:
                summary["motion"]["speed_ms"] = round(m.typical_speed_ms, 2)
        return summary
