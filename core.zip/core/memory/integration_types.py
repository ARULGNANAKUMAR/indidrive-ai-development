"""
IndiDrive AI — Phase 5.4 | Memory Integration Types
=====================================================
Data contracts for the Memory Integration layer.  These types form the
read-only "Memory Context" that downstream AI components consume.

Pipeline position:

    Perception → Fusion → Prediction (Phase 4D)
                    ↓
            Memory Integration  (Phase 5.4)
                 ↙       ↓       ↘
          Object   Prototype   Retrieval
                    ↓
               MemoryContext  (this module)
                    ↓
         Future Reasoning / AI Brain

Design rules (same as all prior phases):
  * compact — no raw sensor data, no large tensors
  * deterministic — same input → same output
  * serialisable — to_dict()
  * offline-first — no cloud, no LLM, no vector DB
  * optional fields are None, not fabricated
  * read-only snapshot — downstream consumers must not mutate the
    underlying memory stores through this context

Phase boundary: Phase 5.4 only.
Does NOT:
  * perform steering / braking / path planning / collision avoidance
  * directly drive any control output
  * make autonomous decisions
  * implement a reasoning engine
"""
from __future__ import annotations

import copy
import json
import math
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional

from core.perception.perception_types import NOT_AVAILABLE

from .memory_types import ObjectMemoryEntry
from .prototype_types import ObjectPrototype
from .retrieval_types import RetrievalResult

__all__ = [
    "INTEGRATION_SCHEMA_VERSION",
    "MemoryContextStatus",
    "ObjectMemoryRef",
    "PrototypeRef",
    "MemoryContextMetadata",
    "MemoryContext",
    "MemoryIntegrationStats",
]

# Increment when the serialised schema changes in a breaking way.
INTEGRATION_SCHEMA_VERSION: int = 1


class MemoryContextStatus(str, Enum):
    """Overall status of the produced MemoryContext.

    AVAILABLE    — all three memory subsystems responded normally.
    PARTIAL      — at least one subsystem is degraded/failed; results
                   are still provided from whatever subsystems succeeded.
    EMPTY        — memory exists but contains no entries yet (cold start).
    DISABLED     — the memory integration layer is configured off.
    FAILED       — the integration itself encountered a hard error.
    """
    AVAILABLE = "AVAILABLE"
    PARTIAL = "PARTIAL"
    EMPTY = "EMPTY"
    DISABLED = "DISABLED"
    FAILED = "FAILED"


@dataclass
class ObjectMemoryRef:
    """Compact reference to a single ObjectMemoryEntry in the context.

    Contains only the fields downstream AI needs — not a copy of the full
    entry, not any raw sensor data.
    """
    memory_id: str
    track_id: Optional[str] = None
    object_type: str = NOT_AVAILABLE
    confidence: float = 0.0
    lifecycle_state: str = NOT_AVAILABLE
    # Compact position summary (from MemoryPositionSummary)
    position_x: Optional[float] = None
    position_y: Optional[float] = None
    position_z: Optional[float] = None
    # Compact motion summary
    speed_ms: Optional[float] = None
    heading_rad: Optional[float] = None
    # Appearance label
    appearance_label: Optional[str] = None
    # When this memory was last observed (wall clock seconds)
    observed_at: Optional[float] = None

    def to_dict(self) -> dict:
        return {
            "memory_id": self.memory_id,
            "track_id": self.track_id if self.track_id is not None else NOT_AVAILABLE,
            "object_type": self.object_type,
            "confidence": round(self.confidence, 6),
            "lifecycle_state": self.lifecycle_state,
            "position_x": self.position_x if self.position_x is not None else NOT_AVAILABLE,
            "position_y": self.position_y if self.position_y is not None else NOT_AVAILABLE,
            "position_z": self.position_z if self.position_z is not None else NOT_AVAILABLE,
            "speed_ms": self.speed_ms if self.speed_ms is not None else NOT_AVAILABLE,
            "heading_rad": self.heading_rad if self.heading_rad is not None else NOT_AVAILABLE,
            "appearance_label": (
                self.appearance_label if self.appearance_label is not None else NOT_AVAILABLE
            ),
            "observed_at": self.observed_at if self.observed_at is not None else NOT_AVAILABLE,
        }

    @staticmethod
    def from_entry(entry: ObjectMemoryEntry) -> "ObjectMemoryRef":
        """Build a compact reference from a full ObjectMemoryEntry."""
        pos_x = pos_y = pos_z = None
        if entry.position is not None and entry.position.is_valid():
            pos_x = entry.position.x
            pos_y = entry.position.y
            pos_z = entry.position.z

        speed = heading = None
        if entry.motion is not None and entry.motion.is_valid():
            speed = entry.motion.speed_ms
            heading = entry.motion.heading_rad

        return ObjectMemoryRef(
            memory_id=entry.memory_id,
            track_id=entry.track_id,
            object_type=entry.object_type,
            confidence=entry.confidence,
            lifecycle_state=entry.lifecycle_state.value,
            position_x=pos_x,
            position_y=pos_y,
            position_z=pos_z,
            speed_ms=speed,
            heading_rad=heading,
            appearance_label=entry.appearance_label,
            observed_at=entry.observed_at,
        )


@dataclass
class PrototypeRef:
    """Compact reference to an ObjectPrototype in the context.

    Contains the prototype key, object type, and aggregate statistics
    that downstream AI can use without copying the full prototype store.
    """
    prototype_key: str
    object_type: str = NOT_AVAILABLE
    subtype: Optional[str] = None
    observation_count: int = 0
    # Aggregated geometry summary (means)
    mean_length_m: Optional[float] = None
    mean_width_m: Optional[float] = None
    mean_height_m: Optional[float] = None
    # Aggregated motion summary
    mean_speed_ms: Optional[float] = None
    # Confidence of the prototype (aggregate)
    mean_confidence: Optional[float] = None
    # When this prototype was last updated
    last_updated_at: Optional[float] = None

    def to_dict(self) -> dict:
        def _f(v):
            return round(v, 6) if v is not None else NOT_AVAILABLE

        return {
            "prototype_key": self.prototype_key,
            "object_type": self.object_type,
            "subtype": self.subtype if self.subtype is not None else NOT_AVAILABLE,
            "observation_count": self.observation_count,
            "mean_length_m": _f(self.mean_length_m),
            "mean_width_m": _f(self.mean_width_m),
            "mean_height_m": _f(self.mean_height_m),
            "mean_speed_ms": _f(self.mean_speed_ms),
            "mean_confidence": _f(self.mean_confidence),
            "last_updated_at": (
                self.last_updated_at if self.last_updated_at is not None else NOT_AVAILABLE
            ),
        }

    @staticmethod
    def from_prototype(proto: ObjectPrototype) -> "PrototypeRef":
        """Build a compact reference from a full ObjectPrototype.

        ObjectPrototype.geometry is a GeometryFeature (dataclass with
        .length, .width, .height attributes).
        ObjectPrototype.motion is a MotionFeature (dataclass with
        .typical_speed_ms attribute).
        ObjectPrototype.confidence is a float (running mean).
        ObjectPrototype timestamps use .updated_at (not last_updated_at).
        """
        ml = mw = mh = ms = None

        # Geometry means — GeometryFeature has direct float attributes
        if proto.geometry is not None:
            geo = proto.geometry
            ml = geo.length
            mw = geo.width
            mh = geo.height

        # Motion means — MotionFeature has .typical_speed_ms
        if proto.motion is not None:
            mot = proto.motion
            ms = mot.typical_speed_ms

        # Confidence is a plain float on ObjectPrototype
        mean_conf: Optional[float] = None
        raw_conf = proto.confidence
        if raw_conf is not None and isinstance(raw_conf, (int, float)) and math.isfinite(raw_conf):
            mean_conf = float(raw_conf)

        # Timestamp — ObjectPrototype uses .updated_at
        updated = getattr(proto, "updated_at", None)

        return PrototypeRef(
            prototype_key=proto.prototype_key,
            object_type=proto.object_type,
            subtype=proto.subtype,
            observation_count=proto.observation_count,
            mean_length_m=ml,
            mean_width_m=mw,
            mean_height_m=mh,
            mean_speed_ms=ms,
            mean_confidence=mean_conf,
            last_updated_at=updated,
        )


@dataclass
class MemoryContextMetadata:
    """Lightweight metadata / health summary for the MemoryContext."""

    # Counts from each subsystem
    object_memory_count: int = 0
    prototype_count: int = 0
    retrieval_candidate_count: int = 0
    retrieval_result_count: int = 0

    # Per-subsystem status strings (AVAILABLE | DEGRADED | FAILED | DISABLED | EMPTY)
    object_memory_status: str = NOT_AVAILABLE
    prototype_memory_status: str = NOT_AVAILABLE
    retrieval_status: str = NOT_AVAILABLE

    # Overall context status
    context_status: MemoryContextStatus = MemoryContextStatus.EMPTY

    # Integration processing time (wall clock seconds, not invented)
    integration_duration_s: Optional[float] = None

    def to_dict(self) -> dict:
        return {
            "object_memory_count": self.object_memory_count,
            "prototype_count": self.prototype_count,
            "retrieval_candidate_count": self.retrieval_candidate_count,
            "retrieval_result_count": self.retrieval_result_count,
            "object_memory_status": self.object_memory_status,
            "prototype_memory_status": self.prototype_memory_status,
            "retrieval_status": self.retrieval_status,
            "context_status": self.context_status.value,
            "integration_duration_s": (
                round(self.integration_duration_s, 6)
                if self.integration_duration_s is not None
                else NOT_AVAILABLE
            ),
        }


@dataclass
class MemoryContext:
    """Compact, read-only memory context for downstream AI consumers.

    Produced once per processing cycle by MemoryIntegration.process().

    Downstream consumers must treat this as an immutable snapshot.  The
    context contains only compact references — not copies of the full
    memory stores.  This prevents accidental store mutation through the
    context and keeps the object small.

    Fields
    ------
    timestamp:
        Wall-clock time when the context was created (seconds since epoch).
    frame_id:
        Frame/cycle counter from the upstream world state, for correlation.
    objects:
        Compact references to relevant ObjectMemoryEntry instances.
        One entry per in-memory object (after lifecycle filtering).
    prototypes:
        Compact references to ObjectPrototype summaries for the object
        types observed in this context.
    similar_experiences:
        Ranked list of RetrievalResult from Phase 5.3B.
        Empty when retrieval is disabled or memory is empty.
    metadata:
        Health / count / status summary for observability.
    integration_schema_version:
        Schema version for forward compatibility.
    """

    timestamp: float = field(default_factory=time.time)
    frame_id: int = 0

    # Compact references — not full copies of the stores
    objects: List[ObjectMemoryRef] = field(default_factory=list)
    prototypes: List[PrototypeRef] = field(default_factory=list)
    similar_experiences: List[RetrievalResult] = field(default_factory=list)

    # Health / observability
    metadata: MemoryContextMetadata = field(default_factory=MemoryContextMetadata)

    # Schema
    integration_schema_version: int = INTEGRATION_SCHEMA_VERSION

    # ------------------------------------------------------------------
    # Convenience helpers
    # ------------------------------------------------------------------

    @property
    def is_available(self) -> bool:
        """True when memory is usable (AVAILABLE or PARTIAL)."""
        return self.metadata.context_status in (
            MemoryContextStatus.AVAILABLE,
            MemoryContextStatus.PARTIAL,
        )

    @property
    def is_empty(self) -> bool:
        return self.metadata.context_status == MemoryContextStatus.EMPTY

    @property
    def object_count(self) -> int:
        return len(self.objects)

    @property
    def experience_count(self) -> int:
        return len(self.similar_experiences)

    # ------------------------------------------------------------------
    # Serialisation
    # ------------------------------------------------------------------

    def to_dict(self) -> dict:
        return {
            "integration_schema_version": self.integration_schema_version,
            "timestamp": self.timestamp,
            "frame_id": self.frame_id,
            "objects": [o.to_dict() for o in self.objects],
            "prototypes": [p.to_dict() for p in self.prototypes],
            "similar_experiences": [e.to_dict() for e in self.similar_experiences],
            "metadata": self.metadata.to_dict(),
        }

    def to_json(self) -> str:
        """Deterministic JSON serialisation (sorted keys)."""
        return json.dumps(self.to_dict(), sort_keys=True)

    # ------------------------------------------------------------------
    # Snapshot / defensive copy
    # ------------------------------------------------------------------

    def snapshot(self) -> "MemoryContext":
        """Return a deep copy of this context so the caller can safely
        hold it across processing cycles without aliasing issues."""
        return copy.deepcopy(self)

    # ------------------------------------------------------------------
    # Empty context factory
    # ------------------------------------------------------------------

    @staticmethod
    def empty(
        *,
        timestamp: Optional[float] = None,
        frame_id: int = 0,
        status: MemoryContextStatus = MemoryContextStatus.EMPTY,
        reason: str = "",
    ) -> "MemoryContext":
        """Return a safe empty context — used during degraded operation."""
        meta = MemoryContextMetadata(
            context_status=status,
            object_memory_status=reason or status.value,
            prototype_memory_status=reason or status.value,
            retrieval_status=reason or status.value,
        )
        return MemoryContext(
            timestamp=timestamp if timestamp is not None else time.time(),
            frame_id=frame_id,
            objects=[],
            prototypes=[],
            similar_experiences=[],
            metadata=meta,
        )


@dataclass
class MemoryIntegrationStats:
    """Cumulative runtime statistics for the MemoryIntegration layer.

    All counts are monotonically increasing from initialisation.
    Reported as-measured; no invented values.
    """
    cycles_processed: int = 0
    objects_processed: int = 0
    object_memory_adds: int = 0
    object_memory_updates: int = 0
    object_memory_failures: int = 0
    prototype_observations: int = 0
    prototype_failures: int = 0
    retrieval_calls: int = 0
    retrieval_results: int = 0
    retrieval_failures: int = 0
    degraded_cycles: int = 0

    def to_dict(self) -> dict:
        return {
            "cycles_processed": self.cycles_processed,
            "objects_processed": self.objects_processed,
            "object_memory_adds": self.object_memory_adds,
            "object_memory_updates": self.object_memory_updates,
            "object_memory_failures": self.object_memory_failures,
            "prototype_observations": self.prototype_observations,
            "prototype_failures": self.prototype_failures,
            "retrieval_calls": self.retrieval_calls,
            "retrieval_results": self.retrieval_results,
            "retrieval_failures": self.retrieval_failures,
            "degraded_cycles": self.degraded_cycles,
        }
