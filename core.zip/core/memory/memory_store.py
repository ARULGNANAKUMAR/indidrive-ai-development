"""
IndiDrive AI — Phase 5.1 | In-Memory Object Store
===================================================
Provides a thread-safe, bounded, offline-first in-memory store for
ObjectMemoryEntry records.  This is the only concrete MemoryStore for
Phase 5.1 — the abstract base class allows future phases to swap in a
persistent (on-disk) store without changing the ObjectMemory API.

Design:
    ObjectMemory
        ↓
    MemoryStore  (abstract interface)
        ↓
    InMemoryStore  (this file — dict-based, RLock-protected)

No network, no database, no cloud.  All operations are O(n) at worst
for cleanup; for n ≤ 10 000 that is sub-millisecond on any modern CPU.

Thread safety: an RLock guards all mutations and all reads that
iterate the store.  Concurrent reads that access a single existing
entry are safe because dict lookup is GIL-protected in CPython, but
we take the lock anyway for correctness across implementations.
"""
from __future__ import annotations

import abc
import threading
import time
from typing import Dict, Iterator, List, Optional

from .memory_types import (
    ObjectMemoryEntry,
    MemoryLifecycleState,
    MemoryCleanupPolicy,
    MemoryOperationResult,
    MemoryStoreStats,
)
from .memory_validation import validate_entry

__all__ = ["MemoryStore", "InMemoryStore"]


# ---------------------------------------------------------------------------
# Abstract interface
# ---------------------------------------------------------------------------

class MemoryStore(abc.ABC):
    """Abstract interface every concrete store must implement.

    Callers (ObjectMemory) should only depend on this interface so
    future phases can substitute a persistent on-disk store without
    touching calling code.
    """

    @abc.abstractmethod
    def add(self, entry: ObjectMemoryEntry) -> MemoryOperationResult:
        """Store a new entry.  Returns failure if memory_id already exists
        or validation fails."""

    @abc.abstractmethod
    def get(self, memory_id: str) -> Optional[ObjectMemoryEntry]:
        """Return the entry for memory_id, or None if absent."""

    @abc.abstractmethod
    def update(
        self, memory_id: str, updated_entry: ObjectMemoryEntry
    ) -> MemoryOperationResult:
        """Replace the stored entry for memory_id.  Returns failure if
        memory_id does not exist or validation of the new entry fails."""

    @abc.abstractmethod
    def remove(self, memory_id: str) -> MemoryOperationResult:
        """Delete the entry for memory_id."""

    @abc.abstractmethod
    def exists(self, memory_id: str) -> bool:
        """True iff memory_id is currently in the store."""

    @abc.abstractmethod
    def list_ids(self) -> List[str]:
        """Return all current memory_ids (stable order, not insertion order)."""

    @abc.abstractmethod
    def list_entries(self) -> List[ObjectMemoryEntry]:
        """Return a snapshot list of all entries."""

    @abc.abstractmethod
    def clear(self) -> int:
        """Remove all entries.  Returns number of entries removed."""

    @abc.abstractmethod
    def stats(self) -> MemoryStoreStats:
        """Return current usage statistics."""

    @abc.abstractmethod
    def cleanup(
        self,
        policy: MemoryCleanupPolicy,
        max_entries: int,
        max_age_s: Optional[float],
        now: Optional[float] = None,
    ) -> int:
        """Evict entries to satisfy capacity / age constraints.
        Returns number of entries removed."""


# ---------------------------------------------------------------------------
# In-memory implementation
# ---------------------------------------------------------------------------

class InMemoryStore(MemoryStore):
    """Thread-safe dict-backed store.  All operations take an RLock."""

    def __init__(self) -> None:
        self._lock: threading.RLock = threading.RLock()
        self._data: Dict[str, ObjectMemoryEntry] = {}

    # ---- add ---------------------------------------------------------------

    def add(self, entry: ObjectMemoryEntry) -> MemoryOperationResult:
        result = validate_entry(entry)
        if not result.ok:
            return result
        with self._lock:
            if entry.memory_id in self._data:
                return MemoryOperationResult.failure(
                    f"memory_id={entry.memory_id!r} already exists; use update()",
                    memory_id=entry.memory_id,
                )
            self._data[entry.memory_id] = entry
        return MemoryOperationResult.success(entry.memory_id)

    # ---- get ---------------------------------------------------------------

    def get(self, memory_id: str) -> Optional[ObjectMemoryEntry]:
        with self._lock:
            return self._data.get(memory_id)

    # ---- update ------------------------------------------------------------

    def update(
        self, memory_id: str, updated_entry: ObjectMemoryEntry
    ) -> MemoryOperationResult:
        result = validate_entry(updated_entry)
        if not result.ok:
            return result
        if updated_entry.memory_id != memory_id:
            return MemoryOperationResult.failure(
                f"updated_entry.memory_id={updated_entry.memory_id!r} "
                f"does not match key memory_id={memory_id!r}",
                memory_id=memory_id,
            )
        with self._lock:
            if memory_id not in self._data:
                return MemoryOperationResult.failure(
                    f"memory_id={memory_id!r} not found; use add() for new entries",
                    memory_id=memory_id,
                )
            self._data[memory_id] = updated_entry
        return MemoryOperationResult.success(memory_id)

    # ---- remove ------------------------------------------------------------

    def remove(self, memory_id: str) -> MemoryOperationResult:
        with self._lock:
            if memory_id not in self._data:
                return MemoryOperationResult.failure(
                    f"memory_id={memory_id!r} not found", memory_id=memory_id
                )
            del self._data[memory_id]
        return MemoryOperationResult.success(memory_id)

    # ---- exists ------------------------------------------------------------

    def exists(self, memory_id: str) -> bool:
        with self._lock:
            return memory_id in self._data

    # ---- list --------------------------------------------------------------

    def list_ids(self) -> List[str]:
        with self._lock:
            return sorted(self._data.keys())

    def list_entries(self) -> List[ObjectMemoryEntry]:
        with self._lock:
            return list(self._data.values())

    # ---- clear -------------------------------------------------------------

    def clear(self) -> int:
        with self._lock:
            n = len(self._data)
            self._data.clear()
        return n

    # ---- stats -------------------------------------------------------------

    def stats(self) -> MemoryStoreStats:
        with self._lock:
            total = len(self._data)
            counts: Dict[MemoryLifecycleState, int] = {}
            for e in self._data.values():
                counts[e.lifecycle_state] = counts.get(e.lifecycle_state, 0) + 1
        return MemoryStoreStats(
            total_entries=total,
            new_entries=counts.get(MemoryLifecycleState.NEW, 0),
            active_entries=counts.get(MemoryLifecycleState.ACTIVE, 0),
            stale_entries=counts.get(MemoryLifecycleState.STALE, 0),
            expired_entries=counts.get(MemoryLifecycleState.EXPIRED, 0),
            max_capacity=0,   # set by ObjectMemory layer, not the raw store
            utilization_fraction=0.0,
        )

    # ---- cleanup -----------------------------------------------------------

    def cleanup(
        self,
        policy: MemoryCleanupPolicy,
        max_entries: int,
        max_age_s: Optional[float],
        now: Optional[float] = None,
    ) -> int:
        """Evict expired entries first, then apply policy to meet capacity.

        Returns count of entries removed.  Deterministic for a given
        (store state, policy, max_entries, max_age_s, now) tuple.
        """
        if now is None:
            now = time.time()
        removed = 0

        with self._lock:
            # --- Step 1: age out / mark expired ----------------------------
            if max_age_s is not None:
                to_expire = []
                for mid, entry in self._data.items():
                    age = now - entry.observed_at
                    if age > max_age_s:
                        to_expire.append(mid)
                # Delete expired entries
                for mid in to_expire:
                    del self._data[mid]
                    removed += len(to_expire) > 0 and True  # noqa: counted below
                removed = len(to_expire)  # more accurate

            # --- Step 2: capacity enforcement ------------------------------
            overflow = len(self._data) - max_entries
            if overflow <= 0:
                return removed

            candidates = list(self._data.values())

            if policy == MemoryCleanupPolicy.OLDEST_FIRST:
                # Sort by created_at ascending — oldest first for eviction
                candidates.sort(key=lambda e: e.created_at)
            elif policy == MemoryCleanupPolicy.STALE_FIRST:
                # EXPIRED → STALE → NEW → ACTIVE (worst first)
                _rank = {
                    MemoryLifecycleState.EXPIRED: 0,
                    MemoryLifecycleState.STALE: 1,
                    MemoryLifecycleState.NEW: 2,
                    MemoryLifecycleState.ACTIVE: 3,
                }
                candidates.sort(key=lambda e: (_rank.get(e.lifecycle_state, 2), e.created_at))
            elif policy == MemoryCleanupPolicy.LOWEST_CONFIDENCE:
                # Lowest confidence first; tie-break by created_at
                candidates.sort(key=lambda e: (e.confidence, e.created_at))
            else:
                # Fallback: oldest first
                candidates.sort(key=lambda e: e.created_at)

            to_evict = candidates[:overflow]
            for entry in to_evict:
                if entry.memory_id in self._data:
                    del self._data[entry.memory_id]
                    removed += 1

        return removed
