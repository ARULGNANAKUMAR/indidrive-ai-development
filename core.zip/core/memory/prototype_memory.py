"""
IndiDrive AI — Phase 5.2 | Feature / Prototype Memory Core
=============================================================
Public API for the Object Prototype layer. Sits alongside (not on top
of, and not duplicating) the Phase 5.1 ObjectMemory:

    core.memory.ObjectMemory        -> individual tracked-object memory
    core.memory.PrototypeMemory     -> compact category-level knowledge

PrototypeMemory wraps a PrototypeStore and adds:
  * feature validation before folding an observation in
  * deterministic incremental statistics update (see prototype_types.py)
  * bounded capacity with deterministic eviction
  * configuration integration (core.config_loader, feature_memory section)
  * structured logging via the existing core.logging_system
  * thread safety (delegated to InMemoryPrototypeStore)

This is OFFLINE-FIRST — no network, no cloud, no external database,
no LLM.

Phase boundary: Phase 5.2 only. Do NOT add retrieval, nearest-neighbour
search, or learning here — see feature_types.feature_distance() for the
one narrow exception (a plain pairwise distance primitive).
"""
from __future__ import annotations

import logging
import threading
import time
from typing import Dict, List, Optional

from core.config_loader import get as _cfg_get
from core.logging_system import get_logger as _get_logger

from .memory_types import MemoryOperationResult, MemoryCleanupPolicy
from .feature_types import (
    ObjectFeatureSet,
    DEFAULT_MAX_DESCRIPTOR_DIM,
    validate_feature_set,
)
from .prototype_types import ObjectPrototype, prototype_key_for, update_prototype
from .prototype_store import PrototypeStore, InMemoryPrototypeStore

__all__ = ["PrototypeMemory"]

_LOG_CAT = "system"  # reuse existing log category, same as Phase 5.1


def _log() -> logging.Logger:
    try:
        return _get_logger(_LOG_CAT)
    except Exception:
        return logging.getLogger("indidrive.memory.prototype")


# ---------------------------------------------------------------------------
# Config helpers
# ---------------------------------------------------------------------------

_DEFAULT_ENABLED: bool = True
_DEFAULT_MAX_PROTOTYPES: int = 2_000
_DEFAULT_MAX_FEATURE_DIMENSION: int = DEFAULT_MAX_DESCRIPTOR_DIM
_DEFAULT_MINIMUM_CONFIDENCE: float = 0.0
_DEFAULT_CLEANUP_POLICY: MemoryCleanupPolicy = MemoryCleanupPolicy.LOWEST_CONFIDENCE


def _load_config() -> Dict:
    """Load feature_memory section from prediction_config.yaml, or use
    defaults. Does not raise — degrades gracefully if config is absent."""
    try:
        raw = _cfg_get("prediction", "feature_memory")
        if isinstance(raw, dict):
            return raw
    except Exception:
        pass
    return {}


def _resolve_policy(name: str) -> MemoryCleanupPolicy:
    try:
        return MemoryCleanupPolicy(name.upper())
    except (AttributeError, ValueError):
        return _DEFAULT_CLEANUP_POLICY


# ---------------------------------------------------------------------------
# PrototypeMemory
# ---------------------------------------------------------------------------

class PrototypeMemory:
    """Bounded, thread-safe, offline-first Object Prototype Memory.

    Parameters
    ----------
    store : PrototypeStore, optional
        Inject a custom store (useful for testing). Defaults to a
        fresh InMemoryPrototypeStore.
    max_prototypes : int, optional
        Maximum number of prototypes before cleanup. Overrides config.
    max_feature_dimension : int, optional
        Hard bound on descriptor vector length. Overrides config.
    minimum_confidence : float, optional
        Observations below this confidence are rejected before folding
        into a prototype (quality gate). Overrides config.
    cleanup_policy : MemoryCleanupPolicy, optional
        Eviction strategy when at capacity. Overrides config.
    enabled : bool, optional
        When False, all mutating operations are no-ops.
    """

    def __init__(
        self,
        *,
        store: Optional[PrototypeStore] = None,
        max_prototypes: Optional[int] = None,
        max_feature_dimension: Optional[int] = None,
        minimum_confidence: Optional[float] = None,
        cleanup_policy: Optional[MemoryCleanupPolicy] = None,
        enabled: Optional[bool] = None,
    ) -> None:
        cfg = _load_config()

        self._enabled: bool = (
            enabled if enabled is not None else bool(cfg.get("enabled", _DEFAULT_ENABLED))
        )
        self._max_prototypes: int = (
            max_prototypes if max_prototypes is not None
            else int(cfg.get("max_prototypes", _DEFAULT_MAX_PROTOTYPES))
        )
        self._max_feature_dimension: int = (
            max_feature_dimension if max_feature_dimension is not None
            else int(cfg.get("max_feature_dimension", _DEFAULT_MAX_FEATURE_DIMENSION))
        )
        self._minimum_confidence: float = (
            minimum_confidence if minimum_confidence is not None
            else float(cfg.get("minimum_confidence", _DEFAULT_MINIMUM_CONFIDENCE))
        )
        if cleanup_policy is not None:
            self._cleanup_policy = cleanup_policy
        else:
            self._cleanup_policy = _resolve_policy(
                str(cfg.get("cleanup_policy", _DEFAULT_CLEANUP_POLICY.value))
            )

        self._store: PrototypeStore = store if store is not None else InMemoryPrototypeStore()
        self._update_lock: threading.Lock = threading.Lock()

        _log().debug(
            "PrototypeMemory initialised",
            extra={
                "max_prototypes": self._max_prototypes,
                "max_feature_dimension": self._max_feature_dimension,
                "minimum_confidence": self._minimum_confidence,
                "cleanup_policy": self._cleanup_policy.value,
                "enabled": self._enabled,
            } if hasattr(_log(), "debug") else {},
        )

    # -----------------------------------------------------------------------
    # Core operation: fold an observation into a prototype
    # -----------------------------------------------------------------------

    def observe(
        self, feature: ObjectFeatureSet, observed_at: Optional[float] = None
    ) -> MemoryOperationResult:
        """Validate `feature` and incrementally fold it into the
        matching prototype (creating one if this is the first
        observation of that object_type/subtype).

        Returns MemoryOperationResult — never raises for invalid input.
        """
        if not self._enabled:
            return MemoryOperationResult.failure("PrototypeMemory is disabled")

        result = validate_feature_set(feature, self._max_feature_dimension)
        if not result.ok:
            _log().warning("PrototypeMemory.observe() rejected feature: %s", result.reason)
            return result

        if feature.confidence < self._minimum_confidence:
            reason = (
                f"confidence={feature.confidence!r} below minimum_confidence="
                f"{self._minimum_confidence!r}"
            )
            _log().debug("PrototypeMemory.observe() skipped: %s", reason)
            return MemoryOperationResult.failure(reason)

        key = prototype_key_for(feature.object_type, feature.subtype)
        now = observed_at if observed_at is not None else time.time()

        # Serialise read-modify-write so concurrent observations of the
        # same prototype key cannot race and lose an update.
        with self._update_lock:
            existing = self._store.get(key)
            was_new = existing is None

            if was_new:
                current_total = len(self._store.list_keys())
                if current_total >= self._max_prototypes:
                    removed = self._store.cleanup(
                        policy=self._cleanup_policy,
                        max_prototypes=self._max_prototypes - 1,
                    )
                    _log().debug(
                        "PrototypeMemory capacity cleanup removed %d prototypes", removed
                    )

            updated = update_prototype(existing, feature, prototype_key=key, observed_at=now)
            op = self._store.put(updated)

        if op.ok:
            _log().debug("PrototypeMemory.observe() updated prototype_key=%s", key)
        else:
            _log().warning("PrototypeMemory.observe() failed: %s", op.reason)
        return op

    # -----------------------------------------------------------------------
    # Read access
    # -----------------------------------------------------------------------

    def get(self, prototype_key: str) -> Optional[ObjectPrototype]:
        return self._store.get(prototype_key)

    def get_for(self, object_type: str, subtype: Optional[str] = None) -> Optional[ObjectPrototype]:
        return self._store.get(prototype_key_for(object_type, subtype))

    def exists(self, prototype_key: str) -> bool:
        return self._store.exists(prototype_key)

    def list(self) -> List[ObjectPrototype]:
        return self._store.list_prototypes()

    def list_keys(self) -> List[str]:
        return self._store.list_keys()

    # -----------------------------------------------------------------------
    # Removal / reset
    # -----------------------------------------------------------------------

    def remove(self, prototype_key: str) -> MemoryOperationResult:
        if not self._enabled:
            return MemoryOperationResult.failure("PrototypeMemory is disabled")
        return self._store.remove(prototype_key)

    def clear(self) -> int:
        """Remove all prototypes. Safe regardless of _enabled flag."""
        return self._store.clear()

    # -----------------------------------------------------------------------
    # Capacity management
    # -----------------------------------------------------------------------

    def cleanup(self, now: Optional[float] = None) -> int:
        """Enforce max_prototypes using the configured cleanup policy.
        Returns count removed. Deterministic for a given store state."""
        if not self._enabled:
            return 0
        return self._store.cleanup(
            policy=self._cleanup_policy, max_prototypes=self._max_prototypes, now=now
        )

    # -----------------------------------------------------------------------
    # Properties
    # -----------------------------------------------------------------------

    @property
    def max_prototypes(self) -> int:
        return self._max_prototypes

    @property
    def max_feature_dimension(self) -> int:
        return self._max_feature_dimension

    @property
    def minimum_confidence(self) -> float:
        return self._minimum_confidence

    @property
    def cleanup_policy(self) -> MemoryCleanupPolicy:
        return self._cleanup_policy

    @property
    def enabled(self) -> bool:
        return self._enabled
