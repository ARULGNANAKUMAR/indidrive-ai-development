"""
IndiDrive AI — Phase 0 | Health Check
========================================
Inspects the actual state of the project: Python version, installed
packages, configuration, directories, CARLA availability, sensor
config, model/dataset directories, logging, and whether the project's
own modules import cleanly.

Nothing here is marked PASS unless it was actually verified in this
process. Optional/environment-dependent components (CARLA, camera,
LiDAR, the FastAPI server stack in a sandbox with no network) produce
WARN, not FAIL, and never crash the caller.
"""
from __future__ import annotations

import importlib
import re
import sys
from pathlib import Path

from core.health.component_status import ComponentStatus, PASS, WARN, FAIL, overall_status

ROOT = Path(__file__).resolve().parent.parent.parent

# requirements.txt package name -> importable module name, where they differ.
_IMPORT_NAME_OVERRIDES = {
    "pyyaml": "yaml",
    "flask-cors": "flask_cors",
    "opencv-python": "cv2",
    "uvicorn[standard]": "uvicorn",
}

# Packages that are genuinely optional per requirements.txt / docs/INSTALLATION.md —
# their absence degrades a specific feature but must not fail the health check.
# flask-cors is included here because legacy_simulator/server.py already wraps its
# import in try/except and runs without CORS support if it's missing (HAS_CORS flag) —
# verified by reading that code, not assumed.
_OPTIONAL_PACKAGES = {"reportlab", "ultralytics", "a2wsgi", "flask-cors"}

MIN_PYTHON = (3, 10)


def _parse_requirements() -> list[str]:
    req_path = ROOT / "requirements.txt"
    if not req_path.exists():
        return []
    names = []
    for line in req_path.read_text().splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        pkg = re.split(r"[<>=!;\s]", line, maxsplit=1)[0]
        if pkg:
            names.append(pkg)
    return names


def check_python_version() -> ComponentStatus:
    actual = sys.version_info[:2]
    if actual >= MIN_PYTHON:
        return ComponentStatus("Python", PASS, f"Python {actual[0]}.{actual[1]} (>= {MIN_PYTHON[0]}.{MIN_PYTHON[1]} required)")
    return ComponentStatus("Python", FAIL, f"Python {actual[0]}.{actual[1]} is below the required {MIN_PYTHON[0]}.{MIN_PYTHON[1]}")


def check_dependencies() -> ComponentStatus:
    packages = _parse_requirements()
    if not packages:
        return ComponentStatus("Dependencies", WARN, "requirements.txt not found or empty")

    missing_required, missing_optional, present = [], [], []
    for pkg in packages:
        import_name = _IMPORT_NAME_OVERRIDES.get(pkg.lower(), pkg.replace("-", "_"))
        try:
            importlib.import_module(import_name)
            present.append(pkg)
        except ImportError:
            (missing_optional if pkg.lower() in _OPTIONAL_PACKAGES else missing_required).append(pkg)

    details = {"present": present, "missing_required": missing_required, "missing_optional": missing_optional}
    if missing_required:
        return ComponentStatus(
            "Dependencies", WARN,
            f"{len(missing_required)} required package(s) not installed: {', '.join(missing_required)}. "
            "Run: pip install -r requirements.txt --break-system-packages",
            details,
        )
    if missing_optional:
        return ComponentStatus(
            "Dependencies", WARN,
            f"{len(present)}/{len(packages)} installed; optional package(s) missing: {', '.join(missing_optional)}",
            details,
        )
    return ComponentStatus("Dependencies", PASS, f"All {len(packages)} packages importable", details)


def check_configuration() -> ComponentStatus:
    from core.config_loader import load_all_configs, ConfigError
    try:
        cfgs = load_all_configs()
        return ComponentStatus("Configuration", PASS, f"Loaded {len(cfgs)} config files", {"files": list(cfgs)})
    except ConfigError as e:
        return ComponentStatus("Configuration", FAIL, str(e))


def check_project_structure() -> ComponentStatus:
    expected = ["config", "docs", "logs", "data", "models", "tests", "storage",
                "core", "api", "frontend", "legacy_simulator"]
    missing = [d for d in expected if not (ROOT / d).is_dir()]
    if missing:
        return ComponentStatus("Project Structure", WARN, f"Missing directories: {', '.join(missing)}",
                                {"missing": missing})
    return ComponentStatus("Project Structure", PASS, f"All {len(expected)} expected directories present")


def check_carla() -> ComponentStatus:
    try:
        importlib.import_module("core.carla_integration.connection")
    except Exception as e:
        return ComponentStatus("CARLA", FAIL, f"core.carla_integration.connection failed to import: {e}")
    try:
        importlib.import_module("carla")
        return ComponentStatus("CARLA", PASS, "carla package installed and client wrapper importable")
    except ImportError:
        return ComponentStatus(
            "CARLA", WARN,
            "carla package not installed (expected in a dev sandbox — it is not a normal PyPI wheel; "
            "install from CARLA's own PythonAPI distribution, see docs/CARLA_SETUP.md). "
            "Client wrapper code itself imports cleanly.",
        )


def check_camera_lidar() -> tuple[ComponentStatus, ComponentStatus]:
    try:
        importlib.import_module("core.carla_integration.sensors")
        wrapper_ok = True
        wrapper_err = ""
    except Exception as e:
        wrapper_ok = False
        wrapper_err = str(e)

    try:
        importlib.import_module("carla")
        carla_present = True
    except ImportError:
        carla_present = False

    if not wrapper_ok:
        cam = ComponentStatus("Camera", FAIL, f"sensor module failed to import: {wrapper_err}")
        lidar = ComponentStatus("LiDAR", FAIL, f"sensor module failed to import: {wrapper_err}")
        return cam, lidar

    if carla_present:
        cam = ComponentStatus("Camera", PASS, "sensor module importable, carla package present")
        lidar = ComponentStatus("LiDAR", PASS, "sensor module importable, carla package present")
    else:
        cam = ComponentStatus("Camera", WARN, "sensor module importable, but only usable with a live CARLA server (carla package not installed)")
        lidar = ComponentStatus("LiDAR", WARN, "sensor module importable, but only usable with a live CARLA server (carla package not installed)")
    return cam, lidar


def check_dataset() -> ComponentStatus:
    try:
        from core.dataset.manager import DatasetManager
        mgr = DatasetManager()
        datasets = mgr.list_datasets()
        return ComponentStatus("Dataset", PASS, f"DatasetManager importable, {len(datasets)} dataset(s) registered")
    except Exception as e:
        return ComponentStatus("Dataset", FAIL, f"DatasetManager failed: {e}")


def check_models() -> ComponentStatus:
    try:
        from core.models.manager import ModelManager
        mgr = ModelManager()
        data = mgr.list_models()
        return ComponentStatus("Models", PASS, f"ModelManager importable, {len(data.get('models', []))} model(s) registered")
    except Exception as e:
        return ComponentStatus("Models", FAIL, f"ModelManager failed: {e}")


def check_logging() -> ComponentStatus:
    try:
        from core.logging_system import ensure_log_directories, CATEGORIES
        created = ensure_log_directories()
        missing = [c for c in CATEGORIES if not (ROOT / "logs" / c).is_dir()]
        if missing:
            return ComponentStatus("Logging", FAIL, f"Could not create log dirs: {missing}")
        return ComponentStatus("Logging", PASS, f"All {len(CATEGORIES)} log categories present", {"newly_created": created})
    except Exception as e:
        return ComponentStatus("Logging", FAIL, f"Logging system failed: {e}")


def check_core_modules() -> ComponentStatus:
    modules = [
        "core.dataset.manager", "core.models.manager", "core.echo.echo_v2",
        "core.benchmark.suite", "core.scenarios.manager", "core.reports.generator",
        "core.deployment", "core.modes",
    ]
    failed = {}
    for m in modules:
        try:
            importlib.import_module(m)
        except Exception as e:
            failed[m] = str(e)
    if failed:
        return ComponentStatus("Core Modules", FAIL, f"{len(failed)}/{len(modules)} modules failed to import", failed)
    return ComponentStatus("Core Modules", PASS, f"All {len(modules)} core modules import cleanly")


def check_legacy_simulator() -> ComponentStatus:
    legacy_dir = ROOT / "legacy_simulator"
    if not legacy_dir.exists():
        return ComponentStatus("Legacy Simulator", FAIL, "legacy_simulator/ directory missing")
    sys.path.insert(0, str(legacy_dir))
    try:
        server_mod = importlib.import_module("server")
        importlib.reload(server_mod)  # ensure a clean import even if cached oddly
        n_routes = len(server_mod.app.url_map._rules)
        return ComponentStatus("Legacy Simulator", PASS, f"Flask app imports cleanly, {n_routes} routes registered")
    except Exception as e:
        return ComponentStatus("Legacy Simulator", FAIL, f"legacy_simulator/server.py failed to import: {e}")


def check_api_server() -> ComponentStatus:
    try:
        importlib.import_module("api.server")
        return ComponentStatus("API Server", PASS, "api/server.py (FastAPI) imports cleanly")
    except ImportError as e:
        return ComponentStatus(
            "API Server", WARN,
            f"api/server.py could not be imported (missing dependency: {e}). "
            "Run: pip install -r requirements.txt --break-system-packages",
        )
    except Exception as e:
        return ComponentStatus("API Server", FAIL, f"api/server.py raised a non-import error: {e}")


def run_health_check() -> dict:
    """Runs every check and returns {components: [...], overall: 'READY'|'DEGRADED'|'NOT READY'}."""
    components: list[ComponentStatus] = [
        check_python_version(),
        check_configuration(),
        check_dependencies(),
        check_project_structure(),
        check_carla(),
    ]
    cam, lidar = check_camera_lidar()
    components += [cam, lidar]
    components += [
        check_dataset(),
        check_models(),
        check_logging(),
        check_core_modules(),
        check_legacy_simulator(),
        check_api_server(),
    ]
    return {
        "components": [c.to_dict() for c in components],
        "overall": overall_status(components),
    }
