"""
IndiDrive AI — Phase 0 | Health Check: Component Status
===========================================================
Small, dependency-free status types shared by health_check.py and
system_report.py.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

PASS = "PASS"
WARN = "WARN"
FAIL = "FAIL"

VALID_STATUSES = (PASS, WARN, FAIL)


@dataclass
class ComponentStatus:
    name: str
    status: str                      # PASS | WARN | FAIL
    message: str = ""
    details: dict = field(default_factory=dict)

    def __post_init__(self):
        if self.status not in VALID_STATUSES:
            raise ValueError(f"Invalid status '{self.status}' for component '{self.name}'. "
                              f"Expected one of {VALID_STATUSES}.")

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "status": self.status,
            "message": self.message,
            "details": self.details,
        }


def overall_status(components: list[ComponentStatus]) -> str:
    """
    READY      - every component PASS (WARNs on genuinely optional
                 components like CARLA/Camera/LiDAR still count as READY
                 since Phase 0 does not require a live CARLA server).
    DEGRADED   - at least one WARN, no FAIL.
    NOT READY  - at least one FAIL.
    """
    statuses = [c.status for c in components]
    if FAIL in statuses:
        return "NOT READY"
    if WARN in statuses:
        return "DEGRADED"
    return "READY"
