"""
IndiDrive AI — Phase 0 | Health Check: System Report
=========================================================
Formats the output of health_check.run_health_check() as the
human-readable console report and as JSON.
"""
from __future__ import annotations

import json
import time

from core.health.health_check import run_health_check

BANNER = "INDIDRIVE AI SYSTEM HEALTH"


def format_report(result: dict) -> str:
    lines = [BANNER, "=" * len(BANNER), ""]
    name_width = max((len(c["name"]) for c in result["components"]), default=10) + 2
    for c in result["components"]:
        lines.append(f"{c['name']:<{name_width}}{c['status']}")
        if c["status"] != "PASS" and c["message"]:
            lines.append(f"{'':<{name_width}}  -> {c['message']}")
    lines.append("")
    lines.append(f"Overall: {result['overall']}")
    return "\n".join(lines)


def run_and_print() -> dict:
    result = run_health_check()
    print(format_report(result))
    return result


def run_and_time() -> dict:
    """Runs the health check and returns the result plus wall-clock execution time in seconds."""
    start = time.perf_counter()
    result = run_health_check()
    elapsed = time.perf_counter() - start
    result["execution_time_seconds"] = round(elapsed, 4)
    return result


def run_and_json() -> str:
    return json.dumps(run_health_check(), indent=2)


if __name__ == "__main__":
    import sys
    result = run_and_print()
    sys.exit(0 if result["overall"] != "NOT READY" else 1)
