"""
IndiDrive AI — Phase 5 | Scenario Manager
Predefined Indian road scenarios + randomized scenario generation for
feeding the benchmark suite and the Phase 1 3D frontend.
"""
from __future__ import annotations
import random
import time
import uuid
from typing import Optional

PREDEFINED_SCENARIOS = {
    "village_road":       {"road_type": "RURAL",  "weather": "sunny", "traffic_density": "low",
                            "hazards": ["potholes", "unmarked_lanes", "livestock"]},
    "market_road":         {"road_type": "URBAN",  "weather": "sunny", "traffic_density": "very_high",
                            "hazards": ["pedestrians", "hand_carts", "double_parking"]},
    "highway":             {"road_type": "HIGHWAY", "weather": "clear", "traffic_density": "medium",
                            "hazards": ["high_speed_merges", "lane_changes"]},
    "school_zone":         {"road_type": "URBAN",  "weather": "sunny", "traffic_density": "medium",
                            "hazards": ["children_crossing", "school_buses"]},
    "hospital_area":       {"road_type": "URBAN",  "weather": "sunny", "traffic_density": "medium",
                            "hazards": ["ambulances", "pedestrians", "no_honking_zone"]},
    "rain":                {"road_type": "URBAN",  "weather": "rain", "traffic_density": "medium",
                            "hazards": ["low_traction", "waterlogging", "reduced_visibility"]},
    "fog":                 {"road_type": "HIGHWAY", "weather": "fog", "traffic_density": "low",
                            "hazards": ["low_visibility", "slow_moving_vehicles"]},
    "night":               {"road_type": "URBAN",  "weather": "clear_night", "traffic_density": "low",
                            "hazards": ["glare", "unlit_pedestrians", "unlit_vehicles"]},
    "cattle_crossing":     {"road_type": "RURAL",  "weather": "sunny", "traffic_density": "low",
                            "hazards": ["livestock_on_road", "sudden_stop_required"]},
    "wrong_side_traffic":  {"road_type": "URBAN",  "weather": "sunny", "traffic_density": "medium",
                            "hazards": ["oncoming_wrong_lane", "evasive_maneuver_required"]},
    "construction_zone":   {"road_type": "URBAN",  "weather": "sunny", "traffic_density": "medium",
                            "hazards": ["lane_closure", "workers_on_road", "uneven_surface"]},
}


class ScenarioManager:
    def list_scenarios(self) -> dict:
        return PREDEFINED_SCENARIOS

    def get_scenario(self, name: str) -> dict:
        if name not in PREDEFINED_SCENARIOS:
            raise KeyError(f"unknown scenario '{name}'")
        return {"name": name, **PREDEFINED_SCENARIOS[name]}

    def random_scenario(self, seed: Optional[int] = None) -> dict:
        rng = random.Random(seed)
        name = rng.choice(list(PREDEFINED_SCENARIOS.keys()))
        base = dict(PREDEFINED_SCENARIOS[name])
        # Add some randomized perturbation so repeated runs aren't identical.
        base["scenario_run_id"] = uuid.uuid4().hex[:8]
        base["name"] = name
        base["ego_speed_kmph"] = rng.choice([15, 25, 35, 45, 60, 80])
        base["object_count"] = rng.randint(2, 25)
        base["generated_at"] = time.time()
        return base

    def combine(self, names: list[str]) -> dict:
        """Compound scenario, e.g. ['rain', 'night', 'market_road']."""
        hazards, road_types, weathers = [], [], []
        for n in names:
            s = self.get_scenario(n)
            hazards += s["hazards"]
            road_types.append(s["road_type"])
            weathers.append(s["weather"])
        return {
            "name": "+".join(names),
            "road_type": road_types[-1],
            "weather": weathers[-1] if "rain" not in weathers and "fog" not in weathers else
                       next((w for w in weathers if w in ("rain", "fog")), weathers[-1]),
            "hazards": sorted(set(hazards)),
        }

