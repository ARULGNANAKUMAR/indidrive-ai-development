"""
IndiDrive AI — Phase 11.4 | Recovery Manager
=============================================
Lightweight evidence-based recovery state tracker for sensors and
subsystems.

Design rules:
  * Tracks logical recovery state only — does NOT restart devices, does NOT
    reconnect hardware, does NOT manipulate OS-level devices.
  * Evidence-based: requires configurable consecutive healthy cycles before
    confirming recovery.
  * Hysteresis on both failure entry and recovery exit.
  * Deterministic — no random values, no wall-clock inside logic.
  * Uses bounded state — no unlimited history.
  * Thread-safe via per-instance lock.
"""
from __future__ import annotations

import math
import threading
from dataclasses import dataclass, field
from typing import Dict, Optional

from .failsafe_config import FailSafeConfig
from .failsafe_types import RecoveryStatus

__all__ = ["RecoveryManager", "ComponentRecoveryState"]


@dataclass
class ComponentRecoveryState:
    """
    Bounded recovery state for one sensor or subsystem.

    Fields
    ------
    component_id             : Unique string identifier for the component.
    recovery_status          : Current RecoveryStatus enum value.
    consecutive_failure_count: Cycles the component has been in a failure state.
    consecutive_healthy_count: Cycles the component has been healthy (for recovery).
    first_detected_at        : Timestamp when the failure was first detected.
    latest_timestamp         : Timestamp from the most recent observation.
    active                   : True if there is an active failure.
    blocked                  : True if recovery is blocked by external condition.
    blocked_reason           : String reason for block (empty if not blocked).
    """
    component_id:              str            = ""
    recovery_status:           RecoveryStatus = RecoveryStatus.NOT_REQUIRED
    consecutive_failure_count: int            = 0
    consecutive_healthy_count: int            = 0
    first_detected_at:         float          = 0.0
    latest_timestamp:          float          = 0.0
    active:                    bool           = False
    blocked:                   bool           = False
    blocked_reason:            str            = ""


class RecoveryManager:
    """
    Manages logical recovery state for a collection of named components
    (sensors or subsystems).

    Usage
    -----
    On every pipeline cycle:
      1. Call record_failure(component_id, timestamp) when a failure is detected.
      2. Call record_healthy(component_id, timestamp) when the component appears healthy.
      3. Call get_status(component_id) to read the current RecoveryStatus.
      4. Call block_recovery(component_id, reason) / unblock_recovery() as needed.
      5. Call get_state(component_id) for the full ComponentRecoveryState snapshot.

    The manager does NOT determine whether a component is healthy or failed —
    that is the job of the sensor_failure classifier and subsystem evaluators.
    It only tracks the lifecycle: confirmed failure → pending → validating → recovered.
    """

    def __init__(self, config: FailSafeConfig) -> None:
        self._config = config
        self._lock = threading.Lock()
        self._states: Dict[str, ComponentRecoveryState] = {}

    # ------------------------------------------------------------------
    # Public API

    def record_failure(self, component_id: str, timestamp: float) -> RecoveryStatus:
        """
        Record one failure cycle for the component.

        Returns the updated RecoveryStatus after applying hysteresis.
        If the failure count reaches failure_confirmation_cycles, the
        component transitions to active failure.
        """
        with self._lock:
            state = self._get_or_create(component_id)
            state.consecutive_healthy_count = 0
            state.consecutive_failure_count += 1
            state.latest_timestamp = timestamp

            if not state.active:
                if state.consecutive_failure_count >= self._config.failure_confirmation_cycles:
                    state.active = True
                    if state.first_detected_at == 0.0:
                        state.first_detected_at = timestamp
                    state.recovery_status = RecoveryStatus.NOT_REQUIRED
                # else: still within confirmation window — not yet active

            elif state.active:
                # Reset any recovery progress
                if state.recovery_status in (
                    RecoveryStatus.RECOVERY_PENDING,
                    RecoveryStatus.RECOVERY_VALIDATING,
                ):
                    state.recovery_status = RecoveryStatus.NOT_REQUIRED

            return state.recovery_status

    def record_healthy(self, component_id: str, timestamp: float) -> RecoveryStatus:
        """
        Record one healthy cycle for the component.

        Returns the updated RecoveryStatus.
        Healthy cycles accumulate toward recovery confirmation.
        If the component was not previously in failure, resets state cleanly.
        """
        with self._lock:
            state = self._get_or_create(component_id)
            state.latest_timestamp = timestamp

            if not state.active:
                # Was never in confirmed failure — just track healthy state
                state.consecutive_failure_count = 0
                state.consecutive_healthy_count += 1
                state.recovery_status = RecoveryStatus.NOT_REQUIRED
                return state.recovery_status

            # Active failure — accumulate recovery evidence
            state.consecutive_failure_count = 0
            state.consecutive_healthy_count += 1

            if state.blocked:
                state.recovery_status = RecoveryStatus.RECOVERY_BLOCKED
                return state.recovery_status

            # Transition through recovery states
            cfg = self._config
            if state.consecutive_healthy_count == 1:
                state.recovery_status = RecoveryStatus.RECOVERY_PENDING
            elif state.consecutive_healthy_count < cfg.recovery_confirmation_cycles:
                state.recovery_status = RecoveryStatus.RECOVERY_VALIDATING
            else:
                # Sufficient clean cycles
                state.recovery_status = RecoveryStatus.RECOVERY_CONFIRMED
                state.active = False
                state.consecutive_failure_count = 0
                state.first_detected_at = 0.0

            return state.recovery_status

    def block_recovery(self, component_id: str, reason: str) -> None:
        """
        Block recovery for a component (e.g. because active emergency exists
        or the Safety Supervisor has not permitted recovery).
        """
        with self._lock:
            state = self._get_or_create(component_id)
            state.blocked = True
            state.blocked_reason = reason
            if state.active and state.recovery_status not in (
                RecoveryStatus.RECOVERY_CONFIRMED,
                RecoveryStatus.NOT_REQUIRED,
            ):
                state.recovery_status = RecoveryStatus.RECOVERY_BLOCKED

    def unblock_recovery(self, component_id: str) -> None:
        """Remove recovery block for a component."""
        with self._lock:
            state = self._get_or_create(component_id)
            state.blocked = False
            state.blocked_reason = ""
            if state.recovery_status == RecoveryStatus.RECOVERY_BLOCKED:
                if state.consecutive_healthy_count > 0:
                    state.recovery_status = RecoveryStatus.RECOVERY_PENDING
                else:
                    state.recovery_status = RecoveryStatus.NOT_REQUIRED

    def get_status(self, component_id: str) -> RecoveryStatus:
        """Return the current RecoveryStatus for a component."""
        with self._lock:
            state = self._states.get(component_id)
            if state is None:
                return RecoveryStatus.NOT_REQUIRED
            return state.recovery_status

    def is_active_failure(self, component_id: str) -> bool:
        """True if there is a confirmed active failure for this component."""
        with self._lock:
            state = self._states.get(component_id)
            return state.active if state is not None else False

    def get_state(self, component_id: str) -> Optional[ComponentRecoveryState]:
        """Return a snapshot copy of the ComponentRecoveryState (or None)."""
        with self._lock:
            state = self._states.get(component_id)
            if state is None:
                return None
            # Return a shallow copy to avoid external mutation
            return ComponentRecoveryState(
                component_id=state.component_id,
                recovery_status=state.recovery_status,
                consecutive_failure_count=state.consecutive_failure_count,
                consecutive_healthy_count=state.consecutive_healthy_count,
                first_detected_at=state.first_detected_at,
                latest_timestamp=state.latest_timestamp,
                active=state.active,
                blocked=state.blocked,
                blocked_reason=state.blocked_reason,
            )

    def first_detected_at(self, component_id: str) -> float:
        """Return the timestamp when the failure was first detected (0.0 if none)."""
        with self._lock:
            state = self._states.get(component_id)
            return state.first_detected_at if state else 0.0

    def reset(self, component_id: str) -> None:
        """
        Reset state for a component to a clean slate.
        Use when a component is restarted or reconfigured.
        """
        with self._lock:
            if component_id in self._states:
                del self._states[component_id]

    def all_active_failures(self) -> Dict[str, ComponentRecoveryState]:
        """Return a dict of component_id → state for all currently active failures."""
        with self._lock:
            return {
                cid: ComponentRecoveryState(
                    component_id=s.component_id,
                    recovery_status=s.recovery_status,
                    consecutive_failure_count=s.consecutive_failure_count,
                    consecutive_healthy_count=s.consecutive_healthy_count,
                    first_detected_at=s.first_detected_at,
                    latest_timestamp=s.latest_timestamp,
                    active=s.active,
                    blocked=s.blocked,
                    blocked_reason=s.blocked_reason,
                )
                for cid, s in self._states.items()
                if s.active
            }

    # ------------------------------------------------------------------
    # Private helpers

    def _get_or_create(self, component_id: str) -> ComponentRecoveryState:
        """Must be called with self._lock held."""
        if component_id not in self._states:
            self._states[component_id] = ComponentRecoveryState(
                component_id=component_id,
            )
        return self._states[component_id]
