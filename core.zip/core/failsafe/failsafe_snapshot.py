"""
IndiDrive AI — Phase 11.4 | Fail-Safe Snapshot Builder
========================================================
Builds immutable FailSafeSnapshot instances from a FailSafeDecision.
Kept as a separate module so the snapshot construction logic is
testable independently of the engine.
"""
from __future__ import annotations

from typing import FrozenSet, Tuple

from .failsafe_types import (
    FAILSAFE_SCHEMA_VERSION,
    FailSafeDecision,
    FailSafeSnapshot,
    FailSafeState,
    FailureSeverity,
    SensorFailureEvent,
    SubsystemFailureEvent,
    SystemCapability,
)

__all__ = ["build_snapshot"]


def build_snapshot(decision: FailSafeDecision) -> FailSafeSnapshot:
    """
    Build an immutable FailSafeSnapshot from a FailSafeDecision.

    The snapshot mirrors the decision's state but is expressed as a
    compact, de-duplicated view for pipeline consumers.  It does not
    re-derive any failure logic — it only restructures the decision for
    safe external consumption.

    Parameters
    ----------
    decision : FailSafeDecision
        The decision produced by the Fail-Safe engine this cycle.

    Returns
    -------
    FailSafeSnapshot
    """
    # De-duplicate capabilities across all active failures
    cap_set: FrozenSet[SystemCapability] = frozenset(decision.affected_capabilities)

    # Most severe failure among all active events
    severity_str = _aggregate_severity(
        decision.active_sensor_failures,
        decision.active_subsystem_failures,
        decision.severity,
    )

    return FailSafeSnapshot(
        timestamp=decision.timestamp,
        schema_version=FAILSAFE_SCHEMA_VERSION,
        decision=decision,
        active_sensor_failures=decision.active_sensor_failures,
        active_subsystem_failures=decision.active_subsystem_failures,
        affected_capabilities=tuple(sorted(cap_set, key=lambda c: c.value)),
        fail_safe_state=decision.fail_safe_state,
        control_withheld=decision.control_withheld,
        severity=severity_str,
        confidence=decision.confidence,
        uncertainty=decision.uncertainty,
        degraded=decision.degraded,
        stale=decision.stale,
    )


def _aggregate_severity(
    sensor_failures: Tuple[SensorFailureEvent, ...],
    subsystem_failures: Tuple[SubsystemFailureEvent, ...],
    fallback: str,
) -> str:
    """
    Return the string value of the most severe active failure.
    Falls back to the decision's severity string if no events are present.
    """
    priority = [
        FailureSeverity.CRITICAL,
        FailureSeverity.HIGH,
        FailureSeverity.MEDIUM,
        FailureSeverity.LOW,
        FailureSeverity.INFO,
    ]

    current_idx = len(priority)  # start at lowest priority (beyond INFO)

    for evt in sensor_failures:
        try:
            idx = priority.index(evt.severity)
            if idx < current_idx:
                current_idx = idx
        except ValueError:
            pass

    for evt in subsystem_failures:
        try:
            idx = priority.index(evt.severity)
            if idx < current_idx:
                current_idx = idx
        except ValueError:
            pass

    if current_idx < len(priority):
        return priority[current_idx].value
    return fallback
