"""
IndiDrive AI — Phase 11.4 | Fail-Safe Configuration
=====================================================
All thresholds, timeouts, cycle counts, and policy flags for the
Fail-Safe and Sensor Failure Handling layer.

No magic numbers are scattered through the engine — all tunable values
live here.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict

__all__ = ["FailSafeConfig"]

# ---------------------------------------------------------------------------
# Safe defaults — conservative, designed for the Indian-road CARLA context
# ---------------------------------------------------------------------------

_DEFAULT_FAILURE_CONFIRMATION_CYCLES: int   = 2     # cycles before marking as failed
_DEFAULT_RECOVERY_CONFIRMATION_CYCLES: int  = 4     # clean cycles before recovered
_DEFAULT_FAILURE_HOLD_TIME_S:         float = 0.5   # minimum seconds to hold failure state
_DEFAULT_RECOVERY_HOLD_TIME_S:        float = 1.0   # minimum seconds in recovery validation

# Sensor timeout thresholds (seconds of no fresh data before SENSOR_TIMEOUT)
_DEFAULT_CAMERA_TIMEOUT_S:        float = 0.5
_DEFAULT_LIDAR_TIMEOUT_S:         float = 0.5
_DEFAULT_RADAR_TIMEOUT_S:         float = 1.0   # radar may run at lower rate
_DEFAULT_VEHICLE_STATE_TIMEOUT_S: float = 0.3   # high rate, short timeout

# Subsystem output timeout thresholds (seconds)
_DEFAULT_PERCEPTION_TIMEOUT_S:    float = 0.5
_DEFAULT_FUSION_TIMEOUT_S:        float = 0.5
_DEFAULT_PREDICTION_TIMEOUT_S:    float = 0.5
_DEFAULT_WORLD_MODEL_TIMEOUT_S:   float = 0.5
_DEFAULT_PLANNING_TIMEOUT_S:      float = 1.0
_DEFAULT_TRACKING_TIMEOUT_S:      float = 0.5
_DEFAULT_MPC_TIMEOUT_S:           float = 0.5
_DEFAULT_CONTROL_TIMEOUT_S:       float = 0.5
_DEFAULT_SAFETY_MONITOR_TIMEOUT_S: float = 1.0
_DEFAULT_EMERGENCY_DET_TIMEOUT_S:  float = 1.0
_DEFAULT_SAFETY_SUPERVISOR_TIMEOUT_S: float = 1.0

# Confidence / uncertainty thresholds
_DEFAULT_LOW_CONFIDENCE_THRESHOLD:   float = 0.25  # below this → SENSOR_LOW_CONFIDENCE
_DEFAULT_HIGH_UNCERTAINTY_THRESHOLD: float = 0.75  # above this → treat as degraded

# Synchronisation
_DEFAULT_SYNC_TIMESTAMP_TOLERANCE_S: float = 0.1   # max sensor timestamp skew
_DEFAULT_SYNC_LATENCY_THRESHOLD_S:   float = 0.2   # max individual sensor latency

# Critical sensor policy: require camera OR lidar for NORMAL_OPERATION
# (if both unavailable → CONTROL_WITHHELD)
_DEFAULT_REQUIRE_CAMERA_OR_LIDAR: bool = True

# Redundancy: camera + lidar give overlapping object detection.
# If one is degraded but the other is healthy, stay in DEGRADED_OPERATION,
# not SUBSYSTEM_FAILURE.
_DEFAULT_CAMERA_LIDAR_REDUNDANCY: bool = True


@dataclass
class FailSafeConfig:
    """
    Configuration for the Phase 11.4 Fail-Safe engine.

    Hysteresis
    ----------
    failure_confirmation_cycles : Cycles a failure must persist before it is
                                  recorded (debounce against noise).
    recovery_confirmation_cycles: Clean cycles required before declaring recovery.
    failure_hold_time_s         : Minimum wall-time seconds to hold failure state.
    recovery_hold_time_s        : Minimum wall-time seconds before confirming recovery.

    Sensor timeouts (seconds)
    -------------------------
    camera_timeout_s, lidar_timeout_s, radar_timeout_s,
    vehicle_state_timeout_s     : Per-sensor max age before SENSOR_TIMEOUT.

    Subsystem timeouts (seconds)
    ----------------------------
    perception/fusion/.../safety_supervisor timeout fields.

    Confidence / uncertainty
    ------------------------
    low_confidence_threshold    : Below this level → SENSOR_LOW_CONFIDENCE.
    high_uncertainty_threshold  : Above this level → treat as degraded.

    Synchronisation
    ---------------
    sync_timestamp_tolerance_s  : Max skew between sensor timestamps.
    sync_latency_threshold_s    : Max individual sensor pipeline latency.

    Policy flags
    ------------
    enable_failsafe             : Master switch (True = active).
    require_camera_or_lidar     : At least one of {camera, lidar} must be
                                  healthy for NORMAL_OPERATION.
    camera_lidar_redundancy     : Treat camera+lidar as overlapping for
                                  object detection (one may compensate for other).
    """
    # Feature switch
    enable_failsafe: bool = True

    # Hysteresis
    failure_confirmation_cycles:  int   = _DEFAULT_FAILURE_CONFIRMATION_CYCLES
    recovery_confirmation_cycles: int   = _DEFAULT_RECOVERY_CONFIRMATION_CYCLES
    failure_hold_time_s:          float = _DEFAULT_FAILURE_HOLD_TIME_S
    recovery_hold_time_s:         float = _DEFAULT_RECOVERY_HOLD_TIME_S

    # Sensor timeouts
    camera_timeout_s:        float = _DEFAULT_CAMERA_TIMEOUT_S
    lidar_timeout_s:         float = _DEFAULT_LIDAR_TIMEOUT_S
    radar_timeout_s:         float = _DEFAULT_RADAR_TIMEOUT_S
    vehicle_state_timeout_s: float = _DEFAULT_VEHICLE_STATE_TIMEOUT_S

    # Subsystem timeouts
    perception_timeout_s:        float = _DEFAULT_PERCEPTION_TIMEOUT_S
    fusion_timeout_s:            float = _DEFAULT_FUSION_TIMEOUT_S
    prediction_timeout_s:        float = _DEFAULT_PREDICTION_TIMEOUT_S
    world_model_timeout_s:       float = _DEFAULT_WORLD_MODEL_TIMEOUT_S
    planning_timeout_s:          float = _DEFAULT_PLANNING_TIMEOUT_S
    tracking_timeout_s:          float = _DEFAULT_TRACKING_TIMEOUT_S
    mpc_timeout_s:               float = _DEFAULT_MPC_TIMEOUT_S
    control_timeout_s:           float = _DEFAULT_CONTROL_TIMEOUT_S
    safety_monitor_timeout_s:    float = _DEFAULT_SAFETY_MONITOR_TIMEOUT_S
    emergency_det_timeout_s:     float = _DEFAULT_EMERGENCY_DET_TIMEOUT_S
    safety_supervisor_timeout_s: float = _DEFAULT_SAFETY_SUPERVISOR_TIMEOUT_S

    # Confidence / uncertainty
    low_confidence_threshold:   float = _DEFAULT_LOW_CONFIDENCE_THRESHOLD
    high_uncertainty_threshold: float = _DEFAULT_HIGH_UNCERTAINTY_THRESHOLD

    # Synchronisation
    sync_timestamp_tolerance_s: float = _DEFAULT_SYNC_TIMESTAMP_TOLERANCE_S
    sync_latency_threshold_s:   float = _DEFAULT_SYNC_LATENCY_THRESHOLD_S

    # Policy
    require_camera_or_lidar:  bool = _DEFAULT_REQUIRE_CAMERA_OR_LIDAR
    camera_lidar_redundancy:  bool = _DEFAULT_CAMERA_LIDAR_REDUNDANCY

    # -----------------------------------------------------------------------

    def __post_init__(self) -> None:
        self._validate()

    def _validate(self) -> None:
        int_fields = [
            ("failure_confirmation_cycles",  self.failure_confirmation_cycles),
            ("recovery_confirmation_cycles", self.recovery_confirmation_cycles),
        ]
        for name, val in int_fields:
            if not isinstance(val, int) or val < 0:
                raise ValueError(f"FailSafeConfig.{name} must be >= 0, got {val!r}")

        positive_floats = [
            ("failure_hold_time_s",          self.failure_hold_time_s),
            ("recovery_hold_time_s",         self.recovery_hold_time_s),
            ("camera_timeout_s",             self.camera_timeout_s),
            ("lidar_timeout_s",              self.lidar_timeout_s),
            ("radar_timeout_s",              self.radar_timeout_s),
            ("vehicle_state_timeout_s",      self.vehicle_state_timeout_s),
            ("perception_timeout_s",         self.perception_timeout_s),
            ("fusion_timeout_s",             self.fusion_timeout_s),
            ("prediction_timeout_s",         self.prediction_timeout_s),
            ("world_model_timeout_s",        self.world_model_timeout_s),
            ("planning_timeout_s",           self.planning_timeout_s),
            ("tracking_timeout_s",           self.tracking_timeout_s),
            ("mpc_timeout_s",                self.mpc_timeout_s),
            ("control_timeout_s",            self.control_timeout_s),
            ("safety_monitor_timeout_s",     self.safety_monitor_timeout_s),
            ("emergency_det_timeout_s",      self.emergency_det_timeout_s),
            ("safety_supervisor_timeout_s",  self.safety_supervisor_timeout_s),
            ("sync_timestamp_tolerance_s",   self.sync_timestamp_tolerance_s),
            ("sync_latency_threshold_s",     self.sync_latency_threshold_s),
        ]
        for name, val in positive_floats:
            if not isinstance(val, (int, float)) or val <= 0.0:
                raise ValueError(f"FailSafeConfig.{name} must be > 0, got {val!r}")

        for name, val in [
            ("low_confidence_threshold",   self.low_confidence_threshold),
            ("high_uncertainty_threshold", self.high_uncertainty_threshold),
        ]:
            if not (0.0 <= val <= 1.0):
                raise ValueError(f"FailSafeConfig.{name} must be in [0,1], got {val!r}")

    # -----------------------------------------------------------------------
    # Named presets

    @classmethod
    def default(cls) -> "FailSafeConfig":
        """Default config — suitable for development / simulation."""
        return cls()

    @classmethod
    def conservative(cls) -> "FailSafeConfig":
        """Faster failure detection, longer recovery confirmation."""
        return cls(
            failure_confirmation_cycles=1,
            recovery_confirmation_cycles=6,
            failure_hold_time_s=1.0,
            recovery_hold_time_s=2.0,
        )

    @classmethod
    def strict(cls) -> "FailSafeConfig":
        """Very tight timeouts, immediate failure detection, slow recovery."""
        return cls(
            failure_confirmation_cycles=1,
            recovery_confirmation_cycles=8,
            camera_timeout_s=0.2,
            lidar_timeout_s=0.2,
            vehicle_state_timeout_s=0.15,
            failure_hold_time_s=2.0,
            recovery_hold_time_s=4.0,
            sync_timestamp_tolerance_s=0.05,
        )

    def sensor_timeout_for(self, sensor_name: str) -> float:
        """
        Look up the configured timeout for a named sensor.
        Returns a conservative default if the sensor is not explicitly configured.
        """
        mapping: Dict[str, float] = {
            "camera":        self.camera_timeout_s,
            "lidar":         self.lidar_timeout_s,
            "radar":         self.radar_timeout_s,
            "vehicle_state": self.vehicle_state_timeout_s,
        }
        return mapping.get(sensor_name.lower(), self.camera_timeout_s)

    def subsystem_timeout_for(self, subsystem_name: str) -> float:
        """
        Look up the configured timeout for a named subsystem.
        Returns a conservative default if not explicitly configured.
        """
        mapping: Dict[str, float] = {
            "perception":        self.perception_timeout_s,
            "fusion":            self.fusion_timeout_s,
            "prediction":        self.prediction_timeout_s,
            "world_model":       self.world_model_timeout_s,
            "planning":          self.planning_timeout_s,
            "tracking":          self.tracking_timeout_s,
            "mpc":               self.mpc_timeout_s,
            "control":           self.control_timeout_s,
            "safety_monitor":    self.safety_monitor_timeout_s,
            "emergency_detection": self.emergency_det_timeout_s,
            "safety_supervisor": self.safety_supervisor_timeout_s,
        }
        return mapping.get(subsystem_name.lower(), self.perception_timeout_s)
