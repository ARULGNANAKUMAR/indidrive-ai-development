"""
IndiDrive AI — Phase 11.4 | Fail-Safe Package
===============================================
Fail-Safe and Sensor Failure Handling layer.

Public surface
--------------
FailSafeEngine         — Main engine; call .evaluate() each pipeline cycle.
FailSafeConfig         — Configuration (timeouts, hysteresis, policy).
FailSafeDecision       — Immutable decision output per cycle.
FailSafeSnapshot       — Immutable snapshot for downstream consumers.
FailSafeValidator      — Validate decisions and snapshots.
RecoveryManager        — Evidence-based recovery state tracker.

All types are in failsafe_types.py; import them directly or via this package.
"""
from .failsafe_config import FailSafeConfig
from .failsafe_engine import FailSafeEngine
from .failsafe_snapshot import build_snapshot
from .failsafe_types import (
    FAILSAFE_SCHEMA_VERSION,
    FailSafeDecision,
    FailSafeSnapshot,
    FailSafeState,
    FailSafeSensorType,
    FailSafeSubsystemType,
    FailureSeverity,
    FailureUrgency,
    RecoveryStatus,
    SensorFailureEvent,
    SensorFailureType,
    SensorHealthSummary,
    SubsystemFailureEvent,
    SubsystemFailureType,
    SystemCapability,
)
from .failsafe_validator import FailSafeValidator
from .recovery_manager import RecoveryManager

__all__ = [
    "FAILSAFE_SCHEMA_VERSION",
    "FailSafeConfig",
    "FailSafeDecision",
    "FailSafeEngine",
    "FailSafeSnapshot",
    "FailSafeState",
    "FailSafeSensorType",
    "FailSafeSubsystemType",
    "FailSafeValidator",
    "FailureSeverity",
    "FailureUrgency",
    "RecoveryManager",
    "SensorFailureEvent",
    "SensorFailureType",
    "SensorHealthSummary",
    "SubsystemFailureEvent",
    "SubsystemFailureType",
    "SystemCapability",
    "build_snapshot",
]
