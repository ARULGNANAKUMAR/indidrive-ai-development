"""
IndiDrive AI — Phase 11.4 | Fail-Safe Types
=============================================
Typed enumerations and immutable data containers for the Fail-Safe and
Sensor Failure Handling layer.

Design rules:
  * All containers are frozen dataclasses — immutable after construction.
  * No computation in this module — only type definitions.
  * No circular imports — stdlib and typing only.
  * Deterministic: same input → same output.
  * UNKNOWN states are explicit, never silent fallbacks to healthy/normal.
  * Severity and urgency are kept separate.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Optional, Tuple

__all__ = [
    # Schema
    "FAILSAFE_SCHEMA_VERSION",
    # Fail-safe state
    "FailSafeState",
    "FAILSAFE_STATE_PRIORITY",
    # Sensor enums
    "FailSafeSensorType",
    "SensorFailureType",
    "SensorHealthSummary",
    # Subsystem enums
    "FailSafeSubsystemType",
    "SubsystemFailureType",
    # Capability enums
    "SystemCapability",
    # Severity / urgency
    "FailureSeverity",
    "SEVERITY_PRIORITY",
    "FailureUrgency",
    # Recovery
    "RecoveryStatus",
    # Data containers
    "SensorFailureEvent",
    "SubsystemFailureEvent",
    "FailSafeDecision",
    "FailSafeSnapshot",
]

FAILSAFE_SCHEMA_VERSION: str = "11.4"


# ---------------------------------------------------------------------------
# Fail-Safe State — the primary operational state of the fail-safe layer
# ---------------------------------------------------------------------------

class FailSafeState(str, Enum):
    """
    Overall operational state as assessed by the Fail-Safe engine.

    NORMAL_OPERATION    — Required safety-critical capabilities are available
                          and validated. No active fail-safe conditions.
    DEGRADED_OPERATION  — Some capability is degraded, but safe operation
                          may still be possible.
    SENSOR_DEGRADED     — A sensor is available but quality is reduced.
    SENSOR_UNAVAILABLE  — A required sensor is unavailable.
    SUBSYSTEM_DEGRADED  — A subsystem is operating with reduced capability.
    SUBSYSTEM_FAILURE   — A subsystem is not trustworthy.
    FAIL_SAFE_ACTIVE    — The system has entered an explicit safety fallback state.
    CONTROL_RESTRICTED  — Normal control authority is restricted.
    CONTROL_WITHHELD    — Normal control authority is not permitted.
    RECOVERY_PENDING    — A failed component appears to be recovering but is
                          not yet validated.
    RECOVERY_VALIDATING — Recovery evidence is being checked.
    RECOVERED           — The component has passed recovery validation.
    UNKNOWN_FAIL_SAFE_STATE — The system cannot establish a trustworthy state.
    """
    NORMAL_OPERATION        = "NORMAL_OPERATION"
    DEGRADED_OPERATION      = "DEGRADED_OPERATION"
    SENSOR_DEGRADED         = "SENSOR_DEGRADED"
    SENSOR_UNAVAILABLE      = "SENSOR_UNAVAILABLE"
    SUBSYSTEM_DEGRADED      = "SUBSYSTEM_DEGRADED"
    SUBSYSTEM_FAILURE       = "SUBSYSTEM_FAILURE"
    FAIL_SAFE_ACTIVE        = "FAIL_SAFE_ACTIVE"
    CONTROL_RESTRICTED      = "CONTROL_RESTRICTED"
    CONTROL_WITHHELD        = "CONTROL_WITHHELD"
    RECOVERY_PENDING        = "RECOVERY_PENDING"
    RECOVERY_VALIDATING     = "RECOVERY_VALIDATING"
    RECOVERED               = "RECOVERED"
    UNKNOWN_FAIL_SAFE_STATE = "UNKNOWN_FAIL_SAFE_STATE"


# Priority ordering: lower index = higher precedence when aggregating states
FAILSAFE_STATE_PRIORITY: Tuple[FailSafeState, ...] = (
    FailSafeState.UNKNOWN_FAIL_SAFE_STATE,
    FailSafeState.CONTROL_WITHHELD,
    FailSafeState.FAIL_SAFE_ACTIVE,
    FailSafeState.SUBSYSTEM_FAILURE,
    FailSafeState.CONTROL_RESTRICTED,
    FailSafeState.SENSOR_UNAVAILABLE,
    FailSafeState.SUBSYSTEM_DEGRADED,
    FailSafeState.SENSOR_DEGRADED,
    FailSafeState.RECOVERY_PENDING,
    FailSafeState.RECOVERY_VALIDATING,
    FailSafeState.DEGRADED_OPERATION,
    FailSafeState.RECOVERED,
    FailSafeState.NORMAL_OPERATION,
)


# ---------------------------------------------------------------------------
# Sensor Types — identities of sensors present in this project
# ---------------------------------------------------------------------------

class FailSafeSensorType(str, Enum):
    """
    Sensor identities supported by the fail-safe layer.
    Only sensors present in the actual project architecture are listed.
    CAMERA, LIDAR, RADAR correspond to the SensorType enum in sensor_types.py.
    IMU, GNSS, VEHICLE_STATE are logical sensor sources from Phase 10 / vehicle.
    """
    CAMERA        = "CAMERA"
    LIDAR         = "LIDAR"
    RADAR         = "RADAR"
    IMU           = "IMU"
    GNSS          = "GNSS"
    VEHICLE_STATE = "VEHICLE_STATE"
    UNKNOWN_SENSOR = "UNKNOWN_SENSOR"


# ---------------------------------------------------------------------------
# Sensor Failure Types
# ---------------------------------------------------------------------------

class SensorFailureType(str, Enum):
    """
    Structured categories of sensor failures.
    Distinguishes stale, degraded, unavailable, invalid, corrupted, and
    synchronization failures — these require different responses.
    """
    SENSOR_MISSING                 = "SENSOR_MISSING"
    SENSOR_TIMEOUT                 = "SENSOR_TIMEOUT"
    SENSOR_STALE                   = "SENSOR_STALE"
    SENSOR_INVALID_DATA            = "SENSOR_INVALID_DATA"
    SENSOR_CORRUPTED_DATA          = "SENSOR_CORRUPTED_DATA"
    SENSOR_LOW_CONFIDENCE          = "SENSOR_LOW_CONFIDENCE"
    SENSOR_RATE_DEGRADATION        = "SENSOR_RATE_DEGRADATION"
    SENSOR_TIMESTAMP_FAILURE       = "SENSOR_TIMESTAMP_FAILURE"
    SENSOR_FRAME_FAILURE           = "SENSOR_FRAME_FAILURE"
    SENSOR_BUFFER_FAILURE          = "SENSOR_BUFFER_FAILURE"
    SENSOR_SYNCHRONIZATION_FAILURE = "SENSOR_SYNCHRONIZATION_FAILURE"
    SENSOR_HEALTH_CRITICAL         = "SENSOR_HEALTH_CRITICAL"
    SENSOR_CONFIGURATION_FAILURE   = "SENSOR_CONFIGURATION_FAILURE"
    SENSOR_RUNTIME_FAILURE         = "SENSOR_RUNTIME_FAILURE"
    SENSOR_UNKNOWN_FAILURE         = "SENSOR_UNKNOWN_FAILURE"


# ---------------------------------------------------------------------------
# Sensor Health Summary — safety-facing translation of Phase 1 health
# ---------------------------------------------------------------------------

class SensorHealthSummary(str, Enum):
    """
    Normalised safety-facing sensor health states translated from Phase 1.
    The fail-safe layer consumes existing SensorHealthRecord states and
    maps them to these safety consequences — no duplication of health logic.

    Maps from Phase 1 SensorHealthMonitor states:
      ONLINE         → HEALTHY
      DEGRADED       → DEGRADED
      OFFLINE        → UNAVAILABLE  (after staleness)
      NOT_CONFIGURED → UNAVAILABLE  (sensor not present)
    Additional safety-layer states:
      STALE          → data timestamp too old but sensor still online
      INVALID        → data failed structural validation
      CRITICAL       → sensor health critically degraded
      UNKNOWN        → health cannot be determined
    """
    HEALTHY     = "HEALTHY"
    DEGRADED    = "DEGRADED"
    STALE       = "STALE"
    UNAVAILABLE = "UNAVAILABLE"
    INVALID     = "INVALID"
    CRITICAL    = "CRITICAL"
    UNKNOWN     = "UNKNOWN"


# ---------------------------------------------------------------------------
# Subsystem Types — all subsystems that can be tracked for failures
# ---------------------------------------------------------------------------

class FailSafeSubsystemType(str, Enum):
    """
    Subsystem identities tracked by the fail-safe layer.
    Corresponds to actual pipeline phases in this project.
    """
    SENSOR_PIPELINE       = "SENSOR_PIPELINE"
    PERCEPTION            = "PERCEPTION"
    FUSION                = "FUSION"
    PREDICTION            = "PREDICTION"
    ROAD_UNDERSTANDING    = "ROAD_UNDERSTANDING"
    WORLD_MODEL           = "WORLD_MODEL"
    REASONING             = "REASONING"
    PLANNING              = "PLANNING"
    TRACKING              = "TRACKING"
    MPC                   = "MPC"
    CONTROL               = "CONTROL"
    VEHICLE_STATE         = "VEHICLE_STATE"
    SAFETY_MONITOR        = "SAFETY_MONITOR"
    EMERGENCY_DETECTION   = "EMERGENCY_DETECTION"
    SAFETY_SUPERVISOR     = "SAFETY_SUPERVISOR"
    INTEGRATION_PIPELINE  = "INTEGRATION_PIPELINE"
    UNKNOWN_SUBSYSTEM     = "UNKNOWN_SUBSYSTEM"


# ---------------------------------------------------------------------------
# Subsystem Failure Types
# ---------------------------------------------------------------------------

class SubsystemFailureType(str, Enum):
    """Failure modes for subsystems."""
    OUTPUT_UNAVAILABLE   = "OUTPUT_UNAVAILABLE"
    OUTPUT_STALE         = "OUTPUT_STALE"
    OUTPUT_INVALID       = "OUTPUT_INVALID"
    OUTPUT_DEGRADED      = "OUTPUT_DEGRADED"
    INTERNAL_ERROR       = "INTERNAL_ERROR"
    DEPENDENCY_FAILED    = "DEPENDENCY_FAILED"
    VALIDATION_FAILED    = "VALIDATION_FAILED"
    CONFIDENCE_TOO_LOW   = "CONFIDENCE_TOO_LOW"
    TIMEOUT              = "TIMEOUT"
    UNKNOWN_FAILURE      = "UNKNOWN_FAILURE"


# ---------------------------------------------------------------------------
# System Capabilities — what the system can do (not which component exists)
# ---------------------------------------------------------------------------

class SystemCapability(str, Enum):
    """
    Functional capabilities the fail-safe layer reasons about.
    A sensor or subsystem failure propagates only to capabilities that are
    actually affected by that failure, according to the dependency graph.
    """
    OBJECT_DETECTION         = "OBJECT_DETECTION"
    OBJECT_TRACKING          = "OBJECT_TRACKING"
    DEPTH_ESTIMATION         = "DEPTH_ESTIMATION"
    ROAD_BOUNDARY_ESTIMATION = "ROAD_BOUNDARY_ESTIMATION"
    DRIVABLE_AREA_ESTIMATION = "DRIVABLE_AREA_ESTIMATION"
    LANE_ESTIMATION          = "LANE_ESTIMATION"
    ROAD_HAZARD_ESTIMATION   = "ROAD_HAZARD_ESTIMATION"
    SENSOR_FUSION            = "SENSOR_FUSION"
    MOTION_PREDICTION        = "MOTION_PREDICTION"
    COLLISION_RISK_ESTIMATION = "COLLISION_RISK_ESTIMATION"
    WORLD_MODEL_VALIDITY     = "WORLD_MODEL_VALIDITY"
    PLANNING                 = "PLANNING"
    TRAJECTORY_TRACKING      = "TRAJECTORY_TRACKING"
    MPC_CONTROL              = "MPC_CONTROL"
    VEHICLE_STATE_ESTIMATION = "VEHICLE_STATE_ESTIMATION"
    SAFETY_MONITORING        = "SAFETY_MONITORING"
    EMERGENCY_DETECTION      = "EMERGENCY_DETECTION"
    CONTROL_AUTHORITY        = "CONTROL_AUTHORITY"


# ---------------------------------------------------------------------------
# Failure Severity — how serious the failure is
# ---------------------------------------------------------------------------

class FailureSeverity(str, Enum):
    """
    Severity of a detected failure.
    Kept separate from urgency — severity describes the potential impact,
    urgency describes the time pressure for response.
    """
    INFO     = "INFO"
    LOW      = "LOW"
    MEDIUM   = "MEDIUM"
    HIGH     = "HIGH"
    CRITICAL = "CRITICAL"
    UNKNOWN  = "UNKNOWN"


# Priority ordering for severity aggregation (lower index = higher priority)
SEVERITY_PRIORITY: Tuple[FailureSeverity, ...] = (
    FailureSeverity.CRITICAL,
    FailureSeverity.HIGH,
    FailureSeverity.MEDIUM,
    FailureSeverity.LOW,
    FailureSeverity.INFO,
    # UNKNOWN handled separately
)


# ---------------------------------------------------------------------------
# Failure Urgency — how quickly the system must respond
# ---------------------------------------------------------------------------

class FailureUrgency(str, Enum):
    """
    Urgency of response required for a detected failure.
    Independent of severity: a severe condition may have low urgency
    (e.g. a non-critical sensor that will not be used for minutes), or
    a medium-severity condition may have immediate urgency
    (e.g. timestamp drift affecting fusion right now).
    """
    NONE      = "NONE"
    LOW       = "LOW"
    MEDIUM    = "MEDIUM"
    HIGH      = "HIGH"
    IMMEDIATE = "IMMEDIATE"
    UNKNOWN   = "UNKNOWN"


# ---------------------------------------------------------------------------
# Recovery Status
# ---------------------------------------------------------------------------

class RecoveryStatus(str, Enum):
    """
    Recovery lifecycle state for a failed sensor or subsystem.
    Recovery is evidence-based and requires configured confirmation cycles.
    """
    NOT_REQUIRED        = "NOT_REQUIRED"
    RECOVERY_PENDING    = "RECOVERY_PENDING"
    RECOVERY_VALIDATING = "RECOVERY_VALIDATING"
    RECOVERY_CONFIRMED  = "RECOVERY_CONFIRMED"
    RECOVERY_FAILED     = "RECOVERY_FAILED"
    RECOVERY_BLOCKED    = "RECOVERY_BLOCKED"


# ---------------------------------------------------------------------------
# Sensor Failure Event
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class SensorFailureEvent:
    """
    Structured event representing a failure condition on one sensor.

    Fields
    ------
    sensor_type          : FailSafeSensorType enum.
    failure_type         : SensorFailureType enum.
    severity             : FailureSeverity enum.
    urgency              : FailureUrgency enum.
    timestamp            : Timestamp from the sensor frame (not wall clock).
    frame_id             : Frame counter at detection (0 if unknown).
    first_detected_at    : Timestamp when failure was first detected.
    last_observed_at     : Timestamp of the most recent failure observation.
    confidence           : [0.0, 1.0] confidence in this failure detection.
    uncertainty          : [0.0, 1.0] uncertainty (separate from severity).
    stale                : True if the sensor data is stale.
    degraded             : True if the sensor is degraded (not fully failed).
    affected_capabilities: Capabilities directly affected by this sensor failure.
    reason_codes         : Tuple of string reason codes explaining the failure.
    evidence             : Compact structured evidence (no raw sensor data).
    recovery_status      : RecoveryStatus enum.
    schema_version       : "11.4".
    """
    sensor_type:           FailSafeSensorType             = FailSafeSensorType.UNKNOWN_SENSOR
    failure_type:          SensorFailureType              = SensorFailureType.SENSOR_UNKNOWN_FAILURE
    severity:              FailureSeverity                = FailureSeverity.UNKNOWN
    urgency:               FailureUrgency                 = FailureUrgency.UNKNOWN
    timestamp:             float                          = 0.0
    frame_id:              int                            = 0
    first_detected_at:     float                          = 0.0
    last_observed_at:      float                          = 0.0
    confidence:            float                          = 0.0
    uncertainty:           float                          = 1.0
    stale:                 bool                           = False
    degraded:              bool                           = False
    affected_capabilities: Tuple[SystemCapability, ...]   = field(default_factory=tuple)
    reason_codes:          Tuple[str, ...]                = field(default_factory=tuple)
    evidence:              Optional[dict]                 = None
    recovery_status:       RecoveryStatus                 = RecoveryStatus.NOT_REQUIRED
    schema_version:        str                            = FAILSAFE_SCHEMA_VERSION


# ---------------------------------------------------------------------------
# Subsystem Failure Event
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class SubsystemFailureEvent:
    """
    Structured event representing a failure condition on one subsystem.

    Fields
    ------
    subsystem             : FailSafeSubsystemType enum.
    failure_type          : SubsystemFailureType enum.
    severity              : FailureSeverity enum.
    urgency               : FailureUrgency enum.
    timestamp             : Timestamp from subsystem output.
    confidence            : [0.0, 1.0] confidence in this failure detection.
    uncertainty           : [0.0, 1.0] uncertainty.
    stale                 : True if subsystem output is stale.
    degraded              : True if subsystem is degraded (not fully failed).
    affected_capabilities : Capabilities directly affected by this failure.
    dependent_subsystems  : Downstream subsystems that depend on this one.
    reason_codes          : Tuple of string reason codes.
    evidence              : Compact structured evidence.
    recovery_status       : RecoveryStatus enum.
    schema_version        : "11.4".
    """
    subsystem:             FailSafeSubsystemType          = FailSafeSubsystemType.UNKNOWN_SUBSYSTEM
    failure_type:          SubsystemFailureType           = SubsystemFailureType.UNKNOWN_FAILURE
    severity:              FailureSeverity                = FailureSeverity.UNKNOWN
    urgency:               FailureUrgency                 = FailureUrgency.UNKNOWN
    timestamp:             float                          = 0.0
    confidence:            float                          = 0.0
    uncertainty:           float                          = 1.0
    stale:                 bool                           = False
    degraded:              bool                           = False
    affected_capabilities: Tuple[SystemCapability, ...]   = field(default_factory=tuple)
    dependent_subsystems:  Tuple[FailSafeSubsystemType, ...] = field(default_factory=tuple)
    reason_codes:          Tuple[str, ...]                = field(default_factory=tuple)
    evidence:              Optional[dict]                 = None
    recovery_status:       RecoveryStatus                 = RecoveryStatus.NOT_REQUIRED
    schema_version:        str                            = FAILSAFE_SCHEMA_VERSION


# ---------------------------------------------------------------------------
# Fail-Safe Decision — primary output of one engine cycle
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class FailSafeDecision:
    """
    Immutable Fail-Safe decision for one pipeline cycle.

    This is the primary output of Phase 11.4.
    It MUST NOT directly control the vehicle.
    It feeds structured fail-safe information into Phase 11.3
    (Safety Supervisor) for control-authority determination.

    Fields
    ------
    decision_id             : Deterministic string ID.
    timestamp               : Timestamp from primary input (not wall clock).
    frame_id                : Frame counter.
    fail_safe_state         : FailSafeState enum — the aggregated state.
    control_restriction     : True if control should be restricted.
    control_withheld        : True if control authority should not be granted.
    safety_supervisor_state : State string from Phase 11.3 (pass-through).
    active_sensor_failures  : Tuple of active SensorFailureEvent.
    active_subsystem_failures: Tuple of active SubsystemFailureEvent.
    affected_capabilities   : All capabilities currently affected by failures.
    dominant_reason         : Most significant reason code string.
    reason_codes            : Tuple of all active reason code strings.
    severity                : Most severe FailureSeverity string.
    urgency                 : Most urgent FailureUrgency string.
    confidence              : [0.0, 1.0] confidence in this decision.
    uncertainty             : [0.0, 1.0] uncertainty.
    stale                   : True if any critical input was stale.
    degraded                : True if any input is degraded.
    recovery_status         : Overall recovery status string.
    valid_until             : Timestamp after which this decision should be
                              considered stale (0.0 = not set).
    schema_version          : "11.4".
    """
    decision_id:              str                               = ""
    timestamp:                float                            = 0.0
    frame_id:                 int                              = 0
    fail_safe_state:          FailSafeState                    = FailSafeState.UNKNOWN_FAIL_SAFE_STATE
    control_restriction:      bool                             = True
    control_withheld:         bool                             = True
    safety_supervisor_state:  str                              = "NOT_AVAILABLE"
    active_sensor_failures:   Tuple[SensorFailureEvent, ...]  = field(default_factory=tuple)
    active_subsystem_failures: Tuple[SubsystemFailureEvent, ...] = field(default_factory=tuple)
    affected_capabilities:    Tuple[SystemCapability, ...]     = field(default_factory=tuple)
    dominant_reason:          str                              = "UNKNOWN_FAIL_SAFE_STATE"
    reason_codes:             Tuple[str, ...]                  = field(default_factory=tuple)
    severity:                 str                              = FailureSeverity.UNKNOWN.value
    urgency:                  str                              = FailureUrgency.UNKNOWN.value
    confidence:               float                            = 0.0
    uncertainty:              float                            = 1.0
    stale:                    bool                             = True
    degraded:                 bool                             = True
    recovery_status:          str                              = RecoveryStatus.NOT_REQUIRED.value
    valid_until:              float                            = 0.0
    schema_version:           str                              = FAILSAFE_SCHEMA_VERSION

    @property
    def is_normal(self) -> bool:
        return self.fail_safe_state == FailSafeState.NORMAL_OPERATION

    @property
    def is_critical(self) -> bool:
        return self.fail_safe_state in (
            FailSafeState.CONTROL_WITHHELD,
            FailSafeState.FAIL_SAFE_ACTIVE,
            FailSafeState.UNKNOWN_FAIL_SAFE_STATE,
        )

    def __repr__(self) -> str:
        return (
            f"FailSafeDecision("
            f"state={self.fail_safe_state.value}, "
            f"withheld={self.control_withheld}, "
            f"sensor_failures={len(self.active_sensor_failures)}, "
            f"subsystem_failures={len(self.active_subsystem_failures)})"
        )


# ---------------------------------------------------------------------------
# Fail-Safe Snapshot — immutable snapshot for pipeline consumers
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class FailSafeSnapshot:
    """
    Immutable snapshot of the Fail-Safe engine state for one cycle.
    Safe for consumption by downstream pipeline modules.

    Fields
    ------
    timestamp              : Timestamp of this snapshot.
    schema_version         : "11.4".
    decision               : Full FailSafeDecision for this cycle.
    active_sensor_failures : Deduplicated active sensor failures.
    active_subsystem_failures: Deduplicated active subsystem failures.
    affected_capabilities  : All currently affected capabilities.
    fail_safe_state        : FailSafeState (mirrors decision).
    control_withheld       : True if control is withheld.
    severity               : Most severe failure severity string.
    confidence             : [0.0, 1.0].
    uncertainty            : [0.0, 1.0].
    degraded               : True if any input degraded.
    stale                  : True if any critical input stale.
    """
    timestamp:               float                               = 0.0
    schema_version:          str                                 = FAILSAFE_SCHEMA_VERSION
    decision:                FailSafeDecision                    = field(
        default_factory=FailSafeDecision
    )
    active_sensor_failures:  Tuple[SensorFailureEvent, ...]     = field(default_factory=tuple)
    active_subsystem_failures: Tuple[SubsystemFailureEvent, ...] = field(default_factory=tuple)
    affected_capabilities:   Tuple[SystemCapability, ...]        = field(default_factory=tuple)
    fail_safe_state:         FailSafeState                       = FailSafeState.UNKNOWN_FAIL_SAFE_STATE
    control_withheld:        bool                                = True
    severity:                str                                 = FailureSeverity.UNKNOWN.value
    confidence:              float                               = 0.0
    uncertainty:             float                               = 1.0
    degraded:                bool                                = True
    stale:                   bool                                = True
