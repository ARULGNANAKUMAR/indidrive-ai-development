"""
IndiDrive AI — Phase 11.4 | Fail-Safe Validator
=================================================
Validates FailSafeDecision and FailSafeSnapshot before they are consumed
by downstream modules (Phase 11.3 Safety Supervisor integration).

Design rules:
  * Validates enums, ranges, timestamps, consistency.
  * Rejects invalid safety-critical states — does NOT silently convert them
    to NORMAL_OPERATION or any other healthy-looking state.
  * Returns (is_valid: bool, reason: str) — no exceptions for validation failures.
  * Deterministic.
"""
from __future__ import annotations

import math
from typing import Tuple

from .failsafe_types import (
    FAILSAFE_SCHEMA_VERSION,
    FailSafeDecision,
    FailSafeSnapshot,
    FailSafeState,
    FailureSeverity,
    FailureUrgency,
    RecoveryStatus,
    SensorFailureEvent,
    SensorFailureType,
    SubsystemFailureEvent,
    SubsystemFailureType,
)

__all__ = ["FailSafeValidator"]

_ValidationResult = Tuple[bool, str]


class FailSafeValidator:
    """
    Validates FailSafeDecision and FailSafeSnapshot instances.

    Usage
    -----
    validator = FailSafeValidator()
    ok, reason = validator.validate_decision(decision)
    if not ok:
        # handle invalid decision conservatively
    """

    # ------------------------------------------------------------------
    # Decision validation

    def validate_decision(self, decision: FailSafeDecision) -> _ValidationResult:
        """
        Validate a FailSafeDecision.

        Returns (True, "ok") if valid.
        Returns (False, reason) if invalid — caller must NOT treat the
        decision as representing a safe/normal state.
        """
        if decision is None:
            return False, "decision is None"

        ok, reason = self._validate_schema_version(decision.schema_version)
        if not ok:
            return False, reason

        ok, reason = self._validate_timestamp(decision.timestamp, "decision.timestamp")
        if not ok:
            return False, reason

        ok, reason = self._validate_enum(
            decision.fail_safe_state, FailSafeState, "fail_safe_state"
        )
        if not ok:
            return False, reason

        ok, reason = self._validate_confidence(decision.confidence, "decision.confidence")
        if not ok:
            return False, reason

        ok, reason = self._validate_confidence(decision.uncertainty, "decision.uncertainty")
        if not ok:
            return False, reason

        ok, reason = self._validate_severity_str(decision.severity, "decision.severity")
        if not ok:
            return False, reason

        ok, reason = self._validate_urgency_str(decision.urgency, "decision.urgency")
        if not ok:
            return False, reason

        # Control restriction consistency
        if decision.fail_safe_state in (
            FailSafeState.CONTROL_WITHHELD,
            FailSafeState.UNKNOWN_FAIL_SAFE_STATE,
        ):
            if not decision.control_withheld:
                return False, (
                    f"control_withheld must be True when fail_safe_state="
                    f"{decision.fail_safe_state.value}"
                )

        if decision.fail_safe_state == FailSafeState.NORMAL_OPERATION:
            if decision.control_withheld:
                return False, "control_withheld must be False for NORMAL_OPERATION"
            if decision.control_restriction:
                return False, "control_restriction must be False for NORMAL_OPERATION"

        # Stale/degraded consistency
        if decision.stale and decision.fail_safe_state == FailSafeState.NORMAL_OPERATION:
            return False, "stale=True is inconsistent with NORMAL_OPERATION"

        # Validate nested events
        for i, evt in enumerate(decision.active_sensor_failures):
            ok, reason = self.validate_sensor_failure_event(evt)
            if not ok:
                return False, f"active_sensor_failures[{i}]: {reason}"

        for i, evt in enumerate(decision.active_subsystem_failures):
            ok, reason = self.validate_subsystem_failure_event(evt)
            if not ok:
                return False, f"active_subsystem_failures[{i}]: {reason}"

        # Recovery status
        ok, reason = self._validate_recovery_str(decision.recovery_status, "decision.recovery_status")
        if not ok:
            return False, reason

        return True, "ok"

    # ------------------------------------------------------------------
    # Snapshot validation

    def validate_snapshot(self, snapshot: FailSafeSnapshot) -> _ValidationResult:
        """Validate a FailSafeSnapshot."""
        if snapshot is None:
            return False, "snapshot is None"

        ok, reason = self._validate_schema_version(snapshot.schema_version)
        if not ok:
            return False, reason

        ok, reason = self._validate_timestamp(snapshot.timestamp, "snapshot.timestamp")
        if not ok:
            return False, reason

        ok, reason = self.validate_decision(snapshot.decision)
        if not ok:
            return False, f"snapshot.decision: {reason}"

        ok, reason = self._validate_enum(
            snapshot.fail_safe_state, FailSafeState, "snapshot.fail_safe_state"
        )
        if not ok:
            return False, reason

        # State consistency between snapshot and embedded decision
        if snapshot.fail_safe_state != snapshot.decision.fail_safe_state:
            return False, (
                f"snapshot.fail_safe_state={snapshot.fail_safe_state.value} "
                f"!= decision.fail_safe_state={snapshot.decision.fail_safe_state.value}"
            )

        ok, reason = self._validate_confidence(snapshot.confidence, "snapshot.confidence")
        if not ok:
            return False, reason

        ok, reason = self._validate_confidence(snapshot.uncertainty, "snapshot.uncertainty")
        if not ok:
            return False, reason

        return True, "ok"

    # ------------------------------------------------------------------
    # Event validation

    def validate_sensor_failure_event(self, evt: SensorFailureEvent) -> _ValidationResult:
        """Validate a SensorFailureEvent."""
        if evt is None:
            return False, "event is None"

        ok, reason = self._validate_enum(
            evt.failure_type, SensorFailureType, "failure_type"
        )
        if not ok:
            return False, reason

        ok, reason = self._validate_enum(
            evt.severity, FailureSeverity, "severity"
        )
        if not ok:
            return False, reason

        ok, reason = self._validate_enum(
            evt.urgency, FailureUrgency, "urgency"
        )
        if not ok:
            return False, reason

        ok, reason = self._validate_confidence(evt.confidence, "confidence")
        if not ok:
            return False, reason

        ok, reason = self._validate_confidence(evt.uncertainty, "uncertainty")
        if not ok:
            return False, reason

        if evt.schema_version != FAILSAFE_SCHEMA_VERSION:
            return False, (
                f"sensor event schema_version={evt.schema_version!r} "
                f"!= {FAILSAFE_SCHEMA_VERSION!r}"
            )

        return True, "ok"

    def validate_subsystem_failure_event(self, evt: SubsystemFailureEvent) -> _ValidationResult:
        """Validate a SubsystemFailureEvent."""
        if evt is None:
            return False, "event is None"

        ok, reason = self._validate_enum(
            evt.failure_type, SubsystemFailureType, "failure_type"
        )
        if not ok:
            return False, reason

        ok, reason = self._validate_enum(
            evt.severity, FailureSeverity, "severity"
        )
        if not ok:
            return False, reason

        ok, reason = self._validate_enum(
            evt.urgency, FailureUrgency, "urgency"
        )
        if not ok:
            return False, reason

        ok, reason = self._validate_confidence(evt.confidence, "confidence")
        if not ok:
            return False, reason

        if evt.schema_version != FAILSAFE_SCHEMA_VERSION:
            return False, (
                f"subsystem event schema_version={evt.schema_version!r} "
                f"!= {FAILSAFE_SCHEMA_VERSION!r}"
            )

        return True, "ok"

    # ------------------------------------------------------------------
    # Private helpers

    def _validate_schema_version(self, version: str) -> _ValidationResult:
        if version != FAILSAFE_SCHEMA_VERSION:
            return False, f"schema_version={version!r} != {FAILSAFE_SCHEMA_VERSION!r}"
        return True, "ok"

    def _validate_timestamp(self, ts: object, field_name: str) -> _ValidationResult:
        try:
            f = float(ts)  # type: ignore[arg-type]
            if not math.isfinite(f) or f < 0.0:
                return False, f"{field_name}={f} is not a valid non-negative finite timestamp"
        except (TypeError, ValueError):
            return False, f"{field_name}={ts!r} cannot be converted to float"
        return True, "ok"

    def _validate_enum(self, value: object, enum_cls: type, field_name: str) -> _ValidationResult:
        try:
            enum_cls(value)  # type: ignore[call-arg]
        except (ValueError, KeyError):
            return False, f"{field_name}={value!r} is not a valid {enum_cls.__name__}"
        return True, "ok"

    def _validate_confidence(self, value: object, field_name: str) -> _ValidationResult:
        try:
            f = float(value)  # type: ignore[arg-type]
            if not (0.0 <= f <= 1.0):
                return False, f"{field_name}={f} is not in [0.0, 1.0]"
        except (TypeError, ValueError):
            return False, f"{field_name}={value!r} is not a valid float"
        return True, "ok"

    def _validate_severity_str(self, value: str, field_name: str) -> _ValidationResult:
        try:
            FailureSeverity(value)
        except ValueError:
            return False, f"{field_name}={value!r} is not a valid FailureSeverity"
        return True, "ok"

    def _validate_urgency_str(self, value: str, field_name: str) -> _ValidationResult:
        try:
            FailureUrgency(value)
        except ValueError:
            return False, f"{field_name}={value!r} is not a valid FailureUrgency"
        return True, "ok"

    def _validate_recovery_str(self, value: str, field_name: str) -> _ValidationResult:
        try:
            RecoveryStatus(value)
        except ValueError:
            return False, f"{field_name}={value!r} is not a valid RecoveryStatus"
        return True, "ok"
