"""
IndiDrive AI — Phase 11.4 | Sensor Failure Classifier
=======================================================
Translates Phase 1 sensor health records and raw availability information
into structured SensorFailureEvents understood by the Fail-Safe engine.

Design rules:
  * Consumes existing Phase 1 sensor health — does NOT duplicate health logic.
  * Deterministic — same input → same output.
  * No wall-clock time in classification logic; uses supplied timestamps.
  * Never assumes a sensor is healthy when evidence is absent.
  * Capability propagation follows the explicit dependency map in
    failsafe_engine.py — this module only classifies sensor-level failures.
"""
from __future__ import annotations

import math
from typing import Optional, Sequence, Tuple

from .failsafe_config import FailSafeConfig
from .failsafe_types import (
    FailSafeSensorType,
    FailureSeverity,
    FailureUrgency,
    RecoveryStatus,
    SensorFailureEvent,
    SensorFailureType,
    SensorHealthSummary,
    SystemCapability,
)

__all__ = [
    "translate_sensor_health",
    "classify_sensor_failure",
    "classify_sync_failure",
]

# ---------------------------------------------------------------------------
# Phase 1 sensor health state strings (from sensor_health.py)
# ---------------------------------------------------------------------------
_P1_ONLINE         = "ONLINE"
_P1_DEGRADED       = "DEGRADED"
_P1_OFFLINE        = "OFFLINE"
_P1_NOT_CONFIGURED = "NOT_CONFIGURED"


def translate_sensor_health(
    phase1_state: str,
    frame_age_s: Optional[float],
    confidence: float,
    config: FailSafeConfig,
) -> SensorHealthSummary:
    """
    Translate a Phase 1 SensorHealthRecord state into a safety-facing
    SensorHealthSummary.  No duplication of health calculation — this
    is purely a mapping of existing information.

    Parameters
    ----------
    phase1_state : str
        Value from SensorHealthRecord.state  (ONLINE / DEGRADED / OFFLINE /
        NOT_CONFIGURED).
    frame_age_s  : float | None
        Age of the most recent frame in seconds, from SensorHealthRecord.frame_age().
        None means the sensor has never produced a frame.
    confidence   : float
        [0.0, 1.0] confidence proxy (derived from FPS ratio or callback latency).
    config       : FailSafeConfig

    Returns
    -------
    SensorHealthSummary
    """
    if phase1_state == _P1_NOT_CONFIGURED:
        return SensorHealthSummary.UNAVAILABLE

    if phase1_state == _P1_OFFLINE:
        return SensorHealthSummary.UNAVAILABLE

    if frame_age_s is None:
        # Never received a frame — treat as unavailable
        return SensorHealthSummary.UNAVAILABLE

    if not math.isfinite(frame_age_s) or frame_age_s < 0.0:
        return SensorHealthSummary.INVALID

    if phase1_state == _P1_DEGRADED:
        return SensorHealthSummary.DEGRADED

    # ONLINE — but check for staleness and low confidence
    if confidence < config.low_confidence_threshold:
        return SensorHealthSummary.DEGRADED

    return SensorHealthSummary.HEALTHY


def classify_sensor_failure(
    sensor_type: FailSafeSensorType,
    health_summary: SensorHealthSummary,
    frame_age_s: Optional[float],
    timestamp: float,
    frame_id: int,
    config: FailSafeConfig,
    first_detected_at: float = 0.0,
    confidence: float = 1.0,
    is_valid_data: bool = True,
    is_corrupted: bool = False,
    is_timestamp_invalid: bool = False,
    existing_recovery_status: RecoveryStatus = RecoveryStatus.NOT_REQUIRED,
) -> Optional[SensorFailureEvent]:
    """
    Classify a sensor health summary into a SensorFailureEvent.

    Returns None if the sensor is healthy (no failure to report).
    Returns a SensorFailureEvent describing the failure otherwise.

    Parameters
    ----------
    sensor_type          : Which sensor.
    health_summary       : Translated health from translate_sensor_health().
    frame_age_s          : Age of the latest frame; None = never received.
    timestamp            : Sensor frame timestamp to attach to the event.
    frame_id             : Frame counter.
    config               : FailSafeConfig.
    first_detected_at    : When this failure was first observed (0.0 = now).
    confidence           : Sensor-level confidence proxy.
    is_valid_data        : False if structural validation failed.
    is_corrupted         : True if data integrity check failed.
    is_timestamp_invalid : True if the sensor timestamp is malformed.
    existing_recovery_status: Current recovery state (for continuity).
    """
    # Determine failure type
    failure_type: SensorFailureType
    severity: FailureSeverity
    urgency: FailureUrgency
    stale = False
    degraded = False

    timeout_s = config.sensor_timeout_for(sensor_type.value.lower())

    if is_timestamp_invalid:
        failure_type = SensorFailureType.SENSOR_TIMESTAMP_FAILURE
        severity = FailureSeverity.HIGH
        urgency = FailureUrgency.HIGH
        stale = True

    elif is_corrupted:
        failure_type = SensorFailureType.SENSOR_CORRUPTED_DATA
        severity = FailureSeverity.HIGH
        urgency = FailureUrgency.HIGH

    elif not is_valid_data:
        failure_type = SensorFailureType.SENSOR_INVALID_DATA
        severity = FailureSeverity.HIGH
        urgency = FailureUrgency.HIGH

    elif health_summary == SensorHealthSummary.UNAVAILABLE:
        if frame_age_s is None:
            failure_type = SensorFailureType.SENSOR_MISSING
            severity = FailureSeverity.CRITICAL
            urgency = FailureUrgency.IMMEDIATE
        else:
            failure_type = SensorFailureType.SENSOR_TIMEOUT
            severity = FailureSeverity.CRITICAL
            urgency = FailureUrgency.IMMEDIATE
        stale = True

    elif health_summary == SensorHealthSummary.INVALID:
        failure_type = SensorFailureType.SENSOR_FRAME_FAILURE
        severity = FailureSeverity.HIGH
        urgency = FailureUrgency.HIGH

    elif health_summary == SensorHealthSummary.CRITICAL:
        failure_type = SensorFailureType.SENSOR_HEALTH_CRITICAL
        severity = FailureSeverity.CRITICAL
        urgency = FailureUrgency.IMMEDIATE

    elif health_summary == SensorHealthSummary.STALE:
        failure_type = SensorFailureType.SENSOR_STALE
        severity = FailureSeverity.HIGH
        urgency = FailureUrgency.HIGH
        stale = True

    elif health_summary == SensorHealthSummary.DEGRADED:
        # Distinguish rate degradation from low-confidence degradation
        if confidence < config.low_confidence_threshold:
            failure_type = SensorFailureType.SENSOR_LOW_CONFIDENCE
        else:
            failure_type = SensorFailureType.SENSOR_RATE_DEGRADATION
        severity = FailureSeverity.MEDIUM
        urgency = FailureUrgency.MEDIUM
        degraded = True

    elif health_summary == SensorHealthSummary.UNKNOWN:
        failure_type = SensorFailureType.SENSOR_UNKNOWN_FAILURE
        severity = FailureSeverity.HIGH
        urgency = FailureUrgency.HIGH
        stale = True

    else:
        # HEALTHY — no failure
        return None

    reason_codes: Tuple[str, ...] = (failure_type.value,)
    evidence = {
        "health_summary": health_summary.value,
        "frame_age_s": frame_age_s,
        "confidence": round(confidence, 4),
        "timeout_s": timeout_s,
    }

    # Recovery status: if we were in recovery validating and health is now
    # degraded (not fully failed), keep validation going; otherwise reset.
    recovery_status = existing_recovery_status
    if health_summary in (SensorHealthSummary.UNAVAILABLE, SensorHealthSummary.CRITICAL):
        recovery_status = RecoveryStatus.NOT_REQUIRED  # not recovering yet
    elif health_summary == SensorHealthSummary.DEGRADED and existing_recovery_status in (
        RecoveryStatus.RECOVERY_VALIDATING,
        RecoveryStatus.RECOVERY_PENDING,
    ):
        # Still degraded — not recovered
        recovery_status = RecoveryStatus.RECOVERY_FAILED

    return SensorFailureEvent(
        sensor_type=sensor_type,
        failure_type=failure_type,
        severity=severity,
        urgency=urgency,
        timestamp=timestamp,
        frame_id=frame_id,
        first_detected_at=first_detected_at if first_detected_at > 0.0 else timestamp,
        last_observed_at=timestamp,
        confidence=max(0.0, min(1.0, confidence)),
        uncertainty=max(0.0, min(1.0, 1.0 - confidence)),
        stale=stale,
        degraded=degraded,
        affected_capabilities=(),  # populated by engine via dependency graph
        reason_codes=reason_codes,
        evidence=evidence,
        recovery_status=recovery_status,
    )


def classify_sync_failure(
    sensor_a: FailSafeSensorType,
    sensor_b: FailSafeSensorType,
    timestamp_a: float,
    timestamp_b: float,
    ref_timestamp: float,
    config: FailSafeConfig,
) -> Optional[SensorFailureEvent]:
    """
    Detect a sensor synchronisation failure between two sensors.

    Returns a SensorFailureEvent for the *lagging* sensor if the timestamp
    skew exceeds the configured tolerance; returns None if within tolerance.

    Parameters
    ----------
    sensor_a / sensor_b : The two sensors to compare.
    timestamp_a / timestamp_b: Their respective data timestamps.
    ref_timestamp       : Reference timestamp (e.g. pipeline frame timestamp).
    config              : FailSafeConfig.
    """
    if not (math.isfinite(timestamp_a) and timestamp_a >= 0.0):
        return _make_sync_event(sensor_a, ref_timestamp, "invalid_timestamp_a", config)
    if not (math.isfinite(timestamp_b) and timestamp_b >= 0.0):
        return _make_sync_event(sensor_b, ref_timestamp, "invalid_timestamp_b", config)

    skew = abs(timestamp_a - timestamp_b)
    if skew <= config.sync_timestamp_tolerance_s:
        return None

    # The lagging sensor is the one with the older timestamp
    lagging_sensor = sensor_a if timestamp_a < timestamp_b else sensor_b

    return SensorFailureEvent(
        sensor_type=lagging_sensor,
        failure_type=SensorFailureType.SENSOR_SYNCHRONIZATION_FAILURE,
        severity=FailureSeverity.HIGH,
        urgency=FailureUrgency.HIGH,
        timestamp=ref_timestamp,
        frame_id=0,
        first_detected_at=ref_timestamp,
        last_observed_at=ref_timestamp,
        confidence=0.9,
        uncertainty=0.1,
        stale=True,
        degraded=True,
        affected_capabilities=(),
        reason_codes=(SensorFailureType.SENSOR_SYNCHRONIZATION_FAILURE.value,),
        evidence={
            "skew_s": round(skew, 6),
            "tolerance_s": config.sync_timestamp_tolerance_s,
            "sensor_a": sensor_a.value,
            "sensor_b": sensor_b.value,
            "timestamp_a": timestamp_a,
            "timestamp_b": timestamp_b,
        },
        recovery_status=RecoveryStatus.NOT_REQUIRED,
    )


def _make_sync_event(
    sensor: FailSafeSensorType,
    timestamp: float,
    reason: str,
    config: FailSafeConfig,
) -> SensorFailureEvent:
    return SensorFailureEvent(
        sensor_type=sensor,
        failure_type=SensorFailureType.SENSOR_SYNCHRONIZATION_FAILURE,
        severity=FailureSeverity.HIGH,
        urgency=FailureUrgency.HIGH,
        timestamp=timestamp,
        first_detected_at=timestamp,
        last_observed_at=timestamp,
        confidence=0.9,
        uncertainty=0.1,
        stale=True,
        degraded=False,
        affected_capabilities=(),
        reason_codes=(SensorFailureType.SENSOR_SYNCHRONIZATION_FAILURE.value, reason),
        evidence={"reason": reason},
        recovery_status=RecoveryStatus.NOT_REQUIRED,
    )
