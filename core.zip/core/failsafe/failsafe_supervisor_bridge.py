"""
IndiDrive AI — Phase 11.4 | Fail-Safe → Safety Supervisor Bridge
=================================================================
Translates a FailSafeDecision (Phase 11.4) into the control-authority
and reason-code vocabulary of the Safety Supervisor (Phase 11.3).

Architecture position:

    FailSafeEngine  (Phase 11.4)
          ↓  FailSafeDecision
    FailSafeSupervisorBridge   ← this module
          ↓  FailSafeBridgeResult
    SafetySupervisor.evaluate_with_failsafe()  (Phase 11.3 extension)
          ↓  SafetySupervisorDecision
    Control Authority

Design rules:
  * Pure translation — no new failure detection logic.
  * Never relaxes a restriction imposed by FailSafeDecision.
  * Deterministic — same FailSafeDecision → same FailSafeBridgeResult.
  * Does NOT modify any Phase 11.3 module internals.
  * Does NOT generate actuator commands.
  * Returns structured data consumed by the supervisor's existing aggregation path.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import List, Tuple

from .failsafe_types import (
    FailSafeDecision,
    FailSafeState,
    FailureSeverity,
    RecoveryStatus,
)
from core.safety_supervisor.supervisor_types import ControlAuthority, OverrideReason

__all__ = ["FailSafeBridgeResult", "translate_failsafe_to_supervisor"]


@dataclass(frozen=True)
class FailSafeBridgeResult:
    """
    Translated output of a FailSafeDecision for the Safety Supervisor.

    Fields
    ------
    authority   : ControlAuthority to contribute to the supervisor's
                  authority aggregation.  This is ONE input to the
                  supervisor's _most_restrictive() aggregation — it is
                  NOT the final authority.
    reasons     : OverrideReason list to merge into the supervisor's
                  reason-code list.
    stale       : True if the fail-safe decision itself was stale.
    degraded    : True if the fail-safe decision was degraded.
    confidence  : Fail-safe confidence (passed through to supervisor).
    summary     : Human-readable one-line summary for logging.
    """
    authority:  ControlAuthority              = ControlAuthority.UNKNOWN_CONTROL_AUTHORITY
    reasons:    Tuple[OverrideReason, ...]    = field(default_factory=tuple)
    stale:      bool                          = True
    degraded:   bool                          = True
    confidence: float                         = 0.0
    summary:    str                           = ""


# ---------------------------------------------------------------------------
# Mapping tables
# ---------------------------------------------------------------------------

# FailSafeState → ControlAuthority (most conservative mapping)
_STATE_TO_AUTHORITY: dict[FailSafeState, ControlAuthority] = {
    FailSafeState.NORMAL_OPERATION:        ControlAuthority.NORMAL_CONTROL,
    FailSafeState.DEGRADED_OPERATION:      ControlAuthority.DEGRADED_CONTROL,
    FailSafeState.SENSOR_DEGRADED:         ControlAuthority.LIMITED_CONTROL,
    FailSafeState.SENSOR_UNAVAILABLE:      ControlAuthority.RESTRICTED_CONTROL,
    FailSafeState.SUBSYSTEM_DEGRADED:      ControlAuthority.LIMITED_CONTROL,
    FailSafeState.SUBSYSTEM_FAILURE:       ControlAuthority.RESTRICTED_CONTROL,
    FailSafeState.FAIL_SAFE_ACTIVE:        ControlAuthority.RESTRICTED_CONTROL,
    FailSafeState.CONTROL_RESTRICTED:      ControlAuthority.RESTRICTED_CONTROL,
    FailSafeState.CONTROL_WITHHELD:        ControlAuthority.CONTROL_WITHHELD,
    FailSafeState.RECOVERY_PENDING:        ControlAuthority.RESTRICTED_CONTROL,
    FailSafeState.RECOVERY_VALIDATING:     ControlAuthority.RESTRICTED_CONTROL,
    FailSafeState.RECOVERED:               ControlAuthority.LIMITED_CONTROL,
    FailSafeState.UNKNOWN_FAIL_SAFE_STATE: ControlAuthority.UNKNOWN_CONTROL_AUTHORITY,
}

# FailSafeState → OverrideReason
_STATE_TO_REASON: dict[FailSafeState, OverrideReason] = {
    FailSafeState.NORMAL_OPERATION:        OverrideReason.INSUFFICIENT_CLEAR_CYCLES,  # not used; filtered
    FailSafeState.DEGRADED_OPERATION:      OverrideReason.DEGRADED_SYSTEM,
    FailSafeState.SENSOR_DEGRADED:         OverrideReason.DEGRADED_SYSTEM,
    FailSafeState.SENSOR_UNAVAILABLE:      OverrideReason.SYSTEM_CRITICAL_FAILURE,
    FailSafeState.SUBSYSTEM_DEGRADED:      OverrideReason.DEGRADED_SYSTEM,
    FailSafeState.SUBSYSTEM_FAILURE:       OverrideReason.SYSTEM_CRITICAL_FAILURE,
    FailSafeState.FAIL_SAFE_ACTIVE:        OverrideReason.SYSTEM_CRITICAL_FAILURE,
    FailSafeState.CONTROL_RESTRICTED:      OverrideReason.DEGRADED_SYSTEM,
    FailSafeState.CONTROL_WITHHELD:        OverrideReason.SYSTEM_CRITICAL_FAILURE,
    FailSafeState.RECOVERY_PENDING:        OverrideReason.RECOVERY_IN_PROGRESS,
    FailSafeState.RECOVERY_VALIDATING:     OverrideReason.RECOVERY_IN_PROGRESS,
    FailSafeState.RECOVERED:               OverrideReason.INSUFFICIENT_CLEAR_CYCLES,
    FailSafeState.UNKNOWN_FAIL_SAFE_STATE: OverrideReason.UNKNOWN_SAFETY_STATE,
}

# Dominant reason codes from FailSafeDecision → OverrideReason (best-effort mapping)
_FAILSAFE_REASON_TO_OVERRIDE: dict[str, OverrideReason] = {
    # Sensor failures
    "SENSOR_MISSING":                 OverrideReason.SYSTEM_CRITICAL_FAILURE,
    "SENSOR_TIMEOUT":                 OverrideReason.SYSTEM_CRITICAL_FAILURE,
    "SENSOR_STALE":                   OverrideReason.STALE_VEHICLE_STATE,
    "SENSOR_INVALID_DATA":            OverrideReason.INVALID_VEHICLE_STATE,
    "SENSOR_CORRUPTED_DATA":          OverrideReason.INVALID_VEHICLE_STATE,
    "SENSOR_TIMESTAMP_FAILURE":       OverrideReason.INVALID_VEHICLE_STATE,
    "SENSOR_SYNCHRONIZATION_FAILURE": OverrideReason.STALE_VEHICLE_STATE,
    "SENSOR_HEALTH_CRITICAL":         OverrideReason.SYSTEM_CRITICAL_FAILURE,
    "SENSOR_LOW_CONFIDENCE":          OverrideReason.DEGRADED_SYSTEM,
    "SENSOR_RATE_DEGRADATION":        OverrideReason.DEGRADED_SYSTEM,
    # Subsystem failures
    "OUTPUT_UNAVAILABLE":             OverrideReason.SYSTEM_CRITICAL_FAILURE,
    "OUTPUT_STALE":                   OverrideReason.STALE_SAFETY_STATE,
    "OUTPUT_INVALID":                 OverrideReason.INVALID_VEHICLE_STATE,
    "OUTPUT_DEGRADED":                OverrideReason.DEGRADED_SYSTEM,
    "DEPENDENCY_FAILED":              OverrideReason.SYSTEM_CRITICAL_FAILURE,
    "CONFIDENCE_TOO_LOW":             OverrideReason.DEGRADED_SYSTEM,
    # Recovery
    "RECOVERY_PENDING":               OverrideReason.RECOVERY_IN_PROGRESS,
    "RECOVERY_VALIDATING":            OverrideReason.RECOVERY_IN_PROGRESS,
    "RECOVERY_BLOCKED":               OverrideReason.RECOVERY_IN_PROGRESS,
    # Specific subsystem reason strings
    "CONTROL_FAILURE":                OverrideReason.CONTROL_FAILURE,
    "MPC_FAILURE":                    OverrideReason.MPC_FAILURE,
    "PLANNER_FAILURE":                OverrideReason.PLANNER_FAILURE,
    "TRACKING_FAILURE":               OverrideReason.TRACKING_LOST,
    # States
    "UNKNOWN_FAIL_SAFE_STATE":        OverrideReason.UNKNOWN_SAFETY_STATE,
    "NORMAL_OPERATION":               OverrideReason.INSUFFICIENT_CLEAR_CYCLES,  # filtered
}


def translate_failsafe_to_supervisor(
    decision: FailSafeDecision,
) -> FailSafeBridgeResult:
    """
    Translate a FailSafeDecision into a FailSafeBridgeResult for the
    Safety Supervisor.

    This is a pure mapping — it performs no failure detection of its own.
    It is called once per cycle by SafetySupervisor.evaluate_with_failsafe().

    Parameters
    ----------
    decision : FailSafeDecision
        The decision produced by FailSafeEngine this cycle.

    Returns
    -------
    FailSafeBridgeResult — deterministic, immutable.
    """
    state = decision.fail_safe_state

    # Map fail-safe state to control authority
    authority = _STATE_TO_AUTHORITY.get(state, ControlAuthority.UNKNOWN_CONTROL_AUTHORITY)

    # If fail-safe explicitly withheld, always map to CONTROL_WITHHELD
    # regardless of the state enum (defensive: handles any future states)
    if decision.control_withheld:
        authority = ControlAuthority.CONTROL_WITHHELD

    # Collect reasons
    reasons: List[OverrideReason] = []

    # Primary reason from the fail-safe state
    state_reason = _STATE_TO_REASON.get(state)
    if state_reason and state != FailSafeState.NORMAL_OPERATION:
        reasons.append(state_reason)

    # Additional reasons from the decision's reason_codes
    for code in decision.reason_codes:
        mapped = _FAILSAFE_REASON_TO_OVERRIDE.get(code)
        if mapped and mapped not in reasons and mapped != OverrideReason.INSUFFICIENT_CLEAR_CYCLES:
            reasons.append(mapped)

    # Recovery reasons
    if decision.recovery_status in (
        RecoveryStatus.RECOVERY_PENDING.value,
        RecoveryStatus.RECOVERY_VALIDATING.value,
        RecoveryStatus.RECOVERY_BLOCKED.value,
    ):
        if OverrideReason.RECOVERY_IN_PROGRESS not in reasons:
            reasons.append(OverrideReason.RECOVERY_IN_PROGRESS)

    # Staleness
    if decision.stale and OverrideReason.STALE_SAFETY_STATE not in reasons:
        reasons.append(OverrideReason.STALE_SAFETY_STATE)

    # For NORMAL_OPERATION with no failures, keep reasons empty
    if state == FailSafeState.NORMAL_OPERATION and not decision.active_sensor_failures \
            and not decision.active_subsystem_failures:
        reasons = []

    # Build summary
    n_sensor = len(decision.active_sensor_failures)
    n_sub = len(decision.active_subsystem_failures)
    summary = (
        f"FailSafe→Supervisor: state={state.value} "
        f"authority={authority.value} "
        f"sensor_failures={n_sensor} sub_failures={n_sub} "
        f"withheld={decision.control_withheld}"
    )

    return FailSafeBridgeResult(
        authority=authority,
        reasons=tuple(reasons),
        stale=decision.stale,
        degraded=decision.degraded,
        confidence=decision.confidence,
        summary=summary,
    )
