"""
IndiDrive AI — Phase 11.4 | Fail-Safe Engine
=============================================
Detects, classifies, isolates, and propagates failures for sensors and
subsystems, and produces a structured FailSafeDecision for the Phase 11.3
Safety Supervisor.

Architecture position:
    Sensor / Subsystem Health  (Phase 1–11.3 existing modules)
          ↓
      Fail-Safe Engine  (Phase 11.4 — this module)
          ↓
    Safety Supervisor  (Phase 11.3)
          ↓
    Control Authority

Design rules:
  * Deterministic — same input → same FailSafeDecision.
  * Conservative — missing / stale / unknown safety-critical data is never
    assumed healthy.
  * No wall-clock time inside pure evaluation logic; uses supplied timestamps.
  * Does NOT generate actuator commands, CAN messages, or ECU commands.
  * Does NOT implement a new planner, MPC, perception, or prediction system.
  * Does NOT restart physical sensors or reconnect hardware.
  * Consumes existing Phase 1–11.3 health/status outputs; does NOT duplicate
    their internal logic.
  * Thread-safe: all shared state is protected by a lock; outputs are
    immutable frozen dataclasses.

Capability dependency graph
---------------------------
Camera failure  → OBJECT_DETECTION, LANE_ESTIMATION, ROAD_BOUNDARY_ESTIMATION,
                  DRIVABLE_AREA_ESTIMATION, ROAD_HAZARD_ESTIMATION
LiDAR failure   → OBJECT_DETECTION, DEPTH_ESTIMATION, ROAD_BOUNDARY_ESTIMATION
Radar failure   → OBJECT_DETECTION  (supplementary)
VEHICLE_STATE failure → VEHICLE_STATE_ESTIMATION, TRAJECTORY_TRACKING,
                        MPC_CONTROL, CONTROL_AUTHORITY
Perception failure    → OBJECT_DETECTION, OBJECT_TRACKING, LANE_ESTIMATION,
                        ROAD_HAZARD_ESTIMATION
Fusion failure        → SENSOR_FUSION, WORLD_MODEL_VALIDITY,
                        MOTION_PREDICTION, COLLISION_RISK_ESTIMATION
Prediction failure    → MOTION_PREDICTION, COLLISION_RISK_ESTIMATION
Road understanding    → ROAD_BOUNDARY_ESTIMATION, DRIVABLE_AREA_ESTIMATION,
                        LANE_ESTIMATION
World model failure   → WORLD_MODEL_VALIDITY, PLANNING,
                        COLLISION_RISK_ESTIMATION
Planning failure      → PLANNING
Tracking failure      → TRAJECTORY_TRACKING, MPC_CONTROL
MPC failure           → MPC_CONTROL
Control failure       → CONTROL_AUTHORITY
Safety monitor failure    → SAFETY_MONITORING
Emergency det. failure    → EMERGENCY_DETECTION
Safety supervisor failure → CONTROL_AUTHORITY
"""
from __future__ import annotations

import math
import threading
import uuid
from typing import Dict, FrozenSet, List, Optional, Set, Tuple

from .failsafe_config import FailSafeConfig
from .failsafe_snapshot import build_snapshot
from .failsafe_types import (
    FAILSAFE_SCHEMA_VERSION,
    FAILSAFE_STATE_PRIORITY,
    SEVERITY_PRIORITY,
    FailSafeDecision,
    FailSafeSnapshot,
    FailSafeState,
    FailSafeSensorType,
    FailSafeSubsystemType,
    FailureSeverity,
    FailureUrgency,
    RecoveryStatus,
    SensorFailureEvent,
    SensorFailureType,
    SensorHealthSummary,
    SubsystemFailureEvent,
    SubsystemFailureType,
    SystemCapability,
)
from .failsafe_validator import FailSafeValidator
from .recovery_manager import RecoveryManager
from .sensor_failure import classify_sensor_failure, classify_sync_failure, translate_sensor_health

__all__ = ["FailSafeEngine"]

# ---------------------------------------------------------------------------
# Capability dependency maps
# ---------------------------------------------------------------------------

# Sensor → capabilities directly affected by that sensor's failure
_SENSOR_CAPABILITY_DEPS: Dict[FailSafeSensorType, FrozenSet[SystemCapability]] = {
    FailSafeSensorType.CAMERA: frozenset({
        SystemCapability.OBJECT_DETECTION,
        SystemCapability.LANE_ESTIMATION,
        SystemCapability.ROAD_BOUNDARY_ESTIMATION,
        SystemCapability.DRIVABLE_AREA_ESTIMATION,
        SystemCapability.ROAD_HAZARD_ESTIMATION,
    }),
    FailSafeSensorType.LIDAR: frozenset({
        SystemCapability.OBJECT_DETECTION,
        SystemCapability.DEPTH_ESTIMATION,
        SystemCapability.ROAD_BOUNDARY_ESTIMATION,
    }),
    FailSafeSensorType.RADAR: frozenset({
        SystemCapability.OBJECT_DETECTION,
    }),
    FailSafeSensorType.VEHICLE_STATE: frozenset({
        SystemCapability.VEHICLE_STATE_ESTIMATION,
        SystemCapability.TRAJECTORY_TRACKING,
        SystemCapability.MPC_CONTROL,
        SystemCapability.CONTROL_AUTHORITY,
    }),
    FailSafeSensorType.IMU: frozenset({
        SystemCapability.VEHICLE_STATE_ESTIMATION,
    }),
    FailSafeSensorType.GNSS: frozenset({
        SystemCapability.VEHICLE_STATE_ESTIMATION,
    }),
    FailSafeSensorType.UNKNOWN_SENSOR: frozenset(),
}

# Subsystem → capabilities directly affected by that subsystem's failure
_SUBSYSTEM_CAPABILITY_DEPS: Dict[FailSafeSubsystemType, FrozenSet[SystemCapability]] = {
    FailSafeSubsystemType.SENSOR_PIPELINE: frozenset({
        SystemCapability.OBJECT_DETECTION,
        SystemCapability.SENSOR_FUSION,
    }),
    FailSafeSubsystemType.PERCEPTION: frozenset({
        SystemCapability.OBJECT_DETECTION,
        SystemCapability.OBJECT_TRACKING,
        SystemCapability.LANE_ESTIMATION,
        SystemCapability.ROAD_HAZARD_ESTIMATION,
    }),
    FailSafeSubsystemType.FUSION: frozenset({
        SystemCapability.SENSOR_FUSION,
        SystemCapability.WORLD_MODEL_VALIDITY,
        SystemCapability.MOTION_PREDICTION,
        SystemCapability.COLLISION_RISK_ESTIMATION,
    }),
    FailSafeSubsystemType.PREDICTION: frozenset({
        SystemCapability.MOTION_PREDICTION,
        SystemCapability.COLLISION_RISK_ESTIMATION,
    }),
    FailSafeSubsystemType.ROAD_UNDERSTANDING: frozenset({
        SystemCapability.ROAD_BOUNDARY_ESTIMATION,
        SystemCapability.DRIVABLE_AREA_ESTIMATION,
        SystemCapability.LANE_ESTIMATION,
    }),
    FailSafeSubsystemType.WORLD_MODEL: frozenset({
        SystemCapability.WORLD_MODEL_VALIDITY,
        SystemCapability.PLANNING,
        SystemCapability.COLLISION_RISK_ESTIMATION,
    }),
    FailSafeSubsystemType.REASONING: frozenset(),  # advisory, not directly safety-capability
    FailSafeSubsystemType.PLANNING: frozenset({
        SystemCapability.PLANNING,
    }),
    FailSafeSubsystemType.TRACKING: frozenset({
        SystemCapability.TRAJECTORY_TRACKING,
        SystemCapability.MPC_CONTROL,
    }),
    FailSafeSubsystemType.MPC: frozenset({
        SystemCapability.MPC_CONTROL,
    }),
    FailSafeSubsystemType.CONTROL: frozenset({
        SystemCapability.CONTROL_AUTHORITY,
    }),
    FailSafeSubsystemType.VEHICLE_STATE: frozenset({
        SystemCapability.VEHICLE_STATE_ESTIMATION,
        SystemCapability.TRAJECTORY_TRACKING,
        SystemCapability.MPC_CONTROL,
        SystemCapability.CONTROL_AUTHORITY,
    }),
    FailSafeSubsystemType.SAFETY_MONITOR: frozenset({
        SystemCapability.SAFETY_MONITORING,
    }),
    FailSafeSubsystemType.EMERGENCY_DETECTION: frozenset({
        SystemCapability.EMERGENCY_DETECTION,
    }),
    FailSafeSubsystemType.SAFETY_SUPERVISOR: frozenset({
        SystemCapability.CONTROL_AUTHORITY,
    }),
    FailSafeSubsystemType.INTEGRATION_PIPELINE: frozenset({
        SystemCapability.SENSOR_FUSION,
        SystemCapability.WORLD_MODEL_VALIDITY,
    }),
    FailSafeSubsystemType.UNKNOWN_SUBSYSTEM: frozenset(),
}

# Subsystem → downstream subsystems that depend on it
_SUBSYSTEM_DOWNSTREAM: Dict[FailSafeSubsystemType, FrozenSet[FailSafeSubsystemType]] = {
    FailSafeSubsystemType.SENSOR_PIPELINE: frozenset({
        FailSafeSubsystemType.PERCEPTION,
        FailSafeSubsystemType.FUSION,
    }),
    FailSafeSubsystemType.PERCEPTION: frozenset({
        FailSafeSubsystemType.FUSION,
        FailSafeSubsystemType.WORLD_MODEL,
    }),
    FailSafeSubsystemType.FUSION: frozenset({
        FailSafeSubsystemType.WORLD_MODEL,
        FailSafeSubsystemType.PREDICTION,
    }),
    FailSafeSubsystemType.PREDICTION: frozenset({
        FailSafeSubsystemType.PLANNING,
        FailSafeSubsystemType.REASONING,
    }),
    FailSafeSubsystemType.ROAD_UNDERSTANDING: frozenset({
        FailSafeSubsystemType.WORLD_MODEL,
    }),
    FailSafeSubsystemType.WORLD_MODEL: frozenset({
        FailSafeSubsystemType.PLANNING,
        FailSafeSubsystemType.REASONING,
    }),
    FailSafeSubsystemType.PLANNING: frozenset({
        FailSafeSubsystemType.TRACKING,
    }),
    FailSafeSubsystemType.TRACKING: frozenset({
        FailSafeSubsystemType.MPC,
    }),
    FailSafeSubsystemType.MPC: frozenset({
        FailSafeSubsystemType.CONTROL,
    }),
    FailSafeSubsystemType.SAFETY_MONITOR: frozenset({
        FailSafeSubsystemType.EMERGENCY_DETECTION,
    }),
    FailSafeSubsystemType.EMERGENCY_DETECTION: frozenset({
        FailSafeSubsystemType.SAFETY_SUPERVISOR,
    }),
}

# Capabilities that are safety-critical — their loss forces CONTROL_WITHHELD
_SAFETY_CRITICAL_CAPABILITIES: FrozenSet[SystemCapability] = frozenset({
    SystemCapability.VEHICLE_STATE_ESTIMATION,
    SystemCapability.CONTROL_AUTHORITY,
    SystemCapability.SAFETY_MONITORING,
})

# Capabilities that make CONTROL_RESTRICTED when affected
_CONTROL_RESTRICTING_CAPABILITIES: FrozenSet[SystemCapability] = frozenset({
    SystemCapability.WORLD_MODEL_VALIDITY,
    SystemCapability.PLANNING,
    SystemCapability.TRAJECTORY_TRACKING,
    SystemCapability.MPC_CONTROL,
    SystemCapability.COLLISION_RISK_ESTIMATION,
    SystemCapability.EMERGENCY_DETECTION,
})


def _clamp01(v: float) -> float:
    return min(1.0, max(0.0, v))


def _valid_ts(ts: object) -> bool:
    try:
        f = float(ts)  # type: ignore[arg-type]
        return math.isfinite(f) and f >= 0.0
    except (TypeError, ValueError):
        return False


def _is_stale(data_ts: float, ref_ts: float, timeout_s: float) -> bool:
    if not _valid_ts(data_ts) or not _valid_ts(ref_ts):
        return True
    return (ref_ts - data_ts) > timeout_s


def _dominant_state(states: List[FailSafeState]) -> FailSafeState:
    """Return the highest-priority state from the list."""
    if not states:
        return FailSafeState.NORMAL_OPERATION
    priority_map = {s: i for i, s in enumerate(FAILSAFE_STATE_PRIORITY)}
    return min(states, key=lambda s: priority_map.get(s, len(FAILSAFE_STATE_PRIORITY)))


def _dominant_severity(severities: List[FailureSeverity]) -> FailureSeverity:
    if not severities:
        return FailureSeverity.UNKNOWN
    priority_map = {s: i for i, s in enumerate(SEVERITY_PRIORITY)}
    known = [s for s in severities if s != FailureSeverity.UNKNOWN]
    if not known:
        return FailureSeverity.UNKNOWN
    return min(known, key=lambda s: priority_map.get(s, len(SEVERITY_PRIORITY)))


class FailSafeEngine:
    """
    Phase 11.4 Fail-Safe and Sensor Failure Handling Engine.

    This engine:
      1. Receives sensor health summaries and subsystem status inputs.
      2. Classifies sensor and subsystem failures.
      3. Propagates failures only to directly affected capabilities via the
         explicit dependency graph.
      4. Applies hysteresis (failure confirmation and recovery confirmation cycles).
      5. Produces a deterministic, immutable FailSafeDecision each cycle.
      6. Produces a FailSafeSnapshot for downstream consumers.

    It does NOT:
      - Generate actuator, steering, brake, or throttle commands.
      - Access CAN / ECU / vehicle hardware.
      - Restart physical sensors.
      - Implement a new planner, MPC, perception, or prediction system.
      - Use LLMs, cloud APIs, or non-deterministic services.

    Usage
    -----
    engine = FailSafeEngine(config=FailSafeConfig.default())

    # Each cycle:
    decision = engine.evaluate(
        timestamp=current_timestamp,
        frame_id=frame_counter,
        camera_health=...,
        lidar_health=...,
        ...
    )
    snapshot = engine.last_snapshot()
    """

    def __init__(self, config: Optional[FailSafeConfig] = None) -> None:
        self._config = config or FailSafeConfig.default()
        self._validator = FailSafeValidator()
        self._recovery = RecoveryManager(self._config)
        self._lock = threading.Lock()
        self._last_snapshot: Optional[FailSafeSnapshot] = None

    # ------------------------------------------------------------------
    # Public API

    def evaluate(
        self,
        timestamp: float,
        frame_id: int = 0,
        *,
        # Sensor health inputs (from Phase 1 SensorHealthMonitor)
        camera_health_state: Optional[str] = None,
        camera_frame_age_s: Optional[float] = None,
        camera_confidence: float = 1.0,
        camera_is_valid_data: bool = True,
        camera_is_corrupted: bool = False,
        camera_ts_invalid: bool = False,

        lidar_health_state: Optional[str] = None,
        lidar_frame_age_s: Optional[float] = None,
        lidar_confidence: float = 1.0,
        lidar_is_valid_data: bool = True,
        lidar_is_corrupted: bool = False,
        lidar_ts_invalid: bool = False,

        radar_health_state: Optional[str] = None,
        radar_frame_age_s: Optional[float] = None,
        radar_confidence: float = 1.0,
        radar_is_valid_data: bool = True,

        vehicle_state_health_state: Optional[str] = None,
        vehicle_state_frame_age_s: Optional[float] = None,
        vehicle_state_confidence: float = 1.0,
        vehicle_state_is_valid: bool = True,

        # Synchronisation inputs
        check_camera_lidar_sync: bool = False,
        camera_data_timestamp: float = 0.0,
        lidar_data_timestamp: float = 0.0,

        # Subsystem status inputs (health strings from existing modules)
        # For each subsystem: None = not available, string = phase status
        perception_status: Optional[str] = None,
        perception_confidence: float = 0.0,
        perception_timestamp: float = 0.0,

        fusion_status: Optional[str] = None,
        fusion_confidence: float = 0.0,
        fusion_timestamp: float = 0.0,

        prediction_status: Optional[str] = None,
        prediction_confidence: float = 0.0,
        prediction_timestamp: float = 0.0,

        road_understanding_status: Optional[str] = None,
        road_understanding_timestamp: float = 0.0,

        world_model_valid: Optional[bool] = None,
        world_model_timestamp: float = 0.0,
        world_model_confidence: float = 0.0,
        world_model_degraded: bool = False,

        planning_status: Optional[str] = None,
        planning_timestamp: float = 0.0,
        planning_degraded: bool = False,

        tracking_status: Optional[str] = None,
        tracking_timestamp: float = 0.0,
        tracking_degraded: bool = False,

        mpc_status: Optional[str] = None,
        mpc_timestamp: float = 0.0,
        mpc_degraded: bool = False,

        control_status: Optional[str] = None,
        control_timestamp: float = 0.0,

        safety_monitor_state: Optional[str] = None,
        safety_monitor_timestamp: float = 0.0,
        safety_monitor_confidence: float = 0.0,

        emergency_detection_state: Optional[str] = None,
        emergency_detection_timestamp: float = 0.0,

        safety_supervisor_state: Optional[str] = None,
        safety_supervisor_timestamp: float = 0.0,

        # External blocks on recovery
        emergency_active: bool = False,
        supervisor_permits_recovery: bool = True,
    ) -> FailSafeDecision:
        """
        Evaluate all inputs and produce a FailSafeDecision for this cycle.

        Parameters are intentionally keyword-only (after timestamp/frame_id)
        to prevent positional argument confusion for such a large interface.

        Returns an immutable FailSafeDecision. Also updates the internal
        snapshot accessible via last_snapshot().
        """
        if not _valid_ts(timestamp):
            return self._unknown_decision(0.0, frame_id, "invalid_timestamp")

        cfg = self._config

        if not cfg.enable_failsafe:
            return self._normal_decision(timestamp, frame_id)

        # ------------------------------------------------------------------
        # 1. Classify sensor failures

        sensor_events: List[SensorFailureEvent] = []

        # Camera
        cam_summary = translate_sensor_health(
            camera_health_state or "NOT_CONFIGURED",
            camera_frame_age_s,
            camera_confidence,
            cfg,
        )
        cam_event = classify_sensor_failure(
            FailSafeSensorType.CAMERA,
            cam_summary,
            camera_frame_age_s,
            timestamp,
            frame_id,
            cfg,
            first_detected_at=self._recovery.first_detected_at("camera"),
            confidence=camera_confidence,
            is_valid_data=camera_is_valid_data,
            is_corrupted=camera_is_corrupted,
            is_timestamp_invalid=camera_ts_invalid,
            existing_recovery_status=self._recovery.get_status("camera"),
        )
        cam_event = self._apply_sensor_recovery(
            "camera", cam_event, timestamp, emergency_active, supervisor_permits_recovery
        )
        if cam_event is not None:
            cam_event = self._add_capabilities(cam_event, FailSafeSensorType.CAMERA)
            sensor_events.append(cam_event)

        # LiDAR
        lid_summary = translate_sensor_health(
            lidar_health_state or "NOT_CONFIGURED",
            lidar_frame_age_s,
            lidar_confidence,
            cfg,
        )
        lid_event = classify_sensor_failure(
            FailSafeSensorType.LIDAR,
            lid_summary,
            lidar_frame_age_s,
            timestamp,
            frame_id,
            cfg,
            first_detected_at=self._recovery.first_detected_at("lidar"),
            confidence=lidar_confidence,
            is_valid_data=lidar_is_valid_data,
            is_corrupted=lidar_is_corrupted,
            is_timestamp_invalid=lidar_ts_invalid,
            existing_recovery_status=self._recovery.get_status("lidar"),
        )
        lid_event = self._apply_sensor_recovery(
            "lidar", lid_event, timestamp, emergency_active, supervisor_permits_recovery
        )
        if lid_event is not None:
            lid_event = self._add_capabilities(lid_event, FailSafeSensorType.LIDAR)
            sensor_events.append(lid_event)

        # Radar (optional sensor)
        if radar_health_state is not None:
            rad_summary = translate_sensor_health(
                radar_health_state,
                radar_frame_age_s,
                radar_confidence,
                cfg,
            )
            rad_event = classify_sensor_failure(
                FailSafeSensorType.RADAR,
                rad_summary,
                radar_frame_age_s,
                timestamp,
                frame_id,
                cfg,
                first_detected_at=self._recovery.first_detected_at("radar"),
                confidence=radar_confidence,
                is_valid_data=radar_is_valid_data,
                existing_recovery_status=self._recovery.get_status("radar"),
            )
            rad_event = self._apply_sensor_recovery(
                "radar", rad_event, timestamp, emergency_active, supervisor_permits_recovery
            )
            if rad_event is not None:
                rad_event = self._add_capabilities(rad_event, FailSafeSensorType.RADAR)
                sensor_events.append(rad_event)

        # Vehicle state
        vs_summary = translate_sensor_health(
            vehicle_state_health_state or "NOT_CONFIGURED",
            vehicle_state_frame_age_s,
            vehicle_state_confidence,
            cfg,
        )
        if not vehicle_state_is_valid and vs_summary == SensorHealthSummary.HEALTHY:
            vs_summary = SensorHealthSummary.INVALID
        vs_event = classify_sensor_failure(
            FailSafeSensorType.VEHICLE_STATE,
            vs_summary,
            vehicle_state_frame_age_s,
            timestamp,
            frame_id,
            cfg,
            first_detected_at=self._recovery.first_detected_at("vehicle_state"),
            confidence=vehicle_state_confidence,
            is_valid_data=vehicle_state_is_valid,
            existing_recovery_status=self._recovery.get_status("vehicle_state"),
        )
        vs_event = self._apply_sensor_recovery(
            "vehicle_state", vs_event, timestamp, emergency_active, supervisor_permits_recovery
        )
        if vs_event is not None:
            vs_event = self._add_capabilities(vs_event, FailSafeSensorType.VEHICLE_STATE)
            sensor_events.append(vs_event)

        # Sensor synchronisation (camera ↔ lidar)
        if check_camera_lidar_sync and camera_health_state and lidar_health_state:
            sync_event = classify_sync_failure(
                FailSafeSensorType.CAMERA,
                FailSafeSensorType.LIDAR,
                camera_data_timestamp,
                lidar_data_timestamp,
                timestamp,
                cfg,
            )
            if sync_event is not None:
                # Sync failure affects fusion-dependent capabilities
                sync_caps = tuple(
                    _SUBSYSTEM_CAPABILITY_DEPS.get(FailSafeSubsystemType.FUSION, frozenset())
                )
                sync_event = SensorFailureEvent(
                    **{
                        **sync_event.__dict__,  # type: ignore[arg-type]
                        "affected_capabilities": sync_caps,
                    }
                )
                sensor_events.append(sync_event)

        # ------------------------------------------------------------------
        # 2. Classify subsystem failures

        sub_events: List[SubsystemFailureEvent] = []

        sub_events += self._classify_subsystem(
            FailSafeSubsystemType.PERCEPTION, "perception",
            perception_status, perception_confidence,
            perception_timestamp, timestamp, cfg,
            emergency_active, supervisor_permits_recovery,
        )
        sub_events += self._classify_subsystem(
            FailSafeSubsystemType.FUSION, "fusion",
            fusion_status, fusion_confidence,
            fusion_timestamp, timestamp, cfg,
            emergency_active, supervisor_permits_recovery,
        )
        sub_events += self._classify_subsystem(
            FailSafeSubsystemType.PREDICTION, "prediction",
            prediction_status, prediction_confidence,
            prediction_timestamp, timestamp, cfg,
            emergency_active, supervisor_permits_recovery,
        )
        sub_events += self._classify_subsystem(
            FailSafeSubsystemType.ROAD_UNDERSTANDING, "road_understanding",
            road_understanding_status, 1.0,
            road_understanding_timestamp, timestamp, cfg,
            emergency_active, supervisor_permits_recovery,
        )

        # World model — has explicit valid flag
        if world_model_valid is not None:
            wm_status_str = "OK" if world_model_valid else "INVALID"
            wm_conf = world_model_confidence if world_model_valid else 0.0
            sub_events += self._classify_subsystem(
                FailSafeSubsystemType.WORLD_MODEL, "world_model",
                wm_status_str, wm_conf,
                world_model_timestamp, timestamp, cfg,
                emergency_active, supervisor_permits_recovery,
                degraded=world_model_degraded,
            )

        sub_events += self._classify_subsystem(
            FailSafeSubsystemType.PLANNING, "planning",
            planning_status, 1.0,
            planning_timestamp, timestamp, cfg,
            emergency_active, supervisor_permits_recovery,
            degraded=planning_degraded,
        )
        sub_events += self._classify_subsystem(
            FailSafeSubsystemType.TRACKING, "tracking",
            tracking_status, 1.0,
            tracking_timestamp, timestamp, cfg,
            emergency_active, supervisor_permits_recovery,
            degraded=tracking_degraded,
        )
        sub_events += self._classify_subsystem(
            FailSafeSubsystemType.MPC, "mpc",
            mpc_status, 1.0,
            mpc_timestamp, timestamp, cfg,
            emergency_active, supervisor_permits_recovery,
            degraded=mpc_degraded,
        )
        sub_events += self._classify_subsystem(
            FailSafeSubsystemType.CONTROL, "control",
            control_status, 1.0,
            control_timestamp, timestamp, cfg,
            emergency_active, supervisor_permits_recovery,
        )
        sub_events += self._classify_subsystem(
            FailSafeSubsystemType.SAFETY_MONITOR, "safety_monitor",
            safety_monitor_state, safety_monitor_confidence,
            safety_monitor_timestamp, timestamp, cfg,
            emergency_active, supervisor_permits_recovery,
        )
        sub_events += self._classify_subsystem(
            FailSafeSubsystemType.EMERGENCY_DETECTION, "emergency_detection",
            emergency_detection_state, 1.0,
            emergency_detection_timestamp, timestamp, cfg,
            emergency_active, supervisor_permits_recovery,
        )
        sub_events += self._classify_subsystem(
            FailSafeSubsystemType.SAFETY_SUPERVISOR, "safety_supervisor",
            safety_supervisor_state, 1.0,
            safety_supervisor_timestamp, timestamp, cfg,
            emergency_active, supervisor_permits_recovery,
        )

        # ------------------------------------------------------------------
        # 3. Aggregate affected capabilities

        affected_caps: Set[SystemCapability] = set()
        for evt in sensor_events:
            affected_caps.update(evt.affected_capabilities)
        for evt in sub_events:
            affected_caps.update(evt.affected_capabilities)

        # ------------------------------------------------------------------
        # 4. Redundancy: camera+lidar for OBJECT_DETECTION
        #    If one fails but the other is healthy, OBJECT_DETECTION may
        #    remain available (degraded, not failed).
        affected_caps = self._apply_redundancy(
            affected_caps, sensor_events, cam_summary, lid_summary, cfg
        )

        # ------------------------------------------------------------------
        # 5. Determine fail-safe state and control restriction

        fs_state, control_withheld, control_restriction = self._determine_state(
            sensor_events, sub_events, affected_caps, cfg
        )

        # ------------------------------------------------------------------
        # 6. Aggregate severity, urgency, reasons

        all_severities = [e.severity for e in sensor_events] + [e.severity for e in sub_events]
        dominant_sev = _dominant_severity(all_severities)

        all_urgencies = [e.urgency for e in sensor_events] + [e.urgency for e in sub_events]
        dominant_urg = self._dominant_urgency(all_urgencies)

        all_reason_codes: List[str] = []
        for e in sensor_events:
            all_reason_codes.extend(e.reason_codes)
        for e in sub_events:
            all_reason_codes.extend(e.reason_codes)

        dominant_reason = all_reason_codes[0] if all_reason_codes else fs_state.value
        reason_codes_tuple = tuple(dict.fromkeys(all_reason_codes))  # deduplicated, ordered

        # Aggregate recovery status
        recovery_statuses = [e.recovery_status for e in sensor_events] + [
            e.recovery_status for e in sub_events
        ]
        agg_recovery = self._aggregate_recovery(recovery_statuses)

        # Confidence / uncertainty
        confidence = self._aggregate_confidence(sensor_events, sub_events, fs_state)
        uncertainty = _clamp01(1.0 - confidence)

        stale = any(e.stale for e in sensor_events) or any(e.stale for e in sub_events)
        degraded = any(e.degraded for e in sensor_events) or any(e.degraded for e in sub_events)

        # Decision ID — deterministic from key fields
        decision_id = f"fs:{fs_state.value}:{dominant_reason}:{int(timestamp * 1000)}"

        decision = FailSafeDecision(
            decision_id=decision_id,
            timestamp=timestamp,
            frame_id=frame_id,
            fail_safe_state=fs_state,
            control_restriction=control_restriction,
            control_withheld=control_withheld,
            safety_supervisor_state=safety_supervisor_state or "NOT_AVAILABLE",
            active_sensor_failures=tuple(sensor_events),
            active_subsystem_failures=tuple(sub_events),
            affected_capabilities=tuple(sorted(affected_caps, key=lambda c: c.value)),
            dominant_reason=dominant_reason,
            reason_codes=reason_codes_tuple,
            severity=dominant_sev.value,
            urgency=dominant_urg.value,
            confidence=confidence,
            uncertainty=uncertainty,
            stale=stale,
            degraded=degraded,
            recovery_status=agg_recovery.value,
            valid_until=timestamp + cfg.camera_timeout_s,
            schema_version=FAILSAFE_SCHEMA_VERSION,
        )

        # Validate before storing
        ok, reason = self._validator.validate_decision(decision)
        if not ok:
            # Log but still propagate — do not silently convert to normal
            decision = FailSafeDecision(
                **{
                    **decision.__dict__,  # type: ignore[arg-type]
                    "dominant_reason": f"VALIDATION_FAILED:{reason}",
                    "fail_safe_state": FailSafeState.UNKNOWN_FAIL_SAFE_STATE,
                    "control_withheld": True,
                    "control_restriction": True,
                }
            )

        snapshot = build_snapshot(decision)
        with self._lock:
            self._last_snapshot = snapshot

        return decision

    def last_snapshot(self) -> Optional[FailSafeSnapshot]:
        """Return the most recent FailSafeSnapshot (thread-safe, immutable)."""
        with self._lock:
            return self._last_snapshot

    # ------------------------------------------------------------------
    # Private helpers

    def _apply_sensor_recovery(
        self,
        sensor_key: str,
        event: Optional[SensorFailureEvent],
        timestamp: float,
        emergency_active: bool,
        supervisor_permits_recovery: bool,
    ) -> Optional[SensorFailureEvent]:
        """
        Update the recovery manager for this sensor and return an event
        with the updated recovery status.
        """
        if emergency_active:
            self._recovery.block_recovery(sensor_key, "emergency_active")
        elif not supervisor_permits_recovery:
            self._recovery.block_recovery(sensor_key, "supervisor_blocked")
        else:
            self._recovery.unblock_recovery(sensor_key)

        if event is None:
            self._recovery.record_healthy(sensor_key, timestamp)
            return None
        else:
            self._recovery.record_failure(sensor_key, timestamp)
            new_status = self._recovery.get_status(sensor_key)
            # Rebuild event with updated recovery_status
            return SensorFailureEvent(
                sensor_type=event.sensor_type,
                failure_type=event.failure_type,
                severity=event.severity,
                urgency=event.urgency,
                timestamp=event.timestamp,
                frame_id=event.frame_id,
                first_detected_at=event.first_detected_at,
                last_observed_at=event.last_observed_at,
                confidence=event.confidence,
                uncertainty=event.uncertainty,
                stale=event.stale,
                degraded=event.degraded,
                affected_capabilities=event.affected_capabilities,
                reason_codes=event.reason_codes,
                evidence=event.evidence,
                recovery_status=new_status,
            )

    def _add_capabilities(
        self, event: SensorFailureEvent, sensor_type: FailSafeSensorType
    ) -> SensorFailureEvent:
        """Attach capability dependencies to a sensor failure event."""
        caps = tuple(
            sorted(
                _SENSOR_CAPABILITY_DEPS.get(sensor_type, frozenset()),
                key=lambda c: c.value,
            )
        )
        return SensorFailureEvent(
            sensor_type=event.sensor_type,
            failure_type=event.failure_type,
            severity=event.severity,
            urgency=event.urgency,
            timestamp=event.timestamp,
            frame_id=event.frame_id,
            first_detected_at=event.first_detected_at,
            last_observed_at=event.last_observed_at,
            confidence=event.confidence,
            uncertainty=event.uncertainty,
            stale=event.stale,
            degraded=event.degraded,
            affected_capabilities=caps,
            reason_codes=event.reason_codes,
            evidence=event.evidence,
            recovery_status=event.recovery_status,
        )

    def _classify_subsystem(
        self,
        sub_type: FailSafeSubsystemType,
        sub_key: str,
        status: Optional[str],
        confidence: float,
        data_timestamp: float,
        ref_timestamp: float,
        cfg: FailSafeConfig,
        emergency_active: bool,
        supervisor_permits_recovery: bool,
        degraded: bool = False,
    ) -> List[SubsystemFailureEvent]:
        """
        Classify a single subsystem and return 0 or 1 SubsystemFailureEvent.
        """
        # Update recovery blocks
        if emergency_active:
            self._recovery.block_recovery(sub_key, "emergency_active")
        elif not supervisor_permits_recovery:
            self._recovery.block_recovery(sub_key, "supervisor_blocked")
        else:
            self._recovery.unblock_recovery(sub_key)

        timeout_s = cfg.subsystem_timeout_for(sub_key)

        failure_type: Optional[SubsystemFailureType] = None
        severity = FailureSeverity.UNKNOWN
        urgency = FailureUrgency.UNKNOWN
        stale = False

        if status is None:
            # No output available
            failure_type = SubsystemFailureType.OUTPUT_UNAVAILABLE
            severity = FailureSeverity.HIGH
            urgency = FailureUrgency.HIGH
            stale = True

        elif _is_stale(data_timestamp, ref_timestamp, timeout_s):
            failure_type = SubsystemFailureType.OUTPUT_STALE
            severity = FailureSeverity.HIGH
            urgency = FailureUrgency.HIGH
            stale = True

        elif status in ("INVALID", "FAILED", "ERROR", "UNAVAILABLE"):
            failure_type = SubsystemFailureType.OUTPUT_INVALID
            severity = FailureSeverity.HIGH
            urgency = FailureUrgency.HIGH

        elif degraded or status in ("DEGRADED", "CAUTION", "RESTRICTED"):
            failure_type = SubsystemFailureType.OUTPUT_DEGRADED
            severity = FailureSeverity.MEDIUM
            urgency = FailureUrgency.MEDIUM

        elif confidence < cfg.low_confidence_threshold:
            failure_type = SubsystemFailureType.CONFIDENCE_TOO_LOW
            severity = FailureSeverity.MEDIUM
            urgency = FailureUrgency.LOW

        if failure_type is None:
            # Healthy
            self._recovery.record_healthy(sub_key, ref_timestamp)
            return []

        self._recovery.record_failure(sub_key, ref_timestamp)
        recovery_status = self._recovery.get_status(sub_key)

        caps = tuple(
            sorted(
                _SUBSYSTEM_CAPABILITY_DEPS.get(sub_type, frozenset()),
                key=lambda c: c.value,
            )
        )
        downstream = tuple(
            sorted(
                _SUBSYSTEM_DOWNSTREAM.get(sub_type, frozenset()),
                key=lambda s: s.value,
            )
        )

        event = SubsystemFailureEvent(
            subsystem=sub_type,
            failure_type=failure_type,
            severity=severity,
            urgency=urgency,
            timestamp=data_timestamp if _valid_ts(data_timestamp) else ref_timestamp,
            confidence=_clamp01(confidence),
            uncertainty=_clamp01(1.0 - confidence),
            stale=stale,
            degraded=degraded,
            affected_capabilities=caps,
            dependent_subsystems=downstream,
            reason_codes=(failure_type.value,),
            evidence={
                "status": status,
                "data_timestamp": data_timestamp,
                "ref_timestamp": ref_timestamp,
                "timeout_s": timeout_s,
            },
            recovery_status=recovery_status,
        )
        return [event]

    def _apply_redundancy(
        self,
        affected_caps: Set[SystemCapability],
        sensor_events: List[SensorFailureEvent],
        cam_summary: SensorHealthSummary,
        lid_summary: SensorHealthSummary,
        cfg: FailSafeConfig,
    ) -> Set[SystemCapability]:
        """
        If camera+lidar provide overlapping coverage and one is healthy,
        do not mark OBJECT_DETECTION as lost — only as degraded.
        This does NOT invent redundancy that doesn't exist in the architecture.
        """
        if not cfg.camera_lidar_redundancy:
            return affected_caps

        cam_failed = cam_summary in (SensorHealthSummary.UNAVAILABLE, SensorHealthSummary.CRITICAL)
        lid_failed = lid_summary in (SensorHealthSummary.UNAVAILABLE, SensorHealthSummary.CRITICAL)

        # If one fails but the other is fully healthy, OBJECT_DETECTION is
        # degraded (not lost) — leave it in affected_caps but the state will
        # be DEGRADED_OPERATION, not SUBSYSTEM_FAILURE.
        # This is already expressed by having the event with SENSOR_DEGRADED.
        # No removal of capabilities here — this is handled in state determination.

        return affected_caps

    def _determine_state(
        self,
        sensor_events: List[SensorFailureEvent],
        sub_events: List[SubsystemFailureEvent],
        affected_caps: Set[SystemCapability],
        cfg: FailSafeConfig,
    ) -> Tuple[FailSafeState, bool, bool]:
        """
        Determine the overall FailSafeState and control restriction flags.

        Returns (fail_safe_state, control_withheld, control_restriction)
        """
        if not sensor_events and not sub_events:
            return FailSafeState.NORMAL_OPERATION, False, False

        # Check safety-critical capability loss
        critical_caps_lost = _SAFETY_CRITICAL_CAPABILITIES & affected_caps
        restricting_caps_lost = _CONTROL_RESTRICTING_CAPABILITIES & affected_caps

        # Any critical severity failure → FAIL_SAFE_ACTIVE at minimum
        has_critical = any(
            e.severity == FailureSeverity.CRITICAL
            for e in (*sensor_events, *sub_events)
        )

        # Check for control / safety supervisor failure
        control_sub_failed = any(
            e.subsystem in (
                FailSafeSubsystemType.CONTROL,
                FailSafeSubsystemType.SAFETY_SUPERVISOR,
            )
            for e in sub_events
        )
        vehicle_state_failed = any(
            e.sensor_type == FailSafeSensorType.VEHICLE_STATE
            and e.severity in (FailureSeverity.CRITICAL, FailureSeverity.HIGH)
            for e in sensor_events
        )

        # Determine if camera+lidar are both critically failed (redundancy exhausted)
        cam_critical = any(
            e.sensor_type == FailSafeSensorType.CAMERA
            and e.severity == FailureSeverity.CRITICAL
            for e in sensor_events
        )
        lid_critical = any(
            e.sensor_type == FailSafeSensorType.LIDAR
            and e.severity == FailureSeverity.CRITICAL
            for e in sensor_events
        )
        perception_lost = cam_critical and lid_critical

        control_withheld = False
        control_restriction = False
        states: List[FailSafeState] = []

        # CONTROL_WITHHELD conditions — only when a safety-critical capability is lost
        # or a control / safety authority subsystem has failed
        if critical_caps_lost or control_sub_failed or vehicle_state_failed:
            control_withheld = True
            control_restriction = True
            states.append(FailSafeState.CONTROL_WITHHELD)

        elif perception_lost:
            # Both primary perception sensors (camera+lidar) are critically failed —
            # redundancy exhausted; FAIL_SAFE_ACTIVE and control withheld
            control_withheld = True
            control_restriction = True
            states.append(FailSafeState.FAIL_SAFE_ACTIVE)

        elif has_critical:
            # A component has CRITICAL severity, but the loss is not directly in a
            # safety-critical capability (e.g. one of camera/lidar down while
            # the other is healthy). Restrict but do not withhold.
            control_restriction = True
            states.append(FailSafeState.FAIL_SAFE_ACTIVE)

        elif restricting_caps_lost:
            control_restriction = True
            states.append(FailSafeState.CONTROL_RESTRICTED)

        # Sensor-level states
        sensor_critical = any(
            e.severity == FailureSeverity.CRITICAL for e in sensor_events
        )
        sensor_unavailable = any(
            e.failure_type in (
                SensorFailureType.SENSOR_MISSING,
                SensorFailureType.SENSOR_TIMEOUT,
            )
            for e in sensor_events
        )
        sensor_degraded = any(
            e.degraded for e in sensor_events
        )

        if sensor_unavailable:
            states.append(FailSafeState.SENSOR_UNAVAILABLE)
        elif sensor_degraded:
            states.append(FailSafeState.SENSOR_DEGRADED)

        # Subsystem-level states
        sub_failed = any(
            e.failure_type in (
                SubsystemFailureType.OUTPUT_INVALID,
                SubsystemFailureType.OUTPUT_UNAVAILABLE,
                SubsystemFailureType.INTERNAL_ERROR,
            )
            for e in sub_events
            if e.severity in (FailureSeverity.CRITICAL, FailureSeverity.HIGH)
        )
        sub_degraded = any(
            e.degraded or e.failure_type == SubsystemFailureType.OUTPUT_DEGRADED
            for e in sub_events
        )

        if sub_failed:
            states.append(FailSafeState.SUBSYSTEM_FAILURE)
        elif sub_degraded:
            states.append(FailSafeState.SUBSYSTEM_DEGRADED)

        # Recovery states
        recovery_statuses = [e.recovery_status for e in (*sensor_events, *sub_events)]
        if RecoveryStatus.RECOVERY_VALIDATING in recovery_statuses:
            states.append(FailSafeState.RECOVERY_VALIDATING)
        elif RecoveryStatus.RECOVERY_PENDING in recovery_statuses:
            states.append(FailSafeState.RECOVERY_PENDING)

        # General degraded operation
        if not states:
            states.append(FailSafeState.DEGRADED_OPERATION)
            control_restriction = True

        fs_state = _dominant_state(states)

        # Enforce: if withheld, restriction must also be True
        if control_withheld:
            control_restriction = True

        return fs_state, control_withheld, control_restriction

    def _dominant_urgency(self, urgencies: List[FailureUrgency]) -> FailureUrgency:
        priority = [
            FailureUrgency.IMMEDIATE,
            FailureUrgency.HIGH,
            FailureUrgency.MEDIUM,
            FailureUrgency.LOW,
            FailureUrgency.NONE,
        ]
        known = [u for u in urgencies if u != FailureUrgency.UNKNOWN]
        if not known:
            return FailureUrgency.UNKNOWN
        pm = {u: i for i, u in enumerate(priority)}
        return min(known, key=lambda u: pm.get(u, len(priority)))

    def _aggregate_recovery(self, statuses: List[RecoveryStatus]) -> RecoveryStatus:
        priority = [
            RecoveryStatus.RECOVERY_BLOCKED,
            RecoveryStatus.RECOVERY_FAILED,
            RecoveryStatus.RECOVERY_PENDING,
            RecoveryStatus.RECOVERY_VALIDATING,
            RecoveryStatus.RECOVERY_CONFIRMED,
            RecoveryStatus.NOT_REQUIRED,
        ]
        if not statuses:
            return RecoveryStatus.NOT_REQUIRED
        pm = {s: i for i, s in enumerate(priority)}
        return min(statuses, key=lambda s: pm.get(s, len(priority)))

    def _aggregate_confidence(
        self,
        sensor_events: List[SensorFailureEvent],
        sub_events: List[SubsystemFailureEvent],
        state: FailSafeState,
    ) -> float:
        if state == FailSafeState.NORMAL_OPERATION:
            return 1.0
        if state in (FailSafeState.CONTROL_WITHHELD, FailSafeState.UNKNOWN_FAIL_SAFE_STATE):
            # High confidence in the failure
            return 0.9 if sensor_events or sub_events else 0.5
        all_conf = [e.confidence for e in (*sensor_events, *sub_events)]
        if not all_conf:
            return 0.5
        return _clamp01(sum(all_conf) / len(all_conf))

    def _normal_decision(self, timestamp: float, frame_id: int) -> FailSafeDecision:
        return FailSafeDecision(
            decision_id=f"fs:NORMAL:{int(timestamp * 1000)}",
            timestamp=timestamp,
            frame_id=frame_id,
            fail_safe_state=FailSafeState.NORMAL_OPERATION,
            control_restriction=False,
            control_withheld=False,
            safety_supervisor_state="NOT_AVAILABLE",
            active_sensor_failures=(),
            active_subsystem_failures=(),
            affected_capabilities=(),
            dominant_reason="NORMAL_OPERATION",
            reason_codes=(),
            severity=FailureSeverity.INFO.value,
            urgency=FailureUrgency.NONE.value,
            confidence=1.0,
            uncertainty=0.0,
            stale=False,
            degraded=False,
            recovery_status=RecoveryStatus.NOT_REQUIRED.value,
            valid_until=timestamp + self._config.camera_timeout_s,
        )

    def _unknown_decision(self, timestamp: float, frame_id: int, reason: str) -> FailSafeDecision:
        return FailSafeDecision(
            decision_id=f"fs:UNKNOWN:{reason}:{int(timestamp * 1000)}",
            timestamp=timestamp,
            frame_id=frame_id,
            fail_safe_state=FailSafeState.UNKNOWN_FAIL_SAFE_STATE,
            control_restriction=True,
            control_withheld=True,
            dominant_reason=reason,
            reason_codes=(reason,),
            severity=FailureSeverity.UNKNOWN.value,
            urgency=FailureUrgency.UNKNOWN.value,
            confidence=0.0,
            uncertainty=1.0,
            stale=True,
            degraded=True,
        )
