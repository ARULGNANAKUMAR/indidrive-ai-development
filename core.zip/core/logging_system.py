"""
IndiDrive AI — Phase 0 | Structured Logging
=============================================
Reusable logging system writing structured JSON-lines events into
logs/<category>/, plus a normal stdlib logger for console output.

Categories map to the directories required by Phase 0:
    system, sensors, vehicle, decisions, benchmark, errors

This does not replace any existing logging (e.g. legacy_simulator's own
logging.basicConfig console logger, or core modules' print-free file
writes) — it is new, additive infrastructure any Phase 0+ code can use.

Never logs secrets: callers should not pass API keys, passwords, tokens,
or credentials in `extra`; get_logger() does not accept or inspect
environment variables, so it cannot leak them itself, but callers are
responsible for not passing sensitive values through `extra`.
"""
from __future__ import annotations

import json
import logging
import sys
import time
from pathlib import Path
from typing import Any, Optional

ROOT = Path(__file__).resolve().parent.parent
LOGS_DIR = ROOT / "logs"

CATEGORIES = ("system", "sensors", "vehicle", "decisions", "benchmark", "errors", "perception")

LEVELS = {
    "DEBUG": logging.DEBUG,
    "INFO": logging.INFO,
    "WARNING": logging.WARNING,
    "ERROR": logging.ERROR,
    "CRITICAL": logging.CRITICAL,
}

_SENSITIVE_KEY_MARKERS = ("password", "secret", "token", "api_key", "apikey", "credential")


def ensure_log_directories() -> list[str]:
    """Create logs/<category>/ for every required category. Returns created paths (as strings)."""
    created = []
    for cat in CATEGORIES:
        d = LOGS_DIR / cat
        if not d.exists():
            d.mkdir(parents=True, exist_ok=True)
            created.append(str(d))
        else:
            d.mkdir(parents=True, exist_ok=True)
    return created


def _redact(extra: dict[str, Any]) -> dict[str, Any]:
    safe = {}
    for k, v in extra.items():
        if any(marker in k.lower() for marker in _SENSITIVE_KEY_MARKERS):
            safe[k] = "***REDACTED***"
        else:
            safe[k] = v
    return safe


class StructuredLogger:
    """
    Writes one JSON object per line to logs/<category>/<category>.log,
    and mirrors to the console via the stdlib logging module.

    Usage:
        log = StructuredLogger("system", component="health_check")
        log.info("startup", status="ok")
        log.error("config_load_failed", error=str(e))
    """

    def __init__(self, category: str, component: str = "", level: str = "INFO"):
        if category not in CATEGORIES:
            raise ValueError(f"Unknown log category '{category}'. Expected one of: {CATEGORIES}")
        self.category = category
        self.component = component
        ensure_log_directories()
        self._path = LOGS_DIR / category / f"{category}.log"

        self._logger = logging.getLogger(f"indidrive.{category}.{component or 'general'}")
        self._logger.setLevel(LEVELS.get(level.upper(), logging.INFO))
        if not self._logger.handlers:
            handler = logging.StreamHandler(sys.stdout)
            handler.setFormatter(logging.Formatter(
                "%(asctime)s %(levelname)s [%(name)s] %(message)s"
            ))
            self._logger.addHandler(handler)
            self._logger.propagate = False

    def _write(self, level: str, event: str, status: Optional[str], error: Optional[str],
               extra: dict[str, Any]) -> None:
        record = {
            "timestamp": time.strftime("%Y-%m-%dT%H:%M:%S", time.gmtime()),
            "component": self.component or self.category,
            "severity": level,
            "event": event,
        }
        if status is not None:
            record["status"] = status
        if error is not None:
            record["error"] = error
        if extra:
            record.update(_redact(extra))

        try:
            with open(self._path, "a", encoding="utf-8") as f:
                f.write(json.dumps(record, default=str) + "\n")
        except OSError:
            # Logging must never crash the caller; console mirror below still fires.
            pass

        console_msg = f"{event}" + (f" status={status}" if status else "") + (f" error={error}" if error else "")
        getattr(self._logger, level.lower(), self._logger.info)(console_msg)

    def debug(self, event: str, status: Optional[str] = None, error: Optional[str] = None, **extra):
        self._write("DEBUG", event, status, error, extra)

    def info(self, event: str, status: Optional[str] = None, error: Optional[str] = None, **extra):
        self._write("INFO", event, status, error, extra)

    def warning(self, event: str, status: Optional[str] = None, error: Optional[str] = None, **extra):
        self._write("WARNING", event, status, error, extra)

    def error(self, event: str, status: Optional[str] = None, error: Optional[str] = None, **extra):
        self._write("ERROR", event, status, error, extra)

    def critical(self, event: str, status: Optional[str] = None, error: Optional[str] = None, **extra):
        self._write("CRITICAL", event, status, error, extra)


def get_logger(category: str, component: str = "", level: str = "INFO") -> StructuredLogger:
    return StructuredLogger(category, component, level)
