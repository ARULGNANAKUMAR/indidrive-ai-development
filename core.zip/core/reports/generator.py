"""
IndiDrive AI — Phase 5 | Report Generator
Generates JSON, CSV and PDF (via reportlab if installed, else a
plain-text .txt fallback that is clearly labeled as such) reports for
benchmark runs, scenario replays, AI decisions, and overall safety.
"""
from __future__ import annotations

import csv
import json
import time
import uuid
from pathlib import Path

STORAGE_ROOT = Path(__file__).resolve().parents[2] / "storage" / "reports"


class ReportGenerator:
    def __init__(self):
        STORAGE_ROOT.mkdir(parents=True, exist_ok=True)

    def _new_path(self, kind: str, ext: str) -> Path:
        ts = time.strftime("%Y%m%d_%H%M%S")
        return STORAGE_ROOT / f"{kind}_{ts}_{uuid.uuid4().hex[:6]}.{ext}"

    def json_report(self, kind: str, data: dict) -> str:
        path = self._new_path(kind, "json")
        path.write_text(json.dumps(data, indent=2))
        return str(path)

    def csv_metrics(self, kind: str, rows: list[dict]) -> str:
        path = self._new_path(kind, "csv")
        if not rows:
            path.write_text("")
            return str(path)
        keys = sorted({k for r in rows for k in r.keys()})
        with open(path, "w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=keys)
            writer.writeheader()
            writer.writerows(rows)
        return str(path)

    def pdf_report(self, title: str, sections: list[tuple[str, str]]) -> str:
        """sections: list of (heading, body_text)"""
        try:
            from reportlab.lib.pagesizes import A4
            from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer
            from reportlab.lib.styles import getSampleStyleSheet
            path = self._new_path("technical_report", "pdf")
            doc = SimpleDocTemplate(str(path), pagesize=A4)
            styles = getSampleStyleSheet()
            story = [Paragraph(title, styles["Title"]), Spacer(1, 16)]
            for heading, body in sections:
                story.append(Paragraph(heading, styles["Heading2"]))
                story.append(Paragraph(body.replace("\n", "<br/>"), styles["BodyText"]))
                story.append(Spacer(1, 10))
            doc.build(story)
            return str(path)
        except Exception:
            # Honest fallback: plain text report, same content, .txt extension.
            path = self._new_path("technical_report_TEXT_FALLBACK", "txt")
            with open(path, "w") as f:
                f.write(f"{title}\n{'=' * len(title)}\n\n")
                f.write("[reportlab not installed — this is a plain-text fallback, not a real PDF]\n\n")
                for heading, body in sections:
                    f.write(f"{heading}\n{'-' * len(heading)}\n{body}\n\n")
            return str(path)

    def safety_report(self, benchmark_result: dict) -> dict:
        """Bundles JSON + CSV + PDF for a benchmark run into one safety report set."""
        rows = [{"category": cat, **res} for cat, res in benchmark_result["results"].items()]
        json_path = self.json_report("safety", benchmark_result)
        csv_path = self.csv_metrics("safety_metrics", rows)
        sections = [(cat.replace("_", " ").title(),
                     f"Score: {res['score']}/100  |  Mode: {res['mode']}  |  Metrics: {res['unit_metrics']}")
                    for cat, res in benchmark_result["results"].items()]
        sections.insert(0, ("Overall Safety Score", f"{benchmark_result['overall_score']}/100"))
        pdf_path = self.pdf_report("IndiDrive AI — Safety & Benchmark Report", sections)
        return {"json": json_path, "csv": csv_path, "pdf": pdf_path}

    def scenario_replay_summary(self, scenario: dict, experiences: list[dict]) -> str:
        body = f"Scenario: {json.dumps(scenario, indent=2)}\n\nExperiences replayed: {len(experiences)}\n"
        for e in experiences[:50]:
            body += f"- [{e['outcome']}] action={e['action_taken']} importance={e['importance']}\n"
        return self.pdf_report("Scenario Replay Summary", [("Replay", body)])

    def ai_decision_report(self, decisions: list[dict]) -> str:
        rows = decisions
        return self.csv_metrics("ai_decisions", rows)
