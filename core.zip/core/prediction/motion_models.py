"""
IndiDrive AI — Phase 4A | Motion Models
===========================================
Three deterministic kinematic models used to roll a `MotionState`
forward by `dt` seconds:

    constant_velocity(state, dt)          -- CV
    constant_acceleration(state, dt)      -- CA
    constant_turn_rate_and_velocity(state, dt)  -- CTRV

Each takes a MotionState and a non-negative dt and returns a NEW
MotionState (inputs are never mutated). All three are pure functions:
same input -> same output, always (spec section 17, determinism).

No model here reads configuration or performs model *selection* —
that is model_selector.py's job. These are only the equations.
"""
from __future__ import annotations

import math

from .prediction_types import MotionState

# Below this yaw-rate magnitude (rad/s), CTRV falls back to a
# straight-line approximation to avoid division by (near) zero.
YAW_RATE_EPSILON = 1e-4


def _safe_dt(dt: float) -> float:
    """Never allow a negative or non-finite dt to propagate into the
    equations below; treat it as "no time has passed"."""
    if not isinstance(dt, (int, float)) or not math.isfinite(dt) or dt < 0.0:
        return 0.0
    return dt


def constant_velocity(state: MotionState, dt: float) -> MotionState:
    """x(t) = x0 + vx*t ; y(t) = y0 + vy*t.
    The simplest model: velocity, acceleration and yaw are carried
    forward unchanged (CV assumes no turning, no speed change)."""
    t = _safe_dt(dt)
    x = state.x + state.vx * t
    y = state.y + state.vy * t
    z = state.z + state.vz * t
    speed = math.hypot(state.vx, state.vy)
    return MotionState(
        x=x, y=y, z=z,
        vx=state.vx, vy=state.vy, vz=state.vz,
        ax=0.0, ay=0.0, az=0.0,
        yaw=state.yaw, yaw_rate=0.0,
        speed=speed, heading=state.heading,
        timestamp=state.timestamp + t,
    )


def constant_acceleration(state: MotionState, dt: float) -> MotionState:
    """x(t) = x0 + vx*t + 0.5*ax*t^2 ; y(t) = y0 + vy*t + 0.5*ay*t^2.
    If acceleration is missing/non-finite, falls back safely to 0.0
    (i.e. degrades to constant velocity for that axis) rather than
    raising or fabricating a value."""
    t = _safe_dt(dt)
    ax = state.ax if math.isfinite(state.ax) else 0.0
    ay = state.ay if math.isfinite(state.ay) else 0.0
    az = state.az if math.isfinite(state.az) else 0.0

    x = state.x + state.vx * t + 0.5 * ax * t * t
    y = state.y + state.vy * t + 0.5 * ay * t * t
    z = state.z + state.vz * t + 0.5 * az * t * t
    vx = state.vx + ax * t
    vy = state.vy + ay * t
    vz = state.vz + az * t
    speed = math.hypot(vx, vy)
    return MotionState(
        x=x, y=y, z=z,
        vx=vx, vy=vy, vz=vz,
        ax=ax, ay=ay, az=az,
        yaw=state.yaw, yaw_rate=0.0,
        speed=speed, heading=state.heading,
        timestamp=state.timestamp + t,
    )


def constant_turn_rate_and_velocity(state: MotionState, dt: float) -> MotionState:
    """CTRV: constant speed, constant yaw rate. For near-zero yaw rate
    this safely degenerates to straight-line motion instead of dividing
    by (near) zero."""
    t = _safe_dt(dt)
    v = state.speed if math.isfinite(state.speed) and state.speed > 0.0 else math.hypot(state.vx, state.vy)
    yaw = state.yaw
    yaw_rate = state.yaw_rate if math.isfinite(state.yaw_rate) else 0.0

    if abs(yaw_rate) < YAW_RATE_EPSILON:
        # Straight-line approximation (no turning within this horizon).
        x = state.x + v * math.cos(yaw) * t
        y = state.y + v * math.sin(yaw) * t
        new_yaw = yaw
    else:
        new_yaw = yaw + yaw_rate * t
        x = state.x + (v / yaw_rate) * (math.sin(new_yaw) - math.sin(yaw))
        y = state.y + (v / yaw_rate) * (-math.cos(new_yaw) + math.cos(yaw))

    vx = v * math.cos(new_yaw)
    vy = v * math.sin(new_yaw)
    z = state.z + state.vz * t

    return MotionState(
        x=x, y=y, z=z,
        vx=vx, vy=vy, vz=state.vz,
        ax=0.0, ay=0.0, az=0.0,
        yaw=new_yaw, yaw_rate=yaw_rate,
        speed=v, heading=new_yaw,
        timestamp=state.timestamp + t,
    )


MODEL_FUNCTIONS = {
    "CV": constant_velocity,
    "CA": constant_acceleration,
    "CTRV": constant_turn_rate_and_velocity,
}


def predict(state: MotionState, dt: float, model: str) -> MotionState:
    """Dispatch helper: predict(state, dt, "CTRV") etc. Raises
    ValueError for an unknown model name rather than silently picking
    one — callers should always pass a value from ModelType."""
    fn = MODEL_FUNCTIONS.get(model)
    if fn is None:
        raise ValueError(f"Unknown motion model: {model!r}")
    return fn(state, dt)
