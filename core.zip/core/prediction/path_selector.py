"""
IndiDrive AI — Phase 4C | Fast / Deep Prediction Path Selection
=====================================================================
spec section 13: route each track through the cheap "fast path"
(normal, stable object) or a deeper path (unstable object, unusual
lateral motion, low confidence, sensor degradation, sudden
acceleration/braking, temporary track loss). Deliberately small and
deterministic -- no learned model, just rule-based routing on signals
already computed elsewhere in Phase 4C/4B.
"""
from __future__ import annotations

from dataclasses import dataclass
from enum import Enum

from .sensor_quality import SensorQuality

__all__ = ["PredictionPath", "PathDecisionInputs", "select_path"]


class PredictionPath(str, Enum):
    FAST = "FAST"
    DEEP = "DEEP"


@dataclass
class PathDecisionInputs:
    is_stable: bool = True                # Phase 4B's hypothesis-engine stability check
    sensor_quality: SensorQuality = SensorQuality.FULL_FUSION
    lost_this_cycle: bool = False          # coasting without a fresh measurement
    sudden_acceleration: bool = False
    sudden_braking: bool = False
    unpredictable_class: bool = False      # e.g. cattle/pedestrian behaviour prior


_DEEP_SENSOR_TIERS = (SensorQuality.SINGLE_SENSOR, SensorQuality.LOW_CONFIDENCE)


def select_path(inputs: PathDecisionInputs) -> PredictionPath:
    if not inputs.is_stable:
        return PredictionPath.DEEP
    if inputs.sensor_quality in _DEEP_SENSOR_TIERS:
        return PredictionPath.DEEP
    if inputs.lost_this_cycle:
        return PredictionPath.DEEP
    if inputs.sudden_acceleration or inputs.sudden_braking:
        return PredictionPath.DEEP
    if inputs.unpredictable_class:
        return PredictionPath.DEEP
    return PredictionPath.FAST
