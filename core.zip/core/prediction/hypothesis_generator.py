"""
IndiDrive AI — Phase 4B | Multi-Hypothesis Trajectory Generation
======================================================================
Turns one track's current motion state (+ recent history) into a
TrackHypothesisSet: either a single fast-path STRAIGHT hypothesis
(stable objects) or several scored, normalized hypotheses (unstable
objects).

Reuses Phase 4A's motion_models.predict() exclusively — no new
kinematics are introduced here. Every hypothesis's trajectory is
generated at the same `horizons_s` the caller (Phase 4A's
PredictionEngineConfig) is configured with.
"""
from __future__ import annotations

import math
from typing import Optional

from .prediction_types import MotionState, PredictedState, ModelType
from .motion_models import predict as predict_motion
from .hypothesis_types import BehaviourType, TrajectoryHypothesis, TrackHypothesisSet
from .hypothesis_scoring import (
    HypothesisConfig, is_stable, candidate_behaviours, score_behaviour,
    normalize_scores, project_longitudinal_lateral,
)

__all__ = ["HypothesisGenerator"]

# Deterministic base uncertainty (meters) per behaviour: turning /
# braking / accelerating hypotheses are inherently less certain than
# continuing straight at the current state. Fixed constants, not
# fabricated per-call randomness.
_BASE_SIGMA = {
    BehaviourType.STRAIGHT: 0.3,
    BehaviourType.LEFT: 0.6,
    BehaviourType.RIGHT: 0.6,
    BehaviourType.BRAKING: 0.4,
    BehaviourType.ACCELERATION: 0.45,
}
_SIGMA_GROWTH_PER_SECOND = 0.35


def _finite(*values) -> bool:
    return all(isinstance(v, (int, float)) and math.isfinite(v) for v in values)


def _unproject(heading: float, a_long: float, a_lat: float) -> tuple:
    if not _finite(heading, a_long, a_lat):
        return 0.0, 0.0
    c, s = math.cos(heading), math.sin(heading)
    ax = a_long * c - a_lat * s
    ay = a_long * s + a_lat * c
    return ax, ay


class HypothesisGenerator:
    """Stateless generator: every call is a pure function of its
    arguments (spec section 17, determinism)."""

    def __init__(self, config: HypothesisConfig = None):
        self.config = config or HypothesisConfig()

    # -- behaviour -> (model, adjusted MotionState) -------------------

    def _state_for_behaviour(
        self, behaviour: BehaviourType, current_state: MotionState,
        selected_model: ModelType,
    ) -> tuple:
        cfg = self.config
        heading = current_state.heading
        a_long, a_lat = project_longitudinal_lateral(heading, current_state.ax, current_state.ay)

        if behaviour == BehaviourType.STRAIGHT:
            # Continue exactly as Phase 4A's own model selection would.
            return selected_model, current_state

        if behaviour in (BehaviourType.LEFT, BehaviourType.RIGHT):
            sign = 1.0 if behaviour == BehaviourType.LEFT else -1.0
            measured = abs(current_state.yaw_rate)
            magnitude = measured if measured >= cfg.min_turn_rate else cfg.min_turn_rate
            adjusted = MotionState(
                x=current_state.x, y=current_state.y, z=current_state.z,
                vx=current_state.vx, vy=current_state.vy, vz=current_state.vz,
                ax=0.0, ay=0.0, az=current_state.az,
                yaw=current_state.yaw, yaw_rate=sign * magnitude,
                speed=current_state.speed, heading=current_state.heading,
                timestamp=current_state.timestamp,
            )
            return ModelType.CTRV, adjusted

        if behaviour == BehaviourType.BRAKING:
            measured = -a_long if a_long < 0.0 else 0.0
            magnitude = measured if measured > 1e-6 else cfg.default_brake_decel
            ax, ay = _unproject(heading, -magnitude, 0.0)
            adjusted = MotionState(
                x=current_state.x, y=current_state.y, z=current_state.z,
                vx=current_state.vx, vy=current_state.vy, vz=current_state.vz,
                ax=ax, ay=ay, az=current_state.az,
                yaw=current_state.yaw, yaw_rate=0.0,
                speed=current_state.speed, heading=current_state.heading,
                timestamp=current_state.timestamp,
            )
            return ModelType.CA, adjusted

        if behaviour == BehaviourType.ACCELERATION:
            measured = a_long if a_long > 0.0 else 0.0
            magnitude = measured if measured > 1e-6 else cfg.default_accel
            ax, ay = _unproject(heading, magnitude, 0.0)
            adjusted = MotionState(
                x=current_state.x, y=current_state.y, z=current_state.z,
                vx=current_state.vx, vy=current_state.vy, vz=current_state.vz,
                ax=ax, ay=ay, az=current_state.az,
                yaw=current_state.yaw, yaw_rate=0.0,
                speed=current_state.speed, heading=current_state.heading,
                timestamp=current_state.timestamp,
            )
            return ModelType.CA, adjusted

        return selected_model, current_state

    def _rollout(self, behaviour: BehaviourType, current_state: MotionState,
                 selected_model: ModelType, horizons_s: tuple) -> tuple:
        model, state = self._state_for_behaviour(behaviour, current_state, selected_model)
        trajectory = []
        for h in horizons_s:
            future = predict_motion(state, h, model.value)
            trajectory.append(PredictedState(
                timestamp=current_state.timestamp + h,
                x=future.x, y=future.y, z=future.z,
                vx=future.vx, vy=future.vy, vz=future.vz,
                yaw=future.yaw, speed=future.speed, horizon_s=h,
            ))
        return model, trajectory

    def _uncertainty(self, behaviour: BehaviourType, confidence: float, horizons_s: tuple) -> dict:
        confidence = confidence if _finite(confidence) else 0.0
        confidence = max(0.0, min(1.0, confidence))
        h_max = max(horizons_s) if horizons_s else 0.0
        base = _BASE_SIGMA.get(behaviour, 0.5) * (1.5 - confidence)
        sigma = base + _SIGMA_GROWTH_PER_SECOND * h_max * (1.5 - confidence)
        sigma = max(0.0, sigma)
        return {"sigma_x": sigma, "sigma_y": sigma, "sigma_vx": sigma * 0.5, "sigma_vy": sigma * 0.5}

    # -- public entry point --------------------------------------------

    def generate(
        self, *, track_id: str, object_type: str, current_state: MotionState,
        selected_model: ModelType, horizons_s: tuple,
        history_yaw_rates: Optional[list] = None, confidence: float = 1.0,
    ) -> TrackHypothesisSet:
        """Build the TrackHypothesisSet for one track this cycle."""
        cfg = self.config
        history_yaw_rates = history_yaw_rates or []

        if not current_state.is_valid():
            return TrackHypothesisSet(track_id=track_id, object_type=object_type, is_stable=True, hypotheses=[])

        stable = is_stable(
            current_state.yaw_rate, current_state.ax, current_state.ay,
            current_state.heading, cfg, vx=current_state.vx, vy=current_state.vy,
        )

        if stable:
            # -- fast path: single best (STRAIGHT) trajectory ---------
            model, trajectory = self._rollout(BehaviourType.STRAIGHT, current_state, selected_model, horizons_s)
            hyp = TrajectoryHypothesis(
                track_id=track_id, model=model, behaviour=BehaviourType.STRAIGHT,
                probability=1.0, confidence=max(0.0, min(1.0, confidence)),
                trajectory=trajectory,
                uncertainty=self._uncertainty(BehaviourType.STRAIGHT, confidence, horizons_s),
            )
            return TrackHypothesisSet(track_id=track_id, object_type=object_type, is_stable=True, hypotheses=[hyp])

        # -- uncertain path: multiple hypotheses, scored & normalized --
        behaviours = candidate_behaviours(
            current_state.yaw_rate, current_state.ax, current_state.ay,
            current_state.heading, current_state.vx, current_state.vy, cfg,
        )
        raw_scores = {
            b: score_behaviour(
                b, yaw_rate=current_state.yaw_rate, ax=current_state.ax, ay=current_state.ay,
                heading=current_state.heading, vx=current_state.vx, vy=current_state.vy,
                object_type=object_type, history_yaw_rates=history_yaw_rates, config=cfg,
            )
            for b in behaviours
        }
        probabilities = normalize_scores(raw_scores)

        # Prune negligible hypotheses (never prune below one).
        kept = {b: p for b, p in probabilities.items() if p >= cfg.min_probability}
        if not kept:
            kept = probabilities
        if BehaviourType.STRAIGHT not in kept and probabilities:
            # Always keep STRAIGHT as the fallback baseline.
            kept[BehaviourType.STRAIGHT] = probabilities.get(BehaviourType.STRAIGHT, 0.0)
        # Cap the number of hypotheses deterministically (highest probability first).
        ordered = sorted(kept.items(), key=lambda kv: (-kv[1], kv[0].value))[: cfg.max_hypotheses]
        kept = dict(ordered)
        final_probabilities = normalize_scores({b: p for b, p in kept.items()})

        hypotheses = []
        for behaviour, probability in sorted(final_probabilities.items(), key=lambda kv: (-kv[1], kv[0].value)):
            model, trajectory = self._rollout(behaviour, current_state, selected_model, horizons_s)
            hyp_confidence = max(0.0, min(1.0, confidence * (0.5 + 0.5 * probability)))
            hypotheses.append(TrajectoryHypothesis(
                track_id=track_id, model=model, behaviour=behaviour,
                probability=probability, confidence=hyp_confidence,
                trajectory=trajectory,
                uncertainty=self._uncertainty(behaviour, confidence, horizons_s),
            ))

        return TrackHypothesisSet(track_id=track_id, object_type=object_type, is_stable=False, hypotheses=hypotheses)
