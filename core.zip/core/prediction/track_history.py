"""
IndiDrive AI — Phase 4A | Track History
============================================
Bounded per-track buffer of recent motion samples. Every tracked
object's last N cycles are kept (never unlimited growth — spec
section 5) so:

    - model_selector.py can look at recent yaw/speed stability
    - acceleration and yaw_rate (not directly present on a Phase 3
      FusedObject) can be estimated from consecutive samples

Keyed by Phase 3's own `track_id` (core/fusion/track_fusion.py) —
Phase 4A does not mint a second, competing ID space.
"""
from __future__ import annotations

import math
from collections import deque
from dataclasses import dataclass
from typing import Optional

DEFAULT_MAX_HISTORY = 20


@dataclass
class TrackHistoryEntry:
    timestamp: float
    x: float
    y: float
    z: float
    vx: float
    vy: float
    vz: float
    ax: float
    ay: float
    az: float
    heading: float
    yaw_rate: float
    confidence: float

    def to_dict(self) -> dict:
        return {
            "timestamp": self.timestamp,
            "position": {"x": self.x, "y": self.y, "z": self.z},
            "velocity": {"vx": self.vx, "vy": self.vy, "vz": self.vz},
            "acceleration": {"ax": self.ax, "ay": self.ay, "az": self.az},
            "heading": self.heading,
            "yaw_rate": self.yaw_rate,
            "confidence": self.confidence,
        }


def _finite(*values: float) -> bool:
    return all(isinstance(v, (int, float)) and math.isfinite(v) for v in values)


def _angle_diff(a: float, b: float) -> float:
    """Shortest signed difference a-b, wrapped to [-pi, pi]."""
    d = a - b
    return (d + math.pi) % (2 * math.pi) - math.pi


class TrackHistoryManager:
    """Owns one bounded deque[TrackHistoryEntry] per track_id."""

    def __init__(self, max_history: int = DEFAULT_MAX_HISTORY):
        self.max_history = max(1, max_history)
        self._tracks: dict[str, deque] = {}

    def add_measurement(
        self, track_id: str, *, timestamp: float, x: float, y: float, z: float,
        vx: float, vy: float, vz: float, heading: float, confidence: float,
    ) -> TrackHistoryEntry:
        """Append a raw measurement, deriving acceleration and yaw_rate
        from the previous entry (finite-difference). Missing/absent
        previous history yields 0.0 acceleration/yaw_rate rather than
        a fabricated guess."""
        buf = self._tracks.setdefault(track_id, deque(maxlen=self.max_history))
        prev = buf[-1] if buf else None

        ax = ay = az = 0.0
        yaw_rate = 0.0
        if prev is not None:
            dt = timestamp - prev.timestamp
            if _finite(dt) and dt > 0.0:
                if _finite(vx, prev.vx):
                    ax = (vx - prev.vx) / dt
                if _finite(vy, prev.vy):
                    ay = (vy - prev.vy) / dt
                if _finite(vz, prev.vz):
                    az = (vz - prev.vz) / dt
                if _finite(heading, prev.heading):
                    yaw_rate = _angle_diff(heading, prev.heading) / dt

        entry = TrackHistoryEntry(
            timestamp=timestamp, x=x, y=y, z=z,
            vx=vx, vy=vy, vz=vz,
            ax=ax if _finite(ax) else 0.0,
            ay=ay if _finite(ay) else 0.0,
            az=az if _finite(az) else 0.0,
            heading=heading, yaw_rate=yaw_rate if _finite(yaw_rate) else 0.0,
            confidence=confidence,
        )
        buf.append(entry)
        return entry

    def get_history(self, track_id: str) -> list:
        buf = self._tracks.get(track_id)
        return list(buf) if buf else []

    def get_latest(self, track_id: str) -> Optional[TrackHistoryEntry]:
        buf = self._tracks.get(track_id)
        return buf[-1] if buf else None

    def has_track(self, track_id: str) -> bool:
        return track_id in self._tracks

    def remove_track(self, track_id: str) -> None:
        self._tracks.pop(track_id, None)

    def active_track_ids(self) -> list:
        return list(self._tracks.keys())

    def reset(self) -> None:
        self._tracks.clear()
