"""
IndiDrive AI — Phase 4B | Multi-Hypothesis Prediction Engine
==================================================================
Purely additive on top of Phase 4A: consumes a `PredictedWorldState`
(Phase 4A's own output — nothing here re-implements track history,
Kalman filtering or model selection) and produces one
TrackHypothesisSet per predicted object.

Phase 4A's `prediction_engine.py` is never modified or re-run here —
this engine only reads its output plus (optionally) the same
TrackHistoryManager instance for historical yaw_rate context.
"""
from __future__ import annotations

from dataclasses import dataclass, field

from .prediction_types import PredictedWorldState
from .track_history import TrackHistoryManager
from .hypothesis_types import TrackHypothesisSet
from .hypothesis_generator import HypothesisGenerator
from .hypothesis_scoring import HypothesisConfig

__all__ = ["HypothesisEngine", "HypothesisWorldResult"]


@dataclass
class HypothesisWorldResult:
    """Mirrors PredictedWorldState's shape for one Phase 4B cycle."""
    timestamp: float
    frame_id: int
    tracks: dict = field(default_factory=dict)  # track_id -> TrackHypothesisSet
    warnings: list = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "timestamp": self.timestamp,
            "frame_id": self.frame_id,
            "tracks": {tid: hs.to_dict() for tid, hs in self.tracks.items()},
            "warnings": self.warnings,
        }


class HypothesisEngine:
    def __init__(self, config: HypothesisConfig = None):
        self.config = config or HypothesisConfig()
        self._generator = HypothesisGenerator(config=self.config)

    def process(
        self, predicted_world_state: PredictedWorldState,
        history: TrackHistoryManager = None,
    ) -> HypothesisWorldResult:
        warnings: list = []
        tracks: dict = {}

        horizons_s = tuple(
            sorted({p.horizon_s for obj in predicted_world_state.objects for p in obj.trajectory})
        ) or ()

        for obj in predicted_world_state.objects:
            obj_horizons = tuple(p.horizon_s for p in obj.trajectory) or horizons_s
            history_yaw_rates = []
            if history is not None:
                history_yaw_rates = [e.yaw_rate for e in history.get_history(obj.track_id)]

            try:
                hyp_set = self._generator.generate(
                    track_id=obj.track_id, object_type=obj.object_type,
                    current_state=obj.current_state, selected_model=obj.selected_model,
                    horizons_s=obj_horizons, history_yaw_rates=history_yaw_rates,
                    confidence=obj.prediction_confidence,
                )
            except Exception as exc:  # never crash the pipeline over one track
                warnings.append(f"skipped track {obj.track_id}: {exc}")
                continue

            tracks[obj.track_id] = hyp_set

        return HypothesisWorldResult(
            timestamp=predicted_world_state.timestamp,
            frame_id=predicted_world_state.frame_id,
            tracks=tracks, warnings=warnings,
        )
