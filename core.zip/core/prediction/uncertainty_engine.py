"""
IndiDrive AI — Phase 4C | Uncertainty Engine
=================================================
Extends Phase 4B's per-hypothesis uncertainty (hypothesis_generator's
_uncertainty()) with the full factor set spec section 8 requires:

    * prediction horizon            -- grows monotonically with time
    * object class                  -- via object_behaviour.py priors
    * velocity stability            -- from recent track history
    * acceleration stability        -- from recent track history
    * heading stability             -- from recent track history
    * sensor confidence             -- via sensor_quality.py
    * track age                     -- younger tracks are less certain
    * lost measurement duration     -- coasting inflates uncertainty
    * hypothesis uncertainty        -- Phase 4B's own sigma, folded in
                                        as a base rather than replaced

Every multiplier is a fixed, documented constant (spec: "do not use
fake statistical values") applied to a real base sigma derived from
the Kalman/hypothesis covariance already computed upstream — this
module never invents a sigma out of nothing when a real one is
available, and only supplies a small deterministic floor when it
isn't (e.g. brand-new track, no covariance yet).
"""
from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Optional

from .object_behaviour import get_profile
from .sensor_quality import SensorQuality, uncertainty_multiplier, confidence_multiplier

__all__ = [
    "UncertaintyFactors", "UncertaintyResult", "compute_uncertainty",
    "stability_factor",
]

# Sigma (meters) used when no upstream covariance/base sigma is
# available at all -- a small deterministic floor, not a guess at the
# object's actual spread.
BASE_SIGMA_FLOOR = 0.15

# Growth applied per second of prediction horizon (spec section 9:
# 0.25s < 1s < 3s < 5s must be strictly increasing).
HORIZON_GROWTH_PER_SECOND = 0.35

# Track-age ramp: brand-new tracks (age 1) are penalized; the penalty
# fades out by CONFIRM_AGE cycles.
CONFIRM_AGE_CYCLES = 5
NEW_TRACK_PENALTY = 0.5

# Lost-measurement growth per second without a real update.
LOST_GROWTH_PER_SECOND = 0.6


def _finite(v) -> bool:
    return isinstance(v, (int, float)) and math.isfinite(v)


def _clamp01(v: float) -> float:
    return max(0.0, min(1.0, v))


@dataclass
class UncertaintyFactors:
    """All inputs the engine can use. Every field is optional except
    horizon_s/object_type -- Phase 4C never crashes just because one
    upstream signal (e.g. sensor quality) wasn't wired through yet."""
    horizon_s: float
    object_type: str = ""
    base_sigma: Optional[float] = None          # real upstream sigma (Kalman/hypothesis), meters
    velocity_std: Optional[float] = None         # m/s, recent history
    acceleration_std: Optional[float] = None     # m/s^2, recent history
    heading_std: Optional[float] = None          # rad, recent history
    sensor_quality: Optional[SensorQuality] = None
    track_age_cycles: int = 0
    lost_duration_s: float = 0.0
    base_confidence: float = 1.0


@dataclass
class UncertaintyResult:
    sigma_x: float
    sigma_y: float
    sigma_vx: float
    sigma_vy: float
    confidence: float
    lateral_factor: float
    time_factor: float

    def to_dict(self) -> dict:
        return {
            "sigma_x": self.sigma_x, "sigma_y": self.sigma_y,
            "sigma_vx": self.sigma_vx, "sigma_vy": self.sigma_vy,
            "confidence": round(self.confidence, 6),
        }


def stability_factor(velocity_std: Optional[float], acceleration_std: Optional[float],
                      heading_std: Optional[float]) -> float:
    """>=1.0. A perfectly steady track (all stds ~0 or unknown) scores
    1.0; the more the recent history wobbles, the higher this grows.
    Deterministic linear combination -- no fitted/sampled coefficients."""
    v = velocity_std if _finite(velocity_std) and velocity_std >= 0 else 0.0
    a = acceleration_std if _finite(acceleration_std) and acceleration_std >= 0 else 0.0
    h = heading_std if _finite(heading_std) and heading_std >= 0 else 0.0
    return 1.0 + 0.25 * v + 0.4 * a + 0.6 * h


def _track_age_factor(track_age_cycles: int) -> float:
    age = track_age_cycles if isinstance(track_age_cycles, int) and track_age_cycles > 0 else 0
    if age >= CONFIRM_AGE_CYCLES:
        return 1.0
    remaining = (CONFIRM_AGE_CYCLES - age) / CONFIRM_AGE_CYCLES
    return 1.0 + NEW_TRACK_PENALTY * remaining


def _lost_factor(lost_duration_s: float) -> float:
    d = lost_duration_s if _finite(lost_duration_s) and lost_duration_s > 0 else 0.0
    return 1.0 + LOST_GROWTH_PER_SECOND * d


def compute_uncertainty(factors: UncertaintyFactors) -> UncertaintyResult:
    horizon_s = factors.horizon_s if _finite(factors.horizon_s) and factors.horizon_s >= 0 else 0.0

    base_sigma = factors.base_sigma if _finite(factors.base_sigma) and factors.base_sigma > 0 else BASE_SIGMA_FLOOR

    profile = get_profile(factors.object_type)
    lateral_factor = profile.lateral_uncertainty_factor * (0.5 + 0.5 * profile.unpredictability)
    longitudinal_factor = profile.longitudinal_uncertainty_factor

    time_factor = 1.0 + HORIZON_GROWTH_PER_SECOND * horizon_s

    stab_factor = stability_factor(factors.velocity_std, factors.acceleration_std, factors.heading_std)

    sq = factors.sensor_quality
    sensor_factor = uncertainty_multiplier(sq) if sq is not None else 1.0

    age_factor = _track_age_factor(factors.track_age_cycles)
    lost_factor = _lost_factor(factors.lost_duration_s)

    common = time_factor * stab_factor * sensor_factor * age_factor * lost_factor

    sigma_x = base_sigma * lateral_factor * common
    sigma_y = base_sigma * longitudinal_factor * common
    sigma_vx = sigma_x * 0.5
    sigma_vy = sigma_y * 0.5

    base_conf = factors.base_confidence if _finite(factors.base_confidence) else 1.0
    base_conf = _clamp01(base_conf)
    conf_sensor = confidence_multiplier(sq) if sq is not None else 1.0
    confidence = base_conf * conf_sensor / common
    confidence = _clamp01(confidence)

    return UncertaintyResult(
        sigma_x=sigma_x, sigma_y=sigma_y, sigma_vx=sigma_vx, sigma_vy=sigma_vy,
        confidence=confidence, lateral_factor=lateral_factor, time_factor=time_factor,
    )
