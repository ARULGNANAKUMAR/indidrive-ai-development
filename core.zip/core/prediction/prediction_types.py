"""
IndiDrive AI — Phase 4A | Motion Prediction Data Contracts
==============================================================
Strongly-typed containers for everything that flows into and out of
the prediction layer. Mirrors the design philosophy of Phase 2's
core/perception/perception_types.py and Phase 3's
core/fusion/fusion_types.py: dataclasses (not raw dicts), explicit
"unavailable" states instead of fabricated values, and a single
stable output shape (`PredictedWorldState`) that a future Phase 4B
(path planning / collision avoidance) can depend on.

Nothing in this file performs prediction logic — these are structural
containers plus small helpers. Reuses Phase 2/3 primitives (HealthState,
NOT_AVAILABLE, Position3D) rather than redefining them.
"""
from __future__ import annotations

import math
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Optional

from core.perception.perception_types import NOT_AVAILABLE, HealthState

__all__ = [
    "NOT_AVAILABLE",
    "ModelType", "TrackLifecycleState",
    "MotionState", "PredictedState", "PredictedObject",
    "PredictionMetrics", "PredictedWorldState",
]


class ModelType(str, Enum):
    """Which motion model produced a given trajectory. Selection is
    always deterministic — see model_selector.py."""
    CV = "CV"      # constant velocity
    CA = "CA"      # constant acceleration
    CTRV = "CTRV"  # constant turn-rate and velocity
    NOT_AVAILABLE = "NOT_AVAILABLE"


class TrackLifecycleState(str, Enum):
    """Independent from Phase 3's ObjectLifecycleState (which tracks
    per-cycle fusion confirmation). This tracks whether Phase 4A still
    has a usable motion history/filter for a given track_id."""
    NEW = "NEW"
    ACTIVE = "ACTIVE"
    TEMPORARILY_LOST = "TEMPORARILY_LOST"
    STALE = "STALE"
    DELETED = "DELETED"


@dataclass
class MotionState:
    """Unified kinematic state used everywhere in Phase 4A — the motion
    models, the Kalman filter, and track history all speak this shape.
    Coordinates/units match Phase 3's FusedObject.position_3d /
    velocity (vehicle frame, meters, meters/second) and heading
    (radians). Never silently reinterpreted into a different frame.
    """
    x: float
    y: float
    z: float
    vx: float
    vy: float
    vz: float
    ax: float
    ay: float
    az: float
    yaw: float
    yaw_rate: float
    speed: float
    heading: float
    timestamp: float

    @staticmethod
    def is_finite(*values: float) -> bool:
        return all(isinstance(v, (int, float)) and math.isfinite(v) for v in values)

    def is_valid(self) -> bool:
        return self.is_finite(
            self.x, self.y, self.z, self.vx, self.vy, self.vz,
            self.ax, self.ay, self.az, self.yaw, self.yaw_rate,
            self.speed, self.heading, self.timestamp,
        )

    def to_dict(self) -> dict:
        return {
            "x": self.x, "y": self.y, "z": self.z,
            "vx": self.vx, "vy": self.vy, "vz": self.vz,
            "ax": self.ax, "ay": self.ay, "az": self.az,
            "yaw": self.yaw, "yaw_rate": self.yaw_rate,
            "speed": self.speed, "heading": self.heading,
            "timestamp": self.timestamp,
        }


@dataclass
class PredictedState:
    """One point on a predicted trajectory (one horizon)."""
    timestamp: float
    x: float
    y: float
    z: float
    vx: float
    vy: float
    vz: float
    yaw: float
    speed: float
    horizon_s: float = 0.0
    covariance: Optional[list] = None  # 4x4 [x,y,vx,vy] covariance, row-major, or None

    def to_dict(self) -> dict:
        return {
            "timestamp": self.timestamp,
            "horizon_s": self.horizon_s,
            "x": self.x, "y": self.y, "z": self.z,
            "vx": self.vx, "vy": self.vy, "vz": self.vz,
            "yaw": self.yaw, "speed": self.speed,
            "covariance": self.covariance if self.covariance is not None else NOT_AVAILABLE,
        }


@dataclass
class PredictedObject:
    """A single tracked object's prediction output for one cycle."""
    track_id: str
    object_type: str
    current_state: MotionState
    trajectory: list = field(default_factory=list)          # list[PredictedState], one per horizon
    prediction_confidence: float = 0.0
    uncertainty: dict = field(default_factory=dict)          # {"sigma_x":..,"sigma_y":..,"sigma_vx":..,"sigma_vy":..} at final horizon
    selected_model: ModelType = ModelType.NOT_AVAILABLE
    lifecycle_state: TrackLifecycleState = TrackLifecycleState.NEW
    warnings: list = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "track_id": self.track_id,
            "object_type": self.object_type,
            "current_state": self.current_state.to_dict(),
            "trajectory": [p.to_dict() for p in self.trajectory],
            "prediction_confidence": round(self.prediction_confidence, 3),
            "uncertainty": self.uncertainty if self.uncertainty else NOT_AVAILABLE,
            "selected_model": self.selected_model.value,
            "lifecycle_state": self.lifecycle_state.value,
            "warnings": self.warnings,
        }


@dataclass
class PredictionMetrics:
    """Every latency here is measured with time.perf_counter() at the
    point of use — never a placeholder or hard-coded value."""
    track_update_latency_ms: float = 0.0
    kalman_latency_ms: float = 0.0
    model_selection_latency_ms: float = 0.0
    trajectory_generation_latency_ms: float = 0.0
    prediction_latency_ms: float = 0.0
    objects_per_second: float = 0.0
    prediction_fps: float = 0.0

    def to_dict(self) -> dict:
        return {
            "track_update_latency_ms": round(self.track_update_latency_ms, 3),
            "kalman_latency_ms": round(self.kalman_latency_ms, 3),
            "model_selection_latency_ms": round(self.model_selection_latency_ms, 3),
            "trajectory_generation_latency_ms": round(self.trajectory_generation_latency_ms, 3),
            "prediction_latency_ms": round(self.prediction_latency_ms, 3),
            "objects_per_second": round(self.objects_per_second, 2),
            "prediction_fps": round(self.prediction_fps, 2),
        }


@dataclass
class PredictedWorldState:
    """The primary interface a future Phase 4B (path planning /
    collision avoidance) will depend on. One PredictedWorldState is
    produced per PredictionManager processing cycle, from exactly one
    Phase 3 FusedWorldState."""
    timestamp: float
    frame_id: int
    objects: list = field(default_factory=list)               # list[PredictedObject]
    prediction_health: HealthState = HealthState.NOT_CONFIGURED
    warnings: list = field(default_factory=list)
    metrics: PredictionMetrics = field(default_factory=PredictionMetrics)
    created_at: float = field(default_factory=time.time)

    def to_dict(self) -> dict:
        return {
            "timestamp": self.timestamp,
            "frame_id": self.frame_id,
            "objects": [o.to_dict() for o in self.objects],
            "prediction_health": self.prediction_health.value,
            "warnings": self.warnings,
            "metrics": self.metrics.to_dict(),
        }
