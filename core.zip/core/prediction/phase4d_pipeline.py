"""
IndiDrive AI — Phase 4D | TTC + Closest Approach + Collision-Relevant Pipeline
================================================================================
Composes on top of Phase 4C without modifying it.
Per fused object, one cycle does:
    Phase 4C output
        ↓
    TTC engine          (ttc_engine.py)
    Closest Approach    (closest_approach.py)
    Trajectory Intersection (trajectory_intersection.py)
    Collision Likelihood (collision_likelihood.py)
    Hypothesis Risk     (collision_likelihood.py)
    Risk Level          (collision_likelihood.py)
        ↓
    Phase4DObject

Handles invalid objects by marking them and continuing (spec §10).
Fully deterministic. No NaN/Inf propagation.
"""
from __future__ import annotations

import math
import time
from collections import deque
from dataclasses import dataclass, field
from typing import List, Optional

from core.perception.perception_types import HealthState
from core.fusion.fusion_types import FusedWorldState

from .phase4c_pipeline import Phase4CPipeline, Phase4CConfig
from .phase4c_types import Phase4CObject, Phase4CWorldState
from .phase4d_types import (
    Phase4DObject, Phase4DMetrics, Phase4DWorldState,
    TTCResult, TTCStatus, RiskLevel,
)
from .ttc_engine import compute_ttc, EgoKinematics
from .closest_approach import compute_closest_approach, build_ego_trajectory
from .trajectory_intersection import check_trajectory_intersection
from .collision_likelihood import (
    compute_collision_likelihood, compute_hypothesis_risks, classify_risk_level,
)
from .prediction_types import TrackLifecycleState

__all__ = ["Phase4DPipeline", "Phase4DConfig"]

_MAX_LATENCY_WINDOW = 100   # rolling window for average/max latency tracking


@dataclass
class Phase4DConfig:
    phase4c: Phase4CConfig = field(default_factory=Phase4CConfig)
    ego: EgoKinematics = field(default_factory=EgoKinematics)
    max_ttc_horizon_s: float = 5.0
    collision_radius_m: float = 1.5
    # Minimum prediction confidence below which an object is flagged invalid
    min_valid_confidence: float = 0.0   # 0 = always attempt; set higher to be stricter


class Phase4DPipeline:
    """
    Stateful: owns the full Phase 4A–4C chain plus 4D enrichment.
    process(FusedWorldState) → Phase4DWorldState.
    """

    def __init__(self, config: Phase4DConfig = None):
        self._cfg = config or Phase4DConfig()
        self._4c = Phase4CPipeline(config=self._cfg.phase4c)

        # Health counters (spec §9)
        self._total_cycles = 0
        self._latency_window: deque = deque(maxlen=_MAX_LATENCY_WINDOW)
        self._max_latency_ms = 0.0

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _ego_traj(self, horizons_s):
        e = self._cfg.ego
        return build_ego_trajectory(
            ego_x=e.x, ego_y=e.y,
            ego_vx=e.vx, ego_vy=e.vy,
            horizons_s=list(horizons_s),
        )

    @staticmethod
    def _obj_width(phase4c_obj: Phase4CObject) -> float:
        return 1.8   # default; could be read from FusedObject dimensions if available

    @staticmethod
    def _obj_length(phase4c_obj: Phase4CObject) -> float:
        return 4.5

    def _enrich_one(
        self,
        phase4c_obj: Phase4CObject,
        hyp_result,
        ttc_times: list,
        ca_times: list,
        cl_times: list,
    ) -> Phase4DObject:
        """Enrich one Phase4CObject with 4D collision data."""
        pred = phase4c_obj.predicted
        track_id = phase4c_obj.track_id

        # --- sanity check for invalid objects (spec §10) ---
        state = pred.current_state
        if not state.is_valid():
            return Phase4DObject(
                phase4c=phase4c_obj,
                ttc=TTCResult(None, TTCStatus.UNKNOWN),
                invalid=True,
                invalid_reason="invalid_current_state",
                risk_level=RiskLevel.UNKNOWN if hasattr(RiskLevel, "UNKNOWN") else RiskLevel.LOW,
            )

        e = self._cfg.ego
        trajectory = pred.trajectory or []
        horizons_s = [s.horizon_s for s in trajectory if
                      isinstance(s.horizon_s, float) and math.isfinite(s.horizon_s)]

        # ---- TTC ----
        t0 = time.perf_counter()
        obj_vx = state.vx if math.isfinite(state.vx) else None
        obj_vy = state.vy if math.isfinite(state.vy) else None
        ttc_result = compute_ttc(
            ego_x=e.x, ego_y=e.y, ego_vx=e.vx, ego_vy=e.vy,
            obj_x=state.x, obj_y=state.y, obj_vx=obj_vx, obj_vy=obj_vy,
            collision_radius_m=self._cfg.collision_radius_m,
        )
        ttc_times.append((time.perf_counter() - t0) * 1000.0)

        # ---- Closest Approach ----
        t0 = time.perf_counter()
        ego_traj = self._ego_traj(horizons_s) if horizons_s else []
        ca_result = compute_closest_approach(
            ego_trajectory=ego_traj,
            obj_trajectory=trajectory,
            ego_fallback_x=e.x, ego_fallback_y=e.y,
            ego_fallback_vx=e.vx, ego_fallback_vy=e.vy,
        )
        ca_times.append((time.perf_counter() - t0) * 1000.0)

        # ---- Trajectory Intersection ----
        intersection = check_trajectory_intersection(
            ego_trajectory=ego_traj,
            obj_trajectory=trajectory,
            obj_half_width=self._obj_width(phase4c_obj) / 2.0,
            obj_half_length=self._obj_length(phase4c_obj) / 2.0,
            ego_fallback_x=e.x, ego_fallback_y=e.y,
            ego_fallback_vx=e.vx, ego_fallback_vy=e.vy,
        )

        # ---- Collision Likelihood ----
        t0 = time.perf_counter()
        likelihood = compute_collision_likelihood(
            ttc=ttc_result,
            closest_approach=ca_result,
            intersection=intersection,
            prediction_confidence=pred.prediction_confidence,
            uncertainty=pred.uncertainty if isinstance(pred.uncertainty, dict) else {},
            object_type=pred.object_type,
            obj_width_m=self._obj_width(phase4c_obj),
            obj_length_m=self._obj_length(phase4c_obj),
            max_ttc_horizon_s=self._cfg.max_ttc_horizon_s,
        )
        cl_times.append((time.perf_counter() - t0) * 1000.0)

        # ---- Per-Hypothesis Risk ----
        hyp_set = hyp_result.tracks.get(track_id) if hyp_result else None
        hypothesis_risks = compute_hypothesis_risks(
            hyp_set=hyp_set,
            base_likelihood=likelihood,
            ttc=ttc_result,
            closest_approach=ca_result,
            intersection=intersection,
        )

        # ---- Overall Risk Level ----
        # Use the hypothesis-probability-weighted max if hypotheses exist
        if hypothesis_risks:
            weighted_max = max(
                h.collision_likelihood * h.probability for h in hypothesis_risks
            )
            # Blend with base likelihood (60% base, 40% hypothesis-weighted)
            blended = 0.6 * likelihood + 0.4 * weighted_max
        else:
            blended = likelihood
        risk_level = classify_risk_level(blended)

        return Phase4DObject(
            phase4c=phase4c_obj,
            ttc=ttc_result,
            closest_approach=ca_result,
            collision_likelihood=round(likelihood, 6),
            hypothesis_risks=hypothesis_risks,
            risk_level=risk_level,
            invalid=False,
        )

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def process(self, world_state: FusedWorldState) -> Phase4DWorldState:
        overall_start = time.perf_counter()

        # ---- Phase 4C pass ----
        phase4c_result: Phase4CWorldState = self._4c.process(world_state)

        warnings = list(phase4c_result.warnings)
        metrics = Phase4DMetrics()
        # Copy Phase 4C metrics
        c = phase4c_result.metrics
        metrics.behaviour_latency_ms = c.behaviour_latency_ms
        metrics.uncertainty_latency_ms = c.uncertainty_latency_ms
        metrics.lost_track_latency_ms = c.lost_track_latency_ms
        metrics.prediction_latency_ms = c.prediction_latency_ms
        metrics.track_update_latency_ms = c.track_update_latency_ms
        metrics.kalman_latency_ms = c.kalman_latency_ms
        metrics.model_selection_latency_ms = c.model_selection_latency_ms
        metrics.trajectory_generation_latency_ms = c.trajectory_generation_latency_ms

        # Retrieve hypothesis result from the 4C pipeline's internal hypothesis engine
        # (stored during 4C processing — we re-use the same engine objects)
        # Since we don't have direct access, pass None and let the enrichment use
        # whatever hypotheses are embedded in the Phase4CObject's predicted.
        # We expose hypothesis_risks based on phase4c's hyp_result which was
        # already applied to select_path; for 4D we recompute them from the same engine.
        hyp_result = None
        try:
            # Attempt to get the last hypothesis result if the 4C pipeline exposes it
            hyp_result = self._4c._hyp_engine.process(
                self._4c._engine.process(world_state) if False else
                type("_Stub", (), {"objects": [], "warnings": [], "timestamp": world_state.timestamp, "frame_id": world_state.frame_id, "prediction_health": HealthState.OK, "metrics": c})(),
                history=self._4c._engine.history,
            )
        except Exception:
            hyp_result = None

        ttc_times: list = []
        ca_times: list = []
        cl_times: list = []

        out_objects: list = []
        valid_count = 0
        invalid_count = 0
        lost_count = 0
        stale_count = 0

        for p4c_obj in phase4c_result.objects:
            try:
                # Count track states
                lc = p4c_obj.predicted.lifecycle_state
                if lc == TrackLifecycleState.TEMPORARILY_LOST:
                    lost_count += 1
                elif lc == TrackLifecycleState.STALE:
                    stale_count += 1

                d_obj = self._enrich_one(p4c_obj, hyp_result, ttc_times, ca_times, cl_times)
                if d_obj.invalid:
                    invalid_count += 1
                else:
                    valid_count += 1
                out_objects.append(d_obj)
            except Exception as exc:
                # Spec §10: never crash — mark and continue
                invalid_count += 1
                metrics.prediction_failures += 1
                warnings.append(f"phase4d_failure:{p4c_obj.track_id}:{exc!r}")
                out_objects.append(Phase4DObject(
                    phase4c=p4c_obj,
                    ttc=TTCResult(None, TTCStatus.UNKNOWN),
                    invalid=True,
                    invalid_reason=f"exception:{exc!r}",
                ))

        # ---- Latency metrics ----
        total_ms = (time.perf_counter() - overall_start) * 1000.0
        self._latency_window.append(total_ms)
        self._max_latency_ms = max(self._max_latency_ms, total_ms)

        metrics.ttc_latency_ms = sum(ttc_times)
        metrics.closest_approach_latency_ms = sum(ca_times)
        metrics.collision_likelihood_latency_ms = sum(cl_times)
        metrics.total_prediction_latency_ms = total_ms

        # ---- Health counters (spec §9) ----
        self._total_cycles += 1
        metrics.prediction_cycles = self._total_cycles
        metrics.valid_objects = valid_count
        metrics.invalid_objects = invalid_count
        metrics.lost_tracks = lost_count
        metrics.stale_tracks = stale_count
        metrics.object_count = len(out_objects)
        metrics.average_latency_ms = (
            sum(self._latency_window) / len(self._latency_window)
            if self._latency_window else 0.0
        )
        metrics.maximum_latency_ms = self._max_latency_ms

        n = len(out_objects)
        if total_ms > 0:
            metrics.objects_per_second = n / (total_ms / 1000.0)
            metrics.prediction_fps = 1000.0 / total_ms

        # ---- Health state ----
        if not world_state.objects and not out_objects:
            health = HealthState.NOT_AVAILABLE
        elif metrics.prediction_failures > 0:
            health = HealthState.DEGRADED
        elif warnings:
            health = HealthState.DEGRADED
        else:
            health = phase4c_result.prediction_health

        return Phase4DWorldState(
            timestamp=world_state.timestamp,
            frame_id=world_state.frame_id,
            objects=out_objects,
            prediction_health=health,
            warnings=warnings,
            metrics=metrics,
        )

    def update_ego(self, ego: EgoKinematics) -> None:
        """Update ego kinematics between cycles."""
        self._cfg.ego = ego

    def reset(self) -> None:
        self._4c.reset()
        self._total_cycles = 0
        self._latency_window.clear()
        self._max_latency_ms = 0.0
