"""
IndiDrive AI — Phase 4C | Lost-Track Coasting & Reassociation
===================================================================
spec section 11/12: when a track's measurement disappears for a
cycle or two, keep predicting from its last known motion state
("coasting") instead of dropping it immediately, growing uncertainty
as the gap without a real measurement grows. Reassociation itself is
handled structurally by Phase 4A's TrackLifecycleManager /
TrackHistoryManager / per-track KalmanFilter, which are all keyed by
`track_id` and persist through TEMPORARILY_LOST / STALE -- as soon as
a measurement with the same track_id reappears, Phase 4A naturally
continues the existing track (see prediction_engine.py's
`_get_filter` / `_history.add_measurement`, both dict-keyed lookups
that create-or-reuse). This module only supplies the *coasted*
predictions to fill the gap while a track has no fresh measurement.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Optional

from .prediction_types import (
    MotionState, PredictedState, PredictedObject, ModelType, TrackLifecycleState,
)
from .motion_models import predict as predict_motion
from .object_behaviour import clamp_yaw_rate_for_class
from .uncertainty_engine import UncertaintyFactors, compute_uncertainty
from .sensor_quality import SensorQuality

__all__ = ["coast_track"]


def _finite(*values) -> bool:
    return all(isinstance(v, (int, float)) and math.isfinite(v) for v in values)


def coast_track(
    *, last_object: PredictedObject, now_ts: float, horizons_s: tuple,
    lifecycle_state: TrackLifecycleState, lifecycle_confidence: float,
    track_age_cycles: int = 0,
) -> Optional[PredictedObject]:
    """Produce a short-term coasted PredictedObject for a track that
    was not seen this cycle. Returns None if the last known state or
    now_ts is unusable (never fabricates a position)."""
    last_state = last_object.current_state
    if last_state is None or not last_state.is_valid() or not _finite(now_ts):
        return None

    elapsed = now_ts - last_state.timestamp
    if not _finite(elapsed) or elapsed < 0:
        return None

    model = last_object.selected_model if last_object.selected_model != ModelType.NOT_AVAILABLE else ModelType.CV

    # Class-aware smoothing (spec 5): never coast a bus/truck through a
    # sharper turn than that class can plausibly execute.
    clamped_yaw_rate = clamp_yaw_rate_for_class(last_object.object_type, last_state.yaw_rate)
    coast_base_state = MotionState(
        x=last_state.x, y=last_state.y, z=last_state.z,
        vx=last_state.vx, vy=last_state.vy, vz=last_state.vz,
        ax=last_state.ax, ay=last_state.ay, az=last_state.az,
        yaw=last_state.yaw, yaw_rate=clamped_yaw_rate,
        speed=last_state.speed, heading=last_state.heading,
        timestamp=last_state.timestamp,
    )

    # Advance to "now" first, then roll trajectory out from there.
    now_state = predict_motion(coast_base_state, elapsed, model.value)
    now_state = MotionState(
        x=now_state.x, y=now_state.y, z=now_state.z,
        vx=now_state.vx, vy=now_state.vy, vz=now_state.vz,
        ax=now_state.ax, ay=now_state.ay, az=now_state.az,
        yaw=now_state.yaw, yaw_rate=clamped_yaw_rate,
        speed=now_state.speed, heading=now_state.heading,
        timestamp=now_ts,
    )
    if not now_state.is_valid():
        return None

    base_sigma = None
    if last_object.uncertainty:
        base_sigma = max(
            last_object.uncertainty.get("sigma_x", 0.0),
            last_object.uncertainty.get("sigma_y", 0.0),
        ) or None

    trajectory = []
    for h in horizons_s:
        future = predict_motion(now_state, h, model.value)
        result = compute_uncertainty(UncertaintyFactors(
            horizon_s=h, object_type=last_object.object_type, base_sigma=base_sigma,
            sensor_quality=SensorQuality.LOW_CONFIDENCE,  # coasting: no fresh measurement at all
            track_age_cycles=track_age_cycles, lost_duration_s=elapsed,
            base_confidence=lifecycle_confidence,
        ))
        cov = [
            [result.sigma_x ** 2, 0.0, 0.0, 0.0],
            [0.0, result.sigma_y ** 2, 0.0, 0.0],
            [0.0, 0.0, result.sigma_vx ** 2, 0.0],
            [0.0, 0.0, 0.0, result.sigma_vy ** 2],
        ]
        trajectory.append(PredictedState(
            timestamp=now_ts + h, x=future.x, y=future.y, z=future.z,
            vx=future.vx, vy=future.vy, vz=future.vz,
            yaw=future.yaw, speed=future.speed, horizon_s=h, covariance=cov,
        ))

    final = compute_uncertainty(UncertaintyFactors(
        horizon_s=max(horizons_s) if horizons_s else 0.0,
        object_type=last_object.object_type, base_sigma=base_sigma,
        sensor_quality=SensorQuality.LOW_CONFIDENCE,
        track_age_cycles=track_age_cycles, lost_duration_s=elapsed,
        base_confidence=lifecycle_confidence,
    ))

    return PredictedObject(
        track_id=last_object.track_id, object_type=last_object.object_type,
        current_state=now_state, trajectory=trajectory,
        prediction_confidence=final.confidence,
        uncertainty=final.to_dict(), selected_model=model,
        lifecycle_state=lifecycle_state,
        warnings=[f"coasted {elapsed:.3f}s without measurement"],
    )
