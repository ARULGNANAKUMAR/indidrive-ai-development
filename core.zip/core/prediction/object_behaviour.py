"""
IndiDrive AI — Phase 4C | Object-Specific Behaviour Priors
================================================================
Deterministic behaviour priors for the object classes that matter on
unstructured Indian roads (spec section 1-7). Nothing here performs
prediction itself — these are lookup tables + small pure helpers that
uncertainty_engine.py and path_selector.py consume.

No fake statistics (spec section 4): every multiplier below is a
fixed, documented constant reflecting how each class actually
behaves relative to a "textbook" passenger car (factor 1.0), not a
sampled/fabricated number. Values are relative multipliers, not
measured physical constants.
"""
from __future__ import annotations

from dataclasses import dataclass
from enum import Enum

__all__ = [
    "ObjectBehaviourClass", "BehaviourProfile",
    "classify_object", "get_profile", "clamp_yaw_rate_for_class",
]


class ObjectBehaviourClass(str, Enum):
    CAR = "CAR"
    MOTORCYCLE = "MOTORCYCLE"
    SCOOTER = "SCOOTER"
    AUTO_RICKSHAW = "AUTO_RICKSHAW"
    BUS = "BUS"
    TRUCK = "TRUCK"
    TRACTOR = "TRACTOR"
    CYCLE = "CYCLE"
    PEDESTRIAN = "PEDESTRIAN"
    CATTLE = "CATTLE"
    UNKNOWN = "UNKNOWN"


@dataclass(frozen=True)
class BehaviourProfile:
    """Relative behaviour multipliers for one object class. 1.0 is the
    car baseline in every field; values above 1.0 mean "more
    uncertain / more agile / less predictable than a car", values
    below 1.0 mean "steadier / less agile than a car"."""
    behaviour_class: ObjectBehaviourClass
    lateral_uncertainty_factor: float      # spec 2/3/4: motorcycle/pedestrian/cattle lateral spread
    direction_uncertainty_factor: float    # how uncertain the *heading* itself is
    agility: float                         # how quickly heading/lane position can realistically change
    longitudinal_uncertainty_factor: float
    unpredictability: float                # spec 4: cattle highly unpredictable
    max_yaw_rate: float                    # rad/s ceiling used to smooth bus/truck turns (spec 5)
    sudden_lateral_move_prone: bool        # spec 2: motorcycle cut-in / filtering
    sudden_entry_prone: bool               # spec 3: pedestrian/cattle sudden road entry


# Deterministic priors. Car is the 1.0 baseline for every factor.
_PROFILES: dict = {
    ObjectBehaviourClass.CAR: BehaviourProfile(
        ObjectBehaviourClass.CAR,
        lateral_uncertainty_factor=1.0, direction_uncertainty_factor=1.0,
        agility=1.0, longitudinal_uncertainty_factor=1.0, unpredictability=1.0,
        max_yaw_rate=1.2, sudden_lateral_move_prone=False, sudden_entry_prone=False,
    ),
    ObjectBehaviourClass.MOTORCYCLE: BehaviourProfile(
        ObjectBehaviourClass.MOTORCYCLE,
        # spec 2: higher lateral uncertainty, sudden lateral movement,
        # cut-in behaviour, filtering between vehicles.
        lateral_uncertainty_factor=2.2, direction_uncertainty_factor=1.8,
        agility=2.0, longitudinal_uncertainty_factor=1.3, unpredictability=1.6,
        max_yaw_rate=2.5, sudden_lateral_move_prone=True, sudden_entry_prone=False,
    ),
    ObjectBehaviourClass.SCOOTER: BehaviourProfile(
        ObjectBehaviourClass.SCOOTER,
        lateral_uncertainty_factor=2.0, direction_uncertainty_factor=1.7,
        agility=1.8, longitudinal_uncertainty_factor=1.2, unpredictability=1.5,
        max_yaw_rate=2.2, sudden_lateral_move_prone=True, sudden_entry_prone=False,
    ),
    ObjectBehaviourClass.AUTO_RICKSHAW: BehaviourProfile(
        ObjectBehaviourClass.AUTO_RICKSHAW,
        # Three-wheeler: narrower than a car, prone to abrupt lane
        # changes/u-turns but not as agile as a two-wheeler.
        lateral_uncertainty_factor=1.7, direction_uncertainty_factor=1.5,
        agility=1.5, longitudinal_uncertainty_factor=1.2, unpredictability=1.4,
        max_yaw_rate=1.8, sudden_lateral_move_prone=True, sudden_entry_prone=False,
    ),
    ObjectBehaviourClass.BUS: BehaviourProfile(
        ObjectBehaviourClass.BUS,
        # spec 5: smoother turning, lower lateral agility, longer
        # movement continuity.
        lateral_uncertainty_factor=0.6, direction_uncertainty_factor=0.6,
        agility=0.4, longitudinal_uncertainty_factor=0.8, unpredictability=0.7,
        max_yaw_rate=0.5, sudden_lateral_move_prone=False, sudden_entry_prone=False,
    ),
    ObjectBehaviourClass.TRUCK: BehaviourProfile(
        ObjectBehaviourClass.TRUCK,
        lateral_uncertainty_factor=0.6, direction_uncertainty_factor=0.6,
        agility=0.35, longitudinal_uncertainty_factor=0.8, unpredictability=0.7,
        max_yaw_rate=0.45, sudden_lateral_move_prone=False, sudden_entry_prone=False,
    ),
    ObjectBehaviourClass.TRACTOR: BehaviourProfile(
        ObjectBehaviourClass.TRACTOR,
        # spec 6: low speed, irregular movement, lateral uncertainty.
        lateral_uncertainty_factor=1.5, direction_uncertainty_factor=1.4,
        agility=0.7, longitudinal_uncertainty_factor=1.4, unpredictability=1.4,
        max_yaw_rate=1.0, sudden_lateral_move_prone=False, sudden_entry_prone=False,
    ),
    ObjectBehaviourClass.CYCLE: BehaviourProfile(
        ObjectBehaviourClass.CYCLE,
        lateral_uncertainty_factor=1.9, direction_uncertainty_factor=1.6,
        agility=1.6, longitudinal_uncertainty_factor=1.1, unpredictability=1.5,
        max_yaw_rate=2.0, sudden_lateral_move_prone=True, sudden_entry_prone=False,
    ),
    ObjectBehaviourClass.PEDESTRIAN: BehaviourProfile(
        ObjectBehaviourClass.PEDESTRIAN,
        # spec 3: lateral crossing, sudden road entry, variable direction.
        lateral_uncertainty_factor=2.5, direction_uncertainty_factor=2.5,
        agility=2.2, longitudinal_uncertainty_factor=1.0, unpredictability=1.9,
        max_yaw_rate=3.0, sudden_lateral_move_prone=True, sudden_entry_prone=True,
    ),
    ObjectBehaviourClass.CATTLE: BehaviourProfile(
        ObjectBehaviourClass.CATTLE,
        # spec 4: cattle treated as highly unpredictable, broad
        # lateral/direction/behaviour uncertainty.
        lateral_uncertainty_factor=3.0, direction_uncertainty_factor=3.0,
        agility=1.5, longitudinal_uncertainty_factor=1.6, unpredictability=2.5,
        max_yaw_rate=2.0, sudden_lateral_move_prone=True, sudden_entry_prone=True,
    ),
    ObjectBehaviourClass.UNKNOWN: BehaviourProfile(
        ObjectBehaviourClass.UNKNOWN,
        # Unknown class: assume worse than a car (never assume best
        # case for something the perception stack couldn't classify).
        lateral_uncertainty_factor=1.5, direction_uncertainty_factor=1.5,
        agility=1.3, longitudinal_uncertainty_factor=1.3, unpredictability=1.5,
        max_yaw_rate=1.5, sudden_lateral_move_prone=True, sudden_entry_prone=False,
    ),
}

# Alias table: raw perception/fusion object_class strings -> behaviour
# class. Kept explicit and deterministic (no fuzzy matching).
_ALIASES: dict = {
    "car": ObjectBehaviourClass.CAR,
    "sedan": ObjectBehaviourClass.CAR,
    "hatchback": ObjectBehaviourClass.CAR,
    "suv": ObjectBehaviourClass.CAR,
    "van": ObjectBehaviourClass.CAR,
    "jeep": ObjectBehaviourClass.CAR,

    "motorcycle": ObjectBehaviourClass.MOTORCYCLE,
    "motorbike": ObjectBehaviourClass.MOTORCYCLE,
    "bike": ObjectBehaviourClass.MOTORCYCLE,
    "two_wheeler": ObjectBehaviourClass.MOTORCYCLE,
    "two-wheeler": ObjectBehaviourClass.MOTORCYCLE,

    "scooter": ObjectBehaviourClass.SCOOTER,
    "moped": ObjectBehaviourClass.SCOOTER,

    "auto_rickshaw": ObjectBehaviourClass.AUTO_RICKSHAW,
    "auto-rickshaw": ObjectBehaviourClass.AUTO_RICKSHAW,
    "autorickshaw": ObjectBehaviourClass.AUTO_RICKSHAW,
    "auto": ObjectBehaviourClass.AUTO_RICKSHAW,
    "rickshaw": ObjectBehaviourClass.AUTO_RICKSHAW,
    "tuktuk": ObjectBehaviourClass.AUTO_RICKSHAW,
    "three_wheeler": ObjectBehaviourClass.AUTO_RICKSHAW,

    "bus": ObjectBehaviourClass.BUS,
    "minibus": ObjectBehaviourClass.BUS,

    "truck": ObjectBehaviourClass.TRUCK,
    "lorry": ObjectBehaviourClass.TRUCK,
    "trailer": ObjectBehaviourClass.TRUCK,

    "tractor": ObjectBehaviourClass.TRACTOR,
    "trolley": ObjectBehaviourClass.TRACTOR,

    "cycle": ObjectBehaviourClass.CYCLE,
    "bicycle": ObjectBehaviourClass.CYCLE,
    "cyclist": ObjectBehaviourClass.CYCLE,

    "pedestrian": ObjectBehaviourClass.PEDESTRIAN,
    "person": ObjectBehaviourClass.PEDESTRIAN,
    "walker": ObjectBehaviourClass.PEDESTRIAN,

    "cattle": ObjectBehaviourClass.CATTLE,
    "cow": ObjectBehaviourClass.CATTLE,
    "bull": ObjectBehaviourClass.CATTLE,
    "buffalo": ObjectBehaviourClass.CATTLE,
    "ox": ObjectBehaviourClass.CATTLE,
    "goat": ObjectBehaviourClass.CATTLE,
    "stray_animal": ObjectBehaviourClass.CATTLE,
}


def classify_object(object_type: str) -> ObjectBehaviourClass:
    """Maps a raw object_class string (Phase 2/3 vocabulary, whatever
    case/spacing it arrives in) to a Phase 4C behaviour class.
    Unrecognized/empty input -> UNKNOWN (never guessed as CAR)."""
    if not isinstance(object_type, str):
        return ObjectBehaviourClass.UNKNOWN
    key = object_type.strip().lower().replace(" ", "_")
    return _ALIASES.get(key, ObjectBehaviourClass.UNKNOWN)


def get_profile(object_type: str) -> BehaviourProfile:
    return _PROFILES[classify_object(object_type)]


def clamp_yaw_rate_for_class(object_type: str, yaw_rate: float) -> float:
    """spec section 5: buses/trucks turn smoothly — never let a noisy
    measurement push their predicted yaw_rate past what the class can
    physically do. Sign is preserved; only magnitude is clamped."""
    import math as _math
    if not isinstance(yaw_rate, (int, float)) or not _math.isfinite(yaw_rate):
        return 0.0
    profile = get_profile(object_type)
    limit = profile.max_yaw_rate
    if yaw_rate > limit:
        return limit
    if yaw_rate < -limit:
        return -limit
    return yaw_rate
