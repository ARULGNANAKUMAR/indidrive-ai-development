"""
IndiDrive AI — Phase 4D | Data Contracts
=========================================
TTC, Closest Approach, Collision Likelihood, Risk Level.
All deterministic — same input produces identical output.
No NaN/Inf propagation.
"""
from __future__ import annotations

import math
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Optional

from core.perception.perception_types import HealthState
from .phase4c_types import Phase4CObject, Phase4CMetrics

__all__ = [
    "TTCStatus", "RiskLevel",
    "TTCResult", "ClosestApproachResult", "HypothesisRisk",
    "Phase4DObject", "Phase4DMetrics", "Phase4DWorldState",
]

_NOT_AVAILABLE = "NOT_AVAILABLE"


class TTCStatus(str, Enum):
    FINITE = "FINITE"           # positive, meaningful TTC exists
    NO_COLLISION = "NO_COLLISION"  # objects diverging or parallel — no collision
    UNKNOWN = "UNKNOWN"         # insufficient data to compute


class RiskLevel(str, Enum):
    LOW = "LOW"
    MEDIUM = "MEDIUM"
    HIGH = "HIGH"
    CRITICAL = "CRITICAL"


@dataclass
class TTCResult:
    ttc_s: Optional[float]      # seconds until collision; None when status != FINITE
    status: TTCStatus
    closing_speed_ms: Optional[float] = None   # positive = closing, None if unknown

    def to_dict(self) -> dict:
        return {
            "ttc_s": round(self.ttc_s, 4) if self.ttc_s is not None else _NOT_AVAILABLE,
            "status": self.status.value,
            "closing_speed_ms": round(self.closing_speed_ms, 4)
            if self.closing_speed_ms is not None else _NOT_AVAILABLE,
        }


@dataclass
class ClosestApproachResult:
    minimum_distance_m: float          # metres; always >= 0
    time_of_closest_approach_s: float  # seconds from now; >= 0
    relative_position_x: float         # object x - ego x at closest approach
    relative_position_y: float         # object y - ego y at closest approach
    relative_velocity_x: float         # object vx - ego vx at closest approach time
    relative_velocity_y: float         # object vy - ego vy at closest approach time

    def to_dict(self) -> dict:
        return {
            "minimum_distance_m": round(self.minimum_distance_m, 4),
            "time_of_closest_approach_s": round(self.time_of_closest_approach_s, 4),
            "relative_position_x": round(self.relative_position_x, 4),
            "relative_position_y": round(self.relative_position_y, 4),
            "relative_velocity_x": round(self.relative_velocity_x, 4),
            "relative_velocity_y": round(self.relative_velocity_y, 4),
        }


@dataclass
class HypothesisRisk:
    """Risk assessment for a single behaviour hypothesis."""
    behaviour: str
    probability: float
    collision_likelihood: float   # deterministic risk score [0, 1]
    risk_level: RiskLevel

    def to_dict(self) -> dict:
        return {
            "behaviour": self.behaviour,
            "probability": round(self.probability, 6),
            "collision_likelihood": round(self.collision_likelihood, 4),
            "risk_level": self.risk_level.value,
        }


@dataclass
class Phase4DObject:
    """Phase 4D-enriched output for one predicted object (one cycle)."""
    phase4c: Phase4CObject

    # TTC
    ttc: TTCResult = field(default_factory=lambda: TTCResult(None, TTCStatus.UNKNOWN))

    # Closest approach (from trajectory comparison)
    closest_approach: Optional[ClosestApproachResult] = None

    # Deterministic risk score [0, 1] — NOT calibrated ML probability
    collision_likelihood: float = 0.0

    # Per-hypothesis risks
    hypothesis_risks: list = field(default_factory=list)  # list[HypothesisRisk]

    # Overall prediction-level risk (NOT final safety decision)
    risk_level: RiskLevel = RiskLevel.LOW

    # True when this object had invalid data — still included but marked
    invalid: bool = False
    invalid_reason: str = ""

    # ---- convenience proxies so callers don't have to dig into phase4c ----
    @property
    def track_id(self) -> str:
        return self.phase4c.track_id

    @property
    def object_type(self) -> str:
        return self.phase4c.predicted.object_type

    @property
    def prediction_confidence(self) -> float:
        return self.phase4c.predicted.prediction_confidence

    @property
    def uncertainty(self) -> dict:
        return self.phase4c.predicted.uncertainty

    def to_dict(self) -> dict:
        d = self.phase4c.to_dict()
        d["ttc"] = self.ttc.to_dict()
        d["closest_approach"] = (
            self.closest_approach.to_dict() if self.closest_approach else _NOT_AVAILABLE
        )
        d["collision_likelihood"] = round(self.collision_likelihood, 4)
        d["hypothesis_risks"] = [h.to_dict() for h in self.hypothesis_risks]
        d["risk_level"] = self.risk_level.value
        d["invalid"] = self.invalid
        if self.invalid:
            d["invalid_reason"] = self.invalid_reason
        return d


@dataclass
class Phase4DMetrics(Phase4CMetrics):
    ttc_latency_ms: float = 0.0
    closest_approach_latency_ms: float = 0.0
    collision_likelihood_latency_ms: float = 0.0
    total_prediction_latency_ms: float = 0.0

    # Health counters (spec requirement 9)
    prediction_cycles: int = 0
    valid_objects: int = 0
    invalid_objects: int = 0
    lost_tracks: int = 0
    stale_tracks: int = 0
    prediction_failures: int = 0
    average_latency_ms: float = 0.0
    maximum_latency_ms: float = 0.0
    object_count: int = 0

    def to_dict(self) -> dict:
        base = super().to_dict()
        base.update({
            "ttc_latency_ms": round(self.ttc_latency_ms, 3),
            "closest_approach_latency_ms": round(self.closest_approach_latency_ms, 3),
            "collision_likelihood_latency_ms": round(self.collision_likelihood_latency_ms, 3),
            "total_prediction_latency_ms": round(self.total_prediction_latency_ms, 3),
            "prediction_cycles": self.prediction_cycles,
            "valid_objects": self.valid_objects,
            "invalid_objects": self.invalid_objects,
            "lost_tracks": self.lost_tracks,
            "stale_tracks": self.stale_tracks,
            "prediction_failures": self.prediction_failures,
            "average_latency_ms": round(self.average_latency_ms, 3),
            "maximum_latency_ms": round(self.maximum_latency_ms, 3),
            "object_count": self.object_count,
        })
        return base


@dataclass
class Phase4DWorldState:
    timestamp: float
    frame_id: int
    objects: list = field(default_factory=list)  # list[Phase4DObject]
    prediction_health: HealthState = HealthState.NOT_CONFIGURED
    warnings: list = field(default_factory=list)
    metrics: Phase4DMetrics = field(default_factory=Phase4DMetrics)
    created_at: float = field(default_factory=time.time)

    def to_dict(self) -> dict:
        return {
            "timestamp": self.timestamp,
            "frame_id": self.frame_id,
            "objects": [o.to_dict() for o in self.objects],
            "prediction_health": self.prediction_health.value,
            "warnings": self.warnings,
            "metrics": self.metrics.to_dict(),
        }
