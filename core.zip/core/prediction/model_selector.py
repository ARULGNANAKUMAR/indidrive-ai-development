"""
IndiDrive AI — Phase 4A | Model Selector
=============================================
Deterministic rule-based selection between CV / CA / CTRV for a given
track. No randomness anywhere (spec section 10/17): the same
(MotionState, history) pair always yields the same ModelType.

Selection order (checked top to bottom, first match wins):
    1. turning (|yaw_rate| above threshold)         -> CTRV
    2. accelerating (|acceleration| above threshold) -> CA
    3. otherwise (stable speed & heading)            -> CV

Speed/measurement-confidence and object type are accepted as optional
extra signals (spec section 10 lists them as things selection "can
consider") but the default thresholds below only need yaw_rate/accel
to make a deterministic call; they are kept as explicit parameters so
a future tune can use them without changing the function signature.
"""
from __future__ import annotations

import math
from dataclasses import dataclass

from .prediction_types import ModelType

DEFAULT_YAW_RATE_THRESHOLD = 0.05     # rad/s -- above this, treat as turning
DEFAULT_ACCEL_THRESHOLD = 0.5         # m/s^2 -- above this, treat as accelerating
DEFAULT_STATIONARY_SPEED = 0.1        # m/s -- at/below this, always CV (no basis to fit a turn/accel model)


@dataclass
class ModelSelectorConfig:
    yaw_rate_threshold: float = DEFAULT_YAW_RATE_THRESHOLD
    accel_threshold: float = DEFAULT_ACCEL_THRESHOLD
    stationary_speed: float = DEFAULT_STATIONARY_SPEED


class ModelSelector:
    def __init__(self, config: ModelSelectorConfig = None):
        self.config = config or ModelSelectorConfig()

    def select(
        self, *, speed: float, yaw_rate: float, ax: float, ay: float,
        object_type: str = "", measurement_confidence: float = 1.0,
    ) -> ModelType:
        cfg = self.config

        # Guard against non-finite inputs feeding a bad decision.
        speed = speed if math.isfinite(speed) else 0.0
        yaw_rate = yaw_rate if math.isfinite(yaw_rate) else 0.0
        ax = ax if math.isfinite(ax) else 0.0
        ay = ay if math.isfinite(ay) else 0.0

        if speed <= cfg.stationary_speed:
            return ModelType.CV

        if abs(yaw_rate) > cfg.yaw_rate_threshold:
            return ModelType.CTRV

        accel_mag = math.hypot(ax, ay)
        if accel_mag > cfg.accel_threshold:
            return ModelType.CA

        return ModelType.CV
