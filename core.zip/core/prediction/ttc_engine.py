"""
IndiDrive AI — Phase 4D | TTC Engine
======================================
Robust Time-To-Collision supporting:
  - same direction, opposite direction, crossing, stationary object
  - zero relative velocity, negative closing velocity, missing velocity

Returns TTCResult with explicit semantic TTCStatus.
Never returns NaN, Inf, or negative TTC.
Fully deterministic.
"""
from __future__ import annotations

import math
from typing import Optional

from .phase4d_types import TTCResult, TTCStatus

__all__ = ["compute_ttc", "EgoKinematics"]

# Lateral radius summed for a "collision" event (metres).
# Used as the half-width threshold for same-direction/opposite-direction TTC.
_DEFAULT_COLLISION_RADIUS_M = 1.5   # generous: car width ~1.8 m, half = 0.9 m + margin

# Minimum closing speed below which we consider relative motion zero (m/s).
_ZERO_SPEED_THRESHOLD = 0.05


class EgoKinematics:
    """Ego vehicle kinematics used for trajectory intersection.
    All values are in the vehicle/world frame, metres, m/s.
    """
    __slots__ = ("x", "y", "vx", "vy", "width_m", "length_m")

    def __init__(
        self,
        x: float = 0.0, y: float = 0.0,
        vx: float = 0.0, vy: float = 0.0,
        width_m: float = 1.8, length_m: float = 4.5,
    ):
        self.x = x
        self.y = y
        self.vx = vx
        self.vy = vy
        self.width_m = width_m
        self.length_m = length_m


def _safe_finite(v) -> Optional[float]:
    """Return v if it is a finite number, else None."""
    if isinstance(v, (int, float)) and math.isfinite(v):
        return float(v)
    return None


def compute_ttc(
    ego_x: float, ego_y: float, ego_vx: float, ego_vy: float,
    obj_x: float, obj_y: float, obj_vx: Optional[float], obj_vy: Optional[float],
    collision_radius_m: float = _DEFAULT_COLLISION_RADIUS_M,
) -> TTCResult:
    """
    Compute TTC between ego and one object using relative-motion algebra.

    Algorithm:
        1. Check for invalid / missing data → UNKNOWN
        2. Compute relative position and velocity
        3. Check closing speed sign:
           - if diverging (closing_speed < -threshold) → NO_COLLISION
           - if near-zero → NO_COLLISION (parallel or stationary rel.)
        4. Compute time-of-closest-approach and check if distance at that
           time is <= collision_radius → FINITE, else NO_COLLISION

    Returns TTCResult with status FINITE | NO_COLLISION | UNKNOWN.
    Never exposes negative TTC or NaN.
    """
    # --- validate inputs ---
    ego_x_ = _safe_finite(ego_x)
    ego_y_ = _safe_finite(ego_y)
    ego_vx_ = _safe_finite(ego_vx)
    ego_vy_ = _safe_finite(ego_vy)
    obj_x_ = _safe_finite(obj_x)
    obj_y_ = _safe_finite(obj_y)
    obj_vx_ = _safe_finite(obj_vx)
    obj_vy_ = _safe_finite(obj_vy)

    if any(v is None for v in (ego_x_, ego_y_, ego_vx_, ego_vy_, obj_x_, obj_y_)):
        return TTCResult(None, TTCStatus.UNKNOWN)

    if obj_vx_ is None or obj_vy_ is None:
        # Object velocity unknown: treat as stationary for conservative estimate
        obj_vx_ = 0.0
        obj_vy_ = 0.0
        velocity_missing = True
    else:
        velocity_missing = False

    # --- relative kinematics ---
    dx = obj_x_ - ego_x_  # object relative to ego
    dy = obj_y_ - ego_y_
    dvx = obj_vx_ - ego_vx_  # relative velocity: d(dx)/dt = obj_vx - ego_vx
    dvy = obj_vy_ - ego_vy_

    dist_sq = dx * dx + dy * dy
    dist = math.sqrt(dist_sq)

    rel_speed_sq = dvx * dvx + dvy * dvy
    rel_speed = math.sqrt(rel_speed_sq)

    # Closing speed = -d(dist)/dt = -(dx·dvx + dy·dvy)/dist
    # Positive closing speed means objects approaching.
    if dist > 1e-9:
        closing_speed = -(dx * dvx + dy * dvy) / dist
    else:
        # Objects already at same position — immediate collision
        closing_speed = rel_speed

    # --- already overlapping? ---
    if dist <= collision_radius_m:
        return TTCResult(
            ttc_s=0.0, status=TTCStatus.FINITE, closing_speed_ms=closing_speed
        )

    # --- stationary relative motion ---
    if rel_speed < _ZERO_SPEED_THRESHOLD:
        return TTCResult(None, TTCStatus.NO_COLLISION, closing_speed_ms=0.0)

    # --- diverging ---
    if closing_speed < -_ZERO_SPEED_THRESHOLD:
        return TTCResult(None, TTCStatus.NO_COLLISION, closing_speed_ms=closing_speed)

    # --- time of closest approach ---
    # t* = -(dx·dvx + dy·dvy) / (dvx²+dvy²)  [minimises |r(t)|²]
    denom = dvx * dvx + dvy * dvy
    if denom < 1e-12:
        return TTCResult(None, TTCStatus.NO_COLLISION, closing_speed_ms=closing_speed)

    t_star = -(dx * dvx + dy * dvy) / denom

    if t_star < 0.0:
        # Closest approach already in the past — diverging now
        return TTCResult(None, TTCStatus.NO_COLLISION, closing_speed_ms=closing_speed)

    # distance at t_star
    cx = dx + dvx * t_star
    cy = dy + dvy * t_star
    closest_dist = math.sqrt(cx * cx + cy * cy)

    if closest_dist > collision_radius_m:
        return TTCResult(None, TTCStatus.NO_COLLISION, closing_speed_ms=closing_speed)

    # Trajectories will intersect — back-solve for when |r(t)| = collision_radius.
    # |r(t)|² = (dx+dvx·t)² + (dy+dvy·t)² = collision_radius²
    # at²  + bt + c = 0  where a=denom, b=2(dx·dvx+dy·dvy), c=dist²-radius²
    a = denom
    b = 2.0 * (dx * dvx + dy * dvy)
    c = dist_sq - collision_radius_m * collision_radius_m

    discriminant = b * b - 4.0 * a * c
    if discriminant < 0.0:
        return TTCResult(None, TTCStatus.NO_COLLISION, closing_speed_ms=closing_speed)

    sqrt_disc = math.sqrt(discriminant)
    t1 = (-b - sqrt_disc) / (2.0 * a)
    t2 = (-b + sqrt_disc) / (2.0 * a)

    # Pick the first positive root (first contact time)
    ttc = None
    for t in sorted([t1, t2]):
        if t >= 0.0:
            ttc = t
            break

    if ttc is None:
        return TTCResult(None, TTCStatus.NO_COLLISION, closing_speed_ms=closing_speed)

    # Safety: guard against extremely tiny negative floating-point artefact
    ttc = max(0.0, ttc)

    status = TTCStatus.UNKNOWN if velocity_missing else TTCStatus.FINITE
    return TTCResult(ttc_s=ttc, status=status, closing_speed_ms=closing_speed)
