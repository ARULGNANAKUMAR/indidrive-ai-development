"""
IndiDrive AI — Phase 4A | Prediction Manager
=================================================
Top-level lifecycle and orchestration, mirroring the responsibilities
of Phase 3's core/fusion/fusion_manager.py one layer up:

    initialize()
    process(fused_world_state)      -> PredictedWorldState
    process_from_fusion_manager(fusion_manager)
    get_latest_prediction()
    get_history()
    get_health()
    get_metrics()
    reset()
    shutdown()

Contains no path-planning/collision-avoidance logic (Phase 4B) and
does not itself talk to sensors — it only consumes Phase 3
FusedWorldStates.
"""
from __future__ import annotations

import threading
from collections import deque
from pathlib import Path
from typing import Optional

from core.fusion.fusion_types import FusedWorldState

from .prediction_engine import (
    PredictionEngine, PredictionEngineConfig, KalmanConfig, DEFAULT_HORIZONS_S,
)
from .model_selector import ModelSelectorConfig
from .track_lifecycle import TrackLifecycleConfig
from .track_history import DEFAULT_MAX_HISTORY
from .prediction_types import PredictedWorldState

try:
    from core.logging_system import get_logger
except ImportError:  # pragma: no cover
    get_logger = None

try:
    from core.config_loader import CONFIG_DIR
except ImportError:  # pragma: no cover
    CONFIG_DIR = None


DEFAULT_PREDICTION_CONFIG = {
    "prediction": {
        "enabled": True,
        "deterministic": True,
        "horizons_s": list(DEFAULT_HORIZONS_S),
        "track_history": {"max_history": DEFAULT_MAX_HISTORY},
        "kalman": {
            "process_noise": 1.0, "measurement_noise": 0.5,
            "initial_position_variance": 10.0, "initial_velocity_variance": 100.0,
        },
        "model_selector": {
            "yaw_rate_threshold": 0.05, "accel_threshold": 0.5, "stationary_speed": 0.1,
        },
        "lifecycle": {
            "confirm_hits": 2, "lost_after_misses": 2, "stale_after_misses": 5,
            "delete_after_misses": 10, "confidence_decay": 0.3, "confidence_recovery": 0.5,
        },
    }
}


def _load_prediction_config() -> dict:
    if CONFIG_DIR is not None:
        try:
            path = Path(CONFIG_DIR) / "prediction_config.yaml"
            if path.exists():
                import yaml  # type: ignore
                with open(path, "r", encoding="utf-8") as f:
                    data = yaml.safe_load(f)
                if isinstance(data, dict) and "prediction" in data:
                    return data
        except Exception:
            pass
    return DEFAULT_PREDICTION_CONFIG


def _engine_config_from_raw(raw: dict) -> PredictionEngineConfig:
    pcfg = raw.get("prediction", {})
    horizons = pcfg.get("horizons_s", list(DEFAULT_HORIZONS_S))
    th_cfg = pcfg.get("track_history", {})
    k_cfg = pcfg.get("kalman", {})
    ms_cfg = pcfg.get("model_selector", {})
    lc_cfg = pcfg.get("lifecycle", {})

    return PredictionEngineConfig(
        enabled=pcfg.get("enabled", True),
        deterministic=pcfg.get("deterministic", True),
        horizons_s=tuple(float(h) for h in horizons),
        max_track_history=th_cfg.get("max_history", DEFAULT_MAX_HISTORY),
        kalman=KalmanConfig(
            process_noise=k_cfg.get("process_noise", 1.0),
            measurement_noise=k_cfg.get("measurement_noise", 0.5),
            initial_position_variance=k_cfg.get("initial_position_variance", 10.0),
            initial_velocity_variance=k_cfg.get("initial_velocity_variance", 100.0),
        ),
        model_selector=ModelSelectorConfig(
            yaw_rate_threshold=ms_cfg.get("yaw_rate_threshold", 0.05),
            accel_threshold=ms_cfg.get("accel_threshold", 0.5),
            stationary_speed=ms_cfg.get("stationary_speed", 0.1),
        ),
        lifecycle=TrackLifecycleConfig(
            confirm_hits=lc_cfg.get("confirm_hits", 2),
            lost_after_misses=lc_cfg.get("lost_after_misses", 2),
            stale_after_misses=lc_cfg.get("stale_after_misses", 5),
            delete_after_misses=lc_cfg.get("delete_after_misses", 10),
            confidence_decay=lc_cfg.get("confidence_decay", 0.3),
            confidence_recovery=lc_cfg.get("confidence_recovery", 0.5),
        ),
    )


class PredictionManager:
    def __init__(self, config: Optional[dict] = None, history_size: int = 30):
        self._raw_config = config or _load_prediction_config()
        self._log = get_logger("system", component="prediction_manager") if get_logger else None
        self._lock = threading.Lock()
        self._history: deque = deque(maxlen=max(1, history_size))
        self._initialized = False
        self.engine: Optional[PredictionEngine] = None

    # -- lifecycle --------------------------------------------------

    def initialize(self) -> None:
        if self._initialized:
            return
        engine_config = _engine_config_from_raw(self._raw_config)
        self.engine = PredictionEngine(engine_config)
        self._initialized = True
        if self._log:
            self._log.info("prediction_manager_initialized", deterministic=engine_config.deterministic)

    def shutdown(self) -> None:
        with self._lock:
            self._history.clear()
        if self.engine:
            self.engine.reset()
        self._initialized = False
        if self._log:
            self._log.info("prediction_manager_shutdown")

    def reset(self) -> None:
        """Clears history and track state but keeps the manager
        initialized/configured (unlike shutdown())."""
        with self._lock:
            self._history.clear()
        if self.engine:
            self.engine.reset()

    def _require_engine(self) -> PredictionEngine:
        if not self._initialized or self.engine is None:
            self.initialize()
        return self.engine

    # -- processing ---------------------------------------------------

    def process(self, fused_world_state: FusedWorldState) -> PredictedWorldState:
        engine = self._require_engine()
        predicted = engine.process(fused_world_state)
        with self._lock:
            self._history.append(predicted)
        return predicted

    def process_from_fusion_manager(self, fusion_manager) -> Optional[PredictedWorldState]:
        """Convenience bridge to Phase 3's FusionManager: predicts
        whatever the manager's latest FusedWorldState is. Returns None
        (does not crash) if nothing has been fused yet."""
        world_state = fusion_manager.get_latest_world_state()
        if world_state is None:
            return None
        return self.process(world_state)

    # -- introspection ---------------------------------------------------

    def get_latest_prediction(self) -> Optional[PredictedWorldState]:
        with self._lock:
            return self._history[-1] if self._history else None

    def get_history(self) -> list:
        with self._lock:
            return list(self._history)

    def get_health(self) -> dict:
        latest = self.get_latest_prediction()
        if latest is None:
            return {"prediction_health": "NOT_CONFIGURED"}
        return {"prediction_health": latest.prediction_health.value, "warnings": latest.warnings}

    def get_metrics(self) -> dict:
        latest = self.get_latest_prediction()
        if latest is None:
            return {}
        return latest.metrics.to_dict()
