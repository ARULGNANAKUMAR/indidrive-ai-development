"""
IndiDrive AI — Phase 4A | Motion Prediction Foundation
===========================================================
Consumes Phase 3's FusedWorldState and produces a PredictedWorldState:
per-track motion history, a lightweight Kalman filter, deterministic
CV/CA/CTRV model selection, and multi-horizon trajectories with
growing uncertainty. Path planning, MPC and final collision avoidance
are NOT part of this phase (Phase 4B+).
"""
from .prediction_types import (
    ModelType, TrackLifecycleState,
    MotionState, PredictedState, PredictedObject,
    PredictionMetrics, PredictedWorldState,
)
from .prediction_engine import PredictionEngine, PredictionEngineConfig
from .prediction_manager import PredictionManager

# -- Phase 4B | Multi-Hypothesis Motion Prediction (additive only) --
from .hypothesis_types import BehaviourType, TrajectoryHypothesis, TrackHypothesisSet
from .hypothesis_scoring import HypothesisConfig
from .hypothesis_generator import HypothesisGenerator
from .hypothesis_engine import HypothesisEngine, HypothesisWorldResult

__all__ = [
    "ModelType", "TrackLifecycleState",
    "MotionState", "PredictedState", "PredictedObject",
    "PredictionMetrics", "PredictedWorldState",
    "PredictionEngine", "PredictionEngineConfig",
    "PredictionManager",
    "BehaviourType", "TrajectoryHypothesis", "TrackHypothesisSet",
    "HypothesisConfig", "HypothesisGenerator",
    "HypothesisEngine", "HypothesisWorldResult",
]

# -- Phase 4D | TTC + Closest Approach + Collision-Relevant Prediction --
from .phase4d_types import (
    TTCStatus, RiskLevel,
    TTCResult, ClosestApproachResult, HypothesisRisk,
    Phase4DObject, Phase4DMetrics, Phase4DWorldState,
)
from .ttc_engine import compute_ttc, EgoKinematics
from .closest_approach import compute_closest_approach, build_ego_trajectory
from .trajectory_intersection import IntersectionResult, check_trajectory_intersection
from .collision_likelihood import (
    compute_collision_likelihood, compute_hypothesis_risks, classify_risk_level,
)
from .phase4d_pipeline import Phase4DPipeline, Phase4DConfig
