"""
IndiDrive AI — Phase 4D | Collision Likelihood Engine
======================================================
Deterministic risk scoring: same input → identical output.
NOT a calibrated machine-learning probability (per spec requirement 5).
Exposed as `collision_likelihood` — a deterministic risk score in [0, 1].

Factors:
    1. Trajectory overlap (from IntersectionResult)
    2. Distance / TTC
    3. Relative velocity (closing speed)
    4. Uncertainty (prediction confidence, sigma)
    5. Object geometry (when available)
    6. Hypothesis probability (per-hypothesis weighting)

Also evaluates per-hypothesis risk (spec requirement 6) and assigns
RiskLevel (spec requirement 7).
"""
from __future__ import annotations

import math
from typing import List, Optional

from .phase4d_types import (
    TTCResult, TTCStatus, ClosestApproachResult,
    HypothesisRisk, RiskLevel,
)
from .trajectory_intersection import IntersectionResult
from .hypothesis_types import TrackHypothesisSet, BehaviourType

__all__ = [
    "compute_collision_likelihood",
    "compute_hypothesis_risks",
    "classify_risk_level",
]

# ---- risk level thresholds (deterministic) ----
_CRITICAL_THRESHOLD = 0.75
_HIGH_THRESHOLD = 0.50
_MEDIUM_THRESHOLD = 0.25


def classify_risk_level(likelihood: float) -> RiskLevel:
    """Map a [0,1] likelihood score to a discrete RiskLevel."""
    if likelihood >= _CRITICAL_THRESHOLD:
        return RiskLevel.CRITICAL
    if likelihood >= _HIGH_THRESHOLD:
        return RiskLevel.HIGH
    if likelihood >= _MEDIUM_THRESHOLD:
        return RiskLevel.MEDIUM
    return RiskLevel.LOW


def _safe(v, default: float = 0.0) -> float:
    if isinstance(v, (int, float)) and math.isfinite(v):
        return float(v)
    return default


def _clamp(v: float, lo: float = 0.0, hi: float = 1.0) -> float:
    return max(lo, min(hi, v))


def compute_collision_likelihood(
    ttc: TTCResult,
    closest_approach: Optional[ClosestApproachResult],
    intersection: IntersectionResult,
    prediction_confidence: float,
    uncertainty: dict,
    object_type: str = "UNKNOWN",
    obj_width_m: float = 1.8,
    obj_length_m: float = 4.5,
    max_ttc_horizon_s: float = 5.0,
) -> float:
    """
    Compute a deterministic collision likelihood score in [0, 1].

    Score is a weighted combination of:
        w1: TTC factor       (closer TTC = higher risk)
        w2: Distance factor  (closer = higher risk)
        w3: Intersection     (overlap = high base risk)
        w4: Velocity factor  (higher closing speed = higher risk)
        w5: Uncertainty      (low confidence = higher risk)

    NOTE: This is a deterministic heuristic score, not a calibrated
    probability (spec requirement 5).
    """
    score = 0.0

    # ---- w1: TTC factor (weight 0.35) ----
    w_ttc = 0.35
    if ttc.status == TTCStatus.FINITE and ttc.ttc_s is not None:
        t = _safe(ttc.ttc_s)
        if t <= 0.0:
            ttc_score = 1.0
        elif t >= max_ttc_horizon_s:
            ttc_score = 0.0
        else:
            # Non-linear: risk rises sharply as TTC approaches 0
            ttc_score = 1.0 - (t / max_ttc_horizon_s) ** 0.5
    elif ttc.status == TTCStatus.NO_COLLISION:
        ttc_score = 0.0
    else:
        # UNKNOWN — use moderate contribution to be conservative
        ttc_score = 0.3
    score += w_ttc * ttc_score

    # ---- w2: distance factor (weight 0.25) ----
    w_dist = 0.25
    if closest_approach is not None:
        d = _safe(closest_approach.minimum_distance_m, default=100.0)
        # Beyond 50 m: negligible risk from distance alone
        dist_score = _clamp(1.0 - d / 50.0)
    else:
        dist_score = 0.2  # uncertain
    score += w_dist * dist_score

    # ---- w3: trajectory intersection (weight 0.25) ----
    w_intersect = 0.25
    if intersection.intersects:
        # Scale by overlap density
        overlap_frac = _clamp(intersection.overlap_count / 10.0)
        intersect_score = 0.6 + 0.4 * overlap_frac
    else:
        # Use separation as a proximity signal
        sep = _safe(intersection.min_separation_m, default=50.0)
        intersect_score = _clamp(1.0 - sep / 20.0) * 0.5
    score += w_intersect * intersect_score

    # ---- w4: closing velocity (weight 0.10) ----
    w_vel = 0.10
    if ttc.closing_speed_ms is not None:
        cs = _safe(ttc.closing_speed_ms)
        # 30 m/s = saturation (~108 km/h)
        vel_score = _clamp(max(0.0, cs) / 30.0)
    else:
        vel_score = 0.1
    score += w_vel * vel_score

    # ---- w5: uncertainty factor (weight 0.05) ----
    w_unc = 0.05
    conf = _safe(prediction_confidence, default=0.5)
    # Lower confidence = slightly higher risk contribution
    unc_score = _clamp(1.0 - conf)
    score += w_unc * unc_score

    return _clamp(score)


def _hypothesis_collision_likelihood(
    behaviour: BehaviourType,
    base_likelihood: float,
    ttc: TTCResult,
    closest_approach: Optional[ClosestApproachResult],
    intersection: IntersectionResult,
) -> float:
    """
    Per-hypothesis likelihood modifier.
    The modifier scales the base likelihood by a behaviour factor.

    BRAKING / STRAIGHT → lower risk than turning / accelerating
    LEFT / RIGHT / ACCELERATION → higher potential risk
    """
    behaviour_modifiers = {
        BehaviourType.STRAIGHT: 0.9,
        BehaviourType.LEFT: 1.2,
        BehaviourType.RIGHT: 1.1,
        BehaviourType.BRAKING: 0.7,
        BehaviourType.ACCELERATION: 1.3,
    }
    modifier = behaviour_modifiers.get(behaviour, 1.0)

    # Base score derived from TTC and distance for this hypothesis
    score = base_likelihood * modifier
    return _clamp(score)


def compute_hypothesis_risks(
    hyp_set: Optional[TrackHypothesisSet],
    base_likelihood: float,
    ttc: TTCResult,
    closest_approach: Optional[ClosestApproachResult],
    intersection: IntersectionResult,
) -> List[HypothesisRisk]:
    """
    Evaluate per-hypothesis collision likelihood and risk level.
    Result is probability-weighted to reflect each hypothesis's
    contribution to overall risk.
    """
    if hyp_set is None or not hyp_set.hypotheses:
        return []

    results = []
    for h in hyp_set.hypotheses:
        prob = _safe(h.probability, default=0.0)
        if prob <= 0.0:
            continue
        hyp_likelihood = _hypothesis_collision_likelihood(
            h.behaviour, base_likelihood, ttc, closest_approach, intersection
        )
        # Weight the per-hypothesis likelihood by the hypothesis probability
        weighted = hyp_likelihood * prob
        results.append(HypothesisRisk(
            behaviour=h.behaviour.value,
            probability=prob,
            collision_likelihood=_clamp(hyp_likelihood),
            risk_level=classify_risk_level(_clamp(weighted)),
        ))

    return results
