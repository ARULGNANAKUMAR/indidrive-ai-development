"""
IndiDrive AI — Phase 4C | Indian-Road Behaviour, Uncertainty & Sensor
Degradation Pipeline
===========================================================================
Composes on top of Phase 4A (`PredictionEngine`) and Phase 4B
(`HypothesisEngine`) without modifying either: this module is the only
new orchestration layer, consuming their public outputs
(`PredictedWorldState`, `HypothesisWorldResult`) plus the read-only
`PredictionEngine.history` / `.lifecycle` accessors.

Per fused object, one cycle does:

    Phase 4A predict -> Phase 4B hypotheses -> Phase 4C:
        object behaviour class (object_behaviour.py)
        sensor degradation tier (sensor_quality.py)
        extended uncertainty (uncertainty_engine.py)
        fast/deep path decision (path_selector.py)

Tracks with no fresh measurement this cycle but still ACTIVE-ish in
Phase 4A's lifecycle (TEMPORARILY_LOST / STALE) are coasted forward
(lost_track_predictor.py) instead of silently disappearing.
"""
from __future__ import annotations

import math
import statistics
import time
from dataclasses import dataclass, field
from typing import Optional

from core.perception.perception_types import HealthState
from core.fusion.fusion_types import FusedWorldState, FusedObject

from .prediction_engine import PredictionEngine, PredictionEngineConfig
from .prediction_types import PredictedWorldState, PredictedObject, TrackLifecycleState
from .hypothesis_engine import HypothesisEngine, HypothesisWorldResult
from .hypothesis_scoring import HypothesisConfig
from .hypothesis_types import BehaviourType

from .object_behaviour import classify_object, get_profile
from .sensor_quality import classify_sensor_quality, SensorQuality
from .uncertainty_engine import UncertaintyFactors, compute_uncertainty
from .path_selector import PathDecisionInputs, PredictionPath, select_path
from .lost_track_predictor import coast_track
from .phase4c_types import Phase4CObject, Phase4CWorldState, Phase4CMetrics

__all__ = ["Phase4CPipeline", "Phase4CConfig"]

# A track counts as "unpredictable class" for routing purposes once its
# behaviour prior's unpredictability exceeds this.
UNPREDICTABLE_CLASS_THRESHOLD = 1.3

# How many TEMPORARILY_LOST/STALE cycles we keep coasting a track for
# before giving up on it even if Phase 4A hasn't deleted it yet.
MAX_COAST_CYCLES_TRACKED = True  # Phase 4A's own DELETE_AFTER_MISSES governs the hard cutoff.


def _finite(*values) -> bool:
    return all(isinstance(v, (int, float)) and math.isfinite(v) for v in values)


def _std(values: list) -> Optional[float]:
    clean = [v for v in values if isinstance(v, (int, float)) and math.isfinite(v)]
    if len(clean) < 2:
        return 0.0 if clean else None
    return statistics.pstdev(clean)


@dataclass
class Phase4CConfig:
    prediction: PredictionEngineConfig = field(default_factory=PredictionEngineConfig)
    hypothesis: HypothesisConfig = field(default_factory=HypothesisConfig)
    history_window: int = 6   # how many recent history samples feed stability stats


class Phase4CPipeline:
    """Stateful across calls (owns the Phase 4A engine, Phase 4B engine,
    and its own record of each track's last real prediction for
    coasting)."""

    def __init__(self, config: Phase4CConfig = None):
        self.config = config or Phase4CConfig()
        self._engine = PredictionEngine(config=self.config.prediction)
        self._hyp_engine = HypothesisEngine(config=self.config.hypothesis)
        self._last_known: dict[str, PredictedObject] = {}

    # -- per-object enrichment ----------------------------------------------

    def _sensor_quality_for(self, fused: Optional[FusedObject], fusion_mode: str,
                             fallback_confidence: float) -> SensorQuality:
        if fused is None:
            return classify_sensor_quality(
                fusion_mode=fusion_mode, sensor_count=None,
                quality=fallback_confidence, position_confidence=fallback_confidence,
            )
        return classify_sensor_quality(
            fusion_mode=fusion_mode, sensor_count=fused.sensor_count,
            quality=fused.quality, position_confidence=fused.position_confidence,
        )

    def _stability_stats(self, track_id: str) -> tuple:
        entries = self._engine.history.get_history(track_id)
        window = entries[-self.config.history_window:] if entries else []
        vx = [e.vx for e in window]
        vy = [e.vy for e in window]
        speeds = [math.hypot(e.vx, e.vy) for e in window]
        accels = [math.hypot(e.ax, e.ay) for e in window]
        headings = [e.heading for e in window]
        velocity_std = _std(speeds)
        acceleration_std = _std(accels)
        heading_std = _std(headings)
        return velocity_std, acceleration_std, heading_std, len(entries)

    def _enrich_one(
        self, predicted_obj: PredictedObject, fused_map: dict, fusion_mode: str,
        hyp_result: HypothesisWorldResult,
    ) -> Phase4CObject:
        track_id = predicted_obj.track_id
        fused = fused_map.get(track_id)

        sensor_quality = self._sensor_quality_for(fused, fusion_mode, predicted_obj.prediction_confidence)
        behaviour_class = classify_object(predicted_obj.object_type)
        profile = get_profile(predicted_obj.object_type)

        hyp_set = hyp_result.tracks.get(track_id)
        is_stable = hyp_set.is_stable if hyp_set is not None else True
        best_hyp = hyp_set.best() if hyp_set is not None else None
        sudden_accel = bool(best_hyp and best_hyp.behaviour == BehaviourType.ACCELERATION)
        sudden_brake = bool(best_hyp and best_hyp.behaviour == BehaviourType.BRAKING)

        velocity_std, acceleration_std, heading_std, track_age = self._stability_stats(track_id)

        horizon_s = max((p.horizon_s for p in predicted_obj.trajectory), default=0.0)
        base_sigma = None
        if predicted_obj.uncertainty:
            base_sigma = max(
                predicted_obj.uncertainty.get("sigma_x", 0.0),
                predicted_obj.uncertainty.get("sigma_y", 0.0),
            ) or None

        result = compute_uncertainty(UncertaintyFactors(
            horizon_s=horizon_s, object_type=predicted_obj.object_type, base_sigma=base_sigma,
            velocity_std=velocity_std, acceleration_std=acceleration_std, heading_std=heading_std,
            sensor_quality=sensor_quality, track_age_cycles=track_age, lost_duration_s=0.0,
            base_confidence=predicted_obj.prediction_confidence,
        ))
        predicted_obj.uncertainty = result.to_dict()
        predicted_obj.prediction_confidence = result.confidence

        path = select_path(PathDecisionInputs(
            is_stable=is_stable, sensor_quality=sensor_quality, lost_this_cycle=False,
            sudden_acceleration=sudden_accel, sudden_braking=sudden_brake,
            unpredictable_class=profile.unpredictability > UNPREDICTABLE_CLASS_THRESHOLD,
        ))

        return Phase4CObject(
            predicted=predicted_obj, behaviour_class=behaviour_class,
            sensor_quality=sensor_quality, prediction_path=path, coasted=False,
        )

    # -- main entry point -----------------------------------------------

    def process(self, world_state: FusedWorldState) -> Phase4CWorldState:
        metrics = Phase4CMetrics()
        overall_start = time.perf_counter()
        warnings: list = []

        predicted: PredictedWorldState = self._engine.process(world_state)
        hyp_result: HypothesisWorldResult = self._hyp_engine.process(predicted, history=self._engine.history)
        warnings.extend(predicted.warnings)
        warnings.extend(hyp_result.warnings)

        fused_map = {
            (obj.track_id or obj.fused_object_id): obj for obj in world_state.objects
        }
        fusion_mode = world_state.fusion_mode.value if hasattr(world_state.fusion_mode, "value") else str(world_state.fusion_mode)

        out_objects: list = []
        seen_ids = set()

        t0 = time.perf_counter()
        for p in predicted.objects:
            enriched = self._enrich_one(p, fused_map, fusion_mode, hyp_result)
            out_objects.append(enriched)
            seen_ids.add(p.track_id)
            self._last_known[p.track_id] = p
        metrics.behaviour_latency_ms = (time.perf_counter() - t0) * 1000.0
        metrics.uncertainty_latency_ms = metrics.behaviour_latency_ms

        # -- coast tracks that are known but weren't seen this cycle -----
        t0 = time.perf_counter()
        for track_id, last_obj in list(self._last_known.items()):
            if track_id in seen_ids:
                continue
            lifecycle_state = self._engine.lifecycle.get_state(track_id)
            if lifecycle_state == TrackLifecycleState.DELETED:
                self._last_known.pop(track_id, None)
                continue
            # spec section 11: coast through *any* missed cycle (not just
            # once the lifecycle has formally downgraded to
            # TEMPORARILY_LOST/STALE) -- a single missed measurement still
            # gets a short-term continued prediction.

            lifecycle_confidence = self._engine.lifecycle.get_confidence(track_id)
            _, _, _, track_age = self._stability_stats(track_id)
            coasted_obj = coast_track(
                last_object=last_obj, now_ts=world_state.timestamp,
                horizons_s=self.config.prediction.horizons_s,
                lifecycle_state=lifecycle_state, lifecycle_confidence=lifecycle_confidence,
                track_age_cycles=track_age,
            )
            if coasted_obj is None:
                continue

            behaviour_class = classify_object(coasted_obj.object_type)
            profile = get_profile(coasted_obj.object_type)
            sensor_quality = SensorQuality.LOW_CONFIDENCE
            path = select_path(PathDecisionInputs(
                is_stable=False, sensor_quality=sensor_quality, lost_this_cycle=True,
                unpredictable_class=profile.unpredictability > UNPREDICTABLE_CLASS_THRESHOLD,
            ))
            out_objects.append(Phase4CObject(
                predicted=coasted_obj, behaviour_class=behaviour_class,
                sensor_quality=sensor_quality, prediction_path=path, coasted=True,
            ))
            warnings.extend(coasted_obj.warnings)
        metrics.lost_track_latency_ms = (time.perf_counter() - t0) * 1000.0

        total_latency_ms = (time.perf_counter() - overall_start) * 1000.0
        metrics.prediction_latency_ms = predicted.metrics.prediction_latency_ms
        metrics.track_update_latency_ms = predicted.metrics.track_update_latency_ms
        metrics.kalman_latency_ms = predicted.metrics.kalman_latency_ms
        metrics.model_selection_latency_ms = predicted.metrics.model_selection_latency_ms
        metrics.trajectory_generation_latency_ms = predicted.metrics.trajectory_generation_latency_ms
        n_objects = len(out_objects)
        if total_latency_ms > 0:
            metrics.objects_per_second = n_objects / (total_latency_ms / 1000.0)
            metrics.prediction_fps = 1000.0 / total_latency_ms

        if not world_state.objects and not out_objects:
            health = HealthState.NOT_AVAILABLE
        elif n_objects == 0:
            health = HealthState.FAILED
        elif warnings:
            health = HealthState.DEGRADED
        else:
            health = predicted.prediction_health

        return Phase4CWorldState(
            timestamp=world_state.timestamp, frame_id=world_state.frame_id,
            objects=out_objects, prediction_health=health,
            warnings=warnings, metrics=metrics,
        )

    def reset(self) -> None:
        self._engine.reset()
        self._last_known.clear()
