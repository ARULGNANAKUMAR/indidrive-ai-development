"""
IndiDrive AI — Phase 4C | Data Contracts
=============================================
Mirrors Phase 4A/4B's philosophy: dataclasses, explicit fields, a
`to_dict()` on everything. Phase 4C never replaces a Phase 4A
PredictedObject or a Phase 4B TrackHypothesisSet -- it wraps them with
the extra behaviour/uncertainty/path context this phase adds.
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Optional

from core.perception.perception_types import HealthState

from .prediction_types import PredictedObject, PredictionMetrics
from .object_behaviour import ObjectBehaviourClass
from .sensor_quality import SensorQuality
from .path_selector import PredictionPath

__all__ = ["Phase4CMetrics", "Phase4CObject", "Phase4CWorldState"]


@dataclass
class Phase4CMetrics(PredictionMetrics):
    behaviour_latency_ms: float = 0.0
    uncertainty_latency_ms: float = 0.0
    lost_track_latency_ms: float = 0.0

    def to_dict(self) -> dict:
        base = super().to_dict()
        base.update({
            "behaviour_latency_ms": round(self.behaviour_latency_ms, 3),
            "uncertainty_latency_ms": round(self.uncertainty_latency_ms, 3),
            "lost_track_latency_ms": round(self.lost_track_latency_ms, 3),
        })
        return base


@dataclass
class Phase4CObject:
    """One track's Phase 4C-enriched output for one cycle."""
    predicted: PredictedObject
    behaviour_class: ObjectBehaviourClass
    sensor_quality: SensorQuality
    prediction_path: PredictionPath
    coasted: bool = False   # True if this cycle had no fresh measurement

    @property
    def track_id(self) -> str:
        return self.predicted.track_id

    def to_dict(self) -> dict:
        d = self.predicted.to_dict()
        d["behaviour_class"] = self.behaviour_class.value
        d["sensor_quality"] = self.sensor_quality.value
        d["prediction_path"] = self.prediction_path.value
        d["coasted"] = self.coasted
        return d


@dataclass
class Phase4CWorldState:
    timestamp: float
    frame_id: int
    objects: list = field(default_factory=list)   # list[Phase4CObject]
    prediction_health: HealthState = HealthState.NOT_CONFIGURED
    warnings: list = field(default_factory=list)
    metrics: Phase4CMetrics = field(default_factory=Phase4CMetrics)
    created_at: float = field(default_factory=time.time)

    def to_dict(self) -> dict:
        return {
            "timestamp": self.timestamp,
            "frame_id": self.frame_id,
            "objects": [o.to_dict() for o in self.objects],
            "prediction_health": self.prediction_health.value,
            "warnings": self.warnings,
            "metrics": self.metrics.to_dict(),
        }
