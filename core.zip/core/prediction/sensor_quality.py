"""
IndiDrive AI — Phase 4C | Sensor Degradation Classification
=================================================================
Turns Phase 3 fusion health signals (FusionMode, per-object quality/
confidence) into one of four deterministic tiers (spec section 10):

    FULL_FUSION      -- all contributing sensors agree, high quality
    PARTIAL_FUSION    -- two sensors, or full fusion with reduced quality
    SINGLE_SENSOR     -- exactly one contributing sensor
    LOW_CONFIDENCE    -- quality/confidence too low to trust regardless
                         of how many sensors contributed (including
                         NO_VALID_SENSOR)

Pure classification only — no prediction logic here. Never invents a
confidence value: everything is read from what Phase 3 already
reports (FusedObject.quality / position_confidence / source_sensors,
FusedWorldState.fusion_mode).
"""
from __future__ import annotations

import math
from dataclasses import dataclass
from enum import Enum
from typing import Optional

__all__ = [
    "SensorQuality", "classify_sensor_quality", "uncertainty_multiplier",
    "confidence_multiplier",
]

# Below this, we don't trust the fused object regardless of sensor count.
LOW_CONFIDENCE_THRESHOLD = 0.35


class SensorQuality(str, Enum):
    FULL_FUSION = "FULL_FUSION"
    PARTIAL_FUSION = "PARTIAL_FUSION"
    SINGLE_SENSOR = "SINGLE_SENSOR"
    LOW_CONFIDENCE = "LOW_CONFIDENCE"


def _finite(v) -> bool:
    return isinstance(v, (int, float)) and math.isfinite(v)


def classify_sensor_quality(
    *, fusion_mode: Optional[str] = None, sensor_count: Optional[int] = None,
    quality: float = 0.0, position_confidence: float = 0.0,
) -> SensorQuality:
    """`fusion_mode`/`sensor_count` are best-effort context (world- and
    object-level respectively); either may be unavailable, in which
    case classification falls back to whichever signal is present."""
    q = quality if _finite(quality) else 0.0
    pc = position_confidence if _finite(position_confidence) else 0.0
    trust = max(q, pc)

    if trust < LOW_CONFIDENCE_THRESHOLD or fusion_mode == "NO_VALID_SENSOR":
        return SensorQuality.LOW_CONFIDENCE

    count = sensor_count if isinstance(sensor_count, int) else None
    if count is None and isinstance(fusion_mode, str):
        if fusion_mode == "FULL_FUSION":
            count = 3
        elif fusion_mode == "PARTIAL_FUSION":
            count = 2
        elif fusion_mode == "SINGLE_SENSOR":
            count = 1

    if count is not None:
        if count >= 3:
            return SensorQuality.FULL_FUSION
        if count == 2:
            return SensorQuality.PARTIAL_FUSION
        if count == 1:
            return SensorQuality.SINGLE_SENSOR
        return SensorQuality.LOW_CONFIDENCE

    # No sensor-count signal at all -- fall back to trust alone.
    if trust >= 0.8:
        return SensorQuality.FULL_FUSION
    if trust >= 0.5:
        return SensorQuality.PARTIAL_FUSION
    return SensorQuality.SINGLE_SENSOR


# Deterministic uncertainty scale-up per tier (multiplies sigma).
_UNCERTAINTY_MULTIPLIER = {
    SensorQuality.FULL_FUSION: 1.0,
    SensorQuality.PARTIAL_FUSION: 1.35,
    SensorQuality.SINGLE_SENSOR: 1.8,
    SensorQuality.LOW_CONFIDENCE: 2.5,
}

# Deterministic confidence scale-down per tier (multiplies confidence).
_CONFIDENCE_MULTIPLIER = {
    SensorQuality.FULL_FUSION: 1.0,
    SensorQuality.PARTIAL_FUSION: 0.85,
    SensorQuality.SINGLE_SENSOR: 0.65,
    SensorQuality.LOW_CONFIDENCE: 0.4,
}


def uncertainty_multiplier(quality: SensorQuality) -> float:
    return _UNCERTAINTY_MULTIPLIER.get(quality, 1.0)


def confidence_multiplier(quality: SensorQuality) -> float:
    return _CONFIDENCE_MULTIPLIER.get(quality, 1.0)
