"""
IndiDrive AI — Phase 4D | Trajectory Intersection
===================================================
Compares ego motion against predicted object trajectories to detect
spatial overlap within a tolerance (collision box).

Uses actual predicted trajectories from Phase 4A/4B/4C.
Does NOT create a full planner (spec requirement 4).
"""
from __future__ import annotations

import math
from dataclasses import dataclass
from typing import List, Optional, Tuple

from .prediction_types import PredictedState

__all__ = [
    "IntersectionResult", "check_trajectory_intersection",
]

_DEFAULT_EGO_HALF_WIDTH = 0.95   # metres (half of ~1.9 m car width)
_DEFAULT_EGO_HALF_LENGTH = 2.5   # metres (half of ~5 m car length)
_DEFAULT_OBJ_HALF_WIDTH = 1.0    # conservative default


@dataclass
class IntersectionResult:
    intersects: bool
    earliest_intersection_s: Optional[float]   # None if no intersection
    overlap_count: int                          # how many horizon samples overlap
    min_separation_m: float                     # minimum separation across all horizons

    def to_dict(self) -> dict:
        return {
            "intersects": self.intersects,
            "earliest_intersection_s": (
                round(self.earliest_intersection_s, 4)
                if self.earliest_intersection_s is not None else None
            ),
            "overlap_count": self.overlap_count,
            "min_separation_m": round(self.min_separation_m, 4),
        }


def _safe(v) -> Optional[float]:
    if isinstance(v, (int, float)) and math.isfinite(v):
        return float(v)
    return None


def _ego_pos_at(ego_traj: List[PredictedState], t: float,
                 fallback_x: float, fallback_y: float,
                 fallback_vx: float, fallback_vy: float) -> Tuple[float, float]:
    """Interpolate/extrapolate ego position at time t."""
    if not ego_traj:
        return (fallback_x + fallback_vx * t, fallback_y + fallback_vy * t)
    if t <= ego_traj[0].horizon_s:
        s = ego_traj[0]
        return s.x, s.y
    if t >= ego_traj[-1].horizon_s:
        s = ego_traj[-1]
        dt = t - s.horizon_s
        return s.x + s.vx * dt, s.y + s.vy * dt
    for i in range(len(ego_traj) - 1):
        s0, s1 = ego_traj[i], ego_traj[i + 1]
        if s0.horizon_s <= t <= s1.horizon_s:
            span = s1.horizon_s - s0.horizon_s
            if span < 1e-9:
                return s0.x, s0.y
            alpha = (t - s0.horizon_s) / span
            return s0.x + alpha * (s1.x - s0.x), s0.y + alpha * (s1.y - s0.y)
    s = ego_traj[-1]
    dt = t - s.horizon_s
    return s.x + s.vx * dt, s.y + s.vy * dt


def check_trajectory_intersection(
    ego_trajectory: List[PredictedState],
    obj_trajectory: List[PredictedState],
    ego_half_width: float = _DEFAULT_EGO_HALF_WIDTH,
    ego_half_length: float = _DEFAULT_EGO_HALF_LENGTH,
    obj_half_width: float = _DEFAULT_OBJ_HALF_WIDTH,
    obj_half_length: float = _DEFAULT_OBJ_HALF_WIDTH,
    ego_fallback_x: float = 0.0,
    ego_fallback_y: float = 0.0,
    ego_fallback_vx: float = 0.0,
    ego_fallback_vy: float = 0.0,
) -> IntersectionResult:
    """
    For each object trajectory horizon sample, check if the object's
    bounding circle overlaps with the ego's bounding circle at the same
    horizon.  Uses circle approximation (conservative):
        collision_r = ego_half_diag + obj_half_diag
    """
    ego_diag = math.sqrt(ego_half_width ** 2 + ego_half_length ** 2)
    obj_diag = math.sqrt(obj_half_width ** 2 + obj_half_length ** 2)
    collision_r = ego_diag + obj_diag

    earliest_t: Optional[float] = None
    overlap_count = 0
    min_sep = float("inf")

    for os in obj_trajectory:
        t = _safe(os.horizon_s)
        ox = _safe(os.x)
        oy = _safe(os.y)
        if t is None or ox is None or oy is None:
            continue
        ex, ey = _ego_pos_at(ego_trajectory, t, ego_fallback_x, ego_fallback_y,
                              ego_fallback_vx, ego_fallback_vy)
        sep = math.sqrt((ox - ex) ** 2 + (oy - ey) ** 2) - collision_r
        if sep < min_sep:
            min_sep = sep
        if sep <= 0.0:
            overlap_count += 1
            if earliest_t is None:
                earliest_t = t

    if min_sep == float("inf"):
        min_sep = float("nan")
        min_sep = 0.0

    return IntersectionResult(
        intersects=(overlap_count > 0),
        earliest_intersection_s=earliest_t,
        overlap_count=overlap_count,
        min_separation_m=max(0.0, min_sep) if overlap_count == 0 else 0.0,
    )
