"""
IndiDrive AI — Phase 4A | Prediction Engine
================================================
Turns one Phase 3 `FusedWorldState` into one `PredictedWorldState`.

Pipeline per fused object (spec section 12):

    Fused Object
      -> Track History      (bounded buffer; derives accel/yaw_rate)
      -> Kalman Predict      (project filter forward by dt)
      -> Measurement Update  (fold in this cycle's x,y)
      -> Filtered Motion State
      -> Model Selector       (CV / CA / CTRV, deterministic)
      -> Motion Model         (rolls the filtered state out to each horizon)
      -> Future States + growing uncertainty

Phase 3 does not import anything from here (core/fusion/ has zero
knowledge of core/prediction/) — this module only ever imports Phase 3
*types*, never the other way around (spec section 12, "do not make
Phase 3 depend on Phase 4").
"""
from __future__ import annotations

import math
import time
from dataclasses import dataclass, field
from typing import Optional

from core.perception.perception_types import HealthState
from core.fusion.fusion_types import FusedWorldState, FusedObject

from .prediction_types import (
    MotionState, PredictedState, PredictedObject, PredictionMetrics,
    PredictedWorldState, ModelType, TrackLifecycleState,
)
from .motion_models import predict as predict_motion
from .kalman_filter import KalmanFilterCV
from .track_history import TrackHistoryManager, DEFAULT_MAX_HISTORY
from .track_lifecycle import TrackLifecycleManager, TrackLifecycleConfig
from .model_selector import ModelSelector, ModelSelectorConfig

DEFAULT_HORIZONS_S = (0.25, 0.5, 1.0, 1.5, 2.0, 3.0, 5.0)


def _finite(*values) -> bool:
    return all(isinstance(v, (int, float)) and math.isfinite(v) for v in values)


@dataclass
class KalmanConfig:
    process_noise: float = 1.0
    measurement_noise: float = 0.5
    initial_position_variance: float = 10.0
    initial_velocity_variance: float = 100.0


@dataclass
class PredictionEngineConfig:
    enabled: bool = True
    deterministic: bool = True
    horizons_s: tuple = DEFAULT_HORIZONS_S
    max_track_history: int = DEFAULT_MAX_HISTORY
    kalman: KalmanConfig = field(default_factory=KalmanConfig)
    model_selector: ModelSelectorConfig = field(default_factory=ModelSelectorConfig)
    lifecycle: TrackLifecycleConfig = field(default_factory=TrackLifecycleConfig)


def _validate_fused_object(obj: FusedObject, now_ts: float) -> Optional[str]:
    """Returns None if the object is usable, otherwise a short reason
    string explaining why it must be skipped (spec section 15 — never
    crash the pipeline over one bad object)."""
    if not _finite(obj.timestamp) or obj.timestamp <= 0:
        return "invalid timestamp"
    if obj.position_3d is None:
        return "missing position"
    p = obj.position_3d
    if not _finite(p.x, p.y, p.z):
        return "non-finite position"
    if obj.velocity is not None and not _finite(*obj.velocity):
        return "non-finite velocity"
    if obj.heading is not None and not _finite(obj.heading):
        return "non-finite heading"
    return None


class PredictionEngine:
    """Stateful across calls (Kalman filters + track history + track
    lifecycle all persist between process() calls for the lifetime of
    one engine instance)."""

    def __init__(self, config: PredictionEngineConfig = None):
        self.config = config or PredictionEngineConfig()
        self._history = TrackHistoryManager(max_history=self.config.max_track_history)
        self._lifecycle = TrackLifecycleManager(config=self.config.lifecycle)
        self._selector = ModelSelector(config=self.config.model_selector)
        self._filters: dict[str, KalmanFilterCV] = {}
        self._last_update_ts: dict[str, float] = {}

    # -- per-track helpers --------------------------------------------------

    def _get_filter(self, track_id: str) -> KalmanFilterCV:
        kf = self._filters.get(track_id)
        if kf is None:
            kf = KalmanFilterCV(
                process_noise=self.config.kalman.process_noise,
                measurement_noise=self.config.kalman.measurement_noise,
                initial_position_variance=self.config.kalman.initial_position_variance,
                initial_velocity_variance=self.config.kalman.initial_velocity_variance,
            )
            self._filters[track_id] = kf
        return kf

    def _drop_track(self, track_id: str) -> None:
        self._filters.pop(track_id, None)
        self._last_update_ts.pop(track_id, None)
        self._history.remove_track(track_id)

    def _project_covariance(self, kf: KalmanFilterCV, dt: float) -> Optional[list]:
        """Read-only covariance projection: clones the filter's current
        (x, P) and runs predict(dt) on the clone so we can report
        growing uncertainty per horizon without mutating the real
        filter (which must only advance by real elapsed time)."""
        state = kf.get_state()
        cov = kf.get_covariance()
        if state is None or cov is None:
            return None
        clone = KalmanFilterCV(
            process_noise=kf.process_noise,
            measurement_noise=kf.measurement_noise,
        )
        clone.x = kf.x.copy()
        clone.P = kf.P.copy()
        clone._initialized = True
        clone.predict(dt)
        return clone.get_covariance()

    def _std_devs_from_cov(self, cov: Optional[list]) -> Optional[dict]:
        if cov is None:
            return None
        try:
            sigma_x = math.sqrt(max(0.0, cov[0][0]))
            sigma_y = math.sqrt(max(0.0, cov[1][1]))
            sigma_vx = math.sqrt(max(0.0, cov[2][2]))
            sigma_vy = math.sqrt(max(0.0, cov[3][3]))
        except (IndexError, TypeError, ValueError):
            return None
        return {"sigma_x": sigma_x, "sigma_y": sigma_y, "sigma_vx": sigma_vx, "sigma_vy": sigma_vy}

    # -- main entry point --------------------------------------------------

    def process(self, world_state: FusedWorldState) -> PredictedWorldState:
        metrics = PredictionMetrics()
        overall_start = time.perf_counter()
        warnings: list = []
        predicted_objects: list = []

        if not self.config.enabled:
            return PredictedWorldState(
                timestamp=world_state.timestamp, frame_id=world_state.frame_id,
                objects=[], prediction_health=HealthState.NOT_CONFIGURED,
                warnings=["prediction disabled"], metrics=metrics,
            )

        seen_track_ids: set = set()

        for obj in world_state.objects:
            reason = _validate_fused_object(obj, world_state.timestamp)
            if reason is not None:
                warnings.append(f"skipped object {obj.fused_object_id}: {reason}")
                continue

            track_id = obj.track_id or obj.fused_object_id
            seen_track_ids.add(track_id)

            # -- track history -------------------------------------------
            t0 = time.perf_counter()
            vx, vy, vz = obj.velocity if obj.velocity is not None else (0.0, 0.0, 0.0)
            heading = obj.heading if obj.heading is not None else 0.0
            entry = self._history.add_measurement(
                track_id, timestamp=obj.timestamp,
                x=obj.position_3d.x, y=obj.position_3d.y, z=obj.position_3d.z,
                vx=vx, vy=vy, vz=vz, heading=heading,
                confidence=obj.position_confidence,
            )
            self._lifecycle.observe(track_id, seen=True)
            metrics.track_update_latency_ms += (time.perf_counter() - t0) * 1000.0

            # -- kalman filter --------------------------------------------
            t0 = time.perf_counter()
            kf = self._get_filter(track_id)
            prev_ts = self._last_update_ts.get(track_id)
            if not kf.is_initialized:
                kf.initialize(entry.x, entry.y, vx=entry.vx, vy=entry.vy)
            else:
                dt = obj.timestamp - prev_ts if prev_ts is not None else 0.0
                kf.predict(dt)
                kf.update(entry.x, entry.y)
            self._last_update_ts[track_id] = obj.timestamp
            filtered = kf.get_state()  # (x, y, vx, vy)
            metrics.kalman_latency_ms += (time.perf_counter() - t0) * 1000.0

            if filtered is None:
                warnings.append(f"skipped object {obj.fused_object_id}: kalman filter unavailable")
                continue
            fx, fy, fvx, fvy = filtered

            current_state = MotionState(
                x=fx, y=fy, z=entry.z,
                vx=fvx, vy=fvy, vz=entry.vz,
                ax=entry.ax, ay=entry.ay, az=entry.az,
                yaw=heading, yaw_rate=entry.yaw_rate,
                speed=math.hypot(fvx, fvy), heading=heading,
                timestamp=obj.timestamp,
            )
            if not current_state.is_valid():
                warnings.append(f"skipped object {obj.fused_object_id}: non-finite filtered state")
                continue

            # -- model selection --------------------------------------------
            t0 = time.perf_counter()
            model = self._selector.select(
                speed=current_state.speed, yaw_rate=entry.yaw_rate,
                ax=entry.ax, ay=entry.ay, object_type=obj.object_class,
                measurement_confidence=obj.position_confidence,
            )
            metrics.model_selection_latency_ms += (time.perf_counter() - t0) * 1000.0

            # -- trajectory generation --------------------------------------
            t0 = time.perf_counter()
            trajectory = []
            for h in self.config.horizons_s:
                future = predict_motion(current_state, h, model.value)
                cov = self._project_covariance(kf, h)
                trajectory.append(PredictedState(
                    timestamp=current_state.timestamp + h,
                    x=future.x, y=future.y, z=future.z,
                    vx=future.vx, vy=future.vy, vz=future.vz,
                    yaw=future.yaw, speed=future.speed,
                    horizon_s=h, covariance=cov,
                ))
            metrics.trajectory_generation_latency_ms += (time.perf_counter() - t0) * 1000.0

            final_cov = trajectory[-1].covariance if trajectory else None
            uncertainty = self._std_devs_from_cov(final_cov) or {}

            lifecycle_state = self._lifecycle.get_state(track_id)
            lifecycle_confidence = self._lifecycle.get_confidence(track_id)
            prediction_confidence = max(0.0, min(1.0, lifecycle_confidence * max(obj.existence_probability, obj.position_confidence)))

            predicted_objects.append(PredictedObject(
                track_id=track_id, object_type=obj.object_class,
                current_state=current_state, trajectory=trajectory,
                prediction_confidence=prediction_confidence,
                uncertainty=uncertainty, selected_model=model,
                lifecycle_state=lifecycle_state,
            ))

        # -- lifecycle bookkeeping for tracks not seen this cycle -----------
        for track_id in list(self._lifecycle.active_track_ids()):
            if track_id not in seen_track_ids:
                self._lifecycle.observe(track_id, seen=False)
        deleted = self._lifecycle.purge_deleted()
        for track_id in deleted:
            self._drop_track(track_id)

        total_latency_ms = (time.perf_counter() - overall_start) * 1000.0
        metrics.prediction_latency_ms = total_latency_ms
        n_objects = len(predicted_objects)
        if total_latency_ms > 0:
            metrics.objects_per_second = n_objects / (total_latency_ms / 1000.0)
            metrics.prediction_fps = 1000.0 / total_latency_ms

        if not world_state.objects:
            health = HealthState.NOT_AVAILABLE
        elif n_objects == 0:
            health = HealthState.FAILED
        elif warnings:
            health = HealthState.DEGRADED
        else:
            health = HealthState.HEALTHY

        return PredictedWorldState(
            timestamp=world_state.timestamp, frame_id=world_state.frame_id,
            objects=predicted_objects, prediction_health=health,
            warnings=warnings, metrics=metrics,
        )

    def reset(self) -> None:
        self._history.reset()
        self._lifecycle.reset()
        self._filters.clear()
        self._last_update_ts.clear()

    def active_track_count(self) -> int:
        return len(self._filters)

    # -- Phase 4C read-only accessors ---------------------------------------
    # Additive only: exposes internal state that already existed so a later
    # phase (4C) can compose on top without reimplementing track history /
    # lifecycle bookkeeping. Does not change any Phase 4A/4B behaviour.

    @property
    def history(self) -> TrackHistoryManager:
        return self._history

    @property
    def lifecycle(self) -> TrackLifecycleManager:
        return self._lifecycle
