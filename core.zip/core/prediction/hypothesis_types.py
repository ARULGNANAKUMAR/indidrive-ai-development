"""
IndiDrive AI — Phase 4B | Multi-Hypothesis Data Contracts
==============================================================
Structural containers for Phase 4B. Mirrors Phase 4A's
prediction_types.py philosophy: dataclasses, explicit "unavailable"
states, no logic beyond small helpers.

Nothing here performs hypothesis generation or scoring — see
hypothesis_generator.py and hypothesis_scoring.py.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum

from .prediction_types import ModelType, PredictedState

__all__ = [
    "BehaviourType", "TrajectoryHypothesis", "TrackHypothesisSet",
]


class BehaviourType(str, Enum):
    """The intent/behaviour a hypothesis represents. Independent from
    ModelType (CV/CA/CTRV) — a behaviour is realized using one of the
    Phase 4A motion models, never a new model family."""
    STRAIGHT = "STRAIGHT"
    LEFT = "LEFT"
    RIGHT = "RIGHT"
    BRAKING = "BRAKING"
    ACCELERATION = "ACCELERATION"


@dataclass
class TrajectoryHypothesis:
    """One possible future for a track. `trajectory` uses the exact
    same PredictedState shape and horizons as Phase 4A — Phase 4B
    never introduces a second, incompatible horizon system."""
    track_id: str
    model: ModelType
    behaviour: BehaviourType
    probability: float = 0.0
    confidence: float = 0.0
    trajectory: list = field(default_factory=list)   # list[PredictedState]
    uncertainty: dict = field(default_factory=dict)  # sigma_x/sigma_y/sigma_vx/sigma_vy at final horizon

    def to_dict(self) -> dict:
        return {
            "track_id": self.track_id,
            "model": self.model.value,
            "behaviour": self.behaviour.value,
            "probability": round(self.probability, 6),
            "confidence": round(self.confidence, 6),
            "trajectory": [p.to_dict() for p in self.trajectory],
            "uncertainty": self.uncertainty,
        }


@dataclass
class TrackHypothesisSet:
    """All hypotheses generated for one track_id in one cycle. This is
    what Phase 4B adds to a track — Phase 4A's PredictedObject for the
    same track_id is left untouched (no duplicate identities)."""
    track_id: str
    object_type: str
    is_stable: bool
    hypotheses: list = field(default_factory=list)  # list[TrajectoryHypothesis]

    def best(self):
        if not self.hypotheses:
            return None
        return max(self.hypotheses, key=lambda h: h.probability)

    def to_dict(self) -> dict:
        return {
            "track_id": self.track_id,
            "object_type": self.object_type,
            "is_stable": self.is_stable,
            "hypotheses": [h.to_dict() for h in self.hypotheses],
        }
