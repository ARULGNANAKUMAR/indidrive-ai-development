"""
IndiDrive AI — Phase 4A | Kalman Filter
============================================
A lightweight, dependency-minimal (numpy only — already a hard
requirement via requirements.txt for core/carla_integration/) constant
velocity Kalman filter over state [x, y, vx, vy].

Used to smooth/filter each track's noisy fused-object measurements
before handing the result to the motion models (see
prediction_engine.py). Not the motion model itself — CV/CA/CTRV in
motion_models.py generate the actual future trajectory; this filter
only produces the best current estimate + covariance to seed them.

Numerically defensive by design (spec section 11):
    - invalid/negative/non-finite dt is treated as 0 (no-op predict)
    - NaN/Inf in a measurement causes update() to be skipped, not applied
    - reset() clears state back to an uninitialized filter
    - covariance is exposed via get_covariance()
"""
from __future__ import annotations

import math
from typing import Optional

import numpy as np

STATE_DIM = 4  # [x, y, vx, vy]


def _finite(*values: float) -> bool:
    return all(isinstance(v, (int, float)) and math.isfinite(v) for v in values)


class KalmanFilterCV:
    """Constant-velocity Kalman filter, state = [x, y, vx, vy]."""

    def __init__(
        self,
        process_noise: float = 1.0,
        measurement_noise: float = 0.5,
        initial_position_variance: float = 10.0,
        initial_velocity_variance: float = 100.0,
    ):
        self.process_noise = process_noise
        self.measurement_noise = measurement_noise
        self._initial_position_variance = initial_position_variance
        self._initial_velocity_variance = initial_velocity_variance
        self.x: Optional[np.ndarray] = None   # state vector (4,)
        self.P: Optional[np.ndarray] = None   # covariance (4,4)
        self._initialized = False

    # -- lifecycle ----------------------------------------------------

    def reset(self) -> None:
        self.x = None
        self.P = None
        self._initialized = False

    def initialize(self, x: float, y: float, vx: float = 0.0, vy: float = 0.0) -> None:
        """Seed the filter with a first measurement. Non-finite inputs
        are replaced with 0.0 rather than poisoning the whole filter."""
        x = x if _finite(x) else 0.0
        y = y if _finite(y) else 0.0
        vx = vx if _finite(vx) else 0.0
        vy = vy if _finite(vy) else 0.0
        self.x = np.array([x, y, vx, vy], dtype=float)
        self.P = np.diag([
            self._initial_position_variance, self._initial_position_variance,
            self._initial_velocity_variance, self._initial_velocity_variance,
        ]).astype(float)
        self._initialized = True

    @property
    def is_initialized(self) -> bool:
        return self._initialized

    # -- core KF ops ----------------------------------------------------

    def _F(self, dt: float) -> np.ndarray:
        return np.array([
            [1.0, 0.0, dt, 0.0],
            [0.0, 1.0, 0.0, dt],
            [0.0, 0.0, 1.0, 0.0],
            [0.0, 0.0, 0.0, 1.0],
        ])

    def _Q(self, dt: float) -> np.ndarray:
        """Discretized white-noise-acceleration process noise. Grows
        with dt so uncertainty legitimately increases the further out
        we predict without a new measurement (spec section 13)."""
        q = self.process_noise
        dt2 = dt * dt
        dt3 = dt2 * dt
        dt4 = dt3 * dt
        return q * np.array([
            [dt4 / 4, 0.0,     dt3 / 2, 0.0],
            [0.0,     dt4 / 4, 0.0,     dt3 / 2],
            [dt3 / 2, 0.0,     dt2,     0.0],
            [0.0,     dt3 / 2, 0.0,     dt2],
        ])

    def predict(self, dt: float) -> None:
        """Project the state and covariance forward by dt seconds.
        A non-finite or negative dt is treated as dt=0 (no-op) instead
        of corrupting the filter."""
        if not self._initialized:
            return
        if not isinstance(dt, (int, float)) or not math.isfinite(dt) or dt < 0.0:
            dt = 0.0
        F = self._F(dt)
        Q = self._Q(dt)
        self.x = F @ self.x
        self.P = F @ self.P @ F.T + Q
        self._sanitize()

    def update(self, z_x: float, z_y: float) -> None:
        """Incorporate a new (x, y) position measurement. Silently
        skipped (not applied, not raised) if the measurement contains
        NaN/Inf or the filter hasn't been initialized yet — callers
        should call initialize() first for a brand-new track."""
        if not self._initialized:
            self.initialize(z_x, z_y)
            return
        if not _finite(z_x, z_y):
            return
        H = np.array([
            [1.0, 0.0, 0.0, 0.0],
            [0.0, 1.0, 0.0, 0.0],
        ])
        R = np.eye(2) * self.measurement_noise
        z = np.array([z_x, z_y])
        y = z - H @ self.x
        S = H @ self.P @ H.T + R
        try:
            K = self.P @ H.T @ np.linalg.inv(S)
        except np.linalg.LinAlgError:
            return  # singular S: skip this update rather than crash
        self.x = self.x + K @ y
        I = np.eye(STATE_DIM)
        self.P = (I - K @ H) @ self.P
        self._sanitize()

    def _sanitize(self) -> None:
        """Guard against NaN/Inf creeping into state or covariance from
        degenerate inputs (e.g. an extreme dt) — falls back to a fresh
        reset rather than letting corrupted numbers propagate."""
        if self.x is None or self.P is None:
            return
        if not np.all(np.isfinite(self.x)) or not np.all(np.isfinite(self.P)):
            self.reset()

    # -- accessors ----------------------------------------------------

    def get_state(self) -> Optional[tuple]:
        """Returns (x, y, vx, vy) or None if uninitialized."""
        if not self._initialized or self.x is None:
            return None
        return tuple(float(v) for v in self.x)

    def get_covariance(self) -> Optional[list]:
        """Returns the 4x4 covariance as a row-major nested list, or
        None if uninitialized."""
        if not self._initialized or self.P is None:
            return None
        return self.P.tolist()

    def get_std_devs(self) -> Optional[tuple]:
        """Returns (sigma_x, sigma_y, sigma_vx, sigma_vy) from the
        covariance diagonal."""
        if not self._initialized or self.P is None:
            return None
        diag = np.diag(self.P)
        return tuple(float(math.sqrt(max(0.0, d))) for d in diag)
