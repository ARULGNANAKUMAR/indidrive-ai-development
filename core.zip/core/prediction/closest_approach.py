"""
IndiDrive AI — Phase 4D | Closest Approach Calculator
=======================================================
Computes minimum predicted distance, time of closest approach,
relative position and velocity using actual predicted trajectories.

Uses the same horizon grid that Phase 4A/4B/4C produces — no new
trajectory generation is performed here.

Fully deterministic. No NaN/Inf propagation.
"""
from __future__ import annotations

import math
from typing import List, Optional

from .prediction_types import PredictedState
from .phase4d_types import ClosestApproachResult

__all__ = ["compute_closest_approach", "build_ego_trajectory"]

_INF = float("inf")


def _dist(ax: float, ay: float, bx: float, by: float) -> float:
    return math.sqrt((ax - bx) ** 2 + (ay - by) ** 2)


def _safe(v) -> Optional[float]:
    if isinstance(v, (int, float)) and math.isfinite(v):
        return float(v)
    return None


def build_ego_trajectory(
    ego_x: float, ego_y: float,
    ego_vx: float, ego_vy: float,
    horizons_s: List[float],
    ego_ax: float = 0.0, ego_ay: float = 0.0,
) -> List[PredictedState]:
    """
    Build a synthetic ego trajectory using constant-acceleration kinematics
    from the ego's current state.  Used when a full ego planner is absent
    (spec requirement 4).
    """
    states = []
    for h in horizons_s:
        x = ego_x + ego_vx * h + 0.5 * ego_ax * h * h
        y = ego_y + ego_vy * h + 0.5 * ego_ay * h * h
        vx = ego_vx + ego_ax * h
        vy = ego_vy + ego_ay * h
        states.append(PredictedState(
            timestamp=h, x=x, y=y, z=0.0,
            vx=vx, vy=vy, vz=0.0,
            yaw=math.atan2(vy, vx) if (abs(vx) + abs(vy)) > 0.01 else 0.0,
            speed=math.hypot(vx, vy),
            horizon_s=h,
        ))
    return states


def compute_closest_approach(
    ego_trajectory: List[PredictedState],
    obj_trajectory: List[PredictedState],
    ego_fallback_x: float = 0.0,
    ego_fallback_y: float = 0.0,
    ego_fallback_vx: float = 0.0,
    ego_fallback_vy: float = 0.0,
) -> ClosestApproachResult:
    """
    Compute closest approach by comparing ego and object predicted
    trajectories sample-by-sample.

    If trajectories have different lengths, the shorter one's last sample
    is extrapolated at constant velocity.

    Never returns NaN or Inf — degrades gracefully to fallback values.
    """
    # Validate trajectories
    def _valid_state(s: PredictedState) -> bool:
        return (
            _safe(s.x) is not None and _safe(s.y) is not None
            and _safe(s.vx) is not None and _safe(s.vy) is not None
            and _safe(s.horizon_s) is not None
        )

    ego_valid = [s for s in ego_trajectory if _valid_state(s)]
    obj_valid = [s for s in obj_trajectory if _valid_state(s)]

    # --- degenerate: no usable trajectory points ---
    if not obj_valid:
        # Fall back to current-position distance
        d = _dist(ego_fallback_x, ego_fallback_y, 0.0, 0.0)
        return ClosestApproachResult(
            minimum_distance_m=max(0.0, d),
            time_of_closest_approach_s=0.0,
            relative_position_x=0.0,
            relative_position_y=0.0,
            relative_velocity_x=ego_fallback_vx,
            relative_velocity_y=ego_fallback_vy,
        )

    # Build a combined horizon list from both trajectories
    # Align by horizon_s — for each object horizon find the nearest ego horizon
    min_dist = _INF
    best_t = 0.0
    best_rx = 0.0
    best_ry = 0.0
    best_rvx = 0.0
    best_rvy = 0.0

    # If ego trajectory is empty fall back to constant-position ego at (0,0)
    def _ego_at(t: float):
        if not ego_valid:
            x = ego_fallback_x + ego_fallback_vx * t
            y = ego_fallback_y + ego_fallback_vy * t
            vx = ego_fallback_vx
            vy = ego_fallback_vy
            return x, y, vx, vy
        # Find bracketing samples and interpolate
        if t <= ego_valid[0].horizon_s:
            s = ego_valid[0]
            return s.x, s.y, s.vx, s.vy
        if t >= ego_valid[-1].horizon_s:
            s = ego_valid[-1]
            # extrapolate
            dt = t - s.horizon_s
            return s.x + s.vx * dt, s.y + s.vy * dt, s.vx, s.vy
        for i in range(len(ego_valid) - 1):
            s0, s1 = ego_valid[i], ego_valid[i + 1]
            if s0.horizon_s <= t <= s1.horizon_s:
                span = s1.horizon_s - s0.horizon_s
                if span < 1e-9:
                    return s0.x, s0.y, s0.vx, s0.vy
                alpha = (t - s0.horizon_s) / span
                x = s0.x + alpha * (s1.x - s0.x)
                y = s0.y + alpha * (s1.y - s0.y)
                vx = s0.vx + alpha * (s1.vx - s0.vx)
                vy = s0.vy + alpha * (s1.vy - s0.vy)
                return x, y, vx, vy
        s = ego_valid[-1]
        return s.x, s.y, s.vx, s.vy

    for os in obj_valid:
        t = os.horizon_s
        ex, ey, evx, evy = _ego_at(t)
        d = _dist(ex, ey, os.x, os.y)
        if d < min_dist:
            min_dist = d
            best_t = t
            best_rx = os.x - ex
            best_ry = os.y - ey
            best_rvx = os.vx - evx
            best_rvy = os.vy - evy

    if min_dist == _INF:
        min_dist = 0.0

    return ClosestApproachResult(
        minimum_distance_m=max(0.0, min_dist),
        time_of_closest_approach_s=max(0.0, best_t),
        relative_position_x=best_rx,
        relative_position_y=best_ry,
        relative_velocity_x=best_rvx,
        relative_velocity_y=best_rvy,
    )
