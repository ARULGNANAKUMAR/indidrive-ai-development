"""
IndiDrive AI — Phase 4B | Deterministic Hypothesis Scoring
================================================================
Pure functions only. Same inputs always produce the same outputs —
no randomness anywhere (mirrors Phase 4A's model_selector.py).

Scoring factors (spec section 4):
    - current lateral motion (yaw_rate, body-frame lateral velocity)
    - acceleration (longitudinal component)
    - heading change (current yaw_rate vs. historical average)
    - historical direction (sign agreement with recent history)
    - object class (pedestrians/cyclists/motorcycles weighted more
      toward lateral hypotheses than cars/trucks)
    - motion stability (low yaw_rate + low lateral accel => stable)
"""
from __future__ import annotations

import math
from dataclasses import dataclass

from .hypothesis_types import BehaviourType

__all__ = [
    "HypothesisConfig", "project_longitudinal_lateral",
    "body_frame_lateral_velocity", "stability_score", "is_stable",
    "candidate_behaviours", "historical_yaw_rate_bias",
    "object_class_lateral_factor", "score_behaviour", "normalize_scores",
]

# Lateral/longitudinal object classes get more weight toward turning
# hypotheses; the rest default to 1.0 (no boost, no penalty).
LATERAL_PRONE_CLASSES = frozenset({
    "pedestrian", "cyclist", "bicycle", "motorcycle", "rider",
})


@dataclass
class HypothesisConfig:
    # -- stability (fast-path) thresholds --
    stable_yaw_rate: float = 0.03        # rad/s
    stable_lateral_accel: float = 0.3    # m/s^2
    stable_longitudinal_accel: float = 0.3  # m/s^2

    # -- candidate-generation thresholds --
    yaw_rate_threshold: float = 0.05     # rad/s -- above this, turning candidate
    lateral_velocity_threshold: float = 0.3  # m/s -- secondary turning signal
    longitudinal_accel_threshold: float = 0.5  # m/s^2 -- braking/accel candidate

    # -- forced-model defaults, used only when the measured signal for
    # a candidate behaviour is itself ~0 (spec: "no random probabilities" --
    # these are fixed constants, never sampled) --
    min_turn_rate: float = 0.15          # rad/s
    default_brake_decel: float = 2.0     # m/s^2
    default_accel: float = 1.5           # m/s^2

    # -- scoring weights --
    yaw_rate_weight: float = 8.0
    lateral_velocity_weight: float = 2.0
    longitudinal_accel_weight: float = 1.5
    straight_base_weight: float = 0.6
    history_agree_boost: float = 1.2
    history_disagree_penalty: float = 0.8

    # -- pruning --
    min_probability: float = 0.03
    max_hypotheses: int = 5


def _finite(*values: float) -> bool:
    return all(isinstance(v, (int, float)) and math.isfinite(v) for v in values)


def project_longitudinal_lateral(heading: float, ax: float, ay: float) -> tuple:
    """World-frame (ax, ay) -> (longitudinal, lateral) acceleration in
    the object's own heading frame."""
    if not _finite(heading, ax, ay):
        return 0.0, 0.0
    c, s = math.cos(heading), math.sin(heading)
    a_long = ax * c + ay * s
    a_lat = -ax * s + ay * c
    return a_long, a_lat


def body_frame_lateral_velocity(heading: float, vx: float, vy: float) -> float:
    if not _finite(heading, vx, vy):
        return 0.0
    c, s = math.cos(heading), math.sin(heading)
    return -vx * s + vy * c


def stability_score(yaw_rate: float, a_lat: float, a_long: float) -> float:
    """1.0 for a perfectly steady object, decaying toward 0 as lateral
    motion / acceleration grows. Deterministic, bounded (0, 1]."""
    yaw_rate = yaw_rate if math.isfinite(yaw_rate) else 0.0
    a_lat = a_lat if math.isfinite(a_lat) else 0.0
    a_long = a_long if math.isfinite(a_long) else 0.0
    return 1.0 / (1.0 + 10.0 * abs(yaw_rate) + abs(a_lat) + abs(a_long))


def is_stable(yaw_rate: float, ax: float, ay: float, heading: float,
              config: HypothesisConfig = None, vx: float = 0.0, vy: float = 0.0) -> bool:
    cfg = config or HypothesisConfig()
    yaw_rate = yaw_rate if math.isfinite(yaw_rate) else 0.0
    a_long, a_lat = project_longitudinal_lateral(heading, ax, ay)
    v_lat = body_frame_lateral_velocity(heading, vx, vy)
    return (
        abs(yaw_rate) <= cfg.stable_yaw_rate
        and abs(a_lat) <= cfg.stable_lateral_accel
        and abs(a_long) <= cfg.stable_longitudinal_accel
        and abs(v_lat) <= cfg.lateral_velocity_threshold
    )


def historical_yaw_rate_bias(history_yaw_rates: list) -> float:
    """Mean yaw_rate across recent history samples (0.0 if none/invalid).
    Used only as a sign-agreement signal, never as the sole driver of a
    hypothesis."""
    vals = [v for v in history_yaw_rates if isinstance(v, (int, float)) and math.isfinite(v)]
    if not vals:
        return 0.0
    return sum(vals) / len(vals)


def object_class_lateral_factor(object_type: str) -> float:
    if isinstance(object_type, str) and object_type.strip().lower() in LATERAL_PRONE_CLASSES:
        return 1.25
    return 1.0


def candidate_behaviours(
    yaw_rate: float, ax: float, ay: float, heading: float,
    vx: float, vy: float, config: HypothesisConfig = None,
) -> list:
    """Deterministic set of behaviours worth scoring for an unstable
    track. STRAIGHT is always included as the baseline continuation."""
    cfg = config or HypothesisConfig()
    yaw_rate = yaw_rate if math.isfinite(yaw_rate) else 0.0
    a_long, _a_lat = project_longitudinal_lateral(heading, ax, ay)
    v_lat = body_frame_lateral_velocity(heading, vx, vy)

    candidates = [BehaviourType.STRAIGHT]

    turning_left = yaw_rate > cfg.yaw_rate_threshold or v_lat > cfg.lateral_velocity_threshold
    turning_right = yaw_rate < -cfg.yaw_rate_threshold or v_lat < -cfg.lateral_velocity_threshold
    if turning_left:
        candidates.append(BehaviourType.LEFT)
    if turning_right:
        candidates.append(BehaviourType.RIGHT)
    if a_long < -cfg.longitudinal_accel_threshold:
        candidates.append(BehaviourType.BRAKING)
    if a_long > cfg.longitudinal_accel_threshold:
        candidates.append(BehaviourType.ACCELERATION)

    return candidates


def score_behaviour(
    behaviour: BehaviourType, *, yaw_rate: float, ax: float, ay: float,
    heading: float, vx: float, vy: float, object_type: str,
    history_yaw_rates: list, config: HypothesisConfig = None,
) -> float:
    """Non-negative, deterministic raw score for one behaviour. Higher
    is more likely. Scores are only meaningful relative to each other
    for the same track (normalize_scores turns them into a
    probability distribution)."""
    cfg = config or HypothesisConfig()
    yaw_rate = yaw_rate if math.isfinite(yaw_rate) else 0.0
    a_long, a_lat = project_longitudinal_lateral(heading, ax, ay)
    v_lat = body_frame_lateral_velocity(heading, vx, vy)
    class_factor = object_class_lateral_factor(object_type)
    hist_bias = historical_yaw_rate_bias(history_yaw_rates)

    if behaviour == BehaviourType.STRAIGHT:
        return cfg.straight_base_weight + stability_score(yaw_rate, a_lat, a_long)

    if behaviour in (BehaviourType.LEFT, BehaviourType.RIGHT):
        sign = 1.0 if behaviour == BehaviourType.LEFT else -1.0
        raw = max(0.0, sign * yaw_rate) * cfg.yaw_rate_weight
        raw += max(0.0, sign * v_lat) * cfg.lateral_velocity_weight
        raw *= class_factor
        if raw > 0.0:
            agrees = (sign * hist_bias) > 0.0
            raw *= cfg.history_agree_boost if agrees else cfg.history_disagree_penalty
        return raw

    if behaviour == BehaviourType.BRAKING:
        return max(0.0, -a_long) * cfg.longitudinal_accel_weight

    if behaviour == BehaviourType.ACCELERATION:
        return max(0.0, a_long) * cfg.longitudinal_accel_weight

    return 0.0


def normalize_scores(raw_scores: dict) -> dict:
    """Turn {behaviour: raw_score} into a normalized probability
    distribution that sums to 1.0. Falls back to a uniform
    distribution if every score is zero/invalid, and never divides by
    zero."""
    cleaned = {
        k: (v if isinstance(v, (int, float)) and math.isfinite(v) and v > 0.0 else 0.0)
        for k, v in raw_scores.items()
    }
    total = sum(cleaned.values())
    if total <= 0.0:
        if not cleaned:
            return {}
        uniform = 1.0 / len(cleaned)
        return {k: uniform for k in cleaned}
    return {k: v / total for k, v in cleaned.items()}
