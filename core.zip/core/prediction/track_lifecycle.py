"""
IndiDrive AI — Phase 4A | Track Lifecycle
==============================================
State machine tracking whether Phase 4A still has a usable
motion history/Kalman filter for a given track_id, independent of
Phase 3's own per-cycle ObjectLifecycleState (CONFIRMED/FUSED/etc,
which is about fusion confidence *this cycle*, not prediction
continuity across cycles).

States (spec section 6):
    NEW                 -- first cycle seen, not yet confirmed stable
    ACTIVE              -- confirmed, currently receiving measurements
    TEMPORARILY_LOST    -- missed a small number of consecutive cycles
    STALE               -- missed too many consecutive cycles; about to expire
    DELETED             -- expired; memory released

Confidence decreases monotonically while a track is missed, and is
restored (not reset to 1.0 instantly) once measurements resume.
"""
from __future__ import annotations

from dataclasses import dataclass, field

from .prediction_types import TrackLifecycleState

DEFAULT_CONFIRM_HITS = 2            # hits needed for NEW -> ACTIVE
DEFAULT_LOST_AFTER_MISSES = 2       # consecutive misses -> TEMPORARILY_LOST
DEFAULT_STALE_AFTER_MISSES = 5      # consecutive misses -> STALE
DEFAULT_DELETE_AFTER_MISSES = 10    # consecutive misses -> DELETED
DEFAULT_CONFIDENCE_DECAY = 0.3      # multiplicative decay applied per missed cycle
DEFAULT_CONFIDENCE_RECOVERY = 0.5   # how much of the gap to 1.0 is recovered per hit


@dataclass
class _TrackLifecycleEntry:
    state: TrackLifecycleState = TrackLifecycleState.NEW
    hits: int = 0
    consecutive_misses: int = 0
    confidence: float = 1.0


@dataclass
class TrackLifecycleConfig:
    confirm_hits: int = DEFAULT_CONFIRM_HITS
    lost_after_misses: int = DEFAULT_LOST_AFTER_MISSES
    stale_after_misses: int = DEFAULT_STALE_AFTER_MISSES
    delete_after_misses: int = DEFAULT_DELETE_AFTER_MISSES
    confidence_decay: float = DEFAULT_CONFIDENCE_DECAY
    confidence_recovery: float = DEFAULT_CONFIDENCE_RECOVERY


class TrackLifecycleManager:
    def __init__(self, config: TrackLifecycleConfig = None):
        self.config = config or TrackLifecycleConfig()
        self._entries: dict[str, _TrackLifecycleEntry] = {}

    def observe(self, track_id: str, seen: bool) -> TrackLifecycleState:
        """Advance one track's lifecycle by one cycle. `seen=True` means
        a fused measurement arrived this cycle for this track_id."""
        cfg = self.config
        entry = self._entries.get(track_id)
        if entry is None:
            entry = _TrackLifecycleEntry()
            self._entries[track_id] = entry

        if seen:
            entry.hits += 1
            entry.consecutive_misses = 0
            entry.confidence = entry.confidence + cfg.confidence_recovery * (1.0 - entry.confidence)
            if entry.state in (TrackLifecycleState.NEW,) and entry.hits >= cfg.confirm_hits:
                entry.state = TrackLifecycleState.ACTIVE
            elif entry.state in (TrackLifecycleState.TEMPORARILY_LOST, TrackLifecycleState.STALE):
                entry.state = TrackLifecycleState.ACTIVE
            elif entry.state == TrackLifecycleState.NEW:
                pass  # stays NEW until confirm_hits reached
        else:
            entry.consecutive_misses += 1
            entry.confidence = entry.confidence * (1.0 - cfg.confidence_decay)
            entry.confidence = max(0.0, entry.confidence)
            if entry.consecutive_misses >= cfg.delete_after_misses:
                entry.state = TrackLifecycleState.DELETED
            elif entry.consecutive_misses >= cfg.stale_after_misses:
                entry.state = TrackLifecycleState.STALE
            elif entry.consecutive_misses >= cfg.lost_after_misses:
                entry.state = TrackLifecycleState.TEMPORARILY_LOST
            # else: stays in whatever state it was (a single missed
            # measurement is tolerated without downgrading immediately)

        return entry.state

    def get_state(self, track_id: str) -> TrackLifecycleState:
        entry = self._entries.get(track_id)
        return entry.state if entry else TrackLifecycleState.DELETED

    def get_confidence(self, track_id: str) -> float:
        entry = self._entries.get(track_id)
        return entry.confidence if entry else 0.0

    def is_deleted(self, track_id: str) -> bool:
        return self.get_state(track_id) == TrackLifecycleState.DELETED

    def purge_deleted(self) -> list:
        """Remove DELETED tracks from internal bookkeeping (releases
        memory) and returns the list of track_ids removed. Callers
        should also drop the corresponding track_history/Kalman
        filter entries for these ids."""
        deleted = [tid for tid, e in self._entries.items() if e.state == TrackLifecycleState.DELETED]
        for tid in deleted:
            del self._entries[tid]
        return deleted

    def active_track_ids(self) -> list:
        return list(self._entries.keys())

    def reset(self) -> None:
        self._entries.clear()
