"""
IndiDrive AI — Phase 11.1 | Safety Monitor Configuration
==========================================================
Validated configuration for the Safety Monitor.

All thresholds are deterministic and testable.
No hard-coded magic numbers in the monitor engine — all come from here.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Tuple

__all__ = ["SafetyMonitorConfig"]

# Default freshness thresholds (seconds)
_DEFAULT_WORLD_MODEL_MAX_AGE_S:   float = 0.5
_DEFAULT_PLANNER_MAX_AGE_S:       float = 0.5
_DEFAULT_TRACKING_MAX_AGE_S:      float = 0.2
_DEFAULT_MPC_MAX_AGE_S:           float = 0.2
_DEFAULT_CONTROL_MAX_AGE_S:       float = 0.2
_DEFAULT_VEHICLE_MAX_AGE_S:       float = 0.2
_DEFAULT_PIPELINE_MAX_AGE_S:      float = 1.0

# Default tracking deviation thresholds (metres)
_DEFAULT_LARGE_CROSS_TRACK_M:     float = 2.0
_DEFAULT_CRITICAL_CROSS_TRACK_M:  float = 5.0

# Default confidence threshold below which state is considered UNKNOWN
_DEFAULT_MIN_CONFIDENCE_FOR_VALID: float = 0.1

# Default uncertainty threshold above which HIGH_ALERT is considered
_DEFAULT_HIGH_UNCERTAINTY_THRESHOLD: float = 0.8


@dataclass
class SafetyMonitorConfig:
    """
    Configuration for the Safety Monitor.

    All thresholds are validated on construction.

    Freshness thresholds
    --------------------
    world_model_max_age_s   : Max age of world model data before STALE (s).
    planner_max_age_s       : Max age of planner output before STALE (s).
    tracking_max_age_s      : Max age of tracking snapshot before STALE (s).
    mpc_max_age_s           : Max age of MPC snapshot before STALE (s).
    control_max_age_s       : Max age of control command before STALE (s).
    vehicle_max_age_s       : Max age of vehicle state before STALE (s).
    pipeline_max_age_s      : Max age of pipeline snapshot before STALE (s).

    Deviation thresholds
    --------------------
    large_cross_track_error_m   : CTE above this → TRACKING_LARGE_DEVIATION.
    critical_cross_track_error_m: CTE above this → CRITICAL observation.

    Confidence / uncertainty
    ------------------------
    min_confidence_for_valid    : Below this → UNKNOWN state.
    high_uncertainty_threshold  : Above this → HIGH_ALERT consideration.

    Required subsystems
    -------------------
    required_subsystems : Tuple of subsystem names that must be HEALTHY
                          for a SAFE assessment.
    """
    # Freshness
    world_model_max_age_s:    float = _DEFAULT_WORLD_MODEL_MAX_AGE_S
    planner_max_age_s:        float = _DEFAULT_PLANNER_MAX_AGE_S
    tracking_max_age_s:       float = _DEFAULT_TRACKING_MAX_AGE_S
    mpc_max_age_s:            float = _DEFAULT_MPC_MAX_AGE_S
    control_max_age_s:        float = _DEFAULT_CONTROL_MAX_AGE_S
    vehicle_max_age_s:        float = _DEFAULT_VEHICLE_MAX_AGE_S
    pipeline_max_age_s:       float = _DEFAULT_PIPELINE_MAX_AGE_S

    # Deviation
    large_cross_track_error_m:    float = _DEFAULT_LARGE_CROSS_TRACK_M
    critical_cross_track_error_m: float = _DEFAULT_CRITICAL_CROSS_TRACK_M

    # Confidence / uncertainty
    min_confidence_for_valid:      float = _DEFAULT_MIN_CONFIDENCE_FOR_VALID
    high_uncertainty_threshold:    float = _DEFAULT_HIGH_UNCERTAINTY_THRESHOLD

    # Required subsystems (must all be HEALTHY for SAFE)
    required_subsystems: Tuple[str, ...] = field(default_factory=lambda: (
        "world_model",
        "planner",
        "tracking",
        "mpc",
        "control",
        "vehicle",
    ))

    def __post_init__(self) -> None:
        self._validate()

    def _validate(self) -> None:
        """Validate all configuration values raise ValueError if invalid."""
        age_fields = [
            ("world_model_max_age_s",  self.world_model_max_age_s),
            ("planner_max_age_s",      self.planner_max_age_s),
            ("tracking_max_age_s",     self.tracking_max_age_s),
            ("mpc_max_age_s",          self.mpc_max_age_s),
            ("control_max_age_s",      self.control_max_age_s),
            ("vehicle_max_age_s",      self.vehicle_max_age_s),
            ("pipeline_max_age_s",     self.pipeline_max_age_s),
        ]
        for name, val in age_fields:
            if not isinstance(val, (int, float)) or val <= 0:
                raise ValueError(
                    f"SafetyMonitorConfig.{name} must be a positive number, got {val!r}"
                )

        dist_fields = [
            ("large_cross_track_error_m",    self.large_cross_track_error_m),
            ("critical_cross_track_error_m", self.critical_cross_track_error_m),
        ]
        for name, val in dist_fields:
            if not isinstance(val, (int, float)) or val <= 0:
                raise ValueError(
                    f"SafetyMonitorConfig.{name} must be a positive number, got {val!r}"
                )

        if self.critical_cross_track_error_m <= self.large_cross_track_error_m:
            raise ValueError(
                "critical_cross_track_error_m must be > large_cross_track_error_m"
            )

        for name, val in [
            ("min_confidence_for_valid",   self.min_confidence_for_valid),
            ("high_uncertainty_threshold", self.high_uncertainty_threshold),
        ]:
            if not isinstance(val, (int, float)) or not (0.0 <= val <= 1.0):
                raise ValueError(
                    f"SafetyMonitorConfig.{name} must be in [0.0, 1.0], got {val!r}"
                )

    @classmethod
    def default(cls) -> "SafetyMonitorConfig":
        """Return a default validated configuration."""
        return cls()

    @classmethod
    def strict(cls) -> "SafetyMonitorConfig":
        """Return a stricter configuration with tighter freshness requirements."""
        return cls(
            world_model_max_age_s=0.2,
            planner_max_age_s=0.2,
            tracking_max_age_s=0.1,
            mpc_max_age_s=0.1,
            control_max_age_s=0.1,
            vehicle_max_age_s=0.1,
            pipeline_max_age_s=0.5,
            large_cross_track_error_m=1.0,
            critical_cross_track_error_m=3.0,
        )
