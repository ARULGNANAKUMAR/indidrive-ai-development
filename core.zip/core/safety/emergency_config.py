"""
IndiDrive AI — Phase 11.2 | Emergency Detector Configuration
=============================================================
Validated, deterministic configuration for the Emergency Detector.
No magic numbers — all thresholds come from here.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Tuple

__all__ = ["EmergencyDetectorConfig"]

# Defaults — conservative for safety
_DEFAULT_TTC_CRITICAL_S:           float = 1.5   # TTC ≤ this → CRITICAL_TTC
_DEFAULT_TTC_EMERGENCY_S:          float = 3.0   # TTC ≤ this → EMERGENCY_DETECTED
_DEFAULT_TTC_POTENTIAL_S:          float = 5.0   # TTC ≤ this → POTENTIAL_EMERGENCY
_DEFAULT_COLLISION_LIKELIHOOD_CRITICAL: float = 0.8
_DEFAULT_COLLISION_LIKELIHOOD_EMERGENCY: float = 0.6
_DEFAULT_COLLISION_LIKELIHOOD_POTENTIAL: float = 0.4
_DEFAULT_PATH_RISK_CRITICAL:       float = 0.85
_DEFAULT_PATH_RISK_EMERGENCY:      float = 0.70
_DEFAULT_PATH_RISK_POTENTIAL:      float = 0.50
_DEFAULT_MIN_CONFIDENCE_FOR_VALID: float = 0.1
_DEFAULT_HIGH_UNCERTAINTY_THRESHOLD: float = 0.8
_DEFAULT_STALE_THRESHOLD_S:        float = 0.5   # inputs older than this → stale
_DEFAULT_PERSISTENCE_CYCLES:       int   = 2     # cycles before confirming emergency
_DEFAULT_CLEAR_CYCLES:             int   = 3     # cycles of NO_EMERGENCY before clearing


@dataclass
class EmergencyDetectorConfig:
    """
    Configuration for the Emergency Detector.

    All thresholds are validated on construction.

    TTC thresholds (seconds)
    ------------------------
    ttc_critical_s          : TTC ≤ this → CRITICAL_EMERGENCY.
    ttc_emergency_s         : TTC ≤ this → EMERGENCY_DETECTED.
    ttc_potential_s         : TTC ≤ this → POTENTIAL_EMERGENCY.

    Collision likelihood thresholds [0,1]
    -------------------------------------
    collision_likelihood_critical  : ≥ this → CRITICAL_EMERGENCY.
    collision_likelihood_emergency : ≥ this → EMERGENCY_DETECTED.
    collision_likelihood_potential : ≥ this → POTENTIAL_EMERGENCY.

    Path risk thresholds [0,1]
    --------------------------
    path_risk_critical   : ≥ this → CRITICAL_EMERGENCY.
    path_risk_emergency  : ≥ this → EMERGENCY_DETECTED.
    path_risk_potential  : ≥ this → POTENTIAL_EMERGENCY.

    Confidence / uncertainty
    ------------------------
    min_confidence_for_valid    : Below this → UNKNOWN state.
    high_uncertainty_threshold  : Above this → treat detection as uncertain.

    Staleness
    ---------
    stale_threshold_s           : Input older than this → stale.

    Hysteresis / debounce
    ---------------------
    persistence_cycles  : Cycles a raw emergency must persist before CONFIRMED.
    clear_cycles        : Cycles of clean data before clearing an emergency.
    """
    # TTC
    ttc_critical_s:    float = _DEFAULT_TTC_CRITICAL_S
    ttc_emergency_s:   float = _DEFAULT_TTC_EMERGENCY_S
    ttc_potential_s:   float = _DEFAULT_TTC_POTENTIAL_S

    # Collision likelihood
    collision_likelihood_critical:  float = _DEFAULT_COLLISION_LIKELIHOOD_CRITICAL
    collision_likelihood_emergency: float = _DEFAULT_COLLISION_LIKELIHOOD_EMERGENCY
    collision_likelihood_potential: float = _DEFAULT_COLLISION_LIKELIHOOD_POTENTIAL

    # Path risk
    path_risk_critical:  float = _DEFAULT_PATH_RISK_CRITICAL
    path_risk_emergency: float = _DEFAULT_PATH_RISK_EMERGENCY
    path_risk_potential: float = _DEFAULT_PATH_RISK_POTENTIAL

    # Confidence / uncertainty
    min_confidence_for_valid:      float = _DEFAULT_MIN_CONFIDENCE_FOR_VALID
    high_uncertainty_threshold:    float = _DEFAULT_HIGH_UNCERTAINTY_THRESHOLD

    # Staleness
    stale_threshold_s: float = _DEFAULT_STALE_THRESHOLD_S

    # Hysteresis
    persistence_cycles: int = _DEFAULT_PERSISTENCE_CYCLES
    clear_cycles:       int = _DEFAULT_CLEAR_CYCLES

    def __post_init__(self) -> None:
        self._validate()

    def _validate(self) -> None:
        """Validate all configuration values; raise ValueError if invalid."""
        # TTC ordering
        if not (0 < self.ttc_critical_s < self.ttc_emergency_s < self.ttc_potential_s):
            raise ValueError(
                "TTC thresholds must satisfy: "
                "0 < ttc_critical_s < ttc_emergency_s < ttc_potential_s, "
                f"got {self.ttc_critical_s}, {self.ttc_emergency_s}, {self.ttc_potential_s}"
            )

        # Collision likelihood ordering [0,1]
        for name, val in [
            ("collision_likelihood_critical",  self.collision_likelihood_critical),
            ("collision_likelihood_emergency", self.collision_likelihood_emergency),
            ("collision_likelihood_potential", self.collision_likelihood_potential),
        ]:
            if not (0.0 <= val <= 1.0):
                raise ValueError(f"{name} must be in [0,1], got {val}")
        if not (self.collision_likelihood_potential
                <= self.collision_likelihood_emergency
                <= self.collision_likelihood_critical):
            raise ValueError(
                "collision_likelihood thresholds must satisfy: "
                "potential ≤ emergency ≤ critical"
            )

        # Path risk ordering [0,1]
        for name, val in [
            ("path_risk_critical",  self.path_risk_critical),
            ("path_risk_emergency", self.path_risk_emergency),
            ("path_risk_potential", self.path_risk_potential),
        ]:
            if not (0.0 <= val <= 1.0):
                raise ValueError(f"{name} must be in [0,1], got {val}")
        if not (self.path_risk_potential
                <= self.path_risk_emergency
                <= self.path_risk_critical):
            raise ValueError(
                "path_risk thresholds must satisfy: potential ≤ emergency ≤ critical"
            )

        # Confidence / uncertainty
        for name, val in [
            ("min_confidence_for_valid",   self.min_confidence_for_valid),
            ("high_uncertainty_threshold", self.high_uncertainty_threshold),
        ]:
            if not (0.0 <= val <= 1.0):
                raise ValueError(f"{name} must be in [0,1], got {val}")

        # Staleness
        if self.stale_threshold_s <= 0:
            raise ValueError(f"stale_threshold_s must be > 0, got {self.stale_threshold_s}")

        # Hysteresis
        if self.persistence_cycles < 0:
            raise ValueError(f"persistence_cycles must be >= 0, got {self.persistence_cycles}")
        if self.clear_cycles < 0:
            raise ValueError(f"clear_cycles must be >= 0, got {self.clear_cycles}")

    @classmethod
    def default(cls) -> "EmergencyDetectorConfig":
        """Return default validated configuration."""
        return cls()

    @classmethod
    def sensitive(cls) -> "EmergencyDetectorConfig":
        """More sensitive thresholds — earlier detection, lower confidence required."""
        return cls(
            ttc_critical_s=2.0,
            ttc_emergency_s=4.0,
            ttc_potential_s=6.0,
            collision_likelihood_critical=0.7,
            collision_likelihood_emergency=0.5,
            collision_likelihood_potential=0.3,
            path_risk_critical=0.75,
            path_risk_emergency=0.60,
            path_risk_potential=0.40,
            persistence_cycles=1,
            clear_cycles=2,
        )

    @classmethod
    def strict(cls) -> "EmergencyDetectorConfig":
        """Stricter (tighter) thresholds — fewer false positives."""
        return cls(
            ttc_critical_s=1.0,
            ttc_emergency_s=2.0,
            ttc_potential_s=3.5,
            collision_likelihood_critical=0.9,
            collision_likelihood_emergency=0.75,
            collision_likelihood_potential=0.55,
            path_risk_critical=0.90,
            path_risk_emergency=0.80,
            path_risk_potential=0.65,
            persistence_cycles=3,
            clear_cycles=4,
        )
