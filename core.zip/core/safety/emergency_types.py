"""
IndiDrive AI — Phase 11.2 | Emergency Detection Types
=======================================================
Typed enumerations and immutable data containers for the Emergency Detector.

Design rules:
  * All containers are frozen dataclasses — immutable after construction.
  * No computation here — only type definitions.
  * No circular imports — stdlib and typing only.
  * Deterministic: same input → same output.
  * UNKNOWN / DEGRADED are explicit states, never silent NO_EMERGENCY fallbacks.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Optional, Tuple

__all__ = [
    # Schema
    "EMERGENCY_SCHEMA_VERSION",
    # Enums
    "EmergencyState",
    "EmergencyType",
    "EmergencySeverity",
    "EmergencyUrgency",
    "EmergencySource",
    # Data containers
    "EmergencyEvidence",
    "EmergencyEvent",
    "EmergencyDetectionState",
]

EMERGENCY_SCHEMA_VERSION: str = "11.2"


# ---------------------------------------------------------------------------
# Emergency State — overall detection result
# ---------------------------------------------------------------------------

class EmergencyState(str, Enum):
    """
    Overall emergency detection state.

    NO_EMERGENCY        — No emergency conditions detected.
    POTENTIAL_EMERGENCY — Marginal or uncertain conditions warrant monitoring.
    EMERGENCY_DETECTED  — Emergency condition confirmed with sufficient confidence.
    CRITICAL_EMERGENCY  — Critical, imminent emergency requiring immediate action.
    EMERGENCY_CLEARED   — Previously detected emergency has been resolved.
    EMERGENCY_UNKNOWN   — Insufficient evidence to determine emergency status.
    EMERGENCY_DEGRADED  — Detection can run but inputs are degraded/stale.
    """
    NO_EMERGENCY        = "NO_EMERGENCY"
    POTENTIAL_EMERGENCY = "POTENTIAL_EMERGENCY"
    EMERGENCY_DETECTED  = "EMERGENCY_DETECTED"
    CRITICAL_EMERGENCY  = "CRITICAL_EMERGENCY"
    EMERGENCY_CLEARED   = "EMERGENCY_CLEARED"
    EMERGENCY_UNKNOWN   = "EMERGENCY_UNKNOWN"
    EMERGENCY_DEGRADED  = "EMERGENCY_DEGRADED"


# Priority ordering (lower index = higher priority) for aggregation
EMERGENCY_STATE_PRIORITY: Tuple[EmergencyState, ...] = (
    EmergencyState.CRITICAL_EMERGENCY,
    EmergencyState.EMERGENCY_DETECTED,
    EmergencyState.POTENTIAL_EMERGENCY,
    EmergencyState.EMERGENCY_DEGRADED,
    EmergencyState.EMERGENCY_CLEARED,
    EmergencyState.NO_EMERGENCY,
    # EMERGENCY_UNKNOWN handled separately
)


# ---------------------------------------------------------------------------
# Emergency Type — classification of what kind of emergency
# ---------------------------------------------------------------------------

class EmergencyType(str, Enum):
    """
    Classification of detected emergency.
    Types are grounded in evidence available from the existing system.
    """
    # --- Traffic / collision ---
    IMMINENT_COLLISION               = "IMMINENT_COLLISION"
    CRITICAL_TTC                     = "CRITICAL_TTC"
    PATH_BLOCKED                     = "PATH_BLOCKED"
    CRITICAL_PATH_RISK               = "CRITICAL_PATH_RISK"
    UNAVOIDABLE_TRAJECTORY_CONFLICT  = "UNAVOIDABLE_TRAJECTORY_CONFLICT"
    VULNERABLE_ROAD_USER_CONFLICT    = "VULNERABLE_ROAD_USER_CONFLICT"
    SUDDEN_CROSSING_OBJECT           = "SUDDEN_CROSSING_OBJECT"
    SUDDEN_CATTLE_CROSSING           = "SUDDEN_CATTLE_CROSSING"
    SUDDEN_PEDESTRIAN_CROSSING       = "SUDDEN_PEDESTRIAN_CROSSING"
    DYNAMIC_OBSTACLE_INTRUSION       = "DYNAMIC_OBSTACLE_INTRUSION"
    VEHICLE_CUT_IN                   = "VEHICLE_CUT_IN"
    HIGHWAY_MERGE_CONFLICT           = "HIGHWAY_MERGE_CONFLICT"
    INTERSECTION_CONFLICT            = "INTERSECTION_CONFLICT"
    ROAD_COLLAPSE_OR_UNUSABLE_REGION = "ROAD_COLLAPSE_OR_UNUSABLE_REGION"
    CRITICAL_ROAD_HAZARD             = "CRITICAL_ROAD_HAZARD"
    # --- System failures ---
    VEHICLE_STATE_INVALID            = "VEHICLE_STATE_INVALID"
    TRACKING_LOST                    = "TRACKING_LOST"
    PLANNER_FAILURE                  = "PLANNER_FAILURE"
    MPC_FAILURE                      = "MPC_FAILURE"
    CONTROL_FAILURE                  = "CONTROL_FAILURE"
    SAFETY_MONITOR_CRITICAL          = "SAFETY_MONITOR_CRITICAL"
    SYSTEM_CRITICAL_FAILURE          = "SYSTEM_CRITICAL_FAILURE"
    # --- Unknown ---
    UNKNOWN_EMERGENCY                = "UNKNOWN_EMERGENCY"


# ---------------------------------------------------------------------------
# Emergency Severity — independent of urgency
# ---------------------------------------------------------------------------

class EmergencySeverity(str, Enum):
    """
    Severity of the detected emergency.
    Separate from urgency — a severe condition may not be immediately urgent.
    """
    LOW      = "LOW"
    MEDIUM   = "MEDIUM"
    HIGH     = "HIGH"
    CRITICAL = "CRITICAL"
    UNKNOWN  = "UNKNOWN"


# ---------------------------------------------------------------------------
# Emergency Urgency — time-criticality, separate from severity
# ---------------------------------------------------------------------------

class EmergencyUrgency(str, Enum):
    """
    Urgency of the detected emergency (time-criticality).
    Separate from severity.

    Example: severity=CRITICAL + urgency=IMMEDIATE → act now
             severity=HIGH    + urgency=HIGH        → act soon
             severity=HIGH    + urgency=LOW         → monitor
    """
    LOW       = "LOW"
    MEDIUM    = "MEDIUM"
    HIGH      = "HIGH"
    IMMEDIATE = "IMMEDIATE"
    UNKNOWN   = "UNKNOWN"


# ---------------------------------------------------------------------------
# Emergency Source — which detection rule triggered the emergency
# ---------------------------------------------------------------------------

class EmergencySource(str, Enum):
    """Source domain that produced an emergency condition."""
    COLLISION_RISK   = "COLLISION_RISK"
    WORLD_MODEL      = "WORLD_MODEL"
    PLANNING         = "PLANNING"
    TRACKING         = "TRACKING"
    MPC              = "MPC"
    CONTROL          = "CONTROL"
    VEHICLE          = "VEHICLE"
    SAFETY_MONITOR   = "SAFETY_MONITOR"
    SYSTEM           = "SYSTEM"
    UNKNOWN          = "UNKNOWN"


# ---------------------------------------------------------------------------
# Emergency Evidence — structured, traceable evidence bundle
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class EmergencyEvidence:
    """
    Structured evidence bundle for one detected emergency condition.
    All fields are optional — only populate from actually available data.
    None means 'not available', not 'zero'.

    Fields
    ------
    ttc_s                   : Time-to-collision in seconds (None = unavailable).
    collision_likelihood    : [0,1] collision likelihood (None = unavailable).
    min_distance_m          : Closest approach distance (None = unavailable).
    path_risk_score         : [0,1] normalised path risk score (None = unavailable).
    risk_level              : Categorical risk level string.
    closing_speed_mps       : Closing speed to object in m/s (None = unavailable).
    predicted_conflict      : True if trajectory conflict predicted.
    object_id               : Primary object ID (None if not applicable).
    object_type             : Object type string (None if not applicable).
    object_subtype          : Object subtype string (None if not applicable).
    safety_state            : Safety state from Phase 11.1 (string).
    safety_reason_codes     : Tuple of Phase 11.1 reason codes.
    planner_status          : Planner status string.
    tracking_quality        : Tracking quality string.
    mpc_status              : MPC status string.
    control_status          : Control command status string.
    dominant_risk_reason    : Dominant risk reason code string.
    extra                   : Optional dict of extra diagnostic data.
    """
    ttc_s:                Optional[float]        = None
    collision_likelihood:  Optional[float]        = None
    min_distance_m:        Optional[float]        = None
    path_risk_score:       Optional[float]        = None
    risk_level:            str                    = "NOT_AVAILABLE"
    closing_speed_mps:     Optional[float]        = None
    predicted_conflict:    bool                   = False
    object_id:             Optional[str]          = None
    object_type:           Optional[str]          = None
    object_subtype:        Optional[str]          = None
    safety_state:          str                    = "NOT_AVAILABLE"
    safety_reason_codes:   Tuple[str, ...]        = field(default_factory=tuple)
    planner_status:        str                    = "NOT_AVAILABLE"
    tracking_quality:      str                    = "NOT_AVAILABLE"
    mpc_status:            str                    = "NOT_AVAILABLE"
    control_status:        str                    = "NOT_AVAILABLE"
    dominant_risk_reason:  str                    = "NOT_AVAILABLE"
    extra:                 Optional[dict]         = None


# ---------------------------------------------------------------------------
# Emergency Event — one detected emergency condition as a structured event
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class EmergencyEvent:
    """
    Structured record of one detected emergency condition.

    Events are deterministic: same input → same event_id.

    Fields
    ------
    event_id            : Deterministic string ID (source:type:timestamp).
    timestamp           : Timestamp from source data (not wall clock).
    emergency_type      : EmergencyType enum.
    state               : EmergencyState for this specific condition.
    severity            : EmergencySeverity enum.
    urgency             : EmergencyUrgency enum.
    source              : EmergencySource enum.
    reason_codes        : Tuple of reason code strings.
    evidence            : EmergencyEvidence bundle.
    affected_objects    : Tuple of object IDs.
    affected_subsystems : Tuple of subsystem name strings.
    confidence          : [0,1] confidence in this detection.
    uncertainty         : [0,1] uncertainty (separate from severity).
    stale               : True if based on stale data.
    degraded            : True if based on degraded data.
    schema_version      : Schema version string.
    """
    event_id:            str                          = ""
    timestamp:           float                        = 0.0
    emergency_type:      EmergencyType                = EmergencyType.UNKNOWN_EMERGENCY
    state:               EmergencyState               = EmergencyState.EMERGENCY_UNKNOWN
    severity:            EmergencySeverity             = EmergencySeverity.UNKNOWN
    urgency:             EmergencyUrgency              = EmergencyUrgency.UNKNOWN
    source:              EmergencySource               = EmergencySource.UNKNOWN
    reason_codes:        Tuple[str, ...]               = field(default_factory=tuple)
    evidence:            EmergencyEvidence             = field(default_factory=EmergencyEvidence)
    affected_objects:    Tuple[str, ...]               = field(default_factory=tuple)
    affected_subsystems: Tuple[str, ...]               = field(default_factory=tuple)
    confidence:          float                        = 0.0
    uncertainty:         float                        = 1.0
    stale:               bool                         = False
    degraded:            bool                         = False
    schema_version:      str                          = EMERGENCY_SCHEMA_VERSION


# ---------------------------------------------------------------------------
# Emergency Detection State — final immutable assessment snapshot
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class EmergencyDetectionState:
    """
    Immutable snapshot of Phase 11.2 emergency detection for one cycle.

    This is the primary output of Phase 11.2.
    It MUST NOT directly control the vehicle.
    It provides emergency classification for Phase 11.3 (Controller Override).

    Fields
    ------
    timestamp               : Timestamp from primary input (not wall clock).
    schema_version          : "11.2".
    detector_status         : "OK" | "DEGRADED" | "UNAVAILABLE".
    emergency_state         : Overall EmergencyState (aggregated).
    dominant_emergency_type : Most critical EmergencyType detected.
    dominant_severity       : Most critical EmergencySeverity.
    dominant_urgency        : EmergencyUrgency of dominant emergency.
    reason_codes            : Tuple of all active reason code strings.
    active_events           : Tuple of EmergencyEvent (one per condition).
    affected_objects        : Tuple of affected object IDs (all events).
    affected_subsystems     : Tuple of affected subsystem names (all events).
    safety_state            : SafetyState from Phase 11.1 (passed through).
    confidence              : [0,1] overall detection confidence.
    uncertainty             : [0,1] overall detection uncertainty.
    stale                   : True if any critical input was stale.
    degraded                : True if any input was degraded.
    valid                   : True if assessment is based on sufficient data.
    hysteresis_counter      : Internal counter for debounce (for next cycle).
    clear_counter           : Internal counter for clearing hysteresis.
    """
    timestamp:               float                         = 0.0
    schema_version:          str                           = EMERGENCY_SCHEMA_VERSION
    detector_status:         str                           = "UNAVAILABLE"
    emergency_state:         EmergencyState                = EmergencyState.EMERGENCY_UNKNOWN
    dominant_emergency_type: EmergencyType                 = EmergencyType.UNKNOWN_EMERGENCY
    dominant_severity:       EmergencySeverity              = EmergencySeverity.UNKNOWN
    dominant_urgency:        EmergencyUrgency               = EmergencyUrgency.UNKNOWN
    reason_codes:            Tuple[str, ...]                = field(default_factory=tuple)
    active_events:           Tuple[EmergencyEvent, ...]     = field(default_factory=tuple)
    affected_objects:        Tuple[str, ...]                = field(default_factory=tuple)
    affected_subsystems:     Tuple[str, ...]                = field(default_factory=tuple)
    safety_state:            str                           = "NOT_AVAILABLE"
    confidence:              float                         = 0.0
    uncertainty:             float                         = 1.0
    stale:                   bool                          = True
    degraded:                bool                          = True
    valid:                   bool                          = False
    hysteresis_counter:      int                           = 0
    clear_counter:           int                           = 0

    @property
    def is_emergency(self) -> bool:
        """True if any emergency is currently detected (Potential or worse)."""
        return self.emergency_state in (
            EmergencyState.POTENTIAL_EMERGENCY,
            EmergencyState.EMERGENCY_DETECTED,
            EmergencyState.CRITICAL_EMERGENCY,
        )

    @property
    def is_critical(self) -> bool:
        """True if a critical emergency is detected."""
        return self.emergency_state == EmergencyState.CRITICAL_EMERGENCY

    @property
    def is_unknown(self) -> bool:
        """True if emergency status cannot be determined."""
        return self.emergency_state == EmergencyState.EMERGENCY_UNKNOWN

    def __repr__(self) -> str:
        return (
            f"EmergencyDetectionState("
            f"state={self.emergency_state.value}, "
            f"type={self.dominant_emergency_type.value}, "
            f"severity={self.dominant_severity.value}, "
            f"urgency={self.dominant_urgency.value}, "
            f"confidence={self.confidence:.2f}, "
            f"events={len(self.active_events)})"
        )
