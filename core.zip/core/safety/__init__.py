"""
IndiDrive AI — Phase 11.1 + 11.2 | Safety Package
====================================================
Phase 11.1: Safety Monitor
Phase 11.2: Emergency Detector
"""
# Phase 11.1 — Safety Monitor
from core.safety.safety_types import (
    SAFETY_MONITOR_SCHEMA_VERSION,
    SafetyConditionSeverity,
    SafetyEvent,
    SafetyMonitorState,
    SafetyObservation,
    SafetyObservationSource,
    SafetyReasonCode,
    SafetyState,
    SubsystemHealth,
    SubsystemHealthState,
)
from core.safety.safety_config import SafetyMonitorConfig
from core.safety.safety_monitor import SafetyMonitor

# Phase 11.2 — Emergency Detector
from core.safety.emergency_types import (
    EMERGENCY_SCHEMA_VERSION,
    EmergencyDetectionState,
    EmergencyEvent as EmergencyDetectionEvent,
    EmergencyEvidence,
    EmergencySource,
    EmergencyState,
    EmergencySeverity,
    EmergencyType,
    EmergencyUrgency,
)
from core.safety.emergency_config import EmergencyDetectorConfig
from core.safety.emergency_detector import EmergencyDetector

__all__ = [
    # Phase 11.1
    "SAFETY_MONITOR_SCHEMA_VERSION",
    "SafetyMonitor",
    "SafetyMonitorConfig",
    "SafetyMonitorState",
    "SafetyState",
    "SafetyObservation",
    "SafetyObservationSource",
    "SafetyEvent",
    "SafetyReasonCode",
    "SafetyConditionSeverity",
    "SubsystemHealth",
    "SubsystemHealthState",
    # Phase 11.2
    "EMERGENCY_SCHEMA_VERSION",
    "EmergencyDetector",
    "EmergencyDetectorConfig",
    "EmergencyDetectionState",
    "EmergencyDetectionEvent",
    "EmergencyEvidence",
    "EmergencySource",
    "EmergencyState",
    "EmergencySeverity",
    "EmergencyType",
    "EmergencyUrgency",
]
