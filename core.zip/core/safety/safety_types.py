"""
IndiDrive AI — Phase 11.1 | Safety Monitor Types
==================================================
Typed enumerations and immutable data containers for the Safety Monitor.

Design rules:
  * All containers are frozen dataclasses — immutable after construction.
  * No computation in this module — only type definitions.
  * No circular imports — only stdlib and typing.
  * Deterministic: same input → same output.
  * UNKNOWN is treated as an explicit state, not a default SAFE fallback.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Optional, Tuple

__all__ = [
    # Schema
    "SAFETY_MONITOR_SCHEMA_VERSION",
    # Enums
    "SafetyState",
    "SubsystemHealthState",
    "SafetyConditionSeverity",
    "SafetyReasonCode",
    "SafetyObservationSource",
    # Data containers
    "SubsystemHealth",
    "SafetyObservation",
    "SafetyEvent",
    "SafetyMonitorState",
]

SAFETY_MONITOR_SCHEMA_VERSION: str = "11.1"


# ---------------------------------------------------------------------------
# Safety state — overall assessment of the monitored system
# ---------------------------------------------------------------------------

class SafetyState(str, Enum):
    """
    Overall safety assessment produced by the Safety Monitor.

    SAFE        — All monitored subsystems are valid, fresh, and healthy.
                  No safety conditions detected.
    CAUTION     — Minor safety concern or slight degradation.
                  Autonomous operation is observable but requires awareness.
    RESTRICTED  — Meaningful operational limitation. At least one subsystem
                  is degraded or a non-critical safety condition is active.
    HIGH_ALERT  — Significant safety concern. Close monitoring required.
                  Multiple degraded subsystems or elevated risk conditions.
    CRITICAL    — Critical safety condition detected.
                  Immediate attention required.
    DEGRADED    — System can assess safety, but one or more required
                  subsystems report degraded state.
    UNKNOWN     — Insufficient valid information to establish reliable
                  safety state. Must NOT be silently converted to SAFE.
    """
    SAFE       = "SAFE"
    CAUTION    = "CAUTION"
    RESTRICTED = "RESTRICTED"
    HIGH_ALERT = "HIGH_ALERT"
    CRITICAL   = "CRITICAL"
    DEGRADED   = "DEGRADED"
    UNKNOWN    = "UNKNOWN"


# Priority ordering for aggregation (lower index = higher priority)
SAFETY_STATE_PRIORITY: Tuple[SafetyState, ...] = (
    SafetyState.CRITICAL,
    SafetyState.HIGH_ALERT,
    SafetyState.RESTRICTED,
    SafetyState.CAUTION,
    SafetyState.DEGRADED,
    SafetyState.SAFE,
    # UNKNOWN is handled explicitly outside this ordering
)


# ---------------------------------------------------------------------------
# Subsystem health
# ---------------------------------------------------------------------------

class SubsystemHealthState(str, Enum):
    """
    Health state of a monitored subsystem.

    HEALTHY     — Subsystem is operating within expected parameters.
    DEGRADED    — Subsystem is operating but with reduced capability or confidence.
    STALE       — Subsystem data timestamp exceeds freshness threshold.
    INVALID     — Subsystem output failed validation.
    UNAVAILABLE — Subsystem output is missing (None / not provided).
    UNKNOWN     — Subsystem health cannot be determined.
    """
    HEALTHY     = "HEALTHY"
    DEGRADED    = "DEGRADED"
    STALE       = "STALE"
    INVALID     = "INVALID"
    UNAVAILABLE = "UNAVAILABLE"
    UNKNOWN     = "UNKNOWN"


# ---------------------------------------------------------------------------
# Severity for individual safety conditions
# ---------------------------------------------------------------------------

class SafetyConditionSeverity(str, Enum):
    """
    Severity of an individual safety condition/observation.

    Maps to SafetyState during aggregation but is stored separately
    to preserve the distinction between severity and overall state.
    """
    CRITICAL   = "CRITICAL"
    HIGH_ALERT = "HIGH_ALERT"
    RESTRICTED = "RESTRICTED"
    CAUTION    = "CAUTION"
    DEGRADED   = "DEGRADED"
    INFO       = "INFO"


# ---------------------------------------------------------------------------
# Reason codes
# ---------------------------------------------------------------------------

class SafetyReasonCode(str, Enum):
    """
    Deterministic string codes explaining why a safety state was assessed.
    """
    # World model
    WORLD_MODEL_INVALID           = "WORLD_MODEL_INVALID"
    WORLD_MODEL_STALE             = "WORLD_MODEL_STALE"
    WORLD_MODEL_DEGRADED          = "WORLD_MODEL_DEGRADED"
    WORLD_MODEL_EMPTY             = "WORLD_MODEL_EMPTY"
    WORLD_MODEL_UNAVAILABLE       = "WORLD_MODEL_UNAVAILABLE"

    # Planning
    PLANNER_INVALID               = "PLANNER_INVALID"
    PLANNER_STALE                 = "PLANNER_STALE"
    PLANNER_DEGRADED              = "PLANNER_DEGRADED"
    PLANNER_BLOCKED               = "PLANNER_BLOCKED"
    PLANNER_NO_FEASIBLE_CANDIDATE = "PLANNER_NO_FEASIBLE_CANDIDATE"
    PLANNING_NOT_ALLOWED          = "PLANNING_NOT_ALLOWED"
    PLANNER_UNAVAILABLE           = "PLANNER_UNAVAILABLE"

    # Tracking
    TRACKING_INVALID              = "TRACKING_INVALID"
    TRACKING_STALE_REFERENCE      = "TRACKING_STALE_REFERENCE"
    TRACKING_DEGRADED             = "TRACKING_DEGRADED"
    TRACKING_REFERENCE_LOST       = "TRACKING_REFERENCE_LOST"
    TRACKING_LARGE_DEVIATION      = "TRACKING_LARGE_DEVIATION"
    TRACKING_UNAVAILABLE          = "TRACKING_UNAVAILABLE"

    # MPC
    MPC_INVALID                   = "MPC_INVALID"
    MPC_STALE                     = "MPC_STALE"
    MPC_DEGRADED                  = "MPC_DEGRADED"
    MPC_NO_FEASIBLE_SOLUTION      = "MPC_NO_FEASIBLE_SOLUTION"
    MPC_CONSTRAINT_VIOLATION      = "MPC_CONSTRAINT_VIOLATION"
    MPC_UNAVAILABLE               = "MPC_UNAVAILABLE"

    # Control
    CONTROL_INVALID               = "CONTROL_INVALID"
    CONTROL_STALE                 = "CONTROL_STALE"
    CONTROL_NO_SOLUTION           = "CONTROL_NO_SOLUTION"
    CONTROL_UNAVAILABLE           = "CONTROL_UNAVAILABLE"

    # Vehicle dynamics
    VEHICLE_DYNAMICS_INVALID      = "VEHICLE_DYNAMICS_INVALID"
    VEHICLE_DYNAMICS_UNAVAILABLE  = "VEHICLE_DYNAMICS_UNAVAILABLE"

    # Safety gate
    SAFETY_GATE_CRITICAL          = "SAFETY_GATE_CRITICAL"
    SAFETY_GATE_HIGH_ALERT        = "SAFETY_GATE_HIGH_ALERT"
    SAFETY_GATE_RESTRICTED        = "SAFETY_GATE_RESTRICTED"
    SAFETY_GATE_DEGRADED          = "SAFETY_GATE_DEGRADED"
    SAFETY_GATE_UNKNOWN           = "SAFETY_GATE_UNKNOWN"

    # Pipeline
    PIPELINE_DEGRADED             = "PIPELINE_DEGRADED"
    PIPELINE_FAILED               = "PIPELINE_FAILED"
    PIPELINE_STALE_INPUT          = "PIPELINE_STALE_INPUT"
    PIPELINE_INVALID_INPUT        = "PIPELINE_INVALID_INPUT"
    PIPELINE_UNAVAILABLE          = "PIPELINE_UNAVAILABLE"

    # Numerical
    NUMERICAL_FAILURE             = "NUMERICAL_FAILURE"

    # Unknown
    INSUFFICIENT_INFORMATION      = "INSUFFICIENT_INFORMATION"
    UNKNOWN_STATE                 = "UNKNOWN_STATE"


# ---------------------------------------------------------------------------
# Observation source
# ---------------------------------------------------------------------------

class SafetyObservationSource(str, Enum):
    """Source subsystem for a safety observation."""
    WORLD_MODEL    = "WORLD_MODEL"
    PLANNER        = "PLANNER"
    TRACKING       = "TRACKING"
    MPC            = "MPC"
    CONTROL        = "CONTROL"
    VEHICLE        = "VEHICLE"
    PIPELINE       = "PIPELINE"
    SAFETY_GATE    = "SAFETY_GATE"
    SAFETY_MONITOR = "SAFETY_MONITOR"


# ---------------------------------------------------------------------------
# Subsystem health container
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class SubsystemHealth:
    """
    Compact health representation for one monitored subsystem.

    Fields
    ------
    subsystem   : Name of the subsystem.
    state       : SubsystemHealthState enum.
    reason      : Human-readable diagnostic.
    reason_code : Machine-readable SafetyReasonCode (or None).
    timestamp   : Timestamp from the subsystem data (0.0 if unavailable).
    stale       : True if data timestamp exceeds freshness threshold.
    degraded    : True if subsystem self-reports degradation.
    valid       : True if subsystem output passed validation.
    """
    subsystem:   str                           = "unknown"
    state:       SubsystemHealthState          = SubsystemHealthState.UNKNOWN
    reason:      str                           = ""
    reason_code: Optional[SafetyReasonCode]    = None
    timestamp:   float                         = 0.0
    stale:       bool                          = False
    degraded:    bool                          = False
    valid:       bool                          = False


# ---------------------------------------------------------------------------
# Safety observation — result of evaluating one safety condition
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class SafetyObservation:
    """
    Immutable observation of one safety condition.

    Each observation captures a single detected condition from one source.
    Multiple observations are aggregated by SafetyMonitor into overall state.

    Fields
    ------
    observation_id      : Deterministic string ID (source:reason_code).
    timestamp           : Timestamp from the source data.
    source              : SafetyObservationSource enum.
    subsystem           : Subsystem name string.
    condition           : Human-readable condition description.
    severity            : SafetyConditionSeverity enum.
    confidence          : [0.0, 1.0] confidence in this observation.
    uncertainty         : [0.0, 1.0] uncertainty (separate from severity).
    reason_code         : SafetyReasonCode enum.
    affected_component  : Component name if specific (or empty string).
    stale               : True if observation is based on stale data.
    degraded            : True if observation indicates degradation.
    valid               : True if observation is from valid data.
    metadata            : Optional dict of extra diagnostic info.
    schema_version      : Schema version string.
    """
    observation_id:     str                        = ""
    timestamp:          float                      = 0.0
    source:             SafetyObservationSource    = SafetyObservationSource.SAFETY_MONITOR
    subsystem:          str                        = ""
    condition:          str                        = ""
    severity:           SafetyConditionSeverity    = SafetyConditionSeverity.INFO
    confidence:         float                      = 0.0
    uncertainty:        float                      = 1.0
    reason_code:        SafetyReasonCode           = SafetyReasonCode.UNKNOWN_STATE
    affected_component: str                        = ""
    stale:              bool                       = False
    degraded:           bool                       = False
    valid:              bool                       = True
    metadata:           Optional[dict]             = None
    schema_version:     str                        = SAFETY_MONITOR_SCHEMA_VERSION


# ---------------------------------------------------------------------------
# Safety event
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class SafetyEvent:
    """
    Structured safety event produced when a safety condition is detected.

    Events are deterministic: same input → same event_id.

    Fields
    ------
    event_id            : Deterministic string ID (source:reason_code:timestamp).
    timestamp           : Timestamp from source data.
    event_type          : String event type (matches reason_code).
    severity            : SafetyConditionSeverity enum.
    source              : SafetyObservationSource enum.
    reason_code         : SafetyReasonCode enum.
    affected_subsystem  : Subsystem name string.
    affected_object     : Object identifier if applicable (or empty).
    confidence          : [0.0, 1.0].
    uncertainty         : [0.0, 1.0].
    stale               : True if event relates to stale data.
    degraded            : True if event relates to degraded state.
    metadata            : Optional extra diagnostic info.
    schema_version      : Schema version string.
    """
    event_id:           str                        = ""
    timestamp:          float                      = 0.0
    event_type:         str                        = ""
    severity:           SafetyConditionSeverity    = SafetyConditionSeverity.INFO
    source:             SafetyObservationSource    = SafetyObservationSource.SAFETY_MONITOR
    reason_code:        SafetyReasonCode           = SafetyReasonCode.UNKNOWN_STATE
    affected_subsystem: str                        = ""
    affected_object:    str                        = ""
    confidence:         float                      = 0.0
    uncertainty:        float                      = 1.0
    stale:              bool                       = False
    degraded:           bool                       = False
    metadata:           Optional[dict]             = None
    schema_version:     str                        = SAFETY_MONITOR_SCHEMA_VERSION


# ---------------------------------------------------------------------------
# Safety Monitor State — final immutable assessment snapshot
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class SafetyMonitorState:
    """
    Immutable snapshot of the Safety Monitor's assessment for one cycle.

    This is the primary output of Phase 11.1.
    It must NOT directly control the vehicle.
    It provides safety state information for later phases (11.2–11.5).

    Fields
    ------
    timestamp           : Timestamp from the primary input (not wall clock).
    schema_version      : "11.1".
    monitor_status      : "OK" | "DEGRADED" | "UNAVAILABLE".
    overall_safety_state: SafetyState enum — the aggregated safety assessment.
    dominant_reason     : The most important reason code string.
    reason_codes        : Tuple of all active reason code strings.
    observations        : Tuple of SafetyObservation (one per detected condition).
    subsystem_health    : Tuple of SubsystemHealth (one per monitored subsystem).
    active_events       : Tuple of SafetyEvent.
    affected_components : Tuple of affected component names.
    confidence          : [0.0, 1.0] overall confidence in the assessment.
    uncertainty         : [0.0, 1.0] overall uncertainty.
    stale               : True if any critical input was stale.
    degraded            : True if any subsystem is degraded.
    valid               : True if assessment is based on sufficient valid data.
    """
    timestamp:            float                          = 0.0
    schema_version:       str                            = SAFETY_MONITOR_SCHEMA_VERSION
    monitor_status:       str                            = "UNAVAILABLE"
    overall_safety_state: SafetyState                   = SafetyState.UNKNOWN
    dominant_reason:      str                            = SafetyReasonCode.UNKNOWN_STATE.value
    reason_codes:         Tuple[str, ...]                = field(default_factory=tuple)
    observations:         Tuple[SafetyObservation, ...]  = field(default_factory=tuple)
    subsystem_health:     Tuple[SubsystemHealth, ...]    = field(default_factory=tuple)
    active_events:        Tuple[SafetyEvent, ...]        = field(default_factory=tuple)
    affected_components:  Tuple[str, ...]                = field(default_factory=tuple)
    confidence:           float                          = 0.0
    uncertainty:          float                          = 1.0
    stale:                bool                           = True
    degraded:             bool                           = True
    valid:                bool                           = False

    @property
    def is_safe(self) -> bool:
        """True only if overall safety state is SAFE."""
        return self.overall_safety_state == SafetyState.SAFE

    @property
    def is_critical(self) -> bool:
        """True if overall safety state is CRITICAL."""
        return self.overall_safety_state == SafetyState.CRITICAL

    @property
    def is_unknown(self) -> bool:
        """True if overall safety state is UNKNOWN."""
        return self.overall_safety_state == SafetyState.UNKNOWN

    def __repr__(self) -> str:
        return (
            f"SafetyMonitorState("
            f"state={self.overall_safety_state.value}, "
            f"confidence={self.confidence:.2f}, "
            f"degraded={self.degraded}, "
            f"observations={len(self.observations)})"
        )
