"""
IndiDrive AI — Phase 11.1 | Safety Monitor Engine
===================================================
Deterministic safety monitoring layer.

This module OBSERVES and REPORTS safety state only.
It does NOT:
  - generate paths or trajectories
  - run MPC
  - calculate steering, throttle, or brake commands
  - override controllers
  - send CAN commands
  - control hardware
  - perform emergency braking or steering

Architecture position:
    Runs alongside/above the existing closed-loop pipeline.
    Reads existing snapshots (world model, planner, tracking, MPC, control,
    vehicle, pipeline) and produces an immutable SafetyMonitorState.

Design rules:
  * Fully deterministic — same input → same output.
  * No wall-clock time inside pure evaluation logic.
    Timestamps come from input data.
  * No random values, no random IDs.
  * Conservative under degradation — unknown → UNKNOWN, not SAFE.
  * NaN/infinity handled gracefully — returns structured degraded state.
  * No modification of any existing Phase 0–10.5 module.
"""
from __future__ import annotations

import math
from typing import Dict, List, Optional, Tuple

from .safety_config import SafetyMonitorConfig
from .safety_types import (
    SAFETY_MONITOR_SCHEMA_VERSION,
    SafetyConditionSeverity,
    SafetyEvent,
    SafetyMonitorState,
    SafetyObservation,
    SafetyObservationSource,
    SafetyReasonCode,
    SafetyState,
    SAFETY_STATE_PRIORITY,
    SubsystemHealth,
    SubsystemHealthState,
)

__all__ = ["SafetyMonitor"]


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _is_finite(val: object) -> bool:
    """Return True iff val is a finite float/int (not NaN, not Inf)."""
    try:
        f = float(val)  # type: ignore[arg-type]
        return math.isfinite(f)
    except (TypeError, ValueError):
        return False


def _is_valid_timestamp(ts: object) -> bool:
    """Return True iff ts is a finite non-negative float."""
    try:
        f = float(ts)  # type: ignore[arg-type]
        return math.isfinite(f) and f >= 0.0
    except (TypeError, ValueError):
        return False


def _is_stale(data_ts: float, ref_ts: float, max_age_s: float) -> bool:
    """
    Return True if data_ts is older than max_age_s relative to ref_ts.
    Both must be valid timestamps.  If either is invalid, returns True (conservative).
    """
    if not _is_valid_timestamp(data_ts) or not _is_valid_timestamp(ref_ts):
        return True
    age = ref_ts - data_ts
    return age > max_age_s


def _severity_to_state(sev: SafetyConditionSeverity) -> SafetyState:
    """Map a condition severity to the corresponding SafetyState."""
    _MAP = {
        SafetyConditionSeverity.CRITICAL:   SafetyState.CRITICAL,
        SafetyConditionSeverity.HIGH_ALERT: SafetyState.HIGH_ALERT,
        SafetyConditionSeverity.RESTRICTED: SafetyState.RESTRICTED,
        SafetyConditionSeverity.CAUTION:    SafetyState.CAUTION,
        SafetyConditionSeverity.DEGRADED:   SafetyState.DEGRADED,
        SafetyConditionSeverity.INFO:       SafetyState.SAFE,
    }
    return _MAP.get(sev, SafetyState.UNKNOWN)


def _aggregate_states(states: List[SafetyState]) -> SafetyState:
    """
    Aggregate multiple SafetyState values into the highest-priority one.
    UNKNOWN propagates explicitly if there are no higher-priority states.
    """
    if not states:
        return SafetyState.UNKNOWN

    # Check UNKNOWN separately — it must not be confused with low priority
    has_unknown = SafetyState.UNKNOWN in states
    non_unknown = [s for s in states if s != SafetyState.UNKNOWN]

    if not non_unknown:
        return SafetyState.UNKNOWN

    # Walk priority list: first match wins
    for priority_state in SAFETY_STATE_PRIORITY:
        if priority_state in non_unknown:
            return priority_state

    # Fallback (should not reach here for valid states in priority list)
    if has_unknown:
        return SafetyState.UNKNOWN
    return SafetyState.SAFE


def _make_observation(
    source: SafetyObservationSource,
    subsystem: str,
    condition: str,
    severity: SafetyConditionSeverity,
    reason_code: SafetyReasonCode,
    timestamp: float,
    confidence: float = 1.0,
    uncertainty: float = 0.0,
    stale: bool = False,
    degraded: bool = False,
    valid: bool = True,
    affected_component: str = "",
    metadata: Optional[dict] = None,
) -> SafetyObservation:
    """Build a deterministic SafetyObservation."""
    obs_id = f"{source.value}:{reason_code.value}"
    return SafetyObservation(
        observation_id=obs_id,
        timestamp=timestamp,
        source=source,
        subsystem=subsystem,
        condition=condition,
        severity=severity,
        confidence=min(1.0, max(0.0, confidence)),
        uncertainty=min(1.0, max(0.0, uncertainty)),
        reason_code=reason_code,
        affected_component=affected_component,
        stale=stale,
        degraded=degraded,
        valid=valid,
        metadata=metadata,
        schema_version=SAFETY_MONITOR_SCHEMA_VERSION,
    )


def _make_event(
    source: SafetyObservationSource,
    subsystem: str,
    severity: SafetyConditionSeverity,
    reason_code: SafetyReasonCode,
    timestamp: float,
    confidence: float = 1.0,
    uncertainty: float = 0.0,
    stale: bool = False,
    degraded: bool = False,
    affected_object: str = "",
    metadata: Optional[dict] = None,
) -> SafetyEvent:
    """Build a deterministic SafetyEvent."""
    event_id = f"{source.value}:{reason_code.value}:{timestamp:.6f}"
    return SafetyEvent(
        event_id=event_id,
        timestamp=timestamp,
        event_type=reason_code.value,
        severity=severity,
        source=source,
        reason_code=reason_code,
        affected_subsystem=subsystem,
        affected_object=affected_object,
        confidence=min(1.0, max(0.0, confidence)),
        uncertainty=min(1.0, max(0.0, uncertainty)),
        stale=stale,
        degraded=degraded,
        metadata=metadata,
        schema_version=SAFETY_MONITOR_SCHEMA_VERSION,
    )


# ---------------------------------------------------------------------------
# Safety Monitor
# ---------------------------------------------------------------------------

class SafetyMonitor:
    """
    Deterministic safety monitoring engine for Phase 11.1.

    Usage
    -----
    ::
        monitor = SafetyMonitor(SafetyMonitorConfig.default())
        state = monitor.assess(
            world_model_snapshot=wm,
            planner_output=po,
            tracking_snapshot=ts,
            mpc_snapshot=mpc,
            control_command=cmd,
            dynamics_snapshot=dyn,
            pipeline_snapshot=pipe,
        )

    All arguments are optional — None means 'unavailable'.

    The same input state always produces the same SafetyMonitorState.
    The result does NOT control the vehicle.
    """

    def __init__(self, config: Optional[SafetyMonitorConfig] = None) -> None:
        self._cfg = config if config is not None else SafetyMonitorConfig.default()

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def assess(
        self,
        *,
        world_model_snapshot=None,
        planner_output=None,
        tracking_snapshot=None,
        mpc_snapshot=None,
        control_command=None,
        dynamics_snapshot=None,
        pipeline_snapshot=None,
        reference_timestamp: Optional[float] = None,
    ) -> SafetyMonitorState:
        """
        Evaluate system safety state from current snapshots.

        Parameters
        ----------
        world_model_snapshot  : WorldModelSnapshot or None.
        planner_output        : PlannerOutput or None.
        tracking_snapshot     : TrackingSnapshot or None.
        mpc_snapshot          : MPCSnapshot or None.
        control_command       : VehicleControlCommand or None.
        dynamics_snapshot     : DynamicsSnapshot or None.
        pipeline_snapshot     : PipelineSnapshot or None.
        reference_timestamp   : Reference timestamp for staleness checks.
                                If None, derived from the most recent input.

        Returns
        -------
        SafetyMonitorState — immutable, deterministic, snapshot.
        """
        try:
            return self._assess_safe(
                world_model_snapshot=world_model_snapshot,
                planner_output=planner_output,
                tracking_snapshot=tracking_snapshot,
                mpc_snapshot=mpc_snapshot,
                control_command=control_command,
                dynamics_snapshot=dynamics_snapshot,
                pipeline_snapshot=pipeline_snapshot,
                reference_timestamp=reference_timestamp,
            )
        except Exception as exc:  # pragma: no cover — defensive wrapper
            # Numerical or structural failure inside the monitor itself.
            # Return a minimal UNKNOWN state rather than crashing the pipeline.
            ts = reference_timestamp if _is_valid_timestamp(reference_timestamp) else 0.0
            obs = _make_observation(
                source=SafetyObservationSource.SAFETY_MONITOR,
                subsystem="safety_monitor",
                condition=f"Safety monitor internal error: {exc}",
                severity=SafetyConditionSeverity.CRITICAL,
                reason_code=SafetyReasonCode.UNKNOWN_STATE,
                timestamp=ts,
                confidence=0.0,
                uncertainty=1.0,
                valid=False,
            )
            return SafetyMonitorState(
                timestamp=ts,
                schema_version=SAFETY_MONITOR_SCHEMA_VERSION,
                monitor_status="ERROR",
                overall_safety_state=SafetyState.UNKNOWN,
                dominant_reason=SafetyReasonCode.UNKNOWN_STATE.value,
                reason_codes=(SafetyReasonCode.UNKNOWN_STATE.value,),
                observations=(obs,),
                confidence=0.0,
                uncertainty=1.0,
                stale=True,
                degraded=True,
                valid=False,
            )

    # ------------------------------------------------------------------
    # Internal evaluation
    # ------------------------------------------------------------------

    def _assess_safe(
        self,
        *,
        world_model_snapshot,
        planner_output,
        tracking_snapshot,
        mpc_snapshot,
        control_command,
        dynamics_snapshot,
        pipeline_snapshot,
        reference_timestamp,
    ) -> SafetyMonitorState:
        cfg = self._cfg

        # Determine reference timestamp for staleness checks
        ref_ts = self._derive_reference_timestamp(
            reference_timestamp=reference_timestamp,
            world_model_snapshot=world_model_snapshot,
            planner_output=planner_output,
            tracking_snapshot=tracking_snapshot,
            mpc_snapshot=mpc_snapshot,
            control_command=control_command,
            dynamics_snapshot=dynamics_snapshot,
            pipeline_snapshot=pipeline_snapshot,
        )

        observations: List[SafetyObservation] = []
        events: List[SafetyEvent] = []
        health_map: Dict[str, SubsystemHealth] = {}

        # --- Evaluate each subsystem ---
        wm_health, wm_obs, wm_events = self._check_world_model(
            world_model_snapshot, ref_ts, cfg
        )
        health_map["world_model"] = wm_health
        observations.extend(wm_obs)
        events.extend(wm_events)

        pl_health, pl_obs, pl_events = self._check_planner(
            planner_output, ref_ts, cfg
        )
        health_map["planner"] = pl_health
        observations.extend(pl_obs)
        events.extend(pl_events)

        tr_health, tr_obs, tr_events = self._check_tracking(
            tracking_snapshot, ref_ts, cfg
        )
        health_map["tracking"] = tr_health
        observations.extend(tr_obs)
        events.extend(tr_events)

        mpc_health, mpc_obs, mpc_events = self._check_mpc(
            mpc_snapshot, ref_ts, cfg
        )
        health_map["mpc"] = mpc_health
        observations.extend(mpc_obs)
        events.extend(mpc_events)

        ctrl_health, ctrl_obs, ctrl_events = self._check_control(
            control_command, ref_ts, cfg
        )
        health_map["control"] = ctrl_health
        observations.extend(ctrl_obs)
        events.extend(ctrl_events)

        veh_health, veh_obs, veh_events = self._check_vehicle(
            dynamics_snapshot, ref_ts, cfg
        )
        health_map["vehicle"] = veh_health
        observations.extend(veh_obs)
        events.extend(veh_events)

        pipe_health, pipe_obs, pipe_events = self._check_pipeline(
            pipeline_snapshot, ref_ts, cfg
        )
        health_map["pipeline"] = pipe_health
        observations.extend(pipe_obs)
        events.extend(pipe_events)

        # --- Aggregate ---
        overall_state = self._aggregate(observations, health_map, cfg)
        reason_codes = self._collect_reason_codes(observations)
        dominant = reason_codes[0] if reason_codes else SafetyReasonCode.UNKNOWN_STATE.value
        affected = tuple(sorted({
            obs.affected_component for obs in observations
            if obs.affected_component
        }))
        confidence = self._aggregate_confidence(observations, health_map)
        uncertainty = 1.0 - confidence
        stale = any(obs.stale for obs in observations)
        degraded = any(
            h.state in (SubsystemHealthState.DEGRADED, SubsystemHealthState.STALE)
            for h in health_map.values()
        )
        # valid = True only when at least one required subsystem is HEALTHY
        # and the overall state is not UNKNOWN
        any_healthy = any(
            health_map.get(s, SubsystemHealth(
                subsystem=s, state=SubsystemHealthState.UNAVAILABLE
            )).state == SubsystemHealthState.HEALTHY
            for s in cfg.required_subsystems
        )
        valid = any_healthy and overall_state != SafetyState.UNKNOWN

        # If all required subsystems have no observations (all healthy), set SAFE
        # but only if there are no problematic observations
        if not observations and all(
            health_map.get(s, SubsystemHealth(subsystem=s, state=SubsystemHealthState.UNAVAILABLE)).state
            == SubsystemHealthState.UNAVAILABLE
            for s in cfg.required_subsystems
        ):
            overall_state = SafetyState.UNKNOWN
            reason_codes = (SafetyReasonCode.INSUFFICIENT_INFORMATION.value,)
            dominant = SafetyReasonCode.INSUFFICIENT_INFORMATION.value
            valid = False

        monitor_status = "OK" if overall_state not in (SafetyState.UNKNOWN,) else "DEGRADED"
        if not valid:
            monitor_status = "DEGRADED"

        return SafetyMonitorState(
            timestamp=ref_ts,
            schema_version=SAFETY_MONITOR_SCHEMA_VERSION,
            monitor_status=monitor_status,
            overall_safety_state=overall_state,
            dominant_reason=dominant,
            reason_codes=tuple(reason_codes),
            observations=tuple(observations),
            subsystem_health=tuple(health_map[k] for k in sorted(health_map.keys())),
            active_events=tuple(events),
            affected_components=affected,
            confidence=confidence,
            uncertainty=uncertainty,
            stale=stale,
            degraded=degraded,
            valid=valid,
        )

    # ------------------------------------------------------------------
    # Reference timestamp derivation
    # ------------------------------------------------------------------

    def _derive_reference_timestamp(self, *, reference_timestamp, **snapshots) -> float:
        """
        Return the reference timestamp for staleness checks.
        Uses explicit reference_timestamp if valid, otherwise derives from inputs.
        """
        if _is_valid_timestamp(reference_timestamp):
            return float(reference_timestamp)

        # Collect timestamps from all available inputs
        candidates: List[float] = []

        wm = snapshots.get("world_model_snapshot")
        if wm is not None:
            ts = getattr(wm, "timestamp", None)
            if _is_valid_timestamp(ts):
                candidates.append(float(ts))

        po = snapshots.get("planner_output")
        if po is not None:
            ts = getattr(po, "timestamp", None)
            if _is_valid_timestamp(ts):
                candidates.append(float(ts))

        tr = snapshots.get("tracking_snapshot")
        if tr is not None:
            ts = getattr(tr, "snap_timestamp", None)
            if _is_valid_timestamp(ts):
                candidates.append(float(ts))

        mpc = snapshots.get("mpc_snapshot")
        if mpc is not None:
            ts = getattr(mpc, "snap_timestamp", None)
            if _is_valid_timestamp(ts):
                candidates.append(float(ts))

        cmd = snapshots.get("control_command")
        if cmd is not None:
            ts = getattr(cmd, "timestamp", None)
            if _is_valid_timestamp(ts):
                candidates.append(float(ts))

        dyn = snapshots.get("dynamics_snapshot")
        if dyn is not None:
            ts = getattr(dyn, "snapshot_timestamp", None)
            if _is_valid_timestamp(ts):
                candidates.append(float(ts))

        pipe = snapshots.get("pipeline_snapshot")
        if pipe is not None:
            ts = getattr(pipe, "timestamp", None)
            if _is_valid_timestamp(ts):
                candidates.append(float(ts))

        return max(candidates) if candidates else 0.0

    # ------------------------------------------------------------------
    # World model checks
    # ------------------------------------------------------------------

    def _check_world_model(
        self, wm, ref_ts: float, cfg: SafetyMonitorConfig
    ) -> Tuple[SubsystemHealth, List[SafetyObservation], List[SafetyEvent]]:
        source = SafetyObservationSource.WORLD_MODEL
        subsystem = "world_model"
        obs: List[SafetyObservation] = []
        events: List[SafetyEvent] = []

        if wm is None:
            health = SubsystemHealth(
                subsystem=subsystem,
                state=SubsystemHealthState.UNAVAILABLE,
                reason="World model snapshot is None",
                reason_code=SafetyReasonCode.WORLD_MODEL_UNAVAILABLE,
                timestamp=0.0,
                stale=False,
                degraded=False,
                valid=False,
            )
            o = _make_observation(
                source=source, subsystem=subsystem,
                condition="World model snapshot unavailable",
                severity=SafetyConditionSeverity.HIGH_ALERT,
                reason_code=SafetyReasonCode.WORLD_MODEL_UNAVAILABLE,
                timestamp=ref_ts, confidence=1.0, uncertainty=0.0,
                valid=False, degraded=False,
            )
            obs.append(o)
            events.append(_make_event(
                source=source, subsystem=subsystem,
                severity=SafetyConditionSeverity.HIGH_ALERT,
                reason_code=SafetyReasonCode.WORLD_MODEL_UNAVAILABLE,
                timestamp=ref_ts,
            ))
            return health, obs, events

        wm_ts = float(getattr(wm, "timestamp", 0.0))
        if not _is_valid_timestamp(wm_ts):
            wm_ts = 0.0

        # Check status
        wm_status = getattr(wm, "status", None)
        wm_status_val = str(wm_status.value) if hasattr(wm_status, "value") else str(wm_status or "")

        if wm_status_val in ("INVALID",):
            health = SubsystemHealth(
                subsystem=subsystem,
                state=SubsystemHealthState.INVALID,
                reason=f"World model status: {wm_status_val}",
                reason_code=SafetyReasonCode.WORLD_MODEL_INVALID,
                timestamp=wm_ts, stale=False, degraded=False, valid=False,
            )
            o = _make_observation(
                source=source, subsystem=subsystem,
                condition=f"World model invalid (status={wm_status_val})",
                severity=SafetyConditionSeverity.HIGH_ALERT,
                reason_code=SafetyReasonCode.WORLD_MODEL_INVALID,
                timestamp=wm_ts, confidence=1.0, uncertainty=0.0,
                valid=False, degraded=False,
            )
            obs.append(o)
            events.append(_make_event(
                source=source, subsystem=subsystem,
                severity=SafetyConditionSeverity.HIGH_ALERT,
                reason_code=SafetyReasonCode.WORLD_MODEL_INVALID,
                timestamp=wm_ts,
            ))
            return health, obs, events

        # Check staleness
        stale = _is_stale(wm_ts, ref_ts, cfg.world_model_max_age_s)

        # Check degradation
        data_quality = getattr(wm, "data_quality", None)
        is_degraded = False
        if data_quality is not None:
            is_degraded = bool(getattr(data_quality, "is_degraded", False))

        # Also check status for DEGRADED / EMPTY
        if wm_status_val in ("DEGRADED", "EMPTY"):
            is_degraded = True

        if stale:
            health = SubsystemHealth(
                subsystem=subsystem,
                state=SubsystemHealthState.STALE,
                reason=f"World model stale (ts={wm_ts:.3f}, ref={ref_ts:.3f})",
                reason_code=SafetyReasonCode.WORLD_MODEL_STALE,
                timestamp=wm_ts, stale=True, degraded=is_degraded, valid=True,
            )
            o = _make_observation(
                source=source, subsystem=subsystem,
                condition="World model data is stale",
                severity=SafetyConditionSeverity.RESTRICTED,
                reason_code=SafetyReasonCode.WORLD_MODEL_STALE,
                timestamp=wm_ts, confidence=0.7, uncertainty=0.3,
                stale=True, degraded=is_degraded, valid=True,
            )
            obs.append(o)
            events.append(_make_event(
                source=source, subsystem=subsystem,
                severity=SafetyConditionSeverity.RESTRICTED,
                reason_code=SafetyReasonCode.WORLD_MODEL_STALE,
                timestamp=wm_ts, stale=True,
            ))
        elif is_degraded:
            health = SubsystemHealth(
                subsystem=subsystem,
                state=SubsystemHealthState.DEGRADED,
                reason=f"World model degraded (status={wm_status_val})",
                reason_code=SafetyReasonCode.WORLD_MODEL_DEGRADED,
                timestamp=wm_ts, stale=False, degraded=True, valid=True,
            )
            o = _make_observation(
                source=source, subsystem=subsystem,
                condition="World model is degraded",
                severity=SafetyConditionSeverity.DEGRADED,
                reason_code=SafetyReasonCode.WORLD_MODEL_DEGRADED,
                timestamp=wm_ts, confidence=0.6, uncertainty=0.4,
                stale=False, degraded=True, valid=True,
            )
            obs.append(o)
        else:
            health = SubsystemHealth(
                subsystem=subsystem,
                state=SubsystemHealthState.HEALTHY,
                reason="World model OK",
                timestamp=wm_ts, stale=False, degraded=False, valid=True,
            )

        return health, obs, events

    # ------------------------------------------------------------------
    # Planner checks
    # ------------------------------------------------------------------

    def _check_planner(
        self, po, ref_ts: float, cfg: SafetyMonitorConfig
    ) -> Tuple[SubsystemHealth, List[SafetyObservation], List[SafetyEvent]]:
        source = SafetyObservationSource.PLANNER
        subsystem = "planner"
        obs: List[SafetyObservation] = []
        events: List[SafetyEvent] = []

        if po is None:
            health = SubsystemHealth(
                subsystem=subsystem, state=SubsystemHealthState.UNAVAILABLE,
                reason="Planner output is None",
                reason_code=SafetyReasonCode.PLANNER_UNAVAILABLE,
                timestamp=0.0, valid=False,
            )
            obs.append(_make_observation(
                source=source, subsystem=subsystem,
                condition="Planner output unavailable",
                severity=SafetyConditionSeverity.HIGH_ALERT,
                reason_code=SafetyReasonCode.PLANNER_UNAVAILABLE,
                timestamp=ref_ts, confidence=1.0, uncertainty=0.0, valid=False,
            ))
            return health, obs, events

        po_ts = float(getattr(po, "timestamp", 0.0))
        if not _is_valid_timestamp(po_ts):
            po_ts = 0.0

        stale = _is_stale(po_ts, ref_ts, cfg.planner_max_age_s)
        is_degraded = bool(getattr(po, "degraded", True))
        po_stale = bool(getattr(po, "stale", False))

        # Check planning_status
        planning_status = getattr(po, "planning_status", None)
        ps_val = str(planning_status.value if hasattr(planning_status, "value") else planning_status or "UNKNOWN")

        # Check safety_gate_state from planner output
        gate_state = str(getattr(po, "safety_gate_state", "") or "")
        planning_allowed = bool(getattr(po, "planning_allowed", False))

        # Safety gate critical states
        if gate_state in ("CRITICAL",):
            o = _make_observation(
                source=SafetyObservationSource.SAFETY_GATE, subsystem="safety_gate",
                condition=f"Safety gate in CRITICAL state",
                severity=SafetyConditionSeverity.CRITICAL,
                reason_code=SafetyReasonCode.SAFETY_GATE_CRITICAL,
                timestamp=po_ts, confidence=1.0, uncertainty=0.0,
                valid=True, degraded=False,
            )
            obs.append(o)
            events.append(_make_event(
                source=SafetyObservationSource.SAFETY_GATE, subsystem="safety_gate",
                severity=SafetyConditionSeverity.CRITICAL,
                reason_code=SafetyReasonCode.SAFETY_GATE_CRITICAL,
                timestamp=po_ts,
            ))
        elif gate_state in ("HIGH_ALERT",):
            obs.append(_make_observation(
                source=SafetyObservationSource.SAFETY_GATE, subsystem="safety_gate",
                condition="Safety gate in HIGH_ALERT state",
                severity=SafetyConditionSeverity.HIGH_ALERT,
                reason_code=SafetyReasonCode.SAFETY_GATE_HIGH_ALERT,
                timestamp=po_ts, confidence=1.0, uncertainty=0.0,
                valid=True,
            ))
        elif gate_state in ("RESTRICTED",):
            obs.append(_make_observation(
                source=SafetyObservationSource.SAFETY_GATE, subsystem="safety_gate",
                condition="Safety gate in RESTRICTED state",
                severity=SafetyConditionSeverity.RESTRICTED,
                reason_code=SafetyReasonCode.SAFETY_GATE_RESTRICTED,
                timestamp=po_ts, confidence=1.0, uncertainty=0.0,
                valid=True,
            ))
        elif gate_state in ("DEGRADED",):
            obs.append(_make_observation(
                source=SafetyObservationSource.SAFETY_GATE, subsystem="safety_gate",
                condition="Safety gate in DEGRADED state",
                severity=SafetyConditionSeverity.DEGRADED,
                reason_code=SafetyReasonCode.SAFETY_GATE_DEGRADED,
                timestamp=po_ts, confidence=1.0, uncertainty=0.0,
                valid=True, degraded=True,
            ))
        elif gate_state in ("UNKNOWN",):
            obs.append(_make_observation(
                source=SafetyObservationSource.SAFETY_GATE, subsystem="safety_gate",
                condition="Safety gate in UNKNOWN state",
                severity=SafetyConditionSeverity.RESTRICTED,
                reason_code=SafetyReasonCode.SAFETY_GATE_UNKNOWN,
                timestamp=po_ts, confidence=0.5, uncertainty=0.5,
                valid=False,
            ))

        # Check planner status
        if ps_val in ("INVALID_INPUT",):
            health = SubsystemHealth(
                subsystem=subsystem, state=SubsystemHealthState.INVALID,
                reason=f"Planner invalid input (status={ps_val})",
                reason_code=SafetyReasonCode.PLANNER_INVALID,
                timestamp=po_ts, valid=False,
            )
            obs.append(_make_observation(
                source=source, subsystem=subsystem,
                condition=f"Planner has invalid input (status={ps_val})",
                severity=SafetyConditionSeverity.HIGH_ALERT,
                reason_code=SafetyReasonCode.PLANNER_INVALID,
                timestamp=po_ts, confidence=1.0, uncertainty=0.0, valid=False,
            ))
            return health, obs, events

        if stale or po_stale:
            health = SubsystemHealth(
                subsystem=subsystem, state=SubsystemHealthState.STALE,
                reason=f"Planner output stale (ts={po_ts:.3f}, ref={ref_ts:.3f})",
                reason_code=SafetyReasonCode.PLANNER_STALE,
                timestamp=po_ts, stale=True, valid=True,
            )
            obs.append(_make_observation(
                source=source, subsystem=subsystem,
                condition="Planner output is stale",
                severity=SafetyConditionSeverity.RESTRICTED,
                reason_code=SafetyReasonCode.PLANNER_STALE,
                timestamp=po_ts, confidence=0.7, uncertainty=0.3,
                stale=True, valid=True,
            ))
            return health, obs, events

        if ps_val in ("BLOCKED", "NO_FEASIBLE_CANDIDATE"):
            code = SafetyReasonCode.PLANNER_BLOCKED if ps_val == "BLOCKED" else SafetyReasonCode.PLANNER_NO_FEASIBLE_CANDIDATE
            health = SubsystemHealth(
                subsystem=subsystem, state=SubsystemHealthState.DEGRADED,
                reason=f"Planner blocked (status={ps_val})",
                reason_code=code,
                timestamp=po_ts, degraded=True, valid=True,
            )
            obs.append(_make_observation(
                source=source, subsystem=subsystem,
                condition=f"Planner has no feasible plan (status={ps_val})",
                severity=SafetyConditionSeverity.HIGH_ALERT,
                reason_code=code,
                timestamp=po_ts, confidence=1.0, uncertainty=0.0,
                degraded=True, valid=True,
            ))
            return health, obs, events

        if ps_val in ("STALE_INPUT",):
            health = SubsystemHealth(
                subsystem=subsystem, state=SubsystemHealthState.STALE,
                reason=f"Planner stale input (status={ps_val})",
                reason_code=SafetyReasonCode.PLANNER_STALE,
                timestamp=po_ts, stale=True, valid=True,
            )
            obs.append(_make_observation(
                source=source, subsystem=subsystem,
                condition=f"Planner reports stale input (status={ps_val})",
                severity=SafetyConditionSeverity.RESTRICTED,
                reason_code=SafetyReasonCode.PLANNER_STALE,
                timestamp=po_ts, confidence=0.7, uncertainty=0.3,
                stale=True, valid=True,
            ))
            return health, obs, events

        if is_degraded or ps_val in ("DEGRADED",):
            health = SubsystemHealth(
                subsystem=subsystem, state=SubsystemHealthState.DEGRADED,
                reason=f"Planner degraded (status={ps_val})",
                reason_code=SafetyReasonCode.PLANNER_DEGRADED,
                timestamp=po_ts, degraded=True, valid=True,
            )
            obs.append(_make_observation(
                source=source, subsystem=subsystem,
                condition="Planner is degraded",
                severity=SafetyConditionSeverity.DEGRADED,
                reason_code=SafetyReasonCode.PLANNER_DEGRADED,
                timestamp=po_ts, confidence=0.6, uncertainty=0.4,
                degraded=True, valid=True,
            ))
            return health, obs, events

        health = SubsystemHealth(
            subsystem=subsystem, state=SubsystemHealthState.HEALTHY,
            reason="Planner OK", timestamp=po_ts, valid=True,
        )
        return health, obs, events

    # ------------------------------------------------------------------
    # Tracking checks
    # ------------------------------------------------------------------

    def _check_tracking(
        self, ts_snap, ref_ts: float, cfg: SafetyMonitorConfig
    ) -> Tuple[SubsystemHealth, List[SafetyObservation], List[SafetyEvent]]:
        source = SafetyObservationSource.TRACKING
        subsystem = "tracking"
        obs: List[SafetyObservation] = []
        events: List[SafetyEvent] = []

        if ts_snap is None:
            health = SubsystemHealth(
                subsystem=subsystem, state=SubsystemHealthState.UNAVAILABLE,
                reason="Tracking snapshot is None",
                reason_code=SafetyReasonCode.TRACKING_UNAVAILABLE,
                timestamp=0.0, valid=False,
            )
            obs.append(_make_observation(
                source=source, subsystem=subsystem,
                condition="Tracking snapshot unavailable",
                severity=SafetyConditionSeverity.HIGH_ALERT,
                reason_code=SafetyReasonCode.TRACKING_UNAVAILABLE,
                timestamp=ref_ts, confidence=1.0, uncertainty=0.0, valid=False,
            ))
            return health, obs, events

        snap_ts = float(getattr(ts_snap, "snap_timestamp", 0.0))
        if not _is_valid_timestamp(snap_ts):
            snap_ts = 0.0

        stale = _is_stale(snap_ts, ref_ts, cfg.tracking_max_age_s)
        is_degraded = bool(getattr(ts_snap, "degraded", True))

        tracking_quality = getattr(ts_snap, "tracking_quality", None)
        tq_val = str(tracking_quality.value if hasattr(tracking_quality, "value") else tracking_quality or "UNKNOWN")

        if tq_val in ("INVALID_INPUT",):
            health = SubsystemHealth(
                subsystem=subsystem, state=SubsystemHealthState.INVALID,
                reason=f"Tracking invalid input (quality={tq_val})",
                reason_code=SafetyReasonCode.TRACKING_INVALID,
                timestamp=snap_ts, valid=False,
            )
            obs.append(_make_observation(
                source=source, subsystem=subsystem,
                condition=f"Tracking has invalid input (quality={tq_val})",
                severity=SafetyConditionSeverity.HIGH_ALERT,
                reason_code=SafetyReasonCode.TRACKING_INVALID,
                timestamp=snap_ts, confidence=1.0, uncertainty=0.0, valid=False,
            ))
            return health, obs, events

        if tq_val in ("REFERENCE_LOST",):
            health = SubsystemHealth(
                subsystem=subsystem, state=SubsystemHealthState.INVALID,
                reason="Tracking reference lost",
                reason_code=SafetyReasonCode.TRACKING_REFERENCE_LOST,
                timestamp=snap_ts, valid=False,
            )
            obs.append(_make_observation(
                source=source, subsystem=subsystem,
                condition="Tracking reference trajectory lost",
                severity=SafetyConditionSeverity.HIGH_ALERT,
                reason_code=SafetyReasonCode.TRACKING_REFERENCE_LOST,
                timestamp=snap_ts, confidence=1.0, uncertainty=0.0, valid=False,
            ))
            events.append(_make_event(
                source=source, subsystem=subsystem,
                severity=SafetyConditionSeverity.HIGH_ALERT,
                reason_code=SafetyReasonCode.TRACKING_REFERENCE_LOST,
                timestamp=snap_ts,
            ))
            return health, obs, events

        if tq_val in ("STALE_REFERENCE",) or stale:
            health = SubsystemHealth(
                subsystem=subsystem, state=SubsystemHealthState.STALE,
                reason=f"Tracking stale (quality={tq_val})",
                reason_code=SafetyReasonCode.TRACKING_STALE_REFERENCE,
                timestamp=snap_ts, stale=True, valid=True,
            )
            obs.append(_make_observation(
                source=source, subsystem=subsystem,
                condition="Tracking reference trajectory is stale",
                severity=SafetyConditionSeverity.RESTRICTED,
                reason_code=SafetyReasonCode.TRACKING_STALE_REFERENCE,
                timestamp=snap_ts, confidence=0.7, uncertainty=0.3,
                stale=True, valid=True,
            ))
            return health, obs, events

        # Large deviation check
        cte = getattr(ts_snap, "cross_track_error_m", None)
        if cte is not None and _is_finite(cte):
            abs_cte = abs(float(cte))
            if abs_cte >= cfg.critical_cross_track_error_m:
                obs.append(_make_observation(
                    source=source, subsystem=subsystem,
                    condition=f"Critical cross-track error: {abs_cte:.2f}m",
                    severity=SafetyConditionSeverity.CRITICAL,
                    reason_code=SafetyReasonCode.TRACKING_LARGE_DEVIATION,
                    timestamp=snap_ts, confidence=1.0, uncertainty=0.0,
                    valid=True, affected_component="trajectory_tracking",
                ))
                events.append(_make_event(
                    source=source, subsystem=subsystem,
                    severity=SafetyConditionSeverity.CRITICAL,
                    reason_code=SafetyReasonCode.TRACKING_LARGE_DEVIATION,
                    timestamp=snap_ts, metadata={"cross_track_error_m": abs_cte},
                ))
                health = SubsystemHealth(
                    subsystem=subsystem, state=SubsystemHealthState.DEGRADED,
                    reason=f"Critical CTE: {abs_cte:.2f}m",
                    reason_code=SafetyReasonCode.TRACKING_LARGE_DEVIATION,
                    timestamp=snap_ts, degraded=True, valid=True,
                )
                return health, obs, events
            elif abs_cte >= cfg.large_cross_track_error_m or tq_val in ("LARGE_DEVIATION",):
                obs.append(_make_observation(
                    source=source, subsystem=subsystem,
                    condition=f"Large cross-track error: {abs_cte:.2f}m",
                    severity=SafetyConditionSeverity.HIGH_ALERT,
                    reason_code=SafetyReasonCode.TRACKING_LARGE_DEVIATION,
                    timestamp=snap_ts, confidence=1.0, uncertainty=0.0,
                    valid=True, affected_component="trajectory_tracking",
                ))
                events.append(_make_event(
                    source=source, subsystem=subsystem,
                    severity=SafetyConditionSeverity.HIGH_ALERT,
                    reason_code=SafetyReasonCode.TRACKING_LARGE_DEVIATION,
                    timestamp=snap_ts, metadata={"cross_track_error_m": abs_cte},
                ))
                health = SubsystemHealth(
                    subsystem=subsystem, state=SubsystemHealthState.DEGRADED,
                    reason=f"Large CTE: {abs_cte:.2f}m",
                    reason_code=SafetyReasonCode.TRACKING_LARGE_DEVIATION,
                    timestamp=snap_ts, degraded=True, valid=True,
                )
                return health, obs, events

        # Also check for LARGE_DEVIATION quality without finite CTE
        if tq_val in ("LARGE_DEVIATION",):
            obs.append(_make_observation(
                source=source, subsystem=subsystem,
                condition="Tracking quality: LARGE_DEVIATION",
                severity=SafetyConditionSeverity.HIGH_ALERT,
                reason_code=SafetyReasonCode.TRACKING_LARGE_DEVIATION,
                timestamp=snap_ts, confidence=1.0, uncertainty=0.0,
                valid=True,
            ))

        if is_degraded or tq_val in ("DEGRADED",):
            health = SubsystemHealth(
                subsystem=subsystem, state=SubsystemHealthState.DEGRADED,
                reason=f"Tracking degraded (quality={tq_val})",
                reason_code=SafetyReasonCode.TRACKING_DEGRADED,
                timestamp=snap_ts, degraded=True, valid=True,
            )
            obs.append(_make_observation(
                source=source, subsystem=subsystem,
                condition="Tracking is degraded",
                severity=SafetyConditionSeverity.DEGRADED,
                reason_code=SafetyReasonCode.TRACKING_DEGRADED,
                timestamp=snap_ts, confidence=0.6, uncertainty=0.4,
                degraded=True, valid=True,
            ))
            return health, obs, events

        health = SubsystemHealth(
            subsystem=subsystem, state=SubsystemHealthState.HEALTHY,
            reason="Tracking OK", timestamp=snap_ts, valid=True,
        )
        return health, obs, events

    # ------------------------------------------------------------------
    # MPC checks
    # ------------------------------------------------------------------

    def _check_mpc(
        self, mpc, ref_ts: float, cfg: SafetyMonitorConfig
    ) -> Tuple[SubsystemHealth, List[SafetyObservation], List[SafetyEvent]]:
        source = SafetyObservationSource.MPC
        subsystem = "mpc"
        obs: List[SafetyObservation] = []
        events: List[SafetyEvent] = []

        if mpc is None:
            health = SubsystemHealth(
                subsystem=subsystem, state=SubsystemHealthState.UNAVAILABLE,
                reason="MPC snapshot is None",
                reason_code=SafetyReasonCode.MPC_UNAVAILABLE,
                timestamp=0.0, valid=False,
            )
            obs.append(_make_observation(
                source=source, subsystem=subsystem,
                condition="MPC snapshot unavailable",
                severity=SafetyConditionSeverity.HIGH_ALERT,
                reason_code=SafetyReasonCode.MPC_UNAVAILABLE,
                timestamp=ref_ts, confidence=1.0, uncertainty=0.0, valid=False,
            ))
            return health, obs, events

        snap_ts = float(getattr(mpc, "snap_timestamp", 0.0))
        if not _is_valid_timestamp(snap_ts):
            snap_ts = 0.0

        stale = _is_stale(snap_ts, ref_ts, cfg.mpc_max_age_s)

        mpc_status = getattr(mpc, "status", None)
        ms_val = str(mpc_status.value if hasattr(mpc_status, "value") else mpc_status or "UNKNOWN")

        feasible = bool(getattr(mpc, "feasible", False))

        if ms_val in ("INVALID_INPUT", "INVALID_REFERENCE"):
            health = SubsystemHealth(
                subsystem=subsystem, state=SubsystemHealthState.INVALID,
                reason=f"MPC invalid input (status={ms_val})",
                reason_code=SafetyReasonCode.MPC_INVALID,
                timestamp=snap_ts, valid=False,
            )
            obs.append(_make_observation(
                source=source, subsystem=subsystem,
                condition=f"MPC has invalid input (status={ms_val})",
                severity=SafetyConditionSeverity.HIGH_ALERT,
                reason_code=SafetyReasonCode.MPC_INVALID,
                timestamp=snap_ts, confidence=1.0, uncertainty=0.0, valid=False,
            ))
            return health, obs, events

        if ms_val in ("STALE_REFERENCE",) or stale:
            health = SubsystemHealth(
                subsystem=subsystem, state=SubsystemHealthState.STALE,
                reason=f"MPC stale (status={ms_val})",
                reason_code=SafetyReasonCode.MPC_STALE,
                timestamp=snap_ts, stale=True, valid=True,
            )
            obs.append(_make_observation(
                source=source, subsystem=subsystem,
                condition="MPC result is stale",
                severity=SafetyConditionSeverity.RESTRICTED,
                reason_code=SafetyReasonCode.MPC_STALE,
                timestamp=snap_ts, confidence=0.7, uncertainty=0.3,
                stale=True, valid=True,
            ))
            return health, obs, events

        if ms_val in ("NO_FEASIBLE_SOLUTION",) or not feasible:
            health = SubsystemHealth(
                subsystem=subsystem, state=SubsystemHealthState.DEGRADED,
                reason=f"MPC no feasible solution (status={ms_val})",
                reason_code=SafetyReasonCode.MPC_NO_FEASIBLE_SOLUTION,
                timestamp=snap_ts, degraded=True, valid=False,
            )
            obs.append(_make_observation(
                source=source, subsystem=subsystem,
                condition=f"MPC has no feasible solution (status={ms_val})",
                severity=SafetyConditionSeverity.HIGH_ALERT,
                reason_code=SafetyReasonCode.MPC_NO_FEASIBLE_SOLUTION,
                timestamp=snap_ts, confidence=1.0, uncertainty=0.0,
                degraded=True, valid=False,
            ))
            return health, obs, events

        constraint_status = getattr(mpc, "constraint_status", None)
        cs_val = str(constraint_status.value if hasattr(constraint_status, "value") else constraint_status or "")
        if cs_val == "VIOLATED":
            obs.append(_make_observation(
                source=source, subsystem=subsystem,
                condition="MPC constraint violated",
                severity=SafetyConditionSeverity.CRITICAL,
                reason_code=SafetyReasonCode.MPC_CONSTRAINT_VIOLATION,
                timestamp=snap_ts, confidence=1.0, uncertainty=0.0, valid=True,
            ))
            events.append(_make_event(
                source=source, subsystem=subsystem,
                severity=SafetyConditionSeverity.CRITICAL,
                reason_code=SafetyReasonCode.MPC_CONSTRAINT_VIOLATION,
                timestamp=snap_ts,
            ))

        if ms_val in ("DEGRADED", "SOLVER_LIMIT_REACHED"):
            health = SubsystemHealth(
                subsystem=subsystem, state=SubsystemHealthState.DEGRADED,
                reason=f"MPC degraded (status={ms_val})",
                reason_code=SafetyReasonCode.MPC_DEGRADED,
                timestamp=snap_ts, degraded=True, valid=True,
            )
            obs.append(_make_observation(
                source=source, subsystem=subsystem,
                condition=f"MPC is degraded (status={ms_val})",
                severity=SafetyConditionSeverity.DEGRADED,
                reason_code=SafetyReasonCode.MPC_DEGRADED,
                timestamp=snap_ts, confidence=0.6, uncertainty=0.4,
                degraded=True, valid=True,
            ))
            return health, obs, events

        health = SubsystemHealth(
            subsystem=subsystem, state=SubsystemHealthState.HEALTHY,
            reason="MPC OK", timestamp=snap_ts, valid=True,
        )
        return health, obs, events

    # ------------------------------------------------------------------
    # Control checks
    # ------------------------------------------------------------------

    def _check_control(
        self, cmd, ref_ts: float, cfg: SafetyMonitorConfig
    ) -> Tuple[SubsystemHealth, List[SafetyObservation], List[SafetyEvent]]:
        source = SafetyObservationSource.CONTROL
        subsystem = "control"
        obs: List[SafetyObservation] = []
        events: List[SafetyEvent] = []

        if cmd is None:
            health = SubsystemHealth(
                subsystem=subsystem, state=SubsystemHealthState.UNAVAILABLE,
                reason="Control command is None",
                reason_code=SafetyReasonCode.CONTROL_UNAVAILABLE,
                timestamp=0.0, valid=False,
            )
            obs.append(_make_observation(
                source=source, subsystem=subsystem,
                condition="Control command unavailable",
                severity=SafetyConditionSeverity.HIGH_ALERT,
                reason_code=SafetyReasonCode.CONTROL_UNAVAILABLE,
                timestamp=ref_ts, confidence=1.0, uncertainty=0.0, valid=False,
            ))
            return health, obs, events

        cmd_ts = float(getattr(cmd, "timestamp", 0.0))
        if not _is_valid_timestamp(cmd_ts):
            cmd_ts = 0.0

        stale = _is_stale(cmd_ts, ref_ts, cfg.control_max_age_s)

        cmd_status = getattr(cmd, "status", None)
        cs_val = str(cmd_status.value if hasattr(cmd_status, "value") else cmd_status or "UNKNOWN")

        if cs_val in ("INVALID",):
            health = SubsystemHealth(
                subsystem=subsystem, state=SubsystemHealthState.INVALID,
                reason=f"Control command invalid (status={cs_val})",
                reason_code=SafetyReasonCode.CONTROL_INVALID,
                timestamp=cmd_ts, valid=False,
            )
            obs.append(_make_observation(
                source=source, subsystem=subsystem,
                condition=f"Control command is invalid (status={cs_val})",
                severity=SafetyConditionSeverity.HIGH_ALERT,
                reason_code=SafetyReasonCode.CONTROL_INVALID,
                timestamp=cmd_ts, confidence=1.0, uncertainty=0.0, valid=False,
            ))
            return health, obs, events

        if cs_val in ("STALE",) or stale:
            health = SubsystemHealth(
                subsystem=subsystem, state=SubsystemHealthState.STALE,
                reason=f"Control command stale (status={cs_val})",
                reason_code=SafetyReasonCode.CONTROL_STALE,
                timestamp=cmd_ts, stale=True, valid=True,
            )
            obs.append(_make_observation(
                source=source, subsystem=subsystem,
                condition="Control command is stale",
                severity=SafetyConditionSeverity.RESTRICTED,
                reason_code=SafetyReasonCode.CONTROL_STALE,
                timestamp=cmd_ts, confidence=0.7, uncertainty=0.3,
                stale=True, valid=True,
            ))
            return health, obs, events

        if cs_val in ("NO_SOLUTION",):
            health = SubsystemHealth(
                subsystem=subsystem, state=SubsystemHealthState.DEGRADED,
                reason="Control has no solution",
                reason_code=SafetyReasonCode.CONTROL_NO_SOLUTION,
                timestamp=cmd_ts, degraded=True, valid=False,
            )
            obs.append(_make_observation(
                source=source, subsystem=subsystem,
                condition="Control command has no MPC solution",
                severity=SafetyConditionSeverity.HIGH_ALERT,
                reason_code=SafetyReasonCode.CONTROL_NO_SOLUTION,
                timestamp=cmd_ts, confidence=1.0, uncertainty=0.0,
                degraded=True, valid=False,
            ))
            return health, obs, events

        health = SubsystemHealth(
            subsystem=subsystem, state=SubsystemHealthState.HEALTHY,
            reason="Control OK", timestamp=cmd_ts, valid=True,
        )
        return health, obs, events

    # ------------------------------------------------------------------
    # Vehicle dynamics checks
    # ------------------------------------------------------------------

    def _check_vehicle(
        self, dyn, ref_ts: float, cfg: SafetyMonitorConfig
    ) -> Tuple[SubsystemHealth, List[SafetyObservation], List[SafetyEvent]]:
        source = SafetyObservationSource.VEHICLE
        subsystem = "vehicle"
        obs: List[SafetyObservation] = []
        events: List[SafetyEvent] = []

        if dyn is None:
            health = SubsystemHealth(
                subsystem=subsystem, state=SubsystemHealthState.UNAVAILABLE,
                reason="Vehicle dynamics snapshot is None",
                reason_code=SafetyReasonCode.VEHICLE_DYNAMICS_UNAVAILABLE,
                timestamp=0.0, valid=False,
            )
            obs.append(_make_observation(
                source=source, subsystem=subsystem,
                condition="Vehicle dynamics snapshot unavailable",
                severity=SafetyConditionSeverity.HIGH_ALERT,
                reason_code=SafetyReasonCode.VEHICLE_DYNAMICS_UNAVAILABLE,
                timestamp=ref_ts, confidence=1.0, uncertainty=0.0, valid=False,
            ))
            return health, obs, events

        snap_ts = float(getattr(dyn, "snapshot_timestamp", 0.0))
        if not _is_valid_timestamp(snap_ts):
            snap_ts = 0.0

        # Check for NaN/Inf in key vehicle state fields
        invalid_fields: List[str] = []
        for field_name in ("x", "y", "yaw", "speed", "acceleration"):
            val = getattr(dyn, field_name, None)
            # dynamics_snapshot doesn't directly expose these — check via state
            if val is not None and not _is_finite(val):
                invalid_fields.append(field_name)

        # Try reading from nested state if available
        state = getattr(dyn, "state", None)
        if state is not None:
            for field_name in ("x", "y", "yaw", "speed"):
                val = getattr(state, field_name, None)
                if val is not None and not _is_finite(val):
                    if field_name not in invalid_fields:
                        invalid_fields.append(field_name)

        if invalid_fields:
            health = SubsystemHealth(
                subsystem=subsystem, state=SubsystemHealthState.INVALID,
                reason=f"Vehicle state has non-finite values: {invalid_fields}",
                reason_code=SafetyReasonCode.VEHICLE_DYNAMICS_INVALID,
                timestamp=snap_ts, valid=False,
            )
            obs.append(_make_observation(
                source=source, subsystem=subsystem,
                condition=f"Vehicle state has NaN/Inf in fields: {invalid_fields}",
                severity=SafetyConditionSeverity.CRITICAL,
                reason_code=SafetyReasonCode.VEHICLE_DYNAMICS_INVALID,
                timestamp=snap_ts, confidence=1.0, uncertainty=0.0, valid=False,
            ))
            events.append(_make_event(
                source=source, subsystem=subsystem,
                severity=SafetyConditionSeverity.CRITICAL,
                reason_code=SafetyReasonCode.VEHICLE_DYNAMICS_INVALID,
                timestamp=snap_ts, metadata={"invalid_fields": invalid_fields},
            ))
            return health, obs, events

        stale = _is_stale(snap_ts, ref_ts, cfg.vehicle_max_age_s)
        if stale:
            health = SubsystemHealth(
                subsystem=subsystem, state=SubsystemHealthState.STALE,
                reason=f"Vehicle state stale (ts={snap_ts:.3f})",
                timestamp=snap_ts, stale=True, valid=True,
            )
            obs.append(_make_observation(
                source=source, subsystem=subsystem,
                condition="Vehicle dynamics state is stale",
                severity=SafetyConditionSeverity.CAUTION,
                reason_code=SafetyReasonCode.VEHICLE_DYNAMICS_INVALID,
                timestamp=snap_ts, confidence=0.7, uncertainty=0.3,
                stale=True, valid=True,
            ))
            return health, obs, events

        health = SubsystemHealth(
            subsystem=subsystem, state=SubsystemHealthState.HEALTHY,
            reason="Vehicle dynamics OK", timestamp=snap_ts, valid=True,
        )
        return health, obs, events

    # ------------------------------------------------------------------
    # Pipeline checks
    # ------------------------------------------------------------------

    def _check_pipeline(
        self, pipe, ref_ts: float, cfg: SafetyMonitorConfig
    ) -> Tuple[SubsystemHealth, List[SafetyObservation], List[SafetyEvent]]:
        source = SafetyObservationSource.PIPELINE
        subsystem = "pipeline"
        obs: List[SafetyObservation] = []
        events: List[SafetyEvent] = []

        if pipe is None:
            health = SubsystemHealth(
                subsystem=subsystem, state=SubsystemHealthState.UNAVAILABLE,
                reason="Pipeline snapshot is None",
                timestamp=0.0, valid=False,
            )
            # Pipeline being None is not necessarily a safety concern —
            # it may not have run yet in this cycle.
            return health, obs, events

        pipe_ts = float(getattr(pipe, "timestamp", 0.0))
        if not _is_valid_timestamp(pipe_ts):
            pipe_ts = 0.0

        pipeline_status = getattr(pipe, "pipeline_status", None)
        ps_val = str(pipeline_status.value if hasattr(pipeline_status, "value") else pipeline_status or "UNKNOWN")

        is_degraded = bool(getattr(pipe, "degraded", False))
        reason_codes_raw = getattr(pipe, "reason_codes", ()) or ()
        pipe_reasons = tuple(str(r) for r in reason_codes_raw)

        if ps_val in ("INVALID_INPUT",):
            health = SubsystemHealth(
                subsystem=subsystem, state=SubsystemHealthState.INVALID,
                reason=f"Pipeline invalid input (status={ps_val})",
                timestamp=pipe_ts, valid=False,
            )
            obs.append(_make_observation(
                source=source, subsystem=subsystem,
                condition=f"Pipeline has invalid input (status={ps_val})",
                severity=SafetyConditionSeverity.HIGH_ALERT,
                reason_code=SafetyReasonCode.PIPELINE_INVALID_INPUT,
                timestamp=pipe_ts, confidence=1.0, uncertainty=0.0, valid=False,
            ))
            return health, obs, events

        if ps_val in ("STALE_INPUT",):
            health = SubsystemHealth(
                subsystem=subsystem, state=SubsystemHealthState.STALE,
                reason=f"Pipeline stale input (status={ps_val})",
                timestamp=pipe_ts, stale=True, valid=True,
            )
            obs.append(_make_observation(
                source=source, subsystem=subsystem,
                condition=f"Pipeline has stale input (status={ps_val})",
                severity=SafetyConditionSeverity.RESTRICTED,
                reason_code=SafetyReasonCode.PIPELINE_STALE_INPUT,
                timestamp=pipe_ts, confidence=0.7, uncertainty=0.3,
                stale=True, valid=True,
            ))
            return health, obs, events

        failed_statuses = {
            "PLANNING_FAILED", "TRACKING_FAILED", "MPC_FAILED",
            "CONTROL_FAILED", "DYNAMICS_FAILED",
        }
        if ps_val in failed_statuses:
            health = SubsystemHealth(
                subsystem=subsystem, state=SubsystemHealthState.DEGRADED,
                reason=f"Pipeline stage failed (status={ps_val})",
                timestamp=pipe_ts, degraded=True, valid=False,
            )
            obs.append(_make_observation(
                source=source, subsystem=subsystem,
                condition=f"Pipeline stage failed (status={ps_val})",
                severity=SafetyConditionSeverity.HIGH_ALERT,
                reason_code=SafetyReasonCode.PIPELINE_FAILED,
                timestamp=pipe_ts, confidence=1.0, uncertainty=0.0,
                degraded=True, valid=False,
            ))
            return health, obs, events

        if is_degraded or ps_val in ("DEGRADED",):
            health = SubsystemHealth(
                subsystem=subsystem, state=SubsystemHealthState.DEGRADED,
                reason=f"Pipeline degraded (status={ps_val})",
                timestamp=pipe_ts, degraded=True, valid=True,
            )
            obs.append(_make_observation(
                source=source, subsystem=subsystem,
                condition="Pipeline is degraded",
                severity=SafetyConditionSeverity.DEGRADED,
                reason_code=SafetyReasonCode.PIPELINE_DEGRADED,
                timestamp=pipe_ts, confidence=0.6, uncertainty=0.4,
                degraded=True, valid=True,
            ))
            return health, obs, events

        health = SubsystemHealth(
            subsystem=subsystem, state=SubsystemHealthState.HEALTHY,
            reason="Pipeline OK", timestamp=pipe_ts, valid=True,
        )
        return health, obs, events

    # ------------------------------------------------------------------
    # Aggregation helpers
    # ------------------------------------------------------------------

    def _aggregate(
        self,
        observations: List[SafetyObservation],
        health_map: Dict[str, SubsystemHealth],
        cfg: SafetyMonitorConfig,
    ) -> SafetyState:
        """Aggregate observations and subsystem health into overall SafetyState."""
        if not observations:
            # No observations: check if all required subsystems are healthy
            required_healthy = all(
                health_map.get(s, SubsystemHealth(
                    subsystem=s, state=SubsystemHealthState.UNAVAILABLE
                )).state == SubsystemHealthState.HEALTHY
                for s in cfg.required_subsystems
            )
            if required_healthy:
                return SafetyState.SAFE
            # Some required subsystems unavailable but no conditions detected
            return SafetyState.UNKNOWN

        # Collect states from observations
        states: List[SafetyState] = [
            _severity_to_state(obs.severity) for obs in observations
        ]
        return _aggregate_states(states)

    def _collect_reason_codes(
        self, observations: List[SafetyObservation]
    ) -> List[str]:
        """Collect unique reason codes, ordered by severity (most severe first)."""
        severity_order = {
            SafetyConditionSeverity.CRITICAL:   0,
            SafetyConditionSeverity.HIGH_ALERT: 1,
            SafetyConditionSeverity.RESTRICTED: 2,
            SafetyConditionSeverity.CAUTION:    3,
            SafetyConditionSeverity.DEGRADED:   4,
            SafetyConditionSeverity.INFO:       5,
        }
        seen: set = set()
        codes: List[tuple] = []
        for obs in sorted(observations, key=lambda o: severity_order.get(o.severity, 9)):
            code = obs.reason_code.value
            if code not in seen:
                seen.add(code)
                codes.append((severity_order.get(obs.severity, 9), code))

        return [c for _, c in sorted(codes)]

    def _aggregate_confidence(
        self,
        observations: List[SafetyObservation],
        health_map: Dict[str, SubsystemHealth],
    ) -> float:
        """
        Aggregate confidence across subsystem health and observations.
        Conservative: lower confidence if any subsystem is unhealthy.
        """
        if not health_map:
            return 0.0

        healthy_count = sum(
            1 for h in health_map.values()
            if h.state == SubsystemHealthState.HEALTHY
        )
        total = len(health_map)

        if total == 0:
            return 0.0

        base_confidence = healthy_count / total

        # Reduce further if there are high-severity observations
        critical_obs = [
            o for o in observations
            if o.severity in (SafetyConditionSeverity.CRITICAL, SafetyConditionSeverity.HIGH_ALERT)
        ]
        if critical_obs:
            base_confidence *= 0.5

        return min(1.0, max(0.0, base_confidence))
