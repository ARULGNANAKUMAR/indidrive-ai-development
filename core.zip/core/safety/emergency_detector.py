"""
IndiDrive AI — Phase 11.2 | Emergency Detector Engine
=======================================================
Deterministic emergency detection layer.

This module DETECTS and CLASSIFIES emergency conditions.
It does NOT:
  - generate steering, brake, throttle, or any control commands
  - perform emergency braking or steering
  - override controllers
  - send CAN commands
  - control hardware
  - generate alternative paths or select paths
  - run MPC
  - create a new perception or prediction system

Architecture:
    Sits directly below Phase 11.1 Safety Monitor.
    Consumes SafetyMonitorState + World Model + Planning + Tracking +
    MPC + Control + Vehicle snapshots.
    Produces an immutable EmergencyDetectionState.

Design rules:
  * Fully deterministic — same input → same output.
  * No wall-clock time inside pure evaluation logic.
  * No random values, no random IDs.
  * Conservative under uncertainty — unknown → EMERGENCY_UNKNOWN, not NO_EMERGENCY.
  * NaN/Inf handled gracefully — returns structured degraded/unknown state.
  * Zero modification of any Phase 0–11.1 module.
  * Hysteresis is stateless from the caller's perspective — pass prior state
    to enable it, or pass None for stateless operation.
"""
from __future__ import annotations

import math
from typing import Dict, List, Optional, Set, Tuple

from .emergency_config import EmergencyDetectorConfig
from .emergency_types import (
    EMERGENCY_SCHEMA_VERSION,
    EMERGENCY_STATE_PRIORITY,
    EmergencyDetectionState,
    EmergencyEvent,
    EmergencyEvidence,
    EmergencySource,
    EmergencyState,
    EmergencySeverity,
    EmergencyType,
    EmergencyUrgency,
)
from .safety_types import SafetyState

__all__ = ["EmergencyDetector"]

# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

_NOT_AVAILABLE = "NOT_AVAILABLE"


def _finite(val: object) -> bool:
    """Return True iff val is a finite float/int."""
    try:
        return math.isfinite(float(val))  # type: ignore[arg-type]
    except (TypeError, ValueError):
        return False


def _valid_ts(ts: object) -> bool:
    """Return True iff ts is a finite non-negative float."""
    try:
        f = float(ts)  # type: ignore[arg-type]
        return math.isfinite(f) and f >= 0.0
    except (TypeError, ValueError):
        return False


def _is_stale(data_ts: float, ref_ts: float, threshold_s: float) -> bool:
    """Return True if data_ts is older than threshold_s relative to ref_ts."""
    if not _valid_ts(data_ts) or not _valid_ts(ref_ts):
        return True
    return (ref_ts - data_ts) > threshold_s


def _clamp01(v: float) -> float:
    return min(1.0, max(0.0, v))


def _aggregate_emergency_states(states: List[EmergencyState]) -> EmergencyState:
    """Return the highest-priority EmergencyState from a list."""
    if not states:
        return EmergencyState.EMERGENCY_UNKNOWN
    has_unknown = EmergencyState.EMERGENCY_UNKNOWN in states
    non_unknown = [s for s in states if s != EmergencyState.EMERGENCY_UNKNOWN]
    if not non_unknown:
        return EmergencyState.EMERGENCY_UNKNOWN
    for priority_state in EMERGENCY_STATE_PRIORITY:
        if priority_state in non_unknown:
            return priority_state
    return EmergencyState.EMERGENCY_UNKNOWN if has_unknown else EmergencyState.NO_EMERGENCY


def _make_event_id(source: EmergencySource, etype: EmergencyType, ts: float) -> str:
    return f"{source.value}:{etype.value}:{ts:.6f}"


def _make_event(
    *,
    source: EmergencySource,
    etype: EmergencyType,
    state: EmergencyState,
    severity: EmergencySeverity,
    urgency: EmergencyUrgency,
    timestamp: float,
    reason_codes: Tuple[str, ...] = (),
    evidence: EmergencyEvidence = None,
    affected_objects: Tuple[str, ...] = (),
    affected_subsystems: Tuple[str, ...] = (),
    confidence: float = 1.0,
    uncertainty: float = 0.0,
    stale: bool = False,
    degraded: bool = False,
) -> EmergencyEvent:
    if evidence is None:
        evidence = EmergencyEvidence()
    return EmergencyEvent(
        event_id=_make_event_id(source, etype, timestamp),
        timestamp=timestamp,
        emergency_type=etype,
        state=state,
        severity=severity,
        urgency=urgency,
        source=source,
        reason_codes=reason_codes,
        evidence=evidence,
        affected_objects=affected_objects,
        affected_subsystems=affected_subsystems,
        confidence=_clamp01(confidence),
        uncertainty=_clamp01(uncertainty),
        stale=stale,
        degraded=degraded,
        schema_version=EMERGENCY_SCHEMA_VERSION,
    )


# ---------------------------------------------------------------------------
# Emergency Detector
# ---------------------------------------------------------------------------

class EmergencyDetector:
    """
    Deterministic emergency detection engine for Phase 11.2.

    Usage (stateless)
    -----------------
    ::
        detector = EmergencyDetector(EmergencyDetectorConfig.default())
        state = detector.detect(
            safety_monitor_state=sm_state,
            world_model_snapshot=wm,
            planner_output=po,
            tracking_snapshot=ts,
            mpc_snapshot=mpc,
            control_command=cmd,
            dynamics_snapshot=dyn,
        )

    Usage (with hysteresis)
    -----------------------
    ::
        state = detector.detect(..., prior_state=prev_state)

    All arguments except safety_monitor_state are optional (None = unavailable).
    Same input always produces same EmergencyDetectionState.
    Result NEVER controls the vehicle.
    """

    def __init__(self, config: Optional[EmergencyDetectorConfig] = None) -> None:
        self._cfg = config if config is not None else EmergencyDetectorConfig.default()

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def detect(
        self,
        *,
        safety_monitor_state=None,
        world_model_snapshot=None,
        planner_output=None,
        tracking_snapshot=None,
        mpc_snapshot=None,
        control_command=None,
        dynamics_snapshot=None,
        reference_timestamp: Optional[float] = None,
        prior_state: Optional[EmergencyDetectionState] = None,
    ) -> EmergencyDetectionState:
        """
        Detect and classify emergency conditions from current system state.

        Parameters
        ----------
        safety_monitor_state  : SafetyMonitorState from Phase 11.1 (recommended).
        world_model_snapshot  : WorldModelSnapshot or None.
        planner_output        : PlannerOutput or None.
        tracking_snapshot     : TrackingSnapshot or None.
        mpc_snapshot          : MPCSnapshot or None.
        control_command       : VehicleControlCommand or None.
        dynamics_snapshot     : DynamicsSnapshot or None.
        reference_timestamp   : Reference timestamp; derived from inputs if None.
        prior_state           : Previous EmergencyDetectionState for hysteresis.

        Returns
        -------
        EmergencyDetectionState — immutable, deterministic snapshot.
        """
        try:
            return self._detect_safe(
                safety_monitor_state=safety_monitor_state,
                world_model_snapshot=world_model_snapshot,
                planner_output=planner_output,
                tracking_snapshot=tracking_snapshot,
                mpc_snapshot=mpc_snapshot,
                control_command=control_command,
                dynamics_snapshot=dynamics_snapshot,
                reference_timestamp=reference_timestamp,
                prior_state=prior_state,
            )
        except Exception as exc:  # pragma: no cover — defensive wrapper
            ts = reference_timestamp if _valid_ts(reference_timestamp) else 0.0
            ev = _make_event(
                source=EmergencySource.SYSTEM,
                etype=EmergencyType.SYSTEM_CRITICAL_FAILURE,
                state=EmergencyState.EMERGENCY_UNKNOWN,
                severity=EmergencySeverity.UNKNOWN,
                urgency=EmergencyUrgency.UNKNOWN,
                timestamp=ts,
                reason_codes=(f"DETECTOR_INTERNAL_ERROR:{exc}",),
                confidence=0.0,
                uncertainty=1.0,
            )
            return EmergencyDetectionState(
                timestamp=ts,
                schema_version=EMERGENCY_SCHEMA_VERSION,
                detector_status="ERROR",
                emergency_state=EmergencyState.EMERGENCY_UNKNOWN,
                dominant_emergency_type=EmergencyType.SYSTEM_CRITICAL_FAILURE,
                dominant_severity=EmergencySeverity.UNKNOWN,
                dominant_urgency=EmergencyUrgency.UNKNOWN,
                active_events=(ev,),
                confidence=0.0,
                uncertainty=1.0,
                stale=True,
                degraded=True,
                valid=False,
            )

    # ------------------------------------------------------------------
    # Core detection
    # ------------------------------------------------------------------

    def _detect_safe(
        self,
        *,
        safety_monitor_state,
        world_model_snapshot,
        planner_output,
        tracking_snapshot,
        mpc_snapshot,
        control_command,
        dynamics_snapshot,
        reference_timestamp,
        prior_state,
    ) -> EmergencyDetectionState:
        cfg = self._cfg

        # Derive reference timestamp
        ref_ts = self._derive_ref_ts(
            reference_timestamp,
            safety_monitor_state,
            world_model_snapshot,
            planner_output,
            tracking_snapshot,
            mpc_snapshot,
            control_command,
            dynamics_snapshot,
        )

        # Safety state from Phase 11.1 (string for evidence, enum for logic)
        sm_safety_state_str, sm_safety_state_enum, sm_reason_codes = \
            self._extract_safety_monitor_state(safety_monitor_state)

        events: List[EmergencyEvent] = []

        # --- Detection rules ---

        # 1. Safety Monitor state propagation
        sm_events = self._check_safety_monitor(
            safety_monitor_state, sm_safety_state_enum, sm_reason_codes, ref_ts
        )
        events.extend(sm_events)

        # 2. World model collision / TTC / object risks
        wm_events = self._check_world_model_risks(
            world_model_snapshot, ref_ts, cfg, sm_safety_state_str, sm_reason_codes
        )
        events.extend(wm_events)

        # 3. Planning emergencies (path risk, planner failure, path blocked)
        pl_events = self._check_planning(
            planner_output, ref_ts, cfg, sm_safety_state_str, sm_reason_codes
        )
        events.extend(pl_events)

        # 4. Tracking emergency (reference lost)
        tr_events = self._check_tracking(
            tracking_snapshot, ref_ts, cfg, sm_safety_state_str
        )
        events.extend(tr_events)

        # 5. MPC emergency
        mpc_events = self._check_mpc(
            mpc_snapshot, ref_ts, cfg, sm_safety_state_str
        )
        events.extend(mpc_events)

        # 6. Control emergency
        ctrl_events = self._check_control(
            control_command, ref_ts, cfg, sm_safety_state_str
        )
        events.extend(ctrl_events)

        # 7. Vehicle state emergency
        veh_events = self._check_vehicle(
            dynamics_snapshot, ref_ts, sm_safety_state_str
        )
        events.extend(veh_events)

        # --- Aggregate ---
        raw_state = _aggregate_emergency_states([e.state for e in events]) \
            if events else EmergencyState.NO_EMERGENCY

        # Hysteresis / debounce
        final_state, hysteresis_counter, clear_counter = self._apply_hysteresis(
            raw_state=raw_state,
            prior_state=prior_state,
            cfg=cfg,
        )

        # Dominant event
        dominant_event = self._dominant_event(events)
        dominant_type = dominant_event.emergency_type if dominant_event \
            else EmergencyType.UNKNOWN_EMERGENCY
        dominant_sev = dominant_event.severity if dominant_event \
            else EmergencySeverity.UNKNOWN
        dominant_urg = dominant_event.urgency if dominant_event \
            else EmergencyUrgency.UNKNOWN

        # Collect reason codes, affected objects/subsystems
        reason_codes = self._collect_reason_codes(events)
        affected_objects = tuple(sorted({
            oid for e in events for oid in e.affected_objects if oid
        }))
        affected_subsystems = tuple(sorted({
            s for e in events for s in e.affected_subsystems if s
        }))

        # Staleness / degraded
        stale = any(e.stale for e in events)
        degraded = any(e.degraded for e in events)

        # Confidence
        confidence = self._aggregate_confidence(events, final_state)
        uncertainty = 1.0 - confidence

        # Valid: at least we have some data
        valid = (
            safety_monitor_state is not None or
            world_model_snapshot is not None or
            planner_output is not None
        ) and final_state != EmergencyState.EMERGENCY_UNKNOWN

        detector_status = "OK" if valid else "DEGRADED"

        return EmergencyDetectionState(
            timestamp=ref_ts,
            schema_version=EMERGENCY_SCHEMA_VERSION,
            detector_status=detector_status,
            emergency_state=final_state,
            dominant_emergency_type=dominant_type,
            dominant_severity=dominant_sev,
            dominant_urgency=dominant_urg,
            reason_codes=tuple(reason_codes),
            active_events=tuple(events),
            affected_objects=affected_objects,
            affected_subsystems=affected_subsystems,
            safety_state=sm_safety_state_str,
            confidence=confidence,
            uncertainty=uncertainty,
            stale=stale,
            degraded=degraded,
            valid=valid,
            hysteresis_counter=hysteresis_counter,
            clear_counter=clear_counter,
        )

    # ------------------------------------------------------------------
    # Reference timestamp
    # ------------------------------------------------------------------

    def _derive_ref_ts(self, ref_ts, sm_state, wm, po, ts_snap, mpc, cmd, dyn) -> float:
        if _valid_ts(ref_ts):
            return float(ref_ts)
        candidates: List[float] = []
        for attr, obj in [
            ("timestamp", sm_state),
            ("timestamp", wm),
            ("timestamp", po),
            ("snap_timestamp", ts_snap),
            ("snap_timestamp", mpc),
            ("timestamp", cmd),
            ("snapshot_timestamp", dyn),
        ]:
            val = getattr(obj, attr, None) if obj is not None else None
            if _valid_ts(val):
                candidates.append(float(val))
        return max(candidates) if candidates else 0.0

    # ------------------------------------------------------------------
    # Safety Monitor state extraction
    # ------------------------------------------------------------------

    def _extract_safety_monitor_state(self, sm) -> Tuple[str, object, Tuple[str, ...]]:
        """Return (state_str, state_enum_or_None, reason_codes_tuple)."""
        if sm is None:
            return _NOT_AVAILABLE, None, ()
        state = getattr(sm, "overall_safety_state", None)
        state_str = state.value if hasattr(state, "value") else str(state or _NOT_AVAILABLE)
        reason_codes = tuple(getattr(sm, "reason_codes", ()) or ())
        return state_str, state, reason_codes

    # ------------------------------------------------------------------
    # Detection rules
    # ------------------------------------------------------------------

    def _check_safety_monitor(
        self, sm, sm_state_enum, sm_reason_codes: Tuple[str, ...], ref_ts: float
    ) -> List[EmergencyEvent]:
        """Propagate Phase 11.1 safety monitor state into emergency events."""
        events: List[EmergencyEvent] = []
        if sm is None:
            return events

        sm_ts = float(getattr(sm, "timestamp", ref_ts) or ref_ts)
        sm_confidence = float(getattr(sm, "confidence", 0.0) or 0.0)
        sm_stale = bool(getattr(sm, "stale", False))
        sm_degraded = bool(getattr(sm, "degraded", False))

        ev = EmergencyEvidence(
            safety_state=sm_state_enum.value if hasattr(sm_state_enum, "value")
                         else str(sm_state_enum or _NOT_AVAILABLE),
            safety_reason_codes=sm_reason_codes,
        )

        if sm_state_enum == SafetyState.CRITICAL:
            events.append(_make_event(
                source=EmergencySource.SAFETY_MONITOR,
                etype=EmergencyType.SAFETY_MONITOR_CRITICAL,
                state=EmergencyState.CRITICAL_EMERGENCY,
                severity=EmergencySeverity.CRITICAL,
                urgency=EmergencyUrgency.IMMEDIATE,
                timestamp=sm_ts,
                reason_codes=("SAFETY_MONITOR_CRITICAL",) + sm_reason_codes,
                evidence=ev,
                affected_subsystems=("safety_monitor",),
                confidence=_clamp01(sm_confidence),
                uncertainty=_clamp01(1.0 - sm_confidence),
                stale=sm_stale,
                degraded=sm_degraded,
            ))
        elif sm_state_enum == SafetyState.HIGH_ALERT:
            events.append(_make_event(
                source=EmergencySource.SAFETY_MONITOR,
                etype=EmergencyType.SAFETY_MONITOR_CRITICAL,
                state=EmergencyState.EMERGENCY_DETECTED,
                severity=EmergencySeverity.HIGH,
                urgency=EmergencyUrgency.HIGH,
                timestamp=sm_ts,
                reason_codes=("SAFETY_MONITOR_HIGH_ALERT",) + sm_reason_codes,
                evidence=ev,
                affected_subsystems=("safety_monitor",),
                confidence=_clamp01(sm_confidence),
                uncertainty=_clamp01(1.0 - sm_confidence),
                stale=sm_stale,
                degraded=sm_degraded,
            ))
        elif sm_state_enum in (SafetyState.RESTRICTED, SafetyState.DEGRADED):
            events.append(_make_event(
                source=EmergencySource.SAFETY_MONITOR,
                etype=EmergencyType.SAFETY_MONITOR_CRITICAL,
                state=EmergencyState.POTENTIAL_EMERGENCY,
                severity=EmergencySeverity.MEDIUM,
                urgency=EmergencyUrgency.MEDIUM,
                timestamp=sm_ts,
                reason_codes=("SAFETY_MONITOR_RESTRICTED",) + sm_reason_codes,
                evidence=ev,
                affected_subsystems=("safety_monitor",),
                confidence=_clamp01(sm_confidence),
                uncertainty=_clamp01(1.0 - sm_confidence),
                stale=sm_stale,
                degraded=sm_degraded,
            ))
        elif sm_state_enum == SafetyState.UNKNOWN:
            events.append(_make_event(
                source=EmergencySource.SAFETY_MONITOR,
                etype=EmergencyType.UNKNOWN_EMERGENCY,
                state=EmergencyState.EMERGENCY_UNKNOWN,
                severity=EmergencySeverity.UNKNOWN,
                urgency=EmergencyUrgency.UNKNOWN,
                timestamp=sm_ts,
                reason_codes=("SAFETY_MONITOR_UNKNOWN",) + sm_reason_codes,
                evidence=ev,
                confidence=0.0,
                uncertainty=1.0,
                stale=sm_stale,
                degraded=sm_degraded,
            ))

        return events

    # ------------------------------------------------------------------

    def _check_world_model_risks(
        self, wm, ref_ts: float, cfg: EmergencyDetectorConfig,
        sm_state_str: str, sm_reason_codes: Tuple[str, ...]
    ) -> List[EmergencyEvent]:
        """Check world model objects for collision/TTC/risk emergencies."""
        events: List[EmergencyEvent] = []
        if wm is None:
            return events

        wm_ts = float(getattr(wm, "timestamp", ref_ts) or ref_ts)
        stale = _is_stale(wm_ts, ref_ts, cfg.stale_threshold_s)
        objects = getattr(wm, "objects", ()) or ()

        for obj in objects:
            obj_events = self._evaluate_object(obj, wm_ts, stale, cfg, sm_state_str)
            events.extend(obj_events)

        return events

    def _evaluate_object(
        self, obj, timestamp: float, stale: bool,
        cfg: EmergencyDetectorConfig, sm_state_str: str
    ) -> List[EmergencyEvent]:
        """Evaluate one WorldObject for emergency conditions."""
        events: List[EmergencyEvent] = []

        collision = getattr(obj, "collision", None)
        if collision is None:
            return events

        obj_type = str(getattr(obj, "object_type", _NOT_AVAILABLE) or _NOT_AVAILABLE)
        obj_subtype = str(getattr(obj, "object_subtype", _NOT_AVAILABLE) or _NOT_AVAILABLE)
        obj_id = getattr(obj, "object_id", None) or getattr(obj, "track_id", None) \
                 or getattr(obj, "fused_id", None)
        obj_id_str = str(obj_id) if obj_id else _NOT_AVAILABLE
        affected_objects = (obj_id_str,) if obj_id_str != _NOT_AVAILABLE else ()

        # Quality / confidence
        quality = getattr(obj, "quality", None)
        obj_confidence = float(getattr(quality, "object_confidence", 0.5) or 0.5) \
            if quality else 0.5
        obj_degraded = bool(getattr(quality, "is_degraded", False)) if quality else False
        obj_stale = stale or (bool(getattr(quality, "is_stale", False)) if quality else False)

        # TTC
        ttc_s = getattr(collision, "ttc_s", None)
        ttc_status = str(getattr(collision, "ttc_status", _NOT_AVAILABLE) or _NOT_AVAILABLE)
        closing_speed = getattr(collision, "closing_speed_ms", None)
        min_dist = getattr(collision, "min_distance_m", None)
        col_likelihood = getattr(collision, "collision_likelihood", None)
        risk_level_str = str(getattr(collision, "risk_level", _NOT_AVAILABLE) or _NOT_AVAILABLE)
        predicted_conflict = bool(getattr(collision, "predicted_conflict", False))

        has_ttc = ttc_s is not None and _finite(ttc_s)
        has_likelihood = col_likelihood is not None and _finite(col_likelihood)

        # Determine emergency type from object attributes
        etype = self._classify_object_emergency_type(
            obj_type, obj_subtype, predicted_conflict
        )

        ev_base = EmergencyEvidence(
            ttc_s=float(ttc_s) if has_ttc else None,
            collision_likelihood=float(col_likelihood) if has_likelihood else None,
            min_distance_m=float(min_dist) if (min_dist is not None and _finite(min_dist)) else None,
            closing_speed_mps=float(closing_speed) if (closing_speed is not None and _finite(closing_speed)) else None,
            predicted_conflict=predicted_conflict,
            object_id=obj_id_str if obj_id_str != _NOT_AVAILABLE else None,
            object_type=obj_type,
            object_subtype=obj_subtype,
            safety_state=sm_state_str,
            safety_reason_codes=(),
            risk_level=risk_level_str,
        )

        # --- TTC-based detection ---
        if has_ttc and ttc_status == "FINITE":
            ttc_val = float(ttc_s)
            if ttc_val <= cfg.ttc_critical_s:
                events.append(_make_event(
                    source=EmergencySource.COLLISION_RISK,
                    etype=etype,
                    state=EmergencyState.CRITICAL_EMERGENCY,
                    severity=EmergencySeverity.CRITICAL,
                    urgency=EmergencyUrgency.IMMEDIATE,
                    timestamp=timestamp,
                    reason_codes=("CRITICAL_TTC", f"TTC={ttc_val:.2f}s"),
                    evidence=ev_base,
                    affected_objects=affected_objects,
                    confidence=_clamp01(obj_confidence),
                    uncertainty=_clamp01(1.0 - obj_confidence),
                    stale=obj_stale,
                    degraded=obj_degraded,
                ))
            elif ttc_val <= cfg.ttc_emergency_s:
                events.append(_make_event(
                    source=EmergencySource.COLLISION_RISK,
                    etype=etype,
                    state=EmergencyState.EMERGENCY_DETECTED,
                    severity=EmergencySeverity.HIGH,
                    urgency=EmergencyUrgency.HIGH,
                    timestamp=timestamp,
                    reason_codes=("LOW_TTC", f"TTC={ttc_val:.2f}s"),
                    evidence=ev_base,
                    affected_objects=affected_objects,
                    confidence=_clamp01(obj_confidence),
                    uncertainty=_clamp01(1.0 - obj_confidence),
                    stale=obj_stale,
                    degraded=obj_degraded,
                ))
            elif ttc_val <= cfg.ttc_potential_s:
                events.append(_make_event(
                    source=EmergencySource.COLLISION_RISK,
                    etype=etype,
                    state=EmergencyState.POTENTIAL_EMERGENCY,
                    severity=EmergencySeverity.MEDIUM,
                    urgency=EmergencyUrgency.MEDIUM,
                    timestamp=timestamp,
                    reason_codes=("POTENTIAL_TTC", f"TTC={ttc_val:.2f}s"),
                    evidence=ev_base,
                    affected_objects=affected_objects,
                    confidence=_clamp01(obj_confidence),
                    uncertainty=_clamp01(1.0 - obj_confidence),
                    stale=obj_stale,
                    degraded=obj_degraded,
                ))

        # --- Collision likelihood detection (independent of TTC) ---
        if has_likelihood and col_likelihood is not None:
            cl = float(col_likelihood)
            if cl >= cfg.collision_likelihood_critical:
                events.append(_make_event(
                    source=EmergencySource.COLLISION_RISK,
                    etype=etype,
                    state=EmergencyState.CRITICAL_EMERGENCY,
                    severity=EmergencySeverity.CRITICAL,
                    urgency=EmergencyUrgency.IMMEDIATE,
                    timestamp=timestamp,
                    reason_codes=("CRITICAL_COLLISION_LIKELIHOOD",
                                  f"likelihood={cl:.2f}"),
                    evidence=ev_base,
                    affected_objects=affected_objects,
                    confidence=_clamp01(obj_confidence * cl),
                    uncertainty=_clamp01(1.0 - obj_confidence * cl),
                    stale=obj_stale,
                    degraded=obj_degraded,
                ))
            elif cl >= cfg.collision_likelihood_emergency and not events:
                events.append(_make_event(
                    source=EmergencySource.COLLISION_RISK,
                    etype=etype,
                    state=EmergencyState.EMERGENCY_DETECTED,
                    severity=EmergencySeverity.HIGH,
                    urgency=EmergencyUrgency.HIGH,
                    timestamp=timestamp,
                    reason_codes=("HIGH_COLLISION_LIKELIHOOD",
                                  f"likelihood={cl:.2f}"),
                    evidence=ev_base,
                    affected_objects=affected_objects,
                    confidence=_clamp01(obj_confidence * cl),
                    uncertainty=_clamp01(1.0 - obj_confidence * cl),
                    stale=obj_stale,
                    degraded=obj_degraded,
                ))
            elif cl >= cfg.collision_likelihood_potential and not events:
                events.append(_make_event(
                    source=EmergencySource.COLLISION_RISK,
                    etype=etype,
                    state=EmergencyState.POTENTIAL_EMERGENCY,
                    severity=EmergencySeverity.MEDIUM,
                    urgency=EmergencyUrgency.MEDIUM,
                    timestamp=timestamp,
                    reason_codes=("POTENTIAL_COLLISION_LIKELIHOOD",
                                  f"likelihood={cl:.2f}"),
                    evidence=ev_base,
                    affected_objects=affected_objects,
                    confidence=_clamp01(obj_confidence),
                    uncertainty=_clamp01(1.0 - obj_confidence),
                    stale=obj_stale,
                    degraded=obj_degraded,
                ))

        # --- Predicted trajectory conflict (even without TTC) ---
        if predicted_conflict and risk_level_str == "CRITICAL" and not events:
            events.append(_make_event(
                source=EmergencySource.COLLISION_RISK,
                etype=etype,
                state=EmergencyState.EMERGENCY_DETECTED,
                severity=EmergencySeverity.HIGH,
                urgency=EmergencyUrgency.HIGH,
                timestamp=timestamp,
                reason_codes=("PREDICTED_TRAJECTORY_CONFLICT",),
                evidence=ev_base,
                affected_objects=affected_objects,
                confidence=_clamp01(obj_confidence * 0.8),
                uncertainty=_clamp01(1.0 - obj_confidence * 0.8),
                stale=obj_stale,
                degraded=obj_degraded,
            ))

        return events

    def _classify_object_emergency_type(
        self, obj_type: str, obj_subtype: str, predicted_conflict: bool
    ) -> EmergencyType:
        """Map object type/subtype to the most specific emergency type."""
        ot = obj_type.upper() if obj_type else ""
        os = obj_subtype.upper() if obj_subtype else ""

        if "PEDESTRIAN" in ot:
            return EmergencyType.SUDDEN_PEDESTRIAN_CROSSING
        if "CATTLE" in os or "COW" in os or "ANIMAL" in ot:
            return EmergencyType.SUDDEN_CATTLE_CROSSING
        if "CYCLIST" in ot or "BICYCLE" in ot:
            return EmergencyType.VULNERABLE_ROAD_USER_CONFLICT
        if "TWO_WHEELER" in ot or "MOTORCYCLE" in ot or "AUTO" in os:
            return EmergencyType.VULNERABLE_ROAD_USER_CONFLICT
        if "CUT_IN" in os or "CUTTING" in os:
            return EmergencyType.VEHICLE_CUT_IN
        if predicted_conflict:
            return EmergencyType.UNAVOIDABLE_TRAJECTORY_CONFLICT
        return EmergencyType.IMMINENT_COLLISION

    # ------------------------------------------------------------------

    def _check_planning(
        self, po, ref_ts: float, cfg: EmergencyDetectorConfig,
        sm_state_str: str, sm_reason_codes: Tuple[str, ...]
    ) -> List[EmergencyEvent]:
        """Check planner output for path risk and planning failures."""
        events: List[EmergencyEvent] = []
        if po is None:
            return events

        po_ts = float(getattr(po, "timestamp", ref_ts) or ref_ts)
        stale = _is_stale(po_ts, ref_ts, cfg.stale_threshold_s)
        po_stale = bool(getattr(po, "stale", False))
        is_stale = stale or po_stale

        po_degraded = bool(getattr(po, "degraded", True))
        planning_status = getattr(po, "planning_status", None)
        ps_val = str(planning_status.value if hasattr(planning_status, "value")
                     else planning_status or "UNKNOWN")
        planning_allowed = bool(getattr(po, "planning_allowed", False))

        risk_summary = getattr(po, "risk_summary", None)
        all_high_risk = bool(getattr(risk_summary, "all_candidates_high_risk", False)) \
            if risk_summary else False
        critical_risk_count = int(getattr(risk_summary, "critical_risk_candidate_count", 0)) \
            if risk_summary else 0
        dominant_risk_reason = str(getattr(risk_summary, "dominant_risk_reason", _NOT_AVAILABLE)
                                   or _NOT_AVAILABLE) if risk_summary else _NOT_AVAILABLE

        ev = EmergencyEvidence(
            safety_state=sm_state_str,
            safety_reason_codes=sm_reason_codes,
            planner_status=ps_val,
            dominant_risk_reason=dominant_risk_reason,
        )

        # Planner completely failed
        if ps_val in ("INVALID_INPUT", "NO_FEASIBLE_CANDIDATE", "BLOCKED"):
            events.append(_make_event(
                source=EmergencySource.PLANNING,
                etype=EmergencyType.PLANNER_FAILURE,
                state=EmergencyState.EMERGENCY_DETECTED,
                severity=EmergencySeverity.HIGH,
                urgency=EmergencyUrgency.HIGH,
                timestamp=po_ts,
                reason_codes=(f"PLANNER_FAILURE:{ps_val}",),
                evidence=ev,
                affected_subsystems=("planner",),
                confidence=0.9,
                uncertainty=0.1,
                stale=is_stale,
                degraded=po_degraded,
            ))

        # All candidate paths blocked/high risk
        if all_high_risk and not planning_allowed:
            events.append(_make_event(
                source=EmergencySource.PLANNING,
                etype=EmergencyType.PATH_BLOCKED,
                state=EmergencyState.EMERGENCY_DETECTED,
                severity=EmergencySeverity.HIGH,
                urgency=EmergencyUrgency.HIGH,
                timestamp=po_ts,
                reason_codes=("ALL_CANDIDATES_HIGH_RISK",
                              f"critical_count={critical_risk_count}"),
                evidence=ev,
                affected_subsystems=("planner", "path_risk"),
                confidence=0.85,
                uncertainty=0.15,
                stale=is_stale,
                degraded=po_degraded,
            ))
        elif critical_risk_count > 0:
            events.append(_make_event(
                source=EmergencySource.PLANNING,
                etype=EmergencyType.CRITICAL_PATH_RISK,
                state=EmergencyState.POTENTIAL_EMERGENCY,
                severity=EmergencySeverity.MEDIUM,
                urgency=EmergencyUrgency.MEDIUM,
                timestamp=po_ts,
                reason_codes=(f"CRITICAL_PATH_RISK:count={critical_risk_count}",
                              dominant_risk_reason),
                evidence=ev,
                affected_subsystems=("path_risk",),
                confidence=0.8,
                uncertainty=0.2,
                stale=is_stale,
                degraded=po_degraded,
            ))

        return events

    # ------------------------------------------------------------------

    def _check_tracking(
        self, ts_snap, ref_ts: float, cfg: EmergencyDetectorConfig,
        sm_state_str: str
    ) -> List[EmergencyEvent]:
        """Check tracking snapshot for reference lost / large deviation."""
        events: List[EmergencyEvent] = []
        if ts_snap is None:
            return events

        snap_ts = float(getattr(ts_snap, "snap_timestamp", ref_ts) or ref_ts)
        stale = _is_stale(snap_ts, ref_ts, cfg.stale_threshold_s)

        quality = getattr(ts_snap, "tracking_quality", None)
        tq_val = str(quality.value if hasattr(quality, "value")
                     else quality or "UNKNOWN")

        ev = EmergencyEvidence(
            tracking_quality=tq_val,
            safety_state=sm_state_str,
        )

        if tq_val == "REFERENCE_LOST":
            events.append(_make_event(
                source=EmergencySource.TRACKING,
                etype=EmergencyType.TRACKING_LOST,
                state=EmergencyState.EMERGENCY_DETECTED,
                severity=EmergencySeverity.HIGH,
                urgency=EmergencyUrgency.HIGH,
                timestamp=snap_ts,
                reason_codes=("TRACKING_REFERENCE_LOST",),
                evidence=ev,
                affected_subsystems=("tracking",),
                confidence=0.95,
                uncertainty=0.05,
                stale=stale,
            ))
        elif tq_val == "INVALID_INPUT":
            events.append(_make_event(
                source=EmergencySource.TRACKING,
                etype=EmergencyType.TRACKING_LOST,
                state=EmergencyState.EMERGENCY_DETECTED,
                severity=EmergencySeverity.HIGH,
                urgency=EmergencyUrgency.HIGH,
                timestamp=snap_ts,
                reason_codes=("TRACKING_INVALID_INPUT",),
                evidence=ev,
                affected_subsystems=("tracking",),
                confidence=0.9,
                uncertainty=0.1,
                stale=stale,
            ))

        return events

    # ------------------------------------------------------------------

    def _check_mpc(
        self, mpc, ref_ts: float, cfg: EmergencyDetectorConfig,
        sm_state_str: str
    ) -> List[EmergencyEvent]:
        """Check MPC snapshot for failure conditions."""
        events: List[EmergencyEvent] = []
        if mpc is None:
            return events

        snap_ts = float(getattr(mpc, "snap_timestamp", ref_ts) or ref_ts)
        stale = _is_stale(snap_ts, ref_ts, cfg.stale_threshold_s)

        mpc_status = getattr(mpc, "status", None)
        ms_val = str(mpc_status.value if hasattr(mpc_status, "value")
                     else mpc_status or "UNKNOWN")
        feasible = bool(getattr(mpc, "feasible", False))

        constraint_status = getattr(mpc, "constraint_status", None)
        cs_val = str(constraint_status.value if hasattr(constraint_status, "value")
                     else constraint_status or "")

        ev = EmergencyEvidence(
            mpc_status=ms_val,
            safety_state=sm_state_str,
        )

        if ms_val in ("INVALID_INPUT", "INVALID_REFERENCE"):
            events.append(_make_event(
                source=EmergencySource.MPC,
                etype=EmergencyType.MPC_FAILURE,
                state=EmergencyState.EMERGENCY_DETECTED,
                severity=EmergencySeverity.HIGH,
                urgency=EmergencyUrgency.HIGH,
                timestamp=snap_ts,
                reason_codes=(f"MPC_INVALID:{ms_val}",),
                evidence=ev,
                affected_subsystems=("mpc",),
                confidence=0.95,
                uncertainty=0.05,
                stale=stale,
            ))
        elif ms_val == "NO_FEASIBLE_SOLUTION" or (not feasible and ms_val != "SUCCESS"):
            events.append(_make_event(
                source=EmergencySource.MPC,
                etype=EmergencyType.MPC_FAILURE,
                state=EmergencyState.EMERGENCY_DETECTED,
                severity=EmergencySeverity.HIGH,
                urgency=EmergencyUrgency.HIGH,
                timestamp=snap_ts,
                reason_codes=("MPC_NO_FEASIBLE_SOLUTION",),
                evidence=ev,
                affected_subsystems=("mpc",),
                confidence=0.9,
                uncertainty=0.1,
                stale=stale,
            ))
        if cs_val == "VIOLATED":
            events.append(_make_event(
                source=EmergencySource.MPC,
                etype=EmergencyType.MPC_FAILURE,
                state=EmergencyState.CRITICAL_EMERGENCY,
                severity=EmergencySeverity.CRITICAL,
                urgency=EmergencyUrgency.IMMEDIATE,
                timestamp=snap_ts,
                reason_codes=("MPC_CONSTRAINT_VIOLATED",),
                evidence=ev,
                affected_subsystems=("mpc",),
                confidence=1.0,
                uncertainty=0.0,
                stale=stale,
            ))

        return events

    # ------------------------------------------------------------------

    def _check_control(
        self, cmd, ref_ts: float, cfg: EmergencyDetectorConfig,
        sm_state_str: str
    ) -> List[EmergencyEvent]:
        """Check control command for failure conditions."""
        events: List[EmergencyEvent] = []
        if cmd is None:
            return events

        cmd_ts = float(getattr(cmd, "timestamp", ref_ts) or ref_ts)
        stale = _is_stale(cmd_ts, ref_ts, cfg.stale_threshold_s)

        cmd_status = getattr(cmd, "status", None)
        cs_val = str(cmd_status.value if hasattr(cmd_status, "value")
                     else cmd_status or "UNKNOWN")

        ev = EmergencyEvidence(
            control_status=cs_val,
            safety_state=sm_state_str,
        )

        if cs_val in ("INVALID", "NO_SOLUTION"):
            events.append(_make_event(
                source=EmergencySource.CONTROL,
                etype=EmergencyType.CONTROL_FAILURE,
                state=EmergencyState.EMERGENCY_DETECTED,
                severity=EmergencySeverity.HIGH,
                urgency=EmergencyUrgency.HIGH,
                timestamp=cmd_ts,
                reason_codes=(f"CONTROL_FAILURE:{cs_val}",),
                evidence=ev,
                affected_subsystems=("control",),
                confidence=0.95,
                uncertainty=0.05,
                stale=stale,
            ))

        return events

    # ------------------------------------------------------------------

    def _check_vehicle(
        self, dyn, ref_ts: float, sm_state_str: str
    ) -> List[EmergencyEvent]:
        """Check vehicle dynamics for NaN/Inf state."""
        events: List[EmergencyEvent] = []
        if dyn is None:
            return events

        snap_ts = float(getattr(dyn, "snapshot_timestamp", ref_ts) or ref_ts)
        invalid_fields: List[str] = []

        for fname in ("x", "y", "yaw", "velocity", "acceleration"):
            val = getattr(dyn, fname, None)
            if val is not None and not _finite(val):
                invalid_fields.append(fname)

        state = getattr(dyn, "state", None)
        if state is not None:
            for fname in ("x", "y", "yaw", "speed"):
                val = getattr(state, fname, None)
                if val is not None and not _finite(val) and fname not in invalid_fields:
                    invalid_fields.append(fname)

        if invalid_fields:
            ev = EmergencyEvidence(
                safety_state=sm_state_str,
                extra={"invalid_fields": invalid_fields},
            )
            events.append(_make_event(
                source=EmergencySource.VEHICLE,
                etype=EmergencyType.VEHICLE_STATE_INVALID,
                state=EmergencyState.CRITICAL_EMERGENCY,
                severity=EmergencySeverity.CRITICAL,
                urgency=EmergencyUrgency.IMMEDIATE,
                timestamp=snap_ts,
                reason_codes=("VEHICLE_STATE_NAN_OR_INF",
                              f"fields={invalid_fields}"),
                evidence=ev,
                affected_subsystems=("vehicle",),
                confidence=1.0,
                uncertainty=0.0,
            ))

        return events

    # ------------------------------------------------------------------
    # Hysteresis / debounce
    # ------------------------------------------------------------------

    def _apply_hysteresis(
        self,
        raw_state: EmergencyState,
        prior_state: Optional[EmergencyDetectionState],
        cfg: EmergencyDetectorConfig,
    ) -> Tuple[EmergencyState, int, int]:
        """
        Apply configurable hysteresis to avoid state oscillation.
        Returns (final_state, hysteresis_counter, clear_counter).
        """
        if cfg.persistence_cycles <= 0 and cfg.clear_cycles <= 0:
            return raw_state, 0, 0

        if prior_state is None:
            # No prior state — apply directly without debounce
            return raw_state, 0, 0

        prior_em_state = prior_state.emergency_state
        h_counter = prior_state.hysteresis_counter
        c_counter = prior_state.clear_counter

        is_new_emergency = raw_state in (
            EmergencyState.POTENTIAL_EMERGENCY,
            EmergencyState.EMERGENCY_DETECTED,
            EmergencyState.CRITICAL_EMERGENCY,
        )
        was_emergency = prior_em_state in (
            EmergencyState.POTENTIAL_EMERGENCY,
            EmergencyState.EMERGENCY_DETECTED,
            EmergencyState.CRITICAL_EMERGENCY,
        )

        if is_new_emergency:
            h_counter += 1
            c_counter = 0
            # Apply persistence debounce for lower-severity only
            if raw_state == EmergencyState.POTENTIAL_EMERGENCY \
                    and not was_emergency \
                    and h_counter < cfg.persistence_cycles:
                return prior_em_state if prior_em_state != EmergencyState.NO_EMERGENCY \
                       else EmergencyState.POTENTIAL_EMERGENCY, h_counter, c_counter
            return raw_state, h_counter, c_counter

        # No emergency detected this cycle
        if was_emergency:
            c_counter += 1
            h_counter = 0
            if c_counter < cfg.clear_cycles:
                # Persist the emergency state while clearing
                return prior_em_state, h_counter, c_counter
            # Fully cleared
            c_counter = 0
            return EmergencyState.EMERGENCY_CLEARED, 0, 0

        h_counter = 0
        return raw_state, 0, c_counter

    # ------------------------------------------------------------------
    # Aggregation helpers
    # ------------------------------------------------------------------

    def _dominant_event(
        self, events: List[EmergencyEvent]
    ) -> Optional[EmergencyEvent]:
        """Return the highest-priority event."""
        if not events:
            return None

        priority = {
            EmergencyState.CRITICAL_EMERGENCY:  0,
            EmergencyState.EMERGENCY_DETECTED:  1,
            EmergencyState.POTENTIAL_EMERGENCY: 2,
            EmergencyState.EMERGENCY_DEGRADED:  3,
            EmergencyState.EMERGENCY_UNKNOWN:   4,
            EmergencyState.EMERGENCY_CLEARED:   5,
            EmergencyState.NO_EMERGENCY:        6,
        }
        sev_priority = {
            EmergencySeverity.CRITICAL: 0,
            EmergencySeverity.HIGH:     1,
            EmergencySeverity.MEDIUM:   2,
            EmergencySeverity.LOW:      3,
            EmergencySeverity.UNKNOWN:  4,
        }
        return min(
            events,
            key=lambda e: (
                priority.get(e.state, 9),
                sev_priority.get(e.severity, 9),
                -e.confidence,
            ),
        )

    def _collect_reason_codes(self, events: List[EmergencyEvent]) -> List[str]:
        """Unique reason codes ordered by event severity."""
        seen: Set[str] = set()
        codes: List[str] = []
        priority = {
            EmergencyState.CRITICAL_EMERGENCY:  0,
            EmergencyState.EMERGENCY_DETECTED:  1,
            EmergencyState.POTENTIAL_EMERGENCY: 2,
        }
        for ev in sorted(events, key=lambda e: priority.get(e.state, 9)):
            for rc in ev.reason_codes:
                if rc and rc not in seen:
                    seen.add(rc)
                    codes.append(rc)
        return codes

    def _aggregate_confidence(
        self, events: List[EmergencyEvent], final_state: EmergencyState
    ) -> float:
        """Aggregate confidence across all events."""
        if not events:
            return 0.0
        if final_state == EmergencyState.NO_EMERGENCY:
            return 1.0
        # Weighted by state priority
        priority_weights = {
            EmergencyState.CRITICAL_EMERGENCY:  1.0,
            EmergencyState.EMERGENCY_DETECTED:  0.85,
            EmergencyState.POTENTIAL_EMERGENCY: 0.7,
        }
        weighted = sum(
            ev.confidence * priority_weights.get(ev.state, 0.5)
            for ev in events
        )
        total_weight = sum(
            priority_weights.get(ev.state, 0.5)
            for ev in events
        )
        return _clamp01(weighted / total_weight if total_weight > 0 else 0.0)
