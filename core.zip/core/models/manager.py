"""
IndiDrive AI — Phase 5 | Model Manager
========================================
Registry for AI models used across the stack (YOLOv11, YOLOP, ByteTrack,
SAM2, and any future custom model). Tracks install location, versions,
which model is "active" per role, and performance comparison numbers
that the Benchmark Center writes back into here.

No SQL — a single models.json registry file, small enough that this is
the right call (there are dozens of models, not millions of rows).
"""
from __future__ import annotations

import json
import time
import uuid
from pathlib import Path
from typing import Optional

STORAGE_ROOT = Path(__file__).resolve().parents[2] / "storage" / "models"
REGISTRY_PATH = STORAGE_ROOT / "models.json"

KNOWN_ROLES = ["detector", "segmenter", "tracker", "planner_aux", "custom"]

DEFAULT_CATALOG = [
    {"name": "YOLOv11", "role": "detector", "source": "ultralytics/yolo11", "builtin": True},
    {"name": "YOLOP", "role": "segmenter", "source": "hustvl/YOLOP", "builtin": True},
    {"name": "ByteTrack", "role": "tracker", "source": "ifzhang/ByteTrack", "builtin": True},
    {"name": "SAM2", "role": "segmenter", "source": "facebookresearch/sam2", "builtin": True},
]


class ModelManager:
    def __init__(self):
        STORAGE_ROOT.mkdir(parents=True, exist_ok=True)
        if not REGISTRY_PATH.exists():
            self._save({"models": [], "active": {}})
            for entry in DEFAULT_CATALOG:
                self.install_model(entry["name"], entry["role"], entry["source"], mark_active=False)

    def _load(self) -> dict:
        return json.loads(REGISTRY_PATH.read_text())

    def _save(self, data: dict):
        REGISTRY_PATH.write_text(json.dumps(data, indent=2))

    # ---------- CRUD -----------------------------------------------------

    def list_models(self) -> dict:
        data = self._load()
        return data

    def install_model(self, name: str, role: str, source: str = "", version: str = "v1",
                       weights_path: Optional[str] = None, mark_active: bool = True) -> dict:
        if role not in KNOWN_ROLES:
            raise ValueError(f"role must be one of {KNOWN_ROLES}")
        data = self._load()
        model_id = uuid.uuid4().hex[:10]
        entry = {
            "model_id": model_id,
            "name": name,
            "role": role,
            "source": source,
            "version": version,
            "weights_path": weights_path,
            "installed_at": time.time(),
            "metrics": {},  # populated by benchmark center
            "onnx_path": None,
        }
        data["models"].append(entry)
        if mark_active or role not in data["active"]:
            data["active"][role] = model_id
        self._save(data)
        return entry

    def remove_model(self, model_id: str) -> bool:
        data = self._load()
        before = len(data["models"])
        data["models"] = [m for m in data["models"] if m["model_id"] != model_id]
        for role, active_id in list(data["active"].items()):
            if active_id == model_id:
                del data["active"][role]
        self._save(data)
        return len(data["models"]) < before

    def set_active(self, role: str, model_id: str) -> dict:
        data = self._load()
        if not any(m["model_id"] == model_id for m in data["models"]):
            raise FileNotFoundError(model_id)
        data["active"][role] = model_id
        self._save(data)
        return data["active"]

    def record_metrics(self, model_id: str, metrics: dict) -> dict:
        data = self._load()
        for m in data["models"]:
            if m["model_id"] == model_id:
                m["metrics"].update(metrics)
                m["metrics"]["last_benchmarked_at"] = time.time()
                self._save(data)
                return m
        raise FileNotFoundError(model_id)

    def compare(self, role: Optional[str] = None) -> list[dict]:
        data = self._load()
        models = data["models"] if role is None else [m for m in data["models"] if m["role"] == role]
        return sorted(models, key=lambda m: m["metrics"].get("map50", 0), reverse=True)

    def export_onnx(self, model_id: str) -> dict:
        """
        Attempts a real ONNX export via ultralytics if the model + lib are
        available; otherwise records the export as unavailable rather than
        faking a file.
        """
        data = self._load()
        target = next((m for m in data["models"] if m["model_id"] == model_id), None)
        if target is None:
            raise FileNotFoundError(model_id)
        try:
            from ultralytics import YOLO  # type: ignore
            weights = target.get("weights_path") or "yolo11n.pt"
            model = YOLO(weights)
            onnx_path = model.export(format="onnx")
            target["onnx_path"] = str(onnx_path)
            status = "exported"
        except Exception as e:
            status = f"unavailable ({type(e).__name__}: {e})"
        self._save(data)
        return {"model_id": model_id, "status": status, "onnx_path": target.get("onnx_path")}
