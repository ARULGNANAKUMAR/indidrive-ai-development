"""
IndiDrive AI — Phase 5 | ECHO V2 Self-Learning
================================================
Pipeline: Experience -> Pattern -> Principle -> Capability -> Model Improvement.

This is a real, working implementation of that pipeline at the level
that's honest to build without a training cluster:

  Experience  : one recorded driving decision + outcome (from Phase 3/4).
  Pattern     : experiences clustered by similarity (situation features)
                using simple k-means-style centroid clustering — no
                heavyweight ML dependency required, but genuinely
                grouping by feature distance, not just tagging randomly.
  Principle   : a pattern promoted once it has enough support + a
                consistent outcome — stored as an explicit rule
                (condition -> recommended action) a planner can read.
  Capability  : principles a promoted further into a named capability
                once several principles reinforce the same behavior
                across contexts (e.g. "cautious cattle-crossing braking").
  Model Improvement : capabilities are exported as a training-hint file
                (JSON) that a future fine-tuning job would consume —
                this module does not itself retrain a network.

Storage: JSONL for experiences (append-only, replayable), JSON for
patterns/principles/capabilities (small enough for whole-file rewrite).
"""
from __future__ import annotations

import json
import math
import time
import uuid
from pathlib import Path
from typing import Optional

STORAGE_ROOT = Path(__file__).resolve().parents[2] / "storage" / "echo"
EXPERIENCES_PATH = STORAGE_ROOT / "experiences.jsonl"
PATTERNS_PATH = STORAGE_ROOT / "patterns.json"
PRINCIPLES_PATH = STORAGE_ROOT / "principles.json"
CAPABILITIES_PATH = STORAGE_ROOT / "capabilities.json"

FEATURE_KEYS = ["risk_score", "ttc_min", "speed", "drivable_frac", "lane_count"]


def _euclid(a: dict, b: dict) -> float:
    return math.sqrt(sum((a.get(k, 0.0) - b.get(k, 0.0)) ** 2 for k in FEATURE_KEYS))


class EchoV2:
    def __init__(self):
        STORAGE_ROOT.mkdir(parents=True, exist_ok=True)
        EXPERIENCES_PATH.touch(exist_ok=True)
        for p in (PATTERNS_PATH, PRINCIPLES_PATH, CAPABILITIES_PATH):
            if not p.exists():
                p.write_text("[]")

    # ---------- Experience -------------------------------------------------

    def record_experience(self, scenario: str, features: dict, action_taken: str,
                           outcome: str, notes: str = "") -> dict:
        """outcome in {'safe','near_miss','collision','inefficient'}"""
        exp = {
            "exp_id": uuid.uuid4().hex[:12],
            "ts": time.time(),
            "scenario": scenario,
            "features": {k: float(features.get(k, 0.0)) for k in FEATURE_KEYS},
            "action_taken": action_taken,
            "outcome": outcome,
            "notes": notes,
            "importance": self._importance(outcome),
            "pattern_id": None,
        }
        with open(EXPERIENCES_PATH, "a") as f:
            f.write(json.dumps(exp) + "\n")
        return exp

    def _importance(self, outcome: str) -> float:
        return {"collision": 1.0, "near_miss": 0.8, "inefficient": 0.4, "safe": 0.2}.get(outcome, 0.3)

    def list_experiences(self, limit: int = 200) -> list[dict]:
        lines = [json.loads(l) for l in open(EXPERIENCES_PATH) if l.strip()]
        return lines[-limit:]

    def replay(self, scenario: Optional[str] = None, min_importance: float = 0.0) -> list[dict]:
        exps = self.list_experiences(limit=100000)
        return [e for e in exps
                if e["importance"] >= min_importance and (scenario is None or e["scenario"] == scenario)]

    # ---------- Pattern clustering ------------------------------------------

    def cluster_patterns(self, k: int = 6, iterations: int = 15) -> list[dict]:
        """Simple k-means over experience feature vectors."""
        exps = self.list_experiences(limit=100000)
        if len(exps) < k:
            k = max(1, len(exps))
        if k == 0:
            return []
        centroids = [exps[i]["features"] for i in range(k)]
        assignments = [0] * len(exps)

        for _ in range(iterations):
            for i, e in enumerate(exps):
                dists = [_euclid(e["features"], c) for c in centroids]
                assignments[i] = dists.index(min(dists))
            for c_idx in range(k):
                members = [exps[i]["features"] for i in range(len(exps)) if assignments[i] == c_idx]
                if members:
                    centroids[c_idx] = {key: sum(m[key] for m in members) / len(members) for key in FEATURE_KEYS}

        patterns = []
        for c_idx in range(k):
            members = [exps[i] for i in range(len(exps)) if assignments[i] == c_idx]
            if not members:
                continue
            outcome_counts: dict[str, int] = {}
            for m in members:
                outcome_counts[m["outcome"]] = outcome_counts.get(m["outcome"], 0) + 1
            dominant_outcome = max(outcome_counts, key=outcome_counts.get)
            consistency = outcome_counts[dominant_outcome] / len(members)
            patterns.append({
                "pattern_id": uuid.uuid4().hex[:10],
                "centroid": centroids[c_idx],
                "support": len(members),
                "dominant_outcome": dominant_outcome,
                "consistency": round(consistency, 3),
                "member_scenarios": list({m["scenario"] for m in members}),
                "created_at": time.time(),
            })
        PATTERNS_PATH.write_text(json.dumps(patterns, indent=2))
        return patterns

    # ---------- Principle promotion -----------------------------------------

    def promote_principles(self, min_support: int = 3, min_consistency: float = 0.7) -> list[dict]:
        patterns = json.loads(PATTERNS_PATH.read_text())
        principles = json.loads(PRINCIPLES_PATH.read_text())
        existing_ids = {p["source_pattern_id"] for p in principles}
        for p in patterns:
            if p["pattern_id"] in existing_ids:
                continue
            if p["support"] >= min_support and p["consistency"] >= min_consistency:
                action = self._infer_action(p)
                principles.append({
                    "principle_id": uuid.uuid4().hex[:10],
                    "source_pattern_id": p["pattern_id"],
                    "condition": p["centroid"],
                    "recommended_action": action,
                    "confidence": p["consistency"],
                    "scenarios": p["member_scenarios"],
                    "promoted_at": time.time(),
                })
        PRINCIPLES_PATH.write_text(json.dumps(principles, indent=2))
        return principles

    def _infer_action(self, pattern: dict) -> str:
        if pattern["dominant_outcome"] in ("collision", "near_miss"):
            return "REDUCE_SPEED_AND_INCREASE_FOLLOWING_DISTANCE"
        if pattern["dominant_outcome"] == "inefficient":
            return "OPTIMIZE_PATH_SMOOTHING"
        return "MAINTAIN_CURRENT_BEHAVIOR"

    # ---------- Capability promotion ----------------------------------------

    def promote_capabilities(self, min_principle_group: int = 2) -> list[dict]:
        principles = json.loads(PRINCIPLES_PATH.read_text())
        capabilities = json.loads(CAPABILITIES_PATH.read_text())
        existing_actions = {c["action"] for c in capabilities}

        groups: dict[str, list[dict]] = {}
        for p in principles:
            groups.setdefault(p["recommended_action"], []).append(p)

        for action, group in groups.items():
            if action in existing_actions or len(group) < min_principle_group:
                continue
            scenarios = sorted({s for p in group for s in p["scenarios"]})
            capabilities.append({
                "capability_id": uuid.uuid4().hex[:10],
                "action": action,
                "name": self._name_capability(action, scenarios),
                "supporting_principles": [p["principle_id"] for p in group],
                "scenarios": scenarios,
                "avg_confidence": round(sum(p["confidence"] for p in group) / len(group), 3),
                "created_at": time.time(),
            })
        CAPABILITIES_PATH.write_text(json.dumps(capabilities, indent=2))
        return capabilities

    def _name_capability(self, action: str, scenarios: list[str]) -> str:
        ctx = scenarios[0].replace("_", " ") if scenarios else "general"
        return f"{action.replace('_', ' ').title()} ({ctx})"

    def export_training_hints(self) -> dict:
        """Hand-off artifact for a future fine-tuning job. Does not retrain anything itself."""
        capabilities = json.loads(CAPABILITIES_PATH.read_text())
        return {
            "generated_at": time.time(),
            "capability_count": len(capabilities),
            "capabilities": capabilities,
            "note": "Consume this in a separate fine-tuning pipeline; ECHO V2 only mines patterns, it does not train weights.",
        }

    # ---------- Memory management --------------------------------------------

    def memory_growth(self) -> dict:
        exps = self.list_experiences(limit=100000)
        return {
            "total_experiences": len(exps),
            "patterns": len(json.loads(PATTERNS_PATH.read_text())),
            "principles": len(json.loads(PRINCIPLES_PATH.read_text())),
            "capabilities": len(json.loads(CAPABILITIES_PATH.read_text())),
        }

    def cleanup(self, keep_last: int = 5000, min_importance_to_keep: float = 0.3) -> dict:
        """
        Forgetting policy: keep everything above min_importance, and among
        the low-importance rest keep only the most recent `keep_last`.
        """
        exps = self.list_experiences(limit=10_000_000)
        important = [e for e in exps if e["importance"] >= min_importance_to_keep]
        unimportant = [e for e in exps if e["importance"] < min_importance_to_keep][-keep_last:]
        kept = sorted(important + unimportant, key=lambda e: e["ts"])
        with open(EXPERIENCES_PATH, "w") as f:
            for e in kept:
                f.write(json.dumps(e) + "\n")
        return {"before": len(exps), "after": len(kept), "removed": len(exps) - len(kept)}
