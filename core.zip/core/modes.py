"""
IndiDrive AI — Phase 0 | Operating Modes
===========================================
Application-level operating mode, separate from and additive to the
pre-existing core/deployment.py DeploymentManager. See
docs/PROJECT_AUDIT.md ("Two mode concepts") for why both exist.

Supported modes (Phase 0 scope — infrastructure separation only, no
mode here implements autonomous behavior):

    OFFLINE    Default. No outbound calls to any cloud/LLM/remote AI API.
               (Nothing in this codebase currently makes such calls, so
               this is currently a no-op guarantee, not an enforced one.)
    CARLA      Working against a live CARLA server via
               core/carla_integration/.
    RECORD     Recording sensor/scenario data (e.g. scripts/carla_spawn_and_record.py).
    TEST       Running the automated test suite (tests/).
    BENCHMARK  Running core/benchmark/suite.py.

Phase 0 only provides clean separation and a place to read/set the
current mode — it does NOT implement offline autonomous driving,
automatic mode transitions, or mode-specific behavior gating beyond
what is described above.
"""
from __future__ import annotations

import json
import os
import time
from pathlib import Path
from typing import Optional

ROOT = Path(__file__).resolve().parent.parent
STATE_PATH = ROOT / "storage" / "operating_mode.json"

VALID_MODES = ("OFFLINE", "CARLA", "RECORD", "TEST", "BENCHMARK")

ENV_VAR = "INDIDRIVE_MODE"


class InvalidModeError(ValueError):
    pass


def _default_mode() -> str:
    env_mode = os.environ.get(ENV_VAR, "").strip().upper()
    if env_mode in VALID_MODES:
        return env_mode
    return "OFFLINE"


def get_mode() -> dict:
    """Return the current operating mode, reading persisted state if present."""
    if STATE_PATH.exists():
        try:
            data = json.loads(STATE_PATH.read_text())
            if data.get("mode") in VALID_MODES:
                return data
        except (json.JSONDecodeError, OSError):
            pass
    return {"mode": _default_mode(), "set_at": None, "source": "default"}


def set_mode(mode: str) -> dict:
    """Persist a new operating mode. Raises InvalidModeError for anything not in VALID_MODES."""
    mode = mode.strip().upper()
    if mode not in VALID_MODES:
        raise InvalidModeError(f"'{mode}' is not a valid mode. Expected one of: {VALID_MODES}")
    STATE_PATH.parent.mkdir(parents=True, exist_ok=True)
    data = {"mode": mode, "set_at": time.time(), "source": "explicit"}
    STATE_PATH.write_text(json.dumps(data, indent=2))
    return data


def list_modes() -> dict:
    return {
        "modes": list(VALID_MODES),
        "current": get_mode()["mode"],
        "env_var": ENV_VAR,
    }


def is_offline() -> bool:
    return get_mode()["mode"] == "OFFLINE"
