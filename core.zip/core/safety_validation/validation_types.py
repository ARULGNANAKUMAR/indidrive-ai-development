"""
IndiDrive AI — Phase 11.5 | Safety Validation Types
=====================================================
Typed enumerations and immutable data containers for the
Safety Validation and Stress Testing layer.

Design rules:
  * Frozen dataclasses — immutable after construction.
  * No computation — only type definitions.
  * No circular imports — stdlib and typing only.
  * Deterministic: same input → same output.
  * Results are COMPACT — no full World Model copies embedded.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Optional, Tuple

__all__ = [
    "VALIDATION_SCHEMA_VERSION",
    # Enums
    "ValidationStatus",
    "InvariantId",
    "FaultTarget",
    "FaultType",
    "ScenarioCategory",
    # Containers
    "AssertionResult",
    "SafetyValidationResult",
    "ValidationTrace",
    "FaultSpec",
    "ScenarioSpec",
]

VALIDATION_SCHEMA_VERSION: str = "11.5"


# ---------------------------------------------------------------------------
# Validation Status
# ---------------------------------------------------------------------------

class ValidationStatus(str, Enum):
    """
    Result status of a safety validation run.

    PASS          — All expected safety invariants satisfied.
    FAIL          — A defined safety invariant or expected condition violated.
    INCONCLUSIVE  — Required evidence was insufficient.
    DEGRADED      — Validation completed but system was in degraded operation.
    SKIPPED       — Scenario skipped (optional capability not available).
    INVALID_INPUT — The scenario/test itself is malformed.
    UNKNOWN       — Framework cannot determine a trustworthy result.
    """
    PASS          = "PASS"
    FAIL          = "FAIL"
    INCONCLUSIVE  = "INCONCLUSIVE"
    DEGRADED      = "DEGRADED"
    SKIPPED       = "SKIPPED"
    INVALID_INPUT = "INVALID_INPUT"
    UNKNOWN       = "UNKNOWN"


# ---------------------------------------------------------------------------
# Safety Invariant IDs
# ---------------------------------------------------------------------------

class InvariantId(str, Enum):
    """
    Named safety invariants that this framework enforces.
    Maps directly to the specification items A–J.
    """
    # A — Critical emergency cannot silently grant normal control
    INVARIANT_A_NO_NORMAL_ON_CRITICAL_EMERGENCY = "A_NO_NORMAL_ON_CRITICAL_EMERGENCY"
    # B — Critical safety state cannot silently become normal
    INVARIANT_B_NO_NORMAL_FROM_CRITICAL_SAFETY  = "B_NO_NORMAL_FROM_CRITICAL_SAFETY"
    # C — Stale safety-critical info cannot be treated as fresh
    INVARIANT_C_STALE_IS_NOT_FRESH              = "C_STALE_IS_NOT_FRESH"
    # D — Invalid safety-critical info cannot become trusted
    INVARIANT_D_INVALID_IS_NOT_TRUSTED          = "D_INVALID_IS_NOT_TRUSTED"
    # E — Sensor failure must affect dependent capabilities
    INVARIANT_E_SENSOR_FAILURE_PROPAGATES       = "E_SENSOR_FAILURE_PROPAGATES"
    # F — Sensor failure must not kill unrelated capabilities
    INVARIANT_F_SENSOR_FAILURE_SCOPED           = "F_SENSOR_FAILURE_SCOPED"
    # G — Control failure cannot result in normal control authority
    INVARIANT_G_CONTROL_FAILURE_IS_RESTRICTED   = "G_CONTROL_FAILURE_IS_RESTRICTED"
    # H — Recovery must be validated
    INVARIANT_H_RECOVERY_REQUIRES_EVIDENCE      = "H_RECOVERY_REQUIRES_EVIDENCE"
    # I — Multiple failures must be preserved
    INVARIANT_I_MULTIPLE_FAILURES_PRESERVED     = "I_MULTIPLE_FAILURES_PRESERVED"
    # J — Determinism: identical inputs → identical outputs
    INVARIANT_J_DETERMINISM                     = "J_DETERMINISM"


# ---------------------------------------------------------------------------
# Fault injection targets and types (test-only, not runtime)
# ---------------------------------------------------------------------------

class FaultTarget(str, Enum):
    """
    Target of a fault injection operation (test-only).
    Maps to physical sensors and logical subsystems in the pipeline.
    """
    CAMERA             = "CAMERA"
    LIDAR              = "LIDAR"
    RADAR              = "RADAR"
    SENSOR_BUFFER      = "SENSOR_BUFFER"
    PERCEPTION         = "PERCEPTION"
    FUSION             = "FUSION"
    PREDICTION         = "PREDICTION"
    ROAD_UNDERSTANDING = "ROAD_UNDERSTANDING"
    WORLD_MODEL        = "WORLD_MODEL"
    PLANNING           = "PLANNING"
    TRACKING           = "TRACKING"
    MPC                = "MPC"
    CONTROL            = "CONTROL"
    SAFETY_MONITOR     = "SAFETY_MONITOR"
    EMERGENCY_DETECTION = "EMERGENCY_DETECTION"
    SAFETY_SUPERVISOR  = "SAFETY_SUPERVISOR"


class FaultType(str, Enum):
    """Modes of fault injection for testing."""
    UNAVAILABLE         = "UNAVAILABLE"
    DEGRADED            = "DEGRADED"
    STALE               = "STALE"
    INVALID_DATA        = "INVALID_DATA"
    LOW_CONFIDENCE      = "LOW_CONFIDENCE"
    HIGH_UNCERTAINTY    = "HIGH_UNCERTAINTY"
    TIMEOUT             = "TIMEOUT"
    CORRUPTED           = "CORRUPTED"
    NAN_VALUE           = "NAN_VALUE"
    INFINITY_VALUE      = "INFINITY_VALUE"
    INVALID_TIMESTAMP   = "INVALID_TIMESTAMP"
    SYNC_FAILURE        = "SYNC_FAILURE"


# ---------------------------------------------------------------------------
# Scenario categories
# ---------------------------------------------------------------------------

class ScenarioCategory(str, Enum):
    """Broad categories for validation scenarios."""
    NORMAL_OPERATION          = "NORMAL_OPERATION"
    DEGRADED_OPERATION        = "DEGRADED_OPERATION"
    CRITICAL_FAILURE          = "CRITICAL_FAILURE"
    MULTIPLE_FAILURE          = "MULTIPLE_FAILURE"
    FAILURE_CASCADE           = "FAILURE_CASCADE"
    RECOVERY                  = "RECOVERY"
    HYSTERESIS                = "HYSTERESIS"
    STALE_DATA                = "STALE_DATA"
    INVALID_DATA              = "INVALID_DATA"
    BOUNDARY_VALUE            = "BOUNDARY_VALUE"
    HIGH_FREQUENCY_STRESS     = "HIGH_FREQUENCY_STRESS"
    LONG_RUN_SEQUENCE         = "LONG_RUN_SEQUENCE"
    INDIAN_ROAD               = "INDIAN_ROAD"
    INDIAN_ROAD_SENSOR_COMBO  = "INDIAN_ROAD_SENSOR_COMBO"
    DETERMINISM               = "DETERMINISM"
    PROPERTY_BASED            = "PROPERTY_BASED"
    SNAPSHOT_CONSISTENCY      = "SNAPSHOT_CONSISTENCY"
    STATE_TRANSITION          = "STATE_TRANSITION"
    PERFORMANCE               = "PERFORMANCE"


# ---------------------------------------------------------------------------
# Individual assertion result
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class AssertionResult:
    """
    Result of evaluating one named assertion within a scenario.

    Fields
    ------
    assertion_id   : Unique identifier (invariant ID + index).
    invariant_id   : Which safety invariant this assertion checks.
    description    : Human-readable description of what was checked.
    passed         : True if the assertion passed.
    expected       : Expected value/state (as a string for compactness).
    actual         : Actual observed value/state.
    mismatch       : Human-readable description of the mismatch (or "").
    """
    assertion_id: str            = ""
    invariant_id: str            = ""
    description:  str            = ""
    passed:       bool           = False
    expected:     str            = ""
    actual:       str            = ""
    mismatch:     str            = ""


# ---------------------------------------------------------------------------
# Safety Validation Result — primary output per scenario
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class SafetyValidationResult:
    """
    Structured result of validating one scenario against the Phase 11 stack.

    Compact by design — does NOT embed full World Model objects.

    Fields
    ------
    validation_id           : Unique ID for this result.
    scenario_id             : ID of the scenario that was run.
    scenario_category       : ScenarioCategory enum.
    timestamp               : Scenario start timestamp (data time, not wall clock).
    frame_id                : Frame counter at scenario execution.
    status                  : ValidationStatus enum.

    expected_safety_state   : Expected SafetyState string.
    actual_safety_state     : Actual SafetyState string produced.

    expected_emergency_state: Expected EmergencyState string.
    actual_emergency_state  : Actual EmergencyState string produced.

    expected_fail_safe_state: Expected FailSafeState string.
    actual_fail_safe_state  : Actual FailSafeState string produced.

    expected_control_authority: Expected ControlAuthority string.
    actual_control_authority  : Actual ControlAuthority string produced.

    expected_reason_codes   : Expected set of reason code strings.
    actual_reason_codes     : Actual set of reason code strings produced.

    assertion_results       : Tuple of per-assertion results.
    mismatch_codes          : Codes explaining any mismatches.
    diagnostics             : Human-readable diagnostics string.

    severity                : Severity of the scenario tested.
    confidence              : [0.0, 1.0] confidence in this result.
    uncertainty             : [0.0, 1.0] uncertainty.

    stale                   : True if tested system was operating on stale data.
    degraded                : True if tested system was operating in degraded mode.

    execution_time_ms       : Observed wall-clock execution time (ms), 0 if unmeasured.
    cycles_executed         : Number of pipeline cycles executed in the scenario.
    schema_version          : "11.5".
    """
    validation_id:              str                         = ""
    scenario_id:                str                         = ""
    scenario_category:          str                         = ScenarioCategory.NORMAL_OPERATION.value
    timestamp:                  float                       = 0.0
    frame_id:                   int                         = 0
    status:                     ValidationStatus            = ValidationStatus.UNKNOWN

    expected_safety_state:      str                         = ""
    actual_safety_state:        str                         = ""

    expected_emergency_state:   str                         = ""
    actual_emergency_state:     str                         = ""

    expected_fail_safe_state:   str                         = ""
    actual_fail_safe_state:     str                         = ""

    expected_control_authority: str                         = ""
    actual_control_authority:   str                         = ""

    expected_reason_codes:      Tuple[str, ...]             = field(default_factory=tuple)
    actual_reason_codes:        Tuple[str, ...]             = field(default_factory=tuple)

    assertion_results:          Tuple[AssertionResult, ...] = field(default_factory=tuple)
    mismatch_codes:             Tuple[str, ...]             = field(default_factory=tuple)
    diagnostics:                str                         = ""

    severity:                   str                         = "UNKNOWN"
    confidence:                 float                       = 0.0
    uncertainty:                float                       = 1.0

    stale:                      bool                        = False
    degraded:                   bool                        = False

    execution_time_ms:          float                       = 0.0
    cycles_executed:            int                         = 0
    schema_version:             str                         = VALIDATION_SCHEMA_VERSION

    @property
    def passed(self) -> bool:
        return self.status == ValidationStatus.PASS

    @property
    def failed(self) -> bool:
        return self.status == ValidationStatus.FAIL

    @property
    def assertions_passed(self) -> int:
        return sum(1 for a in self.assertion_results if a.passed)

    @property
    def assertions_failed(self) -> int:
        return sum(1 for a in self.assertion_results if not a.passed)

    def __repr__(self) -> str:
        return (
            f"SafetyValidationResult("
            f"scenario={self.scenario_id!r}, "
            f"status={self.status.value}, "
            f"assertions={self.assertions_passed}/{len(self.assertion_results)})"
        )


# ---------------------------------------------------------------------------
# Validation Trace — compact per-cycle record for multi-cycle scenarios
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class ValidationTrace:
    """
    Compact per-cycle trace entry for multi-cycle scenarios.

    Bounded by design — never records raw sensor streams.

    Fields
    ------
    cycle               : Zero-based cycle index within the scenario.
    timestamp           : Data timestamp for this cycle.
    safety_state        : SafetyState string from Phase 11.1.
    emergency_state     : EmergencyState string from Phase 11.2.
    fail_safe_state     : FailSafeState string from Phase 11.4.
    control_authority   : ControlAuthority string from Phase 11.3.
    active_failures     : Tuple of active failure type strings.
    active_emergencies  : Tuple of active emergency type strings.
    dominant_reason     : Dominant override reason string.
    stale               : True if this cycle had stale safety data.
    degraded            : True if this cycle had degraded data.
    """
    cycle:             int           = 0
    timestamp:         float         = 0.0
    safety_state:      str           = "UNKNOWN"
    emergency_state:   str           = "EMERGENCY_UNKNOWN"
    fail_safe_state:   str           = "UNKNOWN_FAIL_SAFE_STATE"
    control_authority: str           = "UNKNOWN_CONTROL_AUTHORITY"
    active_failures:   Tuple[str, ...] = field(default_factory=tuple)
    active_emergencies: Tuple[str, ...] = field(default_factory=tuple)
    dominant_reason:   str           = ""
    stale:             bool          = False
    degraded:          bool          = False


# ---------------------------------------------------------------------------
# Fault Specification — test-only fault injection descriptor
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class FaultSpec:
    """
    Deterministic fault injection specification for test scenarios.

    This is ONLY used in test scenarios — it is never injected
    into the runtime autonomous system.

    Fields
    ------
    target              : FaultTarget — which component to fault.
    fault_type          : FaultType — nature of the fault.
    activation_cycle    : Cycle index at which the fault starts (0-based).
    duration_cycles     : How many cycles the fault persists (0 = permanent).
    severity            : Optional severity override string.
    parameters          : Optional dict of fault-specific parameters.
    """
    target:           FaultTarget           = FaultTarget.CAMERA
    fault_type:       FaultType             = FaultType.UNAVAILABLE
    activation_cycle: int                   = 0
    duration_cycles:  int                   = 0       # 0 = lasts for scenario duration
    severity:         str                   = "HIGH"
    parameters:       Optional[dict]        = None


# ---------------------------------------------------------------------------
# Scenario Specification — compact scenario descriptor for the runner
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class ScenarioSpec:
    """
    Compact scenario descriptor passed to SafetyScenarioRunner.

    Fields
    ------
    scenario_id             : Unique scenario identifier.
    category                : ScenarioCategory enum.
    description             : Human-readable scenario description.
    faults                  : Ordered fault injection sequence.
    cycles                  : Number of pipeline cycles to simulate.
    timestamp_start         : Starting data timestamp for the scenario.
    timestamp_step          : Per-cycle timestamp increment (seconds).
    expected_safety_state   : Expected SafetyState string (or "").
    expected_emergency_state: Expected EmergencyState string (or "").
    expected_fail_safe_state: Expected FailSafeState string (or "").
    expected_control_authority: Expected ControlAuthority string (or "").
    invariants_to_check     : Which invariant IDs to evaluate.
    severity                : Scenario severity string.
    """
    scenario_id:                str                    = ""
    category:                   str                    = ScenarioCategory.NORMAL_OPERATION.value
    description:                str                    = ""
    faults:                     Tuple[FaultSpec, ...]  = field(default_factory=tuple)
    cycles:                     int                    = 1
    timestamp_start:            float                  = 1000.0
    timestamp_step:             float                  = 0.05   # 20 Hz
    expected_safety_state:      str                    = ""
    expected_emergency_state:   str                    = ""
    expected_fail_safe_state:   str                    = ""
    expected_control_authority: str                    = ""
    invariants_to_check:        Tuple[str, ...]        = field(default_factory=tuple)
    severity:                   str                    = "MEDIUM"
