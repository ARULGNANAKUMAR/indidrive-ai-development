"""
IndiDrive AI — Phase 11.5 | Safety Validation Package
=======================================================
Safety Validation and Stress Testing layer.

Sits above Phase 11.1–11.4 and validates that the existing safety
architecture produces correct, conservative behaviour under:
  - normal operation
  - degraded operation
  - emergency conditions
  - sensor failures
  - subsystem failures
  - stale / invalid data
  - multiple simultaneous failures
  - recovery
  - boundary conditions
  - Indian-road safety scenarios
  - high-frequency stress
  - deterministic repeated execution

Public surface
--------------
SafetyValidationEngine   — Core invariant evaluation engine.
SafetyScenarioRunner     — Multi-cycle deterministic scenario executor.
SafetyValidationResult   — Immutable result container.
ValidationStatus         — PASS / FAIL / INCONCLUSIVE / … enum.
InvariantId              — Named safety invariants (A–J).
FaultSpec                — Test-only fault injection descriptor.
ScenarioSpec             — Scenario descriptor for the runner.
ValidationTrace          — Per-cycle compact trace entry.
AssertionResult          — Per-assertion result.
FaultTarget              — Fault target enum.
FaultType                — Fault type enum.
ScenarioCategory         — Scenario category enum.
VALIDATION_SCHEMA_VERSION — "11.5".
"""
from .validation_types import (
    VALIDATION_SCHEMA_VERSION,
    AssertionResult,
    FaultSpec,
    FaultTarget,
    FaultType,
    InvariantId,
    SafetyValidationResult,
    ScenarioCategory,
    ScenarioSpec,
    ValidationStatus,
    ValidationTrace,
)
from .validation_engine import SafetyValidationEngine
from .scenario_runner import SafetyScenarioRunner

__all__ = [
    "VALIDATION_SCHEMA_VERSION",
    "AssertionResult",
    "FaultSpec",
    "FaultTarget",
    "FaultType",
    "InvariantId",
    "SafetyScenarioRunner",
    "SafetyValidationEngine",
    "SafetyValidationResult",
    "ScenarioCategory",
    "ScenarioSpec",
    "ValidationStatus",
    "ValidationTrace",
]
