"""
IndiDrive AI — Phase 11.5 | Safety Scenario Runner
====================================================
Executes deterministic safety validation scenarios against the
existing Phase 11 stack (11.1 → 11.4).

Responsibilities:
  1. Build compact synthetic pipeline states from FaultSpec.
  2. Run existing Phase 11 engines in the correct order.
  3. Collect per-cycle ValidationTrace entries.
  4. Evaluate safety invariants via ValidationEngine.
  5. Return a structured SafetyValidationResult.

This module DOES NOT:
  - create another safety controller, emergency detector, or fail-safe
  - generate actuator commands
  - access real vehicle hardware or CAN/ECU
  - duplicate Phase 10.5 or any prior pipeline
"""
from __future__ import annotations

import math
import time
from typing import Dict, List, Optional, Tuple

from .validation_types import (
    VALIDATION_SCHEMA_VERSION,
    FaultSpec,
    FaultTarget,
    FaultType,
    InvariantId,
    SafetyValidationResult,
    ScenarioCategory,
    ScenarioSpec,
    ValidationStatus,
    ValidationTrace,
)
from .validation_engine import SafetyValidationEngine

# Phase 11.1
from core.safety import (
    SafetyMonitor,
    SafetyMonitorConfig,
    SafetyMonitorState,
    SafetyState,
)
# Phase 11.2
from core.safety import (
    EmergencyDetector,
    EmergencyDetectorConfig,
    EmergencyDetectionState,
    EmergencyState,
    EmergencyType,
    EmergencySeverity,
    EmergencyUrgency,
    EmergencySource,
)
from core.safety.emergency_types import EmergencyEvent, EmergencyEvidence
# Phase 11.3
from core.safety_supervisor import (
    SafetySupervisor,
    SupervisorConfig,
    SafetySupervisorDecision,
    SafetySupervisorSnapshot,
    ControlAuthority,
)
# Phase 11.4
from core.failsafe import (
    FailSafeConfig,
    FailSafeEngine,
    FailSafeDecision,
    FailSafeState,
)

# Existing input types (not modified)
from core.world_model.world_model_types import WorldModelSnapshot, WorldModelStatus
from core.planning.planner_types import PlannerOutput, PlannerStatus
from core.tracking.tracking_snapshot import TrackingSnapshot
from core.tracking.tracking_types import TrackingQuality
from core.control.mpc_snapshot import MPCSnapshot
from core.control.mpc_types import MPCStatus, ConstraintStatus
from core.control.control_snapshot import VehicleControlCommand
from core.control.control_types import ControlCommandStatus
from core.vehicle.dynamics_snapshot import DynamicsSnapshot

__all__ = ["SafetyScenarioRunner"]

_NA = "NOT_AVAILABLE"


# ---------------------------------------------------------------------------
# Synthetic state builders — build minimal valid inputs from fault specs
# ---------------------------------------------------------------------------

def _is_faulted(
    target: FaultTarget,
    fault_type: FaultType,
    faults: List[FaultSpec],
    cycle: int,
) -> bool:
    """Return True if the given target has an active fault at `cycle`."""
    for f in faults:
        if f.target != target:
            continue
        if cycle < f.activation_cycle:
            continue
        if f.duration_cycles > 0 and cycle >= f.activation_cycle + f.duration_cycles:
            continue
        return True
    return False


def _fault_for(
    target: FaultTarget,
    faults: List[FaultSpec],
    cycle: int,
) -> Optional[FaultSpec]:
    """Return the most recently activated FaultSpec for this target at `cycle`."""
    active = [
        f for f in faults
        if f.target == target
        and cycle >= f.activation_cycle
        and (f.duration_cycles == 0 or cycle < f.activation_cycle + f.duration_cycles)
    ]
    return active[-1] if active else None


def _build_world_model(ts: float, faults: List[FaultSpec], cycle: int) -> WorldModelSnapshot:
    wm_fault = _fault_for(FaultTarget.WORLD_MODEL, faults, cycle)
    if wm_fault:
        if wm_fault.fault_type in (FaultType.UNAVAILABLE, FaultType.INVALID_DATA,
                                    FaultType.CORRUPTED, FaultType.NAN_VALUE):
            return WorldModelSnapshot(
                status=WorldModelStatus.INVALID, timestamp=ts,
            )
        elif wm_fault.fault_type in (FaultType.STALE, FaultType.TIMEOUT,
                                      FaultType.INVALID_TIMESTAMP):
            # stale: use an old timestamp (age >> stale threshold)
            return WorldModelSnapshot(
                status=WorldModelStatus.PARTIAL, timestamp=ts - 10.0,
            )
        elif wm_fault.fault_type == FaultType.DEGRADED:
            return WorldModelSnapshot(
                status=WorldModelStatus.DEGRADED, timestamp=ts,
            )
    return WorldModelSnapshot(status=WorldModelStatus.OK, timestamp=ts)


def _build_planner(ts: float, faults: List[FaultSpec], cycle: int) -> PlannerOutput:
    p_fault = _fault_for(FaultTarget.PLANNING, faults, cycle)
    if p_fault:
        if p_fault.fault_type in (FaultType.UNAVAILABLE, FaultType.INVALID_DATA,
                                   FaultType.CORRUPTED, FaultType.NAN_VALUE):
            return PlannerOutput(
                timestamp=ts,
                planning_status=PlannerStatus.UNKNOWN,
                planning_allowed=False,
                safety_gate_state="CRITICAL",
                degraded=True,
                confidence=0.0,
            )
        elif p_fault.fault_type in (FaultType.STALE, FaultType.TIMEOUT,
                                     FaultType.INVALID_TIMESTAMP):
            return PlannerOutput(
                timestamp=ts - 10.0,
                planning_status=PlannerStatus.STALE_INPUT,
                planning_allowed=True,
                safety_gate_state="CLEAR",
                stale=True,
                confidence=0.5,
            )
        elif p_fault.fault_type == FaultType.DEGRADED:
            return PlannerOutput(
                timestamp=ts,
                planning_status=PlannerStatus.DEGRADED,
                planning_allowed=True,
                safety_gate_state="CAUTION",
                degraded=True,
                confidence=0.4,
            )
    return PlannerOutput(
        timestamp=ts,
        planning_status=PlannerStatus.PLAN_AVAILABLE,
        planning_allowed=True,
        safety_gate_state="CLEAR",
        degraded=False,
        stale=False,
        confidence=0.9,
        uncertainty=0.1,
    )


def _build_tracking(ts: float, faults: List[FaultSpec], cycle: int) -> TrackingSnapshot:
    t_fault = _fault_for(FaultTarget.TRACKING, faults, cycle)
    if t_fault:
        if t_fault.fault_type in (FaultType.UNAVAILABLE, FaultType.INVALID_DATA,
                                   FaultType.CORRUPTED, FaultType.NAN_VALUE):
            return TrackingSnapshot(
                snap_timestamp=ts,
                tracking_quality=TrackingQuality.REFERENCE_LOST,
                degraded=True,
                confidence=0.0,
                cross_track_error_m=99.0,
            )
        elif t_fault.fault_type in (FaultType.STALE, FaultType.TIMEOUT,
                                     FaultType.INVALID_TIMESTAMP):
            return TrackingSnapshot(
                snap_timestamp=ts - 10.0,
                tracking_quality=TrackingQuality.STALE_REFERENCE,
                degraded=True,
                confidence=0.4,
            )
        elif t_fault.fault_type == FaultType.DEGRADED:
            return TrackingSnapshot(
                snap_timestamp=ts,
                tracking_quality=TrackingQuality.DEVIATING,
                degraded=True,
                confidence=0.45,
                cross_track_error_m=1.5,
            )
    return TrackingSnapshot(
        snap_timestamp=ts,
        tracking_quality=TrackingQuality.ON_TRACK,
        degraded=False,
        confidence=0.95,
        cross_track_error_m=0.05,
    )


def _build_mpc(ts: float, faults: List[FaultSpec], cycle: int) -> MPCSnapshot:
    m_fault = _fault_for(FaultTarget.MPC, faults, cycle)
    if m_fault:
        if m_fault.fault_type in (FaultType.UNAVAILABLE, FaultType.INVALID_DATA,
                                   FaultType.CORRUPTED, FaultType.NAN_VALUE):
            return MPCSnapshot(
                snap_timestamp=ts,
                sim_timestamp=ts,
                status=MPCStatus.NO_FEASIBLE_SOLUTION,
                feasible=False,
                constraint_status=ConstraintStatus.VIOLATED,
            )
        elif m_fault.fault_type in (FaultType.STALE, FaultType.TIMEOUT,
                                     FaultType.INVALID_TIMESTAMP):
            return MPCSnapshot(
                snap_timestamp=ts - 10.0,
                sim_timestamp=ts - 10.0,
                status=MPCStatus.STALE_REFERENCE,
                feasible=True,
                constraint_status=ConstraintStatus.SATISFIED,
            )
        elif m_fault.fault_type == FaultType.DEGRADED:
            return MPCSnapshot(
                snap_timestamp=ts,
                sim_timestamp=ts,
                status=MPCStatus.DEGRADED,
                feasible=True,
                constraint_status=ConstraintStatus.SATISFIED,
            )
    return MPCSnapshot(
        snap_timestamp=ts,
        sim_timestamp=ts,
        status=MPCStatus.SUCCESS,
        feasible=True,
        constraint_status=ConstraintStatus.SATISFIED,
    )


def _build_control(ts: float, faults: List[FaultSpec], cycle: int) -> VehicleControlCommand:
    c_fault = _fault_for(FaultTarget.CONTROL, faults, cycle)
    if c_fault:
        if c_fault.fault_type in (FaultType.UNAVAILABLE, FaultType.INVALID_DATA):
            return VehicleControlCommand(
                timestamp=ts,
                status=ControlCommandStatus.INVALID,
            )
        elif c_fault.fault_type == FaultType.STALE:
            return VehicleControlCommand(
                timestamp=ts - 10.0,
                status=ControlCommandStatus.VALID,
            )
    return VehicleControlCommand(timestamp=ts, status=ControlCommandStatus.VALID)


def _build_dynamics(ts: float, faults: List[FaultSpec], cycle: int) -> DynamicsSnapshot:
    return DynamicsSnapshot(
        snapshot_timestamp=ts,
        sim_timestamp=ts,
        x=0.0, y=0.0, yaw=0.0,
        velocity=5.0,
    )


def _build_safety_monitor_state(
    ts: float,
    faults: List[FaultSpec],
    cycle: int,
    monitor: SafetyMonitor,
) -> SafetyMonitorState:
    """Build a SafetyMonitorState from synthetic inputs."""
    sm_fault = _fault_for(FaultTarget.SAFETY_MONITOR, faults, cycle)
    if sm_fault and sm_fault.fault_type == FaultType.UNAVAILABLE:
        # Return a minimal UNKNOWN state to simulate safety monitor failure.
        from core.safety.safety_types import (
            SafetyMonitorState, SafetyState,
            SAFETY_MONITOR_SCHEMA_VERSION,
        )
        return SafetyMonitorState(
            timestamp=ts,
            schema_version=SAFETY_MONITOR_SCHEMA_VERSION,
            monitor_status="UNAVAILABLE",
            overall_safety_state=SafetyState.UNKNOWN,
            confidence=0.0,
            uncertainty=1.0,
            stale=True,
            degraded=True,
            valid=False,
        )

    return monitor.assess(
        world_model_snapshot=_build_world_model(ts, faults, cycle),
        planner_output=_build_planner(ts, faults, cycle),
        tracking_snapshot=_build_tracking(ts, faults, cycle),
        mpc_snapshot=_build_mpc(ts, faults, cycle),
        control_command=_build_control(ts, faults, cycle),
        dynamics_snapshot=_build_dynamics(ts, faults, cycle),
        reference_timestamp=ts,
    )


def _build_emergency_state(
    ts: float,
    faults: List[FaultSpec],
    cycle: int,
    detector: EmergencyDetector,
    safety_monitor_state: SafetyMonitorState,
) -> EmergencyDetectionState:
    """Build an EmergencyDetectionState from synthetic inputs and existing safety monitor state."""
    em_fault = _fault_for(FaultTarget.EMERGENCY_DETECTION, faults, cycle)
    if em_fault and em_fault.fault_type == FaultType.UNAVAILABLE:
        from core.safety.emergency_types import (
            EmergencyDetectionState,
            EmergencyState,
            EMERGENCY_SCHEMA_VERSION,
        )
        return EmergencyDetectionState(
            timestamp=ts,
            schema_version=EMERGENCY_SCHEMA_VERSION,
            detector_status="UNAVAILABLE",
            emergency_state=EmergencyState.EMERGENCY_UNKNOWN,
            valid=False,
            stale=True,
            degraded=True,
        )

    # Build minimal world model for emergency detector
    wm = _build_world_model(ts, faults, cycle)
    planner = _build_planner(ts, faults, cycle)
    tracking = _build_tracking(ts, faults, cycle)
    mpc = _build_mpc(ts, faults, cycle)
    control = _build_control(ts, faults, cycle)
    dynamics = _build_dynamics(ts, faults, cycle)

    return detector.detect(
        safety_monitor_state=safety_monitor_state,
        world_model_snapshot=wm,
        planner_output=planner,
        tracking_snapshot=tracking,
        mpc_snapshot=mpc,
        control_command=control,
        dynamics_snapshot=dynamics,
        reference_timestamp=ts,
    )


def _build_failsafe_decision(
    ts: float,
    frame_id: int,
    faults: List[FaultSpec],
    cycle: int,
    fs_engine: FailSafeEngine,
    safety_monitor_state: SafetyMonitorState,
    emergency_state: EmergencyDetectionState,
) -> FailSafeDecision:
    """Build a FailSafeDecision from fault specs and existing Phase 11 state."""
    camera_fault = _fault_for(FaultTarget.CAMERA, faults, cycle)
    lidar_fault = _fault_for(FaultTarget.LIDAR, faults, cycle)
    radar_fault = _fault_for(FaultTarget.RADAR, faults, cycle)

    # Map fault types to the health state strings the failsafe engine recognises.
    # UNAVAILABLE/CORRUPTED/NAN/INVALID_DATA/STALE/TIMEOUT/INVALID_TIMESTAMP all
    # represent conditions where the sensor output cannot be trusted → OFFLINE.
    _sensor_offline_types = (
        FaultType.UNAVAILABLE, FaultType.CORRUPTED, FaultType.NAN_VALUE,
        FaultType.INVALID_DATA, FaultType.STALE, FaultType.TIMEOUT,
        FaultType.INVALID_TIMESTAMP, FaultType.SYNC_FAILURE,
    )

    camera_health = "OFFLINE"  if (camera_fault and camera_fault.fault_type in _sensor_offline_types) else \
                    "DEGRADED" if (camera_fault and camera_fault.fault_type == FaultType.LOW_CONFIDENCE) else \
                    "DEGRADED" if (camera_fault and camera_fault.fault_type == FaultType.DEGRADED) else \
                    "ONLINE"
    lidar_health  = "OFFLINE"  if (lidar_fault and lidar_fault.fault_type in _sensor_offline_types) else \
                    "DEGRADED" if (lidar_fault and lidar_fault.fault_type in (FaultType.DEGRADED, FaultType.LOW_CONFIDENCE)) else \
                    "ONLINE"
    radar_health  = "OFFLINE"  if (radar_fault and radar_fault.fault_type in _sensor_offline_types) else \
                    "DEGRADED" if (radar_fault and radar_fault.fault_type == FaultType.DEGRADED) else \
                    "ONLINE"

    camera_age = 0.05
    lidar_age  = 0.05
    radar_age  = 0.1

    camera_valid = True   # health state already encodes validity
    lidar_valid  = True

    perception_fault  = _fault_for(FaultTarget.PERCEPTION, faults, cycle)
    fusion_fault      = _fault_for(FaultTarget.FUSION, faults, cycle)
    prediction_fault  = _fault_for(FaultTarget.PREDICTION, faults, cycle)

    perception_status = "FAILED"    if perception_fault and perception_fault.fault_type == FaultType.UNAVAILABLE else \
                        "DEGRADED"  if perception_fault and perception_fault.fault_type == FaultType.DEGRADED else \
                        "OK"
    fusion_status     = "FAILED"    if fusion_fault and fusion_fault.fault_type == FaultType.UNAVAILABLE else \
                        "DEGRADED"  if fusion_fault and fusion_fault.fault_type == FaultType.DEGRADED else \
                        "OK"
    prediction_status = "FAILED"    if prediction_fault and prediction_fault.fault_type == FaultType.UNAVAILABLE else \
                        "DEGRADED"  if prediction_fault and prediction_fault.fault_type == FaultType.DEGRADED else \
                        "OK"

    # Planning / tracking / MPC / control failures
    plan_fault    = _fault_for(FaultTarget.PLANNING, faults, cycle)
    track_fault   = _fault_for(FaultTarget.TRACKING, faults, cycle)
    mpc_fault     = _fault_for(FaultTarget.MPC, faults, cycle)
    ctrl_fault    = _fault_for(FaultTarget.CONTROL, faults, cycle)

    planning_status  = "UNKNOWN"  if plan_fault and plan_fault.fault_type in (
                           FaultType.UNAVAILABLE, FaultType.INVALID_DATA,
                           FaultType.CORRUPTED, FaultType.NAN_VALUE) else \
                       "STALE_INPUT" if plan_fault and plan_fault.fault_type in (
                           FaultType.STALE, FaultType.TIMEOUT, FaultType.INVALID_TIMESTAMP) else \
                       "DEGRADED" if plan_fault and plan_fault.fault_type == FaultType.DEGRADED else None
    tracking_status  = "REFERENCE_LOST" if track_fault and track_fault.fault_type in (
                           FaultType.UNAVAILABLE, FaultType.INVALID_DATA,
                           FaultType.CORRUPTED, FaultType.NAN_VALUE) else \
                       "STALE_REFERENCE" if track_fault and track_fault.fault_type in (
                           FaultType.STALE, FaultType.TIMEOUT, FaultType.INVALID_TIMESTAMP) else \
                       "DEVIATING" if track_fault and track_fault.fault_type == FaultType.DEGRADED else None
    mpc_status_str   = "NO_FEASIBLE_SOLUTION" if mpc_fault and mpc_fault.fault_type in (
                           FaultType.UNAVAILABLE, FaultType.INVALID_DATA,
                           FaultType.CORRUPTED, FaultType.NAN_VALUE) else \
                       "STALE_REFERENCE" if mpc_fault and mpc_fault.fault_type in (
                           FaultType.STALE, FaultType.TIMEOUT, FaultType.INVALID_TIMESTAMP) else None
    control_status   = "INVALID"  if ctrl_fault and ctrl_fault.fault_type in (
                           FaultType.UNAVAILABLE, FaultType.INVALID_DATA) else None

    # Default healthy status for subsystems not explicitly faulted
    _ok = "OK"

    return fs_engine.evaluate(
        timestamp=ts,
        frame_id=frame_id,
        camera_health_state=camera_health,
        camera_frame_age_s=camera_age,
        camera_is_valid_data=camera_valid,
        lidar_health_state=lidar_health,
        lidar_frame_age_s=lidar_age,
        lidar_is_valid_data=lidar_valid,
        radar_health_state=radar_health,
        radar_frame_age_s=radar_age,
        vehicle_state_health_state="ONLINE",
        vehicle_state_frame_age_s=0.05,
        vehicle_state_confidence=0.95,
        vehicle_state_is_valid=True,
        perception_status=perception_status,
        perception_confidence=0.9 if perception_status == _ok else 0.3,
        perception_timestamp=ts,
        fusion_status=fusion_status,
        fusion_confidence=0.9 if fusion_status == _ok else 0.3,
        fusion_timestamp=ts,
        prediction_status=prediction_status,
        prediction_confidence=0.9 if prediction_status == _ok else 0.3,
        prediction_timestamp=ts,
        road_understanding_status=_ok,
        road_understanding_timestamp=ts,
        world_model_valid=(safety_monitor_state.overall_safety_state != SafetyState.UNKNOWN),
        world_model_timestamp=ts,
        world_model_confidence=safety_monitor_state.confidence,
        world_model_degraded=safety_monitor_state.degraded,
        planning_status=planning_status if planning_status else _ok,
        planning_timestamp=ts,
        planning_degraded=(plan_fault is not None and plan_fault.fault_type == FaultType.DEGRADED),
        tracking_status=tracking_status if tracking_status else _ok,
        tracking_timestamp=ts,
        tracking_degraded=(track_fault is not None and track_fault.fault_type == FaultType.DEGRADED),
        mpc_status=mpc_status_str if mpc_status_str else _ok,
        mpc_timestamp=ts,
        mpc_degraded=(mpc_fault is not None and mpc_fault.fault_type == FaultType.DEGRADED),
        control_status=control_status if control_status else "VALID",
        control_timestamp=ts,
        safety_monitor_state=safety_monitor_state.overall_safety_state.value,
        safety_monitor_timestamp=safety_monitor_state.timestamp,
        safety_monitor_confidence=safety_monitor_state.confidence,
        emergency_detection_state=emergency_state.emergency_state.value,
        emergency_detection_timestamp=emergency_state.timestamp,
        safety_supervisor_state="NORMAL_CONTROL",
        safety_supervisor_timestamp=ts,
        emergency_active=emergency_state.is_emergency,
        supervisor_permits_recovery=True,
    )


# ---------------------------------------------------------------------------
# Safety Scenario Runner
# ---------------------------------------------------------------------------

class SafetyScenarioRunner:
    """
    Executes deterministic multi-cycle safety scenarios against the
    existing Phase 11 stack, collecting traces and validation results.

    Usage
    -----
    runner = SafetyScenarioRunner()
    result, traces = runner.run(spec)
    assert result.passed
    """

    def __init__(
        self,
        safety_monitor_config: Optional[SafetyMonitorConfig] = None,
        emergency_detector_config: Optional[EmergencyDetectorConfig] = None,
        supervisor_config: Optional[SupervisorConfig] = None,
        failsafe_config: Optional[FailSafeConfig] = None,
    ) -> None:
        self._monitor = SafetyMonitor(
            safety_monitor_config or SafetyMonitorConfig.default()
        )
        self._detector = EmergencyDetector(
            emergency_detector_config or EmergencyDetectorConfig.default()
        )
        self._supervisor = SafetySupervisor(
            supervisor_config or SupervisorConfig.default()
        )
        self._fs_engine = FailSafeEngine(
            failsafe_config or FailSafeConfig()
        )
        self._engine = SafetyValidationEngine()

    def run(
        self,
        spec: ScenarioSpec,
        *,
        record_traces: bool = True,
    ) -> Tuple[SafetyValidationResult, List[ValidationTrace]]:
        """
        Execute a scenario and return (ValidationResult, traces).

        Parameters
        ----------
        spec         : ScenarioSpec describing the scenario.
        record_traces: If True, collect per-cycle trace entries.

        Returns
        -------
        (SafetyValidationResult, List[ValidationTrace])
        """
        faults = list(spec.faults)
        traces: List[ValidationTrace] = []

        # Last-cycle observed outputs (used for validation against spec expectations)
        final_safety_state   = SafetyState.UNKNOWN.value
        final_emergency_state = EmergencyState.EMERGENCY_UNKNOWN.value
        final_fs_state        = FailSafeState.UNKNOWN_FAIL_SAFE_STATE.value
        final_authority       = ControlAuthority.UNKNOWN_CONTROL_AUTHORITY.value
        final_reason_codes: Tuple[str, ...] = ()
        final_stale  = False
        final_degraded = False

        prior_supervisor_snapshot: Optional[SafetySupervisorSnapshot] = None
        start_wall = time.monotonic()

        for cycle in range(spec.cycles):
            ts = spec.timestamp_start + cycle * spec.timestamp_step
            frame_id = cycle

            # --- Run Phase 11.1 ---
            sm_state = _build_safety_monitor_state(
                ts=ts, faults=faults, cycle=cycle, monitor=self._monitor,
            )

            # --- Run Phase 11.2 ---
            em_state = _build_emergency_state(
                ts=ts, faults=faults, cycle=cycle,
                detector=self._detector,
                safety_monitor_state=sm_state,
            )

            # --- Run Phase 11.4 (fail-safe) ---
            fs_decision = _build_failsafe_decision(
                ts=ts, frame_id=frame_id, faults=faults, cycle=cycle,
                fs_engine=self._fs_engine,
                safety_monitor_state=sm_state,
                emergency_state=em_state,
            )

            # --- Run Phase 11.3 (supervisor) with fail-safe integration ---
            planner = _build_planner(ts, faults, cycle)
            tracking = _build_tracking(ts, faults, cycle)
            mpc = _build_mpc(ts, faults, cycle)
            control = _build_control(ts, faults, cycle)
            dynamics = _build_dynamics(ts, faults, cycle)

            sup_snapshot = self._supervisor.evaluate_with_failsafe(
                failsafe_decision=fs_decision,
                safety_monitor_state=sm_state,
                emergency_detection_state=em_state,
                planner_output=planner,
                tracking_snapshot=tracking,
                mpc_snapshot=mpc,
                control_command=control,
                dynamics_snapshot=dynamics,
                reference_timestamp=ts,
                prior_snapshot=prior_supervisor_snapshot,
            )
            sup_decision = sup_snapshot.decision
            prior_supervisor_snapshot = sup_snapshot

            # Collect trace
            active_failures = tuple(
                f.sensor_type.value
                for f in fs_decision.active_sensor_failures
            ) + tuple(
                sf.subsystem.value
                for sf in fs_decision.active_subsystem_failures
            )
            active_emergencies = tuple(
                e.emergency_type.value
                for e in em_state.active_events
            )

            if record_traces:
                traces.append(ValidationTrace(
                    cycle=cycle,
                    timestamp=ts,
                    safety_state=sm_state.overall_safety_state.value,
                    emergency_state=em_state.emergency_state.value,
                    fail_safe_state=fs_decision.fail_safe_state.value,
                    control_authority=sup_decision.control_authority.value,
                    active_failures=active_failures,
                    active_emergencies=active_emergencies,
                    dominant_reason=sup_decision.dominant_reason,
                    stale=sm_state.stale,
                    degraded=sm_state.degraded,
                ))

            # Update last-cycle values
            final_safety_state    = sm_state.overall_safety_state.value
            final_emergency_state = em_state.emergency_state.value
            final_fs_state        = fs_decision.fail_safe_state.value
            final_authority       = sup_decision.control_authority.value
            final_reason_codes    = sup_decision.reason_codes
            final_stale           = sm_state.stale
            final_degraded        = sm_state.degraded

        elapsed_ms = (time.monotonic() - start_wall) * 1000.0

        # Validate final cycle against spec expectations and invariants
        result = self._engine.validate(
            scenario_id=spec.scenario_id,
            category=spec.category,
            timestamp=spec.timestamp_start,
            frame_id=0,
            observed_safety_state=final_safety_state,
            observed_emergency_state=final_emergency_state,
            observed_fail_safe_state=final_fs_state,
            observed_control_authority=final_authority,
            observed_reason_codes=final_reason_codes,
            expected_safety_state=spec.expected_safety_state,
            expected_emergency_state=spec.expected_emergency_state,
            expected_fail_safe_state=spec.expected_fail_safe_state,
            expected_control_authority=spec.expected_control_authority,
            invariants_to_check=spec.invariants_to_check,
            severity=spec.severity,
            stale=final_stale,
            degraded=final_degraded,
            cycles_executed=spec.cycles,
            execution_time_ms=elapsed_ms,
        )
        return result, traces

    def run_determinism_check(
        self,
        spec: ScenarioSpec,
        runs: int = 5,
    ) -> "AssertionResult":
        """
        Run the same scenario `runs` times and verify all outputs are identical.
        Returns an AssertionResult for Invariant J (Determinism).
        """
        from .validation_types import AssertionResult, InvariantId
        results = []
        for _ in range(runs):
            result, _ = self.run(spec, record_traces=False)
            results.append(result)
        return self._engine.check_determinism(results)
