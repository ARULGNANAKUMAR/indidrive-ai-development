"""
IndiDrive AI — Phase 11.5 | Safety Validation Engine
======================================================
Core safety invariant evaluation engine.

This module VALIDATES the existing Phase 11 safety architecture.
It does NOT:
  - replace or duplicate Safety Monitor, Emergency Detector, Safety Supervisor,
    or Fail-Safe logic
  - generate actuator commands
  - access real vehicle hardware
  - create another planner or MPC
  - run runtime fault injection into the autonomous system

Architecture position:
    Safety Monitor (11.1)
    → Emergency Detector (11.2)
    → Safety Supervisor (11.3)
    → Fail-Safe (11.4)
    → Safety Validation (11.5) ← this module

Design:
  * Deterministic — same inputs → same ValidationResult.
  * No wall-clock time inside pure evaluation methods.
  * Compact results — no full World Model copies embedded.
  * Conservative: uncertainty about a result → INCONCLUSIVE, not PASS.
"""
from __future__ import annotations

import math
import time
from typing import List, Optional, Tuple

from .validation_types import (
    VALIDATION_SCHEMA_VERSION,
    AssertionResult,
    InvariantId,
    SafetyValidationResult,
    ScenarioCategory,
    ValidationStatus,
)

# Phase 11 type imports — read-only; no modification of these modules.
from core.safety.safety_types import SafetyState
from core.safety.emergency_types import EmergencyState
from core.safety_supervisor.supervisor_types import ControlAuthority
from core.failsafe.failsafe_types import FailSafeState

__all__ = ["SafetyValidationEngine"]

# Control authorities that count as "unrestricted normal".
# LIMITED_CONTROL is the architecture's degraded-sensor response — it IS a restriction,
# not unrestricted operation. Only NORMAL_CONTROL is truly unrestricted.
_NORMAL_AUTHORITIES = frozenset({
    ControlAuthority.NORMAL_CONTROL.value,
})

# Control authorities that are clearly restricted
_RESTRICTED_AUTHORITIES = frozenset({
    ControlAuthority.RESTRICTED_CONTROL.value,
    ControlAuthority.SAFETY_CONTROL_REQUIRED.value,
    ControlAuthority.OVERRIDE_REQUIRED.value,
    ControlAuthority.CONTROL_WITHHELD.value,
    ControlAuthority.DEGRADED_CONTROL.value,
    ControlAuthority.UNKNOWN_CONTROL_AUTHORITY.value,
})


def _clamp01(v: float) -> float:
    return min(1.0, max(0.0, float(v)))


def _authority_is_normal(authority_str: str) -> bool:
    """True if authority is NORMAL_CONTROL or LIMITED_CONTROL."""
    return authority_str in _NORMAL_AUTHORITIES


def _authority_is_restricted(authority_str: str) -> bool:
    """True if authority is any form of restricted/withheld."""
    return authority_str in _RESTRICTED_AUTHORITIES


# ---------------------------------------------------------------------------
# Safety Validation Engine
# ---------------------------------------------------------------------------

class SafetyValidationEngine:
    """
    Evaluates safety invariants against observed Phase 11 stack outputs.

    Usage
    -----
    engine = SafetyValidationEngine()

    # Build observed outputs from real Phase 11 engines, then:
    result = engine.validate(
        scenario_id="S01_normal_healthy",
        category=ScenarioCategory.NORMAL_OPERATION,
        observed_safety_state="SAFE",
        observed_emergency_state="NO_EMERGENCY",
        observed_fail_safe_state="NORMAL_OPERATION",
        observed_control_authority="NORMAL_CONTROL",
        observed_reason_codes=(),
        expected_safety_state="SAFE",
        expected_emergency_state="NO_EMERGENCY",
        expected_fail_safe_state="NORMAL_OPERATION",
        expected_control_authority="NORMAL_CONTROL",
        invariants_to_check=(...),
        timestamp=1000.0,
    )
    """

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def validate(
        self,
        *,
        scenario_id: str,
        category: str = ScenarioCategory.NORMAL_OPERATION.value,
        timestamp: float = 0.0,
        frame_id: int = 0,

        # Observed outputs from the real Phase 11 engines
        observed_safety_state: str = "",
        observed_emergency_state: str = "",
        observed_fail_safe_state: str = "",
        observed_control_authority: str = "",
        observed_reason_codes: Tuple[str, ...] = (),

        # Expected outputs for comparison
        expected_safety_state: str = "",
        expected_emergency_state: str = "",
        expected_fail_safe_state: str = "",
        expected_control_authority: str = "",
        expected_reason_codes: Tuple[str, ...] = (),

        # Invariant selection
        invariants_to_check: Tuple[str, ...] = (),

        # Metadata
        severity: str = "MEDIUM",
        stale: bool = False,
        degraded: bool = False,
        cycles_executed: int = 1,
        execution_time_ms: float = 0.0,
        diagnostics: str = "",
    ) -> SafetyValidationResult:
        """
        Evaluate expected vs. actual Phase 11 stack outputs and
        check applicable safety invariants.

        Returns an immutable SafetyValidationResult.
        """
        assertions: List[AssertionResult] = []
        mismatch_codes: List[str] = []

        # --- State comparisons ---
        if expected_safety_state:
            a = self._assert_eq(
                assertion_id=f"{scenario_id}:safety_state",
                invariant_id=InvariantId.INVARIANT_B_NO_NORMAL_FROM_CRITICAL_SAFETY.value,
                description="Safety state matches expectation",
                expected=expected_safety_state,
                actual=observed_safety_state,
            )
            assertions.append(a)
            if not a.passed:
                mismatch_codes.append("SAFETY_STATE_MISMATCH")

        if expected_emergency_state:
            a = self._assert_eq(
                assertion_id=f"{scenario_id}:emergency_state",
                invariant_id=InvariantId.INVARIANT_A_NO_NORMAL_ON_CRITICAL_EMERGENCY.value,
                description="Emergency state matches expectation",
                expected=expected_emergency_state,
                actual=observed_emergency_state,
            )
            assertions.append(a)
            if not a.passed:
                mismatch_codes.append("EMERGENCY_STATE_MISMATCH")

        if expected_fail_safe_state:
            a = self._assert_eq(
                assertion_id=f"{scenario_id}:fail_safe_state",
                invariant_id=InvariantId.INVARIANT_G_CONTROL_FAILURE_IS_RESTRICTED.value,
                description="Fail-safe state matches expectation",
                expected=expected_fail_safe_state,
                actual=observed_fail_safe_state,
            )
            assertions.append(a)
            if not a.passed:
                mismatch_codes.append("FAILSAFE_STATE_MISMATCH")

        if expected_control_authority:
            a = self._assert_eq(
                assertion_id=f"{scenario_id}:control_authority",
                invariant_id=InvariantId.INVARIANT_A_NO_NORMAL_ON_CRITICAL_EMERGENCY.value,
                description="Control authority matches expectation",
                expected=expected_control_authority,
                actual=observed_control_authority,
            )
            assertions.append(a)
            if not a.passed:
                mismatch_codes.append("CONTROL_AUTHORITY_MISMATCH")

        # --- Invariant checks ---
        for inv_id in invariants_to_check:
            inv_assertions = self._check_invariant(
                inv_id=inv_id,
                scenario_id=scenario_id,
                observed_safety_state=observed_safety_state,
                observed_emergency_state=observed_emergency_state,
                observed_fail_safe_state=observed_fail_safe_state,
                observed_control_authority=observed_control_authority,
                observed_reason_codes=observed_reason_codes,
                stale=stale,
                degraded=degraded,
            )
            assertions.extend(inv_assertions)
            for a in inv_assertions:
                if not a.passed:
                    mismatch_codes.append(f"INV_{inv_id}_VIOLATED")

        # --- Snapshot cross-consistency ---
        snap_assertions = self._check_snapshot_consistency(
            scenario_id=scenario_id,
            observed_safety_state=observed_safety_state,
            observed_emergency_state=observed_emergency_state,
            observed_fail_safe_state=observed_fail_safe_state,
            observed_control_authority=observed_control_authority,
            stale=stale,
        )
        assertions.extend(snap_assertions)
        for a in snap_assertions:
            if not a.passed:
                mismatch_codes.append("SNAPSHOT_INCONSISTENT")

        # --- Derive status ---
        status = self._derive_status(assertions, degraded=degraded, stale=stale)

        diag_parts = []
        if diagnostics:
            diag_parts.append(diagnostics)
        failed = [a for a in assertions if not a.passed]
        if failed:
            diag_parts.append(
                f"{len(failed)} assertion(s) failed: "
                + "; ".join(f.mismatch or f.description for f in failed[:5])
            )

        return SafetyValidationResult(
            validation_id=f"VAL:{scenario_id}:{timestamp:.3f}",
            scenario_id=scenario_id,
            scenario_category=category,
            timestamp=timestamp,
            frame_id=frame_id,
            status=status,
            expected_safety_state=expected_safety_state,
            actual_safety_state=observed_safety_state,
            expected_emergency_state=expected_emergency_state,
            actual_emergency_state=observed_emergency_state,
            expected_fail_safe_state=expected_fail_safe_state,
            actual_fail_safe_state=observed_fail_safe_state,
            expected_control_authority=expected_control_authority,
            actual_control_authority=observed_control_authority,
            expected_reason_codes=expected_reason_codes,
            actual_reason_codes=observed_reason_codes,
            assertion_results=tuple(assertions),
            mismatch_codes=tuple(dict.fromkeys(mismatch_codes)),
            diagnostics=" | ".join(diag_parts),
            severity=severity,
            confidence=1.0 if status == ValidationStatus.PASS else 0.7,
            uncertainty=0.0 if status == ValidationStatus.PASS else 0.3,
            stale=stale,
            degraded=degraded,
            execution_time_ms=execution_time_ms,
            cycles_executed=cycles_executed,
            schema_version=VALIDATION_SCHEMA_VERSION,
        )

    # ------------------------------------------------------------------
    # Invariant checkers
    # ------------------------------------------------------------------

    def _check_invariant(
        self,
        inv_id: str,
        scenario_id: str,
        observed_safety_state: str,
        observed_emergency_state: str,
        observed_fail_safe_state: str,
        observed_control_authority: str,
        observed_reason_codes: Tuple[str, ...],
        stale: bool,
        degraded: bool,
    ) -> List[AssertionResult]:
        """Dispatch to the appropriate invariant check."""
        dispatch = {
            InvariantId.INVARIANT_A_NO_NORMAL_ON_CRITICAL_EMERGENCY.value:
                self._inv_a,
            InvariantId.INVARIANT_B_NO_NORMAL_FROM_CRITICAL_SAFETY.value:
                self._inv_b,
            InvariantId.INVARIANT_C_STALE_IS_NOT_FRESH.value:
                self._inv_c,
            InvariantId.INVARIANT_D_INVALID_IS_NOT_TRUSTED.value:
                self._inv_d,
            InvariantId.INVARIANT_G_CONTROL_FAILURE_IS_RESTRICTED.value:
                self._inv_g,
            InvariantId.INVARIANT_J_DETERMINISM.value:
                lambda **kw: [],   # determinism checked by scenario runner
        }
        handler = dispatch.get(inv_id)
        if handler is None:
            return []
        return handler(
            scenario_id=scenario_id,
            observed_safety_state=observed_safety_state,
            observed_emergency_state=observed_emergency_state,
            observed_fail_safe_state=observed_fail_safe_state,
            observed_control_authority=observed_control_authority,
            observed_reason_codes=observed_reason_codes,
            stale=stale,
            degraded=degraded,
        )

    def _inv_a(self, *, scenario_id, observed_emergency_state,
               observed_control_authority, **_kw) -> List[AssertionResult]:
        """
        Invariant A: Critical emergency cannot grant normal/limited control.
        """
        is_critical_emergency = (
            observed_emergency_state == EmergencyState.CRITICAL_EMERGENCY.value
        )
        if not is_critical_emergency:
            return []

        is_normal_authority = _authority_is_normal(observed_control_authority)
        return [self._assert_false(
            assertion_id=f"{scenario_id}:inv_a",
            invariant_id=InvariantId.INVARIANT_A_NO_NORMAL_ON_CRITICAL_EMERGENCY.value,
            description="Critical emergency must not grant normal/limited control",
            condition=is_normal_authority,
            mismatch=(
                f"CRITICAL_EMERGENCY present but control_authority="
                f"{observed_control_authority!r} grants unrestricted control"
            ) if is_normal_authority else "",
        )]

    def _inv_b(self, *, scenario_id, observed_safety_state,
               observed_control_authority, **_kw) -> List[AssertionResult]:
        """
        Invariant B: Critical safety state cannot grant normal/limited control.
        """
        is_critical_safety = (
            observed_safety_state == SafetyState.CRITICAL.value
        )
        if not is_critical_safety:
            return []

        is_normal_authority = _authority_is_normal(observed_control_authority)
        return [self._assert_false(
            assertion_id=f"{scenario_id}:inv_b",
            invariant_id=InvariantId.INVARIANT_B_NO_NORMAL_FROM_CRITICAL_SAFETY.value,
            description="Critical safety state must not grant normal/limited control",
            condition=is_normal_authority,
            mismatch=(
                f"CRITICAL safety state but control_authority="
                f"{observed_control_authority!r} grants unrestricted control"
            ) if is_normal_authority else "",
        )]

    def _inv_c(self, *, scenario_id, observed_safety_state,
               observed_control_authority, stale, **_kw) -> List[AssertionResult]:
        """
        Invariant C: Stale safety-critical data cannot produce a trusted normal state.
        When stale=True the system must not claim SAFE + NORMAL_CONTROL.
        """
        if not stale:
            return []
        is_safe_state = observed_safety_state in (SafetyState.SAFE.value,)
        is_normal = _authority_is_normal(observed_control_authority)
        both_claim_normal = is_safe_state and is_normal
        return [self._assert_false(
            assertion_id=f"{scenario_id}:inv_c",
            invariant_id=InvariantId.INVARIANT_C_STALE_IS_NOT_FRESH.value,
            description=(
                "Stale safety data must not produce SAFE+NORMAL_CONTROL"
            ),
            condition=both_claim_normal,
            mismatch=(
                f"Stale data produced safety_state={observed_safety_state!r}, "
                f"control_authority={observed_control_authority!r}"
            ) if both_claim_normal else "",
        )]

    def _inv_d(self, *, scenario_id, observed_safety_state,
               observed_control_authority, **_kw) -> List[AssertionResult]:
        """
        Invariant D: Invalid input cannot produce a trusted SAFE + NORMAL_CONTROL.
        We check that the safety state is not SAFE when degraded/invalid is indicated
        via the safety state itself being UNKNOWN or DEGRADED.
        (NaN/infinity validation is done by the scenario runner before calling engines.)
        The engine should return UNKNOWN or DEGRADED, not SAFE.
        """
        # In an invalid-input scenario, safety state SAFE means the engine
        # silently treated invalid data as healthy — that is a FAIL.
        # This invariant is invoked explicitly by invalid-input scenarios.
        is_clean = (
            observed_safety_state == SafetyState.SAFE.value
            and _authority_is_normal(observed_control_authority)
        )
        return [self._assert_false(
            assertion_id=f"{scenario_id}:inv_d",
            invariant_id=InvariantId.INVARIANT_D_INVALID_IS_NOT_TRUSTED.value,
            description=(
                "Invalid safety-critical input must not produce SAFE + NORMAL_CONTROL"
            ),
            condition=is_clean,
            mismatch=(
                f"Invalid input produced safety_state={observed_safety_state!r}, "
                f"control_authority={observed_control_authority!r} — "
                f"system should not reach SAFE+NORMAL from invalid data"
            ) if is_clean else "",
        )]

    def _inv_g(self, *, scenario_id, observed_fail_safe_state,
               observed_control_authority, **_kw) -> List[AssertionResult]:
        """
        Invariant G: CONTROL_WITHHELD / FAIL_SAFE_ACTIVE fail-safe state
        cannot produce unrestricted normal control.
        """
        is_fail_safe_critical = observed_fail_safe_state in (
            FailSafeState.CONTROL_WITHHELD.value,
            FailSafeState.FAIL_SAFE_ACTIVE.value,
        )
        if not is_fail_safe_critical:
            return []
        is_normal = _authority_is_normal(observed_control_authority)
        return [self._assert_false(
            assertion_id=f"{scenario_id}:inv_g",
            invariant_id=InvariantId.INVARIANT_G_CONTROL_FAILURE_IS_RESTRICTED.value,
            description=(
                "CONTROL_WITHHELD/FAIL_SAFE_ACTIVE must not grant normal control"
            ),
            condition=is_normal,
            mismatch=(
                f"fail_safe_state={observed_fail_safe_state!r} but "
                f"control_authority={observed_control_authority!r} grants unrestricted control"
            ) if is_normal else "",
        )]

    # ------------------------------------------------------------------
    # Snapshot consistency
    # ------------------------------------------------------------------

    def _check_snapshot_consistency(
        self,
        scenario_id: str,
        observed_safety_state: str,
        observed_emergency_state: str,
        observed_fail_safe_state: str,
        observed_control_authority: str,
        stale: bool,
    ) -> List[AssertionResult]:
        """
        Verify cross-field consistency of observed outputs.
        These are structural checks that do not depend on scenario expectations.
        """
        results = []

        # If control is withheld by fail-safe, authority should not be normal.
        if observed_fail_safe_state == FailSafeState.CONTROL_WITHHELD.value:
            is_normal = _authority_is_normal(observed_control_authority)
            results.append(self._assert_false(
                assertion_id=f"{scenario_id}:snap_failsafe_vs_authority",
                invariant_id=InvariantId.INVARIANT_G_CONTROL_FAILURE_IS_RESTRICTED.value,
                description=(
                    "CONTROL_WITHHELD fail-safe state inconsistent with "
                    "normal control authority"
                ),
                condition=is_normal,
                mismatch=(
                    f"fail_safe_state=CONTROL_WITHHELD but "
                    f"control_authority={observed_control_authority!r}"
                ) if is_normal else "",
            ))

        # If emergency is critical, safety state should not be SAFE.
        if observed_emergency_state == EmergencyState.CRITICAL_EMERGENCY.value:
            is_safe = (observed_safety_state == SafetyState.SAFE.value)
            results.append(self._assert_false(
                assertion_id=f"{scenario_id}:snap_critical_emergency_vs_safe",
                invariant_id=InvariantId.INVARIANT_A_NO_NORMAL_ON_CRITICAL_EMERGENCY.value,
                description=(
                    "CRITICAL_EMERGENCY inconsistent with SAFE safety state"
                ),
                condition=is_safe,
                mismatch=(
                    "emergency=CRITICAL_EMERGENCY but safety_state=SAFE — "
                    "critical emergency should elevate safety state"
                ) if is_safe else "",
            ))

        # If stale, safety state must not be SAFE with NORMAL_CONTROL.
        if stale:
            is_safe_normal = (
                observed_safety_state == SafetyState.SAFE.value
                and _authority_is_normal(observed_control_authority)
            )
            results.append(self._assert_false(
                assertion_id=f"{scenario_id}:snap_stale_vs_safe_normal",
                invariant_id=InvariantId.INVARIANT_C_STALE_IS_NOT_FRESH.value,
                description="Stale data must not produce SAFE+NORMAL_CONTROL",
                condition=is_safe_normal,
                mismatch=(
                    f"stale=True but safety_state={observed_safety_state!r}, "
                    f"control_authority={observed_control_authority!r}"
                ) if is_safe_normal else "",
            ))

        return results

    # ------------------------------------------------------------------
    # Assert helpers (pure)
    # ------------------------------------------------------------------

    @staticmethod
    def _assert_eq(
        assertion_id: str,
        invariant_id: str,
        description: str,
        expected: str,
        actual: str,
    ) -> AssertionResult:
        passed = expected == actual
        return AssertionResult(
            assertion_id=assertion_id,
            invariant_id=invariant_id,
            description=description,
            passed=passed,
            expected=expected,
            actual=actual,
            mismatch=(
                f"Expected {expected!r} but got {actual!r}"
            ) if not passed else "",
        )

    @staticmethod
    def _assert_false(
        assertion_id: str,
        invariant_id: str,
        description: str,
        condition: bool,
        mismatch: str = "",
    ) -> AssertionResult:
        """Assert that `condition` is False (i.e., the bad thing did NOT happen)."""
        return AssertionResult(
            assertion_id=assertion_id,
            invariant_id=invariant_id,
            description=description,
            passed=not condition,
            expected="condition=False (invariant must not be violated)",
            actual=f"condition={condition}",
            mismatch=mismatch if condition else "",
        )

    # ------------------------------------------------------------------
    # Status derivation
    # ------------------------------------------------------------------

    @staticmethod
    def _derive_status(
        assertions: List[AssertionResult],
        degraded: bool,
        stale: bool,
    ) -> ValidationStatus:
        if not assertions:
            return ValidationStatus.INCONCLUSIVE
        any_failed = any(not a.passed for a in assertions)
        if any_failed:
            return ValidationStatus.FAIL
        if degraded:
            return ValidationStatus.DEGRADED
        return ValidationStatus.PASS

    # ------------------------------------------------------------------
    # Determinism check helper
    # ------------------------------------------------------------------

    def check_determinism(
        self,
        results: List[SafetyValidationResult],
    ) -> AssertionResult:
        """
        Verify that a list of results (same scenario run multiple times)
        are all identical in key fields.
        """
        if len(results) < 2:
            return AssertionResult(
                assertion_id="determinism:insufficient_runs",
                invariant_id=InvariantId.INVARIANT_J_DETERMINISM.value,
                description="Determinism check needs ≥2 runs",
                passed=False,
                expected="≥2 runs",
                actual=str(len(results)),
                mismatch="Insufficient runs for determinism check",
            )

        ref = results[0]
        mismatches = []
        for i, r in enumerate(results[1:], 1):
            if r.actual_safety_state != ref.actual_safety_state:
                mismatches.append(
                    f"run {i}: safety_state {ref.actual_safety_state!r} "
                    f"→ {r.actual_safety_state!r}"
                )
            if r.actual_emergency_state != ref.actual_emergency_state:
                mismatches.append(
                    f"run {i}: emergency_state {ref.actual_emergency_state!r} "
                    f"→ {r.actual_emergency_state!r}"
                )
            if r.actual_control_authority != ref.actual_control_authority:
                mismatches.append(
                    f"run {i}: control_authority {ref.actual_control_authority!r} "
                    f"→ {r.actual_control_authority!r}"
                )
            if r.actual_fail_safe_state != ref.actual_fail_safe_state:
                mismatches.append(
                    f"run {i}: fail_safe_state {ref.actual_fail_safe_state!r} "
                    f"→ {r.actual_fail_safe_state!r}"
                )

        passed = len(mismatches) == 0
        return AssertionResult(
            assertion_id="determinism:multi_run",
            invariant_id=InvariantId.INVARIANT_J_DETERMINISM.value,
            description=(
                f"Same scenario run {len(results)} times produces identical outputs"
            ),
            passed=passed,
            expected="all runs identical",
            actual="identical" if passed else f"{len(mismatches)} mismatch(es)",
            mismatch="; ".join(mismatches) if mismatches else "",
        )
