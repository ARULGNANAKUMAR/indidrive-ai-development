"""
IndiDrive AI — Phase 10.3 | MPC Lightweight Deterministic Solver
================================================================
A deterministic, bounded grid-search MPC solver.

Solver strategy (GRID_SEARCH)
------------------------------
1. Build a candidate set of (steering, acceleration) pairs by sampling
   a uniform grid over the feasible control range.
2. For each candidate pair, apply it UNIFORMLY across the prediction horizon
   (constant control assumption) and evaluate cost + constraints.
3. Keep the lowest-cost feasible candidate.
4. Optionally refine around the best candidate with a second, finer grid
   (up to max_iterations rounds).

This is NOT:
    * a gradient-based optimizer
    * a quadratic program (QP) solver
    * CasADi / IPOPT
    * a learned / neural-network controller
    * a random-sampling (stochastic) method

Determinism guarantee
---------------------
* No random numbers.
* Candidate ordering is fully determined by the grid parameters.
* Tie-breaking always selects the candidate with the lower grid index
  (lexicographic on steering then acceleration sample).
* Same config + state + reference → same solution, always.

Computational bound
-------------------
    candidates per iteration = steering_samples × acceleration_samples
    total candidates ≤ max_iterations × steering_samples × acceleration_samples

For defaults (7 steering × 5 accel × 5 iter = 175 evaluations):
    each evaluation runs a horizon of 10 bicycle-model steps
    → 1750 state propagations maximum

Performance
-----------
No latency claims are made here.  The benchmark in tests/control103/
reports actual measured time.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import List, Optional, Tuple

from .mpc_config import MPCConfig
from .mpc_constraints import ConstraintCheckResult, MPCConstraintChecker
from .mpc_cost import CostResult, MPCCostCalculator
from .mpc_prediction import MPCControlInput, MPCPredictor, PredictionResult
from .mpc_types import ConstraintStatus, MPCStatus
from ..tracking.reference_trajectory import ReferenceTrajectory
from ..vehicle.vehicle_parameters import VehicleParameters
from ..vehicle.vehicle_state import VehicleState


# ---------------------------------------------------------------------------
# Solver candidate
# ---------------------------------------------------------------------------

@dataclass
class SolverCandidate:
    """
    One evaluated candidate (constant control over horizon).

    Fields
    ------
    steering      : Constant steering angle (rad) for this candidate.
    acceleration  : Constant acceleration (m/s²) for this candidate.
    prediction    : PredictionResult from the bicycle model.
    cost_result   : CostResult from the cost function.
    constraint_ok : ConstraintCheckResult.
    feasible      : True iff prediction valid AND constraints satisfied.
    """
    steering:      float
    acceleration:  float
    prediction:    PredictionResult
    cost_result:   CostResult
    constraint_ok: ConstraintCheckResult
    feasible:      bool


# ---------------------------------------------------------------------------
# Solver result
# ---------------------------------------------------------------------------

@dataclass
class SolverResult:
    """
    Final result of one MPC solve cycle.

    Fields
    ------
    status           : MPCStatus (SUCCESS, NO_FEASIBLE_SOLUTION, etc.)
    feasible         : True iff status == SUCCESS.
    best_steering    : Optimal steering angle (rad); 0.0 if infeasible.
    best_acceleration: Optimal acceleration (m/s²); 0.0 if infeasible.
    best_prediction  : PredictionResult for the optimal candidate; None if infeasible.
    best_cost        : CostResult; None if infeasible.
    iterations       : Number of refinement iterations performed.
    candidates_evaluated: Total number of candidates evaluated.
    message          : Diagnostic message.
    """
    status:               MPCStatus
    feasible:             bool
    best_steering:        float = 0.0
    best_acceleration:    float = 0.0
    best_prediction:      Optional[PredictionResult] = None
    best_cost:            Optional[CostResult]        = None
    iterations:           int = 0
    candidates_evaluated: int = 0
    message:              str = ""


# ---------------------------------------------------------------------------
# Grid-search solver
# ---------------------------------------------------------------------------

class MPCSolver:
    """
    Deterministic lightweight MPC solver.

    Usage
    -----
    >>> solver = MPCSolver(config, vehicle_params)
    >>> result = solver.solve(
    ...     ego_state        = state,
    ...     reference        = reference_traj,
    ...     prev_steering    = 0.0,
    ...     prev_acceleration= 0.0,
    ... )

    The solver is stateless; multiple calls with the same inputs produce
    the same output.
    """

    def __init__(
        self,
        config:         MPCConfig,
        vehicle_params: Optional[VehicleParameters] = None,
    ) -> None:
        self._cfg        = config
        self._predictor  = MPCPredictor(params=vehicle_params)
        self._cost_calc  = MPCCostCalculator(config)
        self._constraint = MPCConstraintChecker(config)

    @property
    def config(self) -> MPCConfig:
        return self._cfg

    # ------------------------------------------------------------------ #
    # Public solve API
    # ------------------------------------------------------------------ #

    def solve(
        self,
        ego_state:         VehicleState,
        reference:         ReferenceTrajectory,
        prev_steering:     float = 0.0,
        prev_acceleration: float = 0.0,
    ) -> SolverResult:
        """
        Run one MPC solve cycle.

        Parameters
        ----------
        ego_state         : Current vehicle state (Phase 10.1).
        reference         : Reference trajectory (Phase 10.2).
        prev_steering     : Previous steering angle (rad).
        prev_acceleration : Previous acceleration (m/s²).

        Returns
        -------
        SolverResult with the lowest-cost feasible constant-control candidate.

        Receding-horizon usage
        ----------------------
        The solver returns the complete optimal prediction.  The caller
        (Phase 10.4 / 10.5) should extract result.best_steering and
        result.best_acceleration as the first control input for the
        current cycle, and re-solve at the next timestep.
        """
        cfg = self._cfg

        # --- Validate inputs ---
        try:
            ego_state.validate()
        except (ValueError, TypeError) as e:
            return SolverResult(
                status=MPCStatus.INVALID_INPUT,
                feasible=False,
                message=f"Invalid ego_state: {e}",
            )

        if reference is None or reference.is_empty:
            return SolverResult(
                status=MPCStatus.INVALID_REFERENCE,
                feasible=False,
                message="Reference trajectory is None or empty",
            )

        if reference.length == 1:
            # Single-point trajectory: can compute cost but tracking is degenerate.
            # Proceed with a warning — solver will still return a result.
            pass

        if not math.isfinite(prev_steering) or not math.isfinite(prev_acceleration):
            return SolverResult(
                status=MPCStatus.INVALID_INPUT,
                feasible=False,
                message=(
                    f"Non-finite previous controls: "
                    f"δ={prev_steering}, a={prev_acceleration}"
                ),
            )

        # --- Build initial candidate grid ---
        best_candidate: Optional[SolverCandidate] = None
        best_cost: float = math.inf
        total_candidates: int = 0
        iterations: int = 0

        # Steering range for initial grid
        steer_min = cfg.min_steering_rad
        steer_max = cfg.max_steering_rad
        accel_min = cfg.min_acceleration_mps2
        accel_max = cfg.max_acceleration_mps2

        reached_limit = False

        for iteration in range(cfg.max_iterations):
            iterations = iteration + 1

            grid_candidates = self._build_grid(
                steer_min, steer_max,
                accel_min, accel_max,
                cfg.steering_samples,
                cfg.acceleration_samples,
                prev_steering,  # rate constraint anchored to prev
            )

            for s_cand, a_cand in grid_candidates:
                total_candidates += 1

                candidate = self._evaluate_candidate(
                    s_cand, a_cand,
                    ego_state, reference,
                    prev_steering, prev_acceleration,
                )

                if candidate.feasible and candidate.cost_result.total_cost < best_cost:
                    best_cost = candidate.cost_result.total_cost
                    best_candidate = candidate

            # --- Refine around best candidate ---
            if best_candidate is not None:
                # Narrow the grid around the best-found candidate
                steer_range  = (steer_max - steer_min) / cfg.steering_samples
                accel_range  = (accel_max - accel_min) / cfg.acceleration_samples

                steer_min = max(cfg.min_steering_rad,
                                best_candidate.steering - steer_range)
                steer_max = min(cfg.max_steering_rad,
                                best_candidate.steering + steer_range)
                accel_min = max(cfg.min_acceleration_mps2,
                                best_candidate.acceleration - accel_range)
                accel_max = min(cfg.max_acceleration_mps2,
                                best_candidate.acceleration + accel_range)

                # Avoid degenerate range
                if steer_max - steer_min < 1e-6 and accel_max - accel_min < 1e-6:
                    break
            else:
                # No feasible candidate found yet — keep full range
                pass

        # --- Check iteration limit ---
        if iterations >= cfg.max_iterations and best_candidate is None:
            reached_limit = True

        # --- Compose result ---
        if best_candidate is None:
            status = (
                MPCStatus.SOLVER_LIMIT_REACHED if reached_limit
                else MPCStatus.NO_FEASIBLE_SOLUTION
            )
            return SolverResult(
                status=status,
                feasible=False,
                iterations=iterations,
                candidates_evaluated=total_candidates,
                message=(
                    "No feasible candidate found after "
                    f"{iterations} iterations, {total_candidates} candidates."
                ),
            )

        return SolverResult(
            status=MPCStatus.SUCCESS,
            feasible=True,
            best_steering=best_candidate.steering,
            best_acceleration=best_candidate.acceleration,
            best_prediction=best_candidate.prediction,
            best_cost=best_candidate.cost_result,
            iterations=iterations,
            candidates_evaluated=total_candidates,
            message=(
                f"Solution found: δ={math.degrees(best_candidate.steering):.2f}°, "
                f"a={best_candidate.acceleration:.3f} m/s², "
                f"cost={best_candidate.cost_result.total_cost:.4f}"
            ),
        )

    # ------------------------------------------------------------------ #
    # Internal helpers
    # ------------------------------------------------------------------ #

    def _build_grid(
        self,
        steer_min:     float,
        steer_max:     float,
        accel_min:     float,
        accel_max:     float,
        steer_samples: int,
        accel_samples: int,
        prev_steering: float,
    ) -> List[Tuple[float, float]]:
        """
        Build an ordered grid of (steering, acceleration) candidate pairs.

        Ordering: steering samples outer loop, acceleration samples inner.
        This is deterministic and consistent across all calls.

        Steering values are additionally filtered against the rate constraint
        so infeasible candidates are not generated.
        """
        cfg = self._cfg

        steer_values = _linspace(steer_min, steer_max, steer_samples)
        accel_values = _linspace(accel_min, accel_max, accel_samples)

        # Filter steering by rate constraint
        rate_limit = cfg.max_steering_rate_rad_s
        max_steer_change = rate_limit * cfg.dt
        steer_values = [
            s for s in steer_values
            if abs(s - prev_steering) <= max_steer_change + 1e-9
        ]

        # If all steering values are rate-constrained out, fall back to
        # the closest feasible values to zero (avoids empty candidate set)
        if not steer_values:
            clipped = max(cfg.min_steering_rad,
                          min(cfg.max_steering_rad,
                              prev_steering))
            steer_values = [clipped]

        candidates: List[Tuple[float, float]] = []
        for s in steer_values:
            for a in accel_values:
                candidates.append((s, a))

        return candidates

    def _evaluate_candidate(
        self,
        steering:          float,
        acceleration:      float,
        ego_state:         VehicleState,
        reference:         ReferenceTrajectory,
        prev_steering:     float,
        prev_acceleration: float,
    ) -> SolverCandidate:
        """
        Evaluate one constant-control candidate over the full horizon.

        Returns a SolverCandidate with prediction, cost, and constraint result.
        """
        cfg = self._cfg

        # Predict
        prediction = self._predictor.predict_constant(
            initial_state=ego_state,
            steering=steering,
            acceleration=acceleration,
            horizon=cfg.prediction_horizon,
            dt=cfg.dt,
        )

        # Check constraints
        constraint_result = self._constraint.check(
            prediction,
            prev_steering=prev_steering,
        )

        # Compute cost only if prediction is valid
        if prediction.valid and constraint_result.feasible:
            cost_result = self._cost_calc.compute(
                prediction,
                reference,
                prev_steering=prev_steering,
                prev_acceleration=prev_acceleration,
            )
            feasible = cost_result.valid
        else:
            cost_result = CostResult(
                total_cost=math.inf,
                valid=False,
                error_message=(
                    f"Prediction invalid={not prediction.valid}, "
                    f"constraints={constraint_result.status}"
                ),
            )
            feasible = False

        return SolverCandidate(
            steering=steering,
            acceleration=acceleration,
            prediction=prediction,
            cost_result=cost_result,
            constraint_ok=constraint_result,
            feasible=feasible,
        )


# ---------------------------------------------------------------------------
# Numeric helper
# ---------------------------------------------------------------------------

def _linspace(start: float, stop: float, n: int) -> List[float]:
    """
    Return n evenly spaced values from start to stop (inclusive).

    n must be ≥ 1.  If n == 1, returns [start].
    Deterministic: no floating-point path dependence.
    """
    if n <= 1:
        return [start]
    step = (stop - start) / (n - 1)
    return [start + i * step for i in range(n)]
