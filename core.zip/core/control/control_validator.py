"""
IndiDrive AI — Phase 10.4 | Control Validator
===============================================
Validates VehicleControlCommand fields and MPC snapshot inputs.

Responsibilities
----------------
1. Validate MPC snapshot before passing to the control pipeline:
   - feasibility
   - freshness (stale timeout)
   - finite first_steering_input / first_acceleration_input
   - non-empty control sequence
2. Validate a completed VehicleControlCommand:
   - finite numeric fields
   - bounds against configured limits
   - command consistency (no simultaneous strong accel + brake)
   - timestamp validity
   - frame_id validity

This module does NOT:
    * Generate control commands.
    * Modify any snapshot or command.
    * Run a controller of any kind.

Determinism:
    Same (command, config, current_time) → same result.
"""
from __future__ import annotations

import math
import time
from dataclasses import dataclass
from typing import Optional, List, Tuple

from .control_config import ControlConfig
from .control_types import (
    CONTROL_SCHEMA_VERSION,
    ControlCommandStatus,
    LongitudinalStatus,
    MPCFreshness,
    SteeringStatus,
)
from .mpc_types import MPCStatus
from .mpc_snapshot import MPCSnapshot


# ---------------------------------------------------------------------------
# Validation result types
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class MPCInputValidationResult:
    """
    Result of validating a Phase 10.3 MPCSnapshot before command generation.

    Attributes
    ----------
    valid       : True iff the snapshot is usable.
    freshness   : MPCFreshness classification.
    issues      : Tuple of human-readable issue strings.
    """
    valid:     bool
    freshness: MPCFreshness
    issues:    Tuple[str, ...]

    @property
    def is_fresh(self) -> bool:
        return self.freshness == MPCFreshness.FRESH

    def __repr__(self) -> str:
        return (
            f"MPCInputValidationResult(valid={self.valid}, "
            f"freshness={self.freshness.value}, "
            f"issues={self.issues})"
        )


@dataclass(frozen=True)
class CommandValidationResult:
    """
    Result of validating a completed VehicleControlCommand.

    Attributes
    ----------
    valid  : True iff all checks passed.
    issues : Tuple of human-readable issue strings.
    """
    valid:  bool
    issues: Tuple[str, ...]

    def __repr__(self) -> str:
        return (
            f"CommandValidationResult(valid={self.valid}, "
            f"issues={self.issues})"
        )


# ---------------------------------------------------------------------------
# Validator class
# ---------------------------------------------------------------------------


class ControlValidator:
    """
    Validates MPC snapshots and VehicleControlCommands.

    Stateless — same inputs always produce same output.

    Usage
    -----
    ::

        validator = ControlValidator(config)

        # Before generating command:
        mpc_result = validator.validate_mpc_snapshot(snapshot, current_time)
        if not mpc_result.valid:
            return VehicleControlCommand.invalid(...)

        # After generating command:
        cmd_result = validator.validate_command(command)
    """

    def __init__(self, config: ControlConfig) -> None:
        if not isinstance(config, ControlConfig):
            raise TypeError(
                f"ControlValidator requires ControlConfig, got {type(config)}"
            )
        self._cfg = config

    # ------------------------------------------------------------------
    # MPC snapshot validation
    # ------------------------------------------------------------------

    def validate_mpc_snapshot(
        self,
        snapshot:     Optional[MPCSnapshot],
        current_time: float,
    ) -> MPCInputValidationResult:
        """
        Validate a Phase 10.3 MPCSnapshot before use in command generation.

        Checks (in order):
        1. Snapshot is not None.
        2. Snapshot status is SUCCESS or DEGRADED (usable statuses).
        3. Snapshot is feasible.
        4. Snapshot timestamp is finite.
        5. Snapshot is not stale (age ≤ stale_timeout_s).
        6. first_steering_input is finite.
        7. first_acceleration_input is finite.
        8. control_sequence is non-empty (has at least one control step).

        Parameters
        ----------
        snapshot     : Phase 10.3 MPCSnapshot (may be None).
        current_time : Current wall-clock time (time.monotonic()).

        Returns
        -------
        MPCInputValidationResult
        """
        issues: List[str] = []
        freshness = MPCFreshness.UNKNOWN

        # Check 1: not None
        if snapshot is None:
            return MPCInputValidationResult(
                valid     = False,
                freshness = MPCFreshness.UNKNOWN,
                issues    = ("MPC snapshot is None — no solution available.",),
            )

        # Check 2: usable status
        usable_statuses = {MPCStatus.SUCCESS, MPCStatus.DEGRADED, MPCStatus.SOLVER_LIMIT_REACHED}
        if snapshot.status not in usable_statuses:
            issues.append(
                f"MPC status is not usable: {snapshot.status.value}"
            )

        # Check 3: feasibility
        if not snapshot.feasible:
            issues.append("MPC snapshot is not feasible.")

        # Check 4: timestamp finite
        if not math.isfinite(snapshot.snap_timestamp):
            issues.append(
                f"MPC snap_timestamp is non-finite: {snapshot.snap_timestamp}"
            )
            freshness = MPCFreshness.INVALID
        else:
            # Check 5: staleness
            if math.isfinite(current_time):
                age = current_time - snapshot.snap_timestamp
                if age < 0:
                    # Clock went backward — treat as stale
                    issues.append(
                        f"MPC snapshot age is negative ({age:.3f}s) — "
                        "clock anomaly; treating as stale."
                    )
                    freshness = MPCFreshness.STALE
                elif age > self._cfg.stale_timeout_s:
                    issues.append(
                        f"MPC snapshot is stale: age={age:.3f}s > "
                        f"timeout={self._cfg.stale_timeout_s:.3f}s."
                    )
                    freshness = MPCFreshness.STALE
                else:
                    freshness = MPCFreshness.FRESH
            else:
                issues.append(
                    f"current_time is non-finite: {current_time}"
                )
                freshness = MPCFreshness.UNKNOWN

        # Check 6: steering input finite
        if not math.isfinite(snapshot.first_steering_input):
            issues.append(
                f"MPC first_steering_input is non-finite: "
                f"{snapshot.first_steering_input}"
            )

        # Check 7: acceleration input finite
        if not math.isfinite(snapshot.first_acceleration_input):
            issues.append(
                f"MPC first_acceleration_input is non-finite: "
                f"{snapshot.first_acceleration_input}"
            )

        # Check 8: non-empty control sequence (only when feasible)
        if snapshot.feasible and len(snapshot.control_sequence) == 0:
            issues.append(
                "MPC control_sequence is empty despite feasible=True."
            )

        valid = (
            len(issues) == 0
            and freshness in (MPCFreshness.FRESH, MPCFreshness.UNKNOWN)
        )

        # If no issues but freshness is STALE, still mark invalid
        if freshness == MPCFreshness.STALE:
            valid = False

        return MPCInputValidationResult(
            valid     = valid,
            freshness = freshness,
            issues    = tuple(issues),
        )

    # ------------------------------------------------------------------
    # Command validation
    # ------------------------------------------------------------------

    def validate_command(
        self,
        command: "VehicleControlCommand",  # type: ignore[name-defined]
    ) -> CommandValidationResult:
        """
        Validate a completed VehicleControlCommand.

        Checks:
        * All numeric fields are finite.
        * Steering angle within [min_steering_rad, max_steering_rad].
        * Steering rate within [0, max_steering_rate_rad_s] (magnitude).
        * Acceleration within [min_acceleration_mps2, max_acceleration_mps2].
        * Brake is non-negative.
        * Brake ≤ max_brake_mps2.
        * Target speed within [min_speed_mps, max_speed_mps].
        * Timestamp is finite.
        * frame_id ≥ 0.
        * No contradictory command: acceleration > 0 with brake > threshold.

        Parameters
        ----------
        command : VehicleControlCommand to validate.

        Returns
        -------
        CommandValidationResult
        """
        cfg    = self._cfg
        issues: List[str] = []

        # Numeric finiteness
        numeric_fields = {
            "steering_angle_rad":  command.steering_angle_rad,
            "steering_rate_rad_s": command.steering_rate_rad_s,
            "acceleration_mps2":   command.acceleration_mps2,
            "brake_mps2":          command.brake_mps2,
            "target_speed_mps":    command.target_speed_mps,
            "timestamp":           command.timestamp,
        }
        for fname, fval in numeric_fields.items():
            if not math.isfinite(fval):
                issues.append(f"{fname} is non-finite: {fval}")

        # frame_id
        if command.frame_id < 0:
            issues.append(f"frame_id must be >= 0, got {command.frame_id}")

        # Steering angle bounds
        if math.isfinite(command.steering_angle_rad):
            if command.steering_angle_rad < cfg.min_steering_rad:
                issues.append(
                    f"steering_angle_rad {command.steering_angle_rad:.4f} < "
                    f"min {cfg.min_steering_rad:.4f}"
                )
            if command.steering_angle_rad > cfg.max_steering_rad:
                issues.append(
                    f"steering_angle_rad {command.steering_angle_rad:.4f} > "
                    f"max {cfg.max_steering_rad:.4f}"
                )

        # Steering rate bounds (magnitude)
        if math.isfinite(command.steering_rate_rad_s):
            if abs(command.steering_rate_rad_s) > cfg.max_steering_rate_rad_s + 1e-9:
                issues.append(
                    f"|steering_rate_rad_s| {abs(command.steering_rate_rad_s):.4f} > "
                    f"max {cfg.max_steering_rate_rad_s:.4f}"
                )

        # Acceleration bounds
        if math.isfinite(command.acceleration_mps2):
            if command.acceleration_mps2 < cfg.min_acceleration_mps2:
                issues.append(
                    f"acceleration_mps2 {command.acceleration_mps2:.4f} < "
                    f"min {cfg.min_acceleration_mps2:.4f}"
                )
            if command.acceleration_mps2 > cfg.max_acceleration_mps2:
                issues.append(
                    f"acceleration_mps2 {command.acceleration_mps2:.4f} > "
                    f"max {cfg.max_acceleration_mps2:.4f}"
                )

        # Brake bounds
        if math.isfinite(command.brake_mps2):
            if command.brake_mps2 < 0:
                issues.append(
                    f"brake_mps2 must be >= 0, got {command.brake_mps2:.4f}"
                )
            if command.brake_mps2 > cfg.max_brake_mps2 + 1e-9:
                issues.append(
                    f"brake_mps2 {command.brake_mps2:.4f} > "
                    f"max_brake_mps2 {cfg.max_brake_mps2:.4f}"
                )

        # Target speed bounds
        if math.isfinite(command.target_speed_mps):
            if command.target_speed_mps < cfg.min_speed_mps:
                issues.append(
                    f"target_speed_mps {command.target_speed_mps:.4f} < "
                    f"min {cfg.min_speed_mps:.4f}"
                )
            if command.target_speed_mps > cfg.max_speed_mps:
                issues.append(
                    f"target_speed_mps {command.target_speed_mps:.4f} > "
                    f"max {cfg.max_speed_mps:.4f}"
                )

        # Consistency: no simultaneous strong acceleration + brake
        if (math.isfinite(command.acceleration_mps2)
                and math.isfinite(command.brake_mps2)):
            if (command.acceleration_mps2 > 0.0
                    and command.brake_mps2 > cfg.brake_threshold_mps2):
                issues.append(
                    f"Contradictory command: acceleration={command.acceleration_mps2:.2f} m/s² > 0 "
                    f"with brake={command.brake_mps2:.2f} m/s² > threshold "
                    f"{cfg.brake_threshold_mps2:.2f} m/s²."
                )

        return CommandValidationResult(
            valid  = (len(issues) == 0),
            issues = tuple(issues),
        )
