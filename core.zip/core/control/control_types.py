"""
IndiDrive AI — Phase 10.4 | Control Types — Enums and Constants
================================================================
Shared enumerations, sentinels, and schema version for the
steering/speed control layer.

Nothing here performs computation; all values are structural.

Architecture position:
    Phase 9.6 Final Planner
            ↓
    Phase 10.1 Vehicle Dynamics
            ↓
    Phase 10.2 Trajectory Tracking
            ↓
    Phase 10.3 MPC Controller
            ↓
    Phase 10.4 Steering / Speed Control  ← this module (types only)
            ↓
    Phase 10.5 Planner → MPC Integration (future)

Coordinate convention (project-wide):
    +X = forward, +Y = left, +Z = up
    Origin = vehicle rear-axle centre
    Units  = metres, radians, seconds, m/s, m/s²

Distinction between Phase 10.3 and Phase 10.4 representations
--------------------------------------------------------------
MPCControlInput / MPCSnapshot.first_steering_input   — mathematical
    MPC optimisation variable.  Computed by Phase 10.3 solver.
    NOT an actuator command.

VehicleControlCommand (Phase 10.4)                   — vehicle-level
    Structured, validated, bounded control command.
    Ready for downstream actuation (Phase 10.5+).
"""
from __future__ import annotations

from enum import Enum

# ---------------------------------------------------------------------------
# Schema version
# ---------------------------------------------------------------------------

CONTROL_SCHEMA_VERSION: str = "10.4"

# Sentinel for optional / unavailable fields
CONTROL_NOT_AVAILABLE: str = "NOT_AVAILABLE"

# ---------------------------------------------------------------------------
# Command source
# ---------------------------------------------------------------------------


class CommandSource(str, Enum):
    """
    Identifies the origin of a control command.

    MPC    — Generated from a valid Phase 10.3 MPC solution.
    HOLD   — Holds the previous valid command (explicit fallback).
    ZERO   — All-zero/safe command (initialisation or explicit request).
    UNKNOWN — Source cannot be determined.
    """
    MPC     = "MPC"
    HOLD    = "HOLD"
    ZERO    = "ZERO"
    UNKNOWN = "UNKNOWN"


# ---------------------------------------------------------------------------
# Steering command status
# ---------------------------------------------------------------------------


class SteeringStatus(str, Enum):
    """
    Explicit status of the steering command produced by Phase 10.4.

    VALID               — Steering command is within all configured limits.
    LIMITED             — MPC steering was clamped; command is still valid
                          but represents saturation (steering_limited=True).
    RATE_LIMITED        — Steering rate was clamped; steering_rate_limited=True.
    INVALID_INPUT       — MPC steering input was non-finite or structurally wrong.
    STALE_MPC           — MPC snapshot is too old; command is degraded.
    NO_MPC_SOLUTION     — MPC snapshot is missing or infeasible.
    CONSTRAINT_VIOLATION— MPC input violates a hard constraint.
    DEGRADED            — Command produced but with reduced confidence.
    UNKNOWN             — Status cannot be determined.
    """
    VALID                = "VALID"
    LIMITED              = "LIMITED"
    RATE_LIMITED         = "RATE_LIMITED"
    INVALID_INPUT        = "INVALID_INPUT"
    STALE_MPC            = "STALE_MPC"
    NO_MPC_SOLUTION      = "NO_MPC_SOLUTION"
    CONSTRAINT_VIOLATION = "CONSTRAINT_VIOLATION"
    DEGRADED             = "DEGRADED"
    UNKNOWN              = "UNKNOWN"


# ---------------------------------------------------------------------------
# Longitudinal command status
# ---------------------------------------------------------------------------


class LongitudinalStatus(str, Enum):
    """
    Explicit status of the longitudinal command produced by Phase 10.4.

    VALID               — Acceleration/brake/speed command within limits.
    LIMITED             — MPC acceleration was clamped; speed_limited=True
                          or accel_limited=True.
    INVALID_INPUT       — MPC acceleration input was non-finite.
    STALE_MPC           — MPC snapshot is too old.
    NO_MPC_SOLUTION     — MPC snapshot is missing or infeasible.
    CONSTRAINT_VIOLATION— Constraint hard-violation in MPC input.
    DEGRADED            — Command produced with reduced confidence.
    UNKNOWN             — Status cannot be determined.
    """
    VALID                = "VALID"
    LIMITED              = "LIMITED"
    INVALID_INPUT        = "INVALID_INPUT"
    STALE_MPC            = "STALE_MPC"
    NO_MPC_SOLUTION      = "NO_MPC_SOLUTION"
    CONSTRAINT_VIOLATION = "CONSTRAINT_VIOLATION"
    DEGRADED             = "DEGRADED"
    UNKNOWN              = "UNKNOWN"


# ---------------------------------------------------------------------------
# Overall control command status
# ---------------------------------------------------------------------------


class ControlCommandStatus(str, Enum):
    """
    Overall status of the VehicleControlCommand produced by Phase 10.4.

    VALID         — All sub-commands are valid and within limits.
    LIMITED       — At least one command was limited/clamped; still usable.
    INVALID       — At least one command is invalid; do not apply.
    STALE         — MPC input was stale; command may be outdated.
    NO_SOLUTION   — No usable MPC solution was available.
    DEGRADED      — Command produced with reduced confidence.
    UNKNOWN       — Status cannot be determined.
    """
    VALID       = "VALID"
    LIMITED     = "LIMITED"
    INVALID     = "INVALID"
    STALE       = "STALE"
    NO_SOLUTION = "NO_SOLUTION"
    DEGRADED    = "DEGRADED"
    UNKNOWN     = "UNKNOWN"


# ---------------------------------------------------------------------------
# Longitudinal mode — normalised longitudinal intent
# ---------------------------------------------------------------------------


class LongitudinalMode(str, Enum):
    """
    Normalised longitudinal command intent.

    ACCELERATE — Positive acceleration demand.
    COAST      — Zero acceleration; neither accelerating nor braking.
    DECELERATE — Negative acceleration; brake pedal not required.
    BRAKE      — Significant deceleration; brake actuator engaged.
    STOP       — Deceleration to zero / hold at rest.
    UNKNOWN    — Mode cannot be determined.
    """
    ACCELERATE = "ACCELERATE"
    COAST      = "COAST"
    DECELERATE = "DECELERATE"
    BRAKE      = "BRAKE"
    STOP       = "STOP"
    UNKNOWN    = "UNKNOWN"


# ---------------------------------------------------------------------------
# MPC freshness
# ---------------------------------------------------------------------------


class MPCFreshness(str, Enum):
    """
    Freshness classification of the MPC snapshot at command generation time.

    FRESH   — Snapshot age is within the configured stale timeout.
    STALE   — Snapshot age exceeds the configured stale timeout.
    INVALID — Snapshot timestamp is non-finite or otherwise invalid.
    UNKNOWN — Freshness cannot be determined (e.g. no snapshot).
    """
    FRESH   = "FRESH"
    STALE   = "STALE"
    INVALID = "INVALID"
    UNKNOWN = "UNKNOWN"


# ---------------------------------------------------------------------------
# Fallback policy
# ---------------------------------------------------------------------------


class FallbackPolicy(str, Enum):
    """
    Explicit fallback behaviour when MPC solution is unavailable.

    INVALID_COMMAND       — Return an INVALID command; do not attempt fallback.
                            Default: safest option, forces upstream handling.
    HOLD_CURRENT          — Return the most recent valid command unchanged.
    SAFE_DECELERATION     — Request a safe deceleration (configured value).
    """
    INVALID_COMMAND    = "INVALID_COMMAND"
    HOLD_CURRENT       = "HOLD_CURRENT"
    SAFE_DECELERATION  = "SAFE_DECELERATION"
