"""
IndiDrive AI — Phase 10.3 | MPC Cost Function
=============================================
Computes the MPC objective (cost) for a predicted state sequence against a
reference trajectory.

Cost structure
--------------
The total cost J is the sum of three components:

    J = J_tracking + J_control_effort + J_control_rate

where:

J_tracking (stage cost, summed over steps k=0..N-1):
    J_tracking_k =
        w_cte    * cross_track_error²
      + w_ate    * along_track_error²
      + w_heading* heading_error²
      + w_speed  * speed_error²    (if reference velocity available)

J_control_effort (summed over steps k=0..N-1):
    J_control_k =
        w_steering     * steering_input²
      + w_acceleration * acceleration_input²

J_control_rate (penalises rapid changes, k=0..N-1):
    J_rate_k =
        w_steering_rate     * (Δsteering)²
      + w_acceleration_rate * (Δacceleration)²

    where Δsteering  = steering[k] - steering[k-1]
          (for k=0: previous control from the current ego state)

Terminal cost (step k=N only, if w_terminal > 0):
    J_terminal = w_terminal * J_tracking_N

Every error is computed against the reference point nearest (in arc-length)
to the predicted state.  Geometric errors use the same sign convention as
Phase 10.2 TrackingError.

Design
------
* No duplication of Phase 10.2 matching logic — uses lightweight local
  matching sufficient for MPC cost evaluation.
* Stateless: same inputs → same output.
* Numerically safe: returns math.inf if any calculation is invalid.
"""
from __future__ import annotations

import math
from dataclasses import dataclass
from typing import List, Optional, Tuple

from .mpc_config import MPCConfig
from .mpc_prediction import MPCControlInput, PredictionResult
from ..tracking.reference_trajectory import ReferencePoint, ReferenceTrajectory
from ..vehicle.vehicle_state import VehicleState, normalise_angle


# ---------------------------------------------------------------------------
# Per-step cost breakdown
# ---------------------------------------------------------------------------

@dataclass
class StepCost:
    """
    Detailed cost breakdown for one prediction step.

    Fields
    ------
    step_index       : 0-based step within the horizon.
    tracking_cost    : J_tracking_k (≥ 0).
    control_cost     : J_control_k  (≥ 0).
    rate_cost        : J_rate_k     (≥ 0).
    terminal_cost    : J_terminal   (≥ 0, only non-zero at step N).
    total_step_cost  : Sum of above.
    cte              : Cross-track error (m) used.
    ate              : Along-track error (m) used.
    heading_err      : Heading error (rad) used.
    speed_err        : Speed error (m/s) used; NaN if unavailable.
    ref_index        : Index of the reference point used for matching.
    """
    step_index:     int   = 0
    tracking_cost:  float = 0.0
    control_cost:   float = 0.0
    rate_cost:      float = 0.0
    terminal_cost:  float = 0.0
    total_step_cost:float = 0.0
    cte:            float = 0.0
    ate:            float = 0.0
    heading_err:    float = 0.0
    speed_err:      float = float("nan")
    ref_index:      int   = 0


@dataclass
class CostResult:
    """
    Aggregated cost for a complete MPC candidate sequence.

    Fields
    ------
    tracking_cost   : Sum of J_tracking over all steps (+ terminal).
    control_cost    : Sum of J_control over all steps.
    rate_cost       : Sum of J_rate over all steps.
    terminal_cost   : Terminal cost J_terminal (included in tracking_cost).
    total_cost      : tracking_cost + control_cost + rate_cost.
    valid           : False if any numerical issue occurred.
    error_message   : Non-empty if valid=False.
    step_costs      : Per-step breakdown (empty if not computed).
    """
    tracking_cost:  float = 0.0
    control_cost:   float = 0.0
    rate_cost:      float = 0.0
    terminal_cost:  float = 0.0
    total_cost:     float = 0.0
    valid:          bool  = True
    error_message:  str   = ""
    step_costs:     List[StepCost] = None

    def __post_init__(self):
        if self.step_costs is None:
            self.step_costs = []

    @classmethod
    def invalid(cls, message: str) -> "CostResult":
        """Return an invalid (infinite-cost) result with an error message."""
        return cls(
            tracking_cost  = math.inf,
            control_cost   = math.inf,
            rate_cost      = math.inf,
            terminal_cost  = math.inf,
            total_cost     = math.inf,
            valid          = False,
            error_message  = message,
        )


# ---------------------------------------------------------------------------
# Reference point matching (lightweight, for MPC only)
# ---------------------------------------------------------------------------

def _nearest_reference_index(
    state: VehicleState,
    points: List[ReferencePoint],
    start_hint: int = 0,
) -> int:
    """
    Return the index of the nearest ReferencePoint to *state* position.

    Uses Euclidean nearest-point search, which is fast and sufficient
    for the MPC cost horizon.

    Searches forward from start_hint to avoid jumping backwards on a
    curved path (monotone matching approximation).
    """
    n = len(points)
    if n == 0:
        return 0
    if n == 1:
        return 0

    best_idx = max(0, min(start_hint, n - 1))
    best_dist2 = (
        (state.x - points[best_idx].x) ** 2
        + (state.y - points[best_idx].y) ** 2
    )

    # Search forward only (avoids regressing on curves)
    for i in range(best_idx + 1, n):
        d2 = (state.x - points[i].x) ** 2 + (state.y - points[i].y) ** 2
        if d2 < best_dist2:
            best_dist2 = d2
            best_idx = i
        elif d2 > best_dist2 * 4.0:
            # Heuristic early stop: distance growing — past the nearest
            break

    return best_idx


def _compute_tracking_errors(
    state:    VehicleState,
    ref:      ReferencePoint,
    ref_prev: Optional[ReferencePoint],
) -> Tuple[float, float, float, float]:
    """
    Compute (cte, ate, heading_err, speed_err) for *state* vs *ref*.

    Cross-track error  : signed perpendicular deviation (m).
        Positive = state is LEFT of reference direction.
    Along-track error  : signed longitudinal displacement (m).
        Positive = state is AHEAD of reference point.
    Heading error      : normalised to [-π, π) (rad).
        Positive = ego heading is CCW (left) of reference.
    Speed error        : m/s. NaN if reference velocity unavailable.

    Uses the direction vector ref_prev→ref (or ref yaw if no prev) to
    establish the reference frame for lateral/longitudinal decomposition.

    Sign conventions match Phase 10.2 TrackingError.
    """
    # --- Reference direction vector ---
    if ref_prev is not None:
        dx_ref = ref.x - ref_prev.x
        dy_ref = ref.y - ref_prev.y
        dist = math.hypot(dx_ref, dy_ref)
        if dist > 1e-6:
            # Unit tangent of the reference path at this point
            tx = dx_ref / dist
            ty = dy_ref / dist
            ref_yaw = math.atan2(dy_ref, dx_ref)
        else:
            # Degenerate segment: fall back to stored yaw
            ref_yaw = ref.yaw if (ref.yaw is not None and math.isfinite(ref.yaw)) else 0.0
            tx = math.cos(ref_yaw)
            ty = math.sin(ref_yaw)
    else:
        ref_yaw = ref.yaw if (ref.yaw is not None and math.isfinite(ref.yaw)) else 0.0
        tx = math.cos(ref_yaw)
        ty = math.sin(ref_yaw)

    # --- Error vector from reference point to ego ---
    ex = state.x - ref.x
    ey = state.y - ref.y

    # Along-track (longitudinal) component: projection onto tangent
    ate = ex * tx + ey * ty

    # Cross-track (lateral) component: projection onto normal (−ty, tx = left normal)
    # Positive CTE = ego is to the LEFT
    cte = -ex * ty + ey * tx

    # --- Heading error ---
    heading_err = 0.0
    if ref.yaw is not None and math.isfinite(ref.yaw):
        heading_err = normalise_angle(state.yaw - ref.yaw)
    elif ref_prev is not None:
        heading_err = normalise_angle(state.yaw - ref_yaw)

    # --- Speed error ---
    speed_err = float("nan")
    if ref.velocity is not None and math.isfinite(ref.velocity):
        speed_err = state.velocity - ref.velocity

    return cte, ate, heading_err, speed_err


# ---------------------------------------------------------------------------
# MPC Cost Calculator
# ---------------------------------------------------------------------------

class MPCCostCalculator:
    """
    Computes the MPC objective cost for a predicted state/control sequence.

    Usage
    -----
    >>> calc   = MPCCostCalculator(config)
    >>> result = calc.compute(prediction, reference, prev_steering=0.0,
    ...                       prev_acceleration=0.0)

    The calculator is stateless; multiple instances may share a config.
    """

    def __init__(self, config: MPCConfig) -> None:
        self._cfg = config

    @property
    def config(self) -> MPCConfig:
        return self._cfg

    # ------------------------------------------------------------------ #
    # Public API
    # ------------------------------------------------------------------ #

    def compute(
        self,
        prediction:        PredictionResult,
        reference:         ReferenceTrajectory,
        prev_steering:     float = 0.0,
        prev_acceleration: float = 0.0,
    ) -> CostResult:
        """
        Compute the total MPC cost for *prediction* against *reference*.

        Parameters
        ----------
        prediction        : PredictionResult from MPCPredictor.
        reference         : Phase 10.2 ReferenceTrajectory.
        prev_steering     : Steering angle at the start of the horizon (rad).
                            Used to compute the rate cost at step 0.
        prev_acceleration : Acceleration at the start of the horizon (m/s²).

        Returns
        -------
        CostResult with total_cost and per-component breakdown.
        If any numerical error occurs, returns CostResult.invalid().
        """
        cfg = self._cfg

        # --- Guard: invalid prediction ---
        if not prediction.valid:
            return CostResult.invalid(
                f"Prediction is invalid: {prediction.error_message}"
            )
        if len(prediction.states) < 2:
            return CostResult.invalid(
                "Prediction has fewer than 2 states (no steps predicted)"
            )

        # --- Guard: empty reference ---
        if reference is None or reference.is_empty:
            return CostResult.invalid("Reference trajectory is empty")

        ref_pts = reference.points
        N = prediction.horizon  # number of control steps = len(states) - 1

        # Input validation
        if not math.isfinite(prev_steering) or not math.isfinite(prev_acceleration):
            return CostResult.invalid(
                f"prev_steering={prev_steering} or "
                f"prev_acceleration={prev_acceleration} is not finite"
            )

        total_tracking  = 0.0
        total_control   = 0.0
        total_rate      = 0.0
        total_terminal  = 0.0
        step_costs: List[StepCost] = []

        # Previous control values for rate cost (k=0 uses ego's current control)
        prev_s = prev_steering
        prev_a = prev_acceleration

        # Monotone reference index hint — advances forward along the path
        ref_hint = 0

        # We compute cost for steps 0..N-1 (stage costs)
        # and additionally at step N (terminal cost)
        for k in range(N):
            state   = prediction.states[k + 1]  # post-step state
            control = prediction.controls[k]

            # --- Numerical safety ---
            if not state.is_finite():
                return CostResult.invalid(f"Non-finite predicted state at step {k + 1}")
            if not control.is_finite():
                return CostResult.invalid(f"Non-finite control at step {k}")

            # --- Reference matching ---
            ref_hint = _nearest_reference_index(state, ref_pts, ref_hint)
            ref      = ref_pts[ref_hint]
            ref_prev = ref_pts[ref_hint - 1] if ref_hint > 0 else None

            # --- Tracking errors ---
            cte, ate, heading_err, speed_err = _compute_tracking_errors(
                state, ref, ref_prev
            )

            # Numerical safety on errors
            if not all(math.isfinite(v) for v in (cte, ate, heading_err)):
                return CostResult.invalid(
                    f"Non-finite tracking error at step {k}: "
                    f"cte={cte}, ate={ate}, heading_err={heading_err}"
                )

            # --- Stage tracking cost: J_tracking_k ---
            j_track = (
                cfg.w_cross_track * cte * cte
                + cfg.w_along_track * ate * ate
                + cfg.w_heading  * heading_err * heading_err
            )
            if math.isfinite(speed_err):
                j_track += cfg.w_speed * speed_err * speed_err

            # --- Control effort cost: J_control_k ---
            s  = control.steering_input
            a  = control.acceleration_input
            j_ctrl = (
                cfg.w_steering     * s * s
                + cfg.w_acceleration * a * a
            )

            # --- Control rate cost: J_rate_k ---
            d_steer = s - prev_s
            d_accel = a - prev_a
            j_rate = (
                cfg.w_steering_rate     * d_steer * d_steer
                + cfg.w_acceleration_rate * d_accel * d_accel
            )

            step_total = j_track + j_ctrl + j_rate

            total_tracking += j_track
            total_control  += j_ctrl
            total_rate     += j_rate

            sc = StepCost(
                step_index    = k,
                tracking_cost = j_track,
                control_cost  = j_ctrl,
                rate_cost     = j_rate,
                terminal_cost = 0.0,
                total_step_cost = step_total,
                cte           = cte,
                ate           = ate,
                heading_err   = heading_err,
                speed_err     = speed_err if math.isfinite(speed_err) else float("nan"),
                ref_index     = ref_hint,
            )
            step_costs.append(sc)

            prev_s = s
            prev_a = a

        # --- Terminal cost at step N ---
        terminal_cost = 0.0
        if cfg.w_terminal > 0.0:
            final_state = prediction.states[N]
            if not final_state.is_finite():
                return CostResult.invalid("Non-finite terminal state")

            ref_hint_t = _nearest_reference_index(final_state, ref_pts, ref_hint)
            ref_t      = ref_pts[ref_hint_t]
            ref_prev_t = ref_pts[ref_hint_t - 1] if ref_hint_t > 0 else None

            cte_t, ate_t, he_t, se_t = _compute_tracking_errors(
                final_state, ref_t, ref_prev_t
            )

            if not all(math.isfinite(v) for v in (cte_t, ate_t, he_t)):
                return CostResult.invalid("Non-finite terminal tracking error")

            j_term_base = (
                cfg.w_cross_track * cte_t * cte_t
                + cfg.w_along_track * ate_t * ate_t
                + cfg.w_heading     * he_t  * he_t
            )
            if math.isfinite(se_t):
                j_term_base += cfg.w_speed * se_t * se_t

            terminal_cost = cfg.w_terminal * j_term_base
            total_tracking += terminal_cost
            total_terminal  = terminal_cost

        total_cost = total_tracking + total_control + total_rate

        # Final numerical safety
        if not math.isfinite(total_cost):
            return CostResult.invalid(
                f"Non-finite total_cost={total_cost} after accumulation"
            )

        return CostResult(
            tracking_cost = total_tracking,
            control_cost  = total_control,
            rate_cost     = total_rate,
            terminal_cost = total_terminal,
            total_cost    = total_cost,
            valid         = True,
            step_costs    = step_costs,
        )
