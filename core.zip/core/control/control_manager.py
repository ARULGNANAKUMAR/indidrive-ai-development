"""
IndiDrive AI — Phase 10.4 | Control Manager
=============================================
Orchestrates the steering/speed control pipeline from MPC snapshot to
validated VehicleControlCommand.

Pipeline
--------
MPCSnapshot (Phase 10.3)
        ↓
 Input Validation (ControlValidator)
        ↓
 Steering Control (SteeringController)
        ↓
 Speed Control (SpeedController)
        ↓
 Command Assembly (VehicleControlCommand.from_results)
        ↓
 Command Validation (ControlValidator)
        ↓
 VehicleControlCommand (Phase 10.4 output)

Responsibilities
----------------
1. Validate the Phase 10.3 MPCSnapshot (freshness, feasibility, finiteness).
2. Apply fallback policy when MPC is unavailable.
3. Run SteeringController with rate-limit state.
4. Run SpeedController.
5. Assemble VehicleControlCommand snapshot.
6. Validate the assembled command.
7. Return the final VehicleControlCommand.

State owned by ControlManager
------------------------------
_prev_steering_rad: Optional[float]
    Previous commanded steering angle, required for steering-rate limiting.
    None on first cycle.

_prev_command: Optional[VehicleControlCommand]
    Previous valid command, for HOLD_CURRENT fallback.

_cycle: int
    Internal cycle counter (monotonically increasing).

Thread safety
-------------
ControlManager is NOT thread-safe.  It owns mutable state.
If multiple threads are needed, each thread must have its own instance.

Determinism
-----------
Same (snapshot, ego_state, ref_speed, current_time) → same output,
given the same prior state.  No random values.

This module does NOT:
    * Run a PID, Pure Pursuit, Stanley, or LQR controller.
    * Plan a path or trajectory.
    * Replan.
    * Detect obstacles.
    * Send commands to CARLA or hardware.
"""
from __future__ import annotations

import math
import time
from typing import Optional

from .control_config import ControlConfig
from .control_snapshot import VehicleControlCommand
from .control_types import (
    CommandSource,
    ControlCommandStatus,
    FallbackPolicy,
    LongitudinalMode,
    LongitudinalStatus,
    MPCFreshness,
    SteeringStatus,
)
from .control_validator import ControlValidator
from .mpc_snapshot import MPCSnapshot
from .mpc_types import MPCStatus
from .speed_controller import LongitudinalResult, SpeedController
from .steering_controller import SteeringController, SteeringResult


class ControlManager:
    """
    Stateful orchestrator for the Phase 10.4 control pipeline.

    Parameters
    ----------
    config : ControlConfig
        Validated configuration for the control layer.

    Usage
    -----
    ::

        manager = ControlManager(ControlConfig.default())

        # Per control cycle:
        cmd = manager.step(
            snapshot       = mpc_snapshot,
            current_velocity_mps = ego_state.velocity,
            ref_speed_mps  = ref_point.velocity,
            dt             = 0.1,
            frame_id       = ego_state.frame_id,
            current_time   = time.monotonic(),
        )
    """

    def __init__(self, config: ControlConfig) -> None:
        if not isinstance(config, ControlConfig):
            raise TypeError(
                f"ControlManager requires ControlConfig, got {type(config)}"
            )
        self._cfg       = config
        self._steer_ctrl = SteeringController(config)
        self._speed_ctrl = SpeedController(config)
        self._validator  = ControlValidator(config)

        # Mutable cycle state
        self._prev_steering_rad: Optional[float]             = None
        self._prev_command:      Optional[VehicleControlCommand] = None
        self._cycle:             int                          = 0

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    @property
    def cycle(self) -> int:
        """Number of completed step() calls."""
        return self._cycle

    @property
    def previous_steering_rad(self) -> Optional[float]:
        """Previous commanded steering angle, or None on first cycle."""
        return self._prev_steering_rad

    @property
    def previous_command(self) -> Optional[VehicleControlCommand]:
        """Most recent valid VehicleControlCommand, or None."""
        return self._prev_command

    def reset(self) -> None:
        """
        Reset mutable state.

        Use when the vehicle state or scenario changes such that
        the previous steering value is no longer valid.
        """
        self._prev_steering_rad = None
        self._prev_command      = None
        # cycle intentionally NOT reset — it is a monotonic counter

    def step(
        self,
        snapshot:             Optional[MPCSnapshot],
        current_velocity_mps: float,
        ref_speed_mps:        Optional[float],
        dt:                   float,
        frame_id:             int   = 0,
        current_time:         Optional[float] = None,
    ) -> VehicleControlCommand:
        """
        Execute one control pipeline cycle.

        Parameters
        ----------
        snapshot             : Phase 10.3 MPCSnapshot.  May be None.
        current_velocity_mps : Ego vehicle forward speed (m/s), must be ≥ 0.
        ref_speed_mps        : Reference speed from trajectory (m/s), or None.
        dt                   : Elapsed time since the previous control step (s).
                               Used for steering-rate limiting and target-speed
                               integration.  Ignored if ≤ 0 or non-finite.
        frame_id             : Frame counter from the ego state.
        current_time         : Wall-clock time (time.monotonic()).  Defaults to
                               time.monotonic() if None.

        Returns
        -------
        VehicleControlCommand — always returns a valid structure, never raises.
        """
        if current_time is None:
            current_time = time.monotonic()

        # ----------------------------------------------------------------
        # Step 1: validate MPC snapshot
        # ----------------------------------------------------------------
        mpc_result = self._validator.validate_mpc_snapshot(snapshot, current_time)

        if not mpc_result.valid:
            cmd = self._apply_fallback(mpc_result.freshness, frame_id, mpc_result.issues)
            self._cycle += 1
            return cmd

        # ----------------------------------------------------------------
        # Step 2: extract MPC inputs — snapshot is confirmed valid here
        # ----------------------------------------------------------------
        assert snapshot is not None  # guaranteed by validate_mpc_snapshot
        mpc_steering  = snapshot.first_steering_input
        mpc_accel     = snapshot.first_acceleration_input

        # ----------------------------------------------------------------
        # Step 3: steering controller
        # ----------------------------------------------------------------
        steer_result = self._steer_ctrl.compute(
            mpc_steering_rad   = mpc_steering,
            prev_steering_rad  = self._prev_steering_rad,
            dt                 = dt,
        )

        # ----------------------------------------------------------------
        # Step 4: speed controller
        # ----------------------------------------------------------------
        speed_result = self._speed_ctrl.compute(
            mpc_acceleration_mps2 = mpc_accel,
            current_velocity_mps  = current_velocity_mps,
            ref_speed_mps         = ref_speed_mps,
            dt                    = dt,
        )

        # ----------------------------------------------------------------
        # Step 5: assemble command snapshot
        # ----------------------------------------------------------------
        cmd = VehicleControlCommand.from_results(
            steering_result     = steer_result,
            longitudinal_result = speed_result,
            frame_id            = frame_id,
            source              = CommandSource.MPC,
        )

        # ----------------------------------------------------------------
        # Step 6: validate assembled command
        # ----------------------------------------------------------------
        cmd_val = self._validator.validate_command(cmd)
        if not cmd_val.valid:
            # Return degraded command with validation issues appended
            cmd = _degrade_command(cmd, cmd_val.issues, frame_id)

        # ----------------------------------------------------------------
        # Step 7: update state for next cycle
        # ----------------------------------------------------------------
        if cmd.is_valid:
            self._prev_steering_rad = cmd.steering_angle_rad
            self._prev_command      = cmd

        self._cycle += 1
        return cmd

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _apply_fallback(
        self,
        freshness:  MPCFreshness,
        frame_id:   int,
        issues:     tuple,
    ) -> VehicleControlCommand:
        """
        Apply the configured fallback policy and return an appropriate command.
        """
        reason_str = "; ".join(issues) if issues else "MPC unavailable."
        policy = self._cfg.fallback_policy

        if policy == FallbackPolicy.HOLD_CURRENT:
            if self._prev_command is not None and self._prev_command.is_valid:
                return self._prev_command
            # No prior valid command — fall through to INVALID
            return VehicleControlCommand.invalid(
                reason   = f"HOLD_CURRENT fallback: no prior valid command. {reason_str}",
                frame_id = frame_id,
                source   = CommandSource.HOLD,
            )

        if policy == FallbackPolicy.SAFE_DECELERATION:
            return _build_safe_deceleration_command(
                safe_decel_mps2 = self._cfg.safe_deceleration_mps2,
                frame_id        = frame_id,
                reason          = reason_str,
            )

        # Default: INVALID_COMMAND
        if freshness == MPCFreshness.STALE:
            return VehicleControlCommand.stale(
                reason   = reason_str,
                frame_id = frame_id,
            )
        return VehicleControlCommand.invalid(
            reason   = reason_str,
            frame_id = frame_id,
            source   = CommandSource.UNKNOWN,
        )


# ---------------------------------------------------------------------------
# Module-level helpers
# ---------------------------------------------------------------------------


def _degrade_command(
    cmd:      VehicleControlCommand,
    issues:   tuple,
    frame_id: int,
) -> VehicleControlCommand:
    """
    Return a copy of *cmd* with status = DEGRADED and validation issues appended.

    Since VehicleControlCommand is frozen, we rebuild it from its fields.
    """
    extra = tuple(f"[VALIDATION] {iss}" for iss in issues)
    new_reasons = cmd.reason_codes + extra

    # Use object.__setattr__ not allowed on frozen — rebuild via __class__
    # We list all fields explicitly to avoid surprises.
    return VehicleControlCommand(
        command_id           = cmd.command_id,
        timestamp            = cmd.timestamp,
        frame_id             = frame_id,
        schema_version       = cmd.schema_version,
        steering_angle_rad   = cmd.steering_angle_rad,
        steering_rate_rad_s  = cmd.steering_rate_rad_s,
        steering_limited     = cmd.steering_limited,
        rate_limited         = cmd.rate_limited,
        steering_status      = cmd.steering_status,
        acceleration_mps2    = cmd.acceleration_mps2,
        brake_mps2           = cmd.brake_mps2,
        target_speed_mps     = cmd.target_speed_mps,
        longitudinal_mode    = cmd.longitudinal_mode,
        accel_limited        = cmd.accel_limited,
        speed_limited        = cmd.speed_limited,
        longitudinal_status  = cmd.longitudinal_status,
        status               = ControlCommandStatus.DEGRADED,
        source               = cmd.source,
        reason_codes         = new_reasons,
    )


def _build_safe_deceleration_command(
    safe_decel_mps2: float,
    frame_id:        int,
    reason:          str,
) -> VehicleControlCommand:
    """
    Build an explicit safe-deceleration command for the SAFE_DECELERATION
    fallback policy.

    The deceleration value is taken from ControlConfig.safe_deceleration_mps2
    (a negative number).  Brake is derived from its magnitude.
    """
    import time as _time
    import uuid as _uuid

    accel      = safe_decel_mps2          # e.g. -2.0 m/s²
    brake_mag  = abs(accel)               # 2.0 m/s²
    now        = _time.monotonic()
    cmd_id     = str(_uuid.uuid4())

    return VehicleControlCommand(
        command_id           = cmd_id,
        timestamp            = now,
        frame_id             = frame_id,
        schema_version       = "10.4",
        steering_angle_rad   = 0.0,
        steering_rate_rad_s  = 0.0,
        steering_limited     = False,
        rate_limited         = False,
        steering_status      = SteeringStatus.VALID,
        acceleration_mps2    = accel,
        brake_mps2           = brake_mag,
        target_speed_mps     = 0.0,
        longitudinal_mode    = LongitudinalMode.BRAKE,
        accel_limited        = False,
        speed_limited        = False,
        longitudinal_status  = LongitudinalStatus.VALID,
        status               = ControlCommandStatus.DEGRADED,
        source               = CommandSource.HOLD,
        reason_codes         = (f"[SAFE_DECEL] {reason}",),
    )
