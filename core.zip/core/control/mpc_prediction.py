"""
IndiDrive AI — Phase 10.3 | MPC Prediction
==========================================
Predicts the future vehicle state sequence for a given control sequence
using the Phase 10.1 kinematic bicycle model.

This module is the MPC prediction layer only.  It does NOT:
    * compute cost
    * check constraints
    * select control inputs
    * send commands to actuators or CARLA

Design
------
* Wraps KinematicBicycleModel.step() — reuses Phase 10.1 dynamics exactly.
* Stateless: same (state, controls, dt) → same predicted trajectory.
* Deterministic: no random number generation.
* Numerically safe: returns a flag rather than raising on bad inputs.

Coordinate convention (project-wide):
    +X = forward, +Y = left, +Z = up
    Origin = vehicle rear-axle centre
    Units  = metres, radians, seconds, m/s, m/s²
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import List, Optional, Tuple

from ..vehicle.bicycle_model import KinematicBicycleModel
from ..vehicle.vehicle_input import VehicleControlInput
from ..vehicle.vehicle_parameters import VehicleParameters
from ..vehicle.vehicle_state import VehicleState


# ---------------------------------------------------------------------------
# Candidate control input for MPC (mathematical only, NOT an actuator command)
# ---------------------------------------------------------------------------

@dataclass
class MPCControlInput:
    """
    One step of the MPC mathematical control sequence.

    This is the optimisation variable inside the MPC solver.
    It represents mathematical steering angle and acceleration
    as inputs to the bicycle model equations.

    THIS IS NOT:
        * a throttle actuator command
        * a brake actuator command
        * a steering actuator command
        * a CARLA VehicleControl object
        * a CAN bus command

    Those belong to Phase 10.4 (Steering / Speed Control) and later.

    Fields
    ------
    steering_input      : Front-wheel steering angle (rad).
    acceleration_input  : Longitudinal acceleration (m/s²).
    step_index          : Index within the MPC horizon (0 = first step).
    """
    steering_input:     float = 0.0   # rad
    acceleration_input: float = 0.0   # m/s²
    step_index:         int   = 0

    def is_finite(self) -> bool:
        return (
            math.isfinite(self.steering_input)
            and math.isfinite(self.acceleration_input)
        )

    def to_vehicle_input(self, timestamp: float = 0.0) -> VehicleControlInput:
        """
        Convert to Phase 10.1 VehicleControlInput for bicycle-model step.

        The conversion is a direct mapping of mathematical variables:
            steering_input  → VehicleControlInput.steering_angle
            acceleration_input → VehicleControlInput.acceleration

        No actuator conversion occurs here.
        """
        return VehicleControlInput(
            steering_angle=self.steering_input,
            acceleration=self.acceleration_input,
            timestamp=timestamp,
            frame_id=self.step_index,
        )

    def __repr__(self) -> str:
        return (
            f"MPCControlInput(δ={math.degrees(self.steering_input):.1f}°, "
            f"a={self.acceleration_input:.2f} m/s², step={self.step_index})"
        )


# ---------------------------------------------------------------------------
# Prediction result
# ---------------------------------------------------------------------------

@dataclass
class PredictionResult:
    """
    Predicted state sequence for one MPC candidate control sequence.

    Fields
    ------
    states          : List of VehicleState; length = horizon + 1.
                      states[0] = initial (current) state.
                      states[k] = state after k control steps.
    controls        : The MPCControlInput sequence used (length = horizon).
    valid           : True iff prediction completed without numerical error.
    error_message   : Non-empty if valid=False, explaining the failure.
    """
    states:        List[VehicleState]    = field(default_factory=list)
    controls:      List[MPCControlInput] = field(default_factory=list)
    valid:         bool                  = True
    error_message: str                   = ""

    @property
    def horizon(self) -> int:
        """Number of prediction steps (= len(states) - 1)."""
        return max(0, len(self.states) - 1)

    @property
    def final_state(self) -> Optional[VehicleState]:
        """The predicted state at the end of the horizon, or None."""
        return self.states[-1] if self.states else None

    @property
    def initial_state(self) -> Optional[VehicleState]:
        """The initial (step 0) state."""
        return self.states[0] if self.states else None


# ---------------------------------------------------------------------------
# Predictor
# ---------------------------------------------------------------------------

class MPCPredictor:
    """
    Applies a control sequence to the bicycle model and returns predicted
    states.

    This is a thin wrapper around KinematicBicycleModel that packages
    the output as a PredictionResult for the MPC cost and constraint
    layers.

    Usage
    -----
    >>> predictor = MPCPredictor(params=VehicleParameters.default())
    >>> controls  = [MPCControlInput(steering_input=0.05,
    ...                              acceleration_input=0.0,
    ...                              step_index=i) for i in range(10)]
    >>> result    = predictor.predict(initial_state, controls, dt=0.1)

    The predictor is stateless; the same call always produces the same
    output.
    """

    def __init__(self, params: Optional[VehicleParameters] = None) -> None:
        self._params = params if params is not None else VehicleParameters.default()
        self._model  = KinematicBicycleModel(self._params)

    @property
    def params(self) -> VehicleParameters:
        return self._params

    # ------------------------------------------------------------------ #
    # Public API
    # ------------------------------------------------------------------ #

    def predict(
        self,
        initial_state: VehicleState,
        controls:      List[MPCControlInput],
        dt:            float,
    ) -> PredictionResult:
        """
        Predict the state sequence for the given control sequence.

        Parameters
        ----------
        initial_state : Current vehicle state (Phase 10.1 VehicleState).
        controls      : Ordered list of MPCControlInput; one per horizon step.
        dt            : Timestep (s); must be > 0 and finite.

        Returns
        -------
        PredictionResult with states list of length len(controls) + 1.
        states[0] is the (copy of) initial_state.

        If any numerical issue is encountered, PredictionResult.valid is
        False and an error_message is set.  The states list will contain
        whatever was computed up to the point of failure.

        Notes
        -----
        * Uses Euler forward integration (same as Phase 10.1 bicycle model).
        * Does NOT validate controls against MPC limits — that is the
          responsibility of MPCConstraintChecker.
        """
        # --- Input validation ---
        if not math.isfinite(dt) or dt <= 0.0:
            return PredictionResult(
                states=[], controls=controls, valid=False,
                error_message=f"Invalid dt={dt}: must be finite and > 0",
            )

        try:
            initial_state.validate()
        except (ValueError, TypeError) as e:
            return PredictionResult(
                states=[], controls=controls, valid=False,
                error_message=f"Invalid initial_state: {e}",
            )

        if not controls:
            # Zero-horizon prediction: just return the initial state
            return PredictionResult(
                states=[initial_state.copy()],
                controls=[],
                valid=True,
            )

        states: List[VehicleState] = [initial_state.copy()]
        current = initial_state

        for i, ctrl in enumerate(controls):
            if not ctrl.is_finite():
                return PredictionResult(
                    states=states, controls=controls, valid=False,
                    error_message=(
                        f"Non-finite control at step {i}: "
                        f"δ={ctrl.steering_input}, a={ctrl.acceleration_input}"
                    ),
                )

            vehicle_input = ctrl.to_vehicle_input(
                timestamp=current.timestamp + dt
            )

            try:
                current = self._model.step(current, vehicle_input, dt)
            except (ValueError, TypeError) as e:
                return PredictionResult(
                    states=states, controls=controls, valid=False,
                    error_message=f"Bicycle model step failed at step {i}: {e}",
                )

            # Numerical safety check after each step
            if not current.is_finite():
                return PredictionResult(
                    states=states, controls=controls, valid=False,
                    error_message=f"Non-finite state after step {i}",
                )

            states.append(current)

        return PredictionResult(
            states=states,
            controls=controls,
            valid=True,
        )

    # ------------------------------------------------------------------ #
    # Convenience: predict a constant control input over N steps
    # ------------------------------------------------------------------ #

    def predict_constant(
        self,
        initial_state: VehicleState,
        steering:      float,
        acceleration:  float,
        horizon:       int,
        dt:            float,
    ) -> PredictionResult:
        """
        Predict with a constant (steering, acceleration) over *horizon* steps.

        Convenience method for cost/constraint testing.
        """
        controls = [
            MPCControlInput(
                steering_input=steering,
                acceleration_input=acceleration,
                step_index=i,
            )
            for i in range(horizon)
        ]
        return self.predict(initial_state, controls, dt)
