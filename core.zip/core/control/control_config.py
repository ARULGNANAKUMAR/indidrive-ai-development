"""
IndiDrive AI — Phase 10.4 | Control Configuration
===================================================
Validated, immutable configuration for the steering/speed control layer.

All physical values are in SI units (metres, seconds, radians, m/s, m/s²).

Design principles
-----------------
* Defaults are aligned with Phase 10.1 VehicleParameters.default() and
  Phase 10.3 MPCConfig defaults.
* Do NOT create conflicting limit values.  The control layer reads limits
  from this config; the bicycle model and MPC each have their own.
* Road-specific speed limits belong to the planner (Phase 9.6 / 10.5),
  not here.

Configuration sections
----------------------
Steering:
    min_steering_rad       — minimum allowed steering output (rad) ≤ 0
    max_steering_rad       — maximum allowed steering output (rad) ≥ 0
    max_steering_rate_rad_s— maximum rate of change of steering (rad/s) > 0

Longitudinal:
    min_acceleration_mps2  — minimum allowed acceleration output (m/s²) < 0
    max_acceleration_mps2  — maximum allowed acceleration output (m/s²) > 0
    min_speed_mps          — minimum allowed target speed (m/s) ≥ 0
    max_speed_mps          — maximum allowed target speed (m/s) > 0

Braking:
    brake_threshold_mps2   — deceleration magnitude below which brake=0
                             (i.e., coast).  Must be ≥ 0.
    max_brake_mps2         — maximum deceleration magnitude (positive value,
                             applied as negative acceleration).  Must be > 0.
                             Used to clamp brake demands.

Staleness:
    stale_timeout_s        — MPC snapshot age beyond which it is STALE (s)

Fallback:
    fallback_policy        — what to do when MPC is unavailable
    safe_deceleration_mps2 — deceleration to apply under SAFE_DECELERATION
                             fallback (negative value, m/s²)
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Optional

from .control_types import FallbackPolicy

# ---------------------------------------------------------------------------
# Defaults — aligned with Phase 10.1 VehicleParameters and Phase 10.3 MPCConfig
# ---------------------------------------------------------------------------

_DEFAULT_MIN_STEER_RAD:        float = -0.610  # −35°
_DEFAULT_MAX_STEER_RAD:        float =  0.610  # +35°
_DEFAULT_MAX_STEER_RATE_RAD_S: float =  0.700  # rad/s

_DEFAULT_MIN_ACCEL_MPS2:       float = -8.0    # max deceleration
_DEFAULT_MAX_ACCEL_MPS2:       float =  4.0    # max acceleration
_DEFAULT_MIN_SPEED_MPS:        float =  0.0    # forward-only
_DEFAULT_MAX_SPEED_MPS:        float = 33.33   # ~120 km/h

_DEFAULT_BRAKE_THRESHOLD_MPS2: float =  0.05   # below this decel → coast
_DEFAULT_MAX_BRAKE_MPS2:       float =  8.0    # magnitude (positive)

_DEFAULT_STALE_TIMEOUT_S:      float =  0.5    # 500 ms

_DEFAULT_FALLBACK_POLICY:      FallbackPolicy = FallbackPolicy.INVALID_COMMAND
_DEFAULT_SAFE_DECEL_MPS2:      float = -2.0    # gentle deceleration fallback


# ---------------------------------------------------------------------------
# Configuration dataclass
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class ControlConfig:
    """
    Immutable, validated configuration for the Phase 10.4 control layer.

    Attributes
    ----------
    enabled                 : Enable / disable the control layer.
    min_steering_rad        : Minimum steering output angle (rad).
    max_steering_rad        : Maximum steering output angle (rad).
    max_steering_rate_rad_s : Maximum steering rate (rad/s).
    min_acceleration_mps2   : Minimum acceleration output (m/s²), must be < 0.
    max_acceleration_mps2   : Maximum acceleration output (m/s²), must be > 0.
    min_speed_mps           : Minimum target speed (m/s).
    max_speed_mps           : Maximum target speed (m/s).
    brake_threshold_mps2    : Decel magnitude below which brake output = 0.
    max_brake_mps2          : Maximum brake deceleration magnitude (positive).
    stale_timeout_s         : MPC age threshold for STALE classification (s).
    fallback_policy         : Behaviour when MPC solution is unavailable.
    safe_deceleration_mps2  : Decel for SAFE_DECELERATION fallback (≤ 0).
    """

    enabled:                 bool          = True

    # Steering limits
    min_steering_rad:        float = _DEFAULT_MIN_STEER_RAD
    max_steering_rad:        float = _DEFAULT_MAX_STEER_RAD
    max_steering_rate_rad_s: float = _DEFAULT_MAX_STEER_RATE_RAD_S

    # Longitudinal limits
    min_acceleration_mps2:   float = _DEFAULT_MIN_ACCEL_MPS2
    max_acceleration_mps2:   float = _DEFAULT_MAX_ACCEL_MPS2
    min_speed_mps:           float = _DEFAULT_MIN_SPEED_MPS
    max_speed_mps:           float = _DEFAULT_MAX_SPEED_MPS

    # Braking representation
    brake_threshold_mps2:    float = _DEFAULT_BRAKE_THRESHOLD_MPS2
    max_brake_mps2:          float = _DEFAULT_MAX_BRAKE_MPS2

    # Staleness
    stale_timeout_s:         float = _DEFAULT_STALE_TIMEOUT_S

    # Fallback
    fallback_policy:         FallbackPolicy = _DEFAULT_FALLBACK_POLICY
    safe_deceleration_mps2:  float = _DEFAULT_SAFE_DECEL_MPS2

    # ------------------------------------------------------------------
    # Validation
    # ------------------------------------------------------------------

    def __post_init__(self) -> None:
        self._validate()

    def _validate(self) -> None:
        """Raise ValueError for any invalid configuration."""
        float_fields = {
            "min_steering_rad":        self.min_steering_rad,
            "max_steering_rad":        self.max_steering_rad,
            "max_steering_rate_rad_s": self.max_steering_rate_rad_s,
            "min_acceleration_mps2":   self.min_acceleration_mps2,
            "max_acceleration_mps2":   self.max_acceleration_mps2,
            "min_speed_mps":           self.min_speed_mps,
            "max_speed_mps":           self.max_speed_mps,
            "brake_threshold_mps2":    self.brake_threshold_mps2,
            "max_brake_mps2":          self.max_brake_mps2,
            "stale_timeout_s":         self.stale_timeout_s,
            "safe_deceleration_mps2":  self.safe_deceleration_mps2,
        }
        for name, val in float_fields.items():
            if not isinstance(val, (int, float)) or not math.isfinite(val):
                raise ValueError(
                    f"ControlConfig.{name} must be finite, got {val!r}"
                )

        # Steering range
        if self.min_steering_rad >= 0:
            raise ValueError(
                f"min_steering_rad must be < 0 (got {self.min_steering_rad})"
            )
        if self.max_steering_rad <= 0:
            raise ValueError(
                f"max_steering_rad must be > 0 (got {self.max_steering_rad})"
            )
        if self.min_steering_rad >= self.max_steering_rad:
            raise ValueError(
                f"min_steering_rad ({self.min_steering_rad}) must be "
                f"< max_steering_rad ({self.max_steering_rad})"
            )
        if self.max_steering_rate_rad_s <= 0:
            raise ValueError(
                f"max_steering_rate_rad_s must be > 0 (got {self.max_steering_rate_rad_s})"
            )

        # Acceleration range
        if self.min_acceleration_mps2 >= 0:
            raise ValueError(
                f"min_acceleration_mps2 must be < 0 (got {self.min_acceleration_mps2})"
            )
        if self.max_acceleration_mps2 <= 0:
            raise ValueError(
                f"max_acceleration_mps2 must be > 0 (got {self.max_acceleration_mps2})"
            )

        # Speed range
        if self.min_speed_mps < 0:
            raise ValueError(
                f"min_speed_mps must be >= 0 (got {self.min_speed_mps})"
            )
        if self.max_speed_mps <= self.min_speed_mps:
            raise ValueError(
                f"max_speed_mps ({self.max_speed_mps}) must be > "
                f"min_speed_mps ({self.min_speed_mps})"
            )

        # Braking
        if self.brake_threshold_mps2 < 0:
            raise ValueError(
                f"brake_threshold_mps2 must be >= 0 (got {self.brake_threshold_mps2})"
            )
        if self.max_brake_mps2 <= 0:
            raise ValueError(
                f"max_brake_mps2 must be > 0 (got {self.max_brake_mps2})"
            )

        # Staleness
        if self.stale_timeout_s <= 0:
            raise ValueError(
                f"stale_timeout_s must be > 0 (got {self.stale_timeout_s})"
            )

        # Fallback deceleration
        if self.safe_deceleration_mps2 > 0:
            raise ValueError(
                f"safe_deceleration_mps2 must be <= 0 "
                f"(got {self.safe_deceleration_mps2})"
            )

    # ------------------------------------------------------------------
    # Factory methods
    # ------------------------------------------------------------------

    @classmethod
    def default(cls) -> "ControlConfig":
        """Return the default ControlConfig."""
        return cls()

    @classmethod
    def from_dict(cls, cfg: dict) -> "ControlConfig":
        """
        Build a ControlConfig from a dict (e.g. loaded from YAML).

        Only keys present in *cfg* override defaults.  Missing keys are
        silently ignored so partial configs are safe.

        Expected dict shape (under a 'control' key — caller strips the key)::

            enabled: true
            steering:
              min_angle: -0.610
              max_angle:  0.610
              max_rate:   0.700
            longitudinal:
              min_acceleration: -8.0
              max_acceleration:  4.0
              min_speed:         0.0
              max_speed:        33.33
            braking:
              threshold:   0.05
              max_brake:   8.0
            stale_timeout: 0.5
            fallback:
              policy:            INVALID_COMMAND
              safe_deceleration: -2.0
        """
        def _f(val, default: float) -> float:
            if val is None:
                return default
            return float(val)

        def _sub(key: str) -> dict:
            v = cfg.get(key, {})
            return v if isinstance(v, dict) else {}

        steering     = _sub("steering")
        longitudinal = _sub("longitudinal")
        braking      = _sub("braking")
        fallback_d   = _sub("fallback")

        policy_str = str(fallback_d.get("policy", "INVALID_COMMAND")).upper()
        try:
            policy = FallbackPolicy[policy_str]
        except KeyError:
            policy = FallbackPolicy.INVALID_COMMAND

        return cls(
            enabled                 = bool(cfg.get("enabled", True)),
            min_steering_rad        = _f(steering.get("min_angle"),  _DEFAULT_MIN_STEER_RAD),
            max_steering_rad        = _f(steering.get("max_angle"),  _DEFAULT_MAX_STEER_RAD),
            max_steering_rate_rad_s = _f(steering.get("max_rate"),   _DEFAULT_MAX_STEER_RATE_RAD_S),
            min_acceleration_mps2   = _f(longitudinal.get("min_acceleration"), _DEFAULT_MIN_ACCEL_MPS2),
            max_acceleration_mps2   = _f(longitudinal.get("max_acceleration"), _DEFAULT_MAX_ACCEL_MPS2),
            min_speed_mps           = _f(longitudinal.get("min_speed"),        _DEFAULT_MIN_SPEED_MPS),
            max_speed_mps           = _f(longitudinal.get("max_speed"),        _DEFAULT_MAX_SPEED_MPS),
            brake_threshold_mps2    = _f(braking.get("threshold"),             _DEFAULT_BRAKE_THRESHOLD_MPS2),
            max_brake_mps2          = _f(braking.get("max_brake"),             _DEFAULT_MAX_BRAKE_MPS2),
            stale_timeout_s         = _f(cfg.get("stale_timeout"),             _DEFAULT_STALE_TIMEOUT_S),
            fallback_policy         = policy,
            safe_deceleration_mps2  = _f(fallback_d.get("safe_deceleration"),  _DEFAULT_SAFE_DECEL_MPS2),
        )
