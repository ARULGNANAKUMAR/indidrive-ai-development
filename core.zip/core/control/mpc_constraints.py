"""
IndiDrive AI — Phase 10.3 | MPC Constraints
============================================
Validates that a predicted state/control sequence satisfies all configured
MPC constraints.

Constraints checked
-------------------
Per control step:
    * Steering angle within [min_steering_rad, max_steering_rad]
    * Steering rate  |Δδ / dt| ≤ max_steering_rate_rad_s
    * Acceleration   within [min_acceleration_mps2, max_acceleration_mps2]

Per predicted state:
    * Velocity within [min_velocity_mps, max_velocity_mps]

A sequence is FEASIBLE iff all constraints are satisfied at every step.
A sequence is INFEASIBLE iff any constraint is violated.

Design
------
* Stateless; deterministic.
* Returns a structured ConstraintCheckResult rather than raising.
* Does NOT modify the control sequence or clamp values; that is the
  responsibility of the solver's candidate generator.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import List, Tuple

from .mpc_config import MPCConfig
from .mpc_prediction import MPCControlInput, PredictionResult
from .mpc_types import ConstraintStatus
from ..vehicle.vehicle_state import VehicleState


# ---------------------------------------------------------------------------
# Violation record
# ---------------------------------------------------------------------------

@dataclass
class ConstraintViolation:
    """
    One constraint violation record.

    Fields
    ------
    step_index  : Step at which the violation occurred.
    field       : Name of the violated field (e.g. 'steering_angle').
    value       : Actual value that violated the constraint.
    limit_min   : Minimum allowed value (None if one-sided upper bound).
    limit_max   : Maximum allowed value (None if one-sided lower bound).
    description : Human-readable description.
    """
    step_index:  int
    field:       str
    value:       float
    limit_min:   float | None
    limit_max:   float | None
    description: str = ""


# ---------------------------------------------------------------------------
# Check result
# ---------------------------------------------------------------------------

@dataclass
class ConstraintCheckResult:
    """
    Result of checking a full control/state sequence against MPC constraints.

    Fields
    ------
    status      : SATISFIED or VIOLATED.
    feasible    : True iff status == SATISFIED.
    violations  : List of ConstraintViolation (empty when feasible).
    """
    status:     ConstraintStatus       = ConstraintStatus.SATISFIED
    feasible:   bool                   = True
    violations: List[ConstraintViolation] = field(default_factory=list)

    @classmethod
    def satisfied(cls) -> "ConstraintCheckResult":
        return cls(status=ConstraintStatus.SATISFIED, feasible=True)

    @classmethod
    def violated(cls, violations: List[ConstraintViolation]) -> "ConstraintCheckResult":
        return cls(
            status=ConstraintStatus.VIOLATED,
            feasible=False,
            violations=violations,
        )


# ---------------------------------------------------------------------------
# Constraint checker
# ---------------------------------------------------------------------------

class MPCConstraintChecker:
    """
    Checks a PredictionResult against the configured MPC limits.

    Usage
    -----
    >>> checker = MPCConstraintChecker(config)
    >>> result  = checker.check(prediction, prev_steering=0.0)

    The checker is stateless; multiple instances may share a config.
    """

    def __init__(self, config: MPCConfig) -> None:
        self._cfg = config

    @property
    def config(self) -> MPCConfig:
        return self._cfg

    # ------------------------------------------------------------------ #
    # Public API
    # ------------------------------------------------------------------ #

    def check(
        self,
        prediction:    PredictionResult,
        prev_steering: float = 0.0,
    ) -> ConstraintCheckResult:
        """
        Check the entire prediction sequence against all MPC constraints.

        Parameters
        ----------
        prediction    : PredictionResult to validate.
        prev_steering : Steering angle before the first control step (rad).
                        Used to evaluate the steering-rate constraint at k=0.

        Returns
        -------
        ConstraintCheckResult with status SATISFIED or VIOLATED.
        """
        cfg = self._cfg
        violations: List[ConstraintViolation] = []

        if not prediction.valid:
            # Treat an invalid prediction as infeasible
            violations.append(ConstraintViolation(
                step_index=0,
                field="prediction_valid",
                value=0.0,
                limit_min=None,
                limit_max=None,
                description=f"Prediction is invalid: {prediction.error_message}",
            ))
            return ConstraintCheckResult.violated(violations)

        prev_s = prev_steering

        for k, ctrl in enumerate(prediction.controls):
            s = ctrl.steering_input
            a = ctrl.acceleration_input

            # 1. Steering angle
            if s < cfg.min_steering_rad - 1e-9 or s > cfg.max_steering_rad + 1e-9:
                violations.append(ConstraintViolation(
                    step_index=k,
                    field="steering_input",
                    value=s,
                    limit_min=cfg.min_steering_rad,
                    limit_max=cfg.max_steering_rad,
                    description=(
                        f"Step {k}: steering {math.degrees(s):.2f}° outside "
                        f"[{math.degrees(cfg.min_steering_rad):.1f}°, "
                        f"{math.degrees(cfg.max_steering_rad):.1f}°]"
                    ),
                ))

            # 2. Steering rate
            achieved_rate = abs(s - prev_s) / cfg.dt
            if achieved_rate > cfg.max_steering_rate_rad_s + 1e-9:
                violations.append(ConstraintViolation(
                    step_index=k,
                    field="steering_rate",
                    value=achieved_rate,
                    limit_min=None,
                    limit_max=cfg.max_steering_rate_rad_s,
                    description=(
                        f"Step {k}: steering rate {achieved_rate:.3f} rad/s > "
                        f"limit {cfg.max_steering_rate_rad_s:.3f} rad/s"
                    ),
                ))

            # 3. Acceleration
            if a < cfg.min_acceleration_mps2 - 1e-9 or a > cfg.max_acceleration_mps2 + 1e-9:
                violations.append(ConstraintViolation(
                    step_index=k,
                    field="acceleration_input",
                    value=a,
                    limit_min=cfg.min_acceleration_mps2,
                    limit_max=cfg.max_acceleration_mps2,
                    description=(
                        f"Step {k}: acceleration {a:.3f} m/s² outside "
                        f"[{cfg.min_acceleration_mps2:.1f}, "
                        f"{cfg.max_acceleration_mps2:.1f}] m/s²"
                    ),
                ))

            # 4. Predicted velocity at the corresponding state
            if k + 1 < len(prediction.states):
                state = prediction.states[k + 1]
                v = state.velocity
                if v < cfg.min_velocity_mps - 1e-9 or v > cfg.max_velocity_mps + 1e-9:
                    violations.append(ConstraintViolation(
                        step_index=k,
                        field="velocity",
                        value=v,
                        limit_min=cfg.min_velocity_mps,
                        limit_max=cfg.max_velocity_mps,
                        description=(
                            f"Step {k}: predicted velocity {v:.3f} m/s outside "
                            f"[{cfg.min_velocity_mps:.1f}, "
                            f"{cfg.max_velocity_mps:.1f}] m/s"
                        ),
                    ))

            prev_s = s

        if violations:
            return ConstraintCheckResult.violated(violations)
        return ConstraintCheckResult.satisfied()

    # ------------------------------------------------------------------ #
    # Convenience: check a single control input (no state prediction)
    # ------------------------------------------------------------------ #

    def check_control(
        self,
        steering:      float,
        acceleration:  float,
        prev_steering: float = 0.0,
    ) -> bool:
        """
        Return True iff the single (steering, acceleration) pair satisfies
        all applicable control constraints.

        Does NOT check velocity (no predicted state available).
        """
        cfg = self._cfg

        if not math.isfinite(steering) or not math.isfinite(acceleration):
            return False

        if steering < cfg.min_steering_rad - 1e-9:
            return False
        if steering > cfg.max_steering_rad + 1e-9:
            return False

        rate = abs(steering - prev_steering) / cfg.dt
        if rate > cfg.max_steering_rate_rad_s + 1e-9:
            return False

        if acceleration < cfg.min_acceleration_mps2 - 1e-9:
            return False
        if acceleration > cfg.max_acceleration_mps2 + 1e-9:
            return False

        return True
