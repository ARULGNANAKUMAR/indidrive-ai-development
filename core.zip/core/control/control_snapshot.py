"""
IndiDrive AI — Phase 10.4 | Control Command Snapshot
======================================================
Immutable vehicle-level control command produced by Phase 10.4.

This is the Phase 10.4 public output consumed by Phase 10.5 and later.

The snapshot contains:
    * Command identity (id, timestamp, frame_id, schema_version)
    * Overall command status
    * Steering command (angle, rate, saturation flags, status)
    * Longitudinal command (acceleration, brake, target speed, mode, status)
    * Source identification
    * Reason codes for diagnostics

The snapshot explicitly does NOT contain:
    * Throttle actuator percentage
    * Brake pedal position
    * Steering motor commands
    * CARLA VehicleControl objects
    * CAN bus commands
    * Hardware-specific representations

Those belong to Phase 10.5 and later.

Design
------
* frozen=True: no field can be changed after construction.
* Thread-safe to share across readers.
* All values are validated before construction.
"""
from __future__ import annotations

import math
import time
import uuid
from dataclasses import dataclass, field
from typing import List, Optional, Tuple

from .control_types import (
    CONTROL_NOT_AVAILABLE,
    CONTROL_SCHEMA_VERSION,
    CommandSource,
    ControlCommandStatus,
    LongitudinalMode,
    LongitudinalStatus,
    SteeringStatus,
)
from .steering_controller import SteeringResult
from .speed_controller import LongitudinalResult


# ---------------------------------------------------------------------------
# Control command snapshot
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class VehicleControlCommand:
    """
    Immutable vehicle-level control command from Phase 10.4.

    frozen=True — no field can be changed after construction.

    Identity
    --------
    command_id      : UUID string (unique per command).
    timestamp       : Wall-clock time when command was generated (s).
    frame_id        : Frame counter from the ego state.
    schema_version  : "10.4".

    Steering
    --------
    steering_angle_rad  : Commanded steering angle (rad).
    steering_rate_rad_s : Commanded steering rate (rad/s).
    steering_limited    : True iff MPC steering was clamped by angle limits.
    rate_limited        : True iff steering change was clamped by rate limit.
    steering_status     : SteeringStatus enum.

    Longitudinal
    ------------
    acceleration_mps2  : Commanded acceleration (m/s²).
                         Positive = accelerate; negative = decelerate.
    brake_mps2         : Commanded brake deceleration magnitude (m/s²) ≥ 0.
    target_speed_mps   : Commanded target speed (m/s).
    longitudinal_mode  : Normalised longitudinal mode.
    accel_limited      : True iff MPC acceleration was clamped.
    speed_limited      : True iff target speed was clamped.
    longitudinal_status: LongitudinalStatus enum.

    Overall
    -------
    status          : ControlCommandStatus (overall).
    source          : CommandSource (MPC / HOLD / ZERO / UNKNOWN).
    reason_codes    : Tuple of diagnostic reason strings.
    """

    # Identity
    command_id:     str   = CONTROL_NOT_AVAILABLE
    timestamp:      float = 0.0
    frame_id:       int   = 0
    schema_version: str   = CONTROL_SCHEMA_VERSION

    # Steering
    steering_angle_rad:  float          = 0.0
    steering_rate_rad_s: float          = 0.0
    steering_limited:    bool           = False
    rate_limited:        bool           = False
    steering_status:     SteeringStatus = SteeringStatus.UNKNOWN

    # Longitudinal
    acceleration_mps2:   float             = 0.0
    brake_mps2:          float             = 0.0
    target_speed_mps:    float             = 0.0
    longitudinal_mode:   LongitudinalMode  = LongitudinalMode.UNKNOWN
    accel_limited:       bool              = False
    speed_limited:       bool              = False
    longitudinal_status: LongitudinalStatus = LongitudinalStatus.UNKNOWN

    # Overall
    status:       ControlCommandStatus = ControlCommandStatus.UNKNOWN
    source:       CommandSource         = CommandSource.UNKNOWN
    reason_codes: Tuple[str, ...]       = field(default_factory=tuple)

    # ------------------------------------------------------------------
    # Properties
    # ------------------------------------------------------------------

    @property
    def is_valid(self) -> bool:
        """True iff overall status is VALID or LIMITED."""
        return self.status in (
            ControlCommandStatus.VALID,
            ControlCommandStatus.LIMITED,
        )

    @property
    def is_usable(self) -> bool:
        """Alias for is_valid."""
        return self.is_valid

    @property
    def has_braking(self) -> bool:
        """True iff the brake command is non-zero."""
        return self.brake_mps2 > 0.0

    # ------------------------------------------------------------------
    # Factory methods
    # ------------------------------------------------------------------

    @classmethod
    def from_results(
        cls,
        steering_result:     SteeringResult,
        longitudinal_result: LongitudinalResult,
        frame_id:            int = 0,
        source:              CommandSource = CommandSource.MPC,
    ) -> "VehicleControlCommand":
        """
        Build a VehicleControlCommand from steering and longitudinal results.

        Parameters
        ----------
        steering_result     : Output of SteeringController.compute().
        longitudinal_result : Output of SpeedController.compute().
        frame_id            : Ego state frame counter.
        source              : Command source (default: MPC).
        """
        now        = time.monotonic()
        cmd_id     = str(uuid.uuid4())
        reasons: List[str] = []

        if steering_result.reason:
            reasons.append(f"[STEER] {steering_result.reason}")
        if longitudinal_result.reason:
            reasons.append(f"[LONG] {longitudinal_result.reason}")

        overall_status = _derive_overall_status(
            steering_result, longitudinal_result
        )

        return cls(
            command_id           = cmd_id,
            timestamp            = now,
            frame_id             = frame_id,
            schema_version       = CONTROL_SCHEMA_VERSION,
            # Steering
            steering_angle_rad   = steering_result.steering_angle_rad,
            steering_rate_rad_s  = steering_result.steering_rate_rad_s,
            steering_limited     = steering_result.steering_limited,
            rate_limited         = steering_result.rate_limited,
            steering_status      = steering_result.status,
            # Longitudinal
            acceleration_mps2    = longitudinal_result.acceleration_mps2,
            brake_mps2           = longitudinal_result.brake_mps2,
            target_speed_mps     = longitudinal_result.target_speed_mps,
            longitudinal_mode    = longitudinal_result.longitudinal_mode,
            accel_limited        = longitudinal_result.accel_limited,
            speed_limited        = longitudinal_result.speed_limited,
            longitudinal_status  = longitudinal_result.status,
            # Overall
            status               = overall_status,
            source               = source,
            reason_codes         = tuple(reasons),
        )

    @classmethod
    def invalid(
        cls,
        reason: str,
        frame_id: int = 0,
        source: CommandSource = CommandSource.UNKNOWN,
    ) -> "VehicleControlCommand":
        """
        Build an explicit INVALID control command.

        Use when MPC input is unavailable, stale, or infeasible.
        """
        now    = time.monotonic()
        cmd_id = str(uuid.uuid4())
        return cls(
            command_id           = cmd_id,
            timestamp            = now,
            frame_id             = frame_id,
            schema_version       = CONTROL_SCHEMA_VERSION,
            steering_angle_rad   = 0.0,
            steering_rate_rad_s  = 0.0,
            steering_limited     = False,
            rate_limited         = False,
            steering_status      = SteeringStatus.NO_MPC_SOLUTION,
            acceleration_mps2    = 0.0,
            brake_mps2           = 0.0,
            target_speed_mps     = 0.0,
            longitudinal_mode    = LongitudinalMode.UNKNOWN,
            accel_limited        = False,
            speed_limited        = False,
            longitudinal_status  = LongitudinalStatus.NO_MPC_SOLUTION,
            status               = ControlCommandStatus.NO_SOLUTION,
            source               = source,
            reason_codes         = (f"[INVALID] {reason}",),
        )

    @classmethod
    def stale(
        cls,
        reason: str,
        frame_id: int = 0,
    ) -> "VehicleControlCommand":
        """Build an explicit STALE control command."""
        now    = time.monotonic()
        cmd_id = str(uuid.uuid4())
        return cls(
            command_id           = cmd_id,
            timestamp            = now,
            frame_id             = frame_id,
            schema_version       = CONTROL_SCHEMA_VERSION,
            steering_angle_rad   = 0.0,
            steering_rate_rad_s  = 0.0,
            steering_limited     = False,
            rate_limited         = False,
            steering_status      = SteeringStatus.STALE_MPC,
            acceleration_mps2    = 0.0,
            brake_mps2           = 0.0,
            target_speed_mps     = 0.0,
            longitudinal_mode    = LongitudinalMode.UNKNOWN,
            accel_limited        = False,
            speed_limited        = False,
            longitudinal_status  = LongitudinalStatus.STALE_MPC,
            status               = ControlCommandStatus.STALE,
            source               = CommandSource.UNKNOWN,
            reason_codes         = (f"[STALE] {reason}",),
        )

    @classmethod
    def zero(cls, frame_id: int = 0) -> "VehicleControlCommand":
        """Build an all-zero safe command (initialisation / explicit safe hold)."""
        now    = time.monotonic()
        cmd_id = str(uuid.uuid4())
        return cls(
            command_id           = cmd_id,
            timestamp            = now,
            frame_id             = frame_id,
            schema_version       = CONTROL_SCHEMA_VERSION,
            steering_angle_rad   = 0.0,
            steering_rate_rad_s  = 0.0,
            steering_limited     = False,
            rate_limited         = False,
            steering_status      = SteeringStatus.VALID,
            acceleration_mps2    = 0.0,
            brake_mps2           = 0.0,
            target_speed_mps     = 0.0,
            longitudinal_mode    = LongitudinalMode.COAST,
            accel_limited        = False,
            speed_limited        = False,
            longitudinal_status  = LongitudinalStatus.VALID,
            status               = ControlCommandStatus.VALID,
            source               = CommandSource.ZERO,
            reason_codes         = (),
        )

    # ------------------------------------------------------------------
    # Repr
    # ------------------------------------------------------------------

    def __repr__(self) -> str:
        return (
            f"VehicleControlCommand("
            f"status={self.status.value}, "
            f"δ={math.degrees(self.steering_angle_rad):.1f}°, "
            f"a={self.acceleration_mps2:.2f} m/s², "
            f"brake={self.brake_mps2:.2f} m/s², "
            f"v_tgt={self.target_speed_mps:.2f} m/s, "
            f"src={self.source.value})"
        )


# ---------------------------------------------------------------------------
# Helper: derive overall status from sub-command results
# ---------------------------------------------------------------------------


def _derive_overall_status(
    steer: SteeringResult,
    longi: LongitudinalResult,
) -> ControlCommandStatus:
    """
    Derive the overall ControlCommandStatus from sub-results.

    Rules (in priority order):
    1. Either sub-command is NO_MPC_SOLUTION → NO_SOLUTION
    2. Either sub-command is STALE_MPC       → STALE
    3. Either sub-command is INVALID_INPUT / CONSTRAINT_VIOLATION → INVALID
    4. Both VALID                            → VALID
    5. Either LIMITED / RATE_LIMITED         → LIMITED
    6. Either DEGRADED                       → DEGRADED
    7. Otherwise                             → UNKNOWN
    """
    s_status = steer.status
    l_status = longi.status

    _no_sol = {SteeringStatus.NO_MPC_SOLUTION, LongitudinalStatus.NO_MPC_SOLUTION}
    _stale  = {SteeringStatus.STALE_MPC, LongitudinalStatus.STALE_MPC}
    _inv    = {
        SteeringStatus.INVALID_INPUT,
        SteeringStatus.CONSTRAINT_VIOLATION,
        LongitudinalStatus.INVALID_INPUT,
        LongitudinalStatus.CONSTRAINT_VIOLATION,
    }
    _limited = {
        SteeringStatus.LIMITED,
        SteeringStatus.RATE_LIMITED,
        LongitudinalStatus.LIMITED,
    }
    _degraded = {
        SteeringStatus.DEGRADED,
        LongitudinalStatus.DEGRADED,
    }

    if s_status in _no_sol or l_status in _no_sol:
        return ControlCommandStatus.NO_SOLUTION
    if s_status in _stale or l_status in _stale:
        return ControlCommandStatus.STALE
    if s_status in _inv or l_status in _inv:
        return ControlCommandStatus.INVALID
    if (s_status == SteeringStatus.VALID
            and l_status == LongitudinalStatus.VALID):
        return ControlCommandStatus.VALID
    if s_status in _limited or l_status in _limited:
        return ControlCommandStatus.LIMITED
    if s_status in _degraded or l_status in _degraded:
        return ControlCommandStatus.DEGRADED

    return ControlCommandStatus.UNKNOWN
