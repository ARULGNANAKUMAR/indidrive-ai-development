"""
IndiDrive AI — Phase 10.3 | MPC Types — Enums and Constants
============================================================
Shared enumerations, sentinels, and schema version for the MPC controller.

Nothing here performs computation; all values are structural.

Architecture position:
    Phase 9.6 Final Planner
            ↓
    Phase 10.1 Vehicle Dynamics
            ↓
    Phase 10.2 Trajectory Tracking
            ↓
    Phase 10.3 MPC Controller Core  ← this module (types only)
            ↓
    Phase 10.4 Steering / Speed Control (future)
            ↓
    Phase 10.5 Planner → MPC Integration (future)

Coordinate convention (project-wide):
    +X = forward, +Y = left, +Z = up
    Origin = vehicle rear-axle centre
    Units  = metres, radians, seconds, m/s, m/s²
"""
from __future__ import annotations

from enum import Enum

# ---------------------------------------------------------------------------
# Schema version
# ---------------------------------------------------------------------------

MPC_SCHEMA_VERSION: str = "10.3"

# Sentinel for optional / unavailable fields
MPC_NOT_AVAILABLE: str = "NOT_AVAILABLE"

# ---------------------------------------------------------------------------
# MPC solution status
# ---------------------------------------------------------------------------

class MPCStatus(str, Enum):
    """
    Explicit status of one MPC solve cycle.

    SUCCESS              — Feasible solution found; first_control is valid.
    NO_FEASIBLE_SOLUTION — No candidate sequence satisfied all constraints.
    INVALID_INPUT        — ego state or reference failed basic validation.
    STALE_REFERENCE      — Reference trajectory timestamp is too old.
    INVALID_REFERENCE    — Reference trajectory is structurally invalid.
    CONSTRAINT_VIOLATION — The returned solution violates a hard constraint
                           (internal consistency error — should not occur
                           in normal operation).
    DEGRADED             — Solution found but with reduced horizon or
                           relaxed constraints; use with caution.
    SOLVER_LIMIT_REACHED — Max iterations exhausted before convergence;
                           best feasible candidate is returned if available.
    UNKNOWN              — Status cannot be determined.
    """
    SUCCESS              = "SUCCESS"
    NO_FEASIBLE_SOLUTION = "NO_FEASIBLE_SOLUTION"
    INVALID_INPUT        = "INVALID_INPUT"
    STALE_REFERENCE      = "STALE_REFERENCE"
    INVALID_REFERENCE    = "INVALID_REFERENCE"
    CONSTRAINT_VIOLATION = "CONSTRAINT_VIOLATION"
    DEGRADED             = "DEGRADED"
    SOLVER_LIMIT_REACHED = "SOLVER_LIMIT_REACHED"
    UNKNOWN              = "UNKNOWN"


# ---------------------------------------------------------------------------
# Constraint status
# ---------------------------------------------------------------------------

class ConstraintStatus(str, Enum):
    """
    Whether a candidate control sequence satisfies all configured constraints.

    SATISFIED  — All constraints satisfied.
    VIOLATED   — At least one constraint violated; sequence is infeasible.
    UNCHECKED  — Constraint check not yet performed.
    """
    SATISFIED = "SATISFIED"
    VIOLATED  = "VIOLATED"
    UNCHECKED = "UNCHECKED"


# ---------------------------------------------------------------------------
# Solver strategy
# ---------------------------------------------------------------------------

class SolverStrategy(str, Enum):
    """
    Deterministic candidate-search strategy used by the lightweight solver.

    GRID_SEARCH — Enumerate a regular grid of (steering, acceleration)
                  samples per timestep, predict each, keep lowest-cost
                  feasible sequence.  Simple, bounded, deterministic.
    ITERATIVE   — Start from the previous solution (warm start), then
                  refine via bounded gradient-free perturbations.
                  Falls back to GRID_SEARCH if no prior solution.
    """
    GRID_SEARCH = "GRID_SEARCH"
    ITERATIVE   = "ITERATIVE"
