"""
IndiDrive AI — Phase 10.3 | MPC Validator
==========================================
Validation utilities for MPC inputs and configuration.

Validates:
    * MPCConfig fields
    * VehicleState (delegates to Phase 10.1 validate())
    * ReferenceTrajectory (structure and content)
    * Control bounds
    * Horizon / dt

Returns structured ValidationResult rather than raising, so callers
can decide how to handle failures.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import List, Optional

from .mpc_config import MPCConfig
from ..tracking.reference_trajectory import ReferenceTrajectory
from ..vehicle.vehicle_state import VehicleState


# ---------------------------------------------------------------------------
# Validation result
# ---------------------------------------------------------------------------

@dataclass
class ValidationResult:
    """
    Result of one validation check.

    Fields
    ------
    valid   : True iff no issues found.
    issues  : List of human-readable issue strings (empty if valid).
    """
    valid:  bool = True
    issues: List[str] = field(default_factory=list)

    def add(self, msg: str) -> None:
        self.issues.append(msg)
        self.valid = False

    def __repr__(self) -> str:
        if self.valid:
            return "ValidationResult(VALID)"
        return f"ValidationResult(INVALID, {len(self.issues)} issues: {self.issues[:2]})"


# ---------------------------------------------------------------------------
# Validator
# ---------------------------------------------------------------------------

class MPCValidator:
    """
    Stateless validation utilities for Phase 10.3 MPC inputs.

    All methods return ValidationResult.  They do NOT raise.
    """

    # ------------------------------------------------------------------ #
    # Config validation
    # ------------------------------------------------------------------ #

    @staticmethod
    def validate_config(config: MPCConfig) -> ValidationResult:
        """
        Validate an MPCConfig object.

        The MPCConfig dataclass already validates in __post_init__, so
        this method is primarily useful for catching configurations that
        were constructed with object.__setattr__ bypasses or for providing
        richer diagnostic messages.
        """
        result = ValidationResult()

        if config is None:
            result.add("MPCConfig is None")
            return result

        # Horizon
        if not isinstance(config.prediction_horizon, int) or config.prediction_horizon < 1:
            result.add(
                f"prediction_horizon must be int ≥ 1, got {config.prediction_horizon!r}"
            )
        if not math.isfinite(config.dt) or config.dt <= 0.0:
            result.add(f"dt must be finite and > 0, got {config.dt}")

        # Weights
        for wname, wval in [
            ("w_cross_track",       config.w_cross_track),
            ("w_along_track",       config.w_along_track),
            ("w_heading",           config.w_heading),
            ("w_speed",             config.w_speed),
            ("w_steering",          config.w_steering),
            ("w_acceleration",      config.w_acceleration),
            ("w_steering_rate",     config.w_steering_rate),
            ("w_acceleration_rate", config.w_acceleration_rate),
            ("w_terminal",          config.w_terminal),
        ]:
            if not isinstance(wval, (int, float)) or not math.isfinite(wval):
                result.add(f"{wname} must be finite, got {wval!r}")
            elif wval < 0.0:
                result.add(f"{wname} must be ≥ 0, got {wval}")

        # Steering limits
        if not math.isfinite(config.min_steering_rad) or config.min_steering_rad > 0.0:
            result.add(
                f"min_steering_rad must be finite and ≤ 0, got {config.min_steering_rad}"
            )
        if not math.isfinite(config.max_steering_rad) or config.max_steering_rad < 0.0:
            result.add(
                f"max_steering_rad must be finite and ≥ 0, got {config.max_steering_rad}"
            )
        if (math.isfinite(config.min_steering_rad)
                and math.isfinite(config.max_steering_rad)
                and config.max_steering_rad <= config.min_steering_rad):
            result.add(
                f"max_steering_rad ({config.max_steering_rad}) must be > "
                f"min_steering_rad ({config.min_steering_rad})"
            )
        if not math.isfinite(config.max_steering_rate_rad_s) or config.max_steering_rate_rad_s <= 0.0:
            result.add(
                f"max_steering_rate_rad_s must be finite and > 0, "
                f"got {config.max_steering_rate_rad_s}"
            )

        # Acceleration limits
        if not math.isfinite(config.min_acceleration_mps2) or config.min_acceleration_mps2 >= 0.0:
            result.add(
                f"min_acceleration_mps2 must be finite and < 0, "
                f"got {config.min_acceleration_mps2}"
            )
        if not math.isfinite(config.max_acceleration_mps2) or config.max_acceleration_mps2 <= 0.0:
            result.add(
                f"max_acceleration_mps2 must be finite and > 0, "
                f"got {config.max_acceleration_mps2}"
            )

        # Velocity limits
        if not math.isfinite(config.min_velocity_mps) or config.min_velocity_mps < 0.0:
            result.add(
                f"min_velocity_mps must be finite and ≥ 0, got {config.min_velocity_mps}"
            )
        if not math.isfinite(config.max_velocity_mps):
            result.add(f"max_velocity_mps must be finite, got {config.max_velocity_mps}")
        elif config.max_velocity_mps <= config.min_velocity_mps:
            result.add(
                f"max_velocity_mps ({config.max_velocity_mps}) must be > "
                f"min_velocity_mps ({config.min_velocity_mps})"
            )

        # Solver params
        if not isinstance(config.max_iterations, int) or config.max_iterations < 1:
            result.add(f"max_iterations must be int ≥ 1, got {config.max_iterations!r}")
        if not isinstance(config.steering_samples, int) or config.steering_samples < 2:
            result.add(f"steering_samples must be int ≥ 2, got {config.steering_samples!r}")
        if not isinstance(config.acceleration_samples, int) or config.acceleration_samples < 2:
            result.add(
                f"acceleration_samples must be int ≥ 2, "
                f"got {config.acceleration_samples!r}"
            )

        return result

    # ------------------------------------------------------------------ #
    # State validation
    # ------------------------------------------------------------------ #

    @staticmethod
    def validate_state(state: Optional[VehicleState]) -> ValidationResult:
        """Validate a VehicleState for MPC use."""
        result = ValidationResult()

        if state is None:
            result.add("VehicleState is None")
            return result

        try:
            state.validate()
        except (ValueError, TypeError) as e:
            result.add(f"VehicleState.validate() failed: {e}")
            return result

        if not state.is_finite():
            result.add("VehicleState has non-finite field(s)")

        return result

    # ------------------------------------------------------------------ #
    # Reference trajectory validation
    # ------------------------------------------------------------------ #

    @staticmethod
    def validate_reference(
        reference:    Optional[ReferenceTrajectory],
        min_points:   int = 1,
        current_time: Optional[float] = None,
        max_age_s:    Optional[float] = None,
    ) -> ValidationResult:
        """
        Validate a ReferenceTrajectory for MPC consumption.

        Parameters
        ----------
        reference    : Trajectory to validate.
        min_points   : Minimum number of points required.
        current_time : If provided with max_age_s, checks staleness.
        max_age_s    : Maximum allowed age of the reference (s).
        """
        result = ValidationResult()

        if reference is None:
            result.add("ReferenceTrajectory is None")
            return result

        if reference.is_empty:
            result.add("ReferenceTrajectory is empty (no points)")
            return result

        if reference.length < min_points:
            result.add(
                f"ReferenceTrajectory has {reference.length} points; "
                f"need ≥ {min_points}"
            )

        # Check all points have finite positions
        bad_points = []
        for i, pt in enumerate(reference.points):
            if not pt.is_position_finite():
                bad_points.append(i)
        if bad_points:
            result.add(
                f"ReferenceTrajectory has non-finite position at "
                f"point indices: {bad_points[:5]}"
            )

        # Staleness check
        if current_time is not None and max_age_s is not None:
            if math.isfinite(reference.timestamp) and reference.timestamp > 0:
                age = current_time - reference.timestamp
                if age > max_age_s:
                    result.add(
                        f"ReferenceTrajectory is stale: age={age:.2f}s > "
                        f"max_age_s={max_age_s:.2f}s"
                    )

        return result

    # ------------------------------------------------------------------ #
    # Horizon / dt validation
    # ------------------------------------------------------------------ #

    @staticmethod
    def validate_horizon(horizon: int, dt: float) -> ValidationResult:
        """Validate prediction horizon and timestep."""
        result = ValidationResult()
        if not isinstance(horizon, int) or horizon < 1:
            result.add(f"horizon must be int ≥ 1, got {horizon!r}")
        if not math.isfinite(dt) or dt <= 0.0:
            result.add(f"dt must be finite and > 0, got {dt}")
        return result
