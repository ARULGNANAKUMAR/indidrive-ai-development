"""
IndiDrive AI — Phase 10.3 | MPC Controller Core
================================================
Top-level Phase 10.3 entry point.

MPCController.solve() takes:
    * current ego VehicleState  (Phase 10.1)
    * ReferenceTrajectory       (Phase 10.2 / 9.6)
    * optional previous controls (for warm-start and rate cost)

and returns an MPCSnapshot containing:
    * MPC status and feasibility
    * first_steering_input / first_acceleration_input
      (mathematical MPC variables — NOT actuator commands)
    * predicted state sequence over the horizon
    * full cost breakdown
    * solver diagnostics

Architecture position:
    Phase 9.6 Final Planner
            ↓
    Phase 10.1 Vehicle Dynamics  (VehicleState, bicycle model)
            ↓
    Phase 10.2 Trajectory Tracking (ReferenceTrajectory, TrackingSnapshot)
            ↓
    MPCController.solve()           ← Phase 10.3
            ↓
    MPCSnapshot
            ↓
    Phase 10.4 Steering / Speed Control (future)
            ↓
    Phase 10.5 Planner → MPC Integration (future)
            ↓
    CARLA Closed-Loop Control (future)

This module does NOT:
    * generate or select paths
    * implement PID, Pure Pursuit, Stanley, or LQR controllers
    * send actuator commands to CARLA
    * implement throttle / brake actuators
    * implement CAN bus commands
    * perform trajectory replanning
    * implement the actuator execution loop (Phase 10.4)
    * implement planner integration (Phase 10.5)

Design
------
* Stateless computation: no hidden mutable state.
* Deterministic: same (state, reference, config) → same snapshot.
* Thread-safe: multiple callers may share one controller instance.
"""
from __future__ import annotations

import math
from typing import Optional

from .mpc_config import MPCConfig
from .mpc_snapshot import MPCSnapshot
from .mpc_solver import MPCSolver
from .mpc_types import MPCStatus
from .mpc_validator import MPCValidator
from ..tracking.reference_trajectory import ReferenceTrajectory
from ..vehicle.vehicle_parameters import VehicleParameters
from ..vehicle.vehicle_state import VehicleState


class MPCController:
    """
    Phase 10.3 MPC Controller Core.

    Usage
    -----
    >>> config  = MPCConfig.default()
    >>> params  = VehicleParameters.default()
    >>> ctrl    = MPCController(config, params)
    >>> snap    = ctrl.solve(
    ...     ego_state         = vehicle_state,
    ...     reference         = reference_trajectory,
    ...     prev_steering     = 0.0,
    ...     prev_acceleration = 0.0,
    ... )
    >>> # Receding-horizon: use first control for this cycle
    >>> steer = snap.first_steering_input     # rad (mathematical, NOT actuator)
    >>> accel = snap.first_acceleration_input # m/s² (mathematical, NOT actuator)

    The controller is stateless: it does not retain results between calls.
    Callers are responsible for passing the previous control inputs.
    """

    def __init__(
        self,
        config:         Optional[MPCConfig]         = None,
        vehicle_params: Optional[VehicleParameters] = None,
    ) -> None:
        """
        Initialise the MPC controller.

        Parameters
        ----------
        config         : MPCConfig (frozen).  Uses default if None.
        vehicle_params : VehicleParameters for the bicycle model.
                         Uses VehicleParameters.default() if None.
                         Should match the Phase 10.1 configuration.
        """
        self._cfg    = config if config is not None else MPCConfig.default()
        self._params = vehicle_params if vehicle_params is not None \
                       else VehicleParameters.default()
        self._solver = MPCSolver(self._cfg, self._params)

    # ------------------------------------------------------------------ #
    # Properties
    # ------------------------------------------------------------------ #

    @property
    def config(self) -> MPCConfig:
        return self._cfg

    @property
    def vehicle_params(self) -> VehicleParameters:
        return self._params

    # ------------------------------------------------------------------ #
    # Primary API — receding-horizon solve
    # ------------------------------------------------------------------ #

    def solve(
        self,
        ego_state:         VehicleState,
        reference:         ReferenceTrajectory,
        prev_steering:     float = 0.0,
        prev_acceleration: float = 0.0,
    ) -> MPCSnapshot:
        """
        Run one MPC optimisation cycle (receding horizon).

        Parameters
        ----------
        ego_state         : Current vehicle state from Phase 10.1.
        reference         : Reference trajectory from Phase 9.6 / 10.2.
        prev_steering     : Steering angle applied in the previous cycle (rad).
                            Used for steering-rate cost and constraint.
        prev_acceleration : Acceleration in the previous cycle (m/s²).
                            Used for acceleration-rate cost.

        Returns
        -------
        MPCSnapshot (immutable, thread-safe).

        Receding-horizon usage
        ----------------------
        Each call optimises over the full horizon and returns the complete
        predicted trajectory.  The caller uses only:
            snap.first_steering_input
            snap.first_acceleration_input
        as the control for the current cycle, then re-calls solve() at the
        next timestep with the updated ego state and (optionally) an updated
        reference.

        The complete predicted_states tuple is available for diagnosis,
        visualisation, and Phase 10.4 feed-forward.

        Notes on first_steering_input / first_acceleration_input
        ---------------------------------------------------------
        These are the mathematical MPC optimisation variables.
        They are NOT:
            * throttle actuator percentage
            * brake actuator percentage
            * steering actuator command
            * CARLA VehicleControl fields
        Phase 10.4 will convert them to actuator-level commands.
        """
        cfg = self._cfg

        # --- Input validation ---
        state_check = MPCValidator.validate_state(ego_state)
        if not state_check.valid:
            return MPCSnapshot.failure(
                status=MPCStatus.INVALID_INPUT,
                message=f"Invalid ego_state: {'; '.join(state_check.issues)}",
                ego_state=ego_state,
                dt=cfg.dt,
                horizon=cfg.prediction_horizon,
            )

        ref_check = MPCValidator.validate_reference(
            reference,
            min_points=1,
            current_time=ego_state.timestamp if ego_state else None,
            max_age_s=cfg.max_reference_age_s,
        )
        if not ref_check.valid:
            # Distinguish stale from structurally invalid
            status = MPCStatus.INVALID_REFERENCE
            for issue in ref_check.issues:
                if "stale" in issue.lower():
                    status = MPCStatus.STALE_REFERENCE
                    break
            return MPCSnapshot.failure(
                status=status,
                message=f"Invalid reference: {'; '.join(ref_check.issues)}",
                ego_state=ego_state,
                dt=cfg.dt,
                horizon=cfg.prediction_horizon,
            )

        if not math.isfinite(prev_steering) or not math.isfinite(prev_acceleration):
            return MPCSnapshot.failure(
                status=MPCStatus.INVALID_INPUT,
                message=(
                    f"Non-finite previous controls: "
                    f"δ={prev_steering}, a={prev_acceleration}"
                ),
                ego_state=ego_state,
                dt=cfg.dt,
                horizon=cfg.prediction_horizon,
            )

        # --- Delegate to solver ---
        solver_result = self._solver.solve(
            ego_state=ego_state,
            reference=reference,
            prev_steering=prev_steering,
            prev_acceleration=prev_acceleration,
        )

        # --- Wrap in snapshot ---
        return MPCSnapshot.from_solver_result(
            solver_result=solver_result,
            ego_state=ego_state,
            dt=cfg.dt,
            horizon=cfg.prediction_horizon,
        )
