"""
IndiDrive AI — Phase 10.4 | Steering Controller
=================================================
Converts the Phase 10.3 MPC steering solution into a bounded, validated
steering command.

Responsibilities
----------------
1. Read the MPC first_steering_input (mathematical optimisation variable).
2. Apply configured steering-angle limits (clamp with saturation flag).
3. Apply steering-rate limits using the previous steering value and dt.
4. Validate the resulting command.
5. Return a deterministic SteeringResult.

This module does NOT:
    * Run a PID, Pure Pursuit, Stanley, or LQR controller.
    * Plan a path or trajectory.
    * Send commands to CARLA or hardware.
    * Access external services or networks.

Coordinate convention:
    Steering angle: radians, positive = left turn (same as project convention).
    +X = forward, +Y = left, +Z = up.

Determinism:
    Same (mpc_steering, prev_steering, dt, config) → same result.
    No random values.

Thread safety:
    Stateless computation — same input always produces same output.
    Mutable previous-steering state is owned by the caller (ControlManager).
"""
from __future__ import annotations

import math
import time
import uuid
from dataclasses import dataclass, field
from typing import Optional

from .control_config import ControlConfig
from .control_types import (
    CONTROL_NOT_AVAILABLE,
    CONTROL_SCHEMA_VERSION,
    SteeringStatus,
)


# ---------------------------------------------------------------------------
# Result type
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class SteeringResult:
    """
    Immutable result of one steering-command generation cycle.

    Fields
    ------
    steering_angle_rad  : Commanded steering angle (rad), within limits.
    steering_rate_rad_s : Commanded steering rate (rad/s), or 0.0 if
                          dt was zero/invalid or first cycle.
    steering_limited    : True iff the MPC angle was clamped by min/max limits.
    rate_limited        : True iff the steering change was clamped by rate limit.
    status              : SteeringStatus enum.
    reason              : Human-readable diagnostic string.
    schema_version      : "10.4"
    """
    steering_angle_rad:  float         = 0.0
    steering_rate_rad_s: float         = 0.0
    steering_limited:    bool          = False
    rate_limited:        bool          = False
    status:              SteeringStatus = SteeringStatus.UNKNOWN
    reason:              str           = ""
    schema_version:      str           = CONTROL_SCHEMA_VERSION

    @property
    def is_valid(self) -> bool:
        """True iff status is VALID, LIMITED, or RATE_LIMITED."""
        return self.status in (
            SteeringStatus.VALID,
            SteeringStatus.LIMITED,
            SteeringStatus.RATE_LIMITED,
        )

    @property
    def is_usable(self) -> bool:
        """Alias for is_valid — indicates command is safe to apply."""
        return self.is_valid

    def __repr__(self) -> str:
        return (
            f"SteeringResult("
            f"δ={math.degrees(self.steering_angle_rad):.2f}°, "
            f"rate={math.degrees(self.steering_rate_rad_s):.2f}°/s, "
            f"limited={self.steering_limited}, "
            f"rate_limited={self.rate_limited}, "
            f"status={self.status.value})"
        )


# ---------------------------------------------------------------------------
# Steering controller
# ---------------------------------------------------------------------------


class SteeringController:
    """
    Converts the MPC steering solution into a bounded steering command.

    Stateless computation — the previous steering value is passed in as an
    argument rather than stored internally.  The ControlManager owns state.

    Usage
    -----
    ::

        cfg = ControlConfig.default()
        ctrl = SteeringController(cfg)
        result = ctrl.compute(
            mpc_steering_rad   = snapshot.first_steering_input,
            prev_steering_rad  = previous_steering,   # None on first cycle
            dt                 = 0.1,
        )
    """

    def __init__(self, config: ControlConfig) -> None:
        if not isinstance(config, ControlConfig):
            raise TypeError(
                f"SteeringController requires ControlConfig, got {type(config)}"
            )
        self._cfg = config

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def compute(
        self,
        mpc_steering_rad:  float,
        prev_steering_rad: Optional[float],
        dt:                float,
    ) -> SteeringResult:
        """
        Compute a bounded steering command from the MPC steering variable.

        Parameters
        ----------
        mpc_steering_rad  : MPC first_steering_input (rad).  Must be finite.
        prev_steering_rad : Previous commanded steering angle (rad), or None
                            for the first control cycle.
        dt                : Time elapsed since the previous command (s).

        Returns
        -------
        SteeringResult — always returns a valid structure, never raises.

        Notes
        -----
        The pipeline is:
            1. Validate mpc_steering_rad (finite check).
            2. Clamp to [min_steering_rad, max_steering_rad].
            3. Apply rate limit using prev_steering_rad and dt.
            4. Determine status.
        """
        cfg = self._cfg

        # ----------------------------------------------------------------
        # Step 1: validate MPC input
        # ----------------------------------------------------------------
        if not math.isfinite(mpc_steering_rad):
            return SteeringResult(
                steering_angle_rad  = 0.0,
                steering_rate_rad_s = 0.0,
                steering_limited    = False,
                rate_limited        = False,
                status              = SteeringStatus.INVALID_INPUT,
                reason              = (
                    f"MPC steering input is non-finite: {mpc_steering_rad}"
                ),
            )

        # ----------------------------------------------------------------
        # Step 2: angle saturation
        # ----------------------------------------------------------------
        clamped_angle  = max(cfg.min_steering_rad,
                             min(cfg.max_steering_rad, mpc_steering_rad))
        angle_limited  = (clamped_angle != mpc_steering_rad)

        # ----------------------------------------------------------------
        # Step 3: steering-rate limiting
        # ----------------------------------------------------------------
        rate_limited   = False
        steering_rate  = 0.0
        final_angle    = clamped_angle

        # Rate limiting is only meaningful when:
        #   * A previous steering value is available (not first cycle).
        #   * dt is positive and finite.
        if prev_steering_rad is not None and math.isfinite(prev_steering_rad):
            if math.isfinite(dt) and dt > 0.0:
                max_delta = cfg.max_steering_rate_rad_s * dt
                delta     = final_angle - prev_steering_rad
                if abs(delta) > max_delta:
                    # Clamp the steering change
                    clamped_delta = math.copysign(max_delta, delta)
                    final_angle   = prev_steering_rad + clamped_delta
                    # Re-clamp to absolute limits after rate limiting
                    final_angle   = max(cfg.min_steering_rad,
                                        min(cfg.max_steering_rad, final_angle))
                    rate_limited  = True
                # Compute the actual rate
                actual_delta  = final_angle - prev_steering_rad
                steering_rate = actual_delta / dt
            # dt == 0 or non-finite: no rate limiting, keep angle, rate = 0
            # (safe — do not divide by zero)
        # prev is None (first cycle): no rate limiting, rate = 0

        # ----------------------------------------------------------------
        # Step 4: determine status
        # ----------------------------------------------------------------
        if rate_limited and angle_limited:
            # Both limits fired; report rate as primary (more restrictive)
            status = SteeringStatus.RATE_LIMITED
            reason = (
                f"Steering angle clamped from {math.degrees(mpc_steering_rad):.2f}° "
                f"and rate-limited."
            )
        elif rate_limited:
            status = SteeringStatus.RATE_LIMITED
            reason = (
                f"Steering rate limited; requested Δδ would exceed "
                f"{math.degrees(cfg.max_steering_rate_rad_s * (dt or 0.0)):.2f}° "
                f"in {dt:.3f}s."
            )
        elif angle_limited:
            status = SteeringStatus.LIMITED
            reason = (
                f"Steering clamped from {math.degrees(mpc_steering_rad):.2f}° "
                f"to [{math.degrees(cfg.min_steering_rad):.1f}°, "
                f"{math.degrees(cfg.max_steering_rad):.1f}°]."
            )
        else:
            status = SteeringStatus.VALID
            reason = ""

        # Final finite check (should always be true here)
        if not math.isfinite(final_angle) or not math.isfinite(steering_rate):
            return SteeringResult(
                steering_angle_rad  = 0.0,
                steering_rate_rad_s = 0.0,
                steering_limited    = False,
                rate_limited        = False,
                status              = SteeringStatus.INVALID_INPUT,
                reason              = "Steering output became non-finite after limiting.",
            )

        return SteeringResult(
            steering_angle_rad  = final_angle,
            steering_rate_rad_s = steering_rate,
            steering_limited    = angle_limited,
            rate_limited        = rate_limited,
            status              = status,
            reason              = reason,
        )
