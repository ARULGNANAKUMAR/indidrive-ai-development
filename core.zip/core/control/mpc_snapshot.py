"""
IndiDrive AI — Phase 10.3 | MPC Snapshot
=========================================
Immutable result snapshot from one MPC solve cycle.

The snapshot is the Phase 10.3 public output.  It is consumed by:
    Phase 10.4 — Steering / Speed Control (future)
    Phase 10.5 — Planner → MPC Integration (future)

The snapshot contains:
    * Solution identity (id, timestamp, frame_id, schema_version)
    * MPC status and feasibility flag
    * First control input (the mathematically optimal steering/acceleration
      for the current cycle)
    * Complete predicted state sequence (horizon states)
    * Complete control sequence used
    * Cost breakdown
    * Constraint status
    * Solver diagnostics

The snapshot explicitly does NOT contain:
    * Throttle actuator commands
    * Brake actuator commands
    * Steering actuator commands
    * CARLA VehicleControl objects
    * CAN bus commands
    * PID, Pure Pursuit, Stanley, or LQR controller outputs
    * Hardware control signals

Those belong to Phase 10.4 and later.

Design
------
* frozen=True: no field can be changed after construction.
* All mutable inputs are copied at creation time.
* Thread-safe to share across readers.
"""
from __future__ import annotations

import math
import time
import uuid
from dataclasses import dataclass, field
from typing import List, Optional, Tuple

from .mpc_cost import CostResult
from .mpc_prediction import MPCControlInput, PredictionResult
from .mpc_solver import SolverResult
from .mpc_types import ConstraintStatus, MPC_NOT_AVAILABLE, MPC_SCHEMA_VERSION, MPCStatus
from ..vehicle.vehicle_state import VehicleState


@dataclass(frozen=True)
class MPCSnapshot:
    """
    Immutable result of one MPC solve cycle.

    frozen=True — no field can be changed after construction.

    Identity
    --------
    solution_id    : UUID string (unique per solve cycle).
    snap_timestamp : Wall-clock time when snapshot was taken (s).
    sim_timestamp  : Ego-state simulation timestamp at solve time (s).
    frame_id       : Frame counter from the ego state.
    schema_version : \"10.3\".

    Solution
    --------
    status         : MPCStatus enum.
    feasible       : True iff status == SUCCESS.

    first_steering_input     : Optimal steering angle (rad) for this cycle.
                               0.0 if infeasible.
    first_acceleration_input : Optimal acceleration (m/s²) for this cycle.
                               0.0 if infeasible.

    IMPORTANT: these are mathematical MPC optimisation variables.
               They are NOT actuator commands.  Phase 10.4 converts them.

    Horizon
    -------
    horizon             : Number of prediction steps (N).
    dt                  : Timestep per step (s).
    predicted_states    : Tuple of VehicleState (length N+1).
                          [0] = current state; [k] = after k steps.
    control_sequence    : Tuple of MPCControlInput (length N).

    Cost breakdown
    --------------
    total_cost      : Total MPC objective value.
    tracking_cost   : Tracking component.
    control_cost    : Control-effort component.
    rate_cost       : Control-rate component.
    terminal_cost   : Terminal-state component.

    Solver diagnostics
    ------------------
    iterations           : Refinement iterations performed.
    candidates_evaluated : Total candidates evaluated.
    constraint_status    : SATISFIED or VIOLATED.
    solver_message       : Human-readable diagnostic string.
    """

    # Identity
    solution_id:    str   = MPC_NOT_AVAILABLE
    snap_timestamp: float = 0.0
    sim_timestamp:  float = 0.0
    frame_id:       int   = 0
    schema_version: str   = MPC_SCHEMA_VERSION

    # Status
    status:   MPCStatus = MPCStatus.UNKNOWN
    feasible: bool      = False

    # First (current) control input — mathematical MPC variable, NOT actuator command
    first_steering_input:     float = 0.0   # rad
    first_acceleration_input: float = 0.0   # m/s²

    # Horizon
    horizon:          int                        = 0
    dt:               float                      = 0.0
    predicted_states: Tuple[VehicleState, ...]   = field(default_factory=tuple)
    control_sequence: Tuple[MPCControlInput, ...] = field(default_factory=tuple)

    # Cost components
    total_cost:    float = math.inf
    tracking_cost: float = math.inf
    control_cost:  float = math.inf
    rate_cost:     float = math.inf
    terminal_cost: float = math.inf

    # Solver diagnostics
    iterations:           int              = 0
    candidates_evaluated: int              = 0
    constraint_status:    ConstraintStatus = ConstraintStatus.UNCHECKED
    solver_message:       str              = ""

    # ------------------------------------------------------------------ #
    # Factory
    # ------------------------------------------------------------------ #

    @classmethod
    def from_solver_result(
        cls,
        solver_result: SolverResult,
        ego_state:     VehicleState,
        dt:            float,
        horizon:       int,
    ) -> "MPCSnapshot":
        """
        Build an MPCSnapshot from a SolverResult.

        Parameters
        ----------
        solver_result : Output of MPCSolver.solve().
        ego_state     : Ego vehicle state at the time of the solve.
        dt            : MPC timestep (s).
        horizon       : Prediction horizon (N).
        """
        now = time.monotonic()
        sol_id = str(uuid.uuid4())

        if solver_result.feasible and solver_result.best_prediction is not None:
            pred = solver_result.best_prediction
            predicted_states = tuple(pred.states)
            control_sequence = tuple(pred.controls)

            cost = solver_result.best_cost
            if cost is not None and cost.valid:
                total_cost    = cost.total_cost
                tracking_cost = cost.tracking_cost
                control_cost  = cost.control_cost
                rate_cost     = cost.rate_cost
                terminal_cost = cost.terminal_cost
            else:
                total_cost = tracking_cost = control_cost = rate_cost = terminal_cost = math.inf

            cst = ConstraintStatus.SATISFIED
        else:
            predicted_states = (ego_state.copy(),)
            control_sequence = ()
            total_cost = tracking_cost = control_cost = rate_cost = terminal_cost = math.inf
            cst = ConstraintStatus.UNCHECKED

        return cls(
            solution_id              = sol_id,
            snap_timestamp           = now,
            sim_timestamp            = ego_state.timestamp,
            frame_id                 = ego_state.frame_id,
            schema_version           = MPC_SCHEMA_VERSION,
            status                   = solver_result.status,
            feasible                 = solver_result.feasible,
            first_steering_input     = solver_result.best_steering,
            first_acceleration_input = solver_result.best_acceleration,
            horizon                  = horizon,
            dt                       = dt,
            predicted_states         = predicted_states,
            control_sequence         = control_sequence,
            total_cost               = total_cost,
            tracking_cost            = tracking_cost,
            control_cost             = control_cost,
            rate_cost                = rate_cost,
            terminal_cost            = terminal_cost,
            iterations               = solver_result.iterations,
            candidates_evaluated     = solver_result.candidates_evaluated,
            constraint_status        = cst,
            solver_message           = solver_result.message,
        )

    @classmethod
    def failure(
        cls,
        status:    MPCStatus,
        message:   str,
        ego_state: Optional[VehicleState] = None,
        dt:        float = 0.0,
        horizon:   int   = 0,
    ) -> "MPCSnapshot":
        """
        Build a failure snapshot (no feasible solution).
        """
        now    = time.monotonic()
        sol_id = str(uuid.uuid4())
        sim_ts = ego_state.timestamp if ego_state is not None else 0.0
        fid    = ego_state.frame_id  if ego_state is not None else 0
        states = (ego_state.copy(),) if ego_state is not None else ()

        return cls(
            solution_id          = sol_id,
            snap_timestamp       = now,
            sim_timestamp        = sim_ts,
            frame_id             = fid,
            schema_version       = MPC_SCHEMA_VERSION,
            status               = status,
            feasible             = False,
            first_steering_input = 0.0,
            first_acceleration_input = 0.0,
            horizon              = horizon,
            dt                   = dt,
            predicted_states     = states,
            control_sequence     = (),
            total_cost           = math.inf,
            tracking_cost        = math.inf,
            control_cost         = math.inf,
            rate_cost            = math.inf,
            terminal_cost        = math.inf,
            iterations           = 0,
            candidates_evaluated = 0,
            constraint_status    = ConstraintStatus.UNCHECKED,
            solver_message       = message,
        )

    # ------------------------------------------------------------------ #
    # Convenience properties
    # ------------------------------------------------------------------ #

    @property
    def is_success(self) -> bool:
        """True iff the solver found a feasible solution."""
        return self.status == MPCStatus.SUCCESS and self.feasible

    @property
    def has_valid_cost(self) -> bool:
        """True iff total_cost is a finite number."""
        return math.isfinite(self.total_cost)

    def __repr__(self) -> str:
        cost_str = f"{self.total_cost:.4f}" if math.isfinite(self.total_cost) else "inf"
        return (
            f"MPCSnapshot(status={self.status.value}, "
            f"feasible={self.feasible}, "
            f"δ={math.degrees(self.first_steering_input):.1f}°, "
            f"a={self.first_acceleration_input:.2f} m/s², "
            f"cost={cost_str}, "
            f"horizon={self.horizon}, dt={self.dt:.2f}s)"
        )
