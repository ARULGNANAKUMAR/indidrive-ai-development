"""
IndiDrive AI — Phase 10.3 + Phase 10.4 | core.control package
==============================================================
MPC Controller Core (Phase 10.3) and Steering/Speed Control (Phase 10.4).

Phase 10.3 Public API
---------------------
    MPCController       — top-level solve() entry point
    MPCConfig           — validated, frozen configuration
    MPCSnapshot         — immutable solve result
    MPCStatus           — solution status enum
    ConstraintStatus    — constraint status enum
    SolverStrategy      — solver strategy enum
    MPCControlInput     — mathematical control variable (NOT actuator command)
    MPCPredictor        — bicycle-model prediction wrapper
    MPCCostCalculator   — cost function
    MPCConstraintChecker— constraint checker
    MPCSolver           — deterministic grid-search solver
    MPCValidator        — input/config validation utilities

Phase 10.4 Public API
---------------------
    ControlConfig       — validated, frozen control layer configuration
    ControlManager      — orchestrates the full MPC→command pipeline
    VehicleControlCommand — immutable vehicle-level control command snapshot
    SteeringController  — MPC steering → bounded steering command
    SpeedController     — MPC acceleration → bounded longitudinal command
    ControlValidator    — validates MPC snapshots and control commands
    SteeringResult      — output of SteeringController
    LongitudinalResult  — output of SpeedController
    ControlCommandStatus, SteeringStatus, LongitudinalStatus — status enums
    CommandSource, LongitudinalMode, MPCFreshness, FallbackPolicy — enums
    CONTROL_SCHEMA_VERSION — "10.4"

What Phase 10.4 does NOT implement
------------------------------------
    * Phase 10.5 planner → MPC → control integration
    * new path planning or replanning
    * obstacle/object detection or perception
    * PID / Pure Pursuit / Stanley / LQR controllers
    * CAN bus or hardware actuator control
    * CARLA VehicleControl objects
"""

from .mpc_types import MPCStatus, ConstraintStatus, SolverStrategy, MPC_SCHEMA_VERSION
from .mpc_config import MPCConfig
from .mpc_prediction import MPCControlInput, MPCPredictor, PredictionResult
from .mpc_cost import MPCCostCalculator, CostResult
from .mpc_constraints import MPCConstraintChecker, ConstraintCheckResult
from .mpc_solver import MPCSolver, SolverResult
from .mpc_snapshot import MPCSnapshot
from .mpc_validator import MPCValidator, ValidationResult
from .mpc_controller import MPCController

# Phase 10.4 — Steering / Speed Control
from .control_types import (
    CONTROL_SCHEMA_VERSION,
    CONTROL_NOT_AVAILABLE,
    CommandSource,
    SteeringStatus,
    LongitudinalStatus,
    ControlCommandStatus,
    LongitudinalMode,
    MPCFreshness,
    FallbackPolicy,
)
from .control_config import ControlConfig
from .steering_controller import SteeringController, SteeringResult
from .speed_controller import SpeedController, LongitudinalResult
from .control_snapshot import VehicleControlCommand
from .control_validator import ControlValidator, MPCInputValidationResult, CommandValidationResult
from .control_manager import ControlManager

__all__ = [
    # Controller
    "MPCController",
    # Config
    "MPCConfig",
    # Types / enums
    "MPCStatus",
    "ConstraintStatus",
    "SolverStrategy",
    "MPC_SCHEMA_VERSION",
    # Prediction
    "MPCControlInput",
    "MPCPredictor",
    "PredictionResult",
    # Cost
    "MPCCostCalculator",
    "CostResult",
    # Constraints
    "MPCConstraintChecker",
    "ConstraintCheckResult",
    # Solver
    "MPCSolver",
    "SolverResult",
    # Snapshot
    "MPCSnapshot",
    # Validation
    "MPCValidator",
    "ValidationResult",
    # Phase 10.4 — types/enums
    "CONTROL_SCHEMA_VERSION",
    "CONTROL_NOT_AVAILABLE",
    "CommandSource",
    "SteeringStatus",
    "LongitudinalStatus",
    "ControlCommandStatus",
    "LongitudinalMode",
    "MPCFreshness",
    "FallbackPolicy",
    # Phase 10.4 — config
    "ControlConfig",
    # Phase 10.4 — controllers
    "SteeringController",
    "SteeringResult",
    "SpeedController",
    "LongitudinalResult",
    # Phase 10.4 — snapshot
    "VehicleControlCommand",
    # Phase 10.4 — validator
    "ControlValidator",
    "MPCInputValidationResult",
    "CommandValidationResult",
    # Phase 10.4 — manager
    "ControlManager",
]
