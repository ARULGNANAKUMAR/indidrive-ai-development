"""
IndiDrive AI — Phase 10.4 | Speed / Longitudinal Controller
============================================================
Converts the Phase 10.3 MPC acceleration solution into a bounded,
validated longitudinal control command including acceleration, brake,
and target speed.

Responsibilities
----------------
1. Read the MPC first_acceleration_input (mathematical optimisation variable).
2. Apply configured acceleration limits (clamp with saturation flag).
3. Apply configured speed limits to derive a bounded target speed.
4. Derive the brake command from the deceleration demand.
5. Determine the longitudinal mode (ACCELERATE / COAST / DECELERATE / BRAKE).
6. Validate all outputs.
7. Return a deterministic LongitudinalResult.

Acceleration → Brake conversion
--------------------------------
The MPC produces a single signed acceleration value (m/s²):
    a ≥ 0         → acceleration command, brake = 0
    -threshold < a < 0  → coast / micro-deceleration, brake = 0
    a ≤ -threshold → deceleration demand.
       brake_mps2 = abs(a), clamped to max_brake_mps2.

The brake output is in the same units as acceleration (m/s²), representing
the demanded deceleration magnitude.  It is NOT a percentage or actuator
position — that conversion belongs to Phase 10.5 / hardware layer.

This module does NOT:
    * Run a PID, Pure Pursuit, Stanley, or LQR controller.
    * Access road speed limits (those belong to the planner).
    * Send commands to CARLA or hardware.
    * Access external services or networks.

Determinism:
    Same (mpc_accel, current_velocity, ref_speed, config) → same result.
    No random values.
"""
from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Optional

from .control_config import ControlConfig
from .control_types import (
    CONTROL_SCHEMA_VERSION,
    LongitudinalMode,
    LongitudinalStatus,
)


# ---------------------------------------------------------------------------
# Result type
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class LongitudinalResult:
    """
    Immutable result of one longitudinal command generation cycle.

    Fields
    ------
    acceleration_mps2  : Commanded acceleration (m/s²).  Positive = accelerate;
                         zero = coast; negative = decelerate.
    brake_mps2         : Commanded brake deceleration magnitude (m/s²) ≥ 0.
                         0 when accelerating or coasting.
    target_speed_mps   : Commanded target speed (m/s), within [min, max].
                         Derived from current velocity + acceleration*dt when
                         ref_speed is unavailable, or bounded ref_speed.
    longitudinal_mode  : Normalised longitudinal intent.
    accel_limited      : True iff MPC acceleration was clamped.
    speed_limited      : True iff target speed was clamped.
    status             : LongitudinalStatus enum.
    reason             : Human-readable diagnostic string.
    schema_version     : "10.4"
    """
    acceleration_mps2: float              = 0.0
    brake_mps2:        float              = 0.0
    target_speed_mps:  float              = 0.0
    longitudinal_mode: LongitudinalMode   = LongitudinalMode.UNKNOWN
    accel_limited:     bool               = False
    speed_limited:     bool               = False
    status:            LongitudinalStatus = LongitudinalStatus.UNKNOWN
    reason:            str                = ""
    schema_version:    str                = CONTROL_SCHEMA_VERSION

    @property
    def is_valid(self) -> bool:
        """True iff status is VALID or LIMITED."""
        return self.status in (
            LongitudinalStatus.VALID,
            LongitudinalStatus.LIMITED,
        )

    @property
    def is_usable(self) -> bool:
        """Alias for is_valid."""
        return self.is_valid

    def __repr__(self) -> str:
        return (
            f"LongitudinalResult("
            f"a={self.acceleration_mps2:.2f} m/s², "
            f"brake={self.brake_mps2:.2f} m/s², "
            f"v_tgt={self.target_speed_mps:.2f} m/s, "
            f"mode={self.longitudinal_mode.value}, "
            f"status={self.status.value})"
        )


# ---------------------------------------------------------------------------
# Speed controller
# ---------------------------------------------------------------------------


class SpeedController:
    """
    Converts the MPC acceleration solution into bounded longitudinal commands.

    Stateless computation — no internal state.

    Usage
    -----
    ::

        cfg = ControlConfig.default()
        ctrl = SpeedController(cfg)
        result = ctrl.compute(
            mpc_acceleration_mps2 = snapshot.first_acceleration_input,
            current_velocity_mps  = ego_state.velocity,
            ref_speed_mps         = ref_point.velocity,   # or None
            dt                    = 0.1,
        )
    """

    def __init__(self, config: ControlConfig) -> None:
        if not isinstance(config, ControlConfig):
            raise TypeError(
                f"SpeedController requires ControlConfig, got {type(config)}"
            )
        self._cfg = config

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def compute(
        self,
        mpc_acceleration_mps2: float,
        current_velocity_mps:  float,
        ref_speed_mps:         Optional[float],
        dt:                    float,
    ) -> LongitudinalResult:
        """
        Compute bounded longitudinal command from MPC acceleration variable.

        Parameters
        ----------
        mpc_acceleration_mps2 : MPC first_acceleration_input (m/s²).
        current_velocity_mps  : Current ego vehicle velocity (m/s).  Must be ≥ 0.
        ref_speed_mps         : Reference speed from trajectory (m/s), or None.
        dt                    : Control timestep (s).  Used for target speed
                                estimation when ref_speed is unavailable.

        Returns
        -------
        LongitudinalResult — always returns a valid structure, never raises.
        """
        cfg = self._cfg

        # ----------------------------------------------------------------
        # Step 1: validate MPC acceleration input
        # ----------------------------------------------------------------
        if not math.isfinite(mpc_acceleration_mps2):
            return LongitudinalResult(
                acceleration_mps2 = 0.0,
                brake_mps2        = 0.0,
                target_speed_mps  = max(cfg.min_speed_mps, 0.0),
                longitudinal_mode = LongitudinalMode.UNKNOWN,
                accel_limited     = False,
                speed_limited     = False,
                status            = LongitudinalStatus.INVALID_INPUT,
                reason            = (
                    f"MPC acceleration input is non-finite: {mpc_acceleration_mps2}"
                ),
            )

        # ----------------------------------------------------------------
        # Step 2: validate current velocity
        # ----------------------------------------------------------------
        cur_vel_valid = (
            math.isfinite(current_velocity_mps)
            and current_velocity_mps >= 0.0
        )
        if not cur_vel_valid:
            # Use 0 as safe fallback for velocity-dependent calculations
            effective_vel = 0.0
        else:
            effective_vel = current_velocity_mps

        # ----------------------------------------------------------------
        # Step 3: clamp acceleration to configured limits
        # ----------------------------------------------------------------
        clamped_accel = max(
            cfg.min_acceleration_mps2,
            min(cfg.max_acceleration_mps2, mpc_acceleration_mps2),
        )
        accel_limited = (clamped_accel != mpc_acceleration_mps2)

        # ----------------------------------------------------------------
        # Step 4: derive brake command
        # ----------------------------------------------------------------
        # Brake is only non-zero when deceleration exceeds brake_threshold.
        # brake_mps2 is the deceleration magnitude (positive).
        #
        # Convention:
        #   acceleration_mps2 ≥ 0          → brake_mps2 = 0
        #   0 > a > -brake_threshold        → coast, brake_mps2 = 0
        #   a ≤ -brake_threshold            → brake_mps2 = abs(a) clamped
        if clamped_accel <= -cfg.brake_threshold_mps2:
            raw_brake = abs(clamped_accel)
            brake_mps2 = min(raw_brake, cfg.max_brake_mps2)
        else:
            brake_mps2 = 0.0

        # ----------------------------------------------------------------
        # Step 5: determine longitudinal mode
        # ----------------------------------------------------------------
        mode = _derive_mode(clamped_accel, cfg.brake_threshold_mps2)

        # ----------------------------------------------------------------
        # Step 6: target speed
        # ----------------------------------------------------------------
        target_speed_mps, speed_limited = self._compute_target_speed(
            clamped_accel = clamped_accel,
            current_vel   = effective_vel,
            ref_speed     = ref_speed_mps,
            dt            = dt,
            cfg           = cfg,
        )

        # ----------------------------------------------------------------
        # Step 7: consistency — no simultaneous strong acceleration + brake
        # ----------------------------------------------------------------
        # (This can only occur if brake_threshold is misconfigured to a
        #  negative value, which is blocked by ControlConfig validation.
        #  Guard here for defence-in-depth.)
        if clamped_accel > 0 and brake_mps2 > 0:
            # Reset brake — acceleration takes priority
            brake_mps2 = 0.0

        # ----------------------------------------------------------------
        # Step 8: final finite check
        # ----------------------------------------------------------------
        if (
            not math.isfinite(clamped_accel)
            or not math.isfinite(brake_mps2)
            or not math.isfinite(target_speed_mps)
        ):
            return LongitudinalResult(
                acceleration_mps2 = 0.0,
                brake_mps2        = 0.0,
                target_speed_mps  = cfg.min_speed_mps,
                longitudinal_mode = LongitudinalMode.UNKNOWN,
                accel_limited     = False,
                speed_limited     = False,
                status            = LongitudinalStatus.INVALID_INPUT,
                reason            = "Longitudinal output became non-finite after limiting.",
            )

        # ----------------------------------------------------------------
        # Step 9: determine status
        # ----------------------------------------------------------------
        if accel_limited or speed_limited:
            status = LongitudinalStatus.LIMITED
            reason = _build_limited_reason(
                mpc_acceleration_mps2, clamped_accel, accel_limited, speed_limited
            )
        else:
            status = LongitudinalStatus.VALID
            reason = ""

        return LongitudinalResult(
            acceleration_mps2 = clamped_accel,
            brake_mps2        = brake_mps2,
            target_speed_mps  = target_speed_mps,
            longitudinal_mode = mode,
            accel_limited     = accel_limited,
            speed_limited     = speed_limited,
            status            = status,
            reason            = reason,
        )

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _compute_target_speed(
        self,
        clamped_accel: float,
        current_vel:   float,
        ref_speed:     Optional[float],
        dt:            float,
        cfg:           ControlConfig,
    ) -> tuple:
        """
        Derive a bounded target speed from available inputs.

        Priority:
        1. Use ref_speed if finite and non-negative → bound to [min, max].
        2. Estimate from current_vel + clamped_accel * dt if dt valid.
        3. Fall back to current_vel bounded to [min, max].

        Returns (target_speed_mps: float, speed_limited: bool)
        """
        speed_limited = False

        # Option 1: reference speed from trajectory
        if ref_speed is not None and math.isfinite(ref_speed) and ref_speed >= 0.0:
            raw_target = ref_speed
        elif math.isfinite(dt) and dt > 0.0:
            # Option 2: integrate current velocity with clamped acceleration
            raw_target = current_vel + clamped_accel * dt
            raw_target = max(0.0, raw_target)          # velocity can't go negative
        else:
            # Option 3: use current velocity as target
            raw_target = current_vel

        # Clamp to configured speed limits
        target = max(cfg.min_speed_mps, min(cfg.max_speed_mps, raw_target))
        if target != raw_target:
            speed_limited = True

        return target, speed_limited


# ---------------------------------------------------------------------------
# Module-level helpers
# ---------------------------------------------------------------------------


def _derive_mode(
    acceleration_mps2:   float,
    brake_threshold_mps2: float,
) -> LongitudinalMode:
    """
    Classify the acceleration into a normalised longitudinal mode.

    Parameters
    ----------
    acceleration_mps2     : Clamped acceleration command (m/s²).
    brake_threshold_mps2  : Threshold below which deceleration triggers brake.
    """
    if not math.isfinite(acceleration_mps2):
        return LongitudinalMode.UNKNOWN
    if acceleration_mps2 > 0.0:
        return LongitudinalMode.ACCELERATE
    if acceleration_mps2 == 0.0:
        return LongitudinalMode.COAST
    # acceleration_mps2 < 0
    if abs(acceleration_mps2) <= brake_threshold_mps2:
        return LongitudinalMode.DECELERATE
    return LongitudinalMode.BRAKE


def _build_limited_reason(
    mpc_raw:      float,
    clamped:      float,
    accel_lim:    bool,
    speed_lim:    bool,
) -> str:
    parts = []
    if accel_lim:
        parts.append(
            f"Acceleration clamped from {mpc_raw:.2f} to {clamped:.2f} m/s²"
        )
    if speed_lim:
        parts.append("Target speed clamped to configured limits")
    return "; ".join(parts) + "." if parts else ""
