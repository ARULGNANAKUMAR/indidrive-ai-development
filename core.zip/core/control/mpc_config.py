"""
IndiDrive AI — Phase 10.3 | MPC Configuration
==============================================
Validated, immutable configuration for the MPC controller core.

All physical values are in SI units (metres, seconds, radians, m/s, m/s²).
These are configuration-level defaults — they must be tuned once a real
vehicle and test environment are available.

Configuration sections
----------------------
Prediction horizon:
    prediction_horizon  — number of steps N (integer ≥ 1)
    dt                  — timestep per step (s)  > 0

Cost weights (all ≥ 0):
    w_cross_track       — cross-track error squared
    w_along_track       — along-track error squared
    w_heading           — heading error squared
    w_speed             — speed error squared
    w_steering          — steering control effort squared
    w_acceleration      — acceleration control effort squared
    w_steering_rate     — steering rate (Δδ) squared
    w_acceleration_rate — acceleration rate (Δa) squared
    w_terminal          — scale factor for terminal-state cost
                          (applied to the tracking cost at step N)

Control/state limits:
    min_steering_rad    — minimum steering angle (rad) ≤ 0
    max_steering_rad    — maximum steering angle (rad) ≥ 0
    max_steering_rate_rad_s — maximum |Δsteering| / dt (rad/s)
    min_acceleration_mps2   — minimum acceleration (m/s²) < 0
    max_acceleration_mps2   — maximum acceleration (m/s²) > 0
    min_velocity_mps        — minimum velocity (m/s) ≥ 0
    max_velocity_mps        — maximum velocity (m/s) > 0

Solver parameters:
    max_iterations      — maximum refinement iterations (int ≥ 1)
    steering_samples    — number of steering angle samples per step (int ≥ 2)
    acceleration_samples— number of acceleration samples per step (int ≥ 2)
    max_reference_age_s — reject reference trajectories older than this (s)

Notes
-----
* Defaults are consistent with VehicleParameters.default() (Phase 10.1).
* Do not mix DynamicsConfig and MPCConfig limit values; both constrain
  different layers.  The MPC uses its own limits for candidate generation
  and feasibility checking; the bicycle model uses its own for clamping.
* Weights set to 0 effectively disable that cost component.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Optional

from .mpc_types import SolverStrategy


# ---------------------------------------------------------------------------
# Defaults — aligned with Phase 10.1 VehicleParameters.default()
# ---------------------------------------------------------------------------

_DEFAULT_HORIZON:              int   = 10          # prediction steps
_DEFAULT_DT:                   float = 0.1         # 100 ms per step
_DEFAULT_MAX_ITER:             int   = 5
_DEFAULT_STEER_SAMPLES:        int   = 7
_DEFAULT_ACCEL_SAMPLES:        int   = 5

# Cost weights
_DEFAULT_W_CTE:                float = 2.0
_DEFAULT_W_ATE:                float = 0.5
_DEFAULT_W_HEADING:            float = 1.5
_DEFAULT_W_SPEED:              float = 1.0
_DEFAULT_W_STEER:              float = 0.1
_DEFAULT_W_ACCEL:              float = 0.1
_DEFAULT_W_STEER_RATE:         float = 0.5
_DEFAULT_W_ACCEL_RATE:         float = 0.2
_DEFAULT_W_TERMINAL:           float = 2.0   # multiplier on terminal tracking cost

# Limits — match Phase 10.1 VehicleParameters defaults
_DEFAULT_MIN_STEER_RAD:        float = -0.610  # −35°
_DEFAULT_MAX_STEER_RAD:        float =  0.610  # +35°
_DEFAULT_MAX_STEER_RATE_RAD_S: float =  0.700  # rad/s
_DEFAULT_MIN_ACCEL_MPS2:       float = -8.0
_DEFAULT_MAX_ACCEL_MPS2:       float =  4.0
_DEFAULT_MIN_VEL_MPS:          float =  0.0
_DEFAULT_MAX_VEL_MPS:          float = 33.33   # ~120 km/h

_DEFAULT_MAX_REF_AGE_S:        float = 2.0


# ---------------------------------------------------------------------------
# Configuration dataclass
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class MPCConfig:
    """
    Immutable, validated MPC configuration.

    All cost weights must be ≥ 0.
    Limit fields must form valid ranges (min < max, etc.).

    Terminal cost note
    ------------------
    w_terminal > 0 enables a terminal cost applied at step N only,
    using the same tracking cost formula multiplied by w_terminal.
    Set w_terminal = 0.0 to disable terminal cost.
    """

    # Prediction horizon
    prediction_horizon:    int   = _DEFAULT_HORIZON
    dt:                    float = _DEFAULT_DT

    # Cost weights
    w_cross_track:         float = _DEFAULT_W_CTE
    w_along_track:         float = _DEFAULT_W_ATE
    w_heading:             float = _DEFAULT_W_HEADING
    w_speed:               float = _DEFAULT_W_SPEED
    w_steering:            float = _DEFAULT_W_STEER
    w_acceleration:        float = _DEFAULT_W_ACCEL
    w_steering_rate:       float = _DEFAULT_W_STEER_RATE
    w_acceleration_rate:   float = _DEFAULT_W_ACCEL_RATE
    w_terminal:            float = _DEFAULT_W_TERMINAL

    # Control limits
    min_steering_rad:          float = _DEFAULT_MIN_STEER_RAD
    max_steering_rad:          float = _DEFAULT_MAX_STEER_RAD
    max_steering_rate_rad_s:   float = _DEFAULT_MAX_STEER_RATE_RAD_S
    min_acceleration_mps2:     float = _DEFAULT_MIN_ACCEL_MPS2
    max_acceleration_mps2:     float = _DEFAULT_MAX_ACCEL_MPS2
    min_velocity_mps:          float = _DEFAULT_MIN_VEL_MPS
    max_velocity_mps:          float = _DEFAULT_MAX_VEL_MPS

    # Solver parameters
    max_iterations:        int   = _DEFAULT_MAX_ITER
    steering_samples:      int   = _DEFAULT_STEER_SAMPLES
    acceleration_samples:  int   = _DEFAULT_ACCEL_SAMPLES
    solver_strategy:       SolverStrategy = SolverStrategy.GRID_SEARCH
    max_reference_age_s:   float = _DEFAULT_MAX_REF_AGE_S

    # ------------------------------------------------------------------ #
    # Post-init validation
    # ------------------------------------------------------------------ #

    def __post_init__(self) -> None:
        self._validate()

    def _validate(self) -> None:
        """Raise ValueError for any invalid configuration field."""

        # --- Horizon / dt ---
        if not isinstance(self.prediction_horizon, int) or self.prediction_horizon < 1:
            raise ValueError(
                f"prediction_horizon must be int ≥ 1, got {self.prediction_horizon!r}"
            )
        if not math.isfinite(self.dt) or self.dt <= 0.0:
            raise ValueError(
                f"dt must be finite and > 0, got {self.dt}"
            )

        # --- Cost weights (all must be ≥ 0 and finite) ---
        _weight_fields = (
            ("w_cross_track",       self.w_cross_track),
            ("w_along_track",       self.w_along_track),
            ("w_heading",           self.w_heading),
            ("w_speed",             self.w_speed),
            ("w_steering",          self.w_steering),
            ("w_acceleration",      self.w_acceleration),
            ("w_steering_rate",     self.w_steering_rate),
            ("w_acceleration_rate", self.w_acceleration_rate),
            ("w_terminal",          self.w_terminal),
        )
        for name, val in _weight_fields:
            if not isinstance(val, (int, float)) or not math.isfinite(val):
                raise ValueError(f"MPCConfig.{name} must be finite, got {val!r}")
            if val < 0.0:
                raise ValueError(
                    f"MPCConfig.{name} must be ≥ 0 (cost weights are non-negative), "
                    f"got {val}"
                )

        # --- Steering limits ---
        if not math.isfinite(self.min_steering_rad) or self.min_steering_rad > 0.0:
            raise ValueError(
                f"min_steering_rad must be finite and ≤ 0, got {self.min_steering_rad}"
            )
        if not math.isfinite(self.max_steering_rad) or self.max_steering_rad < 0.0:
            raise ValueError(
                f"max_steering_rad must be finite and ≥ 0, got {self.max_steering_rad}"
            )
        if self.max_steering_rad < abs(self.min_steering_rad) * 0.0:
            pass  # asymmetric limits are valid
        if not math.isfinite(self.max_steering_rate_rad_s) or self.max_steering_rate_rad_s <= 0.0:
            raise ValueError(
                f"max_steering_rate_rad_s must be finite and > 0, "
                f"got {self.max_steering_rate_rad_s}"
            )

        # --- Acceleration limits ---
        if not math.isfinite(self.min_acceleration_mps2) or self.min_acceleration_mps2 >= 0.0:
            raise ValueError(
                f"min_acceleration_mps2 must be finite and < 0, "
                f"got {self.min_acceleration_mps2}"
            )
        if not math.isfinite(self.max_acceleration_mps2) or self.max_acceleration_mps2 <= 0.0:
            raise ValueError(
                f"max_acceleration_mps2 must be finite and > 0, "
                f"got {self.max_acceleration_mps2}"
            )

        # --- Velocity limits ---
        if not math.isfinite(self.min_velocity_mps) or self.min_velocity_mps < 0.0:
            raise ValueError(
                f"min_velocity_mps must be finite and ≥ 0, got {self.min_velocity_mps}"
            )
        if not math.isfinite(self.max_velocity_mps) or self.max_velocity_mps <= self.min_velocity_mps:
            raise ValueError(
                f"max_velocity_mps must be finite and > min_velocity_mps "
                f"({self.min_velocity_mps}), got {self.max_velocity_mps}"
            )

        # --- Solver parameters ---
        if not isinstance(self.max_iterations, int) or self.max_iterations < 1:
            raise ValueError(
                f"max_iterations must be int ≥ 1, got {self.max_iterations!r}"
            )
        if not isinstance(self.steering_samples, int) or self.steering_samples < 2:
            raise ValueError(
                f"steering_samples must be int ≥ 2, got {self.steering_samples!r}"
            )
        if not isinstance(self.acceleration_samples, int) or self.acceleration_samples < 2:
            raise ValueError(
                f"acceleration_samples must be int ≥ 2, got {self.acceleration_samples!r}"
            )
        if not math.isfinite(self.max_reference_age_s) or self.max_reference_age_s <= 0.0:
            raise ValueError(
                f"max_reference_age_s must be finite and > 0, got {self.max_reference_age_s}"
            )

    # ------------------------------------------------------------------ #
    # Factory helpers
    # ------------------------------------------------------------------ #

    @classmethod
    def default(cls) -> "MPCConfig":
        """Return the default MPC configuration."""
        return cls()

    @classmethod
    def from_dict(cls, cfg: dict) -> "MPCConfig":
        """
        Build MPCConfig from a dict (e.g. loaded from YAML).

        Only recognised keys are consumed; unknown keys are ignored.
        Missing keys fall back to class defaults.
        """
        mpc = cfg.get("mpc", cfg)  # allow top-level or nested under 'mpc'

        weights = mpc.get("weights", {})
        limits  = mpc.get("limits",  {})

        def _f(d: dict, key: str, default: float) -> float:
            v = d.get(key, default)
            return float(v) if v is not None else default

        def _i(d: dict, key: str, default: int) -> int:
            v = d.get(key, default)
            return int(v) if v is not None else default

        strategy_str = mpc.get("solver_strategy", SolverStrategy.GRID_SEARCH.value)
        try:
            strategy = SolverStrategy(strategy_str)
        except ValueError:
            strategy = SolverStrategy.GRID_SEARCH

        return cls(
            prediction_horizon    = _i(mpc, "prediction_horizon", _DEFAULT_HORIZON),
            dt                    = _f(mpc, "dt", _DEFAULT_DT),

            w_cross_track         = _f(weights, "cross_track",       _DEFAULT_W_CTE),
            w_along_track         = _f(weights, "along_track",        _DEFAULT_W_ATE),
            w_heading             = _f(weights, "heading",            _DEFAULT_W_HEADING),
            w_speed               = _f(weights, "speed",              _DEFAULT_W_SPEED),
            w_steering            = _f(weights, "steering",           _DEFAULT_W_STEER),
            w_acceleration        = _f(weights, "acceleration",       _DEFAULT_W_ACCEL),
            w_steering_rate       = _f(weights, "steering_rate",      _DEFAULT_W_STEER_RATE),
            w_acceleration_rate   = _f(weights, "acceleration_rate",  _DEFAULT_W_ACCEL_RATE),
            w_terminal            = _f(weights, "terminal",           _DEFAULT_W_TERMINAL),

            min_steering_rad      = _f(limits, "steering_min",           _DEFAULT_MIN_STEER_RAD),
            max_steering_rad      = _f(limits, "steering_max",           _DEFAULT_MAX_STEER_RAD),
            max_steering_rate_rad_s = _f(limits, "steering_rate_max",    _DEFAULT_MAX_STEER_RATE_RAD_S),
            min_acceleration_mps2 = _f(limits, "acceleration_min",       _DEFAULT_MIN_ACCEL_MPS2),
            max_acceleration_mps2 = _f(limits, "acceleration_max",       _DEFAULT_MAX_ACCEL_MPS2),
            min_velocity_mps      = _f(limits, "velocity_min",           _DEFAULT_MIN_VEL_MPS),
            max_velocity_mps      = _f(limits, "velocity_max",           _DEFAULT_MAX_VEL_MPS),

            max_iterations        = _i(mpc, "max_iterations",        _DEFAULT_MAX_ITER),
            steering_samples      = _i(mpc, "steering_samples",      _DEFAULT_STEER_SAMPLES),
            acceleration_samples  = _i(mpc, "acceleration_samples",  _DEFAULT_ACCEL_SAMPLES),
            solver_strategy       = strategy,
            max_reference_age_s   = _f(mpc, "max_reference_age_s",   _DEFAULT_MAX_REF_AGE_S),
        )

    # ------------------------------------------------------------------ #
    # Derived helpers
    # ------------------------------------------------------------------ #

    @property
    def horizon_duration_s(self) -> float:
        """Total prediction horizon duration in seconds."""
        return self.prediction_horizon * self.dt
