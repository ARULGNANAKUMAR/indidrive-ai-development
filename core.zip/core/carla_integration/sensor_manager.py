"""
IndiDrive AI — Phase 1 | Sensor Manager
==========================================
Centralizes sensor lifecycle: init, start, stop, restart, status, and
exposes the latest structured data via SensorBuffer. Contains NO
perception logic — it only moves SensorFrame objects from a
SensorInterface into a SensorBuffer and updates SensorHealthMonitor.
"""
from __future__ import annotations

import time
from typing import Optional

from .sensor_buffer import SensorBuffer
from .sensor_health import SensorHealthMonitor
from .sensor_interface import SensorInterface
from .sensor_types import FrameStatus, SensorAvailability

try:
    from core.logging_system import get_logger
except ImportError:  # pragma: no cover - allows use outside the app package
    get_logger = None


class SensorManager:
    def __init__(self, buffer_capacity: int = 30, overflow_policy: str = "DROP_OLDEST",
                 stale_after_s: float = 1.0):
        self._sensors: dict[str, SensorInterface] = {}
        self._buffers: dict[str, SensorBuffer] = {}
        self._running: dict[str, bool] = {}
        self.health = SensorHealthMonitor(stale_after_s=stale_after_s)
        self._buffer_capacity = buffer_capacity
        self._overflow_policy = overflow_policy
        self._log = get_logger("sensors", component="sensor_manager") if get_logger else None

    def _info(self, event: str, **extra) -> None:
        if self._log:
            self._log.info(event, **extra)

    def _error(self, event: str, error: str, **extra) -> None:
        if self._log:
            self._log.error(event, error=error, **extra)

    def register(self, sensor: SensorInterface) -> None:
        """Register a sensor (live or offline). Does not start it yet."""
        sensor_id = sensor.sensor_id
        self._sensors[sensor_id] = sensor
        self._buffers[sensor_id] = SensorBuffer(sensor_id, capacity=self._buffer_capacity,
                                                  overflow_policy=self._overflow_policy)
        self._running[sensor_id] = False

        if sensor.availability != SensorAvailability.AVAILABLE:
            self.health.mark_not_configured(sensor_id)
            self._info("sensor_not_configured", sensor_id=sensor_id,
                       availability=sensor.availability.value)
        else:
            self.health.register(sensor_id, configured=True)
            self._info("sensor_registered", sensor_id=sensor_id, sensor_type=sensor.sensor_type.value)

    def start(self, sensor_id: str) -> bool:
        """Start one registered sensor. Returns False (without raising) if not configured/available."""
        sensor = self._sensors.get(sensor_id)
        if sensor is None:
            self._error("sensor_start_failed", error="unknown sensor_id", sensor_id=sensor_id)
            return False
        if sensor.availability != SensorAvailability.AVAILABLE:
            self._info("sensor_start_skipped", sensor_id=sensor_id, reason=sensor.availability.value)
            return False

        def _on_frame(frame):
            frame.timestamp.mark_processed()
            t0 = frame.timestamp.reception_time
            latency_ms = max(0.0, (time.time() - t0) * 1000.0)

            if frame.status == FrameStatus.INVALID:
                self.health.record_error(sensor_id, frame.metadata.get("invalid_reason", "invalid frame"))
                self._error("sensor_frame_invalid", error=frame.metadata.get("invalid_reason", "unknown"),
                            sensor_id=sensor_id, frame_id=frame.frame_id)
                return

            buf = self._buffers[sensor_id]
            dropped_before = buf.dropped_count
            buf.push(frame)
            dropped_after = buf.dropped_count
            if dropped_after > dropped_before:
                self.health.record_dropped(sensor_id, dropped_after - dropped_before)
            self.health.record_frame(sensor_id, frame.frame_id, callback_latency_ms=latency_ms)

        try:
            sensor.start(_on_frame)
            self._running[sensor_id] = True
            self._info("sensor_started", sensor_id=sensor_id)
            return True
        except Exception as e:
            self.health.record_error(sensor_id, str(e))
            self._error("sensor_start_failed", error=str(e), sensor_id=sensor_id)
            return False

    def start_all(self) -> dict[str, bool]:
        return {sid: self.start(sid) for sid in self._sensors}

    def stop(self, sensor_id: str) -> None:
        sensor = self._sensors.get(sensor_id)
        if sensor is None:
            return
        try:
            sensor.stop()
        except Exception as e:
            self._error("sensor_stop_failed", error=str(e), sensor_id=sensor_id)
        finally:
            self._running[sensor_id] = False
            if sensor_id in self._buffers:
                self._buffers[sensor_id].close()
            self.health.mark_offline(sensor_id)
            self._info("sensor_stopped", sensor_id=sensor_id)

    def stop_all(self) -> None:
        for sid in list(self._sensors):
            self.stop(sid)

    def restart(self, sensor_id: str) -> bool:
        """Attempt a safe restart of a failed sensor: stop, fresh buffer, start."""
        self.stop(sensor_id)
        self._buffers[sensor_id] = SensorBuffer(sensor_id, capacity=self._buffer_capacity,
                                                  overflow_policy=self._overflow_policy)
        ok = self.start(sensor_id)
        self._info("sensor_restart", sensor_id=sensor_id, status="ok" if ok else "failed")
        return ok

    def latest(self, sensor_id: str):
        buf = self._buffers.get(sensor_id)
        return buf.latest() if buf else None

    def buffer(self, sensor_id: str) -> Optional[SensorBuffer]:
        return self._buffers.get(sensor_id)

    def closest_related_frames(self, reference_sensor_id: str, reference_sensor_time: float,
                                other_sensor_ids: Optional[list[str]] = None) -> dict:
        """
        Basic frame association (Phase 1 scope only — NOT sensor fusion):
        given a reference timestamp, return each requested sensor's
        temporally-closest buffered frame.
        """
        other_sensor_ids = other_sensor_ids or [sid for sid in self._buffers if sid != reference_sensor_id]
        result = {}
        ref_buf = self._buffers.get(reference_sensor_id)
        if ref_buf:
            result[reference_sensor_id] = ref_buf.get_closest_by_timestamp(reference_sensor_time)
        for sid in other_sensor_ids:
            buf = self._buffers.get(sid)
            result[sid] = buf.get_closest_by_timestamp(reference_sensor_time) if buf else None
        return result

    def status_report(self) -> dict:
        report = self.health.report()
        for sid, buf in self._buffers.items():
            if sid in report:
                report[sid]["buffer"] = buf.stats()
        return report

    def cleanup(self) -> None:
        """Full teardown: stop sensors, release buffers. Safe to call multiple times."""
        self.stop_all()
