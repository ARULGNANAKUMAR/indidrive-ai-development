"""
IndiDrive AI — Phase 1 | Sensor Abstraction Layer
====================================================
Defines SensorInterface so that everything downstream (SensorManager,
future Phase 2+ perception) consumes a standard SensorFrame stream and
never talks to CARLA-specific APIs directly.

Implementations:
    CARLACameraSensor, CARLALiDARSensor, CARLARadarSensor  — live, wrap
        core/carla_integration/sensors.py's attach_* functions
    OfflineCameraReplay, OfflineLiDARReplay, OfflineRadarReplay — read
        previously recorded frames back out through the same interface

Radar note: CARLA's built-in `sensor.other.radar` blueprint exists, but
this project's Phase 0 config (config/sensor_config.yaml) explicitly
marks radar as `enabled: false` / `status: unavailable` — no radar
transform/config was ever defined for the vehicle. CARLARadarSensor
therefore reports SensorAvailability.NOT_CONFIGURED rather than
fabricating detections. If a future phase configures a real radar
transform, CARLARadarSensor can attach `sensor.other.radar` for real.
"""
from __future__ import annotations

import abc
import time
from typing import Callable, Optional

from .sensor_types import (
    CameraFrame, LiDARFrame, RadarFrame, SensorType, SensorAvailability, Timestamp,
    validate_camera_frame, validate_lidar_frame, validate_radar_frame,
)


class SensorInterface(abc.ABC):
    """Standard interface every sensor source (live or replayed) implements."""

    sensor_id: str
    sensor_type: SensorType

    @abc.abstractmethod
    def start(self, on_frame: Callable[[object], None]) -> None:
        """Begin producing frames; calls on_frame(SensorFrame) for each one."""

    @abc.abstractmethod
    def stop(self) -> None:
        """Stop producing frames and release any resources."""

    @property
    def availability(self) -> SensorAvailability:
        return SensorAvailability.AVAILABLE


# ---------------------------------------------------------------------------
# Live CARLA implementations
# ---------------------------------------------------------------------------

class CARLACameraSensor(SensorInterface):
    sensor_type = SensorType.CAMERA

    def __init__(self, world, vehicle, sensor_id: str = "rgb_front",
                 width: int = 800, height: int = 600, fov: float = 90.0, transform=None):
        self.sensor_id = sensor_id
        self._world, self._vehicle = world, vehicle
        self._width, self._height, self._fov, self._transform = width, height, fov, transform
        self._actor = None
        self._seq = 0

    def start(self, on_frame: Callable[[object], None]) -> None:
        from . import sensors as raw_sensors
        import carla

        bp_lib = self._world.get_blueprint_library()
        cam_bp = bp_lib.find("sensor.camera.rgb")
        cam_bp.set_attribute("image_size_x", str(self._width))
        cam_bp.set_attribute("image_size_y", str(self._height))
        cam_bp.set_attribute("fov", str(self._fov))
        transform = self._transform or carla.Transform(carla.Location(x=1.6, z=1.7))
        self._actor = self._world.spawn_actor(cam_bp, transform, attach_to=self._vehicle)

        def _cb(carla_image):
            recv_t = time.time()
            image = raw_sensors._decode_rgb_image(carla_image)
            self._seq += 1
            frame = CameraFrame(
                sensor_id=self.sensor_id, frame_id=carla_image.frame,
                timestamp=Timestamp(sensor_time=carla_image.timestamp, reception_time=recv_t),
                sequence_number=self._seq, payload=None,
                width=image.shape[1], height=image.shape[0], channels=image.shape[2],
                encoding="rgb8", image=image,
            )
            ok, reason = validate_camera_frame(frame)
            if not ok:
                from .sensor_types import FrameStatus
                frame.status = FrameStatus.INVALID
                frame.metadata["invalid_reason"] = reason
            on_frame(frame)

        self._actor.listen(_cb)

    def stop(self) -> None:
        if self._actor is not None:
            try:
                if self._actor.is_alive:
                    self._actor.destroy()
            except Exception:
                pass
            self._actor = None


class CARLALiDARSensor(SensorInterface):
    sensor_type = SensorType.LIDAR

    def __init__(self, world, vehicle, sensor_id: str = "lidar_top",
                 channels: int = 32, range_m: float = 50.0,
                 points_per_second: int = 100_000, rotation_frequency: float = 10.0, transform=None):
        self.sensor_id = sensor_id
        self._world, self._vehicle = world, vehicle
        self._channels, self._range_m = channels, range_m
        self._pps, self._rot_freq, self._transform = points_per_second, rotation_frequency, transform
        self._actor = None
        self._seq = 0

    def start(self, on_frame: Callable[[object], None]) -> None:
        from . import sensors as raw_sensors
        import carla

        bp_lib = self._world.get_blueprint_library()
        lidar_bp = bp_lib.find("sensor.lidar.ray_cast")
        lidar_bp.set_attribute("channels", str(self._channels))
        lidar_bp.set_attribute("range", str(self._range_m))
        lidar_bp.set_attribute("points_per_second", str(self._pps))
        lidar_bp.set_attribute("rotation_frequency", str(self._rot_freq))
        transform = self._transform or carla.Transform(carla.Location(x=0.0, z=2.4))
        self._actor = self._world.spawn_actor(lidar_bp, transform, attach_to=self._vehicle)

        def _cb(carla_meas):
            recv_t = time.time()
            points = raw_sensors._decode_lidar(carla_meas)
            self._seq += 1
            frame = LiDARFrame(
                sensor_id=self.sensor_id, frame_id=carla_meas.frame,
                timestamp=Timestamp(sensor_time=carla_meas.timestamp, reception_time=recv_t),
                sequence_number=self._seq, payload=None,
                point_count=points.shape[0], dimensions=points.shape[1], points=points,
            )
            ok, reason = validate_lidar_frame(frame)
            if not ok:
                from .sensor_types import FrameStatus
                frame.status = FrameStatus.INVALID
                frame.metadata["invalid_reason"] = reason
            on_frame(frame)

        self._actor.listen(_cb)

    def stop(self) -> None:
        if self._actor is not None:
            try:
                if self._actor.is_alive:
                    self._actor.destroy()
            except Exception:
                pass
            self._actor = None


class CARLARadarSensor(SensorInterface):
    """
    See module docstring: Phase 0's sensor_config.yaml marks radar as not
    configured for this vehicle. This class honestly reports that instead
    of fabricating detections. `start()` is a no-op when not configured.
    """
    sensor_type = SensorType.RADAR

    def __init__(self, world, vehicle, sensor_id: str = "radar_front", configured: bool = False, transform=None):
        self.sensor_id = sensor_id
        self._world, self._vehicle = world, vehicle
        self._configured = configured
        self._transform = transform
        self._actor = None
        self._seq = 0

    @property
    def availability(self) -> SensorAvailability:
        return SensorAvailability.AVAILABLE if self._configured else SensorAvailability.NOT_CONFIGURED

    def start(self, on_frame: Callable[[object], None]) -> None:
        if not self._configured:
            return  # honest no-op; SensorManager reads .availability to report NOT_CONFIGURED
        import carla
        from .sensor_types import RadarDetection

        bp_lib = self._world.get_blueprint_library()
        radar_bp = bp_lib.find("sensor.other.radar")
        transform = self._transform or carla.Transform(carla.Location(x=2.0, z=1.0))
        self._actor = self._world.spawn_actor(radar_bp, transform, attach_to=self._vehicle)

        def _cb(carla_radar_measurement):
            recv_t = time.time()
            detections = [
                RadarDetection(depth=d.depth, velocity=d.velocity, azimuth=d.azimuth, altitude=d.altitude)
                for d in carla_radar_measurement
            ]
            self._seq += 1
            frame = RadarFrame(
                sensor_id=self.sensor_id, frame_id=carla_radar_measurement.frame,
                timestamp=Timestamp(sensor_time=carla_radar_measurement.timestamp, reception_time=recv_t),
                sequence_number=self._seq, payload=None,
                detection_count=len(detections), detections=detections,
            )
            ok, reason = validate_radar_frame(frame)
            if not ok:
                from .sensor_types import FrameStatus
                frame.status = FrameStatus.INVALID
                frame.metadata["invalid_reason"] = reason
            on_frame(frame)

        self._actor.listen(_cb)

    def stop(self) -> None:
        if self._actor is not None:
            try:
                if self._actor.is_alive:
                    self._actor.destroy()
            except Exception:
                pass
            self._actor = None


# ---------------------------------------------------------------------------
# Offline replay implementations — same interface, no CARLA needed
# ---------------------------------------------------------------------------

class _OfflineReplayBase(SensorInterface):
    """Shared plumbing: reads a list of already-deserialized SensorFrame objects."""

    def __init__(self, sensor_id: str, frames: list, playback_rate: float = 1.0):
        self.sensor_id = sensor_id
        self._frames = frames
        self._playback_rate = playback_rate
        self._stopped = True
        self._thread = None

    def start(self, on_frame: Callable[[object], None]) -> None:
        import threading

        self._stopped = False

        def _run():
            prev_t = None
            for frame in self._frames:
                if self._stopped:
                    break
                if prev_t is not None and frame.timestamp.sensor_time is not None:
                    dt = max(0.0, (frame.timestamp.sensor_time - prev_t) / max(self._playback_rate, 1e-6))
                    time.sleep(min(dt, 1.0))
                prev_t = frame.timestamp.sensor_time
                on_frame(frame)

        self._thread = threading.Thread(target=_run, daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._stopped = True
        if self._thread is not None:
            self._thread.join(timeout=1.0)
            self._thread = None


class OfflineCameraReplay(_OfflineReplayBase):
    sensor_type = SensorType.CAMERA


class OfflineLiDARReplay(_OfflineReplayBase):
    sensor_type = SensorType.LIDAR


class OfflineRadarReplay(_OfflineReplayBase):
    sensor_type = SensorType.RADAR
