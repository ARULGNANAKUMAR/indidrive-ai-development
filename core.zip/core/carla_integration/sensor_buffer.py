"""
IndiDrive AI — Phase 1 | Thread-Safe Sensor Buffer
=====================================================
A bounded, thread-safe ring buffer per sensor. CARLA sensor callbacks
fire on background threads; readers (health monitor, recorder, future
perception) run on other threads. This is the single synchronization
point between them.

Overflow policy is configurable:
    DROP_OLDEST  (default) — evict the oldest frame to make room (this is
                 what deque(maxlen=N) does natively, so it's effectively free)
    KEEP_LATEST  — reject the newest frame instead (rare; useful if you
                 want the buffer to represent "the earliest unconsumed
                 window" rather than "the most recent window")

Never grows unbounded — capacity is enforced at construction time.
"""
from __future__ import annotations

import threading
from collections import deque
from typing import Optional

from .sensor_types import SensorFrame


DROP_OLDEST = "DROP_OLDEST"
KEEP_LATEST = "KEEP_LATEST"
VALID_POLICIES = (DROP_OLDEST, KEEP_LATEST)


class SensorBuffer:
    """A bounded, thread-safe FIFO of SensorFrame for a single sensor."""

    def __init__(self, sensor_id: str, capacity: int = 30, overflow_policy: str = DROP_OLDEST):
        if capacity <= 0:
            raise ValueError("capacity must be > 0")
        if overflow_policy not in VALID_POLICIES:
            raise ValueError(f"overflow_policy must be one of {VALID_POLICIES}")
        self.sensor_id = sensor_id
        self.capacity = capacity
        self.overflow_policy = overflow_policy

        self._lock = threading.Lock()
        # deque(maxlen=) already implements DROP_OLDEST for free on append().
        self._frames: deque[SensorFrame] = deque(maxlen=capacity if overflow_policy == DROP_OLDEST else None)
        self._dropped_count = 0
        self._total_pushed = 0
        self._closed = False

    def push(self, frame: SensorFrame) -> bool:
        """Add a frame. Returns True if stored, False if rejected (KEEP_LATEST overflow, or closed)."""
        with self._lock:
            if self._closed:
                return False
            self._total_pushed += 1
            if self.overflow_policy == KEEP_LATEST and len(self._frames) >= self.capacity:
                self._dropped_count += 1
                return False
            if self.overflow_policy == DROP_OLDEST and len(self._frames) >= self.capacity:
                self._dropped_count += 1  # the deque itself evicts the oldest on append
            self._frames.append(frame)
            return True

    def latest(self) -> Optional[SensorFrame]:
        with self._lock:
            return self._frames[-1] if self._frames else None

    def get_by_frame_id(self, frame_id: int) -> Optional[SensorFrame]:
        with self._lock:
            for f in reversed(self._frames):
                if f.frame_id == frame_id:
                    return f
        return None

    def get_closest_by_timestamp(self, sensor_time: float) -> Optional[SensorFrame]:
        """Returns the buffered frame whose Timestamp.sensor_time is closest to `sensor_time`."""
        with self._lock:
            candidates = [f for f in self._frames if f.timestamp.sensor_time is not None]
            if not candidates:
                return None
            return min(candidates, key=lambda f: abs(f.timestamp.sensor_time - sensor_time))

    def snapshot(self) -> list[SensorFrame]:
        """Copy of all currently buffered frames, oldest first."""
        with self._lock:
            return list(self._frames)

    def __len__(self) -> int:
        with self._lock:
            return len(self._frames)

    @property
    def dropped_count(self) -> int:
        with self._lock:
            return self._dropped_count

    @property
    def total_pushed(self) -> int:
        with self._lock:
            return self._total_pushed

    def clear(self) -> None:
        with self._lock:
            self._frames.clear()

    def close(self) -> None:
        """Stop accepting new frames and release held frames. Idempotent."""
        with self._lock:
            self._closed = True
            self._frames.clear()

    def stats(self) -> dict:
        with self._lock:
            return {
                "sensor_id": self.sensor_id,
                "capacity": self.capacity,
                "size": len(self._frames),
                "overflow_policy": self.overflow_policy,
                "dropped_count": self._dropped_count,
                "total_pushed": self._total_pushed,
                "closed": self._closed,
            }
