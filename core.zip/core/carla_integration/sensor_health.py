"""
IndiDrive AI — Phase 1 | Sensor Health Monitor
=================================================
Tracks per-sensor runtime health from ACTUAL measurements pushed in by
SensorManager — this module never invents FPS or latency numbers.

States:
    ONLINE          receiving frames within the expected interval
    DEGRADED        connected but stale/slow (frame age or callback
                    latency exceeds the configured threshold)
    OFFLINE         was online, no frames for a long time / explicit stop
    NOT_CONFIGURED  sensor was never enabled/attached (e.g. radar)
"""
from __future__ import annotations

import threading
import time
from dataclasses import dataclass, field
from typing import Optional

ONLINE = "ONLINE"
OFFLINE = "OFFLINE"
DEGRADED = "DEGRADED"
NOT_CONFIGURED = "NOT_CONFIGURED"

VALID_STATES = (ONLINE, OFFLINE, DEGRADED, NOT_CONFIGURED)


@dataclass
class SensorHealthRecord:
    sensor_id: str
    state: str = NOT_CONFIGURED
    last_frame_id: Optional[int] = None
    last_frame_time: Optional[float] = None
    fps: float = 0.0
    dropped_frames: int = 0
    callback_latency_ms: float = 0.0
    error_count: int = 0
    last_error: Optional[str] = None

    def frame_age(self) -> Optional[float]:
        if self.last_frame_time is None:
            return None
        return max(0.0, time.time() - self.last_frame_time)

    def to_dict(self) -> dict:
        return {
            "sensor_id": self.sensor_id,
            "status": self.state,
            "fps": round(self.fps, 2),
            "last_frame_id": self.last_frame_id,
            "frame_age_s": None if self.frame_age() is None else round(self.frame_age(), 3),
            "dropped_frames": self.dropped_frames,
            "callback_latency_ms": round(self.callback_latency_ms, 2),
            "error_count": self.error_count,
            "last_error": self.last_error,
        }


class SensorHealthMonitor:
    """
    Thread-safe health tracker. SensorManager calls `record_frame()` on
    every successful frame and `record_error()` on failures; anything
    (API, CLI, logs) can call `report()` to read current state.
    """

    def __init__(self, stale_after_s: float = 1.0, degraded_latency_ms: float = 200.0):
        self._lock = threading.Lock()
        self._records: dict[str, SensorHealthRecord] = {}
        self._fps_window: dict[str, list[float]] = {}
        self.stale_after_s = stale_after_s
        self.degraded_latency_ms = degraded_latency_ms

    def register(self, sensor_id: str, configured: bool = True) -> None:
        with self._lock:
            if sensor_id not in self._records:
                self._records[sensor_id] = SensorHealthRecord(
                    sensor_id=sensor_id,
                    state=OFFLINE if configured else NOT_CONFIGURED,
                )

    def mark_not_configured(self, sensor_id: str) -> None:
        with self._lock:
            self._records[sensor_id] = SensorHealthRecord(sensor_id=sensor_id, state=NOT_CONFIGURED)

    def record_frame(self, sensor_id: str, frame_id: int, callback_latency_ms: float = 0.0) -> None:
        now = time.time()
        with self._lock:
            rec = self._records.setdefault(sensor_id, SensorHealthRecord(sensor_id=sensor_id))
            window = self._fps_window.setdefault(sensor_id, [])
            window.append(now)
            cutoff = now - 2.0
            while window and window[0] < cutoff:
                window.pop(0)
            rec.fps = (len(window) / 2.0) if len(window) > 1 else rec.fps

            rec.last_frame_id = frame_id
            rec.last_frame_time = now
            rec.callback_latency_ms = callback_latency_ms
            rec.state = DEGRADED if callback_latency_ms > self.degraded_latency_ms else ONLINE

    def record_dropped(self, sensor_id: str, count: int = 1) -> None:
        with self._lock:
            rec = self._records.setdefault(sensor_id, SensorHealthRecord(sensor_id=sensor_id))
            rec.dropped_frames += count

    def record_error(self, sensor_id: str, error: str) -> None:
        with self._lock:
            rec = self._records.setdefault(sensor_id, SensorHealthRecord(sensor_id=sensor_id))
            rec.error_count += 1
            rec.last_error = error

    def mark_offline(self, sensor_id: str) -> None:
        with self._lock:
            rec = self._records.setdefault(sensor_id, SensorHealthRecord(sensor_id=sensor_id))
            rec.state = OFFLINE

    def refresh_staleness(self) -> None:
        """Call periodically: demotes ONLINE/DEGRADED sensors to OFFLINE if no frame for a while."""
        with self._lock:
            for rec in self._records.values():
                if rec.state == NOT_CONFIGURED:
                    continue
                age = rec.frame_age()
                if age is not None and age > self.stale_after_s and rec.state != OFFLINE:
                    rec.state = OFFLINE

    def report(self) -> dict[str, dict]:
        self.refresh_staleness()
        with self._lock:
            return {sid: rec.to_dict() for sid, rec in self._records.items()}

    def status_text(self) -> str:
        """Human-readable status block, matching the Phase 1 spec's example format."""
        report = self.report()
        lines = ["INDIDRIVE SENSOR STATUS", "=" * 32]
        for sid, d in report.items():
            lines.append(f"\n{sid}")
            lines.append(f"Status        : {d['status']}")
            if d["status"] != NOT_CONFIGURED:
                lines.append(f"FPS           : {d['fps']}")
                lines.append(f"Last Frame    : {d['last_frame_id']}")
                lines.append(f"Dropped       : {d['dropped_frames']}")
                lines.append(f"Latency       : {d['callback_latency_ms']} ms")
        return "\n".join(lines)
