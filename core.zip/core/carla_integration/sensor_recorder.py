"""
IndiDrive AI — Phase 1 | Sensor Recording
============================================
Writes SensorFrame streams to disk under:

    data/recordings/session_YYYYMMDD_HHMMSS/
        camera/<sensor_id>/<frame_id>.npy   (+ .json metadata)
        lidar/<sensor_id>/<frame_id>.npy    (+ .json metadata)
        radar/<sensor_id>/<frame_id>.json
        metadata/
        sensor_manifest.json

Only creates subfolders for sensors that actually recorded at least one
frame. Enforces configurable safety limits (max duration / frame count /
storage size) so a forgotten recording session cannot fill the disk.
"""
from __future__ import annotations

import json
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

import numpy as np

from .sensor_types import CameraFrame, LiDARFrame, RadarFrame, SensorFrame

try:
    from core.logging_system import get_logger
except ImportError:  # pragma: no cover
    get_logger = None

ROOT = Path(__file__).resolve().parent.parent.parent
RECORDINGS_DIR = ROOT / "data" / "recordings"


@dataclass
class RecordingLimits:
    max_duration_s: Optional[float] = None
    max_frame_count: Optional[int] = None
    max_storage_bytes: Optional[int] = None


@dataclass
class _SensorStats:
    frames_written: int = 0
    frames_dropped: int = 0
    bytes_written: int = 0


class SensorRecorder:
    def __init__(self, map_name: str = "unknown", vehicle_desc: str = "unknown",
                 limits: Optional[RecordingLimits] = None, base_dir: Optional[Path] = None):
        self.session_id = "session_" + time.strftime("%Y%m%d_%H%M%S")
        self._base_dir = base_dir or RECORDINGS_DIR
        self.session_dir = self._base_dir / self.session_id
        self.map_name = map_name
        self.vehicle_desc = vehicle_desc
        self.limits = limits or RecordingLimits()
        self._log = get_logger("sensors", component="sensor_recorder") if get_logger else None

        self._start_time: Optional[float] = None
        self._end_time: Optional[float] = None
        self._active = False
        self._stop_reason: Optional[str] = None
        self._stats: dict[str, _SensorStats] = {}
        self._enabled_kinds: set[str] = set()

    def _info(self, event: str, **extra) -> None:
        if self._log:
            self._log.info(event, **extra)

    def _warn(self, event: str, **extra) -> None:
        if self._log:
            self._log.warning(event, **extra)

    def start(self) -> None:
        self.session_dir.mkdir(parents=True, exist_ok=True)
        (self.session_dir / "metadata").mkdir(exist_ok=True)
        self._start_time = time.time()
        self._active = True
        self._info("recording_start", session_id=self.session_id, map=self.map_name)

    @property
    def total_frames(self) -> int:
        return sum(s.frames_written for s in self._stats.values())

    @property
    def total_bytes(self) -> int:
        return sum(s.bytes_written for s in self._stats.values())

    def _limit_exceeded(self) -> Optional[str]:
        if self.limits.max_duration_s is not None and self._start_time is not None:
            if time.time() - self._start_time >= self.limits.max_duration_s:
                return f"max_duration_s ({self.limits.max_duration_s}) reached"
        if self.limits.max_frame_count is not None and self.total_frames >= self.limits.max_frame_count:
            return f"max_frame_count ({self.limits.max_frame_count}) reached"
        if self.limits.max_storage_bytes is not None and self.total_bytes >= self.limits.max_storage_bytes:
            return f"max_storage_bytes ({self.limits.max_storage_bytes}) reached"
        return None

    def write_frame(self, frame: SensorFrame) -> bool:
        """Write one frame to disk. Returns False (without raising) once recording has stopped."""
        if not self._active:
            return False

        exceeded = self._limit_exceeded()
        if exceeded:
            self.stop(reason=exceeded)
            return False

        kind = frame.sensor_type.value  # "camera" | "lidar" | "radar"
        self._enabled_kinds.add(kind)
        sensor_dir = self.session_dir / kind / frame.sensor_id
        sensor_dir.mkdir(parents=True, exist_ok=True)

        stats = self._stats.setdefault(frame.sensor_id, _SensorStats())
        bytes_written = 0
        try:
            if isinstance(frame, CameraFrame) and frame.image is not None:
                path = sensor_dir / f"{frame.frame_id}.npy"
                np.save(path, frame.image)
                bytes_written = path.stat().st_size
            elif isinstance(frame, LiDARFrame) and frame.points is not None:
                path = sensor_dir / f"{frame.frame_id}.npy"
                np.save(path, frame.points)
                bytes_written = path.stat().st_size
            elif isinstance(frame, RadarFrame):
                path = sensor_dir / f"{frame.frame_id}.json"
                path.write_text(json.dumps(frame.to_dict(include_payload=True), default=str))
                bytes_written = path.stat().st_size

            meta_path = sensor_dir / f"{frame.frame_id}.meta.json"
            meta_path.write_text(json.dumps(frame.to_dict(include_payload=False), default=str))
            bytes_written += meta_path.stat().st_size
        except OSError as e:
            self._warn("recording_write_failed", error=str(e), sensor_id=frame.sensor_id,
                       frame_id=frame.frame_id)
            stats.frames_dropped += 1
            return False

        stats.frames_written += 1
        stats.bytes_written += bytes_written
        return True

    def stop(self, reason: str = "manual_stop") -> None:
        if not self._active:
            return
        self._active = False
        self._end_time = time.time()
        self._stop_reason = reason
        self._write_manifest()
        self._info("recording_stop", session_id=self.session_id, reason=reason,
                   total_frames=self.total_frames)

    def _write_manifest(self) -> None:
        duration = (self._end_time or time.time()) - (self._start_time or time.time())
        manifest = {
            "session_id": self.session_id,
            "map": self.map_name,
            "vehicle": self.vehicle_desc,
            "start_time": self._start_time,
            "end_time": self._end_time,
            "duration_s": duration,
            "stop_reason": self._stop_reason,
            "sensors": {
                sid: {
                    "frames_written": s.frames_written,
                    "frames_dropped": s.frames_dropped,
                    "bytes_written": s.bytes_written,
                } for sid, s in self._stats.items()
            },
            "statistics": {
                "total_frames": self.total_frames,
                "total_dropped": sum(s.frames_dropped for s in self._stats.values()),
                "total_bytes": self.total_bytes,
            },
        }
        (self.session_dir / "sensor_manifest.json").write_text(json.dumps(manifest, indent=2, default=str))

    @property
    def is_active(self) -> bool:
        return self._active
