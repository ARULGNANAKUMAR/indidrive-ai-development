"""
IndiDrive AI — CARLA Client | Connection Manager
==================================================
Thin, honest wrapper around carla.Client. Does not hide CARLA's real
API behind an abstraction that pretends to be simulator-agnostic —
this project targets CARLA specifically, and hiding that would make
debugging harder, not easier.

Import of `carla` is deferred to runtime (not at module load) so that
the rest of this codebase (dataset manager, tests, etc.) can be
imported and unit-tested on machines that don't have CARLA installed.
"""
from __future__ import annotations

import time
from typing import Optional


class CarlaUnavailableError(RuntimeError):
    """Raised when the `carla` package isn't installed or the server isn't reachable."""


class CarlaConnection:
    def __init__(self, host: str = "localhost", port: int = 2000, timeout: float = 10.0):
        self.host = host
        self.port = port
        self.timeout = timeout
        self._client = None
        self._world = None

    def connect(self):
        try:
            import carla  # noqa: F401  (deferred import — see module docstring)
        except ImportError as e:
            raise CarlaUnavailableError(
                "The `carla` package is not installed in this environment. "
                "Install it from CARLA's own PythonAPI/dist wheel — see docs/CARLA_SETUP.md. "
                f"Original error: {e}"
            )
        import carla
        self._client = carla.Client(self.host, self.port)
        self._client.set_timeout(self.timeout)
        try:
            self._world = self._client.get_world()
        except RuntimeError as e:
            raise CarlaUnavailableError(
                f"Could not reach a CARLA server at {self.host}:{self.port}. "
                "Is CarlaUE4.exe / CarlaUE4.sh actually running and fully loaded? "
                f"Original error: {e}"
            )
        return self

    @property
    def client(self):
        if self._client is None:
            raise RuntimeError("Not connected — call connect() first.")
        return self._client

    @property
    def world(self):
        if self._world is None:
            raise RuntimeError("Not connected — call connect() first.")
        return self._world

    def server_info(self) -> dict:
        return {
            "client_version": self._client.get_client_version(),
            "server_version": self._client.get_server_version(),
            "current_map": self._world.get_map().name,
            "available_maps": self._client.get_available_maps(),
        }

    def set_synchronous_mode(self, enabled: bool = True, fixed_delta_seconds: float = 0.05):
        """
        Synchronous mode is what makes a driving-stack demo reproducible:
        the server only advances a simulation tick when your client calls
        world.tick(), instead of running in real time regardless of
        whether your code kept up. Almost everything downstream (ECHO
        experience logging, benchmarking) wants this for consistent
        timing — asynchronous mode is fine for a first "does it connect"
        smoke test only.
        """
        import carla
        settings = self._world.get_settings()
        settings.synchronous_mode = enabled
        settings.fixed_delta_seconds = fixed_delta_seconds if enabled else None
        self._world.apply_settings(settings)

    def tick(self, timeout: Optional[float] = None):
        return self._world.tick() if timeout is None else self._world.tick(timeout)

    def cleanup_actors(self, actor_list: list):
        """Destroy actors and sensors cleanly — leaked actors pile up across runs otherwise."""
        for actor in actor_list:
            try:
                if actor is not None and actor.is_alive:
                    actor.destroy()
            except Exception:
                pass
