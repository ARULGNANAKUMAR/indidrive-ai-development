"""
IndiDrive AI — CARLA Client | Sensors
=======================================
Attaches RGB camera, LIDAR, and collision sensors to a vehicle, and
provides a thread-safe SensorBus to read the latest data from each.

Real detail that matters: CARLA sensor callbacks fire on a background
thread, not your main loop. Reading `self.latest_frame` from your main
thread while the callback thread is writing it is a real race condition
if you don't guard it — so this uses a lock, not because it "looks more
professional" but because skipping it produces genuinely corrupted
frames intermittently.
"""
from __future__ import annotations
import threading
from typing import Optional, Callable
import numpy as np


class SensorBus:
    """Holds the latest reading from each attached sensor, thread-safely."""
    def __init__(self):
        self._lock = threading.Lock()
        self._latest: dict[str, object] = {}
        self._frame_counts: dict[str, int] = {}

    def _make_callback(self, name: str, decode_fn: Optional[Callable] = None):
        def _cb(data):
            decoded = decode_fn(data) if decode_fn else data
            with self._lock:
                self._latest[name] = decoded
                self._frame_counts[name] = self._frame_counts.get(name, 0) + 1
        return _cb

    def get(self, name: str):
        with self._lock:
            return self._latest.get(name)

    def frame_count(self, name: str) -> int:
        with self._lock:
            return self._frame_counts.get(name, 0)

    def all_names(self) -> list[str]:
        with self._lock:
            return list(self._latest.keys())


def _decode_rgb_image(carla_image) -> np.ndarray:
    """carla.Image.raw_data is BGRA bytes; decode into an HxWx3 RGB numpy array."""
    arr = np.frombuffer(carla_image.raw_data, dtype=np.uint8)
    arr = arr.reshape((carla_image.height, carla_image.width, 4))  # BGRA
    return arr[:, :, :3][:, :, ::-1].copy()  # drop alpha, BGR->RGB, own the memory


def _decode_lidar(carla_lidar_measurement) -> np.ndarray:
    """Returns an Nx4 array of [x, y, z, intensity] points."""
    arr = np.frombuffer(carla_lidar_measurement.raw_data, dtype=np.float32)
    return arr.reshape((-1, 4)).copy()


def attach_rgb_camera(world, vehicle, bus: SensorBus, name: str = "rgb_front",
                       width: int = 800, height: int = 600, fov: float = 90.0,
                       transform=None):
    import carla
    bp_lib = world.get_blueprint_library()
    cam_bp = bp_lib.find("sensor.camera.rgb")
    cam_bp.set_attribute("image_size_x", str(width))
    cam_bp.set_attribute("image_size_y", str(height))
    cam_bp.set_attribute("fov", str(fov))
    if transform is None:
        transform = carla.Transform(carla.Location(x=1.6, z=1.7))  # roughly windshield-mounted
    camera = world.spawn_actor(cam_bp, transform, attach_to=vehicle)
    camera.listen(bus._make_callback(name, _decode_rgb_image))
    return camera


def attach_lidar(world, vehicle, bus: SensorBus, name: str = "lidar_top",
                  channels: int = 32, range_m: float = 50.0,
                  points_per_second: int = 100_000, rotation_frequency: float = 10.0,
                  transform=None):
    import carla
    bp_lib = world.get_blueprint_library()
    lidar_bp = bp_lib.find("sensor.lidar.ray_cast")
    lidar_bp.set_attribute("channels", str(channels))
    lidar_bp.set_attribute("range", str(range_m))
    lidar_bp.set_attribute("points_per_second", str(points_per_second))
    lidar_bp.set_attribute("rotation_frequency", str(rotation_frequency))
    if transform is None:
        transform = carla.Transform(carla.Location(x=0.0, z=2.4))
    lidar = world.spawn_actor(lidar_bp, transform, attach_to=vehicle)
    lidar.listen(bus._make_callback(name, _decode_lidar))
    return lidar


def attach_collision_sensor(world, vehicle, bus: SensorBus, name: str = "collision"):
    import carla
    bp_lib = world.get_blueprint_library()
    col_bp = bp_lib.find("sensor.other.collision")
    transform = carla.Transform()
    collision_sensor = world.spawn_actor(col_bp, transform, attach_to=vehicle)

    def decode(event):
        other = event.other_actor
        return {
            "other_actor_type": other.type_id if other else "unknown",
            "impulse": (event.normal_impulse.x, event.normal_impulse.y, event.normal_impulse.z),
            "frame": event.frame,
        }
    collision_sensor.listen(bus._make_callback(name, decode))
    return collision_sensor


def attach_lane_invasion_sensor(world, vehicle, bus: SensorBus, name: str = "lane_invasion"):
    import carla
    bp_lib = world.get_blueprint_library()
    li_bp = bp_lib.find("sensor.other.lane_invasion")
    transform = carla.Transform()
    sensor = world.spawn_actor(li_bp, transform, attach_to=vehicle)

    def decode(event):
        return {"crossed_lane_markings": [str(m.type) for m in event.crossed_lane_markings],
                "frame": event.frame}
    sensor.listen(bus._make_callback(name, decode))
    return sensor
