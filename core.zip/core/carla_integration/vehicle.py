"""
IndiDrive AI — CARLA Client | Vehicle Spawning
================================================
Spawns an ego vehicle at a valid map spawn point, with real collision
handling: CARLA spawn points can be occupied or invalid on a given map,
so this retries across the map's actual spawn point list rather than
assuming index 0 always works (a common source of silent failures in
CARLA tutorials).
"""
from __future__ import annotations
import random
from typing import Optional


def spawn_ego_vehicle(world, blueprint_filter: str = "vehicle.tesla.model3",
                       preferred_spawn_index: Optional[int] = None, max_attempts: int = 20):
    """
    Returns the spawned carla.Vehicle actor, or raises RuntimeError if no
    spawn point worked after max_attempts.
    """
    import carla
    blueprint_library = world.get_blueprint_library()
    matches = blueprint_library.filter(blueprint_filter)
    if not matches:
        raise ValueError(f"No vehicle blueprint matches filter '{blueprint_filter}'. "
                          f"Try 'vehicle.*' to see what's available on this CARLA build.")
    vehicle_bp = matches[0]
    if vehicle_bp.has_attribute("color"):
        color = random.choice(vehicle_bp.get_attribute("color").recommended_values)
        vehicle_bp.set_attribute("color", color)

    spawn_points = world.get_map().get_spawn_points()
    if not spawn_points:
        raise RuntimeError("This map reports zero spawn points — is the map fully loaded?")

    order = list(range(len(spawn_points)))
    if preferred_spawn_index is not None and 0 <= preferred_spawn_index < len(spawn_points):
        order.remove(preferred_spawn_index)
        order.insert(0, preferred_spawn_index)
    else:
        random.shuffle(order)

    last_error = None
    for idx in order[:max_attempts]:
        try:
            vehicle = world.spawn_actor(vehicle_bp, spawn_points[idx])
            return vehicle
        except RuntimeError as e:
            # Spawn point occupied/colliding — CARLA raises this per-attempt, not fatal.
            last_error = e
            continue
    raise RuntimeError(f"Failed to spawn vehicle after {min(max_attempts, len(order))} attempts "
                        f"across available spawn points. Last error: {last_error}")


def enable_autopilot(vehicle, traffic_manager_port: int = 8000, enabled: bool = True):
    """
    Uses CARLA's built-in Traffic Manager for a first working control
    loop — real rule-based driving behavior, not a stub. Your own
    planner replaces this call once it exists; this exists so the
    camera-feed milestone can show a vehicle that's actually moving
    through traffic, not sitting still.
    """
    vehicle.set_autopilot(enabled, traffic_manager_port)
