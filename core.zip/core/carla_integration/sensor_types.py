"""
IndiDrive AI — Phase 1 | Sensor Data Contract
================================================
Strongly-typed frame representations for the sensor pipeline. These are
the ONLY shapes that flow through SensorBuffer / SensorManager /
SensorRecorder / OfflineSensorReplay. Nothing here performs perception —
these are structural containers plus small validation helpers.

Design note: dataclasses (not raw dicts) so that a typo in a field name
is a AttributeError at dev time, not a silent None at 3am during a demo.
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Optional

import numpy as np


class SensorType(str, Enum):
    CAMERA = "camera"
    LIDAR = "lidar"
    RADAR = "radar"


class FrameStatus(str, Enum):
    OK = "OK"
    INVALID = "INVALID"
    DROPPED = "DROPPED"


class SensorAvailability(str, Enum):
    """Used by the radar interface (and anything else that may not exist)."""
    AVAILABLE = "AVAILABLE"
    NOT_CONFIGURED = "NOT_CONFIGURED"
    NOT_AVAILABLE = "NOT_AVAILABLE"
    DISABLED = "DISABLED"


@dataclass
class Timestamp:
    """
    Tracks the three points in a frame's life that Phase 1 cares about.
    `sensor_time` is the simulation/sensor clock (e.g. carla frame/elapsed
    time) when available; `reception_time` and `processing_time` are wall
    clock (time.time()) on this machine.
    """
    sensor_time: Optional[float] = None
    reception_time: float = field(default_factory=time.time)
    processing_time: Optional[float] = None

    def mark_processed(self) -> None:
        self.processing_time = time.time()

    @property
    def transport_delay(self) -> Optional[float]:
        """reception - sensor. None if sensor_time unknown (e.g. offline replay pre-Phase0 data)."""
        if self.sensor_time is None:
            return None
        return max(0.0, self.reception_time - self.sensor_time)

    @property
    def processing_delay(self) -> Optional[float]:
        if self.processing_time is None:
            return None
        return max(0.0, self.processing_time - self.reception_time)

    @property
    def age(self) -> float:
        """How long ago (seconds, wall clock) this frame was received."""
        return max(0.0, time.time() - self.reception_time)

    def to_dict(self) -> dict:
        return {
            "sensor_time": self.sensor_time,
            "reception_time": self.reception_time,
            "processing_time": self.processing_time,
            "transport_delay": self.transport_delay,
            "processing_delay": self.processing_delay,
        }


@dataclass
class SensorFrame:
    """Base envelope shared by every sensor frame type."""
    sensor_id: str
    sensor_type: SensorType
    frame_id: int
    timestamp: Timestamp
    sequence_number: int
    payload: Any
    metadata: dict = field(default_factory=dict)
    status: FrameStatus = FrameStatus.OK

    def to_dict(self, include_payload: bool = False) -> dict:
        d = {
            "sensor_id": self.sensor_id,
            "sensor_type": self.sensor_type.value,
            "frame_id": self.frame_id,
            "timestamp": self.timestamp.to_dict(),
            "sequence_number": self.sequence_number,
            "metadata": self.metadata,
            "status": self.status.value,
        }
        if include_payload:
            d["payload"] = self.payload
        return d


@dataclass
class CameraFrame(SensorFrame):
    width: int = 0
    height: int = 0
    channels: int = 3
    encoding: str = "rgb8"
    image: Optional[np.ndarray] = None

    sensor_type: SensorType = field(default=SensorType.CAMERA, init=False)

    def to_dict(self, include_payload: bool = False) -> dict:
        d = super().to_dict(include_payload=False)
        d.update({"width": self.width, "height": self.height,
                   "channels": self.channels, "encoding": self.encoding})
        if include_payload and self.image is not None:
            d["image"] = self.image
        return d


@dataclass
class LiDARFrame(SensorFrame):
    point_count: int = 0
    dimensions: int = 4  # x, y, z, intensity
    points: Optional[np.ndarray] = None

    sensor_type: SensorType = field(default=SensorType.LIDAR, init=False)

    def to_dict(self, include_payload: bool = False) -> dict:
        d = super().to_dict(include_payload=False)
        d.update({"point_count": self.point_count, "dimensions": self.dimensions})
        if include_payload and self.points is not None:
            d["points"] = self.points
        return d


@dataclass
class RadarDetection:
    depth: float
    velocity: float
    azimuth: float
    altitude: float


@dataclass
class RadarFrame(SensorFrame):
    detection_count: int = 0
    detections: list = field(default_factory=list)

    sensor_type: SensorType = field(default=SensorType.RADAR, init=False)

    def to_dict(self, include_payload: bool = False) -> dict:
        d = super().to_dict(include_payload=False)
        d.update({"detection_count": self.detection_count})
        if include_payload:
            d["detections"] = [vars(x) if isinstance(x, RadarDetection) else x
                                for x in self.detections]
        return d


# ---------------------------------------------------------------------------
# Validation helpers — Phase 1 only validates STRUCTURE, never CONTENT
# (no "is there an object in this image" — that is Phase 2 perception).
# ---------------------------------------------------------------------------

def validate_camera_frame(frame: CameraFrame) -> tuple[bool, str]:
    if frame.image is None:
        return False, "image is None"
    if not isinstance(frame.image, np.ndarray):
        return False, f"image is not a numpy array (got {type(frame.image).__name__})"
    if frame.image.dtype != np.uint8:
        return False, f"unexpected dtype {frame.image.dtype} (expected uint8)"
    if frame.image.ndim != 3:
        return False, f"expected a HxWxC image, got ndim={frame.image.ndim}"
    h, w, c = frame.image.shape
    if h != frame.height or w != frame.width or c != frame.channels:
        return False, (f"shape {frame.image.shape} does not match declared "
                        f"({frame.height}, {frame.width}, {frame.channels})")
    if h <= 0 or w <= 0:
        return False, f"non-positive dimensions: {frame.image.shape}"
    if frame.frame_id is None or frame.frame_id < 0:
        return False, "invalid frame_id"
    if frame.timestamp is None:
        return False, "missing timestamp"
    return True, "ok"


def validate_lidar_frame(frame: LiDARFrame) -> tuple[bool, str]:
    if frame.points is None:
        return False, "points is None"
    if not isinstance(frame.points, np.ndarray):
        return False, f"points is not a numpy array (got {type(frame.points).__name__})"
    if frame.points.size == 0:
        return False, "empty point cloud"
    if frame.points.ndim != 2 or frame.points.shape[1] != frame.dimensions:
        return False, f"expected Nx{frame.dimensions}, got shape {frame.points.shape}"
    if not np.issubdtype(frame.points.dtype, np.floating):
        return False, f"unexpected dtype {frame.points.dtype} (expected float)"
    if not np.isfinite(frame.points).all():
        return False, "point cloud contains NaN or Inf"
    if frame.point_count != frame.points.shape[0]:
        return False, f"point_count {frame.point_count} != actual {frame.points.shape[0]}"
    return True, "ok"


def validate_radar_frame(frame: RadarFrame) -> tuple[bool, str]:
    if frame.detections is None:
        return False, "detections is None"
    if frame.detection_count != len(frame.detections):
        return False, f"detection_count {frame.detection_count} != actual {len(frame.detections)}"
    for det in frame.detections:
        vals = (det.depth, det.velocity, det.azimuth, det.altitude) if isinstance(det, RadarDetection) \
            else (det.get("depth"), det.get("velocity"), det.get("azimuth"), det.get("altitude"))
        if any(v is None for v in vals):
            return False, "detection missing a required field"
        if any(isinstance(v, float) and (v != v) for v in vals):  # NaN check without importing math
            return False, "detection contains NaN"
    return True, "ok"
