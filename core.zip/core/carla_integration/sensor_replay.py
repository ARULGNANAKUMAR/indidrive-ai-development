"""
IndiDrive AI — Phase 1 | Offline Sensor Data Replay
======================================================
Reads a session directory written by SensorRecorder and reconstructs
SensorFrame objects, so downstream code (or OfflineCameraReplay /
OfflineLiDARReplay / OfflineRadarReplay in sensor_interface.py) can
consume recorded data through the exact same SensorFrame contract as
a live sensor.

This is NOT the autonomous brain and performs no perception — it only
deserializes what SensorRecorder wrote.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Optional

import numpy as np

from .sensor_types import (
    CameraFrame, LiDARFrame, RadarFrame, RadarDetection, SensorType, Timestamp, FrameStatus,
)


class OfflineSensorReplay:
    def __init__(self, session_dir: Path | str):
        self.session_dir = Path(session_dir)
        manifest_path = self.session_dir / "sensor_manifest.json"
        if not manifest_path.exists():
            raise FileNotFoundError(f"No sensor_manifest.json found in {self.session_dir}")
        self.manifest = json.loads(manifest_path.read_text())

    def available_sensors(self) -> dict[str, str]:
        """Returns {sensor_id: sensor_kind} for every sensor with recorded data."""
        found = {}
        for kind_dir in ("camera", "lidar", "radar"):
            kdir = self.session_dir / kind_dir
            if kdir.exists():
                for sensor_dir in kdir.iterdir():
                    if sensor_dir.is_dir():
                        found[sensor_dir.name] = kind_dir
        return found

    def load_frames(self, sensor_id: str) -> list:
        """Load ALL frames for one sensor, sorted by frame_id ascending."""
        sensors = self.available_sensors()
        kind = sensors.get(sensor_id)
        if kind is None:
            return []
        sensor_dir = self.session_dir / kind / sensor_id
        frames = []
        for meta_path in sorted(sensor_dir.glob("*.meta.json")):
            frame_id_str = meta_path.name.replace(".meta.json", "")
            meta = json.loads(meta_path.read_text())
            ts = Timestamp(
                sensor_time=meta["timestamp"].get("sensor_time"),
                reception_time=meta["timestamp"].get("reception_time", 0.0),
                processing_time=meta["timestamp"].get("processing_time"),
            )
            status = FrameStatus(meta.get("status", FrameStatus.OK.value))

            if kind == "camera":
                data_path = sensor_dir / f"{frame_id_str}.npy"
                image = np.load(data_path) if data_path.exists() else None
                frame = CameraFrame(
                    sensor_id=sensor_id, frame_id=int(frame_id_str), timestamp=ts,
                    sequence_number=meta.get("sequence_number", 0), payload=None,
                    width=meta.get("width", 0), height=meta.get("height", 0),
                    channels=meta.get("channels", 3), encoding=meta.get("encoding", "rgb8"),
                    image=image, metadata=meta.get("metadata", {}), status=status,
                )
            elif kind == "lidar":
                data_path = sensor_dir / f"{frame_id_str}.npy"
                points = np.load(data_path) if data_path.exists() else None
                frame = LiDARFrame(
                    sensor_id=sensor_id, frame_id=int(frame_id_str), timestamp=ts,
                    sequence_number=meta.get("sequence_number", 0), payload=None,
                    point_count=meta.get("point_count", 0), dimensions=meta.get("dimensions", 4),
                    points=points, metadata=meta.get("metadata", {}), status=status,
                )
            else:  # radar
                data_path = sensor_dir / f"{frame_id_str}.json"
                raw = json.loads(data_path.read_text()) if data_path.exists() else {}
                dets = [RadarDetection(**d) for d in raw.get("detections", [])]
                frame = RadarFrame(
                    sensor_id=sensor_id, frame_id=int(frame_id_str), timestamp=ts,
                    sequence_number=meta.get("sequence_number", 0), payload=None,
                    detection_count=len(dets), detections=dets,
                    metadata=meta.get("metadata", {}), status=status,
                )
            frames.append(frame)

        frames.sort(key=lambda f: f.frame_id)
        return frames

    def session_summary(self) -> dict:
        return {
            "session_id": self.manifest.get("session_id"),
            "map": self.manifest.get("map"),
            "duration_s": self.manifest.get("duration_s"),
            "sensors": self.manifest.get("sensors", {}),
            "statistics": self.manifest.get("statistics", {}),
        }
