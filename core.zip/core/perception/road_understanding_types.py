"""
IndiDrive AI — Phase 6.1 | Road & Drivable-Area Understanding Data Contracts
================================================================================
Structural containers for the road-geometry understanding layer produced by
`road_understanding.py`. Mirrors the design philosophy of Phase 2's
`perception_types.py` and Phase 3's `fusion_types.py`: dataclasses (not raw
dicts), explicit NOT_AVAILABLE states instead of fabricated values, and a
single stable output shape (`RoadUnderstanding`) that later phases (world
model, reasoning brain, adaptive path planner, collision avoidance, MPC) can
depend on.

Coordinate frame: vehicle frame as defined in docs/COORDINATE_SYSTEMS.md —
+X forward, +Y left, +Z up, origin at rear-axle center, meters. All
boundary/width geometry here is expressed in that frame unless explicitly
marked NOT_AVAILABLE. "left" boundary therefore has the larger Y value.

Nothing in this file performs road-understanding computation — these are
structural containers plus small helpers, same convention as Phase 2/3.
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Optional

from .perception_types import NOT_AVAILABLE

__all__ = [
    "NOT_AVAILABLE",
    "RoadUnderstandingStatus", "BoundaryAvailability",
    "BoundaryPoint", "RoadBoundary", "RoadWidthSample",
    "RoadUnderstanding",
]


class RoadUnderstandingStatus(str, Enum):
    OK = "OK"                        # both boundaries available, valid corridor
    PARTIAL = "PARTIAL"              # only one boundary side, or an incomplete corridor
    DEGRADED = "DEGRADED"            # sensor input present but below usable confidence/point thresholds
    UNAVAILABLE = "UNAVAILABLE"      # no usable sensor input this cycle (all sensors missing/empty)
    INVALID = "INVALID"              # inputs failed geometry validation (NaN/Inf/inconsistent boundaries)


class BoundaryAvailability(str, Enum):
    BOTH = "BOTH"
    LEFT_ONLY = "LEFT_ONLY"
    RIGHT_ONLY = "RIGHT_ONLY"
    NONE = "NONE"


@dataclass
class BoundaryPoint:
    """A single estimated boundary sample, in vehicle-frame meters."""
    x: float                    # forward distance (m)
    y: float                    # lateral position of the boundary at this x (m)
    confidence: float = 0.0
    point_support: int = 0      # number of raw sensor points backing this sample

    def to_dict(self) -> dict:
        return {
            "x": round(self.x, 3),
            "y": round(self.y, 3),
            "confidence": round(self.confidence, 3),
            "point_support": self.point_support,
        }


@dataclass
class RoadBoundary:
    """Left or right road-boundary estimate: a polyline of BoundaryPoint
    samples sorted by ascending x (forward distance)."""
    side: str                                     # "left" | "right"
    points: list = field(default_factory=list)    # list[BoundaryPoint]
    available: bool = False
    source: str = NOT_AVAILABLE                   # camera | lidar | fusion | unknown
    confidence: float = 0.0                        # aggregate confidence across points

    def to_dict(self) -> dict:
        return {
            "side": self.side,
            "available": self.available,
            "points": [p.to_dict() for p in self.points],
            "source": self.source,
            "confidence": round(self.confidence, 3),
        }


@dataclass
class RoadWidthSample:
    distance_m: float
    width_m: Optional[float] = None
    availability: BoundaryAvailability = BoundaryAvailability.NONE

    def to_dict(self) -> dict:
        return {
            "distance_m": round(self.distance_m, 3),
            "width_m": round(self.width_m, 3) if self.width_m is not None else NOT_AVAILABLE,
            "availability": self.availability.value,
        }


@dataclass
class RoadUnderstanding:
    """Phase 6.1 primary output. One RoadUnderstanding is produced per
    RoadUnderstandingPipeline.process() call. This module never calls into
    the world model, reasoning brain, planner, collision avoidance, or MPC —
    it only produces this structure for them to consume later.
    """
    timestamp: float
    frame_id: int
    status: RoadUnderstandingStatus = RoadUnderstandingStatus.UNAVAILABLE
    left_boundary: RoadBoundary = field(default_factory=lambda: RoadBoundary(side="left"))
    right_boundary: RoadBoundary = field(default_factory=lambda: RoadBoundary(side="right"))
    boundary_availability: BoundaryAvailability = BoundaryAvailability.NONE
    drivable_area_available: bool = False
    drivable_polygon: Optional[list] = None        # list[(x, y)] vehicle-frame vertices, or None
    road_width_profile: list = field(default_factory=list)   # list[RoadWidthSample]
    confidence: float = 0.0
    source: str = NOT_AVAILABLE                    # camera | lidar | fusion | unknown
    uncertainty: float = 1.0                        # 0 (certain) .. 1 (fully uncertain); kept separate from confidence
    sensor_status: dict = field(default_factory=dict)  # {"camera": "OK"/"UNAVAILABLE"/..., "lidar": ...}
    warnings: list = field(default_factory=list)
    created_at: float = field(default_factory=time.time)

    def to_dict(self) -> dict:
        return {
            "timestamp": self.timestamp,
            "frame_id": self.frame_id,
            "status": self.status.value,
            "left_boundary": self.left_boundary.to_dict(),
            "right_boundary": self.right_boundary.to_dict(),
            "boundary_availability": self.boundary_availability.value,
            "drivable_area_available": self.drivable_area_available,
            "drivable_polygon": (
                [[round(x, 3), round(y, 3)] for x, y in self.drivable_polygon]
                if self.drivable_polygon else NOT_AVAILABLE
            ),
            "road_width_profile": [s.to_dict() for s in self.road_width_profile],
            "confidence": round(self.confidence, 3),
            "source": self.source,
            "uncertainty": round(self.uncertainty, 3),
            "sensor_status": self.sensor_status,
            "warnings": self.warnings,
        }
