"""
IndiDrive AI — Phase 2 | Perception Health
==============================================
Tracks perception-layer health from ACTUAL measurements, mirroring the
design of Phase 1's core/carla_integration/sensor_health.py. Never
invents FPS/latency; only records what PerceptionManager actually
measured.
"""
from __future__ import annotations

import threading
import time
from dataclasses import dataclass, field
from typing import Optional

from .perception_types import HealthState


@dataclass
class PerceptionHealthRecord:
    component: str                     # "camera" | "lidar" | "road" | "anomaly"
    state: HealthState = HealthState.NOT_CONFIGURED
    frames_processed: int = 0
    frames_failed: int = 0
    frames_dropped: int = 0
    last_latency_ms: float = 0.0
    last_detection_count: int = 0
    last_error: Optional[str] = None
    last_update_time: Optional[float] = None

    def to_dict(self) -> dict:
        return {
            "component": self.component,
            "status": self.state.value,
            "frames_processed": self.frames_processed,
            "frames_failed": self.frames_failed,
            "frames_dropped": self.frames_dropped,
            "last_latency_ms": round(self.last_latency_ms, 3),
            "last_detection_count": self.last_detection_count,
            "last_error": self.last_error,
        }


class PerceptionHealthMonitor:
    def __init__(self):
        self._lock = threading.Lock()
        self._records: dict[str, PerceptionHealthRecord] = {}

    def mark_not_configured(self, component: str) -> None:
        with self._lock:
            self._records[component] = PerceptionHealthRecord(component=component, state=HealthState.NOT_CONFIGURED)

    def mark_not_available(self, component: str) -> None:
        with self._lock:
            self._records[component] = PerceptionHealthRecord(component=component, state=HealthState.NOT_AVAILABLE)

    def record_success(self, component: str, latency_ms: float, detection_count: int) -> None:
        with self._lock:
            rec = self._records.setdefault(component, PerceptionHealthRecord(component=component))
            rec.frames_processed += 1
            rec.last_latency_ms = latency_ms
            rec.last_detection_count = detection_count
            rec.last_update_time = time.time()
            rec.state = HealthState.HEALTHY

    def record_degraded(self, component: str, reason: str) -> None:
        with self._lock:
            rec = self._records.setdefault(component, PerceptionHealthRecord(component=component))
            rec.state = HealthState.DEGRADED
            rec.last_error = reason
            rec.last_update_time = time.time()

    def record_failure(self, component: str, error: str) -> None:
        with self._lock:
            rec = self._records.setdefault(component, PerceptionHealthRecord(component=component))
            rec.frames_failed += 1
            rec.state = HealthState.FAILED
            rec.last_error = error
            rec.last_update_time = time.time()

    def record_dropped(self, component: str, count: int = 1) -> None:
        with self._lock:
            rec = self._records.setdefault(component, PerceptionHealthRecord(component=component))
            rec.frames_dropped += count

    def report(self) -> dict:
        with self._lock:
            return {k: v.to_dict() for k, v in self._records.items()}
