"""
IndiDrive AI — Phase 2 | Shared Perception Utilities
========================================================
Small, dependency-free helpers used across the perception package.
"""
from __future__ import annotations

import time
from contextlib import contextmanager


class Stopwatch:
    """High-resolution timer. Usage:

        sw = Stopwatch()
        with sw:
            do_work()
        sw.elapsed_ms  # actual measured time, never a placeholder
    """
    def __init__(self):
        self.elapsed_ms: float = 0.0
        self._t0: float = 0.0

    def __enter__(self) -> "Stopwatch":
        self._t0 = time.perf_counter()
        return self

    def __exit__(self, *exc) -> None:
        self.elapsed_ms = (time.perf_counter() - self._t0) * 1000.0


@contextmanager
def timed():
    """Context manager yielding a dict that is filled with elapsed_ms on exit."""
    result = {"elapsed_ms": 0.0}
    t0 = time.perf_counter()
    try:
        yield result
    finally:
        result["elapsed_ms"] = (time.perf_counter() - t0) * 1000.0


def percentile(values: list[float], pct: float) -> float:
    """Simple percentile without a numpy/statistics dependency requirement
    at the call site (statistics module could also be used, but this
    keeps the perception package self-contained for this one helper)."""
    if not values:
        return 0.0
    s = sorted(values)
    k = (len(s) - 1) * (pct / 100.0)
    f = int(k)
    c = min(f + 1, len(s) - 1)
    if f == c:
        return s[f]
    return s[f] + (s[c] - s[f]) * (k - f)
