"""
IndiDrive AI — Phase 6.1 | Drivable Area & Road Boundary Understanding
================================================================================
Lightweight road-geometry understanding layer. Combines:

  - Phase 2 camera road perception (`RoadState`/`DrivableArea` — qualitative
    "is there road here, how confident" signal; classical-baseline backend,
    no calibrated pixel->meter geometry available in this repository, so it
    never contributes metric boundary points, only corroborating confidence).
  - Phase 2 LiDAR ground/obstacle separation (`LiDARPerceptionResult.ground_points`
    / `.obstacle_points`, already in vehicle-frame meters per
    docs/COORDINATE_SYSTEMS.md) — a lightweight geometric baseline: at each
    sampled forward distance, the left/right road boundary is estimated from
    the nearest obstacle and/or the observed edge of ground points on each
    side of the vehicle.

This module produces a `RoadUnderstanding` (see road_understanding_types.py)
for later phases (world model, reasoning brain, adaptive path planner,
collision avoidance, MPC) to consume. It does NOT call into any of those —
no path planning, no MPC, no steering/braking, no lane logic, no road-damage
classification (see docs/PHASE_6_1_ROAD_UNDERSTANDING.md for the exact scope
boundary).

Degraded-mode behaviour (Step 14 of the spec):

    camera OK + lidar OK      -> lidar geometry, camera corroborates confidence, source=fusion
    camera OK + lidar missing -> qualitative-only (no metric boundaries), source=camera
    camera missing + lidar OK -> lidar geometric baseline, source=lidar
    both missing               -> status=UNAVAILABLE, nothing fabricated

Never invents boundary geometry where there isn't enough supporting data —
see `_MIN_POINTS_PER_SAMPLE` / `RoadUnderstandingConfig.min_points_per_sample`.
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Any, Optional

import numpy as np

from .lidar_perception import LiDARPerceptionPipeline, LiDARPerceptionResult
from .perception_types import NOT_AVAILABLE, RoadState, DrivableArea, BackendKind
from .road_understanding_types import (
    RoadUnderstanding, RoadUnderstandingStatus, BoundaryAvailability,
    BoundaryPoint, RoadBoundary, RoadWidthSample,
)

try:
    from core.logging_system import get_logger
except ImportError:  # pragma: no cover
    get_logger = None


# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

@dataclass
class RoadUnderstandingConfig:
    enabled: bool = True
    minimum_confidence: float = 0.25
    # Forward distances (meters, vehicle frame +X) at which the road width
    # profile is sampled. Kept short/coarse by default — Step 11: "use only
    # the resolution needed by the existing planner/world model".
    forward_distances_m: tuple = (0.0, 10.0, 20.0, 30.0)
    longitudinal_bin_m: float = 3.0          # +/- half-bin around each sample distance
    lateral_bin_m: float = 0.0               # reserved; 0 = unused (single-bin lateral search)
    min_points_per_sample: int = 5           # below this, that side/sample is UNAVAILABLE, not guessed
    max_lateral_search_m: float = 15.0       # ignore points further out than this to either side
    max_plausible_width_m: float = 40.0      # widths beyond this are rejected as INVALID, not reported
    max_sensor_staleness_s: float = 1.0      # matches perception_config.yaml's health.stale_after_s default

    @classmethod
    def from_dict(cls, d: Optional[dict]) -> "RoadUnderstandingConfig":
        if not d:
            return cls()
        kwargs = {}
        for f in (
            "enabled", "minimum_confidence", "forward_distances_m", "longitudinal_bin_m",
            "min_points_per_sample", "max_lateral_search_m", "max_plausible_width_m",
            "max_sensor_staleness_s",
        ):
            if f in d and d[f] is not None:
                kwargs[f] = tuple(d[f]) if f == "forward_distances_m" else d[f]
        return cls(**kwargs)


# ---------------------------------------------------------------------------
# Pipeline
# ---------------------------------------------------------------------------

class RoadUnderstandingPipeline:
    """
    API (Step 20 of the spec):

        road = pipeline.process(perception=perception_frame, fused_state=fused_world_state)

    All arguments are optional and independently combinable — pass whichever
    of these you have on a given cycle:

        perception     : core.perception.perception_types.PerceptionFrame
                         (Phase 2 single-cycle output; supplies road_state/
                         drivable_area if road_state/drivable_area aren't
                         passed explicitly)
        fused_state    : core.fusion.fusion_types.FusedWorldState
                         (Phase 3 output; same role as `perception`, used
                         when only the fused state is available)
        road_state     : perception_types.RoadState, overrides the above
        drivable_area  : perception_types.DrivableArea, overrides the above
        lidar_result   : LiDARPerceptionResult already computed this cycle
                         (preferred — reuses Phase 2's ground/obstacle
                         separation instead of re-running it)
        lidar_points   : raw Nx3(+) point cloud, vehicle frame meters, used
                         ONLY if `lidar_result` isn't supplied (the pipeline
                         then runs its own internal LiDARPerceptionPipeline
                         to get ground/obstacle separation)
        frame_id       : int, defaults to 0
        timestamp      : float epoch seconds, defaults to time.time()
        lidar_timestamp / camera_timestamp : optional, for staleness checks
    """

    def __init__(self, config: Optional[RoadUnderstandingConfig] = None):
        self.config = config or RoadUnderstandingConfig()
        self._lidar_pipeline = LiDARPerceptionPipeline()
        self._log = get_logger("perception", component="road_understanding") if get_logger else None

    # -- sensor-input resolution ------------------------------------------

    def _resolve_camera(
        self,
        road_state: Optional[RoadState],
        perception: Any,
        fused_state: Any,
        timestamp: float,
        camera_timestamp: Optional[float],
    ) -> tuple[Optional[RoadState], str]:
        rs = road_state
        if rs is None and perception is not None:
            rs = getattr(perception, "road_state", None)
        if rs is None and fused_state is not None:
            rs = getattr(fused_state, "road_state", None)

        if rs is None:
            return None, "UNAVAILABLE"
        if rs.backend in (BackendKind.NOT_CONFIGURED, BackendKind.NOT_AVAILABLE):
            return None, "NOT_CONFIGURED"
        if camera_timestamp is not None and (timestamp - camera_timestamp) > self.config.max_sensor_staleness_s:
            return None, "STALE"
        if not rs.road_present:
            return rs, "NO_ROAD_DETECTED"
        return rs, "OK"

    def _resolve_lidar(
        self,
        lidar_result: Optional[LiDARPerceptionResult],
        lidar_points: Optional[np.ndarray],
        timestamp: float,
        lidar_timestamp: Optional[float],
    ) -> tuple[Optional[np.ndarray], Optional[np.ndarray], str]:
        result = lidar_result
        if result is None and lidar_points is not None:
            result = self._lidar_pipeline.process(lidar_points, timestamp=lidar_timestamp or timestamp)

        if result is None:
            return None, None, "UNAVAILABLE"
        if result.status != "OK":
            return None, None, result.status  # INVALID_FRAME | EMPTY_POINT_CLOUD
        if lidar_timestamp is not None and (timestamp - lidar_timestamp) > self.config.max_sensor_staleness_s:
            return None, None, "STALE"
        if result.ground_points is None and result.obstacle_points is None:
            return None, None, "NO_POINTS"
        return result.ground_points, result.obstacle_points, "OK"

    # -- geometry -----------------------------------------------------------

    @staticmethod
    def _finite_rows(points: Optional[np.ndarray]) -> np.ndarray:
        if points is None or points.shape[0] == 0:
            return np.zeros((0, 3))
        finite = np.isfinite(points[:, :3]).all(axis=1)
        return points[finite][:, :3]

    def _side_estimate(
        self, ground_bin: np.ndarray, obstacle_bin: np.ndarray, positive_side: bool,
    ) -> Optional[tuple[float, int]]:
        """Estimate the boundary y for one side (positive_side=True -> left,
        y>0) at one longitudinal bin. Returns (y, support_point_count) or
        None if there isn't enough evidence to report a value at all."""
        max_lat = self.config.max_lateral_search_m

        def _select(points: np.ndarray) -> np.ndarray:
            if points.shape[0] == 0:
                return points
            y = points[:, 1]
            mask = (y > 0) & (y <= max_lat) if positive_side else (y < 0) & (y >= -max_lat)
            return points[mask]

        obs_side = _select(obstacle_bin)
        gnd_side = _select(ground_bin)

        candidates = []
        support = 0
        if obs_side.shape[0] > 0:
            # nearest obstacle to the vehicle on this side = tightest (most
            # conservative) drivable-space boundary evidence.
            y_obs = float(obs_side[:, 1].min()) if positive_side else float(obs_side[:, 1].max())
            candidates.append(y_obs)
            support += obs_side.shape[0]
        if gnd_side.shape[0] > 0:
            # far edge of observed drivable-looking ground on this side.
            y_gnd = float(gnd_side[:, 1].max()) if positive_side else float(gnd_side[:, 1].min())
            candidates.append(y_gnd)
            support += gnd_side.shape[0]

        if not candidates:
            return None
        if support < self.config.min_points_per_sample:
            return None

        y = min(candidates) if positive_side else max(candidates)
        if not np.isfinite(y):
            return None
        return y, support

    def _confidence_from_support(self, support: int) -> float:
        # Same style of transparent, documented point-density heuristic
        # already used in lidar_perception.py's cluster confidence — more
        # supporting points -> higher confidence this boundary sample is
        # real, not noise. Never a fabricated/fixed constant.
        return float(min(1.0, 0.15 + 0.03 * support))

    def _build_boundaries(
        self, ground_points: np.ndarray, obstacle_points: np.ndarray,
    ) -> tuple[RoadBoundary, RoadBoundary, list[RoadWidthSample], list[str]]:
        left = RoadBoundary(side="left", source="lidar")
        right = RoadBoundary(side="right", source="lidar")
        width_profile: list[RoadWidthSample] = []
        warnings: list[str] = []

        half_bin = self.config.longitudinal_bin_m / 2.0

        for d in self.config.forward_distances_m:
            g_bin = ground_points[np.abs(ground_points[:, 0] - d) <= half_bin] if ground_points.shape[0] else ground_points
            o_bin = obstacle_points[np.abs(obstacle_points[:, 0] - d) <= half_bin] if obstacle_points.shape[0] else obstacle_points

            left_est = self._side_estimate(g_bin, o_bin, positive_side=True)
            right_est = self._side_estimate(g_bin, o_bin, positive_side=False)

            if left_est is not None:
                y, support = left_est
                left.points.append(BoundaryPoint(x=d, y=y, confidence=self._confidence_from_support(support),
                                                   point_support=support))
            if right_est is not None:
                y, support = right_est
                right.points.append(BoundaryPoint(x=d, y=y, confidence=self._confidence_from_support(support),
                                                    point_support=support))

            if left_est is not None and right_est is not None:
                width = left_est[0] - right_est[0]
                if not np.isfinite(width) or width <= 0 or width > self.config.max_plausible_width_m:
                    warnings.append(f"INVALID geometry at x={d}m: implausible width={width:.2f}m — sample rejected")
                    width_profile.append(RoadWidthSample(distance_m=d, width_m=None,
                                                           availability=BoundaryAvailability.BOTH))
                else:
                    width_profile.append(RoadWidthSample(distance_m=d, width_m=width,
                                                           availability=BoundaryAvailability.BOTH))
            elif left_est is not None:
                width_profile.append(RoadWidthSample(distance_m=d, width_m=None,
                                                       availability=BoundaryAvailability.LEFT_ONLY))
            elif right_est is not None:
                width_profile.append(RoadWidthSample(distance_m=d, width_m=None,
                                                       availability=BoundaryAvailability.RIGHT_ONLY))
            else:
                width_profile.append(RoadWidthSample(distance_m=d, width_m=None,
                                                       availability=BoundaryAvailability.NONE))

        left.available = len(left.points) > 0
        right.available = len(right.points) > 0
        left.confidence = float(np.mean([p.confidence for p in left.points])) if left.points else 0.0
        right.confidence = float(np.mean([p.confidence for p in right.points])) if right.points else 0.0
        return left, right, width_profile, warnings

    @staticmethod
    def _build_polygon(left: RoadBoundary, right: RoadBoundary) -> Optional[list]:
        if len(left.points) < 1 or len(right.points) < 1:
            return None
        left_sorted = sorted(left.points, key=lambda p: p.x)
        right_sorted = sorted(right.points, key=lambda p: p.x)
        poly = [(p.x, p.y) for p in left_sorted] + [(p.x, p.y) for p in reversed(right_sorted)]
        return poly

    # -- main entry point ----------------------------------------------------

    def process(
        self,
        perception: Any = None,
        fused_state: Any = None,
        road_state: Optional[RoadState] = None,
        drivable_area: Optional[DrivableArea] = None,
        lidar_result: Optional[LiDARPerceptionResult] = None,
        lidar_points: Optional[np.ndarray] = None,
        frame_id: Optional[int] = None,
        timestamp: Optional[float] = None,
        lidar_timestamp: Optional[float] = None,
        camera_timestamp: Optional[float] = None,
    ) -> RoadUnderstanding:
        ts = timestamp if timestamp is not None else time.time()
        fid = frame_id if frame_id is not None else getattr(perception, "frame_id", None) \
            or getattr(fused_state, "frame_id", None) or 0

        if not self.config.enabled:
            return RoadUnderstanding(
                timestamp=ts, frame_id=fid, status=RoadUnderstandingStatus.UNAVAILABLE,
                sensor_status={"camera": "DISABLED", "lidar": "DISABLED"},
                warnings=["road_understanding disabled via config (road_understanding.enabled=false)"],
            )

        cam_state, cam_status = self._resolve_camera(road_state, perception, fused_state, ts, camera_timestamp)
        ground_pts, obstacle_pts, lidar_status = self._resolve_lidar(lidar_result, lidar_points, ts, lidar_timestamp)

        camera_available = cam_status == "OK"
        lidar_available = lidar_status == "OK"
        sensor_status = {"camera": cam_status, "lidar": lidar_status}

        if not camera_available and not lidar_available:
            return RoadUnderstanding(
                timestamp=ts, frame_id=fid, status=RoadUnderstandingStatus.UNAVAILABLE,
                sensor_status=sensor_status,
                warnings=["no usable sensor input this cycle — road understanding unavailable"],
            )

        warnings: list[str] = []

        if lidar_available:
            ground = self._finite_rows(ground_pts)
            obstacles = self._finite_rows(obstacle_pts)
            left, right, width_profile, geom_warnings = self._build_boundaries(ground, obstacles)
            warnings.extend(geom_warnings)

            valid_widths = [s for s in width_profile if s.width_m is not None]
            both_count = sum(1 for s in width_profile if s.availability == BoundaryAvailability.BOTH)

            if left.available and right.available:
                availability = BoundaryAvailability.BOTH
            elif left.available:
                availability = BoundaryAvailability.LEFT_ONLY
            elif right.available:
                availability = BoundaryAvailability.RIGHT_ONLY
            else:
                availability = BoundaryAvailability.NONE

            lidar_confidence = float(np.mean([b.confidence for b in (left, right) if b.available])) \
                if (left.available or right.available) else 0.0

            if availability == BoundaryAvailability.NONE:
                status = RoadUnderstandingStatus.DEGRADED
                warnings.append("LiDAR available but below min_points_per_sample at every sampled distance")
            elif both_count == 0:
                status = RoadUnderstandingStatus.PARTIAL
            elif both_count < len(self.config.forward_distances_m):
                status = RoadUnderstandingStatus.PARTIAL
            else:
                status = RoadUnderstandingStatus.OK

            confidence = lidar_confidence
            source = "lidar"
            if camera_available:
                # Camera corroboration only nudges confidence — it never
                # supplies geometry of its own (see module docstring).
                confidence = float(min(1.0, confidence + 0.10 * cam_state.road_confidence)) if confidence > 0 else confidence
                source = "fusion"

            drivable_polygon = self._build_polygon(left, right) if availability == BoundaryAvailability.BOTH else None
            drivable_area_available = availability != BoundaryAvailability.NONE

            if confidence < self.config.minimum_confidence and status == RoadUnderstandingStatus.OK:
                status = RoadUnderstandingStatus.PARTIAL
                warnings.append(f"confidence {confidence:.2f} below minimum_confidence "
                                 f"{self.config.minimum_confidence:.2f} — downgraded to PARTIAL")

            return RoadUnderstanding(
                timestamp=ts, frame_id=fid, status=status,
                left_boundary=left, right_boundary=right,
                boundary_availability=availability,
                drivable_area_available=drivable_area_available,
                drivable_polygon=drivable_polygon,
                road_width_profile=width_profile,
                confidence=confidence, source=source,
                uncertainty=float(max(0.0, min(1.0, 1.0 - confidence))),
                sensor_status=sensor_status, warnings=warnings,
            )

        # camera-only: qualitative signal, no calibrated pixel->meter
        # geometry in this repository (see module docstring) — never
        # fabricate metric boundaries from an uncalibrated camera.
        confidence = float(cam_state.road_confidence) if cam_state else 0.0
        status = RoadUnderstandingStatus.PARTIAL if confidence > 0 else RoadUnderstandingStatus.DEGRADED
        warnings.append("camera-only cycle: no calibrated camera geometry available — "
                         "reporting qualitative road presence/confidence only, no metric boundaries")

        return RoadUnderstanding(
            timestamp=ts, frame_id=fid, status=status,
            boundary_availability=BoundaryAvailability.NONE,
            drivable_area_available=bool(cam_state and cam_state.road_present),
            drivable_polygon=None,
            road_width_profile=[],
            confidence=confidence, source="camera" if confidence > 0 else NOT_AVAILABLE,
            uncertainty=float(max(0.0, min(1.0, 1.0 - confidence))) if confidence > 0 else 1.0,
            sensor_status=sensor_status, warnings=warnings,
        )
