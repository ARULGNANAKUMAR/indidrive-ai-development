"""
IndiDrive AI — Phase 6.3 | Road Anomaly / Road Damage Understanding
================================================================================
Lightweight, deterministic road-anomaly understanding layer for Indian roads.

This module takes structured sensor observations (camera / LiDAR / fused) and
produces a fully-typed ``RoadAnomalyState`` — including geometry, severity,
temporal consistency, drivable-area/lane/corridor relationships, confidence
and uncertainty — without fabricating values when evidence is absent.

Pipeline per frame
------------------
  Input observations
       ↓
  1. Validate observations              — reject NaN/Inf/impossible geometry
       ↓
  2. Normalize coordinate representation — ensure vehicle-frame convention
       ↓
  3. Classify anomaly type               — AnomalyType enum
       ↓
  4. Estimate geometry                   — centre, extent, depth, orientation
       ↓
  5. Estimate severity                   — deterministic rule-based
       ↓
  6. Associate / deduplicate             — merge same-location multi-sensor hits
       ↓
  7. Apply temporal consistency          — update observation counts / state
       ↓
  8. Evaluate drivable-area overlap      — consume Phase 6.1 read-only
       ↓
  9. Evaluate lane relationship          — consume Phase 6.2 read-only
       ↓
 10. Evaluate corridor relationship      — lightweight geometric check
       ↓
 11. Calculate confidence + uncertainty
       ↓
 12. Generate RoadAnomalyState

Scope limits (DO NOT add beyond Phase 6.3)
------------------------------------------
  ✗  no path planning, MPC, steering, braking
  ✗  no Phase 3 / 5 / 6.1 / 6.2 mutation
  ✗  no cloud APIs, LLMs, FAISS, vector databases
  ✗  no deep learning training in this module

API
---
    engine = RoadAnomalyEngine(config)
    state: RoadAnomalyState = engine.process(
        observations=observations,          # list[RoadSurfaceObservation]
        road_understanding=road_und,        # Phase 6.1 output (optional)
        lane_structure=lane_struct,         # Phase 6.2 output (optional)
        frame_id=frame_id,
        timestamp=timestamp,
    )

Coordinate frame: +X forward, +Y left, +Z up, origin rear-axle centre (m).
"""
from __future__ import annotations

import math
import time
import uuid
from dataclasses import dataclass, field
from typing import Any, Optional

from .perception_types import NOT_AVAILABLE
from .road_anomaly_types import (
    AnomalyType, AnomalySeverity, AnomalyStatus,
    AnomalyGeometryKind, DepthKind, VisibilityState,
    DrivableAreaRelation, LaneRelation, CorridorRelation,
    TemporalState, RoadSurfaceQuality, AnomalyEngineStatus,
    AnomalyPoint2D, AnomalyPolygon, AnomalyGeometry,
    RoadAnomalyObservation, RoadAnomalyState,
)

try:
    from core.logging_system import get_logger
except ImportError:
    get_logger = None


# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

@dataclass
class RoadAnomalyConfig:
    """All thresholds are configurable; no magic numbers scattered in code."""
    enabled: bool = True

    # Minimum confidence below which an observation is not reported
    minimum_anomaly_confidence: float = 0.20

    # Geometry validity limits
    min_dimension_m: float = 0.01      # below this → INVALID geometry
    max_dimension_m: float = 50.0      # beyond this → INVALID geometry
    max_depth_m: float = 2.0           # deeper than this → INVALID
    max_distance_m: float = 120.0      # anomaly beyond this range → ignored

    # Minimum pothole / crack dimensions to not be discarded as noise
    min_pothole_length_m: float = 0.10
    min_pothole_width_m: float = 0.10
    min_crack_length_m: float = 0.05

    # Severity thresholds (area-based for REGION/POLYGON, length-based for LINE)
    severity_low_area_m2: float = 0.10       # < this → LOW
    severity_medium_area_m2: float = 0.50    # < this → MEDIUM
    severity_high_area_m2: float = 2.0       # < this → HIGH; ≥ this → CRITICAL
    severity_depth_medium_m: float = 0.05    # depth ≥ this → at least MEDIUM
    severity_depth_high_m: float = 0.15      # depth ≥ this → at least HIGH
    severity_depth_critical_m: float = 0.30  # depth ≥ this → CRITICAL

    # Temporal consistency
    persistence_threshold_count: int = 3     # obs_count ≥ this → PERSISTENT
    stale_timeout_s: float = 3.0             # no update for this long → STALE
    max_anomaly_age_s: float = 10.0          # beyond this → EXPIRED

    # Duplicate / association
    association_distance_m: float = 1.5      # same-location merge radius

    # Drivable-area / lane / corridor
    corridor_lateral_half_width_m: float = 1.5   # half-width of vehicle corridor
    corridor_longitudinal_reach_m: float = 40.0  # lookahead for path concern
    road_edge_proximity_m: float = 0.5           # within this of boundary → near edge
    lane_boundary_proximity_m: float = 0.5       # within this of boundary → near-lane

    # Road surface quality thresholds
    quality_damaged_min_anomalies: int = 2        # ≥ this medium/high → DAMAGED
    quality_severely_damaged_min_high: int = 1    # ≥ this HIGH/CRITICAL → SEVERELY_DAMAGED

    @classmethod
    def from_dict(cls, d: Optional[dict]) -> "RoadAnomalyConfig":
        if not d:
            return cls()
        cfg = cls()
        for f_name in (
            "enabled", "minimum_anomaly_confidence",
            "min_dimension_m", "max_dimension_m", "max_depth_m", "max_distance_m",
            "min_pothole_length_m", "min_pothole_width_m", "min_crack_length_m",
            "severity_low_area_m2", "severity_medium_area_m2",
            "severity_high_area_m2", "severity_depth_medium_m",
            "severity_depth_high_m", "severity_depth_critical_m",
            "persistence_threshold_count", "stale_timeout_s", "max_anomaly_age_s",
            "association_distance_m", "corridor_lateral_half_width_m",
            "corridor_longitudinal_reach_m", "road_edge_proximity_m",
            "lane_boundary_proximity_m", "quality_damaged_min_anomalies",
            "quality_severely_damaged_min_high",
        ):
            if f_name in d:
                setattr(cfg, f_name, d[f_name])
        return cfg


# ---------------------------------------------------------------------------
# Input observation contract
# ---------------------------------------------------------------------------

@dataclass
class RoadSurfaceObservation:
    """
    Normalised input to the Phase 6.3 engine.

    Callers (Phase 2 anomaly detection, Phase 3 fusion adapters) fill this
    structure.  The engine never reads raw sensor frames directly.

    Only fields with actual sensor evidence should be set; leave everything
    else at its default rather than fabricating values.
    """
    # Anomaly classification from detector
    anomaly_type: AnomalyType = AnomalyType.UNKNOWN

    # Vehicle-frame position (+X fwd, +Y left), metres
    center_x: Optional[float] = None
    center_y: Optional[float] = None
    center_z: Optional[float] = None    # None unless LiDAR surface height available

    # Extent (metres; None = unknown)
    length_m: Optional[float] = None
    width_m: Optional[float] = None
    depth_m: Optional[float] = None     # None unless depth sensor available
    depth_kind: DepthKind = DepthKind.UNKNOWN
    orientation_rad: Optional[float] = None

    # Polygon contour — optional richer geometry from camera segmentation
    contour_points: Optional[list] = None    # list[(x, y)] vehicle-frame tuples

    # Observation metadata
    confidence: float = 0.0
    source: str = NOT_AVAILABLE          # "camera" | "lidar" | "radar" | "fused"
    timestamp: float = 0.0

    # Visibility
    visibility_state: VisibilityState = VisibilityState.UNKNOWN
    visibility_score: float = 1.0

    # Optional tracking ID from upstream (helps association)
    observation_id: Optional[str] = None


# ---------------------------------------------------------------------------
# Internal temporal record
# ---------------------------------------------------------------------------

@dataclass
class _TemporalRecord:
    """Internal bookkeeping for one tracked anomaly across frames."""
    anomaly_id: str
    anomaly_type: AnomalyType
    first_seen: float
    last_seen: float
    observation_count: int = 1
    # Running weighted average position for centre stability
    sum_cx: float = 0.0
    sum_cy: float = 0.0
    sum_w: float = 0.0    # sum of confidence weights


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _finite(v: Any) -> bool:
    """Return True iff v is a finite float."""
    try:
        return math.isfinite(float(v))
    except (TypeError, ValueError):
        return False


def _validate_position(cx: Any, cy: Any) -> bool:
    return _finite(cx) and _finite(cy)


def _validate_dimension(d: Any, lo: float, hi: float) -> bool:
    """Return True iff d is a finite positive float in [lo, hi]."""
    if d is None:
        return True  # None means unknown, not invalid
    return _finite(d) and lo <= float(d) <= hi


def _euclidean_distance(cx: float, cy: float, cz: Optional[float] = None) -> float:
    if cz is not None and _finite(cz):
        return math.sqrt(cx * cx + cy * cy + cz * cz)
    return math.sqrt(cx * cx + cy * cy)


def _classify_type_from_string(type_str: str) -> AnomalyType:
    """Map legacy string type names (Phase 2 RoadAnomaly) to AnomalyType enum."""
    mapping = {
        "pothole": AnomalyType.POTHOLE,
        "crack": AnomalyType.CRACK,
        "debris": AnomalyType.DEBRIS,
        "mud": AnomalyType.MUD,
        "gravel": AnomalyType.GRAVEL,
        "road_edge_damage": AnomalyType.ROAD_EDGE_DAMAGE,
        "water_patch": AnomalyType.WATER_DAMAGE,
        "damaged_surface": AnomalyType.DAMAGED_SURFACE,
        "loose_material": AnomalyType.LOOSE_MATERIAL,
        "rock": AnomalyType.ROCK,
        "construction_material": AnomalyType.CONSTRUCTION_MATERIAL,
        "uneven_surface": AnomalyType.UNEVEN_SURFACE,
        "water_damage": AnomalyType.WATER_DAMAGE,
    }
    return mapping.get(type_str.lower().strip(), AnomalyType.UNKNOWN)


def _new_anomaly_id() -> str:
    return "anomaly_" + uuid.uuid4().hex[:8]


# ---------------------------------------------------------------------------
# Main engine
# ---------------------------------------------------------------------------

class RoadAnomalyEngine:
    """
    Phase 6.3 Road Anomaly Understanding Engine.

    Thread-safety: not guaranteed.  Call from a single processing thread.
    State is maintained across calls for temporal consistency.
    """

    def __init__(self, config: Optional[RoadAnomalyConfig] = None):
        self.config = config or RoadAnomalyConfig()
        self._logger = None
        if get_logger:
            try:
                self._logger = get_logger("road_anomaly")
            except Exception:
                pass

        # Temporal tracking: anomaly_id → _TemporalRecord
        self._temporal: dict[str, _TemporalRecord] = {}

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def process(
        self,
        observations: Optional[list] = None,          # list[RoadSurfaceObservation]
        road_understanding: Optional[Any] = None,      # Phase 6.1 RoadUnderstanding
        lane_structure: Optional[Any] = None,          # Phase 6.2 LaneStructure
        frame_id: int = 0,
        timestamp: Optional[float] = None,
    ) -> RoadAnomalyState:
        """Run the full Phase 6.3 pipeline for one frame.

        Parameters
        ----------
        observations        : list of RoadSurfaceObservation (may be None/empty)
        road_understanding  : Phase 6.1 RoadUnderstanding (read-only; may be None)
        lane_structure      : Phase 6.2 LaneStructure (read-only; may be None)
        frame_id            : monotonic frame counter
        timestamp           : float seconds (uses time.time() if not provided)
        """
        ts = timestamp if (timestamp is not None and _finite(timestamp)) else time.time()
        observations = observations or []

        if not self.config.enabled:
            return RoadAnomalyState(
                timestamp=ts, frame_id=frame_id,
                status=AnomalyEngineStatus.UNAVAILABLE,
                warnings=["RoadAnomalyEngine disabled in configuration"],
            )

        # Determine sensor availability
        sensor_status = self._build_sensor_status(observations, road_understanding)
        degraded = any(v != "OK" for v in sensor_status.values())

        # --- Step 1: Validate + normalise ----------------------------------
        valid_obs, validation_warnings = self._validate_observations(observations, ts)

        # --- Step 2-4: Classify, build geometry, compute derived fields ----
        candidates: list[RoadAnomalyObservation] = []
        for obs in valid_obs:
            obs_out = self._build_anomaly_observation(obs, ts)
            if obs_out is not None:
                candidates.append(obs_out)

        # --- Step 5: Deduplicate / associate --------------------------------
        candidates = self._associate(candidates)

        # --- Step 6: Temporal consistency ----------------------------------
        candidates = self._update_temporal(candidates, ts)

        # --- Step 7: Drivable-area relationship (Phase 6.1, read-only) -----
        candidates = self._evaluate_drivable_area(candidates, road_understanding)

        # --- Step 8: Lane relationship (Phase 6.2, read-only) --------------
        candidates = self._evaluate_lane_relation(candidates, lane_structure)

        # --- Step 9: Corridor relationship ---------------------------------
        candidates = self._evaluate_corridor(candidates, road_understanding)

        # --- Step 10: Road-edge proximity (Phase 6.1, read-only) -----------
        candidates = self._evaluate_road_edge(candidates, road_understanding)

        # --- Step 11: Filter by minimum confidence -------------------------
        reported = [
            a for a in candidates
            if a.confidence >= self.config.minimum_anomaly_confidence
               or a.temporal_state in (TemporalState.PERSISTENT, TemporalState.OBSERVED)
        ]

        # --- Step 12: Sort deterministically (closest first, then by type) -
        reported = self._sort_anomalies(reported)

        # --- Step 13: Aggregate state --------------------------------------
        overall_conf, overall_unc = self._aggregate_confidence(reported)
        surface_quality = self._derive_surface_quality(reported)
        engine_status = self._derive_engine_status(reported, observations, degraded)
        source_summary = self._build_source_summary(reported)

        stats = {
            "total_anomalies": len(reported),
            "persistent_anomalies": sum(1 for a in reported if a.temporal_state == TemporalState.PERSISTENT),
            "affecting_drivable_area": sum(1 for a in reported if a.affects_drivable_area),
            "affecting_lane_area": sum(1 for a in reported if a.affects_lane_area),
            "affecting_vehicle_path": sum(1 for a in reported if a.affects_vehicle_path),
            "degraded_mode": degraded,
        }

        all_warnings = validation_warnings[:]
        if degraded:
            missing = [k for k, v in sensor_status.items() if v != "OK"]
            all_warnings.append(f"degraded mode — sensors unavailable: {missing}")

        return RoadAnomalyState(
            timestamp=ts,
            frame_id=frame_id,
            status=engine_status,
            anomalies=reported,
            road_surface_quality=surface_quality,
            overall_confidence=overall_conf,
            overall_uncertainty=overall_unc,
            sensor_status=sensor_status,
            degraded=degraded,
            source_summary=source_summary,
            stats=stats,
            warnings=all_warnings,
        )

    def reset(self) -> None:
        """Clear all temporal state (e.g. between scenes)."""
        self._temporal.clear()

    def get_tracked_anomaly_count(self) -> int:
        return len(self._temporal)

    # ------------------------------------------------------------------
    # Pipeline steps (private)
    # ------------------------------------------------------------------

    # Step 1: Validate
    def _validate_observations(
        self, observations: list, ts: float
    ) -> tuple[list, list]:
        """Return (valid_observations, warnings).  Invalid entries are dropped."""
        valid: list[RoadSurfaceObservation] = []
        warnings: list[str] = []
        cfg = self.config

        for i, obs in enumerate(observations):
            if obs is None:
                warnings.append(f"observation[{i}]: None — skipped")
                continue

            if not isinstance(obs, RoadSurfaceObservation):
                warnings.append(f"observation[{i}]: unexpected type {type(obs).__name__} — skipped")
                continue

            cx, cy = obs.center_x, obs.center_y

            # Position validation
            if cx is None or cy is None:
                warnings.append(f"observation[{i}]: missing center_x/center_y — skipped")
                continue
            if not _validate_position(cx, cy):
                warnings.append(f"observation[{i}]: non-finite position ({cx}, {cy}) — skipped")
                continue

            dist = _euclidean_distance(cx, cy, obs.center_z)
            if dist > cfg.max_distance_m:
                warnings.append(
                    f"observation[{i}]: distance {dist:.1f}m exceeds max {cfg.max_distance_m}m — skipped"
                )
                continue

            # Dimension validation
            for dim_name, dim_val in [("length_m", obs.length_m), ("width_m", obs.width_m)]:
                if not _validate_dimension(dim_val, cfg.min_dimension_m, cfg.max_dimension_m):
                    warnings.append(
                        f"observation[{i}]: invalid {dim_name}={dim_val} — cleared"
                    )
                    setattr(obs, dim_name, None)

            if obs.depth_m is not None and not _validate_dimension(
                obs.depth_m, 0.0, cfg.max_depth_m
            ):
                warnings.append(f"observation[{i}]: invalid depth_m={obs.depth_m} — cleared")
                obs.depth_m = None
                obs.depth_kind = DepthKind.UNKNOWN

            # Confidence validation
            if not _finite(obs.confidence) or obs.confidence < 0.0:
                warnings.append(f"observation[{i}]: invalid confidence — set to 0")
                obs.confidence = 0.0
            obs.confidence = min(1.0, obs.confidence)

            # Clamp visibility score
            if not _finite(obs.visibility_score):
                obs.visibility_score = 1.0
            obs.visibility_score = max(0.0, min(1.0, obs.visibility_score))

            valid.append(obs)

        return valid, warnings

    # Step 2-4: Build one RoadAnomalyObservation from a validated observation
    def _build_anomaly_observation(
        self, obs: RoadSurfaceObservation, ts: float
    ) -> Optional[RoadAnomalyObservation]:
        """Return a structured RoadAnomalyObservation or None if skipped."""
        cfg = self.config
        anomaly_type = obs.anomaly_type

        # Geometry
        geom = self._estimate_geometry(obs, anomaly_type)

        # Position convenience
        cx = obs.center_x
        cy = obs.center_y
        cz = obs.center_z
        dist = _euclidean_distance(cx, cy, cz)

        # Severity
        severity = self._estimate_severity(anomaly_type, geom, obs.confidence)

        # Confidence
        conf = self._compute_confidence(obs, geom, severity)

        # Uncertainty flags
        pos_unc = obs.visibility_state in (VisibilityState.OBSCURED, VisibilityState.PARTIAL)
        geom_unc = not geom.has_extent
        class_unc = anomaly_type == AnomalyType.UNKNOWN
        sev_unc = severity == AnomalySeverity.UNKNOWN

        # Aggregate uncertainty
        unc = self._compute_uncertainty(obs, geom, pos_unc, geom_unc, class_unc)

        a_id = obs.observation_id or _new_anomaly_id()

        return RoadAnomalyObservation(
            anomaly_id=a_id,
            anomaly_type=anomaly_type,
            timestamp=ts,
            status=AnomalyStatus.VALID,
            geometry=geom,
            distance_m=dist,
            longitudinal_m=cx,
            lateral_m=cy,
            severity=severity,
            confidence=conf,
            uncertainty=unc,
            position_uncertain=pos_unc,
            geometry_uncertain=geom_unc,
            classification_uncertain=class_unc,
            severity_uncertain=sev_unc,
            source=obs.source,
            observation_count=1,
            first_seen_timestamp=ts,
            last_seen_timestamp=ts,
            persistence_s=0.0,
            temporal_state=TemporalState.NEW,
            temporal_consistency=0.0,
            visibility_state=obs.visibility_state,
            visibility_score=obs.visibility_score,
        )

    def _estimate_geometry(
        self, obs: RoadSurfaceObservation, anomaly_type: AnomalyType
    ) -> AnomalyGeometry:
        cfg = self.config
        cx, cy, cz = obs.center_x, obs.center_y, obs.center_z

        # Determine geometry kind
        if obs.contour_points and len(obs.contour_points) >= 3:
            kind = AnomalyGeometryKind.POLYGON
            pts = [AnomalyPoint2D(x=float(p[0]), y=float(p[1]))
                   for p in obs.contour_points if _finite(p[0]) and _finite(p[1])]
            contour = AnomalyPolygon(points=pts) if len(pts) >= 3 else None
        elif anomaly_type == AnomalyType.CRACK and obs.length_m is not None and obs.width_m is None:
            kind = AnomalyGeometryKind.LINE
            contour = None
        elif obs.length_m is not None or obs.width_m is not None:
            kind = AnomalyGeometryKind.REGION
            contour = None
        else:
            kind = AnomalyGeometryKind.POINT
            contour = None

        length = obs.length_m
        width = obs.width_m

        # Area estimate
        area = None
        if length is not None and width is not None:
            area = length * width
        elif kind == AnomalyGeometryKind.POLYGON and contour and contour.is_valid:
            # Shoelace area
            pts = contour.points
            n = len(pts)
            s = 0.0
            for i in range(n):
                j = (i + 1) % n
                s += pts[i].x * pts[j].y - pts[j].x * pts[i].y
            area = abs(s) * 0.5

        # Longitudinal / lateral reach
        long_reach = (length / 2.0) if length is not None else None
        lat_reach = (width / 2.0) if width is not None else None

        return AnomalyGeometry(
            kind=kind,
            center_x=float(cx),
            center_y=float(cy),
            center_z=float(cz) if (cz is not None and _finite(cz)) else None,
            length_m=length,
            width_m=width,
            depth_estimate_m=obs.depth_m,
            depth_kind=obs.depth_kind,
            orientation_rad=obs.orientation_rad,
            area_estimate_m2=area,
            contour=contour,
            longitudinal_reach_m=long_reach,
            lateral_reach_m=lat_reach,
        )

    def _estimate_severity(
        self, anomaly_type: AnomalyType, geom: AnomalyGeometry, confidence: float
    ) -> AnomalySeverity:
        """Deterministic severity rule system.  No random values."""
        cfg = self.config

        if confidence < 0.1:
            return AnomalySeverity.UNKNOWN

        # Depth-driven (highest specificity for potholes)
        depth = geom.depth_estimate_m
        if depth is not None and geom.depth_kind != DepthKind.UNKNOWN:
            if depth >= cfg.severity_depth_critical_m:
                return AnomalySeverity.CRITICAL
            if depth >= cfg.severity_depth_high_m:
                return AnomalySeverity.HIGH
            if depth >= cfg.severity_depth_medium_m:
                return AnomalySeverity.MEDIUM

        # Area-driven
        area = geom.area_estimate_m2
        if area is not None:
            if area >= cfg.severity_high_area_m2:
                return AnomalySeverity.HIGH if depth is None else AnomalySeverity.HIGH
            if area >= cfg.severity_medium_area_m2:
                return AnomalySeverity.MEDIUM
            if area >= cfg.severity_low_area_m2:
                return AnomalySeverity.LOW

        # Type-based fallback for point anomalies with no size
        point_defaults: dict[AnomalyType, AnomalySeverity] = {
            AnomalyType.ROCK:                 AnomalySeverity.HIGH,
            AnomalyType.POTHOLE:              AnomalySeverity.MEDIUM,
            AnomalyType.WATER_DAMAGE:         AnomalySeverity.MEDIUM,
            AnomalyType.ROAD_EDGE_DAMAGE:     AnomalySeverity.MEDIUM,
            AnomalyType.DAMAGED_SURFACE:      AnomalySeverity.MEDIUM,
            AnomalyType.UNEVEN_SURFACE:       AnomalySeverity.LOW,
            AnomalyType.CRACK:                AnomalySeverity.LOW,
            AnomalyType.DEBRIS:               AnomalySeverity.LOW,
            AnomalyType.CONSTRUCTION_MATERIAL: AnomalySeverity.LOW,
            AnomalyType.GRAVEL:               AnomalySeverity.LOW,
            AnomalyType.LOOSE_MATERIAL:       AnomalySeverity.LOW,
            AnomalyType.MUD:                  AnomalySeverity.LOW,
            AnomalyType.UNKNOWN:              AnomalySeverity.UNKNOWN,
        }
        return point_defaults.get(anomaly_type, AnomalySeverity.UNKNOWN)

    def _compute_confidence(
        self,
        obs: RoadSurfaceObservation,
        geom: AnomalyGeometry,
        severity: AnomalySeverity,
    ) -> float:
        """Deterministic confidence roll-up; all contributors in [0,1]."""
        conf = obs.confidence

        # Reduce for poor visibility
        if obs.visibility_state == VisibilityState.OBSCURED:
            conf *= 0.55
        elif obs.visibility_state == VisibilityState.PARTIAL:
            conf *= 0.75

        # Boost slightly for fused source (multi-sensor agreement)
        if obs.source == "fused":
            conf = min(1.0, conf * 1.10)

        # Slightly reduce for unknown type
        if obs.anomaly_type == AnomalyType.UNKNOWN:
            conf *= 0.80

        # Reduce if geometry is only a point (little structural evidence)
        if geom.kind == AnomalyGeometryKind.POINT:
            conf *= 0.85

        return max(0.0, min(1.0, conf))

    def _compute_uncertainty(
        self,
        obs: RoadSurfaceObservation,
        geom: AnomalyGeometry,
        pos_unc: bool,
        geom_unc: bool,
        class_unc: bool,
    ) -> float:
        """Uncertainty (not simply 1 - confidence).

        Accumulates independent uncertainty sources.
        """
        base = 1.0 - obs.confidence
        # Water coverage inflates position uncertainty significantly
        if obs.visibility_state == VisibilityState.OBSCURED:
            base = min(1.0, base + 0.30)
        if obs.visibility_state == VisibilityState.PARTIAL:
            base = min(1.0, base + 0.15)
        if geom_unc:
            base = min(1.0, base + 0.15)
        if class_unc:
            base = min(1.0, base + 0.10)
        if geom.depth_kind == DepthKind.UNKNOWN:
            base = min(1.0, base + 0.05)
        return max(0.0, min(1.0, base))

    # Step 5: Association / deduplication
    def _associate(
        self, candidates: list[RoadAnomalyObservation]
    ) -> list[RoadAnomalyObservation]:
        """Merge candidates whose centres are within association_distance_m.

        Simple greedy nearest-neighbour merge; deterministic because candidates
        are processed in input order.  Does NOT duplicate Phase 3 fusion.
        """
        if len(candidates) <= 1:
            return candidates

        threshold = self.config.association_distance_m
        merged_flags = [False] * len(candidates)
        result: list[RoadAnomalyObservation] = []

        for i, a in enumerate(candidates):
            if merged_flags[i]:
                continue
            cx_a = a.geometry.center_x or 0.0
            cy_a = a.geometry.center_y or 0.0
            cluster = [a]
            for j, b in enumerate(candidates[i + 1:], start=i + 1):
                if merged_flags[j]:
                    continue
                if a.anomaly_type != b.anomaly_type:
                    continue
                cx_b = b.geometry.center_x or 0.0
                cy_b = b.geometry.center_y or 0.0
                dist = math.sqrt((cx_a - cx_b) ** 2 + (cy_a - cy_b) ** 2)
                if dist <= threshold:
                    cluster.append(b)
                    merged_flags[j] = True

            if len(cluster) == 1:
                result.append(a)
            else:
                result.append(self._merge_cluster(cluster))

        return result

    def _merge_cluster(
        self, cluster: list[RoadAnomalyObservation]
    ) -> RoadAnomalyObservation:
        """Merge a list of same-type nearby observations into one, taking
        highest-confidence properties."""
        # Use the highest-confidence observation as the base
        best = max(cluster, key=lambda a: a.confidence)
        merged = RoadAnomalyObservation(
            anomaly_id=best.anomaly_id,
            anomaly_type=best.anomaly_type,
            timestamp=best.timestamp,
            status=AnomalyStatus.VALID,
            geometry=best.geometry,
            distance_m=best.distance_m,
            longitudinal_m=best.longitudinal_m,
            lateral_m=best.lateral_m,
            severity=best.severity,
            source="fused" if any(a.source != best.source for a in cluster) else best.source,
            visibility_state=best.visibility_state,
            visibility_score=best.visibility_score,
        )
        # Aggregate confidence: slightly boost for multi-source agreement
        merged.confidence = min(1.0, best.confidence * (1.0 + 0.05 * (len(cluster) - 1)))
        merged.uncertainty = best.uncertainty * (1.0 / len(cluster)) if len(cluster) > 1 else best.uncertainty
        merged.uncertainty = max(0.0, min(1.0, merged.uncertainty))
        return merged

    # Step 6: Temporal consistency
    def _update_temporal(
        self, candidates: list[RoadAnomalyObservation], ts: float
    ) -> list[RoadAnomalyObservation]:
        """Update temporal bookkeeping and expire stale records."""
        cfg = self.config

        # Age out expired records
        expired = [
            aid for aid, rec in self._temporal.items()
            if (ts - rec.last_seen) > cfg.max_anomaly_age_s
        ]
        for aid in expired:
            del self._temporal[aid]

        updated: list[RoadAnomalyObservation] = []
        for obs in candidates:
            best_match_id = self._find_temporal_match(obs, ts)

            if best_match_id is not None:
                rec = self._temporal[best_match_id]
                rec.last_seen = ts
                rec.observation_count += 1
                rec.sum_cx += (obs.geometry.center_x or 0.0) * obs.confidence
                rec.sum_cy += (obs.geometry.center_y or 0.0) * obs.confidence
                rec.sum_w += obs.confidence

                obs.anomaly_id = best_match_id
                obs.observation_count = rec.observation_count
                obs.first_seen_timestamp = rec.first_seen
                obs.last_seen_timestamp = ts
                obs.persistence_s = ts - rec.first_seen
            else:
                # New anomaly
                a_id = obs.anomaly_id or _new_anomaly_id()
                obs.anomaly_id = a_id
                rec = _TemporalRecord(
                    anomaly_id=a_id,
                    anomaly_type=obs.anomaly_type,
                    first_seen=ts,
                    last_seen=ts,
                    observation_count=1,
                    sum_cx=(obs.geometry.center_x or 0.0) * obs.confidence,
                    sum_cy=(obs.geometry.center_y or 0.0) * obs.confidence,
                    sum_w=obs.confidence,
                )
                self._temporal[a_id] = rec
                obs.first_seen_timestamp = ts
                obs.last_seen_timestamp = ts

            # Classify temporal state
            rec = self._temporal[obs.anomaly_id]
            if obs.observation_count >= cfg.persistence_threshold_count:
                obs.temporal_state = TemporalState.PERSISTENT
            elif obs.observation_count >= 2:
                obs.temporal_state = TemporalState.OBSERVED
            else:
                obs.temporal_state = TemporalState.NEW

            # Temporal consistency: ratio of observations to possible observations
            elapsed_frames = max(1.0, obs.persistence_s / max(0.05, 1.0))
            obs.temporal_consistency = min(
                1.0, obs.observation_count / (elapsed_frames + 1.0)
            )

            # Confidence boost for persistent anomalies
            if obs.temporal_state == TemporalState.PERSISTENT:
                obs.confidence = min(1.0, obs.confidence * 1.10)
            elif obs.temporal_state == TemporalState.OBSERVED:
                obs.confidence = min(1.0, obs.confidence * 1.05)

            updated.append(obs)

        return updated

    def _find_temporal_match(
        self, obs: RoadAnomalyObservation, ts: float
    ) -> Optional[str]:
        """Find the closest live temporal record matching this observation type."""
        cfg = self.config
        cx = obs.geometry.center_x or 0.0
        cy = obs.geometry.center_y or 0.0
        best_dist = cfg.association_distance_m
        best_id: Optional[str] = None

        for aid, rec in self._temporal.items():
            if rec.anomaly_type != obs.anomaly_type:
                continue
            if (ts - rec.last_seen) > cfg.stale_timeout_s:
                continue
            w = rec.sum_w
            if w <= 0.0:
                continue
            rec_cx = rec.sum_cx / w
            rec_cy = rec.sum_cy / w
            dist = math.sqrt((cx - rec_cx) ** 2 + (cy - rec_cy) ** 2)
            if dist < best_dist:
                best_dist = dist
                best_id = aid

        return best_id

    # Step 7: Drivable-area relationship
    def _evaluate_drivable_area(
        self, candidates: list[RoadAnomalyObservation], road_und: Optional[Any]
    ) -> list[RoadAnomalyObservation]:
        """Consume Phase 6.1 output (read-only) to classify each anomaly."""
        if road_und is None:
            for obs in candidates:
                obs.drivable_area_relation = DrivableAreaRelation.UNKNOWN
                obs.affects_drivable_area = False
            return candidates

        poly = getattr(road_und, "drivable_polygon", None)
        drivable_available = getattr(road_und, "drivable_area_available", False)

        for obs in candidates:
            if not drivable_available or poly is None or len(poly) < 3:
                obs.drivable_area_relation = DrivableAreaRelation.UNKNOWN
                obs.affects_drivable_area = False
                continue

            cx = obs.geometry.center_x
            cy = obs.geometry.center_y
            if cx is None or cy is None:
                obs.drivable_area_relation = DrivableAreaRelation.UNKNOWN
                continue

            inside = _point_in_polygon(cx, cy, poly)
            # Check boundary overlap using reach
            long_r = obs.geometry.longitudinal_reach_m or 0.0
            lat_r = obs.geometry.lateral_reach_m or 0.0

            if inside:
                obs.drivable_area_relation = DrivableAreaRelation.INSIDE_DRIVABLE_AREA
                obs.affects_drivable_area = True
            elif long_r > 0 or lat_r > 0:
                # Check if any corner of bounding box overlaps polygon
                corners = [
                    (cx + long_r, cy + lat_r),
                    (cx + long_r, cy - lat_r),
                    (cx - long_r, cy + lat_r),
                    (cx - long_r, cy - lat_r),
                ]
                if any(_point_in_polygon(px, py, poly) for px, py in corners):
                    obs.drivable_area_relation = DrivableAreaRelation.PARTIALLY_OVERLAPPING_DRIVABLE_AREA
                    obs.affects_drivable_area = True
                else:
                    obs.drivable_area_relation = DrivableAreaRelation.OUTSIDE_DRIVABLE_AREA
                    obs.affects_drivable_area = False
            else:
                obs.drivable_area_relation = DrivableAreaRelation.OUTSIDE_DRIVABLE_AREA
                obs.affects_drivable_area = False

        return candidates

    # Step 8: Lane relationship
    def _evaluate_lane_relation(
        self, candidates: list[RoadAnomalyObservation], lane_struct: Optional[Any]
    ) -> list[RoadAnomalyObservation]:
        """Consume Phase 6.2 output (read-only)."""
        if lane_struct is None:
            for obs in candidates:
                obs.lane_relation = LaneRelation.UNKNOWN
                obs.affects_lane_area = False
            return candidates

        lanes = getattr(lane_struct, "lanes", [])
        proximity = self.config.lane_boundary_proximity_m

        for obs in candidates:
            cx = obs.geometry.center_x
            cy = obs.geometry.center_y
            if cx is None or cy is None or not lanes:
                obs.lane_relation = LaneRelation.UNKNOWN
                obs.affects_lane_area = False
                continue

            relation, in_lane = self._classify_lane_relation(cx, cy, lanes, proximity)
            obs.lane_relation = relation
            obs.affects_lane_area = in_lane

        return candidates

    def _classify_lane_relation(
        self, cx: float, cy: float, lanes: list, proximity: float
    ) -> tuple[LaneRelation, bool]:
        """Return (LaneRelation, affects_lane_area) for point (cx, cy)."""
        for lane in lanes:
            lb = getattr(lane, "left_boundary", None)
            rb = getattr(lane, "right_boundary", None)

            left_y = self._boundary_y_at(lb, cx)
            right_y = self._boundary_y_at(rb, cx)

            if left_y is None or right_y is None:
                continue

            # left_y > right_y in our frame (+Y = left)
            min_y = min(left_y, right_y)
            max_y = max(left_y, right_y)

            if min_y <= cy <= max_y:
                # Check near boundary
                if abs(cy - left_y) <= proximity or abs(cy - right_y) <= proximity:
                    return LaneRelation.NEAR_LANE_BOUNDARY, True
                return LaneRelation.INSIDE_LANE, True

            # Near boundary but outside lane
            if abs(cy - left_y) <= proximity or abs(cy - right_y) <= proximity:
                return LaneRelation.NEAR_LANE_BOUNDARY, False

        # Not inside any lane
        if lanes:
            return LaneRelation.OUTSIDE_LANE_STRUCTURE, False
        return LaneRelation.UNKNOWN, False

    def _boundary_y_at(self, boundary: Optional[Any], cx: float) -> Optional[float]:
        """Interpolate lateral (Y) position of a lane boundary at forward distance cx."""
        if boundary is None or not getattr(boundary, "available", False):
            return None
        pts = getattr(boundary, "points", [])
        if not pts:
            return None
        # Find bracketing points
        sorted_pts = sorted(pts, key=lambda p: p.x)
        for i in range(len(sorted_pts) - 1):
            p0, p1 = sorted_pts[i], sorted_pts[i + 1]
            if p0.x <= cx <= p1.x:
                if abs(p1.x - p0.x) < 1e-6:
                    return p0.y
                t = (cx - p0.x) / (p1.x - p0.x)
                return p0.y + t * (p1.y - p0.y)
        # Extrapolate from nearest endpoint
        if cx < sorted_pts[0].x:
            return sorted_pts[0].y
        return sorted_pts[-1].y

    # Step 9: Corridor relationship
    def _evaluate_corridor(
        self, candidates: list[RoadAnomalyObservation], road_und: Optional[Any]
    ) -> list[RoadAnomalyObservation]:
        """Lightweight geometric check: is anomaly in the vehicle's travel corridor?

        The corridor is approximated as a rectangle: longitudinal lookahead × half-width.
        Uses Phase 6.1 road-width profile if available; falls back to config defaults.
        """
        cfg = self.config
        corridor_half_w = cfg.corridor_lateral_half_width_m
        corridor_len = cfg.corridor_longitudinal_reach_m

        # Try to refine corridor width from Phase 6.1 road-width profile
        if road_und is not None:
            profile = getattr(road_und, "road_width_profile", [])
            if profile:
                near_width = None
                for sample in profile:
                    w = getattr(sample, "width_m", None)
                    if w is not None and w > 0:
                        near_width = w
                        break
                if near_width is not None:
                    # Vehicle corridor ≈ half road width / 2 (one lane)
                    corridor_half_w = min(near_width / 4.0, corridor_half_w)

        for obs in candidates:
            cx = obs.geometry.center_x
            cy = obs.geometry.center_y
            if cx is None or cy is None:
                obs.corridor_relation = CorridorRelation.UNKNOWN
                obs.affects_vehicle_path = False
                continue

            long_r = obs.geometry.longitudinal_reach_m or 0.0
            lat_r = obs.geometry.lateral_reach_m or 0.0

            in_x = 0.0 <= (cx - long_r) <= corridor_len or 0.0 <= (cx + long_r) <= corridor_len
            in_y = abs(cy) - lat_r <= corridor_half_w

            if not in_x:
                obs.corridor_relation = CorridorRelation.CLEAR_OF_CURRENT_CORRIDOR
                obs.affects_vehicle_path = False
            elif in_x and in_y:
                obs.corridor_relation = CorridorRelation.OVERLAPPING_CURRENT_CORRIDOR
                obs.affects_vehicle_path = True
            elif in_x and abs(cy) - lat_r <= corridor_half_w * 2.5:
                obs.corridor_relation = CorridorRelation.NEAR_CURRENT_CORRIDOR
                obs.affects_vehicle_path = False
            else:
                obs.corridor_relation = CorridorRelation.CLEAR_OF_CURRENT_CORRIDOR
                obs.affects_vehicle_path = False

        return candidates

    # Step 10: Road edge proximity
    def _evaluate_road_edge(
        self, candidates: list[RoadAnomalyObservation], road_und: Optional[Any]
    ) -> list[RoadAnomalyObservation]:
        """Mark anomalies that are near Phase 6.1 road boundaries (read-only)."""
        if road_und is None:
            return candidates

        left_boundary = getattr(road_und, "left_boundary", None)
        right_boundary = getattr(road_und, "right_boundary", None)
        prox = self.config.road_edge_proximity_m

        for obs in candidates:
            cx = obs.geometry.center_x
            cy = obs.geometry.center_y
            if cx is None or cy is None:
                continue

            near_left = False
            near_right = False

            if left_boundary is not None and getattr(left_boundary, "available", False):
                ly = self._boundary_y_at(left_boundary, cx)
                if ly is not None and abs(cy - ly) <= prox:
                    near_left = True

            if right_boundary is not None and getattr(right_boundary, "available", False):
                ry = self._boundary_y_at(right_boundary, cx)
                if ry is not None and abs(cy - ry) <= prox:
                    near_right = True

            obs.near_road_edge = near_left or near_right
            if near_left and near_right:
                obs.road_edge_side = "both"
            elif near_left:
                obs.road_edge_side = "left"
            elif near_right:
                obs.road_edge_side = "right"

        return candidates

    # ------------------------------------------------------------------
    # Aggregation helpers
    # ------------------------------------------------------------------

    def _sort_anomalies(
        self, anomalies: list[RoadAnomalyObservation]
    ) -> list[RoadAnomalyObservation]:
        """Stable deterministic sort: distance ascending, then type value, then id."""
        def sort_key(a: RoadAnomalyObservation):
            dist = a.distance_m if a.distance_m is not None else 9999.0
            return (round(dist, 2), a.anomaly_type.value, a.anomaly_id)

        return sorted(anomalies, key=sort_key)

    def _aggregate_confidence(
        self, anomalies: list[RoadAnomalyObservation]
    ) -> tuple[float, float]:
        if not anomalies:
            return 0.0, 1.0
        total_conf = sum(a.confidence for a in anomalies) / len(anomalies)
        total_unc = sum(a.uncertainty for a in anomalies) / len(anomalies)
        return round(max(0.0, min(1.0, total_conf)), 3), round(max(0.0, min(1.0, total_unc)), 3)

    def _derive_surface_quality(
        self, anomalies: list[RoadAnomalyObservation]
    ) -> RoadSurfaceQuality:
        """Deterministic rule-based surface quality from observed anomaly set."""
        cfg = self.config
        if not anomalies:
            return RoadSurfaceQuality.UNKNOWN

        severity_counts = {s: 0 for s in AnomalySeverity}
        for a in anomalies:
            severity_counts[a.severity] += 1

        n_critical = severity_counts[AnomalySeverity.CRITICAL]
        n_high = severity_counts[AnomalySeverity.HIGH]
        n_medium = severity_counts[AnomalySeverity.MEDIUM]

        if n_critical >= 1 or n_high >= cfg.quality_severely_damaged_min_high:
            return RoadSurfaceQuality.SEVERELY_DAMAGED
        if (n_high + n_medium) >= cfg.quality_damaged_min_anomalies:
            return RoadSurfaceQuality.DAMAGED
        if n_medium >= 1 or (n_high + n_medium) >= 1:
            return RoadSurfaceQuality.MINOR_DAMAGE
        if severity_counts[AnomalySeverity.LOW] >= 1:
            return RoadSurfaceQuality.MINOR_DAMAGE
        if severity_counts[AnomalySeverity.NONE] > 0 and (n_high + n_medium + n_critical) == 0:
            return RoadSurfaceQuality.GOOD
        return RoadSurfaceQuality.UNKNOWN

    def _derive_engine_status(
        self,
        anomalies: list,
        observations: list,
        degraded: bool,
    ) -> AnomalyEngineStatus:
        if not observations and not anomalies:
            return AnomalyEngineStatus.UNAVAILABLE
        if degraded:
            return AnomalyEngineStatus.PARTIAL
        if not anomalies and observations:
            return AnomalyEngineStatus.OK  # processed, nothing to report
        return AnomalyEngineStatus.OK

    def _build_source_summary(self, anomalies: list[RoadAnomalyObservation]) -> str:
        if not anomalies:
            return NOT_AVAILABLE
        sources = sorted(set(a.source for a in anomalies if a.source != NOT_AVAILABLE))
        if not sources:
            return NOT_AVAILABLE
        return ",".join(sources)

    def _build_sensor_status(
        self, observations: list, road_und: Optional[Any]
    ) -> dict:
        status: dict[str, str] = {}
        sources = set(
            getattr(obs, "source", NOT_AVAILABLE)
            for obs in observations
            if hasattr(obs, "source")
        )
        for s in ("camera", "lidar", "radar", "fused"):
            status[s] = "OK" if s in sources else "UNAVAILABLE"
        return status


# ---------------------------------------------------------------------------
# Point-in-polygon utility (winding-number / ray-cast, vehicle frame)
# ---------------------------------------------------------------------------

def _point_in_polygon(px: float, py: float, polygon: list) -> bool:
    """
    Ray-casting point-in-polygon test.

    ``polygon`` is a list of (x, y) tuples in vehicle frame.
    Returns True iff (px, py) is strictly inside the polygon.
    """
    n = len(polygon)
    inside = False
    j = n - 1
    for i in range(n):
        xi, yi = polygon[i][0], polygon[i][1]
        xj, yj = polygon[j][0], polygon[j][1]
        if ((yi > py) != (yj > py)) and (px < (xj - xi) * (py - yi) / (yj - yi + 1e-12) + xi):
            inside = not inside
        j = i
    return inside


# ---------------------------------------------------------------------------
# Adapter: convert Phase 2 RoadAnomaly → RoadSurfaceObservation
# ---------------------------------------------------------------------------

def road_anomaly_to_observation(
    phase2_anomaly: Any,
    vehicle_frame_cx: Optional[float] = None,
    vehicle_frame_cy: Optional[float] = None,
) -> RoadSurfaceObservation:
    """
    Convert a Phase 2 ``RoadAnomaly`` (perception_types.py) to a
    ``RoadSurfaceObservation`` for Phase 6.3.

    Phase 2 RoadAnomaly uses pixel-space BoundingBox2D (x, y, width, height)
    and Dimensions3D (length, width, height).  Since Phase 2 does not produce
    metric vehicle-frame coordinates for anomalies (only for objects via LiDAR),
    the caller must provide ``vehicle_frame_cx`` / ``vehicle_frame_cy`` from
    Phase 3 fusion if available; otherwise position is unknown and the
    observation will have POINT geometry with no useful centre.

    Never fabricates values; returns an observation with confidence = 0 and
    unknown type if phase2_anomaly is None or malformed.
    """
    if phase2_anomaly is None:
        return RoadSurfaceObservation()

    atype = _classify_type_from_string(
        getattr(phase2_anomaly, "anomaly_type", "UNKNOWN") or "UNKNOWN"
    )
    conf = float(getattr(phase2_anomaly, "confidence", 0.0) or 0.0)
    conf = max(0.0, min(1.0, conf))

    # Size
    size = getattr(phase2_anomaly, "size_estimate", None)
    length_m = float(size.length) if (size and _finite(getattr(size, "length", None))) else None
    width_m = float(size.width) if (size and _finite(getattr(size, "width", None))) else None

    # Severity → visibility hint
    sev_str = (getattr(phase2_anomaly, "severity", "UNKNOWN") or "UNKNOWN").upper()
    vis_state = VisibilityState.UNKNOWN
    if "water" in (getattr(phase2_anomaly, "anomaly_type", "") or "").lower():
        vis_state = VisibilityState.OBSCURED

    src = getattr(phase2_anomaly, "source", None)
    src_str = src.value if hasattr(src, "value") else str(src or NOT_AVAILABLE)

    ts = float(getattr(phase2_anomaly, "timestamp", 0.0) or 0.0)

    return RoadSurfaceObservation(
        anomaly_type=atype,
        center_x=vehicle_frame_cx,
        center_y=vehicle_frame_cy,
        length_m=length_m,
        width_m=width_m,
        confidence=conf,
        source=src_str,
        timestamp=ts,
        visibility_state=vis_state,
    )
