"""
IndiDrive AI — Phase 2 | Perception Benchmark
=================================================
Measures ACTUAL camera+LiDAR perception throughput/latency by running
real frames (synthetic input data, but real code paths — real
preprocessing, real NMS, real clustering) through PerceptionEngine and
timing each cycle with time.perf_counter(). Every reported number is
computed from these measurements; nothing is a placeholder.

If no real detection model is configured, the benchmark still runs
(camera detection contributes ~0 objects but real preprocessing/NMS
timing) and the report clearly states which backend produced the
numbers (see `camera_backend_kind` in the report) so a NONE/MOCK-backed
benchmark is never mistaken for a REAL-model throughput measurement.
"""
from __future__ import annotations

import statistics
import time
import uuid
from dataclasses import dataclass, field
from typing import Optional

import numpy as np

from .perception_engine import PerceptionEngine, EngineConfig
from .utils import percentile


@dataclass
class BenchmarkReport:
    run_id: str
    iterations: int
    camera_backend_kind: str
    mean_latency_ms: float
    median_latency_ms: float
    p95_latency_ms: float
    min_latency_ms: float
    max_latency_ms: float
    mean_fps: float
    per_iteration_ms: list[float] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "run_id": self.run_id,
            "iterations": self.iterations,
            "camera_backend_kind": self.camera_backend_kind,
            "mean_latency_ms": round(self.mean_latency_ms, 3),
            "median_latency_ms": round(self.median_latency_ms, 3),
            "p95_latency_ms": round(self.p95_latency_ms, 3),
            "min_latency_ms": round(self.min_latency_ms, 3),
            "max_latency_ms": round(self.max_latency_ms, 3),
            "mean_fps": round(self.mean_fps, 2),
        }


def run_camera_benchmark(engine: Optional[PerceptionEngine] = None, iterations: int = 50,
                          image_size: tuple[int, int] = (640, 480)) -> BenchmarkReport:
    engine = engine or PerceptionEngine(EngineConfig())
    w, h = image_size
    rng = np.random.default_rng(0)
    latencies = []
    for i in range(iterations):
        img = rng.integers(0, 255, size=(h, w, 3), dtype=np.uint8)
        t0 = time.perf_counter()
        engine.camera.process(img, timestamp=time.time())
        latencies.append((time.perf_counter() - t0) * 1000.0)

    mean_ms = statistics.mean(latencies)
    return BenchmarkReport(
        run_id=uuid.uuid4().hex[:10], iterations=iterations,
        camera_backend_kind=engine.camera.backend_kind.value,
        mean_latency_ms=mean_ms, median_latency_ms=statistics.median(latencies),
        p95_latency_ms=percentile(latencies, 95), min_latency_ms=min(latencies), max_latency_ms=max(latencies),
        mean_fps=(1000.0 / mean_ms) if mean_ms > 0 else 0.0, per_iteration_ms=latencies,
    )


def run_lidar_benchmark(engine: Optional[PerceptionEngine] = None, iterations: int = 50,
                         n_points: int = 20000) -> BenchmarkReport:
    engine = engine or PerceptionEngine(EngineConfig())
    rng = np.random.default_rng(1)
    latencies = []
    for i in range(iterations):
        pts = rng.uniform(-40, 40, size=(n_points, 4)).astype(np.float32)
        pts[:, 3] = np.abs(pts[:, 3])
        t0 = time.perf_counter()
        engine.lidar.process(pts, timestamp=time.time())
        latencies.append((time.perf_counter() - t0) * 1000.0)

    mean_ms = statistics.mean(latencies)
    return BenchmarkReport(
        run_id=uuid.uuid4().hex[:10], iterations=iterations,
        camera_backend_kind="N/A (lidar benchmark)",
        mean_latency_ms=mean_ms, median_latency_ms=statistics.median(latencies),
        p95_latency_ms=percentile(latencies, 95), min_latency_ms=min(latencies), max_latency_ms=max(latencies),
        mean_fps=(1000.0 / mean_ms) if mean_ms > 0 else 0.0, per_iteration_ms=latencies,
    )
