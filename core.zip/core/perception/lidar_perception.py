"""
IndiDrive AI — Phase 2 | LiDAR Perception Pipeline
======================================================
LiDARFrame -> Validation -> NaN/Inf removal -> Range/Height filtering
-> Ground separation -> Obstacle clustering -> PerceptionObject list.

This is a LIGHTWEIGHT GEOMETRY-BASED baseline (grid/height heuristics),
not a deep-learning LiDAR detector — per the Phase 2 spec, a heavy
LiDAR DL framework is explicitly out of scope for this phase. Ground
separation uses a per-cell local-minimum height model, which is a
reasonable approximation on relatively flat roads but will
under/over-segment on steep terrain, near curbs, and around large
sloped obstacles — that limitation is documented, not hidden.

No scipy/sklearn dependency: clustering is done with a simple grid
(voxel) occupancy + flood-fill connected-components, in pure NumPy.
"""
from __future__ import annotations

import time
import uuid
from dataclasses import dataclass, field
from typing import Optional

import numpy as np

from .perception_types import (
    PerceptionObject, Position3D, Dimensions3D, ProcessingMetrics, SourceSensor, BackendKind,
)

try:
    from core.logging_system import get_logger
except ImportError:  # pragma: no cover
    get_logger = None


@dataclass
class LiDARPerceptionConfig:
    min_range_m: float = 1.0
    max_range_m: float = 80.0
    min_height_m: float = -2.5
    max_height_m: float = 3.5
    ground_removal: bool = True
    ground_cell_size_m: float = 1.0
    ground_margin_m: float = 0.25          # points within this height of the local ground estimate are "ground"
    clustering: bool = True
    cluster_cell_size_m: float = 0.5       # voxel size (XY) used for clustering
    min_cluster_points: int = 4
    max_clusters: int = 200                # bounded — never allocate unbounded clusters from noisy input


@dataclass
class LiDARPerceptionResult:
    objects: list[PerceptionObject]
    metrics: ProcessingMetrics
    status: str                            # OK | INVALID_FRAME | EMPTY_POINT_CLOUD
    ground_point_count: int = 0
    obstacle_point_count: int = 0
    warnings: list[str] = field(default_factory=list)
    # Additive Phase 6.1 field: the actual ground/obstacle point arrays
    # (not just counts), so a later-stage consumer (road_understanding.py)
    # can estimate road geometry without re-running ground separation.
    # None when unavailable (INVALID_FRAME/EMPTY_POINT_CLOUD) — never a
    # fabricated empty-looking array in that case.
    ground_points: Optional[np.ndarray] = None
    obstacle_points: Optional[np.ndarray] = None


class LiDARPerceptionPipeline:
    def __init__(self, config: Optional[LiDARPerceptionConfig] = None):
        self.config = config or LiDARPerceptionConfig()
        self._log = get_logger("sensors", component="lidar_perception") if get_logger else None
        self._fps_window: list[float] = []

    def _record_fps(self) -> float:
        now = time.time()
        self._fps_window.append(now)
        cutoff = now - 2.0
        while self._fps_window and self._fps_window[0] < cutoff:
            self._fps_window.pop(0)
        return (len(self._fps_window) / 2.0) if len(self._fps_window) > 1 else 0.0

    # -- pipeline stages -------------------------------------------------

    def _clean(self, points: np.ndarray) -> np.ndarray:
        """NaN/Inf removal."""
        finite_mask = np.isfinite(points).all(axis=1)
        return points[finite_mask]

    def _range_height_filter(self, points: np.ndarray) -> np.ndarray:
        x, y, z = points[:, 0], points[:, 1], points[:, 2]
        r = np.sqrt(x * x + y * y)
        mask = (
            (r >= self.config.min_range_m) & (r <= self.config.max_range_m)
            & (z >= self.config.min_height_m) & (z <= self.config.max_height_m)
        )
        return points[mask]

    def _ground_separation(self, points: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
        """Returns (ground_points, obstacle_points) using a per-XY-cell
        local-minimum-height model. Documented baseline, not a claim of
        perfect road-surface segmentation (see module docstring)."""
        if not self.config.ground_removal or points.shape[0] == 0:
            return points[:0], points

        cell = self.config.ground_cell_size_m
        cell_idx = np.floor(points[:, :2] / cell).astype(np.int64)
        # Group by cell -> per-cell min z, via a dict keyed on the packed cell index.
        keys = cell_idx[:, 0] * 1_000_003 + cell_idx[:, 1]
        order = np.argsort(keys)
        sorted_keys = keys[order]
        sorted_z = points[order, 2]

        # Compute per-cell minimum z using np.minimum.reduceat on sorted groups.
        unique_keys, first_idx = np.unique(sorted_keys, return_index=True)
        cell_min_z = np.minimum.reduceat(sorted_z, first_idx)
        min_z_lookup = dict(zip(unique_keys.tolist(), cell_min_z.tolist()))

        local_ground_z = np.array([min_z_lookup[k] for k in keys], dtype=np.float64)
        is_ground = points[:, 2] <= (local_ground_z + self.config.ground_margin_m)
        return points[is_ground], points[~is_ground]

    def _cluster(self, points: np.ndarray) -> list[np.ndarray]:
        """Grid-based (voxel) connected-components clustering in the XY
        plane. Returns a list of point-index arrays, one per cluster.
        Bounded by max_clusters — excess clusters (very noisy input) are
        dropped rather than allowed to grow unbounded."""
        if not self.config.clustering or points.shape[0] == 0:
            return []

        cell = self.config.cluster_cell_size_m
        cell_idx = np.floor(points[:, :2] / cell).astype(np.int64)
        # Map each occupied cell -> list of point indices in it.
        cell_to_points: dict[tuple[int, int], list[int]] = {}
        for i, (cx, cy) in enumerate(map(tuple, cell_idx)):
            cell_to_points.setdefault((cx, cy), []).append(i)

        visited: set[tuple[int, int]] = set()
        clusters: list[np.ndarray] = []
        neighbor_offsets = [(-1, -1), (-1, 0), (-1, 1), (0, -1), (0, 1), (1, -1), (1, 0), (1, 1), (0, 0)]

        for start_cell in cell_to_points:
            if start_cell in visited or len(clusters) >= self.config.max_clusters:
                continue
            stack = [start_cell]
            visited.add(start_cell)
            member_cells = []
            while stack:
                c = stack.pop()
                member_cells.append(c)
                for dx, dy in neighbor_offsets:
                    nb = (c[0] + dx, c[1] + dy)
                    if nb in cell_to_points and nb not in visited:
                        visited.add(nb)
                        stack.append(nb)
            point_indices = [i for c in member_cells for i in cell_to_points[c]]
            if len(point_indices) >= self.config.min_cluster_points:
                clusters.append(np.array(point_indices, dtype=np.int64))
        return clusters

    def _cluster_to_object(self, cluster_points: np.ndarray, timestamp: float, cluster_id: int) -> PerceptionObject:
        mins = cluster_points[:, :3].min(axis=0)
        maxs = cluster_points[:, :3].max(axis=0)
        centroid = cluster_points[:, :3].mean(axis=0)
        dims = maxs - mins
        distance = float(np.sqrt(centroid[0] ** 2 + centroid[1] ** 2))
        point_count = cluster_points.shape[0]

        # Simple, transparent confidence heuristic based on point density
        # (more points -> more confidence this is a real object, not noise).
        confidence = float(min(1.0, 0.3 + 0.05 * point_count))

        return PerceptionObject(
            object_id=f"lidar_{uuid.uuid4().hex[:10]}",
            object_class="unknown",         # LiDAR-only clusters carry no semantic class without fusion/classification
            raw_class="cluster",
            confidence=confidence,
            raw_confidence=confidence,
            source_sensor=SourceSensor.LIDAR,
            timestamp=timestamp,
            quality=min(1.0, point_count / 50.0),
            position_3d=Position3D(x=float(centroid[0]), y=float(centroid[1]), z=float(centroid[2])),
            dimensions_3d=Dimensions3D(length=float(dims[0]), width=float(dims[1]), height=float(dims[2])),
            distance=distance,
            tracking_ready=True,
            point_count=int(point_count),
            backend=BackendKind.BASELINE,
            extra={"cluster_id": cluster_id, "min_xyz": mins.tolist(), "max_xyz": maxs.tolist()},
        )

    # -- main entry point -------------------------------------------------

    def process(self, points: Optional[np.ndarray], timestamp: float) -> LiDARPerceptionResult:
        metrics = ProcessingMetrics()
        metrics.input_fps = self._record_fps()
        t_total_start = time.perf_counter()

        if points is None or not isinstance(points, np.ndarray) or points.ndim != 2 or points.shape[1] < 3:
            return LiDARPerceptionResult(objects=[], metrics=metrics, status="INVALID_FRAME",
                                          warnings=["INVALID_FRAME: points must be an Nx3(+) array"])
        if points.shape[0] == 0:
            return LiDARPerceptionResult(objects=[], metrics=metrics, status="EMPTY_POINT_CLOUD",
                                          warnings=["EMPTY_POINT_CLOUD"])

        t0 = time.perf_counter()
        pts = self._clean(points)
        pts = self._range_height_filter(pts)
        metrics.preprocessing_latency_ms = (time.perf_counter() - t0) * 1000.0

        if pts.shape[0] == 0:
            metrics.total_perception_latency_ms = (time.perf_counter() - t_total_start) * 1000.0
            return LiDARPerceptionResult(objects=[], metrics=metrics, status="OK",
                                          warnings=["no points survived range/height filtering"])

        t0 = time.perf_counter()
        ground, obstacles = self._ground_separation(pts)
        metrics.inference_latency_ms = (time.perf_counter() - t0) * 1000.0  # "inference" == geometric processing here

        t0 = time.perf_counter()
        clusters = self._cluster(obstacles)
        objects = [self._cluster_to_object(obstacles[idxs], timestamp, i) for i, idxs in enumerate(clusters)]
        metrics.postprocessing_latency_ms = (time.perf_counter() - t0) * 1000.0
        metrics.total_perception_latency_ms = (time.perf_counter() - t_total_start) * 1000.0
        metrics.processing_fps = 1000.0 / metrics.total_perception_latency_ms if metrics.total_perception_latency_ms > 0 else 0.0

        if self._log:
            self._log.info("lidar_frame_processed", cluster_count=len(objects),
                            ground_points=int(ground.shape[0]), obstacle_points=int(obstacles.shape[0]),
                            latency_ms=round(metrics.total_perception_latency_ms, 2))

        return LiDARPerceptionResult(
            objects=objects, metrics=metrics, status="OK",
            ground_point_count=int(ground.shape[0]), obstacle_point_count=int(obstacles.shape[0]),
            ground_points=ground, obstacle_points=obstacles,
        )
