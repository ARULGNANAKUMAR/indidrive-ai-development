"""
IndiDrive AI — Phase 6.5 | Road Understanding Integration Engine
================================================================================
Aggregates Phase 6.1–6.4 outputs into a single deterministic
``RoadUnderstandingState``.  This module is the implementation counterpart
to ``road_understanding_state.py`` (data contracts).

Responsibilities
----------------
  1. Validate all upstream inputs (None safety, type checks, range checks).
  2. Validate timestamp consistency across modules.
  3. Validate coordinate frame consistency.
  4. Integrate Phase 6.1 (drivable area / road boundaries).
  5. Integrate Phase 6.2 (lane & road structure).
  6. Integrate Phase 6.3 (road anomalies / damage).
  7. Integrate Phase 6.4 (Indian-road context).
  8. Run lightweight cross-module consistency checks.
  9. Propagate degradation from any upstream module.
  10. Aggregate confidence (weighted; explainable formula).
  11. Aggregate uncertainty (additive penalties; not simply 1-confidence).
  12. Generate compact derived summary.
  13. Freeze and return snapshot.

Constraints (same as every previous phase)
------------------------------------------
  * No new perception.  Phase 6.5 reads; it does not detect or classify.
  * No planner / controller / MPC / steering / braking logic.
  * No World Model construction (that is Phase 7).
  * No global mutable state (engine instances are independent).
  * Thread-safe: the engine does not share mutable state across calls.
  * Partial availability: if one module is None the engine continues.
  * Error isolation: an exception in one integration step does not crash
    the entire engine — it sets that module to ERROR and continues.
"""
from __future__ import annotations

import copy
import time
from dataclasses import dataclass, field
from typing import Any, Optional

from .perception_types import NOT_AVAILABLE
from .road_understanding_state import (
    RoadUnderstandingState,
    RoadUnderstandingStateConfig,
    RoadSummary,
    SensorAvailabilitySummary,
    ConsistencyReport,
    ConfidenceBreakdown,
    UncertaintyBreakdown,
    SourceProvenance,
    UnifiedStatus,
    ModuleAvailability,
    TimestampConsistency,
    GeometryConsistency,
    STATE_VERSION,
)

try:
    from core.logging_system import get_logger
    _logger = get_logger("road_understanding_engine") if get_logger else None
except Exception:
    _logger = None


def _log(level: str, msg: str) -> None:
    if _logger:
        getattr(_logger, level, _logger.info)(msg)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _clamp(value: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, value))


def _safe_copy(obj: Any) -> Any:
    """Deep-copy an upstream state object, or return None safely."""
    if obj is None:
        return None
    try:
        return copy.deepcopy(obj)
    except Exception:
        return obj   # fallback: reference if deepcopy fails (should not happen)


def _module_availability(state: Any, degraded_attr: str = "degraded") -> ModuleAvailability:
    """Derive ModuleAvailability from an upstream state object."""
    if state is None:
        return ModuleAvailability.UNAVAILABLE
    # Check status/status enum conventions used across Phase 6.x
    status_val = getattr(state, "status", None)
    if status_val is not None:
        sv = str(status_val.value if hasattr(status_val, "value") else status_val)
        if sv == "UNAVAILABLE":
            return ModuleAvailability.UNAVAILABLE
        if sv == "INVALID":
            return ModuleAvailability.ERROR
        if sv in ("DEGRADED", "PARTIAL"):
            return ModuleAvailability.DEGRADED
        if sv == "OK":
            return ModuleAvailability.OK
    # Fallback: check degraded flag
    if getattr(state, degraded_attr, False):
        return ModuleAvailability.DEGRADED
    return ModuleAvailability.OK


def _module_confidence(state: Any, primary_attr: str = "confidence",
                       fallback_attr: str = "overall_confidence") -> float:
    """Extract confidence from an upstream state, returning 0.0 if unavailable."""
    if state is None:
        return 0.0
    v = getattr(state, primary_attr, None)
    if v is None:
        v = getattr(state, fallback_attr, 0.0)
    try:
        return _clamp(float(v), 0.0, 1.0)
    except (TypeError, ValueError):
        return 0.0


def _module_uncertainty(state: Any, primary_attr: str = "uncertainty",
                        fallback_attr: str = "overall_uncertainty") -> float:
    """Extract uncertainty from an upstream state, returning 1.0 if unavailable."""
    if state is None:
        return 1.0
    v = getattr(state, primary_attr, None)
    if v is None:
        v = getattr(state, fallback_attr, 1.0)
    try:
        return max(0.0, float(v))
    except (TypeError, ValueError):
        return 1.0


def _module_timestamp(state: Any) -> Optional[float]:
    """Extract timestamp from an upstream state, returning None if absent."""
    if state is None:
        return None
    v = getattr(state, "timestamp", None)
    if v is None:
        return None
    try:
        f = float(v)
        return f if f > 0.0 else None
    except (TypeError, ValueError):
        return None


def _module_sensor_status(state: Any) -> dict:
    """Extract sensor_status dict from an upstream state."""
    if state is None:
        return {}
    ss = getattr(state, "sensor_status", {})
    if isinstance(ss, dict):
        return dict(ss)
    # IndianRoadContextState uses a SensorStatusSummary object
    if hasattr(ss, "to_dict"):
        return ss.to_dict()
    return {}


# ---------------------------------------------------------------------------
# Integration engine
# ---------------------------------------------------------------------------

class RoadUnderstandingEngine:
    """
    Phase 6.5 integration engine.

    Usage::

        engine = RoadUnderstandingEngine(config)
        state = engine.process(
            drivable_area=ru,       # RoadUnderstanding from Phase 6.1
            lane_structure=ls,      # LaneStructure from Phase 6.2
            road_anomalies=ras,     # RoadAnomalyState from Phase 6.3
            indian_context=irc,     # IndianRoadContextState from Phase 6.4
        )

    Each call is independent — the engine holds no mutable state between calls.
    Passing None for any upstream module is valid; the engine continues in
    partial-availability mode.

    Parameters
    ----------
    config : RoadUnderstandingStateConfig, optional
        Aggregation and validation configuration.  If None, default values
        are used.
    """

    def __init__(self, config: Optional[RoadUnderstandingStateConfig] = None) -> None:
        self._config: RoadUnderstandingStateConfig = config or RoadUnderstandingStateConfig()

    def process(
        self,
        drivable_area: Optional[Any] = None,
        lane_structure: Optional[Any] = None,
        road_anomalies: Optional[Any] = None,
        indian_context: Optional[Any] = None,
    ) -> RoadUnderstandingState:
        """
        Build and return a unified ``RoadUnderstandingState`` snapshot.

        Processing order is deterministic (spec §26):
          1. validate inputs
          2. validate timestamps
          3. validate coordinate frames
          4. validate upstream states
          5. integrate Phase 6.1
          6. integrate Phase 6.2
          7. integrate Phase 6.3
          8. integrate Phase 6.4
          9. run consistency checks
         10. propagate degradation
         11. aggregate confidence
         12. aggregate uncertainty
         13. generate summary
         14. freeze / return snapshot

        Returns a complete RoadUnderstandingState even when all upstream
        modules are None.
        """
        cfg = self._config
        state = RoadUnderstandingState()
        state.state_version = STATE_VERSION
        state.created_at = time.time()
        warnings: list = []

        # ---- Step 1: Deep-copy inputs for snapshot semantics ---------------
        da   = _safe_copy(drivable_area)
        ls   = _safe_copy(lane_structure)
        ra   = _safe_copy(road_anomalies)
        ctx  = _safe_copy(indian_context)

        # ---- Step 2: Module availability ------------------------------------
        avail61 = _module_availability(da)
        avail62 = _module_availability(ls)
        avail63 = _module_availability(ra)
        avail64 = _module_availability(ctx)

        state.phase61_availability = avail61
        state.phase62_availability = avail62
        state.phase63_availability = avail63
        state.phase64_availability = avail64

        # ---- Step 3: Upstream state references (already deep-copied) --------
        state.drivable_area_state  = da
        state.lane_structure_state = ls
        state.road_anomaly_state   = ra
        state.indian_context_state = ctx

        # ---- Step 4: Timestamp -------------------------------------------
        # Use the most recent valid timestamp as the reference timestamp.
        timestamps = {
            "phase61": _module_timestamp(da),
            "phase62": _module_timestamp(ls),
            "phase63": _module_timestamp(ra),
            "phase64": _module_timestamp(ctx),
        }
        valid_ts = [v for v in timestamps.values() if v is not None]
        if valid_ts:
            state.timestamp = max(valid_ts)
        else:
            state.timestamp = 0.0

        # frame_id: prefer Phase 6.1 (primary geometry source)
        state.frame_id = int(getattr(da, "frame_id", 0) or 0)

        # ---- Step 5: Timestamp consistency validation ----------------------
        consistency = ConsistencyReport()
        consistency = self._validate_timestamps(timestamps, state.timestamp, cfg, warnings)

        # ---- Step 6: Coordinate frame consistency --------------------------
        self._validate_frames(da, ls, ra, consistency, warnings)

        # ---- Step 7: Upstream-state-level validation -----------------------
        # (ranges already validated inside each Phase; we check NaN / Inf)
        self._validate_upstream_states(da, ls, ra, ctx, consistency, warnings)

        # ---- Step 8: Sensor availability summary ---------------------------
        sensor_avail = self._build_sensor_summary(da, ls, ra, ctx, avail61, avail62, avail63, avail64)
        state.sensor_availability = sensor_avail

        # ---- Step 9: Source provenance -------------------------------------
        provenance = SourceProvenance(
            drivable_area=getattr(da, "source", NOT_AVAILABLE) if da else NOT_AVAILABLE,
            lane_structure=getattr(ls, "source", NOT_AVAILABLE) if ls else NOT_AVAILABLE,
            road_anomalies=getattr(ra, "source_summary", NOT_AVAILABLE) if ra else NOT_AVAILABLE,
            context="DERIVED",
        )
        state.provenance = provenance

        # ---- Step 10: Consistency checks (cross-module) --------------------
        self._check_geometry_consistency(da, ls, ra, ctx, consistency, cfg, warnings)
        state.consistency = consistency

        # ---- Step 11: Confidence aggregation --------------------------------
        cb, ub = self._aggregate_confidence_uncertainty(
            da, ls, ra, ctx, avail61, avail62, avail63, avail64,
            consistency, cfg, warnings
        )
        state.confidence_breakdown = cb
        state.uncertainty_breakdown = ub
        state.overall_confidence = cb.overall
        state.overall_uncertainty = ub.overall

        # ---- Step 12: Degradation propagation --------------------------------
        any_degraded = any(
            a in (ModuleAvailability.DEGRADED, ModuleAvailability.ERROR)
            for a in (avail61, avail62, avail63, avail64)
        )
        any_unavailable = any(
            a == ModuleAvailability.UNAVAILABLE
            for a in (avail61, avail62, avail63, avail64)
        )
        all_unavailable = all(
            a == ModuleAvailability.UNAVAILABLE
            for a in (avail61, avail62, avail63, avail64)
        )
        state.degraded = any_degraded or any_unavailable
        sensor_avail.road_understanding_degraded = state.degraded

        # ---- Step 13: Compact derived summary ------------------------------
        state.summary = self._build_summary(da, ls, ra, ctx)

        # ---- Step 14: Overall status ----------------------------------------
        if all_unavailable:
            state.status = UnifiedStatus.UNAVAILABLE
            state.valid = False
        elif consistency.timestamp_consistency == TimestampConsistency.INVALID:
            state.status = UnifiedStatus.INVALID
            state.valid = False
        elif any_degraded or consistency.has_any_conflict():
            state.status = UnifiedStatus.DEGRADED if any_unavailable else UnifiedStatus.PARTIAL
            state.valid = True
        elif any_unavailable:
            state.status = UnifiedStatus.PARTIAL
            state.valid = True
        else:
            state.status = UnifiedStatus.OK
            state.valid = True

        # Sanity: if confidence is very low, downgrade validity
        if state.overall_confidence < 0.05 and state.status == UnifiedStatus.OK:
            state.status = UnifiedStatus.DEGRADED

        state.warnings = warnings
        state.metadata = {
            "engine_version": STATE_VERSION,
            "processing_time_at": state.created_at,
        }

        return state

    # -----------------------------------------------------------------
    # Internal steps
    # -----------------------------------------------------------------

    def _validate_timestamps(
        self,
        timestamps: dict,
        reference_ts: float,
        cfg: RoadUnderstandingStateConfig,
        warnings: list,
    ) -> ConsistencyReport:
        consistency = ConsistencyReport()

        none_modules = [k for k, v in timestamps.items() if v is None]
        if none_modules:
            # Not an error if module is simply unavailable — handled separately
            pass

        valid_ts = {k: v for k, v in timestamps.items() if v is not None}
        if not valid_ts:
            consistency.timestamp_consistency = TimestampConsistency.MISSING
            warnings.append("No valid timestamps from any upstream module.")
            return consistency

        skews = {k: abs(v - reference_ts) for k, v in valid_ts.items()}
        max_skew = max(skews.values())
        consistency.timestamp_skew_seconds = max_skew

        # Check for obviously invalid (negative) timestamps
        if any(v <= 0 for v in valid_ts.values()):
            consistency.timestamp_consistency = TimestampConsistency.INVALID
            warnings.append("One or more upstream modules reported zero / negative timestamp.")
            return consistency

        if max_skew > cfg.max_timestamp_skew_seconds:
            consistency.timestamp_consistency = TimestampConsistency.STALE
            stale_modules = [k for k, s in skews.items() if s > cfg.max_timestamp_skew_seconds]
            warnings.append(
                f"Timestamp skew exceeds tolerance ({max_skew:.3f}s > "
                f"{cfg.max_timestamp_skew_seconds}s). Stale: {stale_modules}"
            )
        elif max_skew > cfg.extended_timestamp_skew_seconds:
            consistency.timestamp_consistency = TimestampConsistency.ACCEPTABLE
            warnings.append(f"Minor timestamp skew ({max_skew:.3f}s) within extended tolerance.")
        else:
            consistency.timestamp_consistency = TimestampConsistency.CONSISTENT

        return consistency

    def _validate_frames(
        self,
        da: Any, ls: Any, ra: Any,
        consistency: ConsistencyReport,
        warnings: list,
    ) -> None:
        """
        Verify that geometry-bearing modules share the same frame_id convention.

        We do not silently transform data.  If frame IDs conflict, we record
        a warning and set geometry_consistency to WARNING.
        """
        frame_ids = {}
        if da is not None:
            fid = getattr(da, "frame_id", None)
            if fid is not None:
                frame_ids["phase61"] = fid
        if ls is not None:
            fid = getattr(ls, "frame_id", None)
            if fid is not None:
                frame_ids["phase62"] = fid
        if ra is not None:
            fid = getattr(ra, "frame_id", None)
            if fid is not None:
                frame_ids["phase63"] = fid

        if len(set(frame_ids.values())) > 1:
            consistency.geometry_consistency = GeometryConsistency.WARNING
            warnings.append(
                f"Frame ID mismatch across geometry modules: {frame_ids}. "
                "Geometry may not be co-registered."
            )

    def _validate_upstream_states(
        self,
        da: Any, ls: Any, ra: Any, ctx: Any,
        consistency: ConsistencyReport,
        warnings: list,
    ) -> None:
        """Lightweight sanity checks on each upstream state object."""
        def _check_confidence(val: float, name: str) -> None:
            if val < 0.0 or val > 1.0:
                warnings.append(f"{name}: confidence {val:.3f} out of [0,1] range.")

        if da is not None:
            _check_confidence(getattr(da, "confidence", 0.0), "Phase 6.1")
        if ls is not None:
            _check_confidence(getattr(ls, "confidence", 0.0), "Phase 6.2")
        if ra is not None:
            _check_confidence(getattr(ra, "overall_confidence", 0.0), "Phase 6.3")
        if ctx is not None:
            _check_confidence(getattr(ctx, "confidence", 0.0), "Phase 6.4")

    def _check_geometry_consistency(
        self,
        da: Any, ls: Any, ra: Any, ctx: Any,
        consistency: ConsistencyReport,
        cfg: RoadUnderstandingStateConfig,
        warnings: list,
    ) -> None:
        """
        Lightweight cross-module geometric consistency checks.

        We NEVER silently modify upstream data.  We only record warnings
        and set consistency flags.
        """
        # If already in CONFLICT from frame check, don't downgrade
        already_conflict = consistency.geometry_consistency == GeometryConsistency.CONFLICT
        has_warning = consistency.geometry_consistency == GeometryConsistency.WARNING

        # --- Road width vs lane structure implication -----------------------
        if da is not None and ls is not None:
            # Get road width from Phase 6.1
            road_width_m: Optional[float] = None
            wps = getattr(da, "road_width_profile", [])
            if wps:
                widths = [
                    wp.width_m for wp in wps
                    if hasattr(wp, "width_m") and wp.width_m is not None
                ]
                if widths:
                    road_width_m = sum(widths) / len(widths)

            # Validate road width in plausible range
            if road_width_m is not None:
                if not (cfg.min_physical_road_width_m <= road_width_m <= cfg.max_physical_road_width_m):
                    warnings.append(
                        f"Phase 6.1 road width {road_width_m:.2f}m outside plausible range "
                        f"[{cfg.min_physical_road_width_m}, {cfg.max_physical_road_width_m}]m."
                    )
                    has_warning = True

            # Lane width validation
            for lane in getattr(ls, "lanes", []):
                for ws in getattr(lane, "width_samples", []):
                    lw = getattr(ws, "estimated_width_m", None)
                    if lw is not None and not (
                        cfg.min_physical_lane_width_m <= lw <= cfg.max_physical_lane_width_m
                    ):
                        warnings.append(
                            f"Phase 6.2 lane {getattr(lane, 'lane_id', '?')} width "
                            f"{lw:.2f}m outside plausible range."
                        )
                        has_warning = True

            # Road width vs implied lane structure width
            lane_count = getattr(ls, "lane_count", None)
            if road_width_m is not None and lane_count and lane_count > 0:
                implied_min = lane_count * cfg.min_physical_lane_width_m
                # Conflict: the minimum width required for lane_count lanes
                # exceeds the observed road width (physical impossibility).
                if implied_min > road_width_m:
                    consistency.road_width_conflict = True
                    warnings.append(
                        f"Road width conflict: Phase 6.1 width {road_width_m:.2f}m but "
                        f"Phase 6.2 implies {lane_count} lanes "
                        f"(min {implied_min:.2f}m needed)."
                    )
                    already_conflict = True

        # --- Marking state conflict (Phase 6.2 vs Phase 6.4) ----------------
        if ls is not None and ctx is not None:
            ls_marking = getattr(ls, "marking_status", None)
            ctx_marking = getattr(ctx, "road_marking_state", None)
            if ls_marking is not None and ctx_marking is not None:
                ls_val = str(ls_marking.value if hasattr(ls_marking, "value") else ls_marking)
                ctx_val = str(ctx_marking.value if hasattr(ctx_marking, "value") else ctx_marking)
                # MARKED vs UNMARKED is a meaningful conflict
                ls_marked = ls_val in ("MARKED",)
                ctx_unmarked = ctx_val in ("UNMARKED",)
                ls_unmarked = ls_val in ("UNMARKED",)
                ctx_marked = ctx_val in ("MARKED",)
                if (ls_marked and ctx_unmarked) or (ls_unmarked and ctx_marked):
                    consistency.marking_state_conflict = True
                    warnings.append(
                        f"Marking state conflict: Phase 6.2 says '{ls_val}', "
                        f"Phase 6.4 says '{ctx_val}'. Uncertainty increased."
                    )
                    has_warning = True

        # --- Anomaly coordinate validation ----------------------------------
        if ra is not None:
            for anomaly in getattr(ra, "anomalies", []):
                geom = getattr(anomaly, "geometry", None)
                if geom is None:
                    continue
                cx = getattr(geom, "center_x_m", None)
                cy = getattr(geom, "center_y_m", None)
                if cx is not None and cy is not None:
                    import math
                    if math.isnan(cx) or math.isinf(cx) or math.isnan(cy) or math.isinf(cy):
                        consistency.anomaly_frame_conflict = True
                        warnings.append(
                            f"Phase 6.3 anomaly {getattr(anomaly, 'anomaly_id', '?')} "
                            "has NaN/Inf geometry coordinates."
                        )
                        already_conflict = True

        # Set final geometry_consistency
        if already_conflict:
            consistency.geometry_consistency = GeometryConsistency.CONFLICT
        elif has_warning:
            consistency.geometry_consistency = GeometryConsistency.WARNING
        elif consistency.geometry_consistency == GeometryConsistency.UNCHECKED:
            # At least some data was present
            if da is not None or ls is not None or ra is not None:
                consistency.geometry_consistency = GeometryConsistency.CONSISTENT

    def _build_sensor_summary(
        self,
        da: Any, ls: Any, ra: Any, ctx: Any,
        avail61: ModuleAvailability,
        avail62: ModuleAvailability,
        avail63: ModuleAvailability,
        avail64: ModuleAvailability,
    ) -> SensorAvailabilitySummary:
        """Build a compact sensor availability summary from upstream sensor_status dicts.

        Conservative aggregation: a sensor is available only if at least one
        module reports it as OK AND no module explicitly reports it as UNAVAILABLE.
        """
        summary = SensorAvailabilitySummary()

        # Collect per-sensor votes from all modules
        sensor_votes: dict = {}   # sensor_name -> list[str]
        for state in (da, ls, ra, ctx):
            ss = _module_sensor_status(state)
            for sensor, val in ss.items():
                sensor_votes.setdefault(sensor, []).append(str(val).upper())

        def _is_available(sensor: str) -> bool:
            votes = sensor_votes.get(sensor, [])
            if not votes:
                return False
            ok_values = {"OK", "AVAILABLE", "HEALTHY", "TRUE", "1"}
            unavail_values = {"UNAVAILABLE", "MISSING", "ERROR", "FALSE", "0"}
            has_ok = any(v in ok_values for v in votes)
            has_unavail = any(v in unavail_values for v in votes)
            # Available only when at least one OK vote AND no explicit UNAVAILABLE
            return has_ok and not has_unavail

        summary.camera_available = _is_available("camera")
        summary.lidar_available = _is_available("lidar")
        summary.radar_available = _is_available("radar")

        # Fusion available if both camera and lidar are
        summary.fusion_available = summary.camera_available and summary.lidar_available

        # Road understanding degraded if any key module is not OK
        summary.road_understanding_degraded = any(
            a in (ModuleAvailability.DEGRADED, ModuleAvailability.ERROR, ModuleAvailability.UNAVAILABLE)
            for a in (avail61, avail62, avail63, avail64)
        )

        return summary

    def _aggregate_confidence_uncertainty(
        self,
        da: Any, ls: Any, ra: Any, ctx: Any,
        avail61: ModuleAvailability,
        avail62: ModuleAvailability,
        avail63: ModuleAvailability,
        avail64: ModuleAvailability,
        consistency: ConsistencyReport,
        cfg: RoadUnderstandingStateConfig,
        warnings: list,
    ):
        """
        Aggregate confidence and uncertainty deterministically.

        Confidence:
            weighted average of available upstream confidences, penalised for
            missing modules, degraded sensors, and consistency conflicts.

        Uncertainty:
            starts from the upstream uncertainties; penalties are added for
            missing data, timestamp staleness, geometry conflicts, etc.

        Neither is simply the inverse of the other.
        """
        cb = ConfidenceBreakdown()
        ub = UncertaintyBreakdown()

        # Per-module confidence / uncertainty
        cb.drivable_area  = _module_confidence(da)
        cb.lane_structure = _module_confidence(ls)
        cb.road_anomaly   = _module_confidence(ra, "overall_confidence", "confidence")
        cb.indian_context = _module_confidence(ctx)

        ub.drivable_area  = _module_uncertainty(da)
        ub.lane_structure = _module_uncertainty(ls)
        ub.road_anomaly   = _module_uncertainty(ra, "overall_uncertainty", "uncertainty")
        ub.indian_context = _module_uncertainty(ctx)

        # --- Overall confidence (weighted) ----------------------------------
        total_weight = 0.0
        weighted_sum = 0.0

        modules = [
            (avail61, cb.drivable_area,  cfg.weight_drivable_area),
            (avail62, cb.lane_structure, cfg.weight_lane_structure),
            (avail63, cb.road_anomaly,   cfg.weight_road_anomaly),
            (avail64, cb.indian_context, cfg.weight_indian_context),
        ]

        for avail, conf, weight in modules:
            if avail != ModuleAvailability.UNAVAILABLE:
                weighted_sum += conf * weight
                total_weight += weight

        if total_weight > 0:
            base_confidence = weighted_sum / total_weight
        else:
            base_confidence = 0.0

        # Penalty: missing modules
        missing_count = sum(
            1 for a in (avail61, avail62, avail63, avail64)
            if a == ModuleAvailability.UNAVAILABLE
        )
        degraded_count = sum(
            1 for a in (avail61, avail62, avail63, avail64)
            if a in (ModuleAvailability.DEGRADED, ModuleAvailability.ERROR)
        )

        confidence_penalty = (
            missing_count * cfg.confidence_penalty_module_missing
            + degraded_count * cfg.confidence_penalty_sensor_degraded
        )

        if consistency.has_any_conflict():
            confidence_penalty += cfg.confidence_penalty_consistency_conflict

        cb.overall = _clamp(base_confidence - confidence_penalty, 0.0, 1.0)

        # --- Overall uncertainty (additive penalties) ----------------------
        # Start from max upstream uncertainty (most conservative)
        available_uncertainties = []
        for avail, unc in [
            (avail61, ub.drivable_area),
            (avail62, ub.lane_structure),
            (avail63, ub.road_anomaly),
            (avail64, ub.indian_context),
        ]:
            if avail != ModuleAvailability.UNAVAILABLE:
                available_uncertainties.append(unc)

        if available_uncertainties:
            base_uncertainty = max(available_uncertainties)
        else:
            base_uncertainty = 1.0

        # Additive penalties
        uncertainty_penalty = 0.0

        if consistency.timestamp_consistency in (
            TimestampConsistency.STALE, TimestampConsistency.INVALID, TimestampConsistency.MISSING
        ):
            uncertainty_penalty += cfg.uncertainty_penalty_timestamp_stale

        if consistency.geometry_consistency == GeometryConsistency.CONFLICT:
            uncertainty_penalty += cfg.uncertainty_penalty_geometry_conflict

        uncertainty_penalty += missing_count * cfg.uncertainty_penalty_module_missing
        uncertainty_penalty += degraded_count * cfg.uncertainty_penalty_sensor_degraded

        # Each consistency warning adds a small penalty
        warning_count = sum(1 for _ in consistency.warnings)
        uncertainty_penalty += warning_count * cfg.uncertainty_penalty_consistency_warning

        ub.overall = _clamp(base_uncertainty + uncertainty_penalty, 0.0, 1.0)

        return cb, ub

    def _build_summary(
        self,
        da: Any, ls: Any, ra: Any, ctx: Any,
    ) -> RoadSummary:
        """
        Build a compact derived summary for downstream fast access.

        Priority: Phase 6.4 (Indian-road context) for semantic fields, as it
        synthesises Phases 6.1–6.3.  Fall back to earlier phases where context
        is not available.
        """
        s = RoadSummary()

        # --- Road type / width (Phase 6.4 preferred) ------------------------
        if ctx is not None:
            rt = getattr(ctx, "road_type", None)
            s.road_type = str(rt.value if hasattr(rt, "value") else rt) if rt is not None else NOT_AVAILABLE

            rwc = getattr(ctx, "road_width_category", None)
            s.road_width_category = str(rwc.value if hasattr(rwc, "value") else rwc) if rwc is not None else NOT_AVAILABLE

            s.estimated_road_width_m = getattr(ctx, "estimated_road_width_m", None)

            td = getattr(ctx, "traffic_density", None)
            s.traffic_density = str(td.value if hasattr(td, "value") else td) if td is not None else NOT_AVAILABLE

            rc = getattr(ctx, "road_complexity", None)
            s.road_complexity = str(rc.value if hasattr(rc, "value") else rc) if rc is not None else NOT_AVAILABLE

            s.animal_present = bool(getattr(ctx, "animal_present", False))

            vru = getattr(ctx, "vru_presence", None)
            s.vru_presence = str(vru.value if hasattr(vru, "value") else vru) if vru is not None else NOT_AVAILABLE

        # --- Lane structure (Phase 6.2 preferred) ---------------------------
        if ls is not None:
            ms = getattr(ls, "marking_status", None)
            s.lane_marking_state = str(ms.value if hasattr(ms, "value") else ms) if ms is not None else NOT_AVAILABLE

            s.lane_count = getattr(ls, "lane_count", None)

            istate = getattr(ls, "intersection_state", None)
            s.intersection_state = str(istate.value if hasattr(istate, "value") else istate) if istate is not None else NOT_AVAILABLE
        elif ctx is not None:
            # Fallback from Phase 6.4
            ms = getattr(ctx, "road_marking_state", None)
            if ms is not None:
                s.lane_marking_state = str(ms.value if hasattr(ms, "value") else ms)
            s.lane_count = getattr(ctx, "lane_count", None)

        # --- Road surface quality (Phase 6.3) --------------------------------
        if ra is not None:
            rsq = getattr(ra, "road_surface_quality", None)
            s.road_surface_quality = str(rsq.value if hasattr(rsq, "value") else rsq) if rsq is not None else NOT_AVAILABLE

            anomalies = getattr(ra, "anomalies", [])
            s.anomaly_count = len(anomalies)

            # Critical anomaly: CRITICAL severity AND inside drivable area
            for anomaly in anomalies:
                sev = getattr(anomaly, "severity", None)
                sev_str = str(sev.value if hasattr(sev, "value") else sev) if sev is not None else ""
                dar = getattr(anomaly, "drivable_area_relation", None)
                dar_str = str(dar.value if hasattr(dar, "value") else dar) if dar is not None else ""
                if sev_str == "CRITICAL" and dar_str in (
                    "INSIDE_DRIVABLE_AREA", "PARTIALLY_OVERLAPPING_DRIVABLE_AREA"
                ):
                    s.has_critical_anomaly = True
                    break

        return s

    # -----------------------------------------------------------------
    # Additional public API
    # -----------------------------------------------------------------

    def build_state(
        self,
        drivable_area: Optional[Any] = None,
        lane_structure: Optional[Any] = None,
        road_anomalies: Optional[Any] = None,
        indian_context: Optional[Any] = None,
    ) -> RoadUnderstandingState:
        """Alias for ``process()`` — matches API description in spec §31."""
        return self.process(
            drivable_area=drivable_area,
            lane_structure=lane_structure,
            road_anomalies=road_anomalies,
            indian_context=indian_context,
        )

    def validate_state(self, state: RoadUnderstandingState) -> list:
        """
        Validate a pre-built ``RoadUnderstandingState`` object.

        Returns a list of validation error strings.  Empty = valid.
        """
        errors: list = []
        if not isinstance(state, RoadUnderstandingState):
            return ["Not a RoadUnderstandingState instance."]

        if state.state_version != STATE_VERSION:
            errors.append(
                f"State version mismatch: got '{state.state_version}', expected '{STATE_VERSION}'."
            )
        if not (0.0 <= state.overall_confidence <= 1.0):
            errors.append(
                f"overall_confidence {state.overall_confidence:.3f} out of [0, 1] range."
            )
        if state.overall_uncertainty < 0.0:
            errors.append(
                f"overall_uncertainty {state.overall_uncertainty:.3f} is negative."
            )
        if state.timestamp < 0.0:
            errors.append(f"timestamp {state.timestamp} is negative.")
        if state.frame_id < 0:
            errors.append(f"frame_id {state.frame_id} is negative.")

        return errors

    def check_consistency(self, state: RoadUnderstandingState) -> ConsistencyReport:
        """Return the consistency report embedded in the state."""
        return state.consistency

    def aggregate_confidence(
        self, da: Any = None, ls: Any = None, ra: Any = None, ctx: Any = None
    ) -> float:
        """Compute overall confidence without building the full state."""
        avails = (
            _module_availability(da),
            _module_availability(ls),
            _module_availability(ra),
            _module_availability(ctx),
        )
        cr = ConsistencyReport()
        cb, _ = self._aggregate_confidence_uncertainty(
            da, ls, ra, ctx,
            *avails, cr, self._config, []
        )
        return cb.overall

    def aggregate_uncertainty(
        self, da: Any = None, ls: Any = None, ra: Any = None, ctx: Any = None
    ) -> float:
        """Compute overall uncertainty without building the full state."""
        avails = (
            _module_availability(da),
            _module_availability(ls),
            _module_availability(ra),
            _module_availability(ctx),
        )
        cr = ConsistencyReport()
        _, ub = self._aggregate_confidence_uncertainty(
            da, ls, ra, ctx,
            *avails, cr, self._config, []
        )
        return ub.overall

    def get_snapshot(
        self,
        drivable_area: Optional[Any] = None,
        lane_structure: Optional[Any] = None,
        road_anomalies: Optional[Any] = None,
        indian_context: Optional[Any] = None,
    ) -> RoadUnderstandingState:
        """Alias for ``process()``."""
        return self.process(
            drivable_area=drivable_area,
            lane_structure=lane_structure,
            road_anomalies=road_anomalies,
            indian_context=indian_context,
        )

    def reset(self) -> None:
        """No-op: the engine holds no mutable per-call state."""
        pass
