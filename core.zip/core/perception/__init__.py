"""
IndiDrive AI — Phase 2 | Real-Time Perception Layer
======================================================
Turns validated SensorFrame objects (Phase 1) into structured
PerceptionFrame objects: detected objects, road/drivable-area state,
and road anomalies — with honest, measured confidence and timing.

This package contains NO sensor acquisition code (that is Phase 1's
core/carla_integration/) and NO planning/control code (that is a
future phase). It is a pure transformation layer:

    SensorFrame  ->  PerceptionManager  ->  PerceptionFrame

Public entry points:
    PerceptionManager   — top-level lifecycle + orchestration (see perception_manager.py)
    PerceptionEngine     — per-frame camera+lidar+road+anomaly fusion (see perception_engine.py)
    PerceptionFrame      — the unified output contract (see perception_types.py)
"""
from .perception_types import (  # noqa: F401
    PerceptionObject, PerceptionFrame, RoadState, DrivableArea, RoadAnomaly,
    ProcessingMetrics, PerceptionQuality, BoundingBox2D, Position3D, Dimensions3D,
    BackendKind, HealthState, NOT_AVAILABLE,
)
from .perception_manager import PerceptionManager  # noqa: F401
from .perception_engine import PerceptionEngine  # noqa: F401
# Phase 6.2
from .lane_structure import LaneStructureEngine, LaneStructureConfig  # noqa: F401
from .lane_structure_types import (  # noqa: F401
    LaneStructure, LaneStructureStatus,
    MarkingStatus, MarkingType, EvidenceKind, RoadTypeHint, IntersectionState,
    LaneMarking, LaneMarkingPoint,
    LaneBoundary, LaneBoundaryPoint,
    LaneCenterline, CenterlinePoint,
    LaneDescriptor, LaneWidthSample,
)

# Phase 6.4
from .indian_road_context import IndianRoadContextEngine, IndianRoadContextConfig  # noqa: F401
from .indian_road_context_types import (  # noqa: F401
    IndianRoadContextState,
    ContextEngineStatus,
    RoadType,
    RoadWidthCategory,
    RoadMarkingState,
    IntersectionContext,
    RoadDamageContext,
    TrafficDensity,
    VRUPresence,
    AnimalActivity,
    RoadComplexity,
    ContextStability,
    ContextFlag,
    TrafficMixSummary,
    RoadsideActivitySummary,
    RoadDamageSummary,
    EvidenceItem,
    SensorStatusSummary,
)

# Phase 6.5 — Unified Road Understanding State
from .road_understanding_state import (  # noqa: F401
    RoadUnderstandingState,
    RoadUnderstandingStateConfig,
    RoadSummary,
    SensorAvailabilitySummary,
    ConsistencyReport,
    ConfidenceBreakdown,
    UncertaintyBreakdown,
    SourceProvenance,
    UnifiedStatus,
    ModuleAvailability,
    TimestampConsistency,
    GeometryConsistency,
    STATE_VERSION,
)
from .road_understanding_engine import RoadUnderstandingEngine  # noqa: F401

__all__ = [
    "PerceptionObject", "PerceptionFrame", "RoadState", "DrivableArea", "RoadAnomaly",
    "ProcessingMetrics", "PerceptionQuality", "BoundingBox2D", "Position3D", "Dimensions3D",
    "BackendKind", "HealthState", "NOT_AVAILABLE",
    "PerceptionManager", "PerceptionEngine",
    # Phase 6.2
    "LaneStructureEngine", "LaneStructureConfig",
    "LaneStructure", "LaneStructureStatus",
    "MarkingStatus", "MarkingType", "EvidenceKind", "RoadTypeHint", "IntersectionState",
    "LaneMarking", "LaneMarkingPoint",
    "LaneBoundary", "LaneBoundaryPoint",
    "LaneCenterline", "CenterlinePoint",
    "LaneDescriptor", "LaneWidthSample",
    # Phase 6.5
    "RoadUnderstandingEngine",
    "RoadUnderstandingState", "RoadUnderstandingStateConfig",
    "RoadSummary", "SensorAvailabilitySummary",
    "ConsistencyReport", "ConfidenceBreakdown", "UncertaintyBreakdown",
    "SourceProvenance", "UnifiedStatus", "ModuleAvailability",
    "TimestampConsistency", "GeometryConsistency", "STATE_VERSION",
    # Phase 6.4
    "IndianRoadContextEngine", "IndianRoadContextConfig",
    "IndianRoadContextState",
    "ContextEngineStatus", "RoadType", "RoadWidthCategory", "RoadMarkingState",
    "IntersectionContext", "RoadDamageContext", "TrafficDensity",
    "VRUPresence", "AnimalActivity", "RoadComplexity", "ContextStability",
    "ContextFlag", "TrafficMixSummary", "RoadsideActivitySummary",
    "RoadDamageSummary", "EvidenceItem", "SensorStatusSummary",
]
