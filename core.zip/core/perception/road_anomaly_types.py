"""
IndiDrive AI — Phase 6.3 | Road Anomaly / Road Damage Understanding Data Contracts
====================================================================================
Structural containers for the road-anomaly understanding layer produced by
``road_anomaly.py``.  Companion to Phase 6.1 (road_understanding_types.py)
and Phase 6.2 (lane_structure_types.py) — same philosophy:

  * dataclasses, not raw dicts
  * explicit NOT_AVAILABLE / unknown states, never fabricated values
  * Indian-road-first: pothole/mud/gravel/debris/water-damage are first-class
  * separation of observation evidence from derived inference
  * deterministic severity / confidence — no random values, no ML training

Coordinate frame: vehicle frame (+X forward, +Y left, +Z up, origin at
rear-axle centre, metres) — identical to Phase 6.1 / 6.2 / COORDINATE_SYSTEMS.md.

Nothing here performs computation; these are structural containers and small
helpers only.  All public names are listed in ``__all__`` for controlled import.
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Optional

from .perception_types import NOT_AVAILABLE

__all__ = [
    "NOT_AVAILABLE",
    # Enums
    "AnomalyType",
    "AnomalySeverity",
    "AnomalyStatus",
    "AnomalyGeometryKind",
    "DepthKind",
    "VisibilityState",
    "DrivableAreaRelation",
    "LaneRelation",
    "CorridorRelation",
    "TemporalState",
    "RoadSurfaceQuality",
    "AnomalyEngineStatus",
    # Geometry containers
    "AnomalyPoint2D",
    "AnomalyPolygon",
    "AnomalyGeometry",
    # Per-anomaly output
    "RoadAnomalyObservation",
    # Top-level output
    "RoadAnomalyState",
]


# ---------------------------------------------------------------------------
# Enums
# ---------------------------------------------------------------------------

class AnomalyType(str, Enum):
    """Extensible taxonomy of road-surface anomalies relevant to Indian roads.

    Add new entries here; the rest of the pipeline uses AnomalyType so
    downstream code picks up new types without modification.
    """
    POTHOLE               = "POTHOLE"
    CRACK                 = "CRACK"
    DAMAGED_SURFACE       = "DAMAGED_SURFACE"
    GRAVEL                = "GRAVEL"
    LOOSE_MATERIAL        = "LOOSE_MATERIAL"
    MUD                   = "MUD"
    WATER_DAMAGE          = "WATER_DAMAGE"
    DEBRIS                = "DEBRIS"
    ROCK                  = "ROCK"
    CONSTRUCTION_MATERIAL = "CONSTRUCTION_MATERIAL"
    UNEVEN_SURFACE        = "UNEVEN_SURFACE"
    ROAD_EDGE_DAMAGE      = "ROAD_EDGE_DAMAGE"
    UNKNOWN               = "UNKNOWN"


class AnomalySeverity(str, Enum):
    """
    Estimated road-anomaly seriousness based on available geometric and
    sensor evidence.  NOT a vehicle-damage probability.

    Derived deterministically from size, depth, position, coverage and
    confidence — see RoadAnomalyEngine._estimate_severity().
    """
    NONE     = "NONE"
    LOW      = "LOW"
    MEDIUM   = "MEDIUM"
    HIGH     = "HIGH"
    CRITICAL = "CRITICAL"
    UNKNOWN  = "UNKNOWN"


class AnomalyStatus(str, Enum):
    """Pipeline-level status of a single anomaly record."""
    VALID        = "VALID"
    INVALID      = "INVALID"      # geometry / coordinate validation failed
    UNCERTAIN    = "UNCERTAIN"    # below minimum confidence threshold
    NOT_AVAILABLE = "NOT_AVAILABLE"


class AnomalyGeometryKind(str, Enum):
    """Shape model used to represent an anomaly's spatial extent."""
    POINT    = "POINT"      # single centre point; size unknown or irrelevant
    REGION   = "REGION"     # axis-aligned bounding region (length × width)
    POLYGON  = "POLYGON"    # arbitrary closed contour (e.g. from camera segmentation)
    LINE     = "LINE"       # crack: single segment (centre + orientation + length)
    POLYLINE = "POLYLINE"   # crack: multi-segment
    UNKNOWN  = "UNKNOWN"


class DepthKind(str, Enum):
    """Whether depth/depth_estimate is a real measurement or unavailable."""
    KNOWN     = "KNOWN"     # LiDAR-derived or stereo-camera height measurement
    ESTIMATED = "ESTIMATED" # heuristic estimate from type/size/context
    UNKNOWN   = "UNKNOWN"   # no depth information; depth_estimate_m must be None


class VisibilityState(str, Enum):
    """How well the anomaly surface can be directly observed by sensors."""
    CLEAR     = "CLEAR"     # directly visible; geometry is well-supported
    PARTIAL   = "PARTIAL"   # partially occluded; some geometry uncertain
    OBSCURED  = "OBSCURED"  # surface hidden (e.g. water-covered pothole)
    UNKNOWN   = "UNKNOWN"


class DrivableAreaRelation(str, Enum):
    """Geometric relationship between this anomaly and the Phase 6.1 drivable corridor."""
    OUTSIDE_DRIVABLE_AREA             = "OUTSIDE_DRIVABLE_AREA"
    PARTIALLY_OVERLAPPING_DRIVABLE_AREA = "PARTIALLY_OVERLAPPING_DRIVABLE_AREA"
    INSIDE_DRIVABLE_AREA              = "INSIDE_DRIVABLE_AREA"
    UNKNOWN                           = "UNKNOWN"


class LaneRelation(str, Enum):
    """Geometric relationship between this anomaly and the Phase 6.2 lane structure."""
    INSIDE_LANE          = "INSIDE_LANE"
    BETWEEN_LANES        = "BETWEEN_LANES"
    NEAR_LANE_BOUNDARY   = "NEAR_LANE_BOUNDARY"
    OUTSIDE_LANE_STRUCTURE = "OUTSIDE_LANE_STRUCTURE"
    UNKNOWN              = "UNKNOWN"


class CorridorRelation(str, Enum):
    """Whether the anomaly lies in the vehicle's currently understood travel corridor."""
    CLEAR_OF_CURRENT_CORRIDOR   = "CLEAR_OF_CURRENT_CORRIDOR"
    NEAR_CURRENT_CORRIDOR       = "NEAR_CURRENT_CORRIDOR"
    OVERLAPPING_CURRENT_CORRIDOR = "OVERLAPPING_CURRENT_CORRIDOR"
    UNKNOWN                     = "UNKNOWN"


class TemporalState(str, Enum):
    """Lifecycle state of an anomaly across successive frames."""
    NEW        = "NEW"        # first observation this session
    OBSERVED   = "OBSERVED"   # seen in at least 2 frames
    PERSISTENT = "PERSISTENT" # consistently observed beyond persistence threshold
    STALE      = "STALE"      # last seen > stale_timeout_s ago
    EXPIRED    = "EXPIRED"    # removed from active set (beyond max age)


class RoadSurfaceQuality(str, Enum):
    """Overall road-surface quality derived deterministically from the anomaly set.

    NOT a subjective human rating — derived from observed anomaly count,
    severity distribution and spatial extent.
    """
    GOOD            = "GOOD"
    MINOR_DAMAGE    = "MINOR_DAMAGE"
    DAMAGED         = "DAMAGED"
    SEVERELY_DAMAGED = "SEVERELY_DAMAGED"
    UNKNOWN         = "UNKNOWN"


class AnomalyEngineStatus(str, Enum):
    """Top-level status of the RoadAnomalyEngine for this cycle."""
    OK          = "OK"
    PARTIAL     = "PARTIAL"     # some inputs missing; operating in degraded mode
    DEGRADED    = "DEGRADED"    # below minimum useful confidence; output unreliable
    UNAVAILABLE = "UNAVAILABLE" # no usable sensor input this cycle
    INVALID     = "INVALID"     # input validation failure


# ---------------------------------------------------------------------------
# Geometry containers
# ---------------------------------------------------------------------------

@dataclass
class AnomalyPoint2D:
    """A single 2-D position in vehicle-frame metres (+X forward, +Y left)."""
    x: float    # forward
    y: float    # lateral (positive = left)

    def to_dict(self) -> dict:
        return {"x": round(self.x, 3), "y": round(self.y, 3)}


@dataclass
class AnomalyPolygon:
    """Closed contour as an ordered list of vehicle-frame points.

    Points are ordered counter-clockwise when viewed from above.
    Minimum 3 points for a valid polygon.
    """
    points: list = field(default_factory=list)   # list[AnomalyPoint2D]

    @property
    def is_valid(self) -> bool:
        return len(self.points) >= 3

    def to_dict(self) -> dict:
        return {"points": [p.to_dict() for p in self.points]}


@dataclass
class AnomalyGeometry:
    """
    Unified geometry container for a road anomaly.

    ``kind`` controls which fields are meaningful:

    POINT    — centre only; length/width/depth may be None
    REGION   — centre + length (longitudinal) + width (lateral); depth optional
    POLYGON  — contour; length/width derived from bounding box if needed
    LINE     — centre + orientation_rad + length; single-segment crack
    POLYLINE — polyline_points; multi-segment crack
    UNKNOWN  — no reliable geometry; all shape fields may be None
    """
    kind: AnomalyGeometryKind = AnomalyGeometryKind.UNKNOWN

    # Centre position in vehicle frame (always attempted even for LINE/POLYGON)
    center_x: Optional[float] = None    # forward (m)
    center_y: Optional[float] = None    # lateral (m)
    center_z: Optional[float] = None    # vertical (m); None if unavailable

    # Bounding extent (REGION / POLYGON)
    length_m: Optional[float] = None    # longitudinal extent (forward direction)
    width_m: Optional[float] = None     # lateral extent

    # Depth (POTHOLE / UNEVEN_SURFACE / surface depressions)
    depth_estimate_m: Optional[float] = None
    depth_kind: DepthKind = DepthKind.UNKNOWN

    # Orientation (LINE / CRACK; also reported for REGION when available)
    orientation_rad: Optional[float] = None   # angle from +X axis (vehicle frame)

    # Area derived from extent (convenience; always <= length*width)
    area_estimate_m2: Optional[float] = None

    # Polygon contour (POLYGON / POLYLINE kinds)
    contour: Optional[AnomalyPolygon] = None

    # Longitudinal / lateral reach for corridor-overlap logic
    longitudinal_reach_m: Optional[float] = None  # max X extent from center
    lateral_reach_m: Optional[float] = None        # max |Y| extent from center

    @property
    def has_center(self) -> bool:
        return self.center_x is not None and self.center_y is not None

    @property
    def has_extent(self) -> bool:
        return self.length_m is not None and self.width_m is not None

    def to_dict(self) -> dict:
        return {
            "kind": self.kind.value,
            "center_x": round(self.center_x, 3) if self.center_x is not None else NOT_AVAILABLE,
            "center_y": round(self.center_y, 3) if self.center_y is not None else NOT_AVAILABLE,
            "center_z": round(self.center_z, 3) if self.center_z is not None else NOT_AVAILABLE,
            "length_m": round(self.length_m, 3) if self.length_m is not None else NOT_AVAILABLE,
            "width_m": round(self.width_m, 3) if self.width_m is not None else NOT_AVAILABLE,
            "depth_estimate_m": round(self.depth_estimate_m, 3) if self.depth_estimate_m is not None else NOT_AVAILABLE,
            "depth_kind": self.depth_kind.value,
            "orientation_rad": round(self.orientation_rad, 4) if self.orientation_rad is not None else NOT_AVAILABLE,
            "area_estimate_m2": round(self.area_estimate_m2, 4) if self.area_estimate_m2 is not None else NOT_AVAILABLE,
            "contour": self.contour.to_dict() if self.contour is not None else NOT_AVAILABLE,
            "longitudinal_reach_m": round(self.longitudinal_reach_m, 3) if self.longitudinal_reach_m is not None else NOT_AVAILABLE,
            "lateral_reach_m": round(self.lateral_reach_m, 3) if self.lateral_reach_m is not None else NOT_AVAILABLE,
        }


# ---------------------------------------------------------------------------
# Per-anomaly output container
# ---------------------------------------------------------------------------

@dataclass
class RoadAnomalyObservation:
    """
    Fully structured representation of a single detected road anomaly.

    Consumers read this structure.  No field is fabricated: fields that
    cannot be determined from available sensor evidence use explicit
    NOT_AVAILABLE / UNKNOWN states rather than invented values.

    Field groups
    ------------
    Identity        — anomaly_id, anomaly_type, timestamp, status
    Position        — geometry (vehicle-frame), distance_m, longitudinal_m,
                      lateral_m
    Severity/Conf   — severity, confidence, uncertainty
    Source          — source (sensor string), observation_count,
                      first_seen_timestamp, last_seen_timestamp,
                      persistence_s, temporal_state
    Visibility      — visibility_state, visibility_score
    Relationships   — drivable_area_relation, affects_drivable_area,
                      lane_relation, affects_lane_area,
                      corridor_relation, affects_vehicle_path
    Road context    — road_edge_proximity (near road edge if relevant)
    Debug           — warnings, metadata
    """
    # --- Identity ----------------------------------------------------------
    anomaly_id: str = ""
    anomaly_type: AnomalyType = AnomalyType.UNKNOWN
    timestamp: float = 0.0
    status: AnomalyStatus = AnomalyStatus.NOT_AVAILABLE

    # --- Geometry ----------------------------------------------------------
    geometry: AnomalyGeometry = field(default_factory=AnomalyGeometry)

    # Convenience derived from geometry.center_x / center_y
    distance_m: Optional[float] = None         # Euclidean distance from vehicle origin
    longitudinal_m: Optional[float] = None     # geometry.center_x (forward reach)
    lateral_m: Optional[float] = None          # geometry.center_y (lateral offset)

    # --- Severity / Confidence / Uncertainty -------------------------------
    severity: AnomalySeverity = AnomalySeverity.UNKNOWN

    # confidence in [0, 1]: how well the anomaly is understood
    confidence: float = 0.0

    # uncertainty: separate from (1 - confidence); reflects incomplete geometry,
    # occlusion, water coverage, sensor degradation
    uncertainty: float = 1.0

    # Per-component uncertainty flags (True = uncertain)
    position_uncertain: bool = False
    geometry_uncertain: bool = False
    classification_uncertain: bool = False
    severity_uncertain: bool = False

    # --- Source / provenance -----------------------------------------------
    source: str = NOT_AVAILABLE     # camera | lidar | radar | fused | unknown

    # --- Temporal consistency ----------------------------------------------
    observation_count: int = 1
    first_seen_timestamp: float = 0.0
    last_seen_timestamp: float = 0.0
    persistence_s: float = 0.0           # last_seen - first_seen
    temporal_state: TemporalState = TemporalState.NEW
    temporal_consistency: float = 0.0    # 0 (flickering) .. 1 (rock-solid)

    # --- Visibility --------------------------------------------------------
    visibility_state: VisibilityState = VisibilityState.UNKNOWN
    visibility_score: float = 1.0        # 0 = hidden, 1 = fully visible

    # --- Spatial relationships (read-only consumers from Phase 6.1 / 6.2) --
    drivable_area_relation: DrivableAreaRelation = DrivableAreaRelation.UNKNOWN
    affects_drivable_area: bool = False

    lane_relation: LaneRelation = LaneRelation.UNKNOWN
    affects_lane_area: bool = False

    corridor_relation: CorridorRelation = CorridorRelation.UNKNOWN
    affects_vehicle_path: bool = False

    # --- Road-edge proximity -----------------------------------------------
    near_road_edge: bool = False        # anomaly close to Phase 6.1 road boundary
    road_edge_side: str = NOT_AVAILABLE # "left" | "right" | NOT_AVAILABLE

    # --- Debug / metadata --------------------------------------------------
    warnings: list = field(default_factory=list)   # list[str]
    metadata: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        return {
            "anomaly_id": self.anomaly_id,
            "anomaly_type": self.anomaly_type.value,
            "timestamp": self.timestamp,
            "status": self.status.value,
            "geometry": self.geometry.to_dict(),
            "distance_m": round(self.distance_m, 3) if self.distance_m is not None else NOT_AVAILABLE,
            "longitudinal_m": round(self.longitudinal_m, 3) if self.longitudinal_m is not None else NOT_AVAILABLE,
            "lateral_m": round(self.lateral_m, 3) if self.lateral_m is not None else NOT_AVAILABLE,
            "severity": self.severity.value,
            "confidence": round(self.confidence, 3),
            "uncertainty": round(self.uncertainty, 3),
            "position_uncertain": self.position_uncertain,
            "geometry_uncertain": self.geometry_uncertain,
            "classification_uncertain": self.classification_uncertain,
            "severity_uncertain": self.severity_uncertain,
            "source": self.source,
            "observation_count": self.observation_count,
            "first_seen_timestamp": self.first_seen_timestamp,
            "last_seen_timestamp": self.last_seen_timestamp,
            "persistence_s": round(self.persistence_s, 3),
            "temporal_state": self.temporal_state.value,
            "temporal_consistency": round(self.temporal_consistency, 3),
            "visibility_state": self.visibility_state.value,
            "visibility_score": round(self.visibility_score, 3),
            "drivable_area_relation": self.drivable_area_relation.value,
            "affects_drivable_area": self.affects_drivable_area,
            "lane_relation": self.lane_relation.value,
            "affects_lane_area": self.affects_lane_area,
            "corridor_relation": self.corridor_relation.value,
            "affects_vehicle_path": self.affects_vehicle_path,
            "near_road_edge": self.near_road_edge,
            "road_edge_side": self.road_edge_side,
            "warnings": self.warnings,
            "metadata": self.metadata,
        }


# ---------------------------------------------------------------------------
# Top-level Phase 6.3 output
# ---------------------------------------------------------------------------

@dataclass
class RoadAnomalyState:
    """
    Phase 6.3 primary output.  One RoadAnomalyState is produced per
    RoadAnomalyEngine.process() call.

    Consumers (world model, reasoning brain, adaptive path planner) read
    this structure.  This module never calls into those consumers.

    Key fields
    ----------
    anomalies           — ordered list of RoadAnomalyObservation, closest first.
    road_surface_quality — deterministic aggregate quality rating.
    overall_confidence  — aggregate confidence across all anomalies this cycle.
    overall_uncertainty — aggregate uncertainty.
    sensor_status       — dict mapping sensor name → status string.
    degraded            — True if any input sensor is unavailable.
    source_summary      — human-readable provenance string.
    stats               — lightweight observability counters (no hot-path logging).
    """
    timestamp: float
    frame_id: int
    status: AnomalyEngineStatus = AnomalyEngineStatus.UNAVAILABLE

    anomalies: list = field(default_factory=list)   # list[RoadAnomalyObservation]

    road_surface_quality: RoadSurfaceQuality = RoadSurfaceQuality.UNKNOWN

    overall_confidence: float = 0.0
    overall_uncertainty: float = 1.0

    # Sensor provenance
    sensor_status: dict = field(default_factory=dict)  # {"camera": "OK" | "UNAVAILABLE", ...}
    degraded: bool = False
    source_summary: str = NOT_AVAILABLE

    # Lightweight stats for observability / debugging
    stats: dict = field(default_factory=dict)
    warnings: list = field(default_factory=list)   # list[str]
    created_at: float = field(default_factory=time.time)

    def to_dict(self) -> dict:
        return {
            "timestamp": self.timestamp,
            "frame_id": self.frame_id,
            "status": self.status.value,
            "road_surface_quality": self.road_surface_quality.value,
            "overall_confidence": round(self.overall_confidence, 3),
            "overall_uncertainty": round(self.overall_uncertainty, 3),
            "sensor_status": self.sensor_status,
            "degraded": self.degraded,
            "source_summary": self.source_summary,
            "anomaly_count": len(self.anomalies),
            "anomalies": [a.to_dict() for a in self.anomalies],
            "stats": self.stats,
            "warnings": self.warnings,
        }
