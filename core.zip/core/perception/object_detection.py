"""
IndiDrive AI — Phase 2 | Object Detection Backend Abstraction
=================================================================
The perception layer must not be hard-coded around one AI model. This
module defines the `ObjectDetector` interface and a small set of
backends selected via configuration (perception.camera.backend /
MODEL_BACKEND env var):

    AUTO     — try YOLO (ultralytics) if a weights file is registered
               and installed, else OpenCV-DNN if a .onnx/.weights file
               is configured, else NONE.
    YOLO     — ultralytics YOLO models (.pt or exported .onnx)
    ONNX     — generic OpenCV-DNN ONNX inference (no ultralytics dependency)
    OPENCV_DNN — alias of ONNX, kept for the name used in the spec
    CUSTOM   — reserved hook for a project-specific backend registered
               at runtime (see `register_custom_backend`)
    NONE     — no model configured; detect() always returns an empty
               list with backend=NOT_CONFIGURED (never fabricated boxes)
    MOCK     — deterministic synthetic backend, ONLY for automated
               tests (see tests/perception/). Never selected by AUTO.

If no trained model file is present (which is the default state of
this repository — no weights are bundled), the backend resolves to
NONE and every consumer must report NOT_CONFIGURED / MODEL_NOT_FOUND
rather than pretending a model ran.
"""
from __future__ import annotations

import time
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

import numpy as np

from .confidence import RawDetection
from .perception_types import BoundingBox2D, BackendKind

ROOT = Path(__file__).resolve().parents[2]


class ModelNotFoundError(RuntimeError):
    """Raised by a backend's load_model() when a required weights file
    is missing. Callers (camera_perception.py) catch this and report
    MODEL_NOT_FOUND rather than crashing the perception pipeline."""


@dataclass
class ModelInfo:
    backend_name: str
    backend_kind: BackendKind
    model_path: Optional[str] = None
    class_names: list[str] = field(default_factory=list)
    input_size: Optional[tuple[int, int]] = None
    load_time_ms: Optional[float] = None
    ready: bool = False
    note: str = ""

    def to_dict(self) -> dict:
        return {
            "backend_name": self.backend_name,
            "backend_kind": self.backend_kind.value,
            "model_path": self.model_path,
            "class_names": self.class_names,
            "input_size": list(self.input_size) if self.input_size else None,
            "load_time_ms": self.load_time_ms,
            "ready": self.ready,
            "note": self.note,
        }


class ObjectDetector(ABC):
    """Interface every detection backend implements."""

    @abstractmethod
    def load_model(self) -> None:
        ...

    @abstractmethod
    def detect(self, image: np.ndarray) -> list[RawDetection]:
        ...

    @abstractmethod
    def get_class_names(self) -> list[str]:
        ...

    @abstractmethod
    def get_model_info(self) -> ModelInfo:
        ...

    @abstractmethod
    def is_ready(self) -> bool:
        ...


class NoneBackend(ObjectDetector):
    """The honest default: no model configured. Always returns an
    empty detection list; never invents boxes."""

    def __init__(self, reason: str = "no model configured"):
        self._reason = reason
        self._info = ModelInfo(
            backend_name="NONE", backend_kind=BackendKind.NOT_CONFIGURED,
            ready=False, note=reason,
        )

    def load_model(self) -> None:
        pass  # nothing to load

    def detect(self, image: np.ndarray) -> list[RawDetection]:
        return []

    def get_class_names(self) -> list[str]:
        return []

    def get_model_info(self) -> ModelInfo:
        return self._info

    def is_ready(self) -> bool:
        return False


class MockBackend(ObjectDetector):
    """Deterministic synthetic backend for automated tests ONLY.
    Produces a fixed, seeded set of boxes so tests are reproducible.
    Always labeled backend=MOCK; never returned by resolve_backend()
    in AUTO mode — a caller must explicitly ask for MOCK (e.g. from a
    test fixture) to get this."""

    _COCO_LIKE_CLASSES = ["car", "person", "motorbike", "bus", "truck", "cow"]

    def __init__(self, n_detections: int = 2, seed: int = 42):
        self._n = n_detections
        self._rng = np.random.default_rng(seed)
        self._ready = False
        self._info = ModelInfo(
            backend_name="MOCK", backend_kind=BackendKind.MOCK,
            class_names=list(self._COCO_LIKE_CLASSES), ready=False,
            note="deterministic synthetic backend — automated tests only, never real inference",
        )

    def load_model(self) -> None:
        t0 = time.perf_counter()
        self._ready = True
        self._info.ready = True
        self._info.load_time_ms = (time.perf_counter() - t0) * 1000.0

    def detect(self, image: np.ndarray) -> list[RawDetection]:
        if not self._ready:
            raise RuntimeError("MockBackend.detect() called before load_model()")
        h, w = image.shape[:2]
        detections = []
        for i in range(self._n):
            bw, bh = w * 0.15, h * 0.25
            x = (w * 0.1) + i * (w * 0.3)
            y = h * 0.4
            cls = self._COCO_LIKE_CLASSES[i % len(self._COCO_LIKE_CLASSES)]
            conf = float(0.55 + 0.1 * self._rng.random())
            detections.append(RawDetection(raw_class=cls, raw_confidence=conf,
                                            bbox=BoundingBox2D(x=x, y=y, width=bw, height=bh)))
        return detections

    def get_class_names(self) -> list[str]:
        return list(self._COCO_LIKE_CLASSES)

    def get_model_info(self) -> ModelInfo:
        return self._info

    def is_ready(self) -> bool:
        return self._ready


class UltralyticsYOLOBackend(ObjectDetector):
    """Real inference via the `ultralytics` package (already an optional
    dependency in requirements.txt, and the model core.models.manager
    registers under role='detector'). Only becomes ready if both the
    package and a weights file are actually available — no fallback
    faking here."""

    def __init__(self, weights_path: str, confidence_threshold: float = 0.25):
        self._weights_path = weights_path
        self._confidence_threshold = confidence_threshold
        self._model = None
        self._ready = False
        self._info = ModelInfo(
            backend_name="YOLO", backend_kind=BackendKind.REAL,
            model_path=weights_path, ready=False,
        )

    def load_model(self) -> None:
        if not Path(self._weights_path).exists():
            raise ModelNotFoundError(f"YOLO weights not found: {self._weights_path}")
        try:
            from ultralytics import YOLO  # type: ignore
        except ImportError as e:
            raise ModelNotFoundError(
                "ultralytics package not installed (pip install ultralytics --break-system-packages)"
            ) from e
        t0 = time.perf_counter()
        self._model = YOLO(self._weights_path)
        self._ready = True
        self._info.load_time_ms = (time.perf_counter() - t0) * 1000.0
        self._info.ready = True
        try:
            self._info.class_names = list(self._model.names.values())
        except Exception:
            self._info.class_names = []

    def detect(self, image: np.ndarray) -> list[RawDetection]:
        if not self._ready or self._model is None:
            raise RuntimeError("UltralyticsYOLOBackend.detect() called before load_model()")
        results = self._model.predict(image, conf=self._confidence_threshold, verbose=False)
        detections: list[RawDetection] = []
        for r in results:
            boxes = getattr(r, "boxes", None)
            if boxes is None:
                continue
            for box in boxes:
                xyxy = box.xyxy[0].tolist()
                conf = float(box.conf[0])
                cls_id = int(box.cls[0])
                raw_class = self._model.names.get(cls_id, str(cls_id))
                x0, y0, x1, y1 = xyxy
                detections.append(RawDetection(
                    raw_class=str(raw_class), raw_confidence=conf,
                    bbox=BoundingBox2D(x=x0, y=y0, width=x1 - x0, height=y1 - y0),
                ))
        return detections

    def get_class_names(self) -> list[str]:
        return self._info.class_names

    def get_model_info(self) -> ModelInfo:
        return self._info

    def is_ready(self) -> bool:
        return self._ready


class OpenCVDNNBackend(ObjectDetector):
    """Real inference via cv2.dnn, for ONNX/Darknet models without
    requiring the ultralytics dependency. Requires the caller to supply
    the exact input size and class names the model was exported with —
    Phase 2 does not guess these."""

    def __init__(self, model_path: str, class_names: list[str],
                 input_size: tuple[int, int] = (640, 640), confidence_threshold: float = 0.25):
        self._model_path = model_path
        self._class_names = class_names
        self._input_size = input_size
        self._confidence_threshold = confidence_threshold
        self._net = None
        self._ready = False
        self._info = ModelInfo(
            backend_name="ONNX", backend_kind=BackendKind.REAL,
            model_path=model_path, class_names=class_names, input_size=input_size, ready=False,
        )

    def load_model(self) -> None:
        if not Path(self._model_path).exists():
            raise ModelNotFoundError(f"ONNX/DNN model not found: {self._model_path}")
        try:
            import cv2  # type: ignore
        except ImportError as e:
            raise ModelNotFoundError("opencv-python not installed") from e
        t0 = time.perf_counter()
        self._net = cv2.dnn.readNet(self._model_path)
        self._ready = True
        self._info.load_time_ms = (time.perf_counter() - t0) * 1000.0
        self._info.ready = True

    def detect(self, image: np.ndarray) -> list[RawDetection]:
        if not self._ready or self._net is None:
            raise RuntimeError("OpenCVDNNBackend.detect() called before load_model()")
        import cv2  # type: ignore
        blob = cv2.dnn.blobFromImage(image, scalefactor=1 / 255.0, size=self._input_size, swapRB=True, crop=False)
        self._net.setInput(blob)
        outputs = self._net.forward()

        detections: list[RawDetection] = []
        h, w = image.shape[:2]
        # Generic handling for a [N, 85]-style YOLO-ONNX output
        # (cx, cy, bw, bh, obj_conf, class_scores...). Custom exports
        # with a different layout should subclass this backend.
        rows = outputs.reshape(-1, outputs.shape[-1]) if outputs.ndim > 2 else outputs
        for row in rows:
            if len(row) < 6:
                continue
            obj_conf = float(row[4])
            class_scores = row[5:]
            cls_id = int(np.argmax(class_scores))
            conf = obj_conf * float(class_scores[cls_id])
            if conf < self._confidence_threshold:
                continue
            cx, cy, bw, bh = row[0], row[1], row[2], row[3]
            x0, y0 = (cx - bw / 2) * (w / self._input_size[0]), (cy - bh / 2) * (h / self._input_size[1])
            raw_class = self._class_names[cls_id] if cls_id < len(self._class_names) else str(cls_id)
            detections.append(RawDetection(
                raw_class=raw_class, raw_confidence=conf,
                bbox=BoundingBox2D(x=x0, y=y0, width=bw * (w / self._input_size[0]), height=bh * (h / self._input_size[1])),
            ))
        return detections

    def get_class_names(self) -> list[str]:
        return self._class_names

    def get_model_info(self) -> ModelInfo:
        return self._info

    def is_ready(self) -> bool:
        return self._ready


_CUSTOM_BACKEND_FACTORY = None


def register_custom_backend(factory) -> None:
    """Allows a downstream project to register a CUSTOM backend factory:
    `factory(config: dict) -> ObjectDetector`. Not populated by default."""
    global _CUSTOM_BACKEND_FACTORY
    _CUSTOM_BACKEND_FACTORY = factory


def _active_yolo_weights_path() -> Optional[str]:
    """Looks up the active 'detector' role model from core.models.manager,
    if the registry has a weights_path recorded. Returns None (not a
    guessed path) if nothing usable is registered."""
    try:
        from core.models.manager import ModelManager
        mgr = ModelManager()
        data = mgr.list_models()
        active_id = data.get("active", {}).get("detector")
        if not active_id:
            return None
        model = next((m for m in data["models"] if m["model_id"] == active_id), None)
        if model and model.get("weights_path") and Path(model["weights_path"]).exists():
            return model["weights_path"]
    except Exception:
        pass
    return None


def resolve_backend(backend_name: str, config: Optional[dict] = None) -> ObjectDetector:
    """Selects and constructs (but does not load) a backend by name.
    `backend_name` follows perception.camera.backend / MODEL_BACKEND:
    AUTO | YOLO | ONNX | OPENCV_DNN | CUSTOM | NONE.
    """
    config = config or {}
    name = (backend_name or "NONE").strip().upper()

    if name == "NONE":
        return NoneBackend(reason="backend explicitly set to NONE")

    if name == "CUSTOM":
        if _CUSTOM_BACKEND_FACTORY is None:
            return NoneBackend(reason="backend=CUSTOM but no custom backend registered "
                                       "(call object_detection.register_custom_backend())")
        return _CUSTOM_BACKEND_FACTORY(config)

    if name == "YOLO":
        weights = config.get("weights_path") or _active_yolo_weights_path()
        if not weights:
            return NoneBackend(reason="backend=YOLO but no weights_path configured or registered")
        return UltralyticsYOLOBackend(weights, confidence_threshold=config.get("confidence_threshold", 0.25))

    if name in ("ONNX", "OPENCV_DNN"):
        weights = config.get("weights_path")
        class_names = config.get("class_names") or []
        if not weights or not class_names:
            return NoneBackend(reason="backend=ONNX but weights_path/class_names not configured")
        input_size = tuple(config.get("input_size", (640, 640)))
        return OpenCVDNNBackend(weights, class_names, input_size=input_size,
                                 confidence_threshold=config.get("confidence_threshold", 0.25))

    if name == "AUTO":
        weights = config.get("weights_path") or _active_yolo_weights_path()
        if weights:
            try:
                import ultralytics  # noqa: F401
                return UltralyticsYOLOBackend(weights, confidence_threshold=config.get("confidence_threshold", 0.25))
            except ImportError:
                pass
        onnx_path = config.get("onnx_path")
        if onnx_path and config.get("class_names"):
            return OpenCVDNNBackend(onnx_path, config["class_names"],
                                     input_size=tuple(config.get("input_size", (640, 640))))
        return NoneBackend(reason="AUTO: no usable model weights found — camera detection is NOT_CONFIGURED")

    return NoneBackend(reason=f"unknown backend '{backend_name}'")
