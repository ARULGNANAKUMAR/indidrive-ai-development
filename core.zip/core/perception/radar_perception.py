"""
IndiDrive AI — Phase 2 | Radar Perception Interface
=======================================================
Radar is optional and, per the Phase 1 sensor config
(config/sensor_config.yaml: radar.enabled=false, status="unavailable"),
no radar module exists anywhere in this codebase. This file defines
the interface future radar support would implement, and a pipeline
that always reports NOT_AVAILABLE honestly rather than fabricating
radar detections.
"""
from __future__ import annotations

from dataclasses import dataclass, field

from .perception_types import ProcessingMetrics, PerceptionObject, BackendKind


@dataclass
class RadarPerceptionResult:
    objects: list[PerceptionObject] = field(default_factory=list)
    metrics: ProcessingMetrics = field(default_factory=ProcessingMetrics)
    status: str = "NOT_AVAILABLE"
    warnings: list[str] = field(default_factory=lambda: [
        "radar hardware/driver not present in this project — see config/sensor_config.yaml"
    ])


class RadarPerceptionPipeline:
    """Always-NOT_AVAILABLE pipeline. Kept as a real class (not a stub
    function) so PerceptionManager can call it uniformly with
    camera/LiDAR pipelines and so a future radar implementation has an
    exact interface to fill in."""

    def is_available(self) -> bool:
        return False

    def process(self, radar_frame, timestamp: float) -> RadarPerceptionResult:
        return RadarPerceptionResult()

    def backend_kind(self) -> BackendKind:
        return BackendKind.NOT_AVAILABLE
