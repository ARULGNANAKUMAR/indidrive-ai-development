"""
IndiDrive AI — Phase 2 | Perception Engine
==============================================
Combines one cycle's camera + LiDAR (+ road + anomaly) results into a
single PerceptionFrame. Contains NO sensor acquisition and NO planning
logic — purely the per-cycle fusion-of-outputs step (real sensor
fusion, e.g. Kalman-filter-based, is explicitly out of scope; this is
just assembling the shared output contract from whichever sensors
produced results this cycle).

Object IDs are NOT tightly coupled to a single sensor's numbering
scheme (each is a fresh uuid-based id, tagged with source_sensor) so
Phase 3 fusion can later associate/merge objects across sensors
without an ID collision.
"""
from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Optional

import numpy as np

from .camera_perception import CameraPerceptionPipeline, CameraPerceptionResult
from .lidar_perception import LiDARPerceptionPipeline, LiDARPerceptionResult
from .radar_perception import RadarPerceptionPipeline, RadarPerceptionResult
from .road_perception import RoadPerceptionPipeline, RoadPerceptionResult
from .anomaly_detection import RoadAnomalyDetector, AnomalyDetectionResult
from .perception_health import PerceptionHealthMonitor
from .postprocessing import summarize_quality, merge_warnings
from .perception_types import (
    PerceptionFrame, ProcessingMetrics, HealthState, RoadState, DrivableArea,
)


@dataclass
class EngineConfig:
    camera_backend: str = "NONE"
    camera_backend_config: Optional[dict] = None
    confidence_threshold: float = 0.40
    nms_threshold: float = 0.45
    road_backend: str = "CLASSICAL"
    road_enabled: bool = True
    anomaly_backend: str = "NOT_CONFIGURED"
    anomaly_enabled: bool = True


class PerceptionEngine:
    """Owns one instance each of the per-sensor pipelines and produces a
    PerceptionFrame per call to `process()`. PerceptionManager owns the
    lifecycle (init/shutdown) and feeds this from SensorManager buffers;
    this class only knows how to turn frames into a PerceptionFrame."""

    def __init__(self, config: Optional[EngineConfig] = None):
        self.config = config or EngineConfig()
        self.camera = CameraPerceptionPipeline(
            backend=self.config.camera_backend,
            backend_config=self.config.camera_backend_config,
            confidence_threshold=self.config.confidence_threshold,
            nms_threshold=self.config.nms_threshold,
        )
        self.lidar = LiDARPerceptionPipeline()
        self.radar = RadarPerceptionPipeline()
        self.road = RoadPerceptionPipeline(backend=self.config.road_backend if self.config.road_enabled else "NONE")
        self.anomaly = RoadAnomalyDetector(backend=self.config.anomaly_backend if self.config.anomaly_enabled else "NOT_CONFIGURED")
        self.health = PerceptionHealthMonitor()
        self._frame_counter = 0

    def process(
        self,
        camera_image: Optional[np.ndarray] = None,
        camera_timestamp: Optional[float] = None,
        lidar_points: Optional[np.ndarray] = None,
        lidar_timestamp: Optional[float] = None,
        sensor_status: Optional[dict] = None,
    ) -> PerceptionFrame:
        t_start = time.perf_counter()
        now = time.time()
        self._frame_counter += 1
        warnings: list[str] = []
        objects = []

        # ---- camera ----
        cam_result: Optional[CameraPerceptionResult] = None
        if camera_image is not None:
            cam_result = self.camera.process(camera_image, camera_timestamp or now)
            objects.extend(cam_result.objects)
            warnings = merge_warnings(warnings, cam_result.warnings)
            if cam_result.status == "OK":
                self.health.record_success("camera", cam_result.metrics.total_perception_latency_ms, len(cam_result.objects))
            elif cam_result.status == "MODEL_NOT_FOUND":
                self.health.mark_not_configured("camera")
            elif cam_result.status == "INVALID_FRAME":
                self.health.record_dropped("camera")
            else:
                self.health.record_failure("camera", cam_result.status)
        else:
            self.health.mark_not_configured("camera")

        # ---- lidar ----
        lidar_result: Optional[LiDARPerceptionResult] = None
        if lidar_points is not None:
            lidar_result = self.lidar.process(lidar_points, lidar_timestamp or now)
            objects.extend(lidar_result.objects)
            warnings = merge_warnings(warnings, lidar_result.warnings)
            if lidar_result.status == "OK":
                self.health.record_success("lidar", lidar_result.metrics.total_perception_latency_ms, len(lidar_result.objects))
            elif lidar_result.status == "EMPTY_POINT_CLOUD":
                self.health.record_dropped("lidar")
            else:
                self.health.record_failure("lidar", lidar_result.status)
        else:
            self.health.mark_not_configured("lidar")

        # ---- radar (always NOT_AVAILABLE unless a future implementation exists) ----
        self.health.mark_not_available("radar")

        # ---- road / drivable area ----
        road_result: RoadPerceptionResult = self.road.process(camera_image)
        warnings = merge_warnings(warnings, road_result.warnings)
        if road_result.status == "OK":
            self.health.record_success("road", road_result.latency_ms, 0)
        else:
            self.health.mark_not_configured("road")

        # ---- road anomalies ----
        anomaly_result: AnomalyDetectionResult = self.anomaly.process(camera_image, camera_timestamp or now)
        warnings = merge_warnings(warnings, anomaly_result.warnings)
        if anomaly_result.status == "REAL":
            self.health.record_success("anomaly", anomaly_result.latency_ms, len(anomaly_result.anomalies))
        else:
            self.health.mark_not_configured("anomaly")

        # ---- assemble ----
        total_latency_ms = (time.perf_counter() - t_start) * 1000.0
        metrics = ProcessingMetrics(
            preprocessing_latency_ms=(cam_result.metrics.preprocessing_latency_ms if cam_result else 0.0)
                                       + (lidar_result.metrics.preprocessing_latency_ms if lidar_result else 0.0),
            inference_latency_ms=(cam_result.metrics.inference_latency_ms if cam_result else 0.0)
                                   + (lidar_result.metrics.inference_latency_ms if lidar_result else 0.0),
            postprocessing_latency_ms=(cam_result.metrics.postprocessing_latency_ms if cam_result else 0.0)
                                        + (lidar_result.metrics.postprocessing_latency_ms if lidar_result else 0.0),
            total_perception_latency_ms=total_latency_ms,
            input_fps=max(cam_result.metrics.input_fps if cam_result else 0.0,
                          lidar_result.metrics.input_fps if lidar_result else 0.0),
            processing_fps=(1000.0 / total_latency_ms) if total_latency_ms > 0 else 0.0,
            dropped_frames=0,
        )

        any_success = bool((cam_result and cam_result.status == "OK") or (lidar_result and lidar_result.status == "OK"))
        overall_health = HealthState.HEALTHY if any_success else (
            HealthState.NOT_CONFIGURED if camera_image is None and lidar_points is None else HealthState.DEGRADED
        )
        quality = summarize_quality(
            objects,
            frame_valid=any_success or (cam_result is None and lidar_result is None),
            model_ready=self.camera.backend_kind.value not in ("NOT_CONFIGURED",),
            inference_success=any_success,
            health=overall_health,
        )

        frame = PerceptionFrame(
            timestamp=now,
            frame_id=self._frame_counter,
            objects=objects,
            road_state=road_result.road_state,
            drivable_area=road_result.drivable_area,
            road_anomalies=anomaly_result.anomalies,
            sensor_status=sensor_status or {},
            processing_metrics=metrics,
            quality=quality,
            warnings=warnings,
        )
        return frame

    def get_health(self) -> dict:
        return self.health.report()

    def get_model_status(self) -> dict:
        return {
            "camera": self.camera.model_status(),
            "lidar": {"backend_kind": "BASELINE", "note": "geometry-based clustering, no trained model"},
            "radar": {"backend_kind": "NOT_AVAILABLE", "note": "no radar hardware/driver in this project"},
            "road": {"backend": self.road.backend},
            "anomaly": {"backend": self.anomaly.backend},
        }
