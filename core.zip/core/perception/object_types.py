"""
IndiDrive AI — Phase 2 | Object Class Taxonomy
==================================================
A single normalized set of Indian-road-relevant object classes, plus a
mapping table from model-specific class names (COCO/YOLO names, custom
model names, etc.) into that normalized taxonomy.

Design note: the class list is configuration-driven (see
config/perception_config.yaml -> perception.classes), not hard-coded
into every consumer. This module provides the DEFAULT list and mapping;
PerceptionManager loads whatever the active config specifies and falls
back to these defaults if the config is silent.

Not every model backend needs to support every class — unmapped raw
classes pass through unchanged with a warning, rather than being
dropped silently (see `normalize_class`).
"""
from __future__ import annotations

# The normalized taxonomy Phase 2 tracks internally.
INDIAN_ROAD_CLASSES: tuple[str, ...] = (
    "car",
    "bus",
    "truck",
    "motorcycle",
    "scooter",
    "auto_rickshaw",
    "bicycle",
    "pedestrian",
    "cattle",
    "animal",
    "tractor",
    "rickshaw",
    "pushcart",
    "road_obstacle",
    "debris",
    "traffic_cone",
    "barrier",
    "unknown",
)

# raw model class name (lowercase) -> normalized class.
# Covers common COCO names (as produced by YOLO/ultralytics/OpenCV-DNN
# COCO-pretrained backbones) plus a handful of Indian-road-specific
# synonyms a custom model might emit.
_DEFAULT_CLASS_MAP: dict[str, str] = {
    # COCO vehicle classes
    "car": "car",
    "motorbike": "motorcycle",
    "motorcycle": "motorcycle",
    "bus": "bus",
    "truck": "truck",
    "bicycle": "bicycle",
    "person": "pedestrian",
    "pedestrian": "pedestrian",
    # COCO animal classes that show up on Indian roads
    "cow": "cattle",
    "cattle": "cattle",
    "horse": "animal",
    "dog": "animal",
    "sheep": "animal",
    "elephant": "animal",
    "goat": "animal",
    "animal": "animal",
    # Indian-road-specific synonyms a custom/fine-tuned model may emit
    "autorickshaw": "auto_rickshaw",
    "auto_rickshaw": "auto_rickshaw",
    "auto-rickshaw": "auto_rickshaw",
    "tuk_tuk": "auto_rickshaw",
    "scooter": "scooter",
    "moped": "scooter",
    "tractor": "tractor",
    "rickshaw": "rickshaw",
    "cycle_rickshaw": "rickshaw",
    "pushcart": "pushcart",
    "cart": "pushcart",
    "handcart": "pushcart",
    "traffic cone": "traffic_cone",
    "traffic_cone": "traffic_cone",
    "cone": "traffic_cone",
    "barrier": "barrier",
    "road barrier": "barrier",
    "debris": "debris",
    "obstacle": "road_obstacle",
    "road_obstacle": "road_obstacle",
}


def normalize_class(raw_class: str, class_map: dict[str, str] | None = None) -> str:
    """Map a raw, model-reported class name into the normalized taxonomy.
    Unknown classes map to 'unknown' rather than being dropped, so a
    detection is never silently discarded just because its class name
    isn't recognized."""
    mapping = class_map if class_map is not None else _DEFAULT_CLASS_MAP
    key = (raw_class or "").strip().lower()
    return mapping.get(key, "unknown")


def default_class_map() -> dict[str, str]:
    return dict(_DEFAULT_CLASS_MAP)


def supported_classes() -> tuple[str, ...]:
    return INDIAN_ROAD_CLASSES
