"""
IndiDrive AI — Phase 2 | Frame-Level Postprocessing
=======================================================
Small helpers that operate on an already-assembled set of
PerceptionObjects / metrics for a frame — as opposed to confidence.py
(per-detection filtering/NMS) and preprocessing.py (per-image
transforms). Used by perception_engine.py to build the final
PerceptionQuality summary for a PerceptionFrame.
"""
from __future__ import annotations

from .perception_types import PerceptionObject, PerceptionQuality, HealthState


def summarize_quality(
    objects: list[PerceptionObject],
    frame_valid: bool,
    model_ready: bool,
    inference_success: bool,
    health: HealthState,
) -> PerceptionQuality:
    avg_conf = (sum(o.confidence for o in objects) / len(objects)) if objects else 0.0
    return PerceptionQuality(
        frame_valid=frame_valid,
        model_ready=model_ready,
        inference_success=inference_success,
        detection_count=len(objects),
        average_confidence=avg_conf,
        health=health,
    )


def merge_warnings(*warning_lists: list[str]) -> list[str]:
    merged: list[str] = []
    for wl in warning_lists:
        for w in wl or []:
            if w and w not in merged:
                merged.append(w)
    return merged
