"""
IndiDrive AI — Phase 2 | Image Preprocessing
================================================
Reusable, allocation-conscious preprocessing for the camera pipeline.
Designed for real-time use: avoids unnecessary copies, validates input
before touching it, and never silently accepts a malformed frame.

OpenCV (cv2) is used when available (it already is — see
requirements.txt: opencv-python>=4.8.0, also used by
core/carla_integration/). If cv2 is somehow unavailable, a pure-NumPy
fallback is used for resize (nearest-neighbor) so the pipeline degrades
rather than crashes.
"""
from __future__ import annotations

from typing import Optional

import numpy as np

try:
    import cv2  # type: ignore
    _HAS_CV2 = True
except ImportError:  # pragma: no cover - exercised only in envs without opencv
    cv2 = None  # type: ignore
    _HAS_CV2 = False


class PreprocessingError(ValueError):
    """Raised when an input image fails structural validation."""


def validate_image(image: Optional[np.ndarray]) -> tuple[bool, str]:
    if image is None:
        return False, "image is None"
    if not isinstance(image, np.ndarray):
        return False, f"image is not a numpy array (got {type(image).__name__})"
    if image.ndim != 3 or image.shape[2] not in (1, 3, 4):
        return False, f"expected HxWxC (C in 1,3,4), got shape {image.shape}"
    if image.shape[0] <= 0 or image.shape[1] <= 0:
        return False, f"non-positive dimensions: {image.shape}"
    if image.dtype != np.uint8:
        return False, f"unexpected dtype {image.dtype} (expected uint8)"
    if not np.isfinite(image).all() if np.issubdtype(image.dtype, np.floating) else False:
        return False, "image contains NaN/Inf"
    return True, "ok"


def to_rgb(image: np.ndarray, source_encoding: str = "rgb8") -> np.ndarray:
    """Converts to RGB if the source is BGR; no-op (view, not copy) otherwise."""
    if source_encoding.lower() in ("bgr8", "bgr"):
        return image[:, :, ::-1]
    return image


def resize(image: np.ndarray, width: int, height: int) -> np.ndarray:
    if image.shape[1] == width and image.shape[0] == height:
        return image
    if _HAS_CV2:
        return cv2.resize(image, (width, height), interpolation=cv2.INTER_LINEAR)
    # Pure-NumPy nearest-neighbor fallback.
    src_h, src_w = image.shape[:2]
    row_idx = (np.arange(height) * (src_h / height)).astype(np.int32)
    col_idx = (np.arange(width) * (src_w / width)).astype(np.int32)
    return image[row_idx][:, col_idx]


def letterbox(image: np.ndarray, target_size: int = 640, pad_value: int = 114) -> tuple[np.ndarray, float, tuple[int, int]]:
    """Resize preserving aspect ratio, padding to a square target_size x
    target_size (the standard YOLO-style input transform). Returns
    (letterboxed_image, scale, (pad_x, pad_y)) so detections can be
    mapped back to original image coordinates."""
    h, w = image.shape[:2]
    scale = min(target_size / h, target_size / w)
    new_h, new_w = int(round(h * scale)), int(round(w * scale))
    resized = resize(image, new_w, new_h)

    canvas = np.full((target_size, target_size, image.shape[2]), pad_value, dtype=np.uint8)
    pad_y = (target_size - new_h) // 2
    pad_x = (target_size - new_w) // 2
    canvas[pad_y:pad_y + new_h, pad_x:pad_x + new_w] = resized
    return canvas, scale, (pad_x, pad_y)


def normalize(image: np.ndarray) -> np.ndarray:
    """uint8 [0,255] -> float32 [0,1]. Allocates one new array (cannot
    normalize in place without losing the original uint8 for display)."""
    return image.astype(np.float32) / 255.0


def unletterbox_bbox(x: float, y: float, w: float, h: float, scale: float, pad: tuple[int, int]) -> tuple[float, float, float, float]:
    """Maps a bbox from letterboxed coordinates back to the original image."""
    pad_x, pad_y = pad
    if scale <= 0:
        return x, y, w, h
    return (x - pad_x) / scale, (y - pad_y) / scale, w / scale, h / scale
