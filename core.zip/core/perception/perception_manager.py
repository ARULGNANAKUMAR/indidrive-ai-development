"""
IndiDrive AI — Phase 2 | Perception Manager
===============================================
Top-level lifecycle and orchestration, mirroring the responsibilities
of Phase 1's core/carla_integration/sensor_manager.py one layer up the
stack:

    initialize()          load config, construct PerceptionEngine
    process_camera()      run camera perception on a single CameraFrame
    process_lidar()       run LiDAR perception on a single LiDARFrame
    process_radar()       always NOT_AVAILABLE (see radar_perception.py)
    process_frame()       full-cycle: camera + lidar (+ road + anomaly) -> PerceptionFrame
    get_latest_perception()
    get_health()
    shutdown()

Contains NO planner/decision logic — this manager's only job is to
turn Phase 1 SensorFrames into PerceptionFrames and expose them. It
does not know about vehicle control.

Bounded memory: only the last `history_size` PerceptionFrames are
retained (small, since a frame here holds no raw image/point-cloud
payload — that stays in the Phase 1 SensorBuffer).
"""
from __future__ import annotations

import threading
from collections import deque
from typing import Optional

import numpy as np

from .perception_engine import PerceptionEngine, EngineConfig
from .perception_types import PerceptionFrame

try:
    from core.logging_system import get_logger
except ImportError:  # pragma: no cover
    get_logger = None

try:
    from core.config_loader import load_config, ConfigError
except ImportError:  # pragma: no cover
    load_config = None
    ConfigError = RuntimeError


DEFAULT_PERCEPTION_CONFIG = {
    "perception": {
        "enabled": True,
        "camera": {"enabled": True, "backend": "AUTO", "confidence_threshold": 0.40, "nms_threshold": 0.45,
                    "input_width": 640, "input_height": 640},
        "lidar": {"enabled": True, "min_range_m": 1.0, "max_range_m": 80.0, "min_height_m": -2.5,
                  "max_height_m": 3.5, "ground_removal": True, "clustering": True},
        "radar": {"enabled": False},
        "road": {"enabled": True, "backend": "CLASSICAL"},
        "road_damage": {"enabled": True, "backend": "NOT_CONFIGURED"},
    }
}


def _load_perception_config() -> dict:
    """Loads config/perception_config.yaml if the Phase 0 config loader
    and file are present; falls back to DEFAULT_PERCEPTION_CONFIG
    otherwise (never crashes PerceptionManager construction)."""
    if load_config is not None:
        try:
            from pathlib import Path
            from core.config_loader import CONFIG_DIR
            path = CONFIG_DIR / "perception_config.yaml"
            if path.exists():
                import yaml  # type: ignore
                with open(path, "r", encoding="utf-8") as f:
                    data = yaml.safe_load(f)
                if isinstance(data, dict) and "perception" in data:
                    return data
        except Exception:
            pass
    return DEFAULT_PERCEPTION_CONFIG


class PerceptionManager:
    def __init__(self, config: Optional[dict] = None, history_size: int = 30):
        self._raw_config = config or _load_perception_config()
        self._pconf = self._raw_config.get("perception", {})
        self._log = get_logger("system", component="perception_manager") if get_logger else None
        self._lock = threading.Lock()
        self._history: deque[PerceptionFrame] = deque(maxlen=max(1, history_size))
        self._initialized = False
        self.engine: Optional[PerceptionEngine] = None

    # -- lifecycle --------------------------------------------------

    def initialize(self) -> None:
        if self._initialized:
            return
        cam_cfg = self._pconf.get("camera", {})
        road_cfg = self._pconf.get("road", {})
        anomaly_cfg = self._pconf.get("road_damage", {})

        engine_config = EngineConfig(
            camera_backend=cam_cfg.get("backend", "AUTO") if cam_cfg.get("enabled", True) else "NONE",
            confidence_threshold=cam_cfg.get("confidence_threshold", 0.40),
            nms_threshold=cam_cfg.get("nms_threshold", 0.45),
            road_backend=road_cfg.get("backend", "CLASSICAL"),
            road_enabled=road_cfg.get("enabled", True),
            anomaly_backend=anomaly_cfg.get("backend", "NOT_CONFIGURED"),
            anomaly_enabled=anomaly_cfg.get("enabled", True),
        )
        self.engine = PerceptionEngine(engine_config)

        # LiDAR config isn't threaded through EngineConfig (kept minimal);
        # apply it directly to the constructed pipeline instead.
        lidar_cfg = self._pconf.get("lidar", {})
        if lidar_cfg:
            lp = self.engine.lidar.config
            lp.min_range_m = lidar_cfg.get("min_range_m", lp.min_range_m)
            lp.max_range_m = lidar_cfg.get("max_range_m", lp.max_range_m)
            lp.min_height_m = lidar_cfg.get("min_height_m", lp.min_height_m)
            lp.max_height_m = lidar_cfg.get("max_height_m", lp.max_height_m)
            lp.ground_removal = lidar_cfg.get("ground_removal", lp.ground_removal)
            lp.clustering = lidar_cfg.get("clustering", lp.clustering)

        self._initialized = True
        if self._log:
            self._log.info("perception_manager_initialized",
                            camera_backend=engine_config.camera_backend,
                            road_backend=engine_config.road_backend)

    def shutdown(self) -> None:
        """Releases perception state. Safe to call multiple times.
        Does not touch Phase 1 sensors/buffers — those are Phase 1's
        SensorManager's responsibility."""
        with self._lock:
            self._history.clear()
        self._initialized = False
        if self._log:
            self._log.info("perception_manager_shutdown")

    def _require_engine(self) -> PerceptionEngine:
        if not self._initialized or self.engine is None:
            self.initialize()
        return self.engine

    # -- per-sensor entry points --------------------------------------

    def process_camera(self, image: Optional[np.ndarray], timestamp: float):
        engine = self._require_engine()
        return engine.camera.process(image, timestamp)

    def process_lidar(self, points: Optional[np.ndarray], timestamp: float):
        engine = self._require_engine()
        return engine.lidar.process(points, timestamp)

    def process_radar(self, radar_frame=None, timestamp: float = 0.0):
        engine = self._require_engine()
        return engine.radar.process(radar_frame, timestamp)

    # -- full cycle -----------------------------------------------------

    def process_frame(
        self,
        camera_image: Optional[np.ndarray] = None,
        camera_timestamp: Optional[float] = None,
        lidar_points: Optional[np.ndarray] = None,
        lidar_timestamp: Optional[float] = None,
        sensor_status: Optional[dict] = None,
    ) -> PerceptionFrame:
        engine = self._require_engine()
        frame = engine.process(
            camera_image=camera_image, camera_timestamp=camera_timestamp,
            lidar_points=lidar_points, lidar_timestamp=lidar_timestamp,
            sensor_status=sensor_status,
        )
        with self._lock:
            self._history.append(frame)
        return frame

    def process_from_sensor_manager(self, sensor_manager, camera_sensor_id: Optional[str] = None,
                                     lidar_sensor_id: Optional[str] = None) -> PerceptionFrame:
        """Convenience bridge to Phase 1's SensorManager: pulls the
        latest buffered CameraFrame/LiDARFrame (if configured) and runs
        one perception cycle. Does not start/stop sensors — that
        remains SensorManager's job."""
        camera_image, camera_ts = None, None
        lidar_points, lidar_ts = None, None

        if camera_sensor_id:
            frame = sensor_manager.latest(camera_sensor_id)
            if frame is not None and getattr(frame, "image", None) is not None:
                camera_image = frame.image
                camera_ts = frame.timestamp.sensor_time or frame.timestamp.reception_time

        if lidar_sensor_id:
            frame = sensor_manager.latest(lidar_sensor_id)
            if frame is not None and getattr(frame, "points", None) is not None:
                lidar_points = frame.points
                lidar_ts = frame.timestamp.sensor_time or frame.timestamp.reception_time

        sensor_status = sensor_manager.status_report() if hasattr(sensor_manager, "status_report") else {}
        return self.process_frame(
            camera_image=camera_image, camera_timestamp=camera_ts,
            lidar_points=lidar_points, lidar_timestamp=lidar_ts,
            sensor_status=sensor_status,
        )

    # -- introspection ---------------------------------------------------

    def get_latest_perception(self) -> Optional[PerceptionFrame]:
        with self._lock:
            return self._history[-1] if self._history else None

    def get_history(self) -> list[PerceptionFrame]:
        with self._lock:
            return list(self._history)

    def get_health(self) -> dict:
        if self.engine is None:
            return {}
        return self.engine.get_health()

    def get_model_status(self) -> dict:
        if self.engine is None:
            return {}
        return self.engine.get_model_status()
