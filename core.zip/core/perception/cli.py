"""
IndiDrive AI — Phase 2 | Perception CLI
===========================================
Usage:
    python3 -m core.perception --help
    python3 -m core.perception perception-health
    python3 -m core.perception perception-test
    python3 -m core.perception perception-replay --session-dir data/recordings/<session> --sensor cam_front
    python3 -m core.perception perception-benchmark --iterations 50 --sensor camera
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np


def cmd_health(args: argparse.Namespace) -> int:
    from .perception_manager import PerceptionManager
    mgr = PerceptionManager()
    mgr.initialize()
    mgr.process_frame()  # ensures at least one cycle so health has data
    print(json.dumps(mgr.get_health(), indent=2))
    return 0


def cmd_test(args: argparse.Namespace) -> int:
    """Runs one synthetic frame through the full engine with the
    deterministic MockBackend, to sanity-check the pipeline wiring
    without needing a real model or sensor."""
    from .perception_engine import PerceptionEngine, EngineConfig
    from .object_detection import MockBackend

    engine = PerceptionEngine(EngineConfig())
    engine.camera._detector = MockBackend(n_detections=2)
    engine.camera._detector.load_model()

    img = np.zeros((480, 640, 3), dtype=np.uint8)
    pts = np.random.default_rng(0).uniform(-10, 10, size=(500, 4)).astype(np.float32)
    pts[:, 3] = np.abs(pts[:, 3])

    frame = engine.process(camera_image=img, camera_timestamp=time.time(),
                            lidar_points=pts, lidar_timestamp=time.time())
    print(f"perception-test: OK — {len(frame.objects)} objects, "
          f"{frame.processing_metrics.total_perception_latency_ms:.2f} ms "
          f"(backend=MOCK — this does not indicate real-model accuracy)")
    print(json.dumps(frame.to_dict(), indent=2)[:2000])
    return 0


def cmd_replay(args: argparse.Namespace) -> int:
    sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
    from core.carla_integration.sensor_replay import OfflineSensorReplay
    from .perception_manager import PerceptionManager

    session_dir = Path(args.session_dir)
    if not session_dir.exists():
        print(f"perception-replay: session directory not found: {session_dir}", file=sys.stderr)
        return 1

    replay = OfflineSensorReplay(session_dir)
    frames = replay.load_frames(args.sensor)
    if not frames:
        print(f"perception-replay: no frames found for sensor '{args.sensor}' in {session_dir}", file=sys.stderr)
        return 1

    mgr = PerceptionManager()
    mgr.initialize()
    processed = 0
    for f in frames:
        if hasattr(f, "image") and f.image is not None:
            mgr.process_frame(camera_image=f.image, camera_timestamp=f.timestamp.sensor_time)
            processed += 1
        elif hasattr(f, "points") and f.points is not None:
            mgr.process_frame(lidar_points=f.points, lidar_timestamp=f.timestamp.sensor_time)
            processed += 1
    print(f"perception-replay: processed {processed}/{len(frames)} frames from '{args.sensor}'")
    return 0


def cmd_benchmark(args: argparse.Namespace) -> int:
    from .perception_benchmark import run_camera_benchmark, run_lidar_benchmark
    if args.sensor == "lidar":
        report = run_lidar_benchmark(iterations=args.iterations)
    else:
        report = run_camera_benchmark(iterations=args.iterations)
    print(json.dumps(report.to_dict(), indent=2))
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="python3 -m core.perception",
                                      description="IndiDrive AI Phase 2 perception CLI")
    sub = parser.add_subparsers(dest="command", required=True)

    sub.add_parser("perception-health", help="Print perception component health").set_defaults(func=cmd_health)
    sub.add_parser("perception-test", help="Run one synthetic frame through the pipeline (mock backend)").set_defaults(func=cmd_test)

    p_replay = sub.add_parser("perception-replay", help="Replay a recorded session through perception")
    p_replay.add_argument("--session-dir", required=True)
    p_replay.add_argument("--sensor", required=True)
    p_replay.set_defaults(func=cmd_replay)

    p_bench = sub.add_parser("perception-benchmark", help="Measure real perception latency/throughput")
    p_bench.add_argument("--iterations", type=int, default=50)
    p_bench.add_argument("--sensor", choices=["camera", "lidar"], default="camera")
    p_bench.set_defaults(func=cmd_benchmark)

    return parser


def main(argv=None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
