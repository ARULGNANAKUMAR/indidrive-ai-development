"""
IndiDrive AI — Phase 6.5 | Unified Road Understanding State
================================================================================
Consolidates outputs from Phase 6.1 (drivable area / road boundaries),
Phase 6.2 (lane & road-structure), Phase 6.3 (road anomaly / damage), and
Phase 6.4 (Indian-road context) into a single clean, versioned, deterministic
``RoadUnderstandingState`` for future Phase 7 (World Model) consumption.

Design principles — same as previous phases:
  * dataclasses, not raw dicts
  * explicit NOT_AVAILABLE / unknown / degraded states; nothing fabricated
  * uncertainty kept separate from confidence
  * immutable snapshot once returned (frozen dataclass fields)
  * compact: no raw sensor frames, point clouds, or large tensors
  * deterministic: identical inputs → identical output

Coordinate frame: vehicle frame (+X forward, +Y left, +Z up, origin at
rear-axle centre, metres) — identical to Phase 6.1–6.4 / COORDINATE_SYSTEMS.md.

Phase 6.5 does NOT perform new perception.  It aggregates and validates.
"""
from __future__ import annotations

import copy
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Optional

from .perception_types import NOT_AVAILABLE

__all__ = [
    "NOT_AVAILABLE",
    # Enums
    "UnifiedStatus",
    "ModuleAvailability",
    "TimestampConsistency",
    "GeometryConsistency",
    # Summary
    "RoadSummary",
    "SensorAvailabilitySummary",
    "ConsistencyReport",
    "ConfidenceBreakdown",
    "UncertaintyBreakdown",
    "SourceProvenance",
    # Top-level output
    "RoadUnderstandingState",
    # Engine config
    "RoadUnderstandingStateConfig",
]

# State schema version — updated when the field layout changes in a
# backward-incompatible way.
STATE_VERSION = "6.5"


# ---------------------------------------------------------------------------
# Enums
# ---------------------------------------------------------------------------

class UnifiedStatus(str, Enum):
    """Overall health of the unified road-understanding state."""
    OK         = "OK"           # all key modules healthy; good confidence
    PARTIAL    = "PARTIAL"      # one or more modules degraded; useful output still available
    DEGRADED   = "DEGRADED"     # significant degradation; output should be used with caution
    UNAVAILABLE = "UNAVAILABLE" # no usable upstream data; state is empty / unknown
    INVALID    = "INVALID"      # input validation failure; geometry / timestamp corruption


class ModuleAvailability(str, Enum):
    """Availability state of a single upstream module."""
    OK          = "OK"           # healthy output present
    DEGRADED    = "DEGRADED"     # present but below confidence / consistency threshold
    UNAVAILABLE = "UNAVAILABLE"  # module produced no output this cycle
    ERROR       = "ERROR"        # module raised an exception; output replaced by safe defaults


class TimestampConsistency(str, Enum):
    """Result of cross-module timestamp validation."""
    CONSISTENT  = "CONSISTENT"   # all timestamps within tolerance
    ACCEPTABLE  = "ACCEPTABLE"   # small skew; within extended tolerance
    STALE       = "STALE"        # one or more modules significantly stale
    MISSING     = "MISSING"      # one or more timestamps absent / zero
    INVALID     = "INVALID"      # non-monotonic or clearly corrupt timestamp
    UNCHECKED   = "UNCHECKED"    # check not yet performed


class GeometryConsistency(str, Enum):
    """Result of cross-module geometric cross-check."""
    CONSISTENT  = "CONSISTENT"   # geometry cross-checks passed
    WARNING     = "WARNING"      # minor geometric inconsistency detected
    CONFLICT    = "CONFLICT"     # significant geometric conflict detected
    UNCHECKED   = "UNCHECKED"    # insufficient data to run checks
    INVALID     = "INVALID"      # geometry validation failure


# ---------------------------------------------------------------------------
# Sub-structures
# ---------------------------------------------------------------------------

@dataclass
class RoadSummary:
    """
    Compact top-level summary for downstream consumers (Phase 7 World Model).

    Only exposes fields that were actually available from upstream modules.
    Unknown values are kept explicit — never fabricated.
    """
    # Road structure
    road_type: str = NOT_AVAILABLE           # forwards Phase 6.4 RoadType.value
    road_width_category: str = NOT_AVAILABLE # forwards Phase 6.4 RoadWidthCategory.value
    estimated_road_width_m: Optional[float] = None  # None = unknown

    # Lane structure
    lane_marking_state: str = NOT_AVAILABLE  # forwards Phase 6.2 MarkingStatus.value
    lane_count: Optional[int] = None         # None = unknown
    intersection_state: str = NOT_AVAILABLE  # NORMAL_ROAD | INTERSECTION | UNKNOWN

    # Road surface
    road_surface_quality: str = NOT_AVAILABLE  # forwards Phase 6.3 RoadSurfaceQuality.value

    # Traffic / context
    traffic_density: str = NOT_AVAILABLE    # forwards Phase 6.4 TrafficDensity.value
    road_complexity: str = NOT_AVAILABLE    # forwards Phase 6.4 RoadComplexity.value

    # Animal / VRU flags
    animal_present: bool = False
    vru_presence: str = NOT_AVAILABLE       # forwards Phase 6.4 VRUPresence.value

    # Anomaly summary
    anomaly_count: int = 0
    has_critical_anomaly: bool = False      # any CRITICAL severity anomaly in drivable area

    def to_dict(self) -> dict:
        return {
            "road_type": self.road_type,
            "road_width_category": self.road_width_category,
            "estimated_road_width_m": (
                round(self.estimated_road_width_m, 3)
                if self.estimated_road_width_m is not None else NOT_AVAILABLE
            ),
            "lane_marking_state": self.lane_marking_state,
            "lane_count": self.lane_count if self.lane_count is not None else NOT_AVAILABLE,
            "intersection_state": self.intersection_state,
            "road_surface_quality": self.road_surface_quality,
            "traffic_density": self.traffic_density,
            "road_complexity": self.road_complexity,
            "animal_present": self.animal_present,
            "vru_presence": self.vru_presence,
            "anomaly_count": self.anomaly_count,
            "has_critical_anomaly": self.has_critical_anomaly,
        }


@dataclass
class SensorAvailabilitySummary:
    """Compact sensor-health summary derived from upstream module reports."""
    camera_available: bool = False
    lidar_available: bool = False
    radar_available: bool = False
    fusion_available: bool = False
    road_understanding_degraded: bool = False

    def to_dict(self) -> dict:
        return {
            "camera_available": self.camera_available,
            "lidar_available": self.lidar_available,
            "radar_available": self.radar_available,
            "fusion_available": self.fusion_available,
            "road_understanding_degraded": self.road_understanding_degraded,
        }


@dataclass
class ConsistencyReport:
    """
    Results of cross-module consistency checks.

    Warnings are raised but upstream data is NEVER silently modified.
    """
    timestamp_consistency: TimestampConsistency = TimestampConsistency.UNCHECKED
    geometry_consistency: GeometryConsistency = GeometryConsistency.UNCHECKED

    # Detailed flags
    lane_outside_road_boundary: bool = False     # Phase 6.2 lane geometry outside Phase 6.1 boundary
    road_width_conflict: bool = False            # Phase 6.1 width vs Phase 6.2 implied width
    marking_state_conflict: bool = False         # Phase 6.2 vs Phase 6.4 marking state
    anomaly_frame_conflict: bool = False         # Phase 6.3 anomaly in wrong coordinate frame
    timestamp_skew_seconds: float = 0.0          # max observed timestamp delta across modules
    warnings: list = field(default_factory=list) # list[str]

    def has_any_conflict(self) -> bool:
        return (
            self.lane_outside_road_boundary
            or self.road_width_conflict
            or self.marking_state_conflict
            or self.anomaly_frame_conflict
            or self.geometry_consistency == GeometryConsistency.CONFLICT
            or self.timestamp_consistency in (
                TimestampConsistency.STALE,
                TimestampConsistency.INVALID,
            )
        )

    def to_dict(self) -> dict:
        return {
            "timestamp_consistency": self.timestamp_consistency.value,
            "geometry_consistency": self.geometry_consistency.value,
            "lane_outside_road_boundary": self.lane_outside_road_boundary,
            "road_width_conflict": self.road_width_conflict,
            "marking_state_conflict": self.marking_state_conflict,
            "anomaly_frame_conflict": self.anomaly_frame_conflict,
            "timestamp_skew_seconds": round(self.timestamp_skew_seconds, 4),
            "warnings": list(self.warnings),
        }


@dataclass
class ConfidenceBreakdown:
    """
    Per-module confidence values used to compute overall_confidence.

    Each value is 0.0–1.0 (or NOT_AVAILABLE if module was unavailable).
    """
    drivable_area: float = 0.0   # Phase 6.1
    lane_structure: float = 0.0  # Phase 6.2
    road_anomaly: float = 0.0    # Phase 6.3
    indian_context: float = 0.0  # Phase 6.4
    overall: float = 0.0         # weighted aggregate

    def to_dict(self) -> dict:
        return {
            "drivable_area": round(self.drivable_area, 3),
            "lane_structure": round(self.lane_structure, 3),
            "road_anomaly": round(self.road_anomaly, 3),
            "indian_context": round(self.indian_context, 3),
            "overall": round(self.overall, 3),
        }


@dataclass
class UncertaintyBreakdown:
    """
    Per-module uncertainty values.

    Uncertainty is NOT simply 1 - confidence.
    It increases when: timestamps stale, frames conflict, sensors degraded,
    modules missing, geometric inconsistencies detected.
    """
    drivable_area: float = 1.0   # Phase 6.1
    lane_structure: float = 1.0  # Phase 6.2
    road_anomaly: float = 1.0    # Phase 6.3
    indian_context: float = 1.0  # Phase 6.4
    overall: float = 1.0         # worst-case propagated uncertainty

    def to_dict(self) -> dict:
        return {
            "drivable_area": round(self.drivable_area, 3),
            "lane_structure": round(self.lane_structure, 3),
            "road_anomaly": round(self.road_anomaly, 3),
            "indian_context": round(self.indian_context, 3),
            "overall": round(self.overall, 3),
        }


@dataclass
class SourceProvenance:
    """Where each section of the unified state came from."""
    drivable_area: str = NOT_AVAILABLE   # camera | lidar | fusion | unknown
    lane_structure: str = NOT_AVAILABLE
    road_anomalies: str = NOT_AVAILABLE
    context: str = "DERIVED"             # always derived by Phase 6.4

    def to_dict(self) -> dict:
        return {
            "drivable_area": self.drivable_area,
            "lane_structure": self.lane_structure,
            "road_anomalies": self.road_anomalies,
            "context": self.context,
        }


# ---------------------------------------------------------------------------
# Top-level unified state
# ---------------------------------------------------------------------------

@dataclass
class RoadUnderstandingState:
    """
    Phase 6.5 primary output.

    One RoadUnderstandingState is produced per RoadUnderstandingEngine.process()
    call.  This is the stable interface between the road-understanding layer
    (Phases 6.1–6.4) and the World Model (Phase 7).

    The state is a snapshot — once returned, changing upstream state objects
    does not mutate this instance (upstream data is deep-copied at construction).

    Phase 7 consumes this state WITHOUT needing to know the internal
    implementation of Phases 6.1–6.4.

    This module does NOT call into:
      - the World Model
      - the planner
      - the MPC / controller
      - any sensor driver
      - any perception model

    It only describes the road environment as understood this cycle.
    """

    # --- Schema identity -------------------------------------------------
    state_version: str = STATE_VERSION

    # --- Temporal / frame identity ----------------------------------------
    timestamp: float = 0.0
    frame_id: int = 0

    # --- Module availability -------------------------------------------
    phase61_availability: ModuleAvailability = ModuleAvailability.UNAVAILABLE
    phase62_availability: ModuleAvailability = ModuleAvailability.UNAVAILABLE
    phase63_availability: ModuleAvailability = ModuleAvailability.UNAVAILABLE
    phase64_availability: ModuleAvailability = ModuleAvailability.UNAVAILABLE

    # --- Upstream state references (deep-copied snapshots) ---------------
    # Type hints use string to avoid circular / Optional import complexity.
    # Consumers can import the upstream types directly from their modules.
    drivable_area_state: Optional[object] = None   # RoadUnderstanding | None
    lane_structure_state: Optional[object] = None  # LaneStructure | None
    road_anomaly_state: Optional[object] = None    # RoadAnomalyState | None
    indian_context_state: Optional[object] = None  # IndianRoadContextState | None

    # --- Compact derived summary (for downstream fast access) -----------
    summary: RoadSummary = field(default_factory=RoadSummary)

    # --- Confidence / uncertainty ----------------------------------------
    confidence_breakdown: ConfidenceBreakdown = field(default_factory=ConfidenceBreakdown)
    uncertainty_breakdown: UncertaintyBreakdown = field(default_factory=UncertaintyBreakdown)
    overall_confidence: float = 0.0    # aggregate [0, 1]
    overall_uncertainty: float = 1.0   # aggregate [0, ∞); usually [0, 1]

    # --- Consistency validation ------------------------------------------
    consistency: ConsistencyReport = field(default_factory=ConsistencyReport)

    # --- Sensor availability ---------------------------------------------
    sensor_availability: SensorAvailabilitySummary = field(
        default_factory=SensorAvailabilitySummary
    )

    # --- Source provenance -----------------------------------------------
    provenance: SourceProvenance = field(default_factory=SourceProvenance)

    # --- Top-level health flags ------------------------------------------
    status: UnifiedStatus = UnifiedStatus.UNAVAILABLE
    degraded: bool = True
    valid: bool = False

    # --- Diagnostics -----------------------------------------------------
    warnings: list = field(default_factory=list)   # list[str]
    metadata: dict = field(default_factory=dict)
    created_at: float = field(default_factory=time.time)

    # -----------------------------------------------------------------
    # Serialization
    # -----------------------------------------------------------------

    def to_dict(self) -> dict:
        """
        Convert to a JSON-serializable dict.

        Raw sensor frames, point clouds, and large tensors are NOT included —
        only structured road-understanding results.
        """
        # Upstream states serialised via their own to_dict() (compact structured form)
        da_dict = (
            self.drivable_area_state.to_dict()
            if self.drivable_area_state is not None else NOT_AVAILABLE
        )
        ls_dict = (
            self.lane_structure_state.to_dict()
            if self.lane_structure_state is not None else NOT_AVAILABLE
        )
        ra_dict = (
            self.road_anomaly_state.to_dict()
            if self.road_anomaly_state is not None else NOT_AVAILABLE
        )
        ctx_dict = (
            self.indian_context_state.to_dict()
            if self.indian_context_state is not None else NOT_AVAILABLE
        )

        return {
            "state_version": self.state_version,
            "timestamp": self.timestamp,
            "frame_id": self.frame_id,
            "status": self.status.value,
            "degraded": self.degraded,
            "valid": self.valid,
            # Module availability
            "module_availability": {
                "phase61_drivable_area": self.phase61_availability.value,
                "phase62_lane_structure": self.phase62_availability.value,
                "phase63_road_anomaly": self.phase63_availability.value,
                "phase64_indian_context": self.phase64_availability.value,
            },
            # Compact summary
            "summary": self.summary.to_dict(),
            # Confidence / uncertainty
            "confidence_breakdown": self.confidence_breakdown.to_dict(),
            "uncertainty_breakdown": self.uncertainty_breakdown.to_dict(),
            "overall_confidence": round(self.overall_confidence, 3),
            "overall_uncertainty": round(self.overall_uncertainty, 3),
            # Consistency
            "consistency": self.consistency.to_dict(),
            # Sensors
            "sensor_availability": self.sensor_availability.to_dict(),
            # Provenance
            "provenance": self.provenance.to_dict(),
            # Full upstream states (compact structured form — no raw sensor data)
            "drivable_area": da_dict,
            "lane_structure": ls_dict,
            "road_anomalies": ra_dict,
            "indian_context": ctx_dict,
            # Diagnostics
            "warnings": list(self.warnings),
            "metadata": dict(self.metadata),
        }

    @classmethod
    def from_dict(cls, d: dict) -> "RoadUnderstandingState":
        """
        Reconstruct a RoadUnderstandingState from a dict produced by ``to_dict()``.

        NOTE: upstream state objects (drivable_area_state, lane_structure_state,
        road_anomaly_state, indian_context_state) are NOT reconstructed — they
        are left as None.  Consumers needing the full upstream objects should
        import and reconstruct them separately.  This method is primarily
        useful for logging, testing, and schema validation.
        """
        state = cls()
        state.state_version = d.get("state_version", STATE_VERSION)
        state.timestamp = float(d.get("timestamp", 0.0))
        state.frame_id = int(d.get("frame_id", 0))
        state.overall_confidence = float(d.get("overall_confidence", 0.0))
        state.overall_uncertainty = float(d.get("overall_uncertainty", 1.0))
        state.degraded = bool(d.get("degraded", True))
        state.valid = bool(d.get("valid", False))
        # Status enum
        try:
            state.status = UnifiedStatus(d.get("status", UnifiedStatus.UNAVAILABLE.value))
        except ValueError:
            state.status = UnifiedStatus.INVALID
        state.warnings = list(d.get("warnings", []))
        state.metadata = dict(d.get("metadata", {}))
        return state


# ---------------------------------------------------------------------------
# Configuration for the integration engine
# ---------------------------------------------------------------------------

@dataclass
class RoadUnderstandingStateConfig:
    """
    Configuration for RoadUnderstandingEngine.

    All thresholds that affect state construction and validation are here —
    no magic numbers in the engine itself.
    """
    # Timestamp tolerance
    max_timestamp_skew_seconds: float = 0.5
    """Maximum allowed timestamp difference across upstream modules (seconds).
    If any module's timestamp differs from the reference by more than this,
    timestamp_consistency becomes STALE and uncertainty is increased."""

    extended_timestamp_skew_seconds: float = 0.2
    """Skew below which consistency is ACCEPTABLE (minor skew, not STALE)."""

    # Geometry tolerances
    lane_boundary_road_boundary_tolerance_m: float = 0.5
    """How far outside the road boundary a lane boundary point may be before
    triggering lane_outside_road_boundary warning (metres)."""

    road_width_conflict_factor: float = 1.5
    """Lane-implied road width may not exceed road_width * this factor before
    a width-conflict warning is raised."""

    min_physical_lane_width_m: float = 1.5
    """Minimum physically plausible lane width (metres)."""
    max_physical_lane_width_m: float = 7.0
    """Maximum physically plausible lane width (metres)."""

    min_physical_road_width_m: float = 2.0
    """Minimum physically plausible road width (metres)."""
    max_physical_road_width_m: float = 40.0
    """Maximum physically plausible road width (metres)."""

    # Confidence aggregation weights
    weight_drivable_area: float = 0.35
    """Weight of Phase 6.1 confidence in the overall_confidence aggregate."""
    weight_lane_structure: float = 0.30
    """Weight of Phase 6.2 confidence."""
    weight_road_anomaly: float = 0.20
    """Weight of Phase 6.3 confidence."""
    weight_indian_context: float = 0.15
    """Weight of Phase 6.4 confidence."""

    # Uncertainty penalties
    uncertainty_penalty_timestamp_stale: float = 0.20
    """Added to overall_uncertainty when timestamp consistency is STALE."""
    uncertainty_penalty_geometry_conflict: float = 0.15
    """Added to overall_uncertainty when geometry_consistency is CONFLICT."""
    uncertainty_penalty_module_missing: float = 0.10
    """Added to overall_uncertainty per missing upstream module."""
    uncertainty_penalty_sensor_degraded: float = 0.10
    """Added to overall_uncertainty when any upstream module is DEGRADED."""
    uncertainty_penalty_consistency_warning: float = 0.05
    """Added to overall_uncertainty per consistency warning."""

    # Confidence penalty for degradation
    confidence_penalty_module_missing: float = 0.10
    """Subtracted from overall_confidence per missing upstream module."""
    confidence_penalty_sensor_degraded: float = 0.05
    """Subtracted from overall_confidence when any module is DEGRADED."""
    confidence_penalty_consistency_conflict: float = 0.10
    """Subtracted from overall_confidence when geometry/timestamp conflicts exist."""

    @classmethod
    def from_dict(cls, d: dict) -> "RoadUnderstandingStateConfig":
        cfg = cls()
        for key, value in d.items():
            if hasattr(cfg, key):
                setattr(cfg, key, type(getattr(cfg, key))(value))
        return cfg

    def to_dict(self) -> dict:
        return {
            "max_timestamp_skew_seconds": self.max_timestamp_skew_seconds,
            "extended_timestamp_skew_seconds": self.extended_timestamp_skew_seconds,
            "lane_boundary_road_boundary_tolerance_m": self.lane_boundary_road_boundary_tolerance_m,
            "road_width_conflict_factor": self.road_width_conflict_factor,
            "min_physical_lane_width_m": self.min_physical_lane_width_m,
            "max_physical_lane_width_m": self.max_physical_lane_width_m,
            "min_physical_road_width_m": self.min_physical_road_width_m,
            "max_physical_road_width_m": self.max_physical_road_width_m,
            "weight_drivable_area": self.weight_drivable_area,
            "weight_lane_structure": self.weight_lane_structure,
            "weight_road_anomaly": self.weight_road_anomaly,
            "weight_indian_context": self.weight_indian_context,
            "uncertainty_penalty_timestamp_stale": self.uncertainty_penalty_timestamp_stale,
            "uncertainty_penalty_geometry_conflict": self.uncertainty_penalty_geometry_conflict,
            "uncertainty_penalty_module_missing": self.uncertainty_penalty_module_missing,
            "uncertainty_penalty_sensor_degraded": self.uncertainty_penalty_sensor_degraded,
            "uncertainty_penalty_consistency_warning": self.uncertainty_penalty_consistency_warning,
            "confidence_penalty_module_missing": self.confidence_penalty_module_missing,
            "confidence_penalty_sensor_degraded": self.confidence_penalty_sensor_degraded,
            "confidence_penalty_consistency_conflict": self.confidence_penalty_consistency_conflict,
        }
