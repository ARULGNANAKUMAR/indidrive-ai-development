"""
IndiDrive AI — Phase 2 | Camera Perception Pipeline
=======================================================
CameraFrame -> Validation -> Preprocessing -> Inference -> Filtering
-> Normalized PerceptionObject list.

Timing is measured with time.perf_counter() around each real stage;
nothing here fabricates latency or detection counts.
"""
from __future__ import annotations

import time
import uuid
from dataclasses import dataclass, field
from typing import Optional

import numpy as np

from . import preprocessing
from .confidence import filter_by_confidence, non_max_suppression, validate_and_clip_boxes, quality_score
from .object_detection import ObjectDetector, NoneBackend, resolve_backend, ModelNotFoundError
from .object_types import normalize_class, default_class_map
from .perception_types import (
    PerceptionObject, ProcessingMetrics, SourceSensor, BackendKind,
)

try:
    from core.logging_system import get_logger
except ImportError:  # pragma: no cover
    get_logger = None


@dataclass
class CameraPerceptionResult:
    objects: list[PerceptionObject]
    metrics: ProcessingMetrics
    status: str                     # OK | INVALID_FRAME | MODEL_NOT_FOUND | INFERENCE_FAILED
    warnings: list[str] = field(default_factory=list)


class CameraPerceptionPipeline:
    def __init__(
        self,
        backend: Optional[str] = None,
        backend_config: Optional[dict] = None,
        confidence_threshold: float = 0.40,
        nms_threshold: float = 0.45,
        input_size: tuple[int, int] = (640, 640),
        class_map: Optional[dict[str, str]] = None,
        class_thresholds: Optional[dict[str, float]] = None,
    ):
        self.confidence_threshold = confidence_threshold
        self.nms_threshold = nms_threshold
        self.input_size = input_size
        self.class_map = class_map or default_class_map()
        self.class_thresholds = class_thresholds or {}

        self._detector: ObjectDetector = resolve_backend(backend or "NONE", backend_config or {})
        self._model_load_error: Optional[str] = None
        self._log = get_logger("sensors", component="camera_perception") if get_logger else None
        self._fps_window: list[float] = []

        try:
            self._detector.load_model()
        except ModelNotFoundError as e:
            self._model_load_error = str(e)
            self._detector = NoneBackend(reason=str(e))
        except Exception as e:  # never let a bad model crash pipeline construction
            self._model_load_error = f"unexpected load error: {e}"
            self._detector = NoneBackend(reason=self._model_load_error)

        if self._log:
            info = self._detector.get_model_info()
            self._log.info("camera_perception_init", status=info.backend_kind.value,
                            backend=info.backend_name, ready=info.ready, note=info.note)

    # -- introspection ------------------------------------------------

    @property
    def backend_kind(self) -> BackendKind:
        return self._detector.get_model_info().backend_kind

    def model_status(self) -> dict:
        info = self._detector.get_model_info()
        d = info.to_dict()
        if self._model_load_error:
            d["load_error"] = self._model_load_error
        return d

    def _record_fps(self) -> float:
        now = time.time()
        self._fps_window.append(now)
        cutoff = now - 2.0
        while self._fps_window and self._fps_window[0] < cutoff:
            self._fps_window.pop(0)
        return (len(self._fps_window) / 2.0) if len(self._fps_window) > 1 else 0.0

    # -- main entry point ----------------------------------------------

    def process(self, image: Optional[np.ndarray], timestamp: float,
                encoding: str = "rgb8") -> CameraPerceptionResult:
        metrics = ProcessingMetrics()
        metrics.input_fps = self._record_fps()
        t_total_start = time.perf_counter()

        ok, reason = preprocessing.validate_image(image)
        if not ok:
            if self._log:
                self._log.warning("camera_frame_invalid", error=reason)
            return CameraPerceptionResult(objects=[], metrics=metrics, status="INVALID_FRAME",
                                           warnings=[f"INVALID_FRAME: {reason}"])

        # ---- preprocessing ----
        t0 = time.perf_counter()
        rgb = preprocessing.to_rgb(image, encoding)
        metrics.preprocessing_latency_ms = (time.perf_counter() - t0) * 1000.0

        if not self._detector.is_ready():
            metrics.total_perception_latency_ms = (time.perf_counter() - t_total_start) * 1000.0
            status = "MODEL_NOT_FOUND" if self._model_load_error else "OK"
            return CameraPerceptionResult(
                objects=[], metrics=metrics, status=status,
                warnings=[self._model_load_error] if self._model_load_error else
                         ["camera backend NOT_CONFIGURED — no detections produced"],
            )

        # ---- inference ----
        t0 = time.perf_counter()
        try:
            raw_detections = self._detector.detect(rgb)
        except Exception as e:
            if self._log:
                self._log.error("camera_inference_failed", error=str(e))
            metrics.inference_latency_ms = (time.perf_counter() - t0) * 1000.0
            metrics.total_perception_latency_ms = (time.perf_counter() - t_total_start) * 1000.0
            return CameraPerceptionResult(objects=[], metrics=metrics, status="INFERENCE_FAILED",
                                           warnings=[f"INFERENCE_FAILED: {e}"])
        metrics.inference_latency_ms = (time.perf_counter() - t0) * 1000.0

        # ---- postprocessing: clip, filter, NMS ----
        t0 = time.perf_counter()
        h, w = image.shape[:2]
        raw_detections = validate_and_clip_boxes(raw_detections, w, h)
        raw_detections = filter_by_confidence(raw_detections, self.confidence_threshold, self.class_thresholds)
        raw_detections = non_max_suppression(raw_detections, self.nms_threshold)

        backend_kind = self._detector.get_model_info().backend_kind
        objects: list[PerceptionObject] = []
        for det in raw_detections:
            norm_class = normalize_class(det.raw_class, self.class_map)
            area_ratio = (det.bbox.width * det.bbox.height) / max(1.0, w * h)
            q = quality_score(det.raw_confidence, area_ratio)
            objects.append(PerceptionObject(
                object_id=f"camera_{uuid.uuid4().hex[:10]}",
                object_class=norm_class,
                raw_class=det.raw_class,
                confidence=det.raw_confidence,
                raw_confidence=det.raw_confidence,
                source_sensor=SourceSensor.CAMERA,
                timestamp=timestamp,
                quality=q,
                bbox_2d=det.bbox,
                tracking_ready=True,
                backend=backend_kind,
            ))
        metrics.postprocessing_latency_ms = (time.perf_counter() - t0) * 1000.0
        metrics.total_perception_latency_ms = (time.perf_counter() - t_total_start) * 1000.0
        metrics.processing_fps = 1000.0 / metrics.total_perception_latency_ms if metrics.total_perception_latency_ms > 0 else 0.0

        if self._log:
            self._log.info("camera_frame_processed", detection_count=len(objects),
                            latency_ms=round(metrics.total_perception_latency_ms, 2))

        return CameraPerceptionResult(objects=objects, metrics=metrics, status="OK")
