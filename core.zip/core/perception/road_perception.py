"""
IndiDrive AI — Phase 2 | Road & Drivable-Area Perception
============================================================
First-stage road understanding. Two backends are supported via
configuration (perception.road.backend):

    SEGMENTATION  — a real trained road/lane segmentation model
                    (interface only; no weights are bundled with this
                    repository, so this resolves to NOT_CONFIGURED
                    unless a model is registered — see object_detection.py's
                    ModelManager integration pattern).
    CLASSICAL     — a labeled BASELINE using classical image processing
                    (grayscale + edge/gradient heuristics for a rough
                    drivable-region estimate). This is NOT semantic
                    segmentation and must never be reported as REAL.
    NONE          — road perception disabled/unavailable.

For unmarked Indian roads, `lane_marking = NOT_AVAILABLE` is a valid,
expected state — the pipeline never invents lane lines that classical
edge detection cannot reliably find on an unmarked road.
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Optional

import numpy as np

from .perception_types import RoadState, DrivableArea, BackendKind, NOT_AVAILABLE

try:
    import cv2  # type: ignore
    _HAS_CV2 = True
except ImportError:  # pragma: no cover
    cv2 = None  # type: ignore
    _HAS_CV2 = False


@dataclass
class RoadPerceptionResult:
    road_state: RoadState
    drivable_area: DrivableArea
    status: str  # OK | NOT_CONFIGURED | INVALID_FRAME
    latency_ms: float = 0.0
    warnings: list = field(default_factory=list)


class RoadPerceptionPipeline:
    def __init__(self, backend: str = "CLASSICAL", lower_roi_fraction: float = 0.55):
        self.backend = (backend or "NONE").strip().upper()
        # Only the bottom portion of the image (below the horizon) is
        # considered for the classical road heuristic.
        self.lower_roi_fraction = lower_roi_fraction

    def _classical_baseline(self, image: np.ndarray) -> tuple[RoadState, DrivableArea]:
        """A deliberately simple heuristic: assumes the road is the
        relatively low-texture, low-saturation region in the lower part
        of the frame. Works reasonably on plain asphalt in good light;
        fails on heavy shadow, standing water, or crowded frames — this
        is documented as BASELINE, never claimed as robust segmentation.
        """
        h, w = image.shape[:2]
        roi_y0 = int(h * (1.0 - self.lower_roi_fraction))
        roi = image[roi_y0:, :]

        if _HAS_CV2:
            gray = cv2.cvtColor(roi, cv2.COLOR_RGB2GRAY)
            edges = cv2.Canny(gray, 50, 150)
            edge_density = float(edges.mean() / 255.0)
        else:
            gray = roi.mean(axis=2)
            gx = np.abs(np.diff(gray, axis=1))
            edge_density = float(gx.mean() / 255.0)

        # Low edge density in the lower ROI -> more likely a plain drivable surface.
        road_confidence = max(0.0, min(1.0, 1.0 - edge_density * 4.0))
        road_present = road_confidence > 0.35

        mask = np.zeros((h, w), dtype=np.uint8)
        mask[roi_y0:, :] = 1 if road_present else 0

        road_state = RoadState(
            road_present=road_present,
            road_confidence=road_confidence,
            road_width_estimate_m=None,       # requires calibrated camera geometry — not available here
            lane_marking=NOT_AVAILABLE,        # classical edge heuristic is not a reliable lane detector
            lane_count_estimate=None,
            road_edge_candidates=[],
            backend=BackendKind.BASELINE,
        )
        drivable_area = DrivableArea(
            drivable_mask_available=True,
            drivable_mask_shape=(h, w),
            drivable_confidence=road_confidence,
            road_boundary_candidates=[],
            backend=BackendKind.BASELINE,
            mask=mask,
        )
        return road_state, drivable_area

    def process(self, image: Optional[np.ndarray]) -> RoadPerceptionResult:
        t0 = time.perf_counter()

        if self.backend == "NONE":
            return RoadPerceptionResult(
                road_state=RoadState(backend=BackendKind.NOT_CONFIGURED),
                drivable_area=DrivableArea(backend=BackendKind.NOT_CONFIGURED),
                status="NOT_CONFIGURED",
                warnings=["road perception disabled (perception.road.enabled=false)"],
            )

        if image is None or not isinstance(image, np.ndarray) or image.ndim != 3:
            return RoadPerceptionResult(
                road_state=RoadState(backend=BackendKind.NOT_CONFIGURED),
                drivable_area=DrivableArea(backend=BackendKind.NOT_CONFIGURED),
                status="INVALID_FRAME",
                warnings=["INVALID_FRAME: road perception requires a valid camera image"],
            )

        if self.backend == "SEGMENTATION":
            # No trained segmentation model ships with this repository.
            # The interface point is here for a future model; until one
            # is registered, road perception honestly reports NOT_CONFIGURED
            # rather than silently falling back without saying so.
            return RoadPerceptionResult(
                road_state=RoadState(backend=BackendKind.NOT_CONFIGURED),
                drivable_area=DrivableArea(backend=BackendKind.NOT_CONFIGURED),
                status="NOT_CONFIGURED",
                latency_ms=(time.perf_counter() - t0) * 1000.0,
                warnings=["backend=SEGMENTATION requested but no segmentation model is registered — "
                          "falling back requires explicit backend=CLASSICAL configuration"],
            )

        # CLASSICAL (default / baseline)
        road_state, drivable_area = self._classical_baseline(image)
        return RoadPerceptionResult(
            road_state=road_state, drivable_area=drivable_area, status="OK",
            latency_ms=(time.perf_counter() - t0) * 1000.0,
        )
