"""
IndiDrive AI — Phase 6.2 | Lane & Road-Structure Understanding
================================================================================
Lightweight lane/road-structure understanding layer.

Builds on Phase 6.1 (road boundary + drivable area) to produce per-lane
geometry, lane markings where observable, centrelines where inferrable,
lane count, lane width, and road heading — all with explicit
observed/inferred/unknown provenance.

Designed for Indian-road conditions:
  - Unmarked / weakly-marked roads are first-class, not exceptions.
  - An inferred structural corridor is clearly distinguished from an
    observed painted lane.
  - No fabrication: if evidence is insufficient, NOT_AVAILABLE/UNKNOWN
    is returned, not a made-up value.

Degraded-mode behaviour
-----------------------
camera OK + lidar OK (RoadUnderstanding available)
    → lane structure derived from RoadUnderstanding + RoadState lane hints
      source = fusion

lidar OK, camera unavailable
    → geometric corridor from road boundaries; no marking info
      source = lidar / inferred

camera OK, lidar unavailable
    → qualitative marking hint from RoadState; no metric geometry
      source = camera

neither available
    → LaneStructure(status=UNAVAILABLE)

This module does NOT:
  - control the vehicle
  - make traffic decisions
  - detect road damage
  - call into path planner / MPC / world model
  - introduce LLMs, cloud APIs, or large neural networks
  - modify Phase 6.1 (road_understanding.py / road_understanding_types.py)

API
---
    engine = LaneStructureEngine(config)
    result: LaneStructure = engine.process(
        road_understanding=road_understanding,   # Phase 6.1 output (preferred)
        road_state=road_state,                   # Phase 2 RoadState (optional)
        frame_id=frame_id,
        timestamp=timestamp,
    )
"""
from __future__ import annotations

import math
import time
from dataclasses import dataclass, field
from typing import Any, Optional

import numpy as np

from .perception_types import NOT_AVAILABLE, BackendKind, RoadState
from .road_understanding_types import (
    RoadUnderstanding, RoadUnderstandingStatus, BoundaryAvailability, BoundaryPoint,
)
from .lane_structure_types import (
    LaneStructure, LaneStructureStatus,
    MarkingStatus, MarkingType, EvidenceKind, RoadTypeHint, IntersectionState,
    LaneMarking, LaneMarkingPoint,
    LaneBoundary, LaneBoundaryPoint,
    LaneCenterline, CenterlinePoint,
    LaneDescriptor, LaneWidthSample,
)

try:
    from core.logging_system import get_logger
except ImportError:  # pragma: no cover
    get_logger = None


# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

@dataclass
class LaneStructureConfig:
    """
    All settings for Phase 6.2.  Loaded from perception_config.yaml section
    ``lane_structure``.  Defaults are conservative / safe for Indian roads.
    """
    enabled: bool = True
    minimum_confidence: float = 0.25

    # Forward distances at which lane widths are sampled (metres, vehicle +X).
    # Inherits from road_understanding forward_distances_m if not set.
    forward_distances_m: tuple = (0.0, 10.0, 20.0, 30.0)

    # Max forward distance for lane geometry output.
    max_forward_distance_m: float = 30.0

    # Allow structural corridor inference on unmarked roads?
    allow_unmarked_inference: bool = True

    # Minimum road width to attempt lane splitting (metres).
    min_road_width_for_lane_split_m: float = 5.5

    # Assumed single-lane usable width on narrow/unmarked roads (metres).
    default_single_lane_width_m: float = 3.5

    # Width below which a road is treated as single-lane regardless of
    # boundary evidence.
    narrow_road_threshold_m: float = 4.5

    # Plausible lane width range for Indian roads.
    min_plausible_lane_width_m: float = 1.5
    max_plausible_lane_width_m: float = 6.0

    # How stale a RoadUnderstanding may be (seconds).
    max_road_understanding_staleness_s: float = 1.0

    @classmethod
    def from_dict(cls, d: Optional[dict]) -> "LaneStructureConfig":
        if not d:
            return cls()
        kwargs: dict = {}
        for f in (
            "enabled", "minimum_confidence", "max_forward_distance_m",
            "allow_unmarked_inference", "min_road_width_for_lane_split_m",
            "default_single_lane_width_m", "narrow_road_threshold_m",
            "min_plausible_lane_width_m", "max_plausible_lane_width_m",
            "max_road_understanding_staleness_s",
        ):
            if f in d and d[f] is not None:
                kwargs[f] = d[f]
        if "forward_distances_m" in d and d["forward_distances_m"] is not None:
            kwargs["forward_distances_m"] = tuple(d["forward_distances_m"])
        return cls(**kwargs)


# ---------------------------------------------------------------------------
# Internal geometry helpers
# ---------------------------------------------------------------------------

def _wrap_angle(a: float) -> float:
    """Wrap angle to [-π, π]."""
    return float((a + math.pi) % (2 * math.pi) - math.pi)


def _points_to_np(points: list) -> np.ndarray:
    """Convert list[BoundaryPoint | LaneBoundaryPoint | CenterlinePoint] to Nx2 array."""
    if not points:
        return np.zeros((0, 2))
    return np.array([[p.x, p.y] for p in points], dtype=np.float64)


def _estimate_heading_from_points(pts_xy: np.ndarray) -> Optional[float]:
    """
    Estimate road heading (radians, vehicle frame) from a polyline.
    Uses least-squares line fit when ≥2 finite points are available.
    Returns None if insufficient data.
    """
    if pts_xy.shape[0] < 2:
        return None
    if not np.isfinite(pts_xy).all():
        return None
    # Fit y = mx + b; heading ≈ atan2(m, 1) for small angles.
    x = pts_xy[:, 0]
    y = pts_xy[:, 1]
    if np.ptp(x) < 1e-6:
        return None
    m, _ = np.polyfit(x, y, 1)
    if not np.isfinite(m):
        return None
    return _wrap_angle(math.atan2(m, 1.0))


def _interp_boundary_y(points: list, x_target: float) -> Optional[float]:
    """
    Linearly interpolate/extrapolate the boundary y at a given x from a
    sorted list of BoundaryPoint / LaneBoundaryPoint objects.
    Returns None if not possible.
    """
    if not points:
        return None
    pts = sorted(points, key=lambda p: p.x)
    xs = [p.x for p in pts]
    ys = [p.y for p in pts]
    if len(pts) == 1:
        return ys[0]
    # Clamp to range
    if x_target <= xs[0]:
        return ys[0]
    if x_target >= xs[-1]:
        return ys[-1]
    for i in range(len(xs) - 1):
        if xs[i] <= x_target <= xs[i + 1]:
            t = (x_target - xs[i]) / (xs[i + 1] - xs[i])
            return ys[i] + t * (ys[i + 1] - ys[i])
    return None


def _validate_geometry(pts: list) -> bool:
    """Return True iff all points have finite coordinates."""
    for p in pts:
        if not (np.isfinite(p.x) and np.isfinite(p.y)):
            return False
    return True


def _avg_confidence(items: list, attr: str = "confidence") -> float:
    vals = [getattr(i, attr) for i in items if hasattr(i, attr)]
    return float(np.mean(vals)) if vals else 0.0


# ---------------------------------------------------------------------------
# Marking classification from Phase 2 RoadState.lane_marking string
# ---------------------------------------------------------------------------

_MARKING_STRING_MAP: dict[str, tuple[MarkingType, MarkingStatus]] = {
    "solid":         (MarkingType.SOLID,        MarkingStatus.MARKED),
    "dashed":        (MarkingType.DASHED,       MarkingStatus.MARKED),
    "double_solid":  (MarkingType.DOUBLE_SOLID, MarkingStatus.MARKED),
    "double_dashed": (MarkingType.DOUBLE_DASHED, MarkingStatus.MARKED),
    "weak":          (MarkingType.UNKNOWN,      MarkingStatus.WEAKLY_MARKED),
    "none":          (MarkingType.UNKNOWN,      MarkingStatus.UNMARKED),
    "unmarked":      (MarkingType.UNKNOWN,      MarkingStatus.UNMARKED),
}


def _classify_marking(lane_marking_str: str) -> tuple[MarkingType, MarkingStatus]:
    """Map Phase 2 lane_marking string to (MarkingType, MarkingStatus)."""
    if not lane_marking_str or lane_marking_str == NOT_AVAILABLE:
        return MarkingType.UNKNOWN, MarkingStatus.UNKNOWN
    key = lane_marking_str.strip().lower()
    return _MARKING_STRING_MAP.get(key, (MarkingType.UNKNOWN, MarkingStatus.UNKNOWN))


# ---------------------------------------------------------------------------
# Boundary conversion helpers
# ---------------------------------------------------------------------------

def _road_boundary_to_lane_boundary(
    rb,  # RoadBoundary (Phase 6.1)
    boundary_id: str,
    source_override: Optional[str] = None,
) -> LaneBoundary:
    """Convert a Phase 6.1 RoadBoundary to a Phase 6.2 LaneBoundary."""
    lb = LaneBoundary(
        boundary_id=boundary_id,
        side=rb.side,
        available=rb.available,
        evidence=EvidenceKind.INFERRED,   # road edge is inferred from LiDAR geometry
        marking_type=MarkingType.UNKNOWN,
        source=source_override or rb.source,
        confidence=rb.confidence,
    )
    for bp in rb.points:
        if np.isfinite(bp.x) and np.isfinite(bp.y):
            lb.points.append(LaneBoundaryPoint(
                x=bp.x, y=bp.y,
                confidence=bp.confidence,
                evidence=EvidenceKind.INFERRED,
            ))
    return lb


def _synthetic_boundary(
    x_samples: tuple,
    y_value: float,
    side: str,
    boundary_id: str,
    confidence: float,
    evidence: EvidenceKind,
    source: str,
) -> LaneBoundary:
    """Build a constant-y boundary (for unmarked corridors or single-lane)."""
    lb = LaneBoundary(
        boundary_id=boundary_id,
        side=side,
        available=True,
        evidence=evidence,
        marking_type=MarkingType.UNKNOWN,
        source=source,
        confidence=confidence,
    )
    for x in x_samples:
        if np.isfinite(x) and np.isfinite(y_value):
            lb.points.append(LaneBoundaryPoint(
                x=float(x), y=float(y_value),
                confidence=confidence,
                evidence=evidence,
            ))
    return lb


# ---------------------------------------------------------------------------
# Centreline derivation
# ---------------------------------------------------------------------------

def _derive_centerline(
    left_boundary: Optional[LaneBoundary],
    right_boundary: Optional[LaneBoundary],
    lane_id: str,
    x_samples: tuple,
    evidence: EvidenceKind,
    confidence_scale: float = 1.0,
) -> Optional[LaneCenterline]:
    """
    Derive a lane centreline from two boundary polylines by averaging y at
    each sampled x distance.  Requires at least one boundary with ≥1 point.
    Returns None if insufficient data.
    """
    if left_boundary is None and right_boundary is None:
        return None

    pts: list[CenterlinePoint] = []
    for x in x_samples:
        ly = _interp_boundary_y(left_boundary.points, x) if (left_boundary and left_boundary.points) else None
        ry = _interp_boundary_y(right_boundary.points, x) if (right_boundary and right_boundary.points) else None

        if ly is not None and ry is not None:
            cy = (ly + ry) / 2.0
            conf = confidence_scale * min(
                _avg_confidence(left_boundary.points) if left_boundary else 0.5,
                _avg_confidence(right_boundary.points) if right_boundary else 0.5,
            )
        elif ly is not None:
            cy = ly  # partial: only left known — centreline = left (uncertain)
            conf = 0.3 * confidence_scale
        elif ry is not None:
            cy = ry
            conf = 0.3 * confidence_scale
        else:
            continue

        if np.isfinite(cy) and np.isfinite(x):
            pts.append(CenterlinePoint(
                x=float(x), y=float(cy),
                confidence=conf,
                evidence=evidence,
            ))

    if not pts:
        return None

    # Estimate heading for each point from the polyline slope.
    if len(pts) >= 2:
        arr = _points_to_np(pts)
        for i, pt in enumerate(pts):
            # Local slope from adjacent points.
            if i == 0:
                dx = pts[1].x - pts[0].x
                dy = pts[1].y - pts[0].y
            elif i == len(pts) - 1:
                dx = pts[-1].x - pts[-2].x
                dy = pts[-1].y - pts[-2].y
            else:
                dx = pts[i + 1].x - pts[i - 1].x
                dy = pts[i + 1].y - pts[i - 1].y
            if abs(dx) > 1e-6:
                pt.heading_rad = _wrap_angle(math.atan2(dy, dx))

    cl = LaneCenterline(
        lane_id=lane_id,
        points=pts,
        available=True,
        evidence=evidence,
        confidence=float(np.mean([p.confidence for p in pts])),
    )
    return cl


# ---------------------------------------------------------------------------
# Width estimation
# ---------------------------------------------------------------------------

def _estimate_width_samples(
    left_boundary: Optional[LaneBoundary],
    right_boundary: Optional[LaneBoundary],
    lane_id: str,
    x_samples: tuple,
    min_w: float,
    max_w: float,
    confidence_scale: float = 1.0,
) -> list:
    """Estimate LaneWidthSample list from two boundaries."""
    samples = []
    if left_boundary is None or right_boundary is None:
        return samples
    for x in x_samples:
        ly = _interp_boundary_y(left_boundary.points, x)
        ry = _interp_boundary_y(right_boundary.points, x)
        if ly is None or ry is None:
            continue
        w = ly - ry
        if not np.isfinite(w) or w < min_w or w > max_w:
            continue
        conf_l = _avg_confidence(left_boundary.points)
        conf_r = _avg_confidence(right_boundary.points)
        conf = confidence_scale * min(conf_l, conf_r)
        samples.append(LaneWidthSample(
            lane_id=lane_id,
            distance_m=float(x),
            estimated_width_m=float(w),
            confidence=conf,
        ))
    return samples


# ---------------------------------------------------------------------------
# Main engine
# ---------------------------------------------------------------------------

class LaneStructureEngine:
    """
    Phase 6.2 — Lane & Road-Structure Understanding.

    API::

        engine = LaneStructureEngine(config)
        result = engine.process(
            road_understanding=ru,   # Phase 6.1 RoadUnderstanding (preferred)
            road_state=rs,           # Phase 2 RoadState (optional; supplies marking info)
            frame_id=0,
            timestamp=None,
        )

    Never calls into path planner, world model, MPC, steering, or any Phase 4+
    decision module.
    """

    def __init__(self, config: Optional[LaneStructureConfig] = None):
        self.config = config or LaneStructureConfig()
        self._log = get_logger("perception", component="lane_structure") if get_logger else None

    # -------------------------------------------------------------------
    # Helpers: resolve inputs
    # -------------------------------------------------------------------

    def _resolve_road_understanding(
        self,
        road_understanding: Optional[RoadUnderstanding],
        perception: Any,
        fused_state: Any,
        timestamp: float,
    ) -> tuple[Optional[RoadUnderstanding], str]:
        ru = road_understanding
        if ru is None and perception is not None:
            ru = getattr(perception, "road_understanding", None)
        if ru is None and fused_state is not None:
            ru = getattr(fused_state, "road_understanding", None)
        if ru is None:
            return None, "UNAVAILABLE"
        age = timestamp - ru.timestamp
        if age > self.config.max_road_understanding_staleness_s:
            return None, "STALE"
        if ru.status == RoadUnderstandingStatus.UNAVAILABLE:
            return ru, "UNAVAILABLE"
        if ru.status == RoadUnderstandingStatus.INVALID:
            return ru, "INVALID"
        return ru, "OK"

    def _resolve_road_state(
        self,
        road_state: Optional[RoadState],
        perception: Any,
        fused_state: Any,
    ) -> Optional[RoadState]:
        rs = road_state
        if rs is None and perception is not None:
            rs = getattr(perception, "road_state", None)
        if rs is None and fused_state is not None:
            rs = getattr(fused_state, "road_state", None)
        if rs is None:
            return None
        if rs.backend in (BackendKind.NOT_CONFIGURED, BackendKind.NOT_AVAILABLE):
            return None
        return rs

    # -------------------------------------------------------------------
    # Marking info from RoadState
    # -------------------------------------------------------------------

    def _extract_marking_info(
        self, rs: Optional[RoadState],
    ) -> tuple[MarkingType, MarkingStatus, float]:
        """
        Extract lane marking type, status, and confidence from Phase 2 RoadState.
        Returns (MarkingType.UNKNOWN, MarkingStatus.UNKNOWN, 0.0) when unavailable.
        """
        if rs is None:
            return MarkingType.UNKNOWN, MarkingStatus.UNKNOWN, 0.0
        mtype, mstatus = _classify_marking(str(rs.lane_marking))
        conf = float(rs.road_confidence) if rs.road_confidence is not None else 0.0
        return mtype, mstatus, conf

    # -------------------------------------------------------------------
    # Lane geometry from Phase 6.1 road boundaries
    # -------------------------------------------------------------------

    def _build_single_lane_from_road_boundaries(
        self,
        ru: RoadUnderstanding,
        mtype: MarkingType,
        mstatus: MarkingStatus,
        source: str,
    ) -> Optional[LaneDescriptor]:
        """
        When road boundaries are available but no inter-lane separator is
        visible, build a single-lane descriptor using the road edges.
        """
        x_samples = tuple(
            d for d in self.config.forward_distances_m
            if d <= self.config.max_forward_distance_m
        )
        left_rb = ru.left_boundary
        right_rb = ru.right_boundary

        left_lb = None
        right_lb = None
        evidence = EvidenceKind.INFERRED

        if left_rb.available:
            left_lb = _road_boundary_to_lane_boundary(left_rb, "lane_0_left", source)
        if right_rb.available:
            right_lb = _road_boundary_to_lane_boundary(right_rb, "lane_0_right", source)

        if left_lb is None and right_lb is None:
            return None

        centerline = _derive_centerline(left_lb, right_lb, "lane_0", x_samples, evidence)
        width_samples = _estimate_width_samples(
            left_lb, right_lb, "lane_0", x_samples,
            self.config.min_plausible_lane_width_m,
            self.config.max_plausible_lane_width_m,
        )

        avail_bounds = [b for b in (left_lb, right_lb) if b is not None]
        conf = float(np.mean([b.confidence for b in avail_bounds])) if avail_bounds else 0.0

        return LaneDescriptor(
            lane_id="lane_0",
            left_boundary=left_lb,
            right_boundary=right_lb,
            centerline=centerline,
            width_samples=width_samples,
            marking_status=mstatus,
            evidence=evidence,
            confidence=conf,
        )

    def _build_two_lane_from_road_boundaries(
        self,
        ru: RoadUnderstanding,
        road_width: float,
        mtype: MarkingType,
        mstatus: MarkingStatus,
        source: str,
    ) -> list:
        """
        When road is wide enough, split into two lanes using the centroid of
        the road width as the separator.  The separator boundary is always
        EvidenceKind.INFERRED (not painted) unless mstatus == MARKED.
        """
        x_samples = tuple(
            d for d in self.config.forward_distances_m
            if d <= self.config.max_forward_distance_m
        )
        left_rb = ru.left_boundary
        right_rb = ru.right_boundary

        separator_evidence = (
            EvidenceKind.OBSERVED if mstatus == MarkingStatus.MARKED
            else EvidenceKind.INFERRED
        )
        outer_evidence = EvidenceKind.INFERRED

        # Build separator (centre) boundary dynamically at each x
        sep_points: list[LaneBoundaryPoint] = []
        for x in x_samples:
            ly = _interp_boundary_y(left_rb.points, x) if left_rb.available else None
            ry = _interp_boundary_y(right_rb.points, x) if right_rb.available else None
            if ly is not None and ry is not None:
                sep_y = (ly + ry) / 2.0
            elif ly is not None:
                sep_y = ly - road_width / 2.0
            elif ry is not None:
                sep_y = ry + road_width / 2.0
            else:
                continue
            if np.isfinite(sep_y):
                conf_l = _avg_confidence(left_rb.points) if left_rb.available else 0.4
                conf_r = _avg_confidence(right_rb.points) if right_rb.available else 0.4
                sep_points.append(LaneBoundaryPoint(
                    x=float(x), y=float(sep_y),
                    confidence=min(conf_l, conf_r) * 0.8,  # separator less certain
                    evidence=separator_evidence,
                ))

        sep_conf = _avg_confidence(sep_points) if sep_points else 0.0

        sep_boundary_left = LaneBoundary(
            boundary_id="sep_right_of_left_lane",
            side="right",
            points=list(sep_points),
            available=bool(sep_points),
            evidence=separator_evidence,
            marking_type=mtype,
            source=source,
            confidence=sep_conf,
        )
        sep_boundary_right = LaneBoundary(
            boundary_id="sep_left_of_right_lane",
            side="left",
            points=list(sep_points),
            available=bool(sep_points),
            evidence=separator_evidence,
            marking_type=mtype,
            source=source,
            confidence=sep_conf,
        )

        left_outer = _road_boundary_to_lane_boundary(left_rb, "lane_0_left", source) if left_rb.available else None
        right_outer = _road_boundary_to_lane_boundary(right_rb, "lane_1_right", source) if right_rb.available else None

        # Lane 0: left lane (positive Y, ego-relative)
        lane0_cl = _derive_centerline(left_outer, sep_boundary_left, "lane_0", x_samples, EvidenceKind.INFERRED)
        lane0_w = _estimate_width_samples(
            left_outer, sep_boundary_left, "lane_0", x_samples,
            self.config.min_plausible_lane_width_m,
            self.config.max_plausible_lane_width_m,
        )
        conf0 = float(np.mean([b.confidence for b in [left_outer, sep_boundary_left] if b])) if any([left_outer, sep_boundary_left]) else 0.0
        lane0 = LaneDescriptor(
            lane_id="lane_0",
            left_boundary=left_outer,
            right_boundary=sep_boundary_left if sep_boundary_left.available else None,
            centerline=lane0_cl,
            width_samples=lane0_w,
            marking_status=mstatus,
            evidence=EvidenceKind.INFERRED,
            confidence=conf0,
        )

        # Lane 1: right lane (negative Y, ego-relative)
        lane1_cl = _derive_centerline(sep_boundary_right, right_outer, "lane_1", x_samples, EvidenceKind.INFERRED)
        lane1_w = _estimate_width_samples(
            sep_boundary_right, right_outer, "lane_1", x_samples,
            self.config.min_plausible_lane_width_m,
            self.config.max_plausible_lane_width_m,
        )
        conf1 = float(np.mean([b.confidence for b in [sep_boundary_right, right_outer] if b])) if any([sep_boundary_right, right_outer]) else 0.0
        lane1 = LaneDescriptor(
            lane_id="lane_1",
            left_boundary=sep_boundary_right if sep_boundary_right.available else None,
            right_boundary=right_outer,
            centerline=lane1_cl,
            width_samples=lane1_w,
            marking_status=mstatus,
            evidence=EvidenceKind.INFERRED,
            confidence=conf1,
        )

        return [lane0, lane1]

    # -------------------------------------------------------------------
    # Unmarked corridor (village / rural road)
    # -------------------------------------------------------------------

    def _build_unmarked_corridor(
        self,
        ru: RoadUnderstanding,
        source: str,
    ) -> Optional[LaneDescriptor]:
        """
        For roads with no observable lane markings, build a structural
        corridor clearly marked EvidenceKind.INFERRED.  Uses Phase 6.1
        road boundaries as the corridor edges.

        Never claims this is a physically painted lane.
        """
        if not self.config.allow_unmarked_inference:
            return None

        x_samples = tuple(
            d for d in self.config.forward_distances_m
            if d <= self.config.max_forward_distance_m
        )

        left_lb = None
        right_lb = None

        if ru.left_boundary.available:
            left_lb = _road_boundary_to_lane_boundary(
                ru.left_boundary, "corridor_left", source)
        if ru.right_boundary.available:
            right_lb = _road_boundary_to_lane_boundary(
                ru.right_boundary, "corridor_right", source)

        if left_lb is None and right_lb is None:
            return None

        centerline = _derive_centerline(
            left_lb, right_lb, "corridor_0", x_samples,
            EvidenceKind.INFERRED, confidence_scale=0.7,
        )
        width_samples = _estimate_width_samples(
            left_lb, right_lb, "corridor_0", x_samples,
            self.config.min_plausible_lane_width_m,
            self.config.max_plausible_lane_width_m,
            confidence_scale=0.7,
        )

        avail = [b for b in (left_lb, right_lb) if b]
        conf = float(np.mean([b.confidence for b in avail])) * 0.7 if avail else 0.0

        return LaneDescriptor(
            lane_id="corridor_0",
            left_boundary=left_lb,
            right_boundary=right_lb,
            centerline=centerline,
            width_samples=width_samples,
            marking_status=MarkingStatus.UNMARKED,
            evidence=EvidenceKind.INFERRED,
            confidence=conf,
        )

    # -------------------------------------------------------------------
    # Road heading
    # -------------------------------------------------------------------

    def _estimate_road_heading(
        self, lanes: list, ru: Optional[RoadUnderstanding],
    ) -> tuple[Optional[float], float]:
        """
        Estimate road heading from available lane centrelines or road
        boundaries.  Returns (heading_rad, confidence).
        """
        # Prefer centreline of first lane.
        for lane in lanes:
            if lane.centerline and len(lane.centerline.points) >= 2:
                arr = _points_to_np(lane.centerline.points)
                h = _estimate_heading_from_points(arr)
                if h is not None:
                    return h, lane.centerline.confidence * 0.9
        # Fall back to road boundaries from Phase 6.1.
        if ru is not None:
            for rb in (ru.left_boundary, ru.right_boundary):
                if rb.available and len(rb.points) >= 2:
                    arr = _points_to_np(rb.points)
                    h = _estimate_heading_from_points(arr)
                    if h is not None:
                        return h, rb.confidence * 0.7
        return None, 0.0

    # -------------------------------------------------------------------
    # Intersection / road-type hints
    # -------------------------------------------------------------------

    @staticmethod
    def _detect_intersection_hint(
        ru: Optional[RoadUnderstanding],
        warnings: list,
    ) -> IntersectionState:
        """
        Extremely basic structural heuristic: if road boundaries diverge
        dramatically in the forward direction, flag as potential intersection.
        No traffic-rule logic here — structural observation only.
        """
        if ru is None or not (ru.left_boundary.available and ru.right_boundary.available):
            return IntersectionState.UNKNOWN

        widths = [s.width_m for s in ru.road_width_profile if s.width_m is not None]
        if len(widths) < 2:
            return IntersectionState.UNKNOWN

        w_near = widths[0]
        w_far = widths[-1]
        if w_near > 0 and (w_far / w_near) > 2.5:
            warnings.append(
                f"road width diverges from {w_near:.1f}m to {w_far:.1f}m — "
                "possible intersection ahead (structural observation only)"
            )
            return IntersectionState.INTERSECTION
        return IntersectionState.NORMAL_ROAD

    @staticmethod
    def _determine_road_type(
        lane_count: Optional[int],
        mstatus: MarkingStatus,
        road_width: Optional[float],
        config: "LaneStructureConfig",
    ) -> RoadTypeHint:
        if mstatus == MarkingStatus.UNMARKED:
            return RoadTypeHint.UNMARKED_CORRIDOR
        if lane_count == 1:
            if road_width is not None and road_width < config.narrow_road_threshold_m:
                return RoadTypeHint.SINGLE_LANE
            return RoadTypeHint.SINGLE_LANE
        if lane_count is not None and lane_count >= 2:
            return RoadTypeHint.MULTI_LANE
        return RoadTypeHint.UNKNOWN

    # -------------------------------------------------------------------
    # Geometry validation
    # -------------------------------------------------------------------

    @staticmethod
    def _validate_lane_structure(lanes: list, warnings: list) -> bool:
        """
        Return False if any lane has invalid geometry (NaN/Inf).
        Adds a warning per invalid lane rather than silently dropping it.
        """
        ok = True
        for lane in lanes:
            for bnd in (lane.left_boundary, lane.right_boundary):
                if bnd is None:
                    continue
                if not _validate_geometry(bnd.points):
                    warnings.append(f"INVALID geometry in boundary {bnd.boundary_id} — NaN/Inf detected")
                    ok = False
            if lane.centerline and not _validate_geometry(lane.centerline.points):
                warnings.append(f"INVALID geometry in centerline {lane.centerline.lane_id}")
                ok = False
            for ws in lane.width_samples:
                if ws.estimated_width_m is not None and not np.isfinite(ws.estimated_width_m):
                    warnings.append(f"INVALID width in {ws.lane_id} at x={ws.distance_m}")
                    ok = False
        return ok

    # -------------------------------------------------------------------
    # Representative road width
    # -------------------------------------------------------------------

    @staticmethod
    def _road_width_estimate(ru: RoadUnderstanding) -> Optional[float]:
        """Return the mean valid road width from the Phase 6.1 profile."""
        vals = [s.width_m for s in ru.road_width_profile if s.width_m is not None]
        if not vals:
            return None
        w = float(np.mean(vals))
        return w if np.isfinite(w) and w > 0 else None

    # -------------------------------------------------------------------
    # Main entry point
    # -------------------------------------------------------------------

    def process(
        self,
        road_understanding: Optional[RoadUnderstanding] = None,
        road_state: Optional[RoadState] = None,
        perception: Any = None,
        fused_state: Any = None,
        frame_id: Optional[int] = None,
        timestamp: Optional[float] = None,
    ) -> LaneStructure:
        """
        Produce a LaneStructure from available Phase 6.1 + Phase 2 inputs.

        Parameters
        ----------
        road_understanding : Phase 6.1 RoadUnderstanding (preferred input)
        road_state         : Phase 2 RoadState (optional; provides marking info)
        perception         : Phase 2 PerceptionFrame (fallback source for both above)
        fused_state        : Phase 3 FusedWorldState (fallback source)
        frame_id           : int, defaults to 0
        timestamp          : float epoch seconds; defaults to time.time()
        """
        ts = timestamp if timestamp is not None else time.time()
        fid = (
            frame_id
            or getattr(perception, "frame_id", None)
            or getattr(fused_state, "frame_id", None)
            or 0
        )

        # -- disabled -------------------------------------------------------
        if not self.config.enabled:
            return LaneStructure(
                timestamp=ts, frame_id=fid,
                status=LaneStructureStatus.UNAVAILABLE,
                sensor_status={"lane_structure": "DISABLED"},
                warnings=["lane_structure disabled via config (lane_structure.enabled=false)"],
            )

        # -- resolve inputs -------------------------------------------------
        ru, ru_status = self._resolve_road_understanding(
            road_understanding, perception, fused_state, ts)
        rs = self._resolve_road_state(road_state, perception, fused_state)

        camera_ok = rs is not None and rs.road_present
        lidar_ok = ru is not None and ru_status == "OK" and (
            ru.status in (RoadUnderstandingStatus.OK, RoadUnderstandingStatus.PARTIAL)
        )

        sensor_status = {
            "road_understanding": ru_status,
            "road_state": "OK" if rs else "UNAVAILABLE",
        }

        # -- no usable input -----------------------------------------------
        if not lidar_ok and not camera_ok:
            return LaneStructure(
                timestamp=ts, frame_id=fid,
                status=LaneStructureStatus.UNAVAILABLE,
                sensor_status=sensor_status,
                warnings=["no usable road_understanding or road_state input — lane structure unavailable"],
            )

        warnings: list[str] = []
        lanes: list[LaneDescriptor] = []
        mtype = MarkingType.UNKNOWN
        mstatus = MarkingStatus.UNKNOWN
        source = NOT_AVAILABLE

        # -- extract marking info from camera (RoadState) -------------------
        if rs is not None:
            mtype, mstatus, _ = self._extract_marking_info(rs)

        # -- determine source label ----------------------------------------
        if lidar_ok and camera_ok:
            source = "fusion"
        elif lidar_ok:
            source = "lidar"
        else:
            source = "camera"

        # -- CASE 1: lidar/road-understanding available ---------------------
        if lidar_ok and ru is not None:
            road_width = self._road_width_estimate(ru)
            avail = ru.boundary_availability

            # Determine marking status from RoadState if camera present;
            # else default to UNKNOWN (we cannot detect paint without camera).
            if not camera_ok:
                mstatus = MarkingStatus.UNKNOWN

            if mstatus == MarkingStatus.UNMARKED or mstatus == MarkingStatus.UNKNOWN:
                # Build an inferred corridor — not a painted lane.
                corridor = self._build_unmarked_corridor(ru, source)
                if corridor:
                    lanes = [corridor]
                    if mstatus == MarkingStatus.UNKNOWN:
                        warnings.append(
                            "marking status unknown — reporting inferred structural corridor")
            elif mstatus in (MarkingStatus.MARKED, MarkingStatus.WEAKLY_MARKED):
                # Road has markings: try to split into lanes if wide enough.
                if (road_width is not None
                        and road_width >= self.config.min_road_width_for_lane_split_m
                        and avail == BoundaryAvailability.BOTH):
                    lanes = self._build_two_lane_from_road_boundaries(
                        ru, road_width, mtype, mstatus, source)
                else:
                    lane0 = self._build_single_lane_from_road_boundaries(
                        ru, mtype, mstatus, source)
                    if lane0:
                        lanes = [lane0]

            # Fallback if nothing built yet
            if not lanes:
                single = self._build_single_lane_from_road_boundaries(
                    ru, mtype, mstatus, source)
                if single:
                    lanes = [single]
                    warnings.append("insufficient data for multi-lane split; returning single lane")

        # -- CASE 2: camera-only (no metric geometry) -----------------------
        elif camera_ok and rs is not None:
            # No LiDAR geometry — cannot produce metric lane boundaries.
            # Report qualitative marking info only.
            warnings.append(
                "camera-only cycle: no metric geometry available — "
                "reporting qualitative marking status only, no lane boundaries"
            )
            # Emit an empty lane with marking metadata but no geometry.
            lanes = [LaneDescriptor(
                lane_id="lane_0_qualitative",
                marking_status=mstatus,
                evidence=EvidenceKind.UNKNOWN,
                confidence=float(rs.road_confidence),
            )]

        # -- Purge lanes with zero-point boundaries (all points were filtered) --
        valid_lanes = []
        for lane in lanes:
            lb_ok = lane.left_boundary is None or len(lane.left_boundary.points) > 0
            rb_ok = lane.right_boundary is None or len(lane.right_boundary.points) > 0
            has_any_boundary = (
                (lane.left_boundary is not None and len(lane.left_boundary.points) > 0)
                or (lane.right_boundary is not None and len(lane.right_boundary.points) > 0)
                or (lane.centerline is not None and len(lane.centerline.points) > 0)
            )
            if has_any_boundary:
                valid_lanes.append(lane)
            else:
                warnings.append(f"Lane {lane.lane_id} has no valid geometry after filtering — dropped")
        lanes = valid_lanes

        if not lanes and (lidar_ok or camera_ok):
            # All lanes were empty after geometry filtering
            return LaneStructure(
                timestamp=ts, frame_id=fid,
                status=LaneStructureStatus.DEGRADED,
                sensor_status=sensor_status,
                warnings=warnings + ["all lane geometry filtered as empty/invalid"],
            )

        # -- Validate geometry ---------------------------------------------
        geom_ok = self._validate_lane_structure(lanes, warnings)
        if not geom_ok:
            # Purge invalid lanes rather than propagate NaN downstream.
            lanes = [
                lane for lane in lanes
                if (
                    (lane.left_boundary is None or _validate_geometry(lane.left_boundary.points))
                    and (lane.right_boundary is None or _validate_geometry(lane.right_boundary.points))
                    and (lane.centerline is None or _validate_geometry(lane.centerline.points))
                )
            ]
            if not lanes:
                return LaneStructure(
                    timestamp=ts, frame_id=fid,
                    status=LaneStructureStatus.INVALID,
                    sensor_status=sensor_status,
                    warnings=warnings + ["all lane geometry failed validation — returning INVALID"],
                )

        # -- Lane count ---------------------------------------------------
        rs_lane_count: Optional[int] = getattr(rs, "lane_count_estimate", None) if rs else None
        if rs_lane_count is not None:
            lane_count: Optional[int] = rs_lane_count
            lane_count_conf = float(rs.road_confidence) if rs else 0.3
        elif lanes:
            lane_count = len(lanes)
            lane_count_conf = float(np.mean([l.confidence for l in lanes]))
        else:
            lane_count = None
            lane_count_conf = 0.0

        # -- Road heading -------------------------------------------------
        road_heading, heading_conf = self._estimate_road_heading(lanes, ru)

        # -- Intersection hint --------------------------------------------
        intersection_state = self._detect_intersection_hint(ru, warnings)

        # -- Road type hint -----------------------------------------------
        rw_sample = self._road_width_estimate(ru) if ru else None
        road_type = self._determine_road_type(lane_count, mstatus, rw_sample, self.config)

        # -- Overall confidence + status ----------------------------------
        if lanes:
            overall_conf = float(np.mean([l.confidence for l in lanes]))
        else:
            overall_conf = 0.0

        if ru is not None:
            overall_conf = float(min(1.0, overall_conf + 0.05 * ru.confidence))

        if overall_conf < self.config.minimum_confidence:
            status = LaneStructureStatus.DEGRADED
            warnings.append(
                f"confidence {overall_conf:.2f} below minimum_confidence "
                f"{self.config.minimum_confidence:.2f} — status DEGRADED"
            )
        elif not lidar_ok:
            status = LaneStructureStatus.PARTIAL
        elif lanes and all(
            l.left_boundary is not None and l.right_boundary is not None
            and l.left_boundary.available and l.right_boundary.available
            for l in lanes
        ):
            status = LaneStructureStatus.OK
        else:
            status = LaneStructureStatus.PARTIAL

        return LaneStructure(
            timestamp=ts,
            frame_id=fid,
            status=status,
            lanes=lanes,
            lane_count=lane_count,
            lane_count_confidence=lane_count_conf,
            road_heading_rad=road_heading,
            road_heading_confidence=heading_conf,
            marking_status=mstatus,
            road_type=road_type,
            intersection_state=intersection_state,
            confidence=overall_conf,
            uncertainty=float(max(0.0, min(1.0, 1.0 - overall_conf))),
            source=source,
            sensor_status=sensor_status,
            warnings=warnings,
        )
