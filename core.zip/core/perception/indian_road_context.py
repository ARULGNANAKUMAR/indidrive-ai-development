"""
IndiDrive AI — Phase 6.4 | Indian-Road Context Fusion
================================================================================
Deterministic, lightweight context-fusion layer that combines Phase 6.1 / 6.2 /
6.3 outputs with the Phase 3 FusedWorldState to produce an
``IndianRoadContextState`` — a structured description of what kind of Indian
road environment the vehicle is currently operating in.

Pipeline per frame
------------------
  Phase 6.1 RoadUnderstanding
  Phase 6.2 LaneStructure
  Phase 6.3 RoadAnomalyState
  Phase 3   FusedWorldState (objects, road_state, fusion_mode)
  Optional  ScenarioContext (metadata — used only as soft evidence)
       ↓
  1. Validate / normalise upstream inputs
       ↓
  2. Derive road-marking state           — from Phase 6.2, with conflict handling
       ↓
  3. Derive road-width category          — from Phase 6.1, with thresholds from config
       ↓
  4. Derive intersection context         — Phase 6.2 structural + perception
       ↓
  5. Summarise road-damage context       — from Phase 6.3 (read-only)
       ↓
  6. Derive traffic context              — density + mix from FusedWorldState.objects
       ↓
  7. Derive VRU / animal context         — from objects
       ↓
  8. Derive roadside activity            — from objects
       ↓
  9. Classify road type                  — deterministic rule engine
       ↓
 10. Estimate road complexity            — weighted score
       ↓
 11. Set context flags                   — from all derived values
       ↓
 12. Aggregate confidence + uncertainty  — transparent aggregation
       ↓
 13. Update temporal stability           — rolling window
       ↓
 14. Apply scenario metadata (soft)      — only as supplementary evidence
       ↓
 15. Build IndianRoadContextState

Scope limits (DO NOT add beyond Phase 6.4)
------------------------------------------
  ✗  no path planning, MPC, steering, braking
  ✗  no Phase 3 / 5 / 6.1 / 6.2 / 6.3 mutation
  ✗  no LLMs, cloud APIs, vector databases, deep learning
  ✗  no geographic name inference (no city/district claims)
  ✗  no "scenario cheating" — sensor context ≠ scenario label

API
---
    engine = IndianRoadContextEngine()
    # or with config dict:
    engine = IndianRoadContextEngine(config={"road_width": {"narrow_threshold_m": 5.5}})

    state: IndianRoadContextState = engine.process(
        fused_world_state=fws,          # Phase 3 (required)
        road_understanding=rud,         # Phase 6.1 (optional)
        lane_structure=ls,              # Phase 6.2 (optional)
        road_anomaly_state=ras,         # Phase 6.3 (optional)
        frame_id=frame_id,
        timestamp=timestamp,
        scenario_context=None,          # dict of metadata hints (optional)
    )

Coordinate frame: +X forward, +Y left, +Z up, origin rear-axle centre (m).
"""
from __future__ import annotations

import math
import time
from collections import deque
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Sequence, Tuple

from .perception_types import NOT_AVAILABLE
from .indian_road_context_types import (
    ContextEngineStatus,
    RoadType,
    RoadWidthCategory,
    RoadMarkingState,
    IntersectionContext,
    RoadDamageContext,
    TrafficDensity,
    VRUPresence,
    AnimalActivity,
    RoadComplexity,
    ContextStability,
    ContextFlag,
    TrafficMixSummary,
    RoadsideActivitySummary,
    RoadDamageSummary,
    EvidenceItem,
    SensorStatusSummary,
    IndianRoadContextState,
)

# Phase 6.1 types
from .road_understanding_types import (
    RoadUnderstanding,
    RoadUnderstandingStatus,
    BoundaryAvailability,
)
# Phase 6.2 types
from .lane_structure_types import (
    LaneStructure,
    LaneStructureStatus,
    MarkingStatus,
    RoadTypeHint,
    IntersectionState as LaneIntersectionState,
)
# Phase 6.3 types
from .road_anomaly_types import (
    RoadAnomalyState,
    AnomalyEngineStatus,
    AnomalyType,
    AnomalySeverity,
    RoadSurfaceQuality,
)

try:
    from core.fusion.fusion_types import FusedWorldState, FusionMode
    _FUSION_TYPES_AVAILABLE = True
except ImportError:
    _FUSION_TYPES_AVAILABLE = False
    FusedWorldState = None  # type: ignore
    FusionMode = None       # type: ignore

try:
    from core.logging_system import get_logger
    _logger = get_logger("phase_6_4")
except Exception:
    _logger = None


# ---------------------------------------------------------------------------
# Default configuration
# ---------------------------------------------------------------------------

_DEFAULT_CONFIG: Dict[str, Any] = {
    "road_width": {
        # Thresholds in metres; derived from Indian road standards + field data
        "very_narrow_threshold_m": 3.5,   # < 3.5 m → VERY_NARROW
        "narrow_threshold_m": 5.5,        # < 5.5 m → NARROW
        "normal_threshold_m": 8.0,        # < 8.0 m → NORMAL
        "wide_threshold_m": 12.0,         # < 12.0 m → WIDE;  >= 12 → VERY_WIDE
    },
    "traffic_density": {
        # Object counts within detection range to classify density
        "very_low_max": 1,
        "low_max": 3,
        "medium_max": 7,
        "high_max": 14,
        # >= high_max+1 → VERY_HIGH
    },
    "vru": {
        "vru_classes": ["pedestrian", "bicycle", "cattle", "animal"],
        "multiple_threshold": 2,
    },
    "animal_classes": ["cattle", "animal"],
    "two_wheeler_classes": ["motorcycle", "scooter", "bicycle"],
    "auto_rickshaw_classes": ["auto_rickshaw"],
    "heavy_vehicle_classes": ["bus", "truck", "tractor"],
    "road_type": {
        # Thresholds used in rule-based road type classifier
        "highway_min_width_m": 9.0,       # >= this → highway evidence
        "highway_min_lanes": 2,
        "market_min_object_count": 4,     # >= this for market-like classification
        "market_pedestrian_min": 2,
        "narrow_max_width_m": 5.5,        # <= this → NARROW evidence
        "village_max_lane_count": 1,      # <= 1 lane → village evidence
    },
    "complexity": {
        # Complexity score weights for each evidence type
        "w_unmarked": 1.2,
        "w_narrow": 0.9,
        "w_anomaly_count_per_anomaly": 0.4,    # per anomaly (capped)
        "w_anomaly_count_cap": 4.0,            # max contribution from anomaly count
        "w_high_severity_per": 0.6,            # per high-severity anomaly (capped)
        "w_high_severity_cap": 2.4,
        "w_high_traffic": 0.8,
        "w_heterogeneous_traffic": 0.5,
        "w_vru": 0.7,
        "w_intersection": 0.6,
        "w_complex_intersection": 1.0,
        "w_weak_boundaries": 0.8,
        "w_weak_lane_structure": 0.5,
        "w_construction": 0.9,
        "w_sensor_degraded": 0.4,
        # Complexity thresholds
        "medium_threshold": 1.5,
        "high_threshold": 3.5,
        "very_high_threshold": 5.5,
    },
    "stability": {
        "stable_frame_count": 3,          # consecutive frames required for STABLE
        "history_size": 8,               # rolling window of past road types
    },
    "confidence": {
        "base": 0.5,
        "phase61_ok_bonus": 0.15,
        "phase62_ok_bonus": 0.15,
        "phase63_ok_bonus": 0.10,
        "fws_ok_bonus": 0.10,
        "degraded_penalty": 0.20,
        "conflict_penalty": 0.10,
    },
    "boundary_confidence": {
        "weak_threshold": 0.35,          # below this → weak_boundaries = True
    },
    "market_context": {
        # Evidence rule: at least these many distinct activity types for market-like
        "min_activity_types": 3,
        "min_object_count": 4,
    },
}


# ---------------------------------------------------------------------------
# Scenario context parsing (soft evidence only)
# ---------------------------------------------------------------------------

def _parse_scenario_hints(scenario_context: Optional[dict]) -> Dict[str, Any]:
    """
    Extract lightweight boolean hints from a scenario metadata dict.

    These are SOFT evidence only — they never override sensor-derived values.
    Returns a dict of hint flags; absent key = no hint.

    No scenario cheating: cattle_expected ≠ cattle_present.
    """
    if not scenario_context or not isinstance(scenario_context, dict):
        return {}
    hints: Dict[str, Any] = {}
    tags = scenario_context.get("tags", []) or []
    tags_lower = [str(t).lower() for t in tags]
    tag_str = " ".join(tags_lower)

    if any(kw in tag_str for kw in ("village", "rural", "kachcha")):
        hints["village_hint"] = True
    if any(kw in tag_str for kw in ("market", "bazaar", "commercial")):
        hints["market_hint"] = True
    if any(kw in tag_str for kw in ("highway", "nh", "sh", "expressway")):
        hints["highway_hint"] = True
    if any(kw in tag_str for kw in ("construction", "roadwork", "building")):
        hints["construction_hint"] = True
    if any(kw in tag_str for kw in ("cattle", "animal", "cow", "buffalo")):
        hints["cattle_expected"] = True   # ≠ sensor observation
    if any(kw in tag_str for kw in ("night", "dark")):
        hints["night"] = True
    if any(kw in tag_str for kw in ("rain", "wet", "flood")):
        hints["rain"] = True
    return hints


# ---------------------------------------------------------------------------
# IndianRoadContextConfig
# ---------------------------------------------------------------------------

@dataclass
class IndianRoadContextConfig:
    """
    Typed config wrapper so thresholds come from config, not hard-coded magic
    numbers scattered through the engine.  Constructed from a nested dict.
    """
    # Road width thresholds
    very_narrow_threshold_m: float = 3.5
    narrow_threshold_m: float = 5.5
    normal_threshold_m: float = 8.0
    wide_threshold_m: float = 12.0

    # Traffic density thresholds (object counts)
    traffic_very_low_max: int = 1
    traffic_low_max: int = 3
    traffic_medium_max: int = 7
    traffic_high_max: int = 14

    # VRU / animal classes
    vru_classes: List[str] = field(default_factory=lambda: ["pedestrian", "bicycle", "cattle", "animal"])
    animal_classes: List[str] = field(default_factory=lambda: ["cattle", "animal"])
    multiple_vru_threshold: int = 2
    two_wheeler_classes: List[str] = field(default_factory=lambda: ["motorcycle", "scooter", "bicycle"])
    auto_rickshaw_classes: List[str] = field(default_factory=lambda: ["auto_rickshaw"])
    heavy_vehicle_classes: List[str] = field(default_factory=lambda: ["bus", "truck", "tractor"])

    # Road type thresholds
    highway_min_width_m: float = 9.0
    highway_min_lanes: int = 2
    market_min_object_count: int = 4
    market_pedestrian_min: int = 2
    narrow_max_width_m: float = 5.5
    village_max_lane_count: int = 1

    # Complexity weights
    w_unmarked: float = 1.2
    w_narrow: float = 0.9
    w_anomaly_count_per: float = 0.4
    w_anomaly_count_cap: float = 4.0
    w_high_severity_per: float = 0.6
    w_high_severity_cap: float = 2.4
    w_high_traffic: float = 0.8
    w_heterogeneous_traffic: float = 0.5
    w_vru: float = 0.7
    w_intersection: float = 0.6
    w_complex_intersection: float = 1.0
    w_weak_boundaries: float = 0.8
    w_weak_lane_structure: float = 0.5
    w_construction: float = 0.9
    w_sensor_degraded: float = 0.4
    complexity_medium_threshold: float = 1.5
    complexity_high_threshold: float = 3.5
    complexity_very_high_threshold: float = 5.5

    # Temporal stability
    stable_frame_count: int = 3
    history_size: int = 8

    # Confidence aggregation
    conf_base: float = 0.5
    conf_phase61_ok: float = 0.15
    conf_phase62_ok: float = 0.15
    conf_phase63_ok: float = 0.10
    conf_fws_ok: float = 0.10
    conf_degraded_penalty: float = 0.20
    conf_conflict_penalty: float = 0.10

    # Boundary / lane weakness thresholds
    boundary_weak_confidence_threshold: float = 0.35
    lane_weak_confidence_threshold: float = 0.35

    # Market context rules
    market_min_activity_types: int = 3

    @classmethod
    def from_dict(cls, cfg: Dict[str, Any]) -> "IndianRoadContextConfig":
        """Build from a nested config dict (same structure as _DEFAULT_CONFIG)."""
        c = cls()
        rw = cfg.get("road_width", {})
        c.very_narrow_threshold_m = float(rw.get("very_narrow_threshold_m", c.very_narrow_threshold_m))
        c.narrow_threshold_m = float(rw.get("narrow_threshold_m", c.narrow_threshold_m))
        c.normal_threshold_m = float(rw.get("normal_threshold_m", c.normal_threshold_m))
        c.wide_threshold_m = float(rw.get("wide_threshold_m", c.wide_threshold_m))

        td = cfg.get("traffic_density", {})
        c.traffic_very_low_max = int(td.get("very_low_max", c.traffic_very_low_max))
        c.traffic_low_max = int(td.get("low_max", c.traffic_low_max))
        c.traffic_medium_max = int(td.get("medium_max", c.traffic_medium_max))
        c.traffic_high_max = int(td.get("high_max", c.traffic_high_max))

        vru = cfg.get("vru", {})
        c.vru_classes = list(vru.get("vru_classes", c.vru_classes))
        c.multiple_vru_threshold = int(vru.get("multiple_threshold", c.multiple_vru_threshold))
        c.animal_classes = list(cfg.get("animal_classes", c.animal_classes))
        c.two_wheeler_classes = list(cfg.get("two_wheeler_classes", c.two_wheeler_classes))
        c.auto_rickshaw_classes = list(cfg.get("auto_rickshaw_classes", c.auto_rickshaw_classes))
        c.heavy_vehicle_classes = list(cfg.get("heavy_vehicle_classes", c.heavy_vehicle_classes))

        rt = cfg.get("road_type", {})
        c.highway_min_width_m = float(rt.get("highway_min_width_m", c.highway_min_width_m))
        c.highway_min_lanes = int(rt.get("highway_min_lanes", c.highway_min_lanes))
        c.market_min_object_count = int(rt.get("market_min_object_count", c.market_min_object_count))
        c.market_pedestrian_min = int(rt.get("market_pedestrian_min", c.market_pedestrian_min))
        c.narrow_max_width_m = float(rt.get("narrow_max_width_m", c.narrow_max_width_m))
        c.village_max_lane_count = int(rt.get("village_max_lane_count", c.village_max_lane_count))

        comp = cfg.get("complexity", {})
        c.w_unmarked = float(comp.get("w_unmarked", c.w_unmarked))
        c.w_narrow = float(comp.get("w_narrow", c.w_narrow))
        c.w_anomaly_count_per = float(comp.get("w_anomaly_count_per_anomaly", c.w_anomaly_count_per))
        c.w_anomaly_count_cap = float(comp.get("w_anomaly_count_cap", c.w_anomaly_count_cap))
        c.w_high_severity_per = float(comp.get("w_high_severity_per", c.w_high_severity_per))
        c.w_high_severity_cap = float(comp.get("w_high_severity_cap", c.w_high_severity_cap))
        c.w_high_traffic = float(comp.get("w_high_traffic", c.w_high_traffic))
        c.w_heterogeneous_traffic = float(comp.get("w_heterogeneous_traffic", c.w_heterogeneous_traffic))
        c.w_vru = float(comp.get("w_vru", c.w_vru))
        c.w_intersection = float(comp.get("w_intersection", c.w_intersection))
        c.w_complex_intersection = float(comp.get("w_complex_intersection", c.w_complex_intersection))
        c.w_weak_boundaries = float(comp.get("w_weak_boundaries", c.w_weak_boundaries))
        c.w_weak_lane_structure = float(comp.get("w_weak_lane_structure", c.w_weak_lane_structure))
        c.w_construction = float(comp.get("w_construction", c.w_construction))
        c.w_sensor_degraded = float(comp.get("w_sensor_degraded", c.w_sensor_degraded))
        c.complexity_medium_threshold = float(comp.get("medium_threshold", c.complexity_medium_threshold))
        c.complexity_high_threshold = float(comp.get("high_threshold", c.complexity_high_threshold))
        c.complexity_very_high_threshold = float(comp.get("very_high_threshold", c.complexity_very_high_threshold))

        stab = cfg.get("stability", {})
        c.stable_frame_count = int(stab.get("stable_frame_count", c.stable_frame_count))
        c.history_size = int(stab.get("history_size", c.history_size))

        conf = cfg.get("confidence", {})
        c.conf_base = float(conf.get("base", c.conf_base))
        c.conf_phase61_ok = float(conf.get("phase61_ok_bonus", c.conf_phase61_ok))
        c.conf_phase62_ok = float(conf.get("phase62_ok_bonus", c.conf_phase62_ok))
        c.conf_phase63_ok = float(conf.get("phase63_ok_bonus", c.conf_phase63_ok))
        c.conf_fws_ok = float(conf.get("fws_ok_bonus", c.conf_fws_ok))
        c.conf_degraded_penalty = float(conf.get("degraded_penalty", c.conf_degraded_penalty))
        c.conf_conflict_penalty = float(conf.get("conflict_penalty", c.conf_conflict_penalty))

        bc = cfg.get("boundary_confidence", {})
        c.boundary_weak_confidence_threshold = float(
            bc.get("weak_threshold", c.boundary_weak_confidence_threshold))

        mc = cfg.get("market_context", {})
        c.market_min_activity_types = int(mc.get("min_activity_types", c.market_min_activity_types))

        return c


# ---------------------------------------------------------------------------
# IndianRoadContextEngine
# ---------------------------------------------------------------------------

class IndianRoadContextEngine:
    """
    Phase 6.4 — Indian-Road Context Fusion Engine.

    Reads Phase 6.1 / 6.2 / 6.3 / FusedWorldState as read-only inputs.
    Never mutates upstream state.
    Never calls planners / controllers / memory.
    """

    def __init__(self, config: Optional[Dict[str, Any]] = None) -> None:
        # Merge user config over defaults
        merged = {**_DEFAULT_CONFIG}
        if config:
            for section, values in config.items():
                if isinstance(values, dict) and section in merged:
                    merged[section] = {**merged[section], **values}
                else:
                    merged[section] = values
        self._cfg = IndianRoadContextConfig.from_dict(merged)

        # Temporal stability — rolling history of classified road_type strings
        self._road_type_history: deque[RoadType] = deque(maxlen=self._cfg.history_size)
        self._last_stable_road_type: RoadType = RoadType.UNKNOWN
        self._stable_frame_count: int = 0
        self._last_state: Optional[IndianRoadContextState] = None

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def process(
        self,
        fused_world_state: Optional[Any] = None,
        road_understanding: Optional[RoadUnderstanding] = None,
        lane_structure: Optional[LaneStructure] = None,
        road_anomaly_state: Optional[RoadAnomalyState] = None,
        frame_id: int = 0,
        timestamp: Optional[float] = None,
        scenario_context: Optional[dict] = None,
    ) -> IndianRoadContextState:
        """
        Fuse upstream phase outputs into one IndianRoadContextState.

        All upstream inputs are treated as read-only.
        scenario_context is optional soft-evidence metadata; sensor-derived
        values take precedence.
        """
        if timestamp is None:
            timestamp = time.time()

        # 1. Validate / normalise inputs
        rud, ls, ras, fws = self._normalise_inputs(
            road_understanding, lane_structure, road_anomaly_state, fused_world_state
        )

        # 2. Build sensor status
        sensor_status = self._build_sensor_status(rud, ls, ras, fws)

        # Early-exit when nothing is available
        if not any([
            sensor_status.road_understanding_available,
            sensor_status.lane_structure_available,
            sensor_status.road_anomaly_available,
            sensor_status.fused_world_state_available,
        ]):
            state = self._unavailable_state(timestamp, frame_id, sensor_status)
            self._update_stability(state)
            return state

        warnings: List[str] = []
        evidence: List[EvidenceItem] = []
        conflict_count = 0

        # 3. Marking state
        marking_state, marking_conf, mc_conflict = self._derive_marking_state(ls, warnings)
        if mc_conflict:
            conflict_count += 1

        # 4. Road-width category
        width_m, width_cat, width_ev = self._derive_road_width(rud, ls, evidence)

        # 5. Intersection context
        intersection_ctx = self._derive_intersection(ls, fws)

        # 6. Road-damage summary
        damage_summary = self._build_damage_summary(ras)

        # 7. Traffic context
        traffic_density, traffic_mix = self._derive_traffic(fws)

        # 8. VRU / animal context
        vru_presence, animal_present, animal_activity = self._derive_vru(fws)

        # 9. Roadside activity
        roadside_activity = self._derive_roadside_activity(fws)

        # 10. Boundary quality
        weak_boundaries = self._derive_weak_boundaries(rud)

        # 11. Weak lane structure
        weak_lane_structure = self._derive_weak_lane_structure(ls)

        # 12. Road-type classification
        rt_hints = _parse_scenario_hints(scenario_context)
        road_type, rt_confidence, rt_evidence = self._classify_road_type(
            width_m=width_m,
            width_cat=width_cat,
            marking_state=marking_state,
            lane_count=ls.lane_count if ls else None,
            lane_count_confidence=ls.lane_count_confidence if ls else 0.0,
            intersection_ctx=intersection_ctx,
            damage_summary=damage_summary,
            traffic_density=traffic_density,
            traffic_mix=traffic_mix,
            vru_presence=vru_presence,
            animal_present=animal_present,
            roadside_activity=roadside_activity,
            weak_boundaries=weak_boundaries,
            rt_hints=rt_hints,
            warnings=warnings,
        )
        evidence.extend(rt_evidence)

        # 13. Road complexity
        complexity, complexity_score, cx_evidence = self._derive_complexity(
            marking_state=marking_state,
            width_cat=width_cat,
            damage_summary=damage_summary,
            traffic_density=traffic_density,
            traffic_mix=traffic_mix,
            vru_presence=vru_presence,
            intersection_ctx=intersection_ctx,
            weak_boundaries=weak_boundaries,
            weak_lane_structure=weak_lane_structure,
            sensor_degraded=sensor_status.any_degraded,
        )
        evidence.extend(cx_evidence)

        # 14. Confidence aggregation
        confidence, uncertainty = self._derive_confidence(
            sensor_status=sensor_status,
            rud=rud, ls=ls, ras=ras,
            conflict_count=conflict_count,
            marking_conf=marking_conf,
        )

        # 15. Context flags
        context_flags = self._build_flags(
            marking_state=marking_state,
            width_cat=width_cat,
            traffic_density=traffic_density,
            vru_presence=vru_presence,
            animal_present=animal_present,
            damage_summary=damage_summary,
            intersection_ctx=intersection_ctx,
            weak_boundaries=weak_boundaries,
            weak_lane_structure=weak_lane_structure,
            complexity=complexity,
            sensor_degraded=sensor_status.any_degraded,
            uncertainty=uncertainty,
            road_type=road_type,
        )

        # 16. Status
        status = self._determine_status(sensor_status, confidence)

        # 17. Source summary
        sources = []
        if rud is not None:
            sources.append("6.1:road_understanding")
        if ls is not None:
            sources.append("6.2:lane_structure")
        if ras is not None:
            sources.append("6.3:road_anomaly")
        if fws is not None:
            sources.append("3:fused_world")
        source_summary = "+".join(sources) if sources else NOT_AVAILABLE

        # 18. Lane count / heading
        lane_count = ls.lane_count if ls else None
        lane_count_conf = ls.lane_count_confidence if ls else 0.0
        rt_hint_val = ls.road_type.value if ls else NOT_AVAILABLE
        ba_val = rud.boundary_availability.value if rud else NOT_AVAILABLE

        state = IndianRoadContextState(
            timestamp=timestamp,
            frame_id=frame_id,
            status=status,
            road_type=road_type,
            road_type_confidence=rt_confidence,
            road_marking_state=marking_state,
            estimated_road_width_m=width_m,
            road_width_category=width_cat,
            lane_count=lane_count,
            lane_count_confidence=lane_count_conf,
            road_type_hint=rt_hint_val,
            boundary_availability=ba_val,
            weak_boundaries=weak_boundaries,
            intersection_context=intersection_ctx,
            road_damage_summary=damage_summary,
            traffic_density=traffic_density,
            traffic_mix=traffic_mix,
            vru_presence=vru_presence,
            animal_present=animal_present,
            animal_activity=animal_activity,
            roadside_activity=roadside_activity,
            road_complexity=complexity,
            complexity_score=round(complexity_score, 4),
            context_flags=context_flags,
            confidence=round(confidence, 4),
            uncertainty=round(uncertainty, 4),
            sensor_status=sensor_status,
            degraded=sensor_status.any_degraded,
            evidence_items=evidence,
            source_summary=source_summary,
            warnings=warnings,
        )

        # 19. Temporal stability
        self._update_stability(state)
        self._last_state = state
        return state

    def get_state(self) -> Optional[IndianRoadContextState]:
        """Return the most recently computed state, or None."""
        return self._last_state

    def reset(self) -> None:
        """Reset temporal stability state."""
        self._road_type_history.clear()
        self._last_stable_road_type = RoadType.UNKNOWN
        self._stable_frame_count = 0
        self._last_state = None

    # ------------------------------------------------------------------
    # Step 1: Input normalisation
    # ------------------------------------------------------------------

    def _normalise_inputs(
        self,
        rud: Any,
        ls: Any,
        ras: Any,
        fws: Any,
    ) -> Tuple[Optional[RoadUnderstanding], Optional[LaneStructure],
               Optional[RoadAnomalyState], Optional[Any]]:
        """Validate upstream inputs; return None for anything unusable."""
        safe_rud = rud if isinstance(rud, RoadUnderstanding) else None
        safe_ls = ls if isinstance(ls, LaneStructure) else None
        safe_ras = ras if isinstance(ras, RoadAnomalyState) else None
        # FusedWorldState: duck-type check (handles missing import)
        if fws is not None and hasattr(fws, "objects") and hasattr(fws, "fusion_mode"):
            safe_fws = fws
        else:
            safe_fws = None
        return safe_rud, safe_ls, safe_ras, safe_fws

    # ------------------------------------------------------------------
    # Step 2: Sensor status
    # ------------------------------------------------------------------

    def _build_sensor_status(
        self,
        rud: Optional[RoadUnderstanding],
        ls: Optional[LaneStructure],
        ras: Optional[RoadAnomalyState],
        fws: Optional[Any],
    ) -> SensorStatusSummary:
        s = SensorStatusSummary()
        s.road_understanding_available = (
            rud is not None
            and rud.status not in (
                RoadUnderstandingStatus.UNAVAILABLE,
                RoadUnderstandingStatus.INVALID,
            )
        )
        s.lane_structure_available = (
            ls is not None
            and ls.status not in (
                LaneStructureStatus.UNAVAILABLE,
                LaneStructureStatus.INVALID,
            )
        )
        s.road_anomaly_available = (
            ras is not None
            and ras.status not in (
                AnomalyEngineStatus.UNAVAILABLE,
                AnomalyEngineStatus.INVALID,
            )
        )
        s.fused_world_state_available = fws is not None

        degraded = False
        if rud and rud.status in (
            RoadUnderstandingStatus.DEGRADED,
            RoadUnderstandingStatus.PARTIAL,
        ):
            degraded = True
        if ls and ls.status in (
            LaneStructureStatus.DEGRADED,
            LaneStructureStatus.PARTIAL,
        ):
            degraded = True
        if ras and ras.status in (
            AnomalyEngineStatus.DEGRADED,
            AnomalyEngineStatus.PARTIAL,
        ):
            degraded = True
        if fws is not None:
            fm = getattr(fws, "fusion_mode", None)
            if _FUSION_TYPES_AVAILABLE and fm in (
                FusionMode.SINGLE_SENSOR,
                FusionMode.NO_VALID_SENSOR,
            ):
                degraded = True

        s.any_degraded = degraded

        # Aggregate sensor_details from all available upstream modules
        details: dict = {}
        if rud:
            details.update(rud.sensor_status or {})
        if ls:
            details.update(ls.sensor_status or {})
        if ras:
            details.update(ras.sensor_status or {})
        s.sensor_details = details
        return s

    # ------------------------------------------------------------------
    # Step 3: Marking state
    # ------------------------------------------------------------------

    def _derive_marking_state(
        self,
        ls: Optional[LaneStructure],
        warnings: List[str],
    ) -> Tuple[RoadMarkingState, float, bool]:
        """
        Return (marking_state, confidence, conflict_detected).

        Phase 6.2 MarkingStatus is the authoritative source.
        If Phase 6.2 is unavailable, marking_state = UNKNOWN.
        """
        if ls is None or ls.status in (
            LaneStructureStatus.UNAVAILABLE,
            LaneStructureStatus.INVALID,
        ):
            return RoadMarkingState.UNKNOWN, 0.0, False

        ms = ls.marking_status
        _MAP = {
            MarkingStatus.MARKED:        RoadMarkingState.MARKED,
            MarkingStatus.WEAKLY_MARKED: RoadMarkingState.WEAKLY_MARKED,
            MarkingStatus.UNMARKED:      RoadMarkingState.UNMARKED,
            MarkingStatus.UNKNOWN:       RoadMarkingState.UNKNOWN,
        }
        return _MAP.get(ms, RoadMarkingState.UNKNOWN), ls.confidence, False

    # ------------------------------------------------------------------
    # Step 4: Road-width category
    # ------------------------------------------------------------------

    def _derive_road_width(
        self,
        rud: Optional[RoadUnderstanding],
        ls: Optional[LaneStructure],
        evidence: List[EvidenceItem],
    ) -> Tuple[Optional[float], RoadWidthCategory, List[EvidenceItem]]:
        """
        Derive estimated_road_width_m and its category.

        Priority:
          1. Phase 6.1 road_width_profile (metrically observed)
          2. Phase 6.2 lane width samples  (inferred)
          3. Phase 6.2 lane count × typical lane width (heuristic, low confidence)
        """
        width_m: Optional[float] = None
        local_evidence: List[EvidenceItem] = []

        # --- Source 1: Phase 6.1 road width profile ---
        if rud and rud.road_width_profile:
            widths = [
                s.width_m for s in rud.road_width_profile
                if s.width_m is not None and s.width_m > 0
            ]
            if widths:
                width_m = float(sum(widths) / len(widths))
                local_evidence.append(EvidenceItem(
                    "road_width_from_phase61_profile",
                    f"{width_m:.2f} m (avg of {len(widths)} samples)",
                    weight=1.0,
                ))

        # --- Source 2: Phase 6.2 lane-width samples ---
        if width_m is None and ls and ls.lanes:
            all_w: List[float] = []
            for lane in ls.lanes:
                for ws in (lane.width_samples or []):
                    if ws.estimated_width_m is not None and ws.estimated_width_m > 0:
                        all_w.append(ws.estimated_width_m)
            if all_w:
                # lane widths → total road width approximation (all lanes)
                total_lanes = ls.lane_count or len(ls.lanes)
                avg_lane_w = sum(all_w) / len(all_w)
                width_m = avg_lane_w * total_lanes
                local_evidence.append(EvidenceItem(
                    "road_width_from_lane_widths",
                    f"{width_m:.2f} m ({total_lanes} lanes × {avg_lane_w:.2f} m)",
                    weight=0.7,
                ))

        # --- Source 3: Phase 6.1 boundary lateral spread ---
        if width_m is None and rud and rud.left_boundary.available and rud.right_boundary.available:
            left_pts = rud.left_boundary.points
            right_pts = rud.right_boundary.points
            if left_pts and right_pts:
                left_ys = [p.y for p in left_pts]
                right_ys = [p.y for p in right_pts]
                span = abs(sum(left_ys) / len(left_ys) - sum(right_ys) / len(right_ys))
                if span > 0.5:
                    width_m = span
                    local_evidence.append(EvidenceItem(
                        "road_width_from_boundary_spread",
                        f"{width_m:.2f} m (boundary lateral span)",
                        weight=0.6,
                    ))

        # Map to category
        cat = self._width_to_category(width_m)

        evidence.extend(local_evidence)
        return width_m, cat, local_evidence

    def _width_to_category(self, width_m: Optional[float]) -> RoadWidthCategory:
        if width_m is None:
            return RoadWidthCategory.UNKNOWN
        c = self._cfg
        if width_m < c.very_narrow_threshold_m:
            return RoadWidthCategory.VERY_NARROW
        if width_m < c.narrow_threshold_m:
            return RoadWidthCategory.NARROW
        if width_m < c.normal_threshold_m:
            return RoadWidthCategory.NORMAL
        if width_m < c.wide_threshold_m:
            return RoadWidthCategory.WIDE
        return RoadWidthCategory.VERY_WIDE

    # ------------------------------------------------------------------
    # Step 5: Intersection context
    # ------------------------------------------------------------------

    def _derive_intersection(
        self,
        ls: Optional[LaneStructure],
        fws: Optional[Any],
    ) -> IntersectionContext:
        """
        Derive intersection context from Phase 6.2 structural information
        and, secondarily, from object density (multiple converging directions).
        """
        if ls is None or ls.status in (
            LaneStructureStatus.UNAVAILABLE,
            LaneStructureStatus.INVALID,
        ):
            return IntersectionContext.UNKNOWN

        phase62_state = ls.intersection_state
        if phase62_state == LaneIntersectionState.INTERSECTION:
            # Upgrade to complex if many objects / multiple boundaries observed
            if fws is not None:
                n_obj = len(fws.objects)
                if n_obj >= self._cfg.market_min_object_count:
                    return IntersectionContext.COMPLEX_INTERSECTION
            # Check lane count: complex if many lanes merge
            if ls.lane_count is not None and ls.lane_count > 3:
                return IntersectionContext.COMPLEX_INTERSECTION
            return IntersectionContext.INTERSECTION

        if phase62_state == LaneIntersectionState.NORMAL_ROAD:
            return IntersectionContext.NO_INTERSECTION

        if phase62_state == LaneIntersectionState.UNKNOWN:
            # If lane count is uncertain but multiple road boundaries exist
            if ls.status == LaneStructureStatus.PARTIAL:
                return IntersectionContext.POSSIBLE_INTERSECTION
            return IntersectionContext.UNKNOWN

        return IntersectionContext.UNKNOWN

    # ------------------------------------------------------------------
    # Step 6: Road-damage summary
    # ------------------------------------------------------------------

    def _build_damage_summary(
        self,
        ras: Optional[RoadAnomalyState],
    ) -> RoadDamageSummary:
        """
        Summarise Phase 6.3 output without duplicating the full anomaly list.
        """
        ds = RoadDamageSummary()
        if ras is None or ras.status in (
            AnomalyEngineStatus.UNAVAILABLE,
            AnomalyEngineStatus.INVALID,
        ):
            return ds

        ds.confidence = ras.overall_confidence
        ds.anomaly_count = len(ras.anomalies)

        high_sev = 0
        for a in ras.anomalies:
            if a.severity in (AnomalySeverity.HIGH, AnomalySeverity.CRITICAL):
                high_sev += 1
            if a.affects_drivable_area:
                ds.drivable_area_overlap = True
            if a.near_road_edge:
                ds.road_edge_damage = True
            if a.anomaly_type == AnomalyType.WATER_DAMAGE:
                ds.water_damage = True
            if a.anomaly_type in (
                AnomalyType.DAMAGED_SURFACE,
                AnomalyType.CRACK,
                AnomalyType.UNEVEN_SURFACE,
            ):
                ds.surface_damage = True
            if a.anomaly_type in (
                AnomalyType.CONSTRUCTION_MATERIAL,
                AnomalyType.DEBRIS,
            ):
                ds.construction_material = True

        ds.high_severity_count = high_sev

        q = ras.road_surface_quality
        _MAP = {
            RoadSurfaceQuality.GOOD:              RoadDamageContext.NO_SIGNIFICANT_DAMAGE,
            RoadSurfaceQuality.MINOR_DAMAGE:      RoadDamageContext.MINOR_DAMAGE,
            RoadSurfaceQuality.DAMAGED:           RoadDamageContext.MODERATE_DAMAGE,
            RoadSurfaceQuality.SEVERELY_DAMAGED:  RoadDamageContext.SEVERE_DAMAGE,
            RoadSurfaceQuality.UNKNOWN:           RoadDamageContext.UNKNOWN,
        }
        ds.damage_context = _MAP.get(q, RoadDamageContext.UNKNOWN)
        return ds

    # ------------------------------------------------------------------
    # Step 7: Traffic context
    # ------------------------------------------------------------------

    def _derive_traffic(
        self,
        fws: Optional[Any],
    ) -> Tuple[TrafficDensity, TrafficMixSummary]:
        mix = TrafficMixSummary()
        if fws is None:
            return TrafficDensity.UNKNOWN, mix

        objects = fws.objects or []
        n = len(objects)
        c = self._cfg

        if n == 0:
            density = TrafficDensity.VERY_LOW
        elif n <= c.traffic_very_low_max:
            density = TrafficDensity.VERY_LOW
        elif n <= c.traffic_low_max:
            density = TrafficDensity.LOW
        elif n <= c.traffic_medium_max:
            density = TrafficDensity.MEDIUM
        elif n <= c.traffic_high_max:
            density = TrafficDensity.HIGH
        else:
            density = TrafficDensity.VERY_HIGH

        # Traffic mix
        class_counts: Dict[str, int] = {}
        for obj in objects:
            cls = getattr(obj, "object_class", "unknown") or "unknown"
            class_counts[cls] = class_counts.get(cls, 0) + 1

        if class_counts:
            total = sum(class_counts.values())
            mix.observed_classes = sorted(class_counts.keys())
            for cls, cnt in class_counts.items():
                ratio = cnt / total if total > 0 else 0
                if ratio < 0.15:
                    mix.relative_presence[cls] = "LOW"
                elif ratio < 0.40:
                    mix.relative_presence[cls] = "MEDIUM"
                else:
                    mix.relative_presence[cls] = "HIGH"
            mix.heterogeneous = len(class_counts) >= 3
            # Confidence proportional to fusion quality
            fm = getattr(fws, "fusion_mode", None)
            if _FUSION_TYPES_AVAILABLE and fm == FusionMode.FULL_FUSION:
                mix.confidence = 0.85
            elif fws is not None:
                mix.confidence = 0.60

        return density, mix

    # ------------------------------------------------------------------
    # Step 8: VRU / animal context
    # ------------------------------------------------------------------

    def _derive_vru(
        self,
        fws: Optional[Any],
    ) -> Tuple[VRUPresence, bool, AnimalActivity]:
        if fws is None:
            return VRUPresence.UNKNOWN, False, AnimalActivity.UNKNOWN

        objects = fws.objects or []
        c = self._cfg
        vru_count = 0
        animal_count = 0
        animal_moving = False
        animal_static = False

        for obj in objects:
            cls = (getattr(obj, "object_class", "") or "").lower()
            if cls in c.vru_classes:
                vru_count += 1
            if cls in c.animal_classes:
                animal_count += 1
                vel = getattr(obj, "velocity", None)
                if vel is not None:
                    speed = math.sqrt(sum(v * v for v in vel))
                    if speed > 0.3:
                        animal_moving = True
                    else:
                        animal_static = True

        if vru_count == 0:
            vru_presence = VRUPresence.NONE_OBSERVED
        elif vru_count < c.multiple_vru_threshold:
            vru_presence = VRUPresence.PRESENT
        else:
            vru_presence = VRUPresence.MULTIPLE_PRESENT

        animal_present = animal_count > 0
        if animal_present:
            if animal_moving and not animal_static:
                animal_act = AnimalActivity.MOVING
            elif animal_static and not animal_moving:
                animal_act = AnimalActivity.STATIC
            else:
                animal_act = AnimalActivity.UNKNOWN
        else:
            animal_act = AnimalActivity.UNKNOWN

        return vru_presence, animal_present, animal_act

    # ------------------------------------------------------------------
    # Step 9: Roadside activity
    # ------------------------------------------------------------------

    def _derive_roadside_activity(
        self,
        fws: Optional[Any],
    ) -> RoadsideActivitySummary:
        ra = RoadsideActivitySummary()
        if fws is None:
            return ra

        objects = fws.objects or []
        c = self._cfg
        seen: set = set()

        for obj in objects:
            cls = (getattr(obj, "object_class", "") or "").lower()
            if cls in ("pedestrian",):
                seen.add("PEDESTRIAN_ACTIVITY")
            if cls in c.two_wheeler_classes:
                seen.add("TWO_WHEELER_ACTIVITY")
            if cls in c.auto_rickshaw_classes:
                seen.add("AUTO_RICKSHAW_ACTIVITY")
            if cls == "bus":
                seen.add("BUS_ACTIVITY")
            if cls in ("truck", "tractor"):
                seen.add("TRUCK_ACTIVITY")
            if cls in c.animal_classes:
                seen.add("ANIMAL_ACTIVITY")
            if cls in ("pushcart", "rickshaw"):
                seen.add("CART_ACTIVITY")

        ra.activity_types = sorted(seen)
        ra.high_activity = len(seen) >= c.market_min_activity_types
        ra.confidence = 0.70 if fws is not None else 0.0
        return ra

    # ------------------------------------------------------------------
    # Step 10: Boundary / lane weakness
    # ------------------------------------------------------------------

    def _derive_weak_boundaries(self, rud: Optional[RoadUnderstanding]) -> bool:
        if rud is None:
            return True
        if rud.status in (RoadUnderstandingStatus.UNAVAILABLE, RoadUnderstandingStatus.INVALID):
            return True
        if rud.confidence < self._cfg.boundary_weak_confidence_threshold:
            return True
        if rud.boundary_availability in (BoundaryAvailability.NONE,):
            return True
        return False

    def _derive_weak_lane_structure(self, ls: Optional[LaneStructure]) -> bool:
        if ls is None:
            return True
        if ls.status in (LaneStructureStatus.UNAVAILABLE, LaneStructureStatus.INVALID):
            return True
        if ls.confidence < self._cfg.lane_weak_confidence_threshold:
            return True
        if ls.marking_status in (MarkingStatus.UNMARKED, MarkingStatus.UNKNOWN):
            return True
        return False

    # ------------------------------------------------------------------
    # Step 11: Road-type classification
    # ------------------------------------------------------------------

    def _classify_road_type(
        self,
        width_m: Optional[float],
        width_cat: RoadWidthCategory,
        marking_state: RoadMarkingState,
        lane_count: Optional[int],
        lane_count_confidence: float,
        intersection_ctx: IntersectionContext,
        damage_summary: RoadDamageSummary,
        traffic_density: TrafficDensity,
        traffic_mix: TrafficMixSummary,
        vru_presence: VRUPresence,
        animal_present: bool,
        roadside_activity: RoadsideActivitySummary,
        weak_boundaries: bool,
        rt_hints: Dict[str, Any],
        warnings: List[str],
    ) -> Tuple[RoadType, float, List[EvidenceItem]]:
        """
        Deterministic evidence-based road-type classification.

        Each candidate is scored by accumulating evidence points.
        The candidate with the most evidence wins, provided it exceeds
        a minimum threshold.  Ties or insufficient evidence → UNKNOWN.

        All scenario-hint contributions are clearly labelled and capped
        at 0.4 (sensor evidence contributions reach up to 1.0).
        """
        scores: Dict[RoadType, float] = {rt: 0.0 for rt in RoadType}
        evidence: List[EvidenceItem] = []
        c = self._cfg

        # --- Intersection area ---
        if intersection_ctx in (IntersectionContext.INTERSECTION,
                                  IntersectionContext.COMPLEX_INTERSECTION):
            scores[RoadType.INTERSECTION_AREA] += 2.0
            evidence.append(EvidenceItem("intersection_structure_present",
                                          intersection_ctx.value, 2.0))

        # --- Construction ---
        if damage_summary.construction_material:
            scores[RoadType.CONSTRUCTION_AREA] += 1.8
            evidence.append(EvidenceItem("construction_material_observed", "true", 1.8))

        # --- Narrow road ---
        if width_cat in (RoadWidthCategory.VERY_NARROW, RoadWidthCategory.NARROW):
            scores[RoadType.NARROW_ROAD] += 1.5
            evidence.append(EvidenceItem("narrow_width",
                                          width_cat.value, 1.5))

        # --- Highway evidence ---
        highway_score = 0.0
        if width_cat in (RoadWidthCategory.WIDE, RoadWidthCategory.VERY_WIDE):
            if width_m is not None and width_m >= c.highway_min_width_m:
                highway_score += 1.2
                evidence.append(EvidenceItem("wide_road", f"{width_m:.1f} m", 1.2))
        if marking_state == RoadMarkingState.MARKED:
            highway_score += 0.8
            evidence.append(EvidenceItem("marked_lanes", "MARKED", 0.8))
        if lane_count is not None and lane_count >= c.highway_min_lanes and lane_count_confidence > 0.5:
            highway_score += 0.7
            evidence.append(EvidenceItem("lane_count", str(lane_count), 0.7))
        if highway_score > 0:
            scores[RoadType.HIGHWAY] += highway_score

        # --- Village-road evidence ---
        village_score = 0.0
        if marking_state in (RoadMarkingState.UNMARKED, RoadMarkingState.WEAKLY_MARKED):
            village_score += 0.8
        if width_cat in (RoadWidthCategory.VERY_NARROW, RoadWidthCategory.NARROW):
            village_score += 0.7
        if weak_boundaries:
            village_score += 0.5
        if lane_count is not None and lane_count <= c.village_max_lane_count and lane_count_confidence > 0.4:
            village_score += 0.5
        if traffic_density in (TrafficDensity.VERY_LOW, TrafficDensity.LOW):
            village_score += 0.3
        if animal_present:
            village_score += 0.4
            evidence.append(EvidenceItem("animal_present", "true", 0.4))
        if damage_summary.anomaly_count >= 2:
            village_score += 0.3
        if village_score > 0:
            scores[RoadType.VILLAGE_ROAD] += village_score

        # --- Market-road evidence ---
        market_score = 0.0
        n_pedestrian = sum(
            1 for cls in (traffic_mix.observed_classes or [])
            if cls == "pedestrian"
        )
        pedestrian_present = (
            vru_presence in (VRUPresence.PRESENT, VRUPresence.MULTIPLE_PRESENT)
        )
        if pedestrian_present:
            market_score += 0.8
        if roadside_activity.high_activity:
            market_score += 1.0
            evidence.append(EvidenceItem("high_roadside_activity", "true", 1.0))
        if traffic_mix.heterogeneous:
            market_score += 0.6
        if traffic_density in (TrafficDensity.HIGH, TrafficDensity.VERY_HIGH):
            market_score += 0.5
        if "auto_rickshaw" in (traffic_mix.observed_classes or []):
            market_score += 0.4
        # Only claim MARKET if evidence is sufficiently strong
        if market_score > 0:
            scores[RoadType.MARKET_ROAD] += market_score

        # --- Urban road ---
        urban_score = 0.0
        if marking_state in (RoadMarkingState.MARKED, RoadMarkingState.WEAKLY_MARKED):
            urban_score += 0.5
        if width_cat in (RoadWidthCategory.NORMAL, RoadWidthCategory.WIDE):
            urban_score += 0.5
        if traffic_density in (TrafficDensity.MEDIUM, TrafficDensity.HIGH):
            urban_score += 0.4
        if traffic_mix.heterogeneous:
            urban_score += 0.3
        if urban_score > 0:
            scores[RoadType.URBAN_ROAD] += urban_score

        # --- Residential road ---
        res_score = 0.0
        if width_cat == RoadWidthCategory.NARROW:
            res_score += 0.6
        if traffic_density in (TrafficDensity.VERY_LOW, TrafficDensity.LOW, TrafficDensity.MEDIUM):
            res_score += 0.4
        if marking_state in (RoadMarkingState.UNMARKED, RoadMarkingState.WEAKLY_MARKED):
            res_score += 0.3
        if res_score > 0:
            scores[RoadType.RESIDENTIAL_ROAD] += res_score

        # --- Open road ---
        open_score = 0.0
        if width_cat in (RoadWidthCategory.NORMAL, RoadWidthCategory.WIDE):
            open_score += 0.4
        if traffic_density in (TrafficDensity.VERY_LOW, TrafficDensity.LOW):
            open_score += 0.3
        if marking_state == RoadMarkingState.UNMARKED:
            open_score += 0.2
        if open_score > 0:
            scores[RoadType.OPEN_ROAD] += open_score

        # --- Scenario hint boosts (soft — clearly labelled, capped at 0.4) ---
        if rt_hints.get("village_hint"):
            scores[RoadType.VILLAGE_ROAD] += 0.3
        if rt_hints.get("market_hint"):
            scores[RoadType.MARKET_ROAD] += 0.3
        if rt_hints.get("highway_hint"):
            scores[RoadType.HIGHWAY] += 0.3
        if rt_hints.get("construction_hint"):
            scores[RoadType.CONSTRUCTION_AREA] += 0.3

        # Remove UNKNOWN from competition (default fallback, not a candidate)
        del scores[RoadType.UNKNOWN]

        # Find winner
        best_type, best_score = max(scores.items(), key=lambda kv: kv[1])

        # Minimum evidence threshold — must be clearly supported
        MIN_SCORE = 1.0
        if best_score < MIN_SCORE:
            road_type = RoadType.UNKNOWN
            rt_confidence = 0.0
        else:
            road_type = best_type
            # Normalise confidence against sum of top-2 scores
            sorted_scores = sorted(scores.values(), reverse=True)
            runner_up = sorted_scores[1] if len(sorted_scores) > 1 else 0.0
            total_top2 = best_score + runner_up + 1e-9
            rt_confidence = min(0.95, best_score / total_top2)

        return road_type, round(rt_confidence, 4), evidence

    # ------------------------------------------------------------------
    # Step 12: Road complexity
    # ------------------------------------------------------------------

    def _derive_complexity(
        self,
        marking_state: RoadMarkingState,
        width_cat: RoadWidthCategory,
        damage_summary: RoadDamageSummary,
        traffic_density: TrafficDensity,
        traffic_mix: TrafficMixSummary,
        vru_presence: VRUPresence,
        intersection_ctx: IntersectionContext,
        weak_boundaries: bool,
        weak_lane_structure: bool,
        sensor_degraded: bool,
    ) -> Tuple[RoadComplexity, float, List[EvidenceItem]]:
        c = self._cfg
        score = 0.0
        evidence: List[EvidenceItem] = []

        def _add(factor: str, value: str, w: float) -> None:
            nonlocal score
            score += w
            evidence.append(EvidenceItem(factor, value, w))

        if marking_state == RoadMarkingState.UNMARKED:
            _add("unmarked_road", "UNMARKED", c.w_unmarked)
        elif marking_state == RoadMarkingState.WEAKLY_MARKED:
            _add("weakly_marked_road", "WEAKLY_MARKED", c.w_unmarked * 0.5)

        if width_cat in (RoadWidthCategory.VERY_NARROW, RoadWidthCategory.NARROW):
            _add("narrow_road", width_cat.value, c.w_narrow)

        # Anomaly contribution (capped)
        anomaly_contrib = min(
            c.w_anomaly_count_per * damage_summary.anomaly_count,
            c.w_anomaly_count_cap,
        )
        if anomaly_contrib > 0:
            _add("road_anomaly_count", str(damage_summary.anomaly_count),
                  round(anomaly_contrib, 3))

        high_sev_contrib = min(
            c.w_high_severity_per * damage_summary.high_severity_count,
            c.w_high_severity_cap,
        )
        if high_sev_contrib > 0:
            _add("high_severity_anomalies", str(damage_summary.high_severity_count),
                  round(high_sev_contrib, 3))

        if traffic_density in (TrafficDensity.HIGH, TrafficDensity.VERY_HIGH):
            _add("high_traffic_density", traffic_density.value, c.w_high_traffic)

        if traffic_mix.heterogeneous:
            _add("heterogeneous_traffic", "true", c.w_heterogeneous_traffic)

        if vru_presence in (VRUPresence.PRESENT, VRUPresence.MULTIPLE_PRESENT):
            _add("vru_present", vru_presence.value, c.w_vru)

        if intersection_ctx == IntersectionContext.COMPLEX_INTERSECTION:
            _add("complex_intersection", "true", c.w_complex_intersection)
        elif intersection_ctx == IntersectionContext.INTERSECTION:
            _add("intersection", "true", c.w_intersection)

        if weak_boundaries:
            _add("weak_road_boundaries", "true", c.w_weak_boundaries)

        if weak_lane_structure:
            _add("weak_lane_structure", "true", c.w_weak_lane_structure)

        if damage_summary.construction_material:
            _add("construction_material", "true", c.w_construction)

        if sensor_degraded:
            _add("sensor_degraded", "true", c.w_sensor_degraded)

        # Map score to enum
        if score < c.complexity_medium_threshold:
            level = RoadComplexity.LOW
        elif score < c.complexity_high_threshold:
            level = RoadComplexity.MEDIUM
        elif score < c.complexity_very_high_threshold:
            level = RoadComplexity.HIGH
        else:
            level = RoadComplexity.VERY_HIGH

        return level, score, evidence

    # ------------------------------------------------------------------
    # Step 13: Context flags
    # ------------------------------------------------------------------

    def _build_flags(
        self,
        marking_state: RoadMarkingState,
        width_cat: RoadWidthCategory,
        traffic_density: TrafficDensity,
        vru_presence: VRUPresence,
        animal_present: bool,
        damage_summary: RoadDamageSummary,
        intersection_ctx: IntersectionContext,
        weak_boundaries: bool,
        weak_lane_structure: bool,
        complexity: RoadComplexity,
        sensor_degraded: bool,
        uncertainty: float,
        road_type: RoadType,
    ) -> List[ContextFlag]:
        flags: set = set()

        if marking_state == RoadMarkingState.UNMARKED:
            flags.add(ContextFlag.UNMARKED_ROAD)
        if width_cat in (RoadWidthCategory.VERY_NARROW, RoadWidthCategory.NARROW):
            flags.add(ContextFlag.NARROW_ROAD)
        if traffic_density in (TrafficDensity.HIGH, TrafficDensity.VERY_HIGH):
            flags.add(ContextFlag.HIGH_TRAFFIC)
        if vru_presence in (VRUPresence.PRESENT, VRUPresence.MULTIPLE_PRESENT):
            flags.add(ContextFlag.HIGH_VRU_ACTIVITY)
        if animal_present:
            flags.add(ContextFlag.ANIMAL_PRESENT)
        if damage_summary.damage_context not in (
            RoadDamageContext.NO_SIGNIFICANT_DAMAGE,
            RoadDamageContext.UNKNOWN,
        ) and damage_summary.anomaly_count > 0:
            flags.add(ContextFlag.ROAD_DAMAGE_PRESENT)
        if damage_summary.damage_context == RoadDamageContext.SEVERE_DAMAGE:
            flags.add(ContextFlag.SEVERE_ROAD_DAMAGE)
        if intersection_ctx in (
            IntersectionContext.INTERSECTION,
            IntersectionContext.COMPLEX_INTERSECTION,
        ):
            flags.add(ContextFlag.INTERSECTION_PRESENT)
        if weak_boundaries:
            flags.add(ContextFlag.WEAK_BOUNDARIES)
        if weak_lane_structure:
            flags.add(ContextFlag.WEAK_LANE_STRUCTURE)
        if damage_summary.construction_material:
            flags.add(ContextFlag.CONSTRUCTION_PRESENT)
        if complexity in (RoadComplexity.HIGH, RoadComplexity.VERY_HIGH):
            flags.add(ContextFlag.HIGH_ROAD_COMPLEXITY)
        if sensor_degraded:
            flags.add(ContextFlag.SENSOR_DEGRADED)
        if uncertainty > 0.6:
            flags.add(ContextFlag.UNCERTAIN_CONTEXT)
        if road_type in (RoadType.MARKET_ROAD,):
            flags.add(ContextFlag.MARKET_LIKE_CONTEXT)
        if road_type in (RoadType.HIGHWAY,):
            flags.add(ContextFlag.HIGHWAY_LIKE_CONTEXT)

        return sorted(flags, key=lambda f: f.value)

    # ------------------------------------------------------------------
    # Step 14: Confidence aggregation
    # ------------------------------------------------------------------

    def _derive_confidence(
        self,
        sensor_status: SensorStatusSummary,
        rud: Optional[RoadUnderstanding],
        ls: Optional[LaneStructure],
        ras: Optional[RoadAnomalyState],
        conflict_count: int,
        marking_conf: float,
    ) -> Tuple[float, float]:
        """
        Transparent deterministic confidence aggregation.

        Starts from a base and adds bonuses for available / OK upstream phases,
        then applies penalties for degraded sensors and conflicts.
        """
        c = self._cfg
        conf = c.conf_base

        if sensor_status.road_understanding_available:
            rud_conf = rud.confidence if rud else 0.0
            conf += c.conf_phase61_ok * max(0.3, rud_conf)

        if sensor_status.lane_structure_available:
            ls_conf = ls.confidence if ls else 0.0
            conf += c.conf_phase62_ok * max(0.3, ls_conf)

        if sensor_status.road_anomaly_available:
            ras_conf = ras.overall_confidence if ras else 0.0
            conf += c.conf_phase63_ok * max(0.3, ras_conf)

        if sensor_status.fused_world_state_available:
            conf += c.conf_fws_ok

        if sensor_status.any_degraded:
            conf -= c.conf_degraded_penalty

        conf -= conflict_count * c.conf_conflict_penalty

        conf = max(0.0, min(1.0, conf))
        uncertainty = round(1.0 - conf, 4)
        return round(conf, 4), uncertainty

    # ------------------------------------------------------------------
    # Step 15: Engine status
    # ------------------------------------------------------------------

    def _determine_status(
        self,
        sensor_status: SensorStatusSummary,
        confidence: float,
    ) -> ContextEngineStatus:
        n_available = sum([
            sensor_status.road_understanding_available,
            sensor_status.lane_structure_available,
            sensor_status.road_anomaly_available,
            sensor_status.fused_world_state_available,
        ])
        if n_available == 0:
            return ContextEngineStatus.UNAVAILABLE
        if sensor_status.any_degraded or confidence < 0.4:
            return ContextEngineStatus.DEGRADED
        if n_available < 3:
            return ContextEngineStatus.PARTIAL
        return ContextEngineStatus.OK

    # ------------------------------------------------------------------
    # Step 16: Temporal stability
    # ------------------------------------------------------------------

    def _update_stability(self, state: IndianRoadContextState) -> None:
        """
        Update rolling road-type history and set stability fields on state.
        Does NOT build a new memory system — just a bounded deque.
        """
        self._road_type_history.append(state.road_type)

        # Count how many recent frames match the current type
        current = state.road_type
        consecutive = 0
        for rt in reversed(self._road_type_history):
            if rt == current:
                consecutive += 1
            else:
                break

        self._stable_frame_count = consecutive
        if consecutive >= self._cfg.stable_frame_count:
            self._last_stable_road_type = current
            state.stability = ContextStability.STABLE
        else:
            state.stability = ContextStability.UNSTABLE

        state.stable_frame_count = consecutive
        state.last_stable_road_type = self._last_stable_road_type

    # ------------------------------------------------------------------
    # Helper: unavailable state
    # ------------------------------------------------------------------

    def _unavailable_state(
        self,
        timestamp: float,
        frame_id: int,
        sensor_status: SensorStatusSummary,
    ) -> IndianRoadContextState:
        return IndianRoadContextState(
            timestamp=timestamp,
            frame_id=frame_id,
            status=ContextEngineStatus.UNAVAILABLE,
            road_type=RoadType.UNKNOWN,
            degraded=True,
            sensor_status=sensor_status,
            uncertainty=1.0,
            confidence=0.0,
            stability=ContextStability.UNKNOWN,
            warnings=["All upstream inputs unavailable; context cannot be determined."],
        )
