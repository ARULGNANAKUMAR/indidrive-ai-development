"""
IndiDrive AI — Phase 6.4 | Indian-Road Context Fusion Data Contracts
================================================================================
Structural containers for the Indian-road context fusion layer produced by
``indian_road_context.py``.  Companion to Phase 6.1 / 6.2 / 6.3 — same
philosophy:

  * dataclasses, not raw dicts
  * explicit NOT_AVAILABLE / unknown states, never fabricated values
  * Indian-road-first: market roads, cattle crossings, unmarked corridors
    are first-class, not exceptions
  * deterministic, explainable — no opaque ML scores

Coordinate frame: vehicle frame (+X forward, +Y left, +Z up, origin rear-axle
centre, metres) — identical to Phase 6.1 / 6.2 / 6.3.

Nothing here performs computation; these are structural containers and small
helpers only.  All public names are listed in ``__all__`` for controlled import.
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from enum import Enum
from typing import List, Optional

from .perception_types import NOT_AVAILABLE

__all__ = [
    "NOT_AVAILABLE",
    # Status enums
    "ContextEngineStatus",
    "RoadType",
    "RoadWidthCategory",
    "RoadMarkingState",
    "IntersectionContext",
    "RoadDamageContext",
    "TrafficDensity",
    "VRUPresence",
    "AnimalActivity",
    "RoadComplexity",
    "ContextStability",
    # Flag enum
    "ContextFlag",
    # Subordinate containers
    "TrafficMixSummary",
    "RoadsideActivitySummary",
    "RoadDamageSummary",
    "EvidenceItem",
    "SensorStatusSummary",
    # Primary output
    "IndianRoadContextState",
]


# ---------------------------------------------------------------------------
# Status / state enums
# ---------------------------------------------------------------------------

class ContextEngineStatus(str, Enum):
    """Top-level status of IndianRoadContextEngine for this cycle."""
    OK          = "OK"
    PARTIAL     = "PARTIAL"      # some upstream inputs missing; degraded context
    DEGRADED    = "DEGRADED"     # below useful threshold; context unreliable
    UNAVAILABLE = "UNAVAILABLE"  # no upstream input available
    INVALID     = "INVALID"      # upstream input failed validation


class RoadType(str, Enum):
    """
    Coarse road-type classification produced by deterministic fusion of
    Phase 6.1 / 6.2 / 6.3 / perception outputs.

    Evidence rules are documented in IndianRoadContextEngine.
    NOT a geographic label — no city/district names.
    """
    UNKNOWN            = "UNKNOWN"
    VILLAGE_ROAD       = "VILLAGE_ROAD"
    RESIDENTIAL_ROAD   = "RESIDENTIAL_ROAD"
    URBAN_ROAD         = "URBAN_ROAD"
    MARKET_ROAD        = "MARKET_ROAD"
    HIGHWAY            = "HIGHWAY"
    HIGHWAY_MERGE_AREA = "HIGHWAY_MERGE_AREA"
    SERVICE_ROAD       = "SERVICE_ROAD"
    INTERSECTION_AREA  = "INTERSECTION_AREA"
    CONSTRUCTION_AREA  = "CONSTRUCTION_AREA"
    NARROW_ROAD        = "NARROW_ROAD"
    OPEN_ROAD          = "OPEN_ROAD"


class RoadWidthCategory(str, Enum):
    """
    Categorical road-width label derived from estimated_road_width_m
    against configurable thresholds.
    """
    UNKNOWN     = "UNKNOWN"
    VERY_NARROW = "VERY_NARROW"   # < very_narrow_threshold_m
    NARROW      = "NARROW"        # < narrow_threshold_m
    NORMAL      = "NORMAL"        # < normal_threshold_m
    WIDE        = "WIDE"          # < wide_threshold_m
    VERY_WIDE   = "VERY_WIDE"     # >= wide_threshold_m


class RoadMarkingState(str, Enum):
    """
    Overall lane/road-marking state for this context observation.

    Derived from Phase 6.2's MarkingStatus using the conflict-resolution
    policy; always explicit — never assumed.
    """
    MARKED        = "MARKED"
    WEAKLY_MARKED = "WEAKLY_MARKED"
    UNMARKED      = "UNMARKED"
    UNKNOWN       = "UNKNOWN"


class IntersectionContext(str, Enum):
    """
    Structural intersection classification.
    NO decision logic (turn/stop/yield) — pure environment description.
    """
    NO_INTERSECTION      = "NO_INTERSECTION"
    POSSIBLE_INTERSECTION = "POSSIBLE_INTERSECTION"
    INTERSECTION         = "INTERSECTION"
    COMPLEX_INTERSECTION = "COMPLEX_INTERSECTION"
    UNKNOWN              = "UNKNOWN"


class RoadDamageContext(str, Enum):
    """
    Aggregate road-damage level derived from Phase 6.3 anomaly set.
    Does NOT replace Phase 6.3 detail — summarises it for context.
    """
    UNKNOWN             = "UNKNOWN"
    NO_SIGNIFICANT_DAMAGE = "NO_SIGNIFICANT_DAMAGE"
    MINOR_DAMAGE        = "MINOR_DAMAGE"
    MODERATE_DAMAGE     = "MODERATE_DAMAGE"
    SEVERE_DAMAGE       = "SEVERE_DAMAGE"


class TrafficDensity(str, Enum):
    """
    Lightweight traffic-density context derived from fused object count and
    configurable thresholds.  NOT a traffic-rule decision.
    """
    UNKNOWN   = "UNKNOWN"
    VERY_LOW  = "VERY_LOW"
    LOW       = "LOW"
    MEDIUM    = "MEDIUM"
    HIGH      = "HIGH"
    VERY_HIGH = "VERY_HIGH"


class VRUPresence(str, Enum):
    """
    Vulnerable Road User (pedestrian / cyclist / animal) presence context.
    Environmental observation only — no avoidance action.
    """
    UNKNOWN          = "UNKNOWN"
    NONE_OBSERVED    = "NONE_OBSERVED"
    PRESENT          = "PRESENT"
    MULTIPLE_PRESENT = "MULTIPLE_PRESENT"


class AnimalActivity(str, Enum):
    """Motion state of observed animal(s) when animal_present is True."""
    STATIC  = "STATIC"
    MOVING  = "MOVING"
    UNKNOWN = "UNKNOWN"


class RoadComplexity(str, Enum):
    """
    Deterministic road-complexity estimate based on weighted evidence.
    Explainable — evidence_items carries the contributing factors.
    """
    UNKNOWN   = "UNKNOWN"
    LOW       = "LOW"
    MEDIUM    = "MEDIUM"
    HIGH      = "HIGH"
    VERY_HIGH = "VERY_HIGH"


class ContextStability(str, Enum):
    """
    Temporal stability of the road-type / complexity classification.
    Updated by the rolling-window stabiliser in IndianRoadContextEngine.
    """
    STABLE    = "STABLE"   # consistent over >= stability_window_frames
    UNSTABLE  = "UNSTABLE" # changed recently; may still be settling
    UNKNOWN   = "UNKNOWN"


# ---------------------------------------------------------------------------
# Context flags (compact boolean/enumerated evidence markers)
# ---------------------------------------------------------------------------

class ContextFlag(str, Enum):
    """
    Compact boolean-equivalent flags set when supporting evidence exists.
    Only set when threshold/rule criteria are met — never assumed.
    """
    UNMARKED_ROAD        = "UNMARKED_ROAD"
    NARROW_ROAD          = "NARROW_ROAD"
    HIGH_TRAFFIC         = "HIGH_TRAFFIC"
    HIGH_VRU_ACTIVITY    = "HIGH_VRU_ACTIVITY"
    ANIMAL_PRESENT       = "ANIMAL_PRESENT"
    ROAD_DAMAGE_PRESENT  = "ROAD_DAMAGE_PRESENT"
    SEVERE_ROAD_DAMAGE   = "SEVERE_ROAD_DAMAGE"
    INTERSECTION_PRESENT = "INTERSECTION_PRESENT"
    WEAK_BOUNDARIES      = "WEAK_BOUNDARIES"
    WEAK_LANE_STRUCTURE  = "WEAK_LANE_STRUCTURE"
    CONSTRUCTION_PRESENT = "CONSTRUCTION_PRESENT"
    HIGH_ROAD_COMPLEXITY = "HIGH_ROAD_COMPLEXITY"
    SENSOR_DEGRADED      = "SENSOR_DEGRADED"
    UNCERTAIN_CONTEXT    = "UNCERTAIN_CONTEXT"
    NARROW_CONSTRAINED   = "NARROW_CONSTRAINED"
    MARKET_LIKE_CONTEXT  = "MARKET_LIKE_CONTEXT"
    HIGHWAY_LIKE_CONTEXT = "HIGHWAY_LIKE_CONTEXT"


# ---------------------------------------------------------------------------
# Subordinate containers
# ---------------------------------------------------------------------------

@dataclass
class EvidenceItem:
    """One piece of evidence supporting a classification decision."""
    factor: str       # short descriptor, e.g. "road_width_below_narrow_threshold"
    value: str        # evidence value, e.g. "3.2 m"
    weight: float = 1.0  # contribution weight used in complexity score

    def to_dict(self) -> dict:
        return {"factor": self.factor, "value": self.value, "weight": round(self.weight, 3)}


@dataclass
class TrafficMixSummary:
    """
    Observed traffic-class composition derived from fused objects.
    Does NOT invent classes not present in Phase 2/3 output.
    """
    observed_classes: List[str] = field(default_factory=list)
    # Relative presence as NONE / LOW / MEDIUM / HIGH — not percentages
    # unless actually computed.  Keys are object class strings.
    relative_presence: dict = field(default_factory=dict)
    heterogeneous: bool = False   # True when 3+ distinct classes observed
    confidence: float = 0.0

    def to_dict(self) -> dict:
        return {
            "observed_classes": self.observed_classes,
            "relative_presence": self.relative_presence,
            "heterogeneous": self.heterogeneous,
            "confidence": round(self.confidence, 3),
        }


@dataclass
class RoadsideActivitySummary:
    """
    Contextual activity indicators derived from existing perception output.
    No new detection — only summarises what Phase 2/3 already provides.
    """
    activity_types: List[str] = field(default_factory=list)
    high_activity: bool = False
    confidence: float = 0.0

    def to_dict(self) -> dict:
        return {
            "activity_types": self.activity_types,
            "high_activity": self.high_activity,
            "confidence": round(self.confidence, 3),
        }


@dataclass
class RoadDamageSummary:
    """
    Compact summary of Phase 6.3 output — does not duplicate full anomaly list.
    """
    damage_context: RoadDamageContext = RoadDamageContext.UNKNOWN
    anomaly_count: int = 0
    high_severity_count: int = 0
    drivable_area_overlap: bool = False   # any anomaly inside drivable area
    road_edge_damage: bool = False
    water_damage: bool = False
    surface_damage: bool = False          # DAMAGED_SURFACE / CRACK / UNEVEN_SURFACE
    construction_material: bool = False   # CONSTRUCTION_MATERIAL / DEBRIS
    confidence: float = 0.0

    def to_dict(self) -> dict:
        return {
            "damage_context": self.damage_context.value,
            "anomaly_count": self.anomaly_count,
            "high_severity_count": self.high_severity_count,
            "drivable_area_overlap": self.drivable_area_overlap,
            "road_edge_damage": self.road_edge_damage,
            "water_damage": self.water_damage,
            "surface_damage": self.surface_damage,
            "construction_material": self.construction_material,
            "confidence": round(self.confidence, 3),
        }


@dataclass
class SensorStatusSummary:
    """Compact upstream sensor/module status for this context frame."""
    road_understanding_available: bool = False
    lane_structure_available: bool = False
    road_anomaly_available: bool = False
    fused_world_state_available: bool = False
    any_degraded: bool = False
    # Per-sensor strings forwarded from upstream, e.g. {"camera": "OK", "lidar": "UNAVAILABLE"}
    sensor_details: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        return {
            "road_understanding_available": self.road_understanding_available,
            "lane_structure_available": self.lane_structure_available,
            "road_anomaly_available": self.road_anomaly_available,
            "fused_world_state_available": self.fused_world_state_available,
            "any_degraded": self.any_degraded,
            "sensor_details": self.sensor_details,
        }


# ---------------------------------------------------------------------------
# Primary Phase 6.4 output
# ---------------------------------------------------------------------------

@dataclass
class IndianRoadContextState:
    """
    Phase 6.4 primary output.  One IndianRoadContextState is produced per
    IndianRoadContextEngine.process() call.

    This is a *context description*, NOT a driving decision.
    Consumers (world model, reasoning brain, path planner) read this
    structure.  This module never calls into those consumers.

    Field groups
    ------------
    Identity        — timestamp, frame_id, status
    Road structure  — road_type, road_marking_state, estimated_road_width_m,
                      road_width_category, lane_count, road_type_hint
    Road boundaries — boundary_availability, weak_boundaries
    Intersection    — intersection_context
    Damage          — road_damage_summary
    Traffic         — traffic_density, traffic_mix
    VRU / animals   — vru_presence, animal_present, animal_activity
    Roadside        — roadside_activity
    Complexity      — road_complexity
    Flags           — context_flags (set[ContextFlag])
    Confidence/Unc  — confidence, uncertainty
    Stability       — stability, stable_frame_count
    Sensor          — sensor_status (SensorStatusSummary), degraded
    Evidence        — evidence_items (list[EvidenceItem])
    Source          — source_summary
    Debug           — warnings, metadata
    """
    # --- Identity -----------------------------------------------------------
    timestamp: float = 0.0
    frame_id: int = 0
    status: ContextEngineStatus = ContextEngineStatus.UNAVAILABLE

    # --- Road structure -----------------------------------------------------
    road_type: RoadType = RoadType.UNKNOWN
    road_type_confidence: float = 0.0

    road_marking_state: RoadMarkingState = RoadMarkingState.UNKNOWN

    estimated_road_width_m: Optional[float] = None  # None = unknown
    road_width_category: RoadWidthCategory = RoadWidthCategory.UNKNOWN

    lane_count: Optional[int] = None        # None = unknown
    lane_count_confidence: float = 0.0

    road_type_hint: str = NOT_AVAILABLE     # forwards Phase 6.2 RoadTypeHint.value

    # --- Road boundaries ----------------------------------------------------
    boundary_availability: str = NOT_AVAILABLE  # forwards Phase 6.1 BoundaryAvailability.value
    weak_boundaries: bool = False

    # --- Intersection -------------------------------------------------------
    intersection_context: IntersectionContext = IntersectionContext.UNKNOWN

    # --- Road damage --------------------------------------------------------
    road_damage_summary: RoadDamageSummary = field(default_factory=RoadDamageSummary)

    # --- Traffic ------------------------------------------------------------
    traffic_density: TrafficDensity = TrafficDensity.UNKNOWN
    traffic_mix: TrafficMixSummary = field(default_factory=TrafficMixSummary)

    # --- VRU / animals ------------------------------------------------------
    vru_presence: VRUPresence = VRUPresence.UNKNOWN
    animal_present: bool = False
    animal_activity: AnimalActivity = AnimalActivity.UNKNOWN

    # --- Roadside activity --------------------------------------------------
    roadside_activity: RoadsideActivitySummary = field(
        default_factory=RoadsideActivitySummary
    )

    # --- Complexity ---------------------------------------------------------
    road_complexity: RoadComplexity = RoadComplexity.UNKNOWN
    complexity_score: float = 0.0  # raw weighted score before enum mapping

    # --- Context flags ------------------------------------------------------
    context_flags: List[ContextFlag] = field(default_factory=list)

    # --- Confidence / uncertainty -------------------------------------------
    confidence: float = 0.0
    uncertainty: float = 1.0

    # --- Temporal stability -------------------------------------------------
    stability: ContextStability = ContextStability.UNKNOWN
    stable_frame_count: int = 0      # consecutive frames with same road_type
    last_stable_road_type: RoadType = RoadType.UNKNOWN

    # --- Sensor status ------------------------------------------------------
    sensor_status: SensorStatusSummary = field(default_factory=SensorStatusSummary)
    degraded: bool = False

    # --- Evidence -----------------------------------------------------------
    evidence_items: List[EvidenceItem] = field(default_factory=list)

    # --- Source / debug -----------------------------------------------------
    source_summary: str = NOT_AVAILABLE
    warnings: List[str] = field(default_factory=list)
    metadata: dict = field(default_factory=dict)
    created_at: float = field(default_factory=time.time)

    # ------------------------------------------------------------------
    # Convenience helpers
    # ------------------------------------------------------------------

    def has_flag(self, flag: ContextFlag) -> bool:
        return flag in self.context_flags

    def to_dict(self) -> dict:
        return {
            "timestamp": self.timestamp,
            "frame_id": self.frame_id,
            "status": self.status.value,
            "road_type": self.road_type.value,
            "road_type_confidence": round(self.road_type_confidence, 3),
            "road_marking_state": self.road_marking_state.value,
            "estimated_road_width_m": (
                round(self.estimated_road_width_m, 3)
                if self.estimated_road_width_m is not None
                else NOT_AVAILABLE
            ),
            "road_width_category": self.road_width_category.value,
            "lane_count": self.lane_count if self.lane_count is not None else NOT_AVAILABLE,
            "lane_count_confidence": round(self.lane_count_confidence, 3),
            "road_type_hint": self.road_type_hint,
            "boundary_availability": self.boundary_availability,
            "weak_boundaries": self.weak_boundaries,
            "intersection_context": self.intersection_context.value,
            "road_damage_summary": self.road_damage_summary.to_dict(),
            "traffic_density": self.traffic_density.value,
            "traffic_mix": self.traffic_mix.to_dict(),
            "vru_presence": self.vru_presence.value,
            "animal_present": self.animal_present,
            "animal_activity": self.animal_activity.value,
            "roadside_activity": self.roadside_activity.to_dict(),
            "road_complexity": self.road_complexity.value,
            "complexity_score": round(self.complexity_score, 3),
            "context_flags": [f.value for f in self.context_flags],
            "confidence": round(self.confidence, 3),
            "uncertainty": round(self.uncertainty, 3),
            "stability": self.stability.value,
            "stable_frame_count": self.stable_frame_count,
            "last_stable_road_type": self.last_stable_road_type.value,
            "sensor_status": self.sensor_status.to_dict(),
            "degraded": self.degraded,
            "evidence_items": [e.to_dict() for e in self.evidence_items],
            "source_summary": self.source_summary,
            "warnings": self.warnings,
            "metadata": self.metadata,
        }
