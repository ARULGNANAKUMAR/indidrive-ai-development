"""
IndiDrive AI — Phase 2 | Confidence Management & NMS
========================================================
Pure functions — no model/state — for filtering raw detections and
suppressing duplicates. Every detection keeps BOTH its raw_confidence
(exactly what the model produced) and filtered_confidence (after any
class-specific threshold adjustment), so nothing downstream mistakes
one for the other.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

from .perception_types import BoundingBox2D


@dataclass
class RawDetection:
    """What a detector backend (object_detection.py) returns, before
    normalization into a full PerceptionObject."""
    raw_class: str
    raw_confidence: float
    bbox: BoundingBox2D


def filter_by_confidence(
    detections: list[RawDetection],
    threshold: float = 0.40,
    class_thresholds: Optional[dict[str, float]] = None,
) -> list[RawDetection]:
    """Drops detections below `threshold`, or below a class-specific
    threshold in `class_thresholds` (keyed by raw_class, lowercase)
    when the architecture supports per-class tuning."""
    class_thresholds = class_thresholds or {}
    kept = []
    for det in detections:
        t = class_thresholds.get(det.raw_class.lower(), threshold)
        if det.raw_confidence >= t:
            kept.append(det)
    return kept


def quality_score(raw_confidence: float, bbox_area_ratio: float, visibility: float = 1.0) -> float:
    """A simple, transparent quality heuristic in [0, 1]:
    confidence weighted down for very small boxes (likely noisy/far
    detections) and for partial visibility. Not a learned score —
    documented here so it is never mistaken for one."""
    size_factor = min(1.0, bbox_area_ratio * 20.0)  # small boxes -> lower quality
    size_factor = max(0.2, size_factor)
    return max(0.0, min(1.0, raw_confidence * size_factor * visibility))


def non_max_suppression(
    detections: list[RawDetection],
    iou_threshold: float = 0.45,
) -> list[RawDetection]:
    """Standard greedy NMS, per-class (a car box and a pedestrian box
    overlapping is not a duplicate). O(n^2) — fine for the detection
    counts a single frame produces; not designed for tens of thousands
    of boxes."""
    kept: list[RawDetection] = []
    by_class: dict[str, list[RawDetection]] = {}
    for det in detections:
        by_class.setdefault(det.raw_class, []).append(det)

    for cls_dets in by_class.values():
        cls_dets = sorted(cls_dets, key=lambda d: d.raw_confidence, reverse=True)
        suppressed = [False] * len(cls_dets)
        for i, det_i in enumerate(cls_dets):
            if suppressed[i]:
                continue
            kept.append(det_i)
            for j in range(i + 1, len(cls_dets)):
                if suppressed[j]:
                    continue
                if det_i.bbox.iou(cls_dets[j].bbox) > iou_threshold:
                    suppressed[j] = True
    return kept


def validate_and_clip_boxes(
    detections: list[RawDetection], img_width: int, img_height: int
) -> list[RawDetection]:
    """Clips every box to image bounds and drops anything left with
    zero/negative area or invalid (NaN/negative) coordinates."""
    valid = []
    for det in detections:
        b = det.bbox
        if any(v != v for v in (b.x, b.y, b.width, b.height)):  # NaN check
            continue
        clipped = b.clip(img_width, img_height)
        if clipped.width <= 0 or clipped.height <= 0:
            continue
        det.bbox = clipped
        valid.append(det)
    return valid
