"""
IndiDrive AI — Phase 6.2 | Lane & Road-Structure Understanding Data Contracts
================================================================================
Structural containers for the lane/road-structure layer produced by
``lane_structure.py``.  Designed as a direct companion to Phase 6.1's
``road_understanding_types.py`` — same philosophy:

  * dataclasses, not raw dicts
  * explicit NOT_AVAILABLE / unknown states, never fabricated values
  * explicit separation of *observed* vs *inferred* evidence
  * Indian-road-first: unmarked roads are first-class, not exceptions

Coordinate frame: vehicle frame (+X forward, +Y left, +Z up, origin
rear-axle centre, metres) — identical to Phase 6.1 / COORDINATE_SYSTEMS.md.

Nothing here performs computation; these are structural containers and small
helpers only.

All public names are listed in ``__all__`` for controlled import.
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Optional

from .perception_types import NOT_AVAILABLE

__all__ = [
    "NOT_AVAILABLE",
    # Status / availability enums
    "LaneStructureStatus",
    "MarkingStatus",
    "MarkingType",
    "EvidenceKind",
    "RoadTypeHint",
    "IntersectionState",
    # Geometry containers
    "LaneMarkingPoint",
    "LaneMarking",
    "LaneBoundaryPoint",
    "LaneBoundary",
    "CenterlinePoint",
    "LaneCenterline",
    "LaneDescriptor",
    "LaneWidthSample",
    # Top-level output
    "LaneStructure",
]


# ---------------------------------------------------------------------------
# Enums
# ---------------------------------------------------------------------------

class LaneStructureStatus(str, Enum):
    OK = "OK"                       # confident lane structure available
    PARTIAL = "PARTIAL"             # only partial information (one boundary, or inferred-only)
    DEGRADED = "DEGRADED"           # sensor present but below confidence/support threshold
    UNAVAILABLE = "UNAVAILABLE"     # no usable sensor input this cycle
    INVALID = "INVALID"             # geometry validation failed (NaN/Inf/impossible)


class MarkingStatus(str, Enum):
    """Distinguishes whether a physical lane marking was observed."""
    MARKED = "MARKED"               # physical lane markings observed by sensor
    WEAKLY_MARKED = "WEAKLY_MARKED" # markings detected but faded / low-confidence
    UNMARKED = "UNMARKED"           # no physical markings; structure inferred from geometry
    UNKNOWN = "UNKNOWN"             # marking status could not be determined


class MarkingType(str, Enum):
    """Physical paint/marking pattern when a marking is present."""
    SOLID = "SOLID"
    DASHED = "DASHED"
    DOUBLE_SOLID = "DOUBLE_SOLID"
    DOUBLE_DASHED = "DOUBLE_DASHED"
    UNKNOWN = "UNKNOWN"


class EvidenceKind(str, Enum):
    """
    Distinguishes how a geometry was produced.

    OBSERVED  — direct sensor measurement (LiDAR point cluster, camera edge).
    INFERRED  — derived from Phase 6.1 road boundary / drivable geometry
                without a directly observed lane marking.
    UNKNOWN   — provenance not determinable.
    """
    OBSERVED = "observed"
    INFERRED = "inferred"
    UNKNOWN = "unknown"


class RoadTypeHint(str, Enum):
    """Coarse structural hint about the road type for this cycle."""
    SINGLE_LANE = "SINGLE_LANE"
    MULTI_LANE = "MULTI_LANE"
    UNDIVIDED = "UNDIVIDED"         # no central divider observed
    UNMARKED_CORRIDOR = "UNMARKED_CORRIDOR"  # village / rural / informal road
    UNKNOWN = "UNKNOWN"


class IntersectionState(str, Enum):
    """Basic structural classification — NO decision logic."""
    NORMAL_ROAD = "NORMAL_ROAD"
    INTERSECTION = "INTERSECTION"
    UNKNOWN = "UNKNOWN"


# ---------------------------------------------------------------------------
# Lane-marking geometry (raw paint-level observations)
# ---------------------------------------------------------------------------

@dataclass
class LaneMarkingPoint:
    """One sampled point along an observed lane marking, vehicle-frame metres."""
    x: float            # forward
    y: float            # lateral
    confidence: float = 0.0

    def to_dict(self) -> dict:
        return {"x": round(self.x, 3), "y": round(self.y, 3),
                "confidence": round(self.confidence, 3)}


@dataclass
class LaneMarking:
    """
    A single detected physical lane marking (painted line on road surface).

    Source: Phase 2 RoadState.lane_marking field or camera road-perception
    heuristic; never fabricated when camera is not available.
    """
    marking_type: MarkingType = MarkingType.UNKNOWN
    points: list = field(default_factory=list)   # list[LaneMarkingPoint]
    confidence: float = 0.0
    visibility: float = 1.0         # 0 = barely visible .. 1 = fully visible
    source: str = NOT_AVAILABLE     # camera | fusion | unknown

    def to_dict(self) -> dict:
        return {
            "marking_type": self.marking_type.value,
            "points": [p.to_dict() for p in self.points],
            "confidence": round(self.confidence, 3),
            "visibility": round(self.visibility, 3),
            "source": self.source,
        }


# ---------------------------------------------------------------------------
# Lane boundary (higher-level abstraction than a raw marking)
# ---------------------------------------------------------------------------

@dataclass
class LaneBoundaryPoint:
    """
    One sample along a lane boundary polyline, vehicle-frame metres.

    ``evidence`` distinguishes:
      OBSERVED — backed by a direct sensor return at this location.
      INFERRED — derived from Phase 6.1 road-boundary / geometry.
    """
    x: float
    y: float
    confidence: float = 0.0
    evidence: EvidenceKind = EvidenceKind.UNKNOWN

    def to_dict(self) -> dict:
        return {
            "x": round(self.x, 3),
            "y": round(self.y, 3),
            "confidence": round(self.confidence, 3),
            "evidence": self.evidence.value,
        }


@dataclass
class LaneBoundary:
    """
    A polyline separating two adjacent lanes, or separating a lane from the
    road edge.  Ordered by ascending x (forward distance).

    This is distinct from Phase 6.1's RoadBoundary (road edge) — a lane
    boundary may exist between two drivable lanes, not just at the road edge.
    """
    boundary_id: str = ""           # e.g. "lane_0_left", "lane_0_right", "lane_1_left"
    side: str = ""                  # "left" | "right" | "center" (centre-line separator)
    points: list = field(default_factory=list)   # list[LaneBoundaryPoint]
    available: bool = False
    evidence: EvidenceKind = EvidenceKind.UNKNOWN
    marking_type: MarkingType = MarkingType.UNKNOWN
    source: str = NOT_AVAILABLE     # camera | lidar | fusion | inferred | unknown
    confidence: float = 0.0

    def to_dict(self) -> dict:
        return {
            "boundary_id": self.boundary_id,
            "side": self.side,
            "available": self.available,
            "evidence": self.evidence.value,
            "marking_type": self.marking_type.value,
            "points": [p.to_dict() for p in self.points],
            "source": self.source,
            "confidence": round(self.confidence, 3),
        }


# ---------------------------------------------------------------------------
# Lane centreline
# ---------------------------------------------------------------------------

@dataclass
class CenterlinePoint:
    """One sample of a lane centreline, vehicle-frame metres."""
    x: float
    y: float
    heading_rad: Optional[float] = None  # local road heading at this point (rad, vehicle frame)
    confidence: float = 0.0
    evidence: EvidenceKind = EvidenceKind.INFERRED   # centreline is almost always inferred

    def to_dict(self) -> dict:
        return {
            "x": round(self.x, 3),
            "y": round(self.y, 3),
            "heading_rad": round(self.heading_rad, 4) if self.heading_rad is not None else NOT_AVAILABLE,
            "confidence": round(self.confidence, 3),
            "evidence": self.evidence.value,
        }


@dataclass
class LaneCenterline:
    """Estimated centreline for one lane. Points sorted by ascending x."""
    lane_id: str = ""
    points: list = field(default_factory=list)   # list[CenterlinePoint]
    available: bool = False
    evidence: EvidenceKind = EvidenceKind.INFERRED
    confidence: float = 0.0

    def to_dict(self) -> dict:
        return {
            "lane_id": self.lane_id,
            "available": self.available,
            "evidence": self.evidence.value,
            "points": [p.to_dict() for p in self.points],
            "confidence": round(self.confidence, 3),
        }


# ---------------------------------------------------------------------------
# Per-lane descriptor
# ---------------------------------------------------------------------------

@dataclass
class LaneWidthSample:
    """Width of a lane at one forward distance."""
    lane_id: str
    distance_m: float
    estimated_width_m: Optional[float] = None
    confidence: float = 0.0

    def to_dict(self) -> dict:
        return {
            "lane_id": self.lane_id,
            "distance_m": round(self.distance_m, 3),
            "estimated_width_m": round(self.estimated_width_m, 3)
                                  if self.estimated_width_m is not None else NOT_AVAILABLE,
            "confidence": round(self.confidence, 3),
        }


@dataclass
class LaneDescriptor:
    """
    A single lane: its boundaries, centreline, width samples, and metadata.
    """
    lane_id: str = ""
    left_boundary: Optional[LaneBoundary] = None
    right_boundary: Optional[LaneBoundary] = None
    centerline: Optional[LaneCenterline] = None
    width_samples: list = field(default_factory=list)  # list[LaneWidthSample]
    marking_status: MarkingStatus = MarkingStatus.UNKNOWN
    evidence: EvidenceKind = EvidenceKind.UNKNOWN
    confidence: float = 0.0

    def to_dict(self) -> dict:
        return {
            "lane_id": self.lane_id,
            "left_boundary": self.left_boundary.to_dict() if self.left_boundary else NOT_AVAILABLE,
            "right_boundary": self.right_boundary.to_dict() if self.right_boundary else NOT_AVAILABLE,
            "centerline": self.centerline.to_dict() if self.centerline else NOT_AVAILABLE,
            "width_samples": [w.to_dict() for w in self.width_samples],
            "marking_status": self.marking_status.value,
            "evidence": self.evidence.value,
            "confidence": round(self.confidence, 3),
        }


# ---------------------------------------------------------------------------
# Top-level Phase 6.2 output
# ---------------------------------------------------------------------------

@dataclass
class LaneStructure:
    """
    Phase 6.2 primary output.  One LaneStructure is produced per
    LaneStructureEngine.process() call.

    Consumers (world model, reasoning, adaptive path planner) read this
    structure.  This module never calls into any of those consumers.

    Key fields
    ----------
    lanes               — ordered list of LaneDescriptor, innermost (ego) first.
    lane_count          — None means unknown.
    road_heading_rad    — best-estimate road heading at ego vehicle, vehicle
                          frame (0 = straight ahead).  None = unknown.
    marking_status      — overall marking status for this observation.
    road_type           — coarse structural hint.
    intersection_state  — NORMAL_ROAD | INTERSECTION | UNKNOWN.
    confidence          — overall confidence for this output.
    uncertainty         — 1 - confidence (kept separate as per Phase 6.1 convention).
    source              — camera | lidar | fusion | inferred | unknown.
    """
    timestamp: float
    frame_id: int
    status: LaneStructureStatus = LaneStructureStatus.UNAVAILABLE

    lanes: list = field(default_factory=list)   # list[LaneDescriptor]
    lane_count: Optional[int] = None
    lane_count_confidence: float = 0.0

    road_heading_rad: Optional[float] = None
    road_heading_confidence: float = 0.0

    marking_status: MarkingStatus = MarkingStatus.UNKNOWN
    road_type: RoadTypeHint = RoadTypeHint.UNKNOWN
    intersection_state: IntersectionState = IntersectionState.UNKNOWN

    confidence: float = 0.0
    uncertainty: float = 1.0

    source: str = NOT_AVAILABLE
    sensor_status: dict = field(default_factory=dict)
    warnings: list = field(default_factory=list)
    created_at: float = field(default_factory=time.time)

    def to_dict(self) -> dict:
        return {
            "timestamp": self.timestamp,
            "frame_id": self.frame_id,
            "status": self.status.value,
            "lane_count": self.lane_count if self.lane_count is not None else NOT_AVAILABLE,
            "lane_count_confidence": round(self.lane_count_confidence, 3),
            "road_heading_rad": round(self.road_heading_rad, 4)
                                 if self.road_heading_rad is not None else NOT_AVAILABLE,
            "road_heading_confidence": round(self.road_heading_confidence, 3),
            "marking_status": self.marking_status.value,
            "road_type": self.road_type.value,
            "intersection_state": self.intersection_state.value,
            "lanes": [lane.to_dict() for lane in self.lanes],
            "confidence": round(self.confidence, 3),
            "uncertainty": round(self.uncertainty, 3),
            "source": self.source,
            "sensor_status": self.sensor_status,
            "warnings": self.warnings,
        }
