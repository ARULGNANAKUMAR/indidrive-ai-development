"""
IndiDrive AI — Phase 2 | Perception Data Contracts
======================================================
Strongly-typed containers for everything that flows OUT of the
perception layer. Mirrors the design philosophy of Phase 1's
core/carla_integration/sensor_types.py: dataclasses (not raw dicts),
explicit "unavailable" states instead of fabricated values, and a
single stable shape (`PerceptionFrame`) that later phases (Phase 3
sensor fusion) can depend on.

Nothing in this file performs detection/inference — these are
structural containers plus small helpers.
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Optional

# Sentinel used wherever a field is structurally present but the value
# is genuinely not known/available (e.g. 3D position from a camera-only
# detection, or lane markings on an unmarked road). Using an explicit
# string sentinel (rather than silently leaving `None`) makes the state
# visible in to_dict()/JSON output rather than looking like a missing key.
NOT_AVAILABLE = "NOT_AVAILABLE"


class BackendKind(str, Enum):
    """Every perception result must declare which of these produced it.
    Never mix MOCK/BASELINE results into a REAL-labeled output."""
    REAL = "REAL"
    BASELINE = "BASELINE"
    MOCK = "MOCK"
    SIMULATION = "SIMULATION"
    NOT_CONFIGURED = "NOT_CONFIGURED"
    NOT_AVAILABLE = "NOT_AVAILABLE"


class HealthState(str, Enum):
    HEALTHY = "HEALTHY"
    DEGRADED = "DEGRADED"
    FAILED = "FAILED"
    NOT_CONFIGURED = "NOT_CONFIGURED"
    NOT_AVAILABLE = "NOT_AVAILABLE"


class SourceSensor(str, Enum):
    CAMERA = "camera"
    LIDAR = "lidar"
    RADAR = "radar"
    FUSED = "fused"  # reserved for Phase 3; unused in Phase 2


# ---------------------------------------------------------------------------
# Geometry
# ---------------------------------------------------------------------------

@dataclass
class BoundingBox2D:
    x: float
    y: float
    width: float
    height: float

    def clip(self, img_width: int, img_height: int) -> "BoundingBox2D":
        x0 = max(0.0, min(self.x, img_width - 1))
        y0 = max(0.0, min(self.y, img_height - 1))
        x1 = max(0.0, min(self.x + self.width, img_width))
        y1 = max(0.0, min(self.y + self.height, img_height))
        return BoundingBox2D(x=x0, y=y0, width=max(0.0, x1 - x0), height=max(0.0, y1 - y0))

    def iou(self, other: "BoundingBox2D") -> float:
        ax0, ay0, ax1, ay1 = self.x, self.y, self.x + self.width, self.y + self.height
        bx0, by0, bx1, by1 = other.x, other.y, other.x + other.width, other.y + other.height
        ix0, iy0 = max(ax0, bx0), max(ay0, by0)
        ix1, iy1 = min(ax1, bx1), min(ay1, by1)
        iw, ih = max(0.0, ix1 - ix0), max(0.0, iy1 - iy0)
        inter = iw * ih
        if inter <= 0.0:
            return 0.0
        union = self.width * self.height + other.width * other.height - inter
        return inter / union if union > 0 else 0.0

    def to_dict(self) -> dict:
        return {"x": self.x, "y": self.y, "width": self.width, "height": self.height}


@dataclass
class Position3D:
    x: float
    y: float
    z: float

    def to_dict(self) -> dict:
        return {"x": self.x, "y": self.y, "z": self.z}


@dataclass
class Dimensions3D:
    length: float
    width: float
    height: float

    def to_dict(self) -> dict:
        return {"length": self.length, "width": self.width, "height": self.height}


# ---------------------------------------------------------------------------
# Objects
# ---------------------------------------------------------------------------

@dataclass
class PerceptionObject:
    """Universal object representation. Sensor-specific pipelines
    (camera_perception.py, lidar_perception.py, radar_perception.py)
    all produce this same shape so Phase 3 fusion can consume them
    uniformly. Fields not known for a given source are left as `None`
    (numeric/structured fields) or NOT_AVAILABLE (status-like fields) —
    never fabricated.
    """
    object_id: str
    object_class: str                       # normalized taxonomy, see object_types.py
    raw_class: str                          # class name as reported by the model, pre-normalization
    confidence: float                       # filtered_confidence (see confidence.py)
    raw_confidence: float
    source_sensor: SourceSensor
    timestamp: float
    quality: float = 0.0                    # 0..1 overall quality score
    bbox_2d: Optional[BoundingBox2D] = None
    position_3d: Optional[Position3D] = None
    dimensions_3d: Optional[Dimensions3D] = None
    velocity: Optional[tuple[float, float, float]] = None
    heading: Optional[float] = None
    distance: Optional[float] = None
    tracking_ready: bool = False
    visibility: float = 1.0                 # 0..1, 1.0 = fully visible/unoccluded (unknown -> 1.0)
    point_count: Optional[int] = None       # populated for LiDAR-derived objects
    backend: BackendKind = BackendKind.NOT_CONFIGURED
    extra: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        return {
            "object_id": self.object_id,
            "class": self.object_class,
            "raw_class": self.raw_class,
            "confidence": round(self.confidence, 4),
            "raw_confidence": round(self.raw_confidence, 4),
            "bbox_2d": self.bbox_2d.to_dict() if self.bbox_2d else None,
            "position_3d": self.position_3d.to_dict() if self.position_3d else NOT_AVAILABLE,
            "dimensions_3d": self.dimensions_3d.to_dict() if self.dimensions_3d else NOT_AVAILABLE,
            "velocity": list(self.velocity) if self.velocity else NOT_AVAILABLE,
            "heading": self.heading if self.heading is not None else NOT_AVAILABLE,
            "distance": self.distance if self.distance is not None else NOT_AVAILABLE,
            "source_sensor": self.source_sensor.value,
            "timestamp": self.timestamp,
            "tracking_ready": self.tracking_ready,
            "visibility": round(self.visibility, 3),
            "point_count": self.point_count if self.point_count is not None else NOT_AVAILABLE,
            "quality": round(self.quality, 3),
            "backend": self.backend.value,
        }


# ---------------------------------------------------------------------------
# Road understanding
# ---------------------------------------------------------------------------

@dataclass
class RoadState:
    road_present: bool = False
    road_confidence: float = 0.0
    road_width_estimate_m: Optional[float] = None
    lane_marking: str = NOT_AVAILABLE       # NOT_AVAILABLE is a VALID state for unmarked Indian roads
    lane_count_estimate: Optional[int] = None
    road_edge_candidates: list = field(default_factory=list)  # list of pixel/point coordinates
    backend: BackendKind = BackendKind.NOT_CONFIGURED

    def to_dict(self) -> dict:
        return {
            "road_present": self.road_present,
            "road_confidence": round(self.road_confidence, 3),
            "road_width_estimate_m": self.road_width_estimate_m if self.road_width_estimate_m is not None else NOT_AVAILABLE,
            "lane_marking": self.lane_marking,
            "lane_count_estimate": self.lane_count_estimate if self.lane_count_estimate is not None else NOT_AVAILABLE,
            "road_edge_candidates": self.road_edge_candidates,
            "backend": self.backend.value,
        }


@dataclass
class DrivableArea:
    drivable_mask_available: bool = False
    drivable_mask_shape: Optional[tuple[int, int]] = None
    drivable_confidence: float = 0.0
    road_boundary_candidates: list = field(default_factory=list)
    backend: BackendKind = BackendKind.NOT_CONFIGURED
    # The mask itself is NOT embedded in to_dict() (would bloat every
    # frame with an HxW array) — callers needing the raw mask should
    # read `mask` directly on the object, not via to_dict().
    mask: Any = None

    def to_dict(self) -> dict:
        return {
            "drivable_mask_available": self.drivable_mask_available,
            "drivable_mask_shape": list(self.drivable_mask_shape) if self.drivable_mask_shape else NOT_AVAILABLE,
            "drivable_confidence": round(self.drivable_confidence, 3),
            "road_boundary_candidates": self.road_boundary_candidates,
            "backend": self.backend.value,
        }


@dataclass
class RoadAnomaly:
    anomaly_type: str                       # pothole | crack | debris | mud | gravel | road_edge_damage | water_patch
    confidence: float
    location: Optional[BoundingBox2D]
    size_estimate: Optional[Dimensions3D]
    severity: str                           # LOW | MEDIUM | HIGH | UNKNOWN
    source: SourceSensor
    timestamp: float
    status: str = NOT_AVAILABLE            # REAL | BASELINE | NOT_CONFIGURED (see anomaly_detection.py)

    def to_dict(self) -> dict:
        return {
            "type": self.anomaly_type,
            "confidence": round(self.confidence, 3),
            "location": self.location.to_dict() if self.location else NOT_AVAILABLE,
            "size_estimate": self.size_estimate.to_dict() if self.size_estimate else NOT_AVAILABLE,
            "severity": self.severity,
            "source": self.source.value,
            "timestamp": self.timestamp,
            "status": self.status,
        }


# ---------------------------------------------------------------------------
# Timing / quality
# ---------------------------------------------------------------------------

@dataclass
class ProcessingMetrics:
    """Every latency here is measured with time.perf_counter() at the
    point of use — never a placeholder or hard-coded value."""
    preprocessing_latency_ms: float = 0.0
    inference_latency_ms: float = 0.0
    postprocessing_latency_ms: float = 0.0
    total_perception_latency_ms: float = 0.0
    input_fps: float = 0.0
    processing_fps: float = 0.0
    dropped_frames: int = 0

    def to_dict(self) -> dict:
        return {
            "preprocessing_latency_ms": round(self.preprocessing_latency_ms, 3),
            "inference_latency_ms": round(self.inference_latency_ms, 3),
            "postprocessing_latency_ms": round(self.postprocessing_latency_ms, 3),
            "total_perception_latency_ms": round(self.total_perception_latency_ms, 3),
            "input_fps": round(self.input_fps, 2),
            "processing_fps": round(self.processing_fps, 2),
            "dropped_frames": self.dropped_frames,
        }


@dataclass
class PerceptionQuality:
    frame_valid: bool = True
    model_ready: bool = False
    inference_success: bool = False
    detection_count: int = 0
    average_confidence: float = 0.0
    health: HealthState = HealthState.NOT_CONFIGURED

    def to_dict(self) -> dict:
        return {
            "frame_valid": self.frame_valid,
            "model_ready": self.model_ready,
            "inference_success": self.inference_success,
            "detection_count": self.detection_count,
            "average_confidence": round(self.average_confidence, 3),
            "health": self.health.value,
        }


# ---------------------------------------------------------------------------
# Unified output
# ---------------------------------------------------------------------------

@dataclass
class PerceptionFrame:
    """The primary interface consumed by any future Phase 3 (sensor
    fusion). One PerceptionFrame is produced per PerceptionManager
    processing cycle (which may combine a camera frame and/or a LiDAR
    frame — either may be absent if that sensor is not configured)."""
    timestamp: float
    frame_id: int
    objects: list[PerceptionObject] = field(default_factory=list)
    road_state: RoadState = field(default_factory=RoadState)
    drivable_area: DrivableArea = field(default_factory=DrivableArea)
    road_anomalies: list[RoadAnomaly] = field(default_factory=list)
    sensor_status: dict = field(default_factory=dict)
    processing_metrics: ProcessingMetrics = field(default_factory=ProcessingMetrics)
    quality: PerceptionQuality = field(default_factory=PerceptionQuality)
    warnings: list[str] = field(default_factory=list)
    created_at: float = field(default_factory=time.time)

    def to_dict(self) -> dict:
        return {
            "timestamp": self.timestamp,
            "frame_id": self.frame_id,
            "objects": [o.to_dict() for o in self.objects],
            "road_state": self.road_state.to_dict(),
            "drivable_area": self.drivable_area.to_dict(),
            "road_anomalies": [a.to_dict() for a in self.road_anomalies],
            "sensor_status": self.sensor_status,
            "processing_metrics": self.processing_metrics.to_dict(),
            "quality": self.quality.to_dict(),
            "warnings": self.warnings,
        }
