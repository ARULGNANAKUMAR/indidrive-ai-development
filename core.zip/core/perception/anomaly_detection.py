"""
IndiDrive AI — Phase 2 | Road Anomaly Perception Interface
==============================================================
Interface for pothole/crack/debris/mud/gravel/road_edge_damage/
water_patch detection. NO trained road-damage model ships with this
repository, so by default this reports status=NOT_CONFIGURED for every
frame — it must never claim potholes are detected unless a real
trained model is registered and loaded.

The architecture is ready for a future trained model: swap
`backend="NOT_CONFIGURED"` for `backend="REAL"` once a model +
weights are registered (mirroring the object_detection.py pattern),
without changing any caller of `RoadAnomalyDetector.process()`.
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Optional

import numpy as np

from .perception_types import RoadAnomaly, BackendKind, SourceSensor

ANOMALY_TYPES = ("pothole", "crack", "debris", "mud", "gravel", "road_edge_damage", "water_patch")


@dataclass
class AnomalyDetectionResult:
    anomalies: list[RoadAnomaly] = field(default_factory=list)
    status: str = "NOT_CONFIGURED"     # REAL | BASELINE | NOT_CONFIGURED
    latency_ms: float = 0.0
    warnings: list[str] = field(default_factory=list)


class RoadAnomalyDetector:
    def __init__(self, backend: str = "NOT_CONFIGURED", model_path: Optional[str] = None):
        self.backend = (backend or "NOT_CONFIGURED").strip().upper()
        self.model_path = model_path
        self._ready = False
        # Placeholder for a future real model object; intentionally
        # never populated in Phase 2 since no weights are bundled.
        self._model = None

        if self.backend == "REAL":
            if not model_path:
                self.backend = "NOT_CONFIGURED"
            else:
                from pathlib import Path
                if not Path(model_path).exists():
                    self.backend = "NOT_CONFIGURED"
                else:
                    # Intentionally not implemented further: no bundled
                    # road-damage model/format is specified yet. When one
                    # is added, load it here and set self._ready = True.
                    self.backend = "NOT_CONFIGURED"

    def is_ready(self) -> bool:
        return self._ready

    def process(self, image: Optional[np.ndarray], timestamp: float) -> AnomalyDetectionResult:
        t0 = time.perf_counter()
        if self.backend != "REAL" or not self._ready:
            return AnomalyDetectionResult(
                anomalies=[], status="NOT_CONFIGURED",
                latency_ms=(time.perf_counter() - t0) * 1000.0,
                warnings=["road anomaly detection has no trained model registered — "
                          "reporting NOT_CONFIGURED rather than a fabricated result"],
            )
        # Unreachable until a real model is registered (see __init__).
        return AnomalyDetectionResult(anomalies=[], status="NOT_CONFIGURED",
                                       latency_ms=(time.perf_counter() - t0) * 1000.0)
