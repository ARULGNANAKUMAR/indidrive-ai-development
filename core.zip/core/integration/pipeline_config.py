"""
IndiDrive AI — Phase 10.5 | Pipeline Configuration
====================================================
Validated, immutable configuration for the closed-loop integration pipeline.

Integration-specific parameters only.
Do NOT duplicate planner / MPC / control / tracking parameters —
those remain in their respective config modules.

Configuration sections
----------------------
enabled                 : Enable / disable the pipeline.
dt                      : Control timestep (s).  Shared across tracking,
                          MPC, and vehicle dynamics.
max_cycles              : Maximum cycles for run_closed_loop().  0 = unlimited.
stale_timeout_s         : Age beyond which planning/MPC results are stale (s).
strict_frame_validation : Reject frames with inconsistent frame_id.
strict_timestamp_validation : Reject cycles with inconsistent timestamps.
ref_speed_mps           : Default reference speed when not supplied by planner (m/s).
"""
from __future__ import annotations

import math
from dataclasses import dataclass

# ---------------------------------------------------------------------------
# Defaults
# ---------------------------------------------------------------------------

_DEFAULT_DT:                      float = 0.1    # 100 ms control timestep
_DEFAULT_MAX_CYCLES:              int   = 0      # 0 = no limit
_DEFAULT_STALE_TIMEOUT_S:         float = 1.0    # 1 second
_DEFAULT_STRICT_FRAME:            bool  = False  # lenient by default
_DEFAULT_STRICT_TS:               bool  = False
_DEFAULT_REF_SPEED_MPS:           float = 5.0    # m/s fallback reference speed


# ---------------------------------------------------------------------------
# Config dataclass
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class PipelineConfig:
    """
    Immutable, validated configuration for the Phase 10.5 pipeline.

    Attributes
    ----------
    enabled                     : Enable / disable the pipeline.
    dt                          : Control timestep (s) > 0.
    max_cycles                  : Maximum cycles (0 = unlimited).
    stale_timeout_s             : Stale-data threshold (s) > 0.
    strict_frame_validation     : Reject inconsistent frame_ids.
    strict_timestamp_validation : Reject inconsistent timestamps.
    ref_speed_mps               : Fallback reference speed (m/s) ≥ 0.
    """
    enabled:                     bool  = True
    dt:                          float = _DEFAULT_DT
    max_cycles:                  int   = _DEFAULT_MAX_CYCLES
    stale_timeout_s:             float = _DEFAULT_STALE_TIMEOUT_S
    strict_frame_validation:     bool  = _DEFAULT_STRICT_FRAME
    strict_timestamp_validation: bool  = _DEFAULT_STRICT_TS
    ref_speed_mps:               float = _DEFAULT_REF_SPEED_MPS

    def __post_init__(self) -> None:
        self._validate()

    def _validate(self) -> None:
        float_fields = {
            "dt":              self.dt,
            "stale_timeout_s": self.stale_timeout_s,
            "ref_speed_mps":   self.ref_speed_mps,
        }
        for name, val in float_fields.items():
            if not isinstance(val, (int, float)) or not math.isfinite(val):
                raise ValueError(
                    f"PipelineConfig.{name} must be finite, got {val!r}"
                )
        if self.dt <= 0:
            raise ValueError(
                f"PipelineConfig.dt must be > 0, got {self.dt}"
            )
        if self.stale_timeout_s <= 0:
            raise ValueError(
                f"PipelineConfig.stale_timeout_s must be > 0, got {self.stale_timeout_s}"
            )
        if self.ref_speed_mps < 0:
            raise ValueError(
                f"PipelineConfig.ref_speed_mps must be >= 0, got {self.ref_speed_mps}"
            )
        if not isinstance(self.max_cycles, int) or self.max_cycles < 0:
            raise ValueError(
                f"PipelineConfig.max_cycles must be int >= 0, got {self.max_cycles!r}"
            )

    @classmethod
    def default(cls) -> "PipelineConfig":
        return cls()

    @classmethod
    def from_dict(cls, cfg: dict) -> "PipelineConfig":
        """
        Build from a dict (e.g. from YAML under 'closed_loop' key).

        Expected shape::

            closed_loop:
              enabled: true
              dt: 0.1
              max_cycles: 100
              stale_timeout: 1.0
              strict_frame_validation: false
              strict_timestamp_validation: false
              ref_speed_mps: 5.0
        """
        def _f(val, default: float) -> float:
            return float(val) if val is not None else default

        def _i(val, default: int) -> int:
            return int(val) if val is not None else default

        def _b(val, default: bool) -> bool:
            return bool(val) if val is not None else default

        return cls(
            enabled                     = _b(cfg.get("enabled"), True),
            dt                          = _f(cfg.get("dt"), _DEFAULT_DT),
            max_cycles                  = _i(cfg.get("max_cycles"), _DEFAULT_MAX_CYCLES),
            stale_timeout_s             = _f(cfg.get("stale_timeout"), _DEFAULT_STALE_TIMEOUT_S),
            strict_frame_validation     = _b(cfg.get("strict_frame_validation"), _DEFAULT_STRICT_FRAME),
            strict_timestamp_validation = _b(cfg.get("strict_timestamp_validation"), _DEFAULT_STRICT_TS),
            ref_speed_mps               = _f(cfg.get("ref_speed_mps"), _DEFAULT_REF_SPEED_MPS),
        )
