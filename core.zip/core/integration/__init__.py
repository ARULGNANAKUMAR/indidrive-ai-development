"""
IndiDrive AI — Phase 10.5 | core.integration package
======================================================
Closed-loop integration pipeline.
"""
from .pipeline_types import (
    PIPELINE_SCHEMA_VERSION, PIPELINE_NOT_AVAILABLE,
    PipelineStatus, StageStatus, StageResult, PipelineInput, PipelineSnapshot,
)
from .pipeline_config import PipelineConfig
from .reference_adapter import adapt_planner_to_reference, make_minimal_reference
from .autonomous_pipeline import AutonomousPipeline

__all__ = [
    "PIPELINE_SCHEMA_VERSION", "PIPELINE_NOT_AVAILABLE",
    "PipelineStatus", "StageStatus", "StageResult", "PipelineInput", "PipelineSnapshot",
    "PipelineConfig", "adapt_planner_to_reference", "make_minimal_reference",
    "AutonomousPipeline",
]
