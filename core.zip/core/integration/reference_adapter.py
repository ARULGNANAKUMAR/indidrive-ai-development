"""
IndiDrive AI — Phase 10.5 | Reference Trajectory Adapter
==========================================================
Adapts Phase 9.6 planner output (CandidatePath waypoints) into the
Phase 10.2 ReferenceTrajectory format consumed by tracking and MPC.

This adapter is a pure structural conversion.
It does NOT:
    * Generate new path points.
    * Perform collision checking.
    * Re-compute risk scores.
    * Implement any planning logic.

The mapping uses the existing ReferenceTrajectory.from_path_points()
classmethod which is already designed for this purpose (Phase 10.2).

If the selected candidate path is unavailable or has no waypoints,
the adapter returns None and an explicit reason string so the pipeline
can handle the failure cleanly.

Determinism:
    Same (planner_output, candidate_set, ref_speed) → same ReferenceTrajectory.
"""
from __future__ import annotations

import math
from typing import Optional, Tuple

# These imports use project-local packages — no circular imports since
# this module is in core/integration/, separate from core/control/ and
# core/tracking/.


def adapt_planner_to_reference(
    planner_output,          # PlannerOutput from Phase 9.6
    candidate_set,           # CandidatePathSet from Phase 9.2 (may be None)
    ref_speed_mps: float,    # Reference speed hint (m/s)
    frame_id: int = 0,
    timestamp: float = 0.0,
) -> Tuple[Optional[object], str]:
    """
    Convert Phase 9.6 planner output into a Phase 10.2 ReferenceTrajectory.

    The adapter:
    1. Checks that the planner produced a valid plan.
    2. Locates the selected candidate path by ID.
    3. Calls ReferenceTrajectory.from_path_points() with the waypoints.
    4. Returns (trajectory, "") on success or (None, reason) on failure.

    Parameters
    ----------
    planner_output  : PlannerOutput from Phase 9.6.  Must have has_valid_plan=True.
    candidate_set   : CandidatePathSet from Phase 9.2.  May be None.
    ref_speed_mps   : Reference speed to fill into trajectory points (m/s).
    frame_id        : Frame counter for the resulting ReferenceTrajectory.
    timestamp       : Timestamp for the resulting ReferenceTrajectory.

    Returns
    -------
    (ReferenceTrajectory, "")      on success
    (None, reason_string)          on failure
    """
    # --- Late imports to avoid circular imports at module load time -------
    from core.tracking.reference_trajectory import ReferenceTrajectory
    from core.planning.planner_types import NOT_AVAILABLE as PLANNER_NA

    # 1. Planner must have a valid plan
    if planner_output is None:
        return None, "planner_output is None"

    if not planner_output.has_valid_plan:
        status = getattr(planner_output, "planning_status", "UNKNOWN")
        return None, (
            f"planner has no valid plan: status={status}"
        )

    selected_id = getattr(planner_output, "selected_candidate_id", PLANNER_NA)
    if not selected_id or selected_id == PLANNER_NA:
        return None, "planner_output.selected_candidate_id is unavailable"

    # 2. Locate the selected candidate path
    if candidate_set is None:
        return None, "candidate_set is None; cannot locate selected path"

    selected_path = None
    candidates = getattr(candidate_set, "candidates", ()) or ()
    for candidate in candidates:
        cid = getattr(candidate, "candidate_id", None)
        if cid == selected_id:
            selected_path = candidate
            break

    if selected_path is None:
        return None, (
            f"Selected candidate '{selected_id}' not found in "
            f"candidate_set ({len(candidates)} candidates)."
        )

    # 3. Get waypoints
    waypoints = list(getattr(selected_path, "waypoints", ()) or ())
    if len(waypoints) == 0:
        return None, (
            f"Selected candidate '{selected_id}' has no waypoints."
        )

    # 4. Convert to ReferenceTrajectory
    # Clamp reference speed to non-negative
    safe_speed = max(0.0, ref_speed_mps) if math.isfinite(ref_speed_mps) else 0.0

    trajectory = ReferenceTrajectory.from_path_points(
        path_points       = waypoints,
        frame_id          = frame_id,
        timestamp         = timestamp,
        source_id         = selected_id,
        reference_velocity= safe_speed if safe_speed > 0 else None,
    )

    if trajectory.is_empty:
        return None, "Converted ReferenceTrajectory is empty"

    return trajectory, ""


def make_minimal_reference(
    x_end:    float = 20.0,
    speed:    float = 5.0,
    n_points: int   = 10,
    frame_id: int   = 0,
    timestamp: float = 0.0,
) -> object:
    """
    Build a minimal straight-ahead ReferenceTrajectory for testing and
    safe-fallback use.

    Generates n_points evenly spaced along +X from 0 to x_end.
    This is used ONLY in tests and explicit fallback paths — it is NOT
    invoked automatically by the pipeline without being requested.

    Parameters
    ----------
    x_end     : Total forward distance (m).
    speed     : Reference speed (m/s).
    n_points  : Number of trajectory points.
    frame_id  : Frame counter.
    timestamp : Trajectory timestamp.
    """
    from core.tracking.reference_trajectory import ReferenceTrajectory
    from core.planning.candidate_path_types import PathPoint

    step = x_end / max(n_points - 1, 1)
    path_points = [
        PathPoint(x=i * step, y=0.0, z=0.0,
                  longitudinal_s=i * step, lateral_offset_m=0.0,
                  heading=0.0, curvature=0.0)
        for i in range(n_points)
    ]
    traj = ReferenceTrajectory.from_path_points(
        path_points       = path_points,
        frame_id          = frame_id,
        timestamp         = timestamp,
        source_id         = "minimal_straight",
        reference_velocity= speed,
    )
    return traj
