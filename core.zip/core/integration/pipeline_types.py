"""
IndiDrive AI — Phase 10.5 | Pipeline Types
===========================================
Shared enumerations, constants, and typed data containers for the
closed-loop integration pipeline.

Architecture position:
    Phase 9.6 Final Planner
            ↓
    Phase 10.2 Trajectory Tracking
            ↓
    Phase 10.3 MPC Controller
            ↓
    Phase 10.4 Steering / Speed Control
            ↓
    Phase 10.1 Vehicle Dynamics
            ↓
    Phase 10.5 Integration Pipeline  ← this module (types only)

Coordinate convention (project-wide):
    +X = forward, +Y = left, +Z = up
    Origin = vehicle rear-axle centre
    Units  = metres, radians, seconds, m/s, m/s²

Design rules:
    * All containers are frozen dataclasses — immutable after construction.
    * No computation in this module — only type definitions.
    * No circular imports — only import from stdlib and typing.
"""
from __future__ import annotations

import time
import uuid
from dataclasses import dataclass, field
from enum import Enum
from typing import Optional, Tuple

# ---------------------------------------------------------------------------
# Schema / sentinel
# ---------------------------------------------------------------------------

PIPELINE_SCHEMA_VERSION: str = "10.5"
PIPELINE_NOT_AVAILABLE:  str = "NOT_AVAILABLE"

# ---------------------------------------------------------------------------
# Pipeline status
# ---------------------------------------------------------------------------


class PipelineStatus(str, Enum):
    """
    Overall status of one closed-loop pipeline cycle.

    INITIALIZING      — Pipeline is being constructed; no cycle run yet.
    READY             — Initialised and ready to run.
    RUNNING           — Cycle is actively in progress.
    COMPLETED         — Cycle completed successfully; all stages passed.
    PLANNING_FAILED   — Phase 9.6 planner returned an unusable result.
    TRACKING_FAILED   — Phase 10.2 tracking stage failed.
    MPC_FAILED        — Phase 10.3 MPC stage failed.
    CONTROL_FAILED    — Phase 10.4 control stage failed.
    DYNAMICS_FAILED   — Phase 10.1 vehicle dynamics propagation failed.
    DEGRADED          — At least one stage produced a degraded output; pipeline
                        continued with reduced confidence.
    STALE_INPUT       — Pipeline input contained stale data.
    INVALID_INPUT     — Pipeline input was structurally invalid.
    SAFETY_RESTRICTED — Upstream safety gate blocked planning.
    UNKNOWN           — Status cannot be determined.
    """
    INITIALIZING      = "INITIALIZING"
    READY             = "READY"
    RUNNING           = "RUNNING"
    COMPLETED         = "COMPLETED"
    PLANNING_FAILED   = "PLANNING_FAILED"
    TRACKING_FAILED   = "TRACKING_FAILED"
    MPC_FAILED        = "MPC_FAILED"
    CONTROL_FAILED    = "CONTROL_FAILED"
    DYNAMICS_FAILED   = "DYNAMICS_FAILED"
    DEGRADED          = "DEGRADED"
    STALE_INPUT       = "STALE_INPUT"
    INVALID_INPUT     = "INVALID_INPUT"
    SAFETY_RESTRICTED = "SAFETY_RESTRICTED"
    UNKNOWN           = "UNKNOWN"


# ---------------------------------------------------------------------------
# Per-stage status
# ---------------------------------------------------------------------------


class StageStatus(str, Enum):
    """
    Status of a single pipeline stage within one cycle.

    PASSED   — Stage completed with a usable result.
    DEGRADED — Stage produced a result but with reduced confidence.
    FAILED   — Stage could not produce a usable result.
    SKIPPED  — Stage was not executed (upstream stage failed).
    UNKNOWN  — Status cannot be determined.
    """
    PASSED   = "PASSED"
    DEGRADED = "DEGRADED"
    FAILED   = "FAILED"
    SKIPPED  = "SKIPPED"
    UNKNOWN  = "UNKNOWN"


# ---------------------------------------------------------------------------
# Pipeline input
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class PipelineInput:
    """
    Typed input for one closed-loop pipeline cycle.

    Contains all information required to run one complete cycle.
    Does NOT contain raw sensor data, camera images, or LiDAR point clouds.

    Fields
    ------
    vehicle_state       : Current ego vehicle state (Phase 10.1 VehicleState).
    planner_input       : PlannerInput for Phase 9.6 (carries upstream context).
    dt                  : Control timestep (s).  Must be > 0 and finite.
    frame_id            : Cycle frame counter (monotonically increasing).
    timestamp           : Wall-clock time at cycle start (s).
    ref_speed_mps       : Reference speed hint (m/s), or None if unavailable.
                          Used by Phase 10.4 target-speed derivation.
    prev_steering_rad   : Previous commanded steering angle (rad), or None.
                          Passed to MPC for steering-rate cost.
    prev_acceleration   : Previous commanded acceleration (m/s²).
                          Passed to MPC for acceleration-rate cost.
    """
    vehicle_state:      object        # VehicleState — typed at runtime
    planner_input:      object        # PlannerInput — typed at runtime
    dt:                 float         = 0.1
    frame_id:           int           = 0
    timestamp:          float         = field(default_factory=time.monotonic)
    ref_speed_mps:      Optional[float] = None
    prev_steering_rad:  float         = 0.0
    prev_acceleration:  float         = 0.0


# ---------------------------------------------------------------------------
# Stage result (per-stage diagnostic)
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class StageResult:
    """
    Diagnostic container for one pipeline stage result.

    Fields
    ------
    stage       : Stage name (e.g., "planning", "tracking", "mpc", "control",
                  "dynamics").
    status      : StageStatus enum.
    reason      : Human-readable diagnostic string.
    duration_ms : Elapsed time for this stage (ms), or 0.0 if not measured.
    """
    stage:       str         = PIPELINE_NOT_AVAILABLE
    status:      StageStatus = StageStatus.UNKNOWN
    reason:      str         = ""
    duration_ms: float       = 0.0


# ---------------------------------------------------------------------------
# Pipeline snapshot — immutable closed-loop cycle result
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class PipelineSnapshot:
    """
    Immutable snapshot representing one complete closed-loop pipeline cycle.

    Contains all intermediate results and the final vehicle state.
    Used for debugging, testing, and logging.

    Fields
    ------
    cycle_id            : UUID string (unique per cycle).
    timestamp           : Wall-clock time at cycle start (s).
    frame_id            : Cycle frame counter.
    schema_version      : "10.5".

    Stage statuses
    --------------
    planning_status     : StageStatus for Phase 9.6.
    tracking_status     : StageStatus for Phase 10.2.
    mpc_status          : StageStatus for Phase 10.3.
    control_status      : StageStatus for Phase 10.4.
    dynamics_status     : StageStatus for Phase 10.1.

    Stage outputs (may be None if stage was skipped/failed)
    --------------------------------------------------------
    planner_output      : PlannerOutput from Phase 9.6.
    tracking_snapshot   : TrackingSnapshot from Phase 10.2.
    mpc_snapshot        : MPCSnapshot from Phase 10.3.
    control_command     : VehicleControlCommand from Phase 10.4.
    current_vehicle_state  : Vehicle state at cycle start.
    next_vehicle_state     : Vehicle state at cycle end (None if dynamics failed).

    Overall
    -------
    pipeline_status     : PipelineStatus (overall).
    degraded            : True iff any stage produced a degraded result.
    reason_codes        : Tuple of diagnostic strings.
    stage_results       : Tuple of StageResult objects (one per stage).
    cycle_duration_ms   : Total cycle wall-clock time (ms).
    """
    # Identity
    cycle_id:       str   = field(default_factory=lambda: str(uuid.uuid4()))
    timestamp:      float = field(default_factory=time.monotonic)
    frame_id:       int   = 0
    schema_version: str   = PIPELINE_SCHEMA_VERSION

    # Stage statuses
    planning_status:  StageStatus = StageStatus.UNKNOWN
    tracking_status:  StageStatus = StageStatus.UNKNOWN
    mpc_status:       StageStatus = StageStatus.UNKNOWN
    control_status:   StageStatus = StageStatus.UNKNOWN
    dynamics_status:  StageStatus = StageStatus.UNKNOWN

    # Stage outputs
    planner_output:         Optional[object] = None  # PlannerOutput
    tracking_snapshot:      Optional[object] = None  # TrackingSnapshot
    mpc_snapshot:           Optional[object] = None  # MPCSnapshot
    control_command:        Optional[object] = None  # VehicleControlCommand
    current_vehicle_state:  Optional[object] = None  # VehicleState
    next_vehicle_state:     Optional[object] = None  # VehicleState

    # Overall
    pipeline_status:    PipelineStatus     = PipelineStatus.UNKNOWN
    degraded:           bool               = False
    reason_codes:       Tuple[str, ...]    = field(default_factory=tuple)
    stage_results:      Tuple[StageResult, ...] = field(default_factory=tuple)
    cycle_duration_ms:  float              = 0.0

    @property
    def is_completed(self) -> bool:
        return self.pipeline_status == PipelineStatus.COMPLETED

    @property
    def has_next_state(self) -> bool:
        return self.next_vehicle_state is not None

    def __repr__(self) -> str:
        return (
            f"PipelineSnapshot("
            f"status={self.pipeline_status.value}, "
            f"frame={self.frame_id}, "
            f"degraded={self.degraded}, "
            f"duration={self.cycle_duration_ms:.1f}ms)"
        )
