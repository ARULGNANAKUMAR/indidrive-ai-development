"""
IndiDrive AI — Phase 10.5 | Autonomous Pipeline
=================================================
Integrates Phases 9.6 → 10.2 → 10.3 → 10.4 → 10.1 into one deterministic
closed-loop software pipeline.

Architecture
------------
Phase 9.6  PlannerEngine.run()
        ↓
ReferenceTrajectory (Phase 10.2 adapter)
        ↓
Phase 10.2  TrackingEngine.update()
        ↓
Phase 10.3  MPCController.solve()
        ↓
Phase 10.4  ControlManager.step()
        ↓
Phase 10.1  KinematicBicycleModel.step()
        ↓
Next VehicleState → next cycle

Design principles
-----------------
* Deterministic: same (state, planner_input, config) → same output.
* Error-isolated: each stage failure returns an explicit PipelineSnapshot
  without corrupting downstream stages.
* Stateful only where necessary: prev_steering, prev_acceleration,
  control_manager state (for rate-limiting), and cycle counter.
* No new planning, control, or perception logic — orchestration only.

What this module does NOT implement:
    * Path planning or replanning.
    * Obstacle detection or prediction.
    * PID, Pure Pursuit, Stanley, or LQR controllers.
    * CAN bus or hardware actuator control.
    * CARLA VehicleControl (no vehicle.apply_control() calls).
    * New MPC optimisation.
    * LLM or cloud API calls.
"""
from __future__ import annotations

import math
import time
from typing import Iterator, List, Optional, Tuple

from .pipeline_config import PipelineConfig
from .pipeline_types import (
    PIPELINE_NOT_AVAILABLE,
    PIPELINE_SCHEMA_VERSION,
    PipelineSnapshot,
    PipelineStatus,
    StageResult,
    StageStatus,
)
from .reference_adapter import adapt_planner_to_reference


class AutonomousPipeline:
    """
    Stateful orchestrator for the Phase 10.5 closed-loop pipeline.

    State owned by this class
    -------------------------
    _prev_steering_rad     : Previous MPC first_steering_input (for rate cost).
    _prev_acceleration     : Previous MPC first_acceleration_input (rate cost).
    _current_reference     : Most recent valid ReferenceTrajectory.
    _cycle                 : Monotonically increasing cycle counter.
    _last_snapshot         : Most recent PipelineSnapshot.

    Thread safety
    -------------
    Not thread-safe — wrap in a lock if used from multiple threads.

    Usage
    -----
    ::

        cfg      = PipelineConfig.default()
        pipeline = AutonomousPipeline(cfg)
        pipeline.initialize(initial_vehicle_state)

        for step_input in input_stream:
            snapshot = pipeline.step(step_input)
            if snapshot.has_next_state:
                current_state = snapshot.next_vehicle_state
    """

    def __init__(self, config: PipelineConfig) -> None:
        if not isinstance(config, PipelineConfig):
            raise TypeError(
                f"AutonomousPipeline requires PipelineConfig, got {type(config)}"
            )
        self._cfg = config
        self._reset_state()
        self._status = PipelineStatus.INITIALIZING

        # Lazily import heavy modules so tests can import pipeline_types alone.
        self._planner_engine = None
        self._tracking_engine = None
        self._mpc_controller  = None
        self._control_manager = None
        self._bicycle_model   = None

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    @property
    def cycle(self) -> int:
        return self._cycle

    @property
    def status(self) -> PipelineStatus:
        return self._status

    @property
    def last_snapshot(self) -> Optional[PipelineSnapshot]:
        return self._last_snapshot

    def initialize(self, initial_vehicle_state: object) -> None:
        """
        Initialise the pipeline with the starting vehicle state.

        Must be called before step().

        Parameters
        ----------
        initial_vehicle_state : VehicleState (Phase 10.1).
        """
        self._current_vehicle_state = initial_vehicle_state
        self._prev_steering_rad     = 0.0
        self._prev_acceleration     = 0.0
        self._current_reference     = None
        self._cycle                 = 0
        self._last_snapshot         = None

        self._build_components()
        self._status = PipelineStatus.READY

    def reset(self, initial_vehicle_state: Optional[object] = None) -> None:
        """
        Reset pipeline state.

        Restores cycle counter, previous control state, reference, and
        component state.  Does not delete configuration.

        Parameters
        ----------
        initial_vehicle_state : New starting VehicleState, or None to
                                keep the current one.
        """
        if initial_vehicle_state is not None:
            self._current_vehicle_state = initial_vehicle_state
        self._prev_steering_rad  = 0.0
        self._prev_acceleration  = 0.0
        self._current_reference  = None
        self._cycle              = 0
        self._last_snapshot      = None
        if self._control_manager is not None:
            self._control_manager.reset()
        self._status = PipelineStatus.READY

    def step(self, planner_input: object) -> PipelineSnapshot:
        """
        Execute one closed-loop pipeline cycle.

        Parameters
        ----------
        planner_input : PlannerInput for Phase 9.6.
                        Carries world model, planning context, and
                        all upstream phase outputs for this cycle.

        Returns
        -------
        PipelineSnapshot — always returns; never raises.

        Pipeline execution order:
            1. Planning    (Phase 9.6)
            2. Reference   (adapter)
            3. Tracking    (Phase 10.2)
            4. MPC         (Phase 10.3)
            5. Control     (Phase 10.4)
            6. Dynamics    (Phase 10.1)
        """
        if self._status not in (PipelineStatus.READY, PipelineStatus.COMPLETED,
                                 PipelineStatus.DEGRADED, PipelineStatus.RUNNING):
            # Not initialised — return an explicit invalid snapshot
            return self._make_failed_snapshot(
                PipelineStatus.INVALID_INPUT,
                "Pipeline not initialised; call initialize() first.",
                frame_id=getattr(planner_input, "frame_id", 0),
            )

        t_cycle_start = time.monotonic()
        self._status  = PipelineStatus.RUNNING
        frame_id      = getattr(planner_input, "frame_id", self._cycle)
        dt            = self._cfg.dt
        stage_results: List[StageResult] = []
        reason_codes:  List[str]         = []
        degraded       = False

        # Aliases for brevity
        ego_state = self._current_vehicle_state

        # ----------------------------------------------------------------
        # Stage 1 — Planning (Phase 9.6)
        # ----------------------------------------------------------------
        t0 = time.monotonic()
        planner_out, planner_snap, _ = self._planner_engine.run(planner_input)
        planning_ms = (time.monotonic() - t0) * 1000.0

        if planner_out is None or not planner_out.planning_allowed:
            reason = (
                "Planning not allowed by safety gate."
                if planner_out and not planner_out.planning_allowed
                else "Planner returned None."
            )
            stage_results.append(
                StageResult("planning", StageStatus.FAILED, reason, planning_ms)
            )
            return self._finish_snapshot(
                frame_id, t_cycle_start, stage_results,
                PipelineStatus.SAFETY_RESTRICTED
                if (planner_out and not planner_out.planning_allowed)
                else PipelineStatus.PLANNING_FAILED,
                planner_out, None, None, None, ego_state, None,
                reason_codes + [reason],
            )

        plan_status = getattr(planner_out, "planning_status", None)
        from core.planning.planner_types import PlannerStatus
        if plan_status == PlannerStatus.SAFETY_RESTRICTED:
            r = f"Planning blocked: SAFETY_RESTRICTED ({plan_status.value})"
            stage_results.append(
                StageResult("planning", StageStatus.FAILED, r, planning_ms)
            )
            return self._finish_snapshot(
                frame_id, t_cycle_start, stage_results,
                PipelineStatus.SAFETY_RESTRICTED,
                planner_out, None, None, None, ego_state, None,
                [r],
            )

        if not planner_out.has_valid_plan:
            degraded = True
            reason = f"Planner has no valid plan: {plan_status}"
            stage_results.append(
                StageResult("planning", StageStatus.DEGRADED, reason, planning_ms)
            )
            reason_codes.append(reason)
            # Use last known reference if available
            if self._current_reference is None:
                return self._finish_snapshot(
                    frame_id, t_cycle_start, stage_results,
                    PipelineStatus.PLANNING_FAILED,
                    planner_out, None, None, None, ego_state, None,
                    reason_codes,
                )
            # Else fall through with existing reference
        else:
            stage_results.append(
                StageResult("planning", StageStatus.PASSED, "", planning_ms)
            )

        # ----------------------------------------------------------------
        # Stage 2 — Reference adaptation
        # ----------------------------------------------------------------
        candidate_set = getattr(planner_input, "candidate_set", None)
        ref_speed     = self._cfg.ref_speed_mps
        ts_now        = time.monotonic()

        if planner_out.has_valid_plan:
            new_ref, ref_reason = adapt_planner_to_reference(
                planner_output = planner_out,
                candidate_set  = candidate_set,
                ref_speed_mps  = ref_speed,
                frame_id       = frame_id,
                timestamp      = ts_now,
            )
            if new_ref is not None:
                self._current_reference = new_ref
            else:
                reason_codes.append(f"Reference adaptation failed: {ref_reason}")
                degraded = True

        if self._current_reference is None:
            r = "No reference trajectory available (planning and prior reference both unavailable)."
            stage_results.append(
                StageResult("tracking", StageStatus.SKIPPED, r, 0.0)
            )
            return self._finish_snapshot(
                frame_id, t_cycle_start, stage_results,
                PipelineStatus.PLANNING_FAILED,
                planner_out, None, None, None, ego_state, None,
                reason_codes + [r],
            )

        reference = self._current_reference

        # ----------------------------------------------------------------
        # Stage 3 — Tracking (Phase 10.2)
        # ----------------------------------------------------------------
        t0 = time.monotonic()
        try:
            tracking_snap = self._tracking_engine.update(ego_state, reference)
        except Exception as exc:
            r = f"Tracking raised: {exc}"
            stage_results.append(
                StageResult("tracking", StageStatus.FAILED, r, 0.0)
            )
            return self._finish_snapshot(
                frame_id, t_cycle_start, stage_results,
                PipelineStatus.TRACKING_FAILED,
                planner_out, None, None, None, ego_state, None,
                reason_codes + [r],
            )
        tracking_ms = (time.monotonic() - t0) * 1000.0

        from core.tracking.tracking_types import TrackingQuality
        t_quality = getattr(tracking_snap, "tracking_quality", None)
        bad_qualities = {
            TrackingQuality.INVALID_INPUT,
            TrackingQuality.REFERENCE_LOST,
        }
        if t_quality in bad_qualities:
            r = f"Tracking failed: quality={t_quality}"
            stage_results.append(
                StageResult("tracking", StageStatus.FAILED, r, tracking_ms)
            )
            return self._finish_snapshot(
                frame_id, t_cycle_start, stage_results,
                PipelineStatus.TRACKING_FAILED,
                planner_out, tracking_snap, None, None, ego_state, None,
                reason_codes + [r],
            )

        degraded_qualities = {
            TrackingQuality.LARGE_DEVIATION,
            TrackingQuality.STALE_REFERENCE,
            TrackingQuality.DEGRADED,
            TrackingQuality.UNKNOWN,
        }
        if getattr(tracking_snap, "degraded", False) or t_quality in degraded_qualities:
            degraded = True
            reason_codes.append(f"Tracking degraded: quality={t_quality}")
            stage_results.append(
                StageResult("tracking", StageStatus.DEGRADED,
                            str(t_quality), tracking_ms)
            )
        else:
            stage_results.append(
                StageResult("tracking", StageStatus.PASSED, "", tracking_ms)
            )

        # ----------------------------------------------------------------
        # Stage 4 — MPC (Phase 10.3)
        # ----------------------------------------------------------------
        t0 = time.monotonic()
        try:
            mpc_snap = self._mpc_controller.solve(
                ego_state         = ego_state,
                reference         = reference,
                prev_steering     = self._prev_steering_rad,
                prev_acceleration = self._prev_acceleration,
            )
        except Exception as exc:
            r = f"MPC raised: {exc}"
            stage_results.append(
                StageResult("mpc", StageStatus.FAILED, r, 0.0)
            )
            return self._finish_snapshot(
                frame_id, t_cycle_start, stage_results,
                PipelineStatus.MPC_FAILED,
                planner_out, tracking_snap, None, None, ego_state, None,
                reason_codes + [r],
            )
        mpc_ms = (time.monotonic() - t0) * 1000.0

        from core.control.mpc_types import MPCStatus
        mpc_status = getattr(mpc_snap, "status", None)
        mpc_usable_statuses = {
            MPCStatus.SUCCESS,
            MPCStatus.DEGRADED,
            MPCStatus.SOLVER_LIMIT_REACHED,
        }
        if mpc_status not in mpc_usable_statuses or not mpc_snap.feasible:
            r = f"MPC failed: status={mpc_status}, feasible={mpc_snap.feasible}"
            stage_results.append(
                StageResult("mpc", StageStatus.FAILED, r, mpc_ms)
            )
            return self._finish_snapshot(
                frame_id, t_cycle_start, stage_results,
                PipelineStatus.MPC_FAILED,
                planner_out, tracking_snap, mpc_snap, None, ego_state, None,
                reason_codes + [r],
            )

        if mpc_status in (MPCStatus.DEGRADED, MPCStatus.SOLVER_LIMIT_REACHED):
            degraded = True
            reason_codes.append(f"MPC degraded: {mpc_status}")
            stage_results.append(
                StageResult("mpc", StageStatus.DEGRADED, str(mpc_status), mpc_ms)
            )
        else:
            stage_results.append(
                StageResult("mpc", StageStatus.PASSED, "", mpc_ms)
            )

        # ----------------------------------------------------------------
        # Stage 5 — Control (Phase 10.4)
        # ----------------------------------------------------------------
        t0 = time.monotonic()
        try:
            control_cmd = self._control_manager.step(
                snapshot             = mpc_snap,
                current_velocity_mps = ego_state.velocity,
                ref_speed_mps        = ref_speed,
                dt                   = dt,
                frame_id             = frame_id,
                current_time         = ts_now,
            )
        except Exception as exc:
            r = f"Control raised: {exc}"
            stage_results.append(
                StageResult("control", StageStatus.FAILED, r, 0.0)
            )
            return self._finish_snapshot(
                frame_id, t_cycle_start, stage_results,
                PipelineStatus.CONTROL_FAILED,
                planner_out, tracking_snap, mpc_snap, None, ego_state, None,
                reason_codes + [r],
            )
        control_ms = (time.monotonic() - t0) * 1000.0

        from core.control.control_types import ControlCommandStatus
        ctrl_status = getattr(control_cmd, "status", None)
        if ctrl_status in (
            ControlCommandStatus.INVALID,
            ControlCommandStatus.NO_SOLUTION,
        ):
            r = f"Control failed: status={ctrl_status}"
            stage_results.append(
                StageResult("control", StageStatus.FAILED, r, control_ms)
            )
            return self._finish_snapshot(
                frame_id, t_cycle_start, stage_results,
                PipelineStatus.CONTROL_FAILED,
                planner_out, tracking_snap, mpc_snap, control_cmd,
                ego_state, None, reason_codes + [r],
            )

        if ctrl_status in (ControlCommandStatus.LIMITED,
                            ControlCommandStatus.DEGRADED,
                            ControlCommandStatus.STALE):
            degraded = True
            reason_codes.append(f"Control limited/degraded: {ctrl_status}")
            stage_results.append(
                StageResult("control", StageStatus.DEGRADED,
                            str(ctrl_status), control_ms)
            )
        else:
            stage_results.append(
                StageResult("control", StageStatus.PASSED, "", control_ms)
            )

        # ----------------------------------------------------------------
        # Stage 6 — Vehicle dynamics (Phase 10.1)
        # ----------------------------------------------------------------
        t0 = time.monotonic()
        try:
            from core.vehicle.vehicle_input import VehicleControlInput
            model_input = VehicleControlInput(
                steering_angle = mpc_snap.first_steering_input,
                acceleration   = mpc_snap.first_acceleration_input,
                timestamp      = ego_state.timestamp,
                frame_id       = frame_id,
            )
            next_state = self._bicycle_model.step(
                state         = ego_state,
                control_input = model_input,
                dt            = dt,
            )
        except Exception as exc:
            r = f"Dynamics raised: {exc}"
            stage_results.append(
                StageResult("dynamics", StageStatus.FAILED, r, 0.0)
            )
            return self._finish_snapshot(
                frame_id, t_cycle_start, stage_results,
                PipelineStatus.DYNAMICS_FAILED,
                planner_out, tracking_snap, mpc_snap, control_cmd,
                ego_state, None, reason_codes + [r],
            )
        dynamics_ms = (time.monotonic() - t0) * 1000.0
        stage_results.append(
            StageResult("dynamics", StageStatus.PASSED, "", dynamics_ms)
        )

        # ----------------------------------------------------------------
        # Update state for next cycle
        # ----------------------------------------------------------------
        self._prev_steering_rad  = mpc_snap.first_steering_input
        self._prev_acceleration  = mpc_snap.first_acceleration_input
        self._current_vehicle_state = next_state
        self._cycle += 1

        final_status = PipelineStatus.DEGRADED if degraded else PipelineStatus.COMPLETED
        self._status = final_status

        snap = self._finish_snapshot(
            frame_id, t_cycle_start, stage_results, final_status,
            planner_out, tracking_snap, mpc_snap, control_cmd,
            ego_state, next_state, reason_codes,
        )
        self._last_snapshot = snap
        return snap

    def run_closed_loop(
        self,
        planner_input_sequence,  # Iterable[PlannerInput]
        update_planner_frame: bool = True,
    ) -> List[PipelineSnapshot]:
        """
        Run multiple closed-loop cycles.

        Parameters
        ----------
        planner_input_sequence : Iterable of PlannerInput objects, one per
                                  cycle.  If max_cycles is set, stops at
                                  that limit.
        update_planner_frame   : If True, update frame_id on each PlannerInput
                                  to match the current cycle.

        Returns
        -------
        List[PipelineSnapshot] — one per executed cycle.
        """
        snapshots = []
        max_c = self._cfg.max_cycles

        for i, pi in enumerate(planner_input_sequence):
            if max_c > 0 and i >= max_c:
                break
            snap = self.step(pi)
            snapshots.append(snap)
            if not snap.has_next_state and snap.pipeline_status not in (
                PipelineStatus.COMPLETED, PipelineStatus.DEGRADED
            ):
                break  # Unrecoverable failure — stop loop

        return snapshots

    def step_with_reference(
        self,
        reference,
        frame_id: int = 0,
        ref_speed_mps=None,
    ):
        """
        One pipeline cycle using a pre-built reference (bypasses planner).
        Stages: Tracking → MPC → Control → Dynamics.
        """
        if self._status not in (PipelineStatus.READY, PipelineStatus.COMPLETED,
                                 PipelineStatus.DEGRADED, PipelineStatus.RUNNING):
            return self._make_failed_snapshot(
                PipelineStatus.INVALID_INPUT,
                "Pipeline not initialised; call initialize() first.",
                frame_id=frame_id,
            )
        t_cycle_start = time.monotonic()
        self._status  = PipelineStatus.RUNNING
        dt            = self._cfg.dt
        stage_results = []
        reason_codes  = []
        degraded      = False
        ego_state     = self._current_vehicle_state
        if ref_speed_mps is None:
            ref_speed_mps = self._cfg.ref_speed_mps

        if reference is None:
            return self._finish_snapshot(
                frame_id, t_cycle_start, stage_results,
                PipelineStatus.PLANNING_FAILED,
                None, None, None, None, ego_state, None, ["reference is None"],
            )
        self._current_reference = reference
        ts_now = time.monotonic()

        # Tracking
        t0 = time.monotonic()
        try:
            tracking_snap = self._tracking_engine.update(ego_state, reference)
        except Exception as exc:
            r = f"Tracking raised: {exc}"
            stage_results.append(StageResult("tracking", StageStatus.FAILED, r, 0.0))
            return self._finish_snapshot(frame_id, t_cycle_start, stage_results,
                PipelineStatus.TRACKING_FAILED, None, None, None, None, ego_state, None, [r])
        tracking_ms = (time.monotonic() - t0) * 1000.0
        from core.tracking.tracking_types import TrackingQuality
        t_quality = getattr(tracking_snap, "tracking_quality", None)
        if t_quality in (TrackingQuality.INVALID_INPUT, TrackingQuality.REFERENCE_LOST):
            r = f"Tracking failed: quality={t_quality}"
            stage_results.append(StageResult("tracking", StageStatus.FAILED, r, tracking_ms))
            return self._finish_snapshot(frame_id, t_cycle_start, stage_results,
                PipelineStatus.TRACKING_FAILED, None, tracking_snap, None, None, ego_state, None, [r])
        stage_results.append(StageResult("tracking", StageStatus.PASSED, "", tracking_ms))

        # MPC
        t0 = time.monotonic()
        try:
            mpc_snap = self._mpc_controller.solve(
                ego_state=ego_state, reference=reference,
                prev_steering=self._prev_steering_rad,
                prev_acceleration=self._prev_acceleration,
            )
        except Exception as exc:
            r = f"MPC raised: {exc}"
            stage_results.append(StageResult("mpc", StageStatus.FAILED, r, 0.0))
            return self._finish_snapshot(frame_id, t_cycle_start, stage_results,
                PipelineStatus.MPC_FAILED, None, tracking_snap, None, None, ego_state, None, [r])
        mpc_ms = (time.monotonic() - t0) * 1000.0
        from core.control.mpc_types import MPCStatus
        mpc_usable = {MPCStatus.SUCCESS, MPCStatus.DEGRADED, MPCStatus.SOLVER_LIMIT_REACHED}
        if mpc_snap.status not in mpc_usable or not mpc_snap.feasible:
            r = f"MPC failed: status={mpc_snap.status}, feasible={mpc_snap.feasible}"
            stage_results.append(StageResult("mpc", StageStatus.FAILED, r, mpc_ms))
            return self._finish_snapshot(frame_id, t_cycle_start, stage_results,
                PipelineStatus.MPC_FAILED, None, tracking_snap, mpc_snap, None, ego_state, None, [r])
        stage_results.append(StageResult("mpc", StageStatus.PASSED, "", mpc_ms))

        # Control
        t0 = time.monotonic()
        try:
            control_cmd = self._control_manager.step(
                snapshot=mpc_snap, current_velocity_mps=ego_state.velocity,
                ref_speed_mps=ref_speed_mps, dt=dt, frame_id=frame_id,
                current_time=ts_now,
            )
        except Exception as exc:
            r = f"Control raised: {exc}"
            stage_results.append(StageResult("control", StageStatus.FAILED, r, 0.0))
            return self._finish_snapshot(frame_id, t_cycle_start, stage_results,
                PipelineStatus.CONTROL_FAILED, None, tracking_snap, mpc_snap, None, ego_state, None, [r])
        control_ms = (time.monotonic() - t0) * 1000.0
        from core.control.control_types import ControlCommandStatus
        if control_cmd.status in (ControlCommandStatus.INVALID, ControlCommandStatus.NO_SOLUTION):
            r = f"Control failed: status={control_cmd.status}"
            stage_results.append(StageResult("control", StageStatus.FAILED, r, control_ms))
            return self._finish_snapshot(frame_id, t_cycle_start, stage_results,
                PipelineStatus.CONTROL_FAILED, None, tracking_snap, mpc_snap, control_cmd,
                ego_state, None, [r])
        stage_results.append(StageResult("control", StageStatus.PASSED, "", control_ms))

        # Dynamics
        t0 = time.monotonic()
        try:
            from core.vehicle.vehicle_input import VehicleControlInput
            model_input = VehicleControlInput(
                steering_angle=mpc_snap.first_steering_input,
                acceleration=mpc_snap.first_acceleration_input,
                timestamp=ego_state.timestamp, frame_id=frame_id,
            )
            next_state = self._bicycle_model.step(ego_state, model_input, dt)
        except Exception as exc:
            r = f"Dynamics raised: {exc}"
            stage_results.append(StageResult("dynamics", StageStatus.FAILED, r, 0.0))
            return self._finish_snapshot(frame_id, t_cycle_start, stage_results,
                PipelineStatus.DYNAMICS_FAILED, None, tracking_snap, mpc_snap, control_cmd,
                ego_state, None, [r])
        dynamics_ms = (time.monotonic() - t0) * 1000.0
        stage_results.append(StageResult("dynamics", StageStatus.PASSED, "", dynamics_ms))

        # Update state for next cycle
        self._prev_steering_rad  = mpc_snap.first_steering_input
        self._prev_acceleration  = mpc_snap.first_acceleration_input
        self._current_vehicle_state = next_state
        self._cycle += 1

        final_status = PipelineStatus.DEGRADED if degraded else PipelineStatus.COMPLETED
        self._status = final_status
        snap = self._finish_snapshot(
            frame_id, t_cycle_start, stage_results, final_status,
            None, tracking_snap, mpc_snap, control_cmd,
            ego_state, next_state, reason_codes,
        )
        self._last_snapshot = snap
        return snap

    def get_snapshot(self) -> Optional[PipelineSnapshot]:
        """Return the most recent PipelineSnapshot, or None if no cycle run."""
        return self._last_snapshot

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _reset_state(self) -> None:
        self._current_vehicle_state = None
        self._prev_steering_rad     = 0.0
        self._prev_acceleration     = 0.0
        self._current_reference     = None
        self._cycle                 = 0
        self._last_snapshot         = None

    def _build_components(self) -> None:
        """Instantiate all pipeline components with default configs."""
        from core.planning.planner_engine import PlannerEngine
        from core.tracking.tracking_engine import TrackingEngine
        from core.control.mpc_controller import MPCController
        from core.control.control_manager import ControlManager
        from core.control.control_config import ControlConfig
        from core.vehicle.bicycle_model import KinematicBicycleModel
        from core.vehicle.vehicle_parameters import VehicleParameters

        self._planner_engine   = PlannerEngine()
        self._tracking_engine  = TrackingEngine()
        self._mpc_controller   = MPCController()
        self._control_manager  = ControlManager(ControlConfig.default())
        self._bicycle_model    = KinematicBicycleModel(VehicleParameters.default())

    def _finish_snapshot(
        self,
        frame_id:       int,
        t_start:        float,
        stage_results:  list,
        pipeline_status: PipelineStatus,
        planner_out,
        tracking_snap,
        mpc_snap,
        control_cmd,
        current_state,
        next_state,
        reason_codes:   list,
    ) -> PipelineSnapshot:
        duration_ms = (time.monotonic() - t_start) * 1000.0

        # Derive per-stage statuses from stage_results
        def _stage_status(name: str) -> StageStatus:
            for sr in stage_results:
                if sr.stage == name:
                    return sr.status
            return StageStatus.SKIPPED

        snap = PipelineSnapshot(
            timestamp             = t_start,
            frame_id              = frame_id,
            schema_version        = PIPELINE_SCHEMA_VERSION,
            planning_status       = _stage_status("planning"),
            tracking_status       = _stage_status("tracking"),
            mpc_status            = _stage_status("mpc"),
            control_status        = _stage_status("control"),
            dynamics_status       = _stage_status("dynamics"),
            planner_output        = planner_out,
            tracking_snapshot     = tracking_snap,
            mpc_snapshot          = mpc_snap,
            control_command       = control_cmd,
            current_vehicle_state = current_state,
            next_vehicle_state    = next_state,
            pipeline_status       = pipeline_status,
            degraded              = (pipeline_status == PipelineStatus.DEGRADED),
            reason_codes          = tuple(reason_codes),
            stage_results         = tuple(stage_results),
            cycle_duration_ms     = duration_ms,
        )
        self._last_snapshot = snap
        return snap

    def _make_failed_snapshot(
        self,
        status:   PipelineStatus,
        reason:   str,
        frame_id: int = 0,
    ) -> PipelineSnapshot:
        import time as _time
        snap = PipelineSnapshot(
            timestamp       = _time.monotonic(),
            frame_id        = frame_id,
            schema_version  = PIPELINE_SCHEMA_VERSION,
            pipeline_status = status,
            degraded        = False,
            reason_codes    = (reason,),
            stage_results   = (),
        )
        self._last_snapshot = snap
        return snap
