"""
IndiDrive AI — Phase 10.2 | Reference Trajectory
=================================================
Typed reference trajectory consumed by the trajectory tracker.

A ReferenceTrajectory is the output of the Phase 9.6 planner (converted
from a CandidatePath / PathPoint list or built directly for testing).
It is an INPUT to Phase 10.2; Phase 10.2 never generates trajectories.

Coordinate convention (project-wide):
    +X = forward, +Y = left, +Z = up
    Origin = vehicle rear-axle centre
    Units  = metres, radians, seconds

Each ReferencePoint carries:
    x, y          — position (m) — REQUIRED
    yaw           — heading (rad), normalised to [-π, π) — optional
    velocity      — reference speed (m/s) — optional
    acceleration  — reference longitudinal acceleration (m/s²) — optional
    curvature     — reference path curvature κ (1/m) — optional
    yaw_rate      — reference ψ̇ (rad/s) — optional
    timestamp     — time at which this point is valid (s) — optional
    arc_length_m  — cumulative arc length from the first point (m) — optional
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import List, Optional, Tuple

from .tracking_types import NOT_AVAILABLE, TRACKING_SCHEMA_VERSION, ReferenceAvailability
from ..vehicle.vehicle_state import normalise_angle
from ..vehicle.vehicle_types import CoordinateFrame


# ---------------------------------------------------------------------------
# Reference point
# ---------------------------------------------------------------------------

@dataclass
class ReferencePoint:
    """
    One point along the reference trajectory.

    Required:
        x, y  — position in metres.

    Optional (None = unavailable):
        yaw, velocity, acceleration, curvature, yaw_rate, timestamp,
        arc_length_m.

    Do not fabricate optional fields.  Unavailable fields stay None.
    """

    x: float = 0.0                       # longitudinal position (m)
    y: float = 0.0                       # lateral position (m)
    yaw: Optional[float] = None          # heading (rad) — normalised to [-π, π)
    velocity: Optional[float] = None     # reference speed (m/s)
    acceleration: Optional[float] = None # reference longitudinal acceleration (m/s²)
    curvature: Optional[float] = None    # reference curvature κ (1/m)
    yaw_rate: Optional[float] = None     # reference ψ̇ (rad/s)
    timestamp: Optional[float] = None   # time (s) — None if not time-stamped
    arc_length_m: Optional[float] = None # cumulative arc length from start (m)

    def __post_init__(self) -> None:
        # Normalise yaw on construction if provided
        if self.yaw is not None and math.isfinite(self.yaw):
            self.yaw = normalise_angle(self.yaw)

    def is_position_finite(self) -> bool:
        """Return True iff x and y are finite."""
        return math.isfinite(self.x) and math.isfinite(self.y)

    def yaw_availability(self) -> ReferenceAvailability:
        if self.yaw is None:
            return ReferenceAvailability.UNAVAILABLE
        if not math.isfinite(self.yaw):
            return ReferenceAvailability.INVALID
        return ReferenceAvailability.AVAILABLE

    def velocity_availability(self) -> ReferenceAvailability:
        if self.velocity is None:
            return ReferenceAvailability.UNAVAILABLE
        if not math.isfinite(self.velocity):
            return ReferenceAvailability.INVALID
        return ReferenceAvailability.AVAILABLE


# ---------------------------------------------------------------------------
# Reference trajectory
# ---------------------------------------------------------------------------

@dataclass
class ReferenceTrajectory:
    """
    Ordered sequence of ReferencePoints forming the reference path.

    This is the INPUT to Phase 10.2.  Phase 10.2 never generates it.

    Attributes
    ----------
    points          : Ordered list of ReferencePoint.  Must be non-empty
                      for a valid trajectory.
    frame_id        : Planning frame that produced this trajectory.
    timestamp       : Wall-clock time when the trajectory was generated (s).
    coordinate_frame: CoordinateFrame (must be VEHICLE for Phase 10.2).
    source_id       : Opaque identifier linking back to the candidate/path
                      that produced this reference (e.g. selected_candidate_id).
    schema_version  : "10.2".
    """

    points:           List[ReferencePoint] = field(default_factory=list)
    frame_id:         int                  = 0
    timestamp:        float                = 0.0
    coordinate_frame: CoordinateFrame      = CoordinateFrame.VEHICLE
    source_id:        str                  = NOT_AVAILABLE
    schema_version:   str                  = TRACKING_SCHEMA_VERSION

    # ------------------------------------------------------------------ #
    # Properties
    # ------------------------------------------------------------------ #

    @property
    def is_empty(self) -> bool:
        return len(self.points) == 0

    @property
    def length(self) -> int:
        return len(self.points)

    @property
    def has_yaw(self) -> bool:
        """True iff at least one point has a valid yaw."""
        return any(
            p.yaw is not None and math.isfinite(p.yaw) for p in self.points
        )

    @property
    def has_velocity(self) -> bool:
        """True iff at least one point has a valid velocity."""
        return any(
            p.velocity is not None and math.isfinite(p.velocity) for p in self.points
        )

    @property
    def has_timestamps(self) -> bool:
        """True iff all points have finite timestamps."""
        return all(
            p.timestamp is not None and math.isfinite(p.timestamp)
            for p in self.points
        )

    # ------------------------------------------------------------------ #
    # Factory helpers
    # ------------------------------------------------------------------ #

    @classmethod
    def from_xy_list(
        cls,
        xy_pairs: List[Tuple[float, float]],
        frame_id: int = 0,
        timestamp: float = 0.0,
        source_id: str = NOT_AVAILABLE,
    ) -> "ReferenceTrajectory":
        """
        Build a minimal trajectory from (x, y) pairs.

        Yaw is derived from consecutive point directions where possible.
        Heading for the last point is copied from the second-to-last.
        A single point gets yaw=0.0.
        """
        if not xy_pairs:
            return cls(points=[], frame_id=frame_id, timestamp=timestamp,
                       source_id=source_id)

        pts: List[ReferencePoint] = []
        n = len(xy_pairs)

        for i, (x, y) in enumerate(xy_pairs):
            if i < n - 1:
                dx = xy_pairs[i + 1][0] - x
                dy = xy_pairs[i + 1][1] - y
                if abs(dx) < 1e-9 and abs(dy) < 1e-9:
                    yaw = pts[-1].yaw if pts else 0.0
                else:
                    yaw = math.atan2(dy, dx)
            elif n == 1:
                yaw = 0.0
            else:
                yaw = pts[-1].yaw if pts else 0.0

            pts.append(ReferencePoint(x=x, y=y, yaw=yaw))

        return cls(points=pts, frame_id=frame_id, timestamp=timestamp,
                   source_id=source_id)

    @classmethod
    def from_path_points(
        cls,
        path_points: list,          # List of PathPoint from candidate_path_types
        frame_id: int = 0,
        timestamp: float = 0.0,
        source_id: str = NOT_AVAILABLE,
        reference_velocity: Optional[float] = None,
    ) -> "ReferenceTrajectory":
        """
        Adapt Phase 9.6 PathPoint objects into a ReferenceTrajectory.

        PathPoint carries: x, y, z, longitudinal_s, lateral_offset_m,
        heading (optional), curvature (optional).

        No velocity in PathPoint — pass reference_velocity to fill all points
        with a uniform speed if available.
        """
        pts: List[ReferencePoint] = []
        n = len(path_points)

        for i, pp in enumerate(path_points):
            yaw = pp.heading  # may be None

            # If no heading, try deriving from adjacent points
            if yaw is None and i < n - 1:
                nxt = path_points[i + 1]
                dx = nxt.x - pp.x
                dy = nxt.y - pp.y
                if abs(dx) > 1e-9 or abs(dy) > 1e-9:
                    yaw = math.atan2(dy, dx)
            elif yaw is None and i > 0 and pts:
                yaw = pts[-1].yaw

            pts.append(ReferencePoint(
                x=pp.x,
                y=pp.y,
                yaw=yaw,
                velocity=reference_velocity,
                acceleration=None,
                curvature=pp.curvature,
                arc_length_m=pp.longitudinal_s if hasattr(pp, "longitudinal_s") else None,
            ))

        return cls(points=pts, frame_id=frame_id, timestamp=timestamp,
                   source_id=source_id)
