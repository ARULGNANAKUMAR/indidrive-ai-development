"""
IndiDrive AI — Phase 10.2 | Tracking Error
==========================================
Typed containers for trajectory tracking errors and matched reference state.

All quantities are in SI units.  Optional fields are None when the
corresponding reference data is unavailable — they are NEVER fabricated.

Sign conventions (vehicle coordinate frame: +X forward, +Y left):
    cross_track_error_m  > 0 → ego is to the LEFT  of the reference path
    cross_track_error_m  < 0 → ego is to the RIGHT of the reference path
    along_track_error_m  > 0 → ego is AHEAD of the matched reference point
    along_track_error_m  < 0 → ego is BEHIND the matched reference point
    heading_error_rad    > 0 → ego heading is CCW (left) of reference heading
    speed_error_mps      > 0 → ego is FASTER than reference speed

Phase 10.2 does NOT produce:
    * steering commands
    * throttle / brake commands
    * MPC outputs
    * actuator commands
"""
from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Optional

from .tracking_types import NOT_AVAILABLE


# ---------------------------------------------------------------------------
# Matched reference state
# ---------------------------------------------------------------------------

@dataclass
class ReferenceState:
    """
    The reference point extracted from the trajectory for the current cycle.

    Only fields available in the input trajectory are populated.
    Unavailable fields are None.

    matched_index — index into ReferenceTrajectory.points of the matched point.
    interpolated  — True if position/heading were interpolated between points.
    """
    matched_index:      int            = 0
    interpolated:       bool           = False

    # Position (always present for a valid match)
    reference_x:        float          = 0.0
    reference_y:        float          = 0.0

    # Optional reference quantities — None = not available in input
    reference_yaw:         Optional[float] = None  # rad
    reference_velocity:    Optional[float] = None  # m/s
    reference_acceleration:Optional[float] = None  # m/s²
    reference_curvature:   Optional[float] = None  # 1/m
    reference_yaw_rate:    Optional[float] = None  # rad/s
    reference_timestamp:   Optional[float] = None  # s

    def has_yaw(self) -> bool:
        return (
            self.reference_yaw is not None
            and math.isfinite(self.reference_yaw)
        )

    def has_velocity(self) -> bool:
        return (
            self.reference_velocity is not None
            and math.isfinite(self.reference_velocity)
        )

    def __repr__(self) -> str:
        yaw_str = f"{math.degrees(self.reference_yaw):.1f}°" \
                  if self.reference_yaw is not None else "N/A"
        vel_str = f"{self.reference_velocity:.2f} m/s" \
                  if self.reference_velocity is not None else "N/A"
        return (
            f"ReferenceState(idx={self.matched_index}, "
            f"x={self.reference_x:.3f}, y={self.reference_y:.3f}, "
            f"yaw={yaw_str}, v={vel_str})"
        )


# ---------------------------------------------------------------------------
# Tracking error
# ---------------------------------------------------------------------------

@dataclass
class TrackingError:
    """
    Geometric and kinematic errors of the ego vehicle relative to the
    matched reference point.

    All distance fields are in metres, angle fields in radians, velocity
    fields in m/s, curvature in 1/m, yaw-rate in rad/s.

    Fields that cannot be computed (missing reference data or unavailable
    ego state) are None.  They are NEVER guessed or fabricated.

    Sign conventions (see module docstring for details):
        cross_track_error_m  > 0 → ego is to the LEFT
        along_track_error_m  > 0 → ego is AHEAD
        heading_error_rad    > 0 → ego heading is CCW of reference
        speed_error_mps      > 0 → ego is FASTER
    """

    # Distance from ego to the nearest reference point/segment (m)
    nearest_distance_m: float = 0.0

    # Signed lateral deviation perpendicular to the reference path (m)
    cross_track_error_m: float = 0.0

    # Signed longitudinal displacement along the reference direction (m)
    along_track_error_m: float = 0.0

    # Heading error normalised to [-π, π) (rad)
    heading_error_rad: float = 0.0

    # Speed error (m/s) — None if reference velocity unavailable
    speed_error_mps: Optional[float] = None

    # Acceleration error (m/s²) — None if either value unavailable
    acceleration_error_mps2: Optional[float] = None

    # Curvature error (1/m) — None if reference curvature unavailable
    curvature_error_1pm: Optional[float] = None

    # Yaw-rate error (rad/s) — None if reference yaw-rate unavailable
    yaw_rate_error_radps: Optional[float] = None

    # ------------------------------------------------------------------ #
    # Derived convenience properties
    # ------------------------------------------------------------------ #

    @property
    def lateral_abs_m(self) -> float:
        """Absolute lateral deviation (m)."""
        return abs(self.cross_track_error_m)

    @property
    def heading_abs_rad(self) -> float:
        """Absolute heading error (rad)."""
        return abs(self.heading_error_rad)

    def all_primary_finite(self) -> bool:
        """True iff the three primary errors are finite numbers."""
        return (
            math.isfinite(self.nearest_distance_m)
            and math.isfinite(self.cross_track_error_m)
            and math.isfinite(self.along_track_error_m)
            and math.isfinite(self.heading_error_rad)
        )

    def __repr__(self) -> str:
        spd = f"{self.speed_error_mps:.2f}" \
              if self.speed_error_mps is not None else "N/A"
        return (
            f"TrackingError("
            f"cte={self.cross_track_error_m:.3f} m, "
            f"ate={self.along_track_error_m:.3f} m, "
            f"he={math.degrees(self.heading_error_rad):.1f}°, "
            f"speed_err={spd} m/s)"
        )
