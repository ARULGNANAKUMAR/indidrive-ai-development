"""
IndiDrive AI — Phase 10.2 | Tracking Engine
============================================
The central Phase 10.2 entry point.

TrackingEngine.update() takes the current ego VehicleState and a
ReferenceTrajectory and returns a TrackingSnapshot describing how well
the vehicle is following the reference path.

Architecture position:

    Phase 9.6 Final Planner
            ↓
    ReferenceTrajectory
            ↓
    Phase 10.1 VehicleState
            ↓
    TrackingEngine.update()     ← Phase 10.2
            ↓
    TrackingSnapshot
            ↓
    Phase 10.3 MPC (future)

This module does NOT:
    * generate or select paths
    * implement any controller (no MPC, no PID, no Pure Pursuit, no Stanley)
    * produce actuator / CARLA commands
    * modify the bicycle model or vehicle parameters
    * run perception, prediction, or planning

Design:
    * Stateless computation; no hidden shared mutable state.
    * Deterministic: same inputs → same snapshot.
    * Thread-safe: multiple callers may share one engine instance.
"""
from __future__ import annotations

import math
import time
from typing import List, Optional, Tuple

from .reference_trajectory import ReferenceTrajectory
from .tracking_config import TrackingConfig
from .tracking_error import ReferenceState, TrackingError
from .tracking_snapshot import TrackingSnapshot
from .tracking_types import NOT_AVAILABLE, TrackingQuality
from .tracking_validator import TrackingValidator
from .trajectory_matcher import TrajectoryMatcher
from ..vehicle.vehicle_state import VehicleState


class TrackingEngine:
    """
    Phase 10.2 trajectory tracking engine.

    Usage
    -----
    >>> engine = TrackingEngine(config)
    >>> snap = engine.update(ego_state=vehicle_state,
    ...                      reference=reference_trajectory)

    The engine is stateless: it does not retain results between calls.
    """

    def __init__(self, config: Optional[TrackingConfig] = None) -> None:
        self._config  = config or TrackingConfig.default()
        self._matcher = TrajectoryMatcher(self._config.matching_method)

    @property
    def config(self) -> TrackingConfig:
        return self._config

    # ------------------------------------------------------------------ #
    # Primary API
    # ------------------------------------------------------------------ #

    def update(
        self,
        ego_state: VehicleState,
        reference: ReferenceTrajectory,
    ) -> TrackingSnapshot:
        """
        Perform one tracking update cycle.

        Parameters
        ----------
        ego_state  : Current ego vehicle state (Phase 10.1 VehicleState).
        reference  : Reference trajectory from Phase 9.6 planner.

        Returns
        -------
        TrackingSnapshot — immutable result; never raises.

        Notes
        -----
        * All validation errors produce a snapshot with an appropriate
          TrackingQuality rather than raising exceptions.
        * All inputs are treated as read-only; neither is modified.
        """
        if not self._config.enabled:
            return self._make_unknown_snapshot(ego_state, reference)

        # --- Validate ego state ------------------------------------------
        ego_ok, _, ego_reasons = TrackingValidator.validate_ego_state(ego_state)
        if not ego_ok:
            return self._make_failed_snapshot(
                ego_state, reference,
                TrackingQuality.INVALID_INPUT,
                ego_reasons,
            )

        # --- Validate reference trajectory --------------------------------
        traj_ok, traj_quality, traj_reasons = TrackingValidator.validate_trajectory(
            reference, self._config, ego_state.timestamp
        )
        if not traj_ok:
            return self._make_failed_snapshot(
                ego_state, reference, traj_quality, traj_reasons
            )

        # --- Validate coordinate frames -----------------------------------
        frame_ok, _, frame_reasons = TrackingValidator.validate_coordinate_frames(
            ego_state, reference
        )
        if not frame_ok:
            return self._make_failed_snapshot(
                ego_state, reference,
                TrackingQuality.INVALID_INPUT,
                frame_reasons,
            )

        # --- Match and compute errors -------------------------------------
        try:
            match_result, ref_state, error = self._matcher.match(
                ego_state, reference
            )
        except Exception as exc:  # pragma: no cover — defensive
            return self._make_failed_snapshot(
                ego_state, reference,
                TrackingQuality.INVALID_INPUT,
                [f"matcher error: {exc}"],
            )

        # --- Assess tracking quality -------------------------------------
        quality, reason_codes = self._assess_quality(error)

        return TrackingSnapshot.from_result(
            ref_state    = ref_state,
            error        = error,
            quality      = quality,
            sim_timestamp= ego_state.timestamp,
            frame_id     = ego_state.frame_id,
            source_id    = reference.source_id,
            degraded     = (quality not in (
                TrackingQuality.ON_TRACK,
                TrackingQuality.MINOR_DEVIATION,
            )),
            confidence   = self._confidence(quality),
            reason_codes = tuple(reason_codes),
            interpolated = match_result.t_on_segment > 0.0,
        )

    # ------------------------------------------------------------------ #
    # Quality assessment
    # ------------------------------------------------------------------ #

    def _assess_quality(
        self,
        error: TrackingError,
    ) -> Tuple[TrackingQuality, List[str]]:
        """
        Map tracking errors to a TrackingQuality category.

        Uses only configurable thresholds — no hard-coded values.
        """
        cfg    = self._config
        codes: List[str] = []

        cte = abs(error.cross_track_error_m)
        he  = abs(error.heading_error_rad)
        spd = abs(error.speed_error_mps) if error.speed_error_mps is not None else 0.0

        # Large deviation — highest priority
        if cte >= cfg.cte_large_m:
            codes.append("LARGE_LATERAL_DEVIATION")
            return TrackingQuality.LARGE_DEVIATION, codes

        # Major threshold
        major = False
        if cte >= cfg.cte_major_m:
            codes.append("MAJOR_LATERAL_DEVIATION")
            major = True
        if he >= cfg.heading_major_rad:
            codes.append("MAJOR_HEADING_ERROR")
            major = True
        if error.speed_error_mps is not None and spd >= cfg.speed_major_mps:
            codes.append("MAJOR_SPEED_ERROR")
            major = True
        if major:
            return TrackingQuality.DEVIATING, codes

        # Minor threshold
        minor = False
        if cte >= cfg.cte_minor_m:
            codes.append("MINOR_LATERAL_DEVIATION")
            minor = True
        if he >= cfg.heading_minor_rad:
            codes.append("MINOR_HEADING_ERROR")
            minor = True
        if error.speed_error_mps is not None and spd >= cfg.speed_minor_mps:
            codes.append("MINOR_SPEED_ERROR")
            minor = True
        if minor:
            return TrackingQuality.MINOR_DEVIATION, codes

        return TrackingQuality.ON_TRACK, codes

    # ------------------------------------------------------------------ #
    # Confidence helper
    # ------------------------------------------------------------------ #

    @staticmethod
    def _confidence(quality: TrackingQuality) -> float:
        """
        Deterministic confidence mapping from quality.

        These are ordinal estimates, not statistical probabilities.
        They are NOT tracking-error magnitudes.
        """
        _map = {
            TrackingQuality.ON_TRACK:        1.0,
            TrackingQuality.MINOR_DEVIATION: 0.8,
            TrackingQuality.DEVIATING:       0.5,
            TrackingQuality.LARGE_DEVIATION: 0.2,
            TrackingQuality.STALE_REFERENCE: 0.1,
            TrackingQuality.REFERENCE_LOST:  0.0,
            TrackingQuality.INVALID_INPUT:   0.0,
            TrackingQuality.DEGRADED:        0.3,
            TrackingQuality.UNKNOWN:         0.0,
        }
        return _map.get(quality, 0.0)

    # ------------------------------------------------------------------ #
    # Snapshot helpers for error cases
    # ------------------------------------------------------------------ #

    def _make_unknown_snapshot(
        self,
        ego: VehicleState,
        ref: Optional[ReferenceTrajectory],
    ) -> TrackingSnapshot:
        return self._make_failed_snapshot(
            ego, ref, TrackingQuality.UNKNOWN, ["TRACKING_DISABLED"]
        )

    def _make_failed_snapshot(
        self,
        ego: Optional[VehicleState],
        ref: Optional[ReferenceTrajectory],
        quality: TrackingQuality,
        reasons: List[str],
    ) -> TrackingSnapshot:
        ts      = ego.timestamp if ego is not None else 0.0
        fid     = ego.frame_id  if ego is not None else 0
        src_id  = ref.source_id if ref is not None else NOT_AVAILABLE

        # Build zero-error sentinel to fill the snapshot
        zero_ref = ReferenceState(matched_index=0, reference_x=0.0, reference_y=0.0)
        zero_err = TrackingError()

        return TrackingSnapshot.from_result(
            ref_state    = zero_ref,
            error        = zero_err,
            quality      = quality,
            sim_timestamp= ts,
            frame_id     = fid,
            source_id    = src_id,
            degraded     = True,
            confidence   = self._confidence(quality),
            reason_codes = tuple(reasons),
            interpolated = False,
        )
