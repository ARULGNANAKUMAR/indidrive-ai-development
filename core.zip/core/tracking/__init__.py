"""
IndiDrive AI — Phase 10.2 | Trajectory Tracking Foundation
===========================================================
Public API for the Phase 10.2 tracking package.

Architecture position:

    Phase 9.6 Final Planner
            ↓
    ReferenceTrajectory
            ↓
    Phase 10.1 VehicleState
            ↓
    TrackingEngine.update()     ← Phase 10.2
            ↓
    TrackingSnapshot
            ↓
    Phase 10.3 MPC (future)

Phase 10.2 does NOT produce:
    * steering / throttle / brake commands
    * MPC outputs
    * actuator commands
    * CARLA control calls

Coordinate convention (project-wide):
    +X = forward, +Y = left, +Z = up
    Origin = vehicle rear-axle centre
    Units  = metres, radians, seconds
"""

from .tracking_types import (
    TRACKING_SCHEMA_VERSION,
    NOT_AVAILABLE,
    MatchingMethod,
    TrackingQuality,
    ReferenceAvailability,
)
from .reference_trajectory import ReferencePoint, ReferenceTrajectory
from .tracking_error import ReferenceState, TrackingError
from .tracking_config import TrackingConfig
from .tracking_validator import TrackingValidator
from .tracking_snapshot import TrackingSnapshot
from .trajectory_matcher import TrajectoryMatcher
from .tracking_engine import TrackingEngine

__all__ = [
    "TRACKING_SCHEMA_VERSION",
    "NOT_AVAILABLE",
    "MatchingMethod",
    "TrackingQuality",
    "ReferenceAvailability",
    "ReferencePoint",
    "ReferenceTrajectory",
    "ReferenceState",
    "TrackingError",
    "TrackingConfig",
    "TrackingValidator",
    "TrackingSnapshot",
    "TrajectoryMatcher",
    "TrackingEngine",
]
