"""
IndiDrive AI — Phase 10.2 | Trajectory Matcher
===============================================
Deterministic nearest-point and nearest-segment matching of the ego
vehicle position against a ReferenceTrajectory.

This module answers:
    "Which reference point / segment is the ego vehicle closest to, and
     what are the geometric tracking errors at that match?"

It does NOT:
    * generate paths or trajectories
    * select among planner candidates
    * issue any control commands (no MPC, no PID, no Pure Pursuit)
    * modify ego state or reference trajectory

Coordinate convention (project-wide):
    +X = forward, +Y = left, +Z = up
    Origin = vehicle rear-axle centre
    Units  = metres, radians, seconds

Sign convention for tracking errors:
    cross_track_error_m  > 0 → ego is to the LEFT  of the reference path
    cross_track_error_m  < 0 → ego is to the RIGHT of the reference path
    along_track_error_m  > 0 → ego is AHEAD of the matched reference point
    along_track_error_m  < 0 → ego is BEHIND the matched reference point
    heading_error_rad    > 0 → ego heading is CCW (left) relative to ref
    speed_error_mps      > 0 → ego is FASTER than reference speed

Equations for cross-track and along-track error
------------------------------------------------
Let  ref  = (x_r, y_r, ψ_r)  —  matched reference point
     ego  = (x_e, y_e, ψ_e)  —  current ego position + heading

dx = x_e - x_r
dy = y_e - y_r

cross_track  = -sin(ψ_r) · dx  +  cos(ψ_r) · dy
along_track  =  cos(ψ_r) · dx  +  sin(ψ_r) · dy

These are standard 2-D rotation of (dx, dy) into the reference frame,
which gives the lateral (perpendicular) and longitudinal (parallel)
components of the ego-to-reference displacement vector.

Reference for sign convention:
    In the vehicle frame +Y = left, so a positive cross-track error means
    the ego is displaced in the +Y direction relative to the path tangent.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Optional, Tuple

from .reference_trajectory import ReferencePoint, ReferenceTrajectory
from .tracking_error import ReferenceState, TrackingError
from .tracking_types import MatchingMethod, NOT_AVAILABLE
from ..vehicle.vehicle_state import VehicleState, normalise_angle


# ---------------------------------------------------------------------------
# Internal: segment projection helper
# ---------------------------------------------------------------------------

def _project_point_onto_segment(
    px: float, py: float,
    ax: float, ay: float,
    bx: float, by: float,
) -> Tuple[float, float, float]:
    """
    Project point P=(px, py) onto segment A→B.

    Returns
    -------
    (qx, qy, t)
        qx, qy — projected point on segment (clamped to [A, B])
        t      — parameter in [0, 1] along the segment (0=A, 1=B)
    """
    dx = bx - ax
    dy = by - ay
    len_sq = dx * dx + dy * dy

    if len_sq < 1e-12:
        # Degenerate zero-length segment — return A
        return ax, ay, 0.0

    t = ((px - ax) * dx + (py - ay) * dy) / len_sq
    t = max(0.0, min(1.0, t))
    return ax + t * dx, ay + t * dy, t


def _sq_dist(x1: float, y1: float, x2: float, y2: float) -> float:
    return (x1 - x2) ** 2 + (y1 - y2) ** 2


# ---------------------------------------------------------------------------
# Matching result
# ---------------------------------------------------------------------------

@dataclass
class MatchResult:
    """
    Internal result of the trajectory-matching step.

    nearest_index   — index of the closest reference point.
    projected_x/y   — the actual projection point on the nearest segment.
    reference_yaw   — heading at the matched location (may be derived).
    t_on_segment    — interpolation parameter in [0,1] for nearest segment.
    segment_index   — lower index of the segment (index, index+1); -1 if
                      single-point trajectory.
    distance_m      — Euclidean distance from ego to the projected point.
    """
    nearest_index: int   = 0
    projected_x:   float = 0.0
    projected_y:   float = 0.0
    reference_yaw: Optional[float] = None
    t_on_segment:  float = 0.0
    segment_index: int   = -1
    distance_m:    float = 0.0


# ---------------------------------------------------------------------------
# Trajectory matcher
# ---------------------------------------------------------------------------

class TrajectoryMatcher:
    """
    Stateless deterministic trajectory matcher.

    Given the ego state and a reference trajectory, this class:
    1. Finds the nearest reference segment (or point).
    2. Projects the ego onto that segment.
    3. Computes cross-track, along-track, heading, speed, and optional
       curvature / yaw-rate errors.
    4. Interpolates reference quantities between adjacent points.

    The matcher holds no mutable state; all computation is in methods that
    receive all required data as arguments.  Multiple threads may safely
    share one matcher instance.
    """

    def __init__(self, method: MatchingMethod = MatchingMethod.NEAREST_SEGMENT) -> None:
        self._method = method

    @property
    def method(self) -> MatchingMethod:
        return self._method

    # ------------------------------------------------------------------ #
    # Primary API
    # ------------------------------------------------------------------ #

    def match(
        self,
        ego: VehicleState,
        trajectory: ReferenceTrajectory,
    ) -> Tuple[MatchResult, ReferenceState, TrackingError]:
        """
        Match *ego* against *trajectory* and compute tracking errors.

        Returns
        -------
        (MatchResult, ReferenceState, TrackingError)

        Raises
        ------
        ValueError : if trajectory is empty (caller should guard with
                     validator first).
        """
        if trajectory.is_empty:
            raise ValueError("Cannot match against an empty ReferenceTrajectory")

        if self._method == MatchingMethod.NEAREST_SEGMENT:
            match_result = self._match_nearest_segment(ego, trajectory)
        else:
            match_result = self._match_nearest_point(ego, trajectory)

        ref_state = self._extract_reference_state(match_result, trajectory)
        error     = self._compute_errors(ego, ref_state, match_result)

        return match_result, ref_state, error

    # ------------------------------------------------------------------ #
    # Matching strategies
    # ------------------------------------------------------------------ #

    def _match_nearest_point(
        self,
        ego: VehicleState,
        trajectory: ReferenceTrajectory,
    ) -> MatchResult:
        """Find the nearest reference point by Euclidean distance."""
        ex, ey = ego.x, ego.y
        best_idx  = 0
        best_dist = float("inf")

        for i, pt in enumerate(trajectory.points):
            d = _sq_dist(ex, ey, pt.x, pt.y)
            if d < best_dist:
                best_dist = d
                best_idx  = i

        pt  = trajectory.points[best_idx]
        ref_yaw = self._point_yaw(best_idx, trajectory)

        return MatchResult(
            nearest_index = best_idx,
            projected_x   = pt.x,
            projected_y   = pt.y,
            reference_yaw = ref_yaw,
            t_on_segment  = 0.0,
            segment_index = -1,
            distance_m    = math.sqrt(best_dist),
        )

    def _match_nearest_segment(
        self,
        ego: VehicleState,
        trajectory: ReferenceTrajectory,
    ) -> MatchResult:
        """
        Find nearest point on any trajectory segment and project ego onto it.

        For a single-point trajectory, falls back to nearest-point matching.
        """
        pts = trajectory.points
        if len(pts) == 1:
            return self._match_nearest_point(ego, trajectory)

        ex, ey = ego.x, ego.y
        best_dist    = float("inf")
        best_qx      = pts[0].x
        best_qy      = pts[0].y
        best_t       = 0.0
        best_seg_idx = 0
        best_pt_idx  = 0

        for i in range(len(pts) - 1):
            a, b = pts[i], pts[i + 1]
            qx, qy, t = _project_point_onto_segment(
                ex, ey, a.x, a.y, b.x, b.y
            )
            d = _sq_dist(ex, ey, qx, qy)
            if d < best_dist:
                best_dist    = d
                best_qx      = qx
                best_qy      = qy
                best_t       = t
                best_seg_idx = i
                best_pt_idx  = i  # lower index of segment

        ref_yaw = self._segment_yaw(
            best_seg_idx, best_t, trajectory
        )

        return MatchResult(
            nearest_index = best_pt_idx,
            projected_x   = best_qx,
            projected_y   = best_qy,
            reference_yaw = ref_yaw,
            t_on_segment  = best_t,
            segment_index = best_seg_idx,
            distance_m    = math.sqrt(best_dist),
        )

    # ------------------------------------------------------------------ #
    # Reference state extraction (with interpolation)
    # ------------------------------------------------------------------ #

    def _extract_reference_state(
        self,
        match: MatchResult,
        trajectory: ReferenceTrajectory,
    ) -> ReferenceState:
        """
        Build ReferenceState from the match result, interpolating optional
        quantities between adjacent points when on a segment.
        """
        pts = trajectory.points
        i   = match.nearest_index
        t   = match.t_on_segment
        j   = match.segment_index        # second point of segment, or -1
        interpolated = (j >= 0 and 0.0 < t < 1.0)

        pt_a = pts[i]
        pt_b = pts[j + 1] if (j >= 0 and j + 1 < len(pts)) else None

        def _interp_opt(va, vb):
            """Linearly interpolate two optional scalars."""
            if va is None:
                return None
            if vb is None or not interpolated:
                return va
            return va + t * (vb - va)

        def _interp_angle(va, vb):
            """Angle-aware interpolation to avoid discontinuities at ±π."""
            if va is None:
                return None
            if vb is None or not interpolated:
                return va
            diff = normalise_angle(vb - va)
            return normalise_angle(va + t * diff)

        ref_yaw    = _interp_angle(pt_a.yaw, pt_b.yaw if pt_b else None)
        ref_vel    = _interp_opt(pt_a.velocity,     pt_b.velocity     if pt_b else None)
        ref_acc    = _interp_opt(pt_a.acceleration, pt_b.acceleration if pt_b else None)
        ref_kappa  = _interp_opt(pt_a.curvature,    pt_b.curvature    if pt_b else None)
        ref_yawrate= _interp_opt(pt_a.yaw_rate,     pt_b.yaw_rate     if pt_b else None)
        ref_ts     = _interp_opt(pt_a.timestamp,    pt_b.timestamp    if pt_b else None)

        # Override yaw with the derived/segment yaw if the point's own
        # yaw was unavailable
        if ref_yaw is None:
            ref_yaw = match.reference_yaw

        return ReferenceState(
            matched_index          = i,
            interpolated           = interpolated,
            reference_x            = match.projected_x,
            reference_y            = match.projected_y,
            reference_yaw          = ref_yaw,
            reference_velocity     = ref_vel,
            reference_acceleration = ref_acc,
            reference_curvature    = ref_kappa,
            reference_yaw_rate     = ref_yawrate,
            reference_timestamp    = ref_ts,
        )

    # ------------------------------------------------------------------ #
    # Error computation
    # ------------------------------------------------------------------ #

    def _compute_errors(
        self,
        ego: VehicleState,
        ref: ReferenceState,
        match: MatchResult,
    ) -> TrackingError:
        """
        Compute all tracking errors from ego state and matched reference.

        Cross-track and along-track errors require a valid reference heading.
        If heading is unavailable, these default to 0.0 with nearest_distance
        still computed from Euclidean distance.
        """
        dx = ego.x - ref.reference_x
        dy = ego.y - ref.reference_y
        nearest_dist = match.distance_m  # already Euclidean from matcher

        if ref.reference_yaw is not None and math.isfinite(ref.reference_yaw):
            psi_r = ref.reference_yaw
            # Standard 2-D rotation into reference frame
            cte  = -math.sin(psi_r) * dx + math.cos(psi_r) * dy
            ate  =  math.cos(psi_r) * dx + math.sin(psi_r) * dy
            # Heading error
            he   = normalise_angle(ego.yaw - psi_r)
        else:
            cte  = 0.0
            ate  = 0.0
            he   = 0.0

        # Speed error
        if (ref.reference_velocity is not None
                and math.isfinite(ref.reference_velocity)):
            speed_err: Optional[float] = ego.velocity - ref.reference_velocity
        else:
            speed_err = None

        # Acceleration error
        if (ref.reference_acceleration is not None
                and math.isfinite(ref.reference_acceleration)):
            accel_err: Optional[float] = (
                ego.acceleration - ref.reference_acceleration
            )
        else:
            accel_err = None

        # Curvature error — ego curvature from bicycle model state
        from ..vehicle.bicycle_model import KinematicBicycleModel
        from ..vehicle.vehicle_parameters import VehicleParameters
        _kbm = KinematicBicycleModel(VehicleParameters.default())
        ego_curvature = _kbm.curvature(ego.steering_angle)

        if (ref.reference_curvature is not None
                and math.isfinite(ref.reference_curvature)):
            kappa_err: Optional[float] = ego_curvature - ref.reference_curvature
        else:
            kappa_err = None

        # Yaw-rate error
        if (ref.reference_yaw_rate is not None
                and math.isfinite(ref.reference_yaw_rate)):
            yr_err: Optional[float] = ego.yaw_rate - ref.reference_yaw_rate
        else:
            yr_err = None

        return TrackingError(
            nearest_distance_m      = nearest_dist,
            cross_track_error_m     = cte,
            along_track_error_m     = ate,
            heading_error_rad       = he,
            speed_error_mps         = speed_err,
            acceleration_error_mps2 = accel_err,
            curvature_error_1pm     = kappa_err,
            yaw_rate_error_radps    = yr_err,
        )

    # ------------------------------------------------------------------ #
    # Heading helpers
    # ------------------------------------------------------------------ #

    def _point_yaw(self, idx: int, traj: ReferenceTrajectory) -> Optional[float]:
        """
        Get heading at point *idx*.

        If the point has an explicit yaw, use it.
        Otherwise derive from neighbouring points.
        """
        pts = traj.points
        pt  = pts[idx]
        if pt.yaw is not None and math.isfinite(pt.yaw):
            return pt.yaw

        # Try forward direction
        if idx < len(pts) - 1:
            dx = pts[idx + 1].x - pt.x
            dy = pts[idx + 1].y - pt.y
            if abs(dx) > 1e-9 or abs(dy) > 1e-9:
                return normalise_angle(math.atan2(dy, dx))

        # Try backward direction
        if idx > 0:
            dx = pt.x - pts[idx - 1].x
            dy = pt.y - pts[idx - 1].y
            if abs(dx) > 1e-9 or abs(dy) > 1e-9:
                return normalise_angle(math.atan2(dy, dx))

        return None

    def _segment_yaw(
        self,
        seg_idx: int,
        t: float,
        traj: ReferenceTrajectory,
    ) -> Optional[float]:
        """
        Heading at parameter *t* along segment (seg_idx, seg_idx+1).

        If both endpoints have explicit yaw, interpolate (angle-aware).
        Otherwise derive from the segment direction.
        """
        pts = traj.points
        a   = pts[seg_idx]
        b   = pts[seg_idx + 1]

        ya = a.yaw
        yb = b.yaw

        if (ya is not None and math.isfinite(ya)
                and yb is not None and math.isfinite(yb)):
            diff = normalise_angle(yb - ya)
            return normalise_angle(ya + t * diff)

        # Derive from segment direction
        dx = b.x - a.x
        dy = b.y - a.y
        if abs(dx) > 1e-9 or abs(dy) > 1e-9:
            return normalise_angle(math.atan2(dy, dx))

        # Zero-length segment
        if ya is not None and math.isfinite(ya):
            return ya
        return None
