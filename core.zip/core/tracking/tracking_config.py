"""
IndiDrive AI — Phase 10.2 | Tracking Configuration
====================================================
Runtime configuration for the trajectory tracker.

All threshold values are in SI units.  They are explicitly labelled as
configuration defaults — not characterised vehicle/road specifications.

YAML key: tracking:
"""
from __future__ import annotations

import math
from dataclasses import dataclass

from .tracking_types import MatchingMethod


@dataclass
class TrackingConfig:
    """
    Configurable thresholds and settings for Phase 10.2.

    Attributes
    ----------
    enabled                 : Master switch; False → engine returns UNKNOWN.
    matching_method         : NEAREST_SEGMENT (default) or NEAREST_POINT.
    max_reference_age_s     : Seconds before a reference trajectory is
                              considered stale (STALE_REFERENCE).
    min_trajectory_points   : Minimum required points; fewer → REFERENCE_LOST.

    Cross-track thresholds (m):
        cte_minor_m         : ON_TRACK → MINOR_DEVIATION boundary.
        cte_major_m         : MINOR_DEVIATION → DEVIATING boundary.
        cte_large_m         : DEVIATING → LARGE_DEVIATION boundary.

    Heading thresholds (rad):
        heading_minor_rad   : ON_TRACK → MINOR_DEVIATION.
        heading_major_rad   : MINOR_DEVIATION → DEVIATING.

    Speed thresholds (m/s):
        speed_minor_mps     : ON_TRACK → MINOR_DEVIATION (signed; absolute value used).
        speed_major_mps     : MINOR_DEVIATION → DEVIATING.
    """

    # Master switch
    enabled: bool = True

    # Matching
    matching_method: MatchingMethod = MatchingMethod.NEAREST_SEGMENT

    # Staleness
    max_reference_age_s: float = 1.0    # trajectory older than this → STALE

    # Minimum trajectory size
    min_trajectory_points: int = 1

    # Cross-track error thresholds (m)
    cte_minor_m: float = 0.30
    cte_major_m: float = 1.00
    cte_large_m: float = 3.00

    # Heading error thresholds (rad) — ~17° and ~45°
    heading_minor_rad: float = 0.30
    heading_major_rad: float = 0.785  # π/4

    # Speed error thresholds (m/s)
    speed_minor_mps: float = 2.0
    speed_major_mps: float = 5.0

    def __post_init__(self) -> None:
        for name, val in [
            ("max_reference_age_s", self.max_reference_age_s),
            ("cte_minor_m",         self.cte_minor_m),
            ("cte_major_m",         self.cte_major_m),
            ("cte_large_m",         self.cte_large_m),
            ("heading_minor_rad",   self.heading_minor_rad),
            ("heading_major_rad",   self.heading_major_rad),
            ("speed_minor_mps",     self.speed_minor_mps),
            ("speed_major_mps",     self.speed_major_mps),
        ]:
            if not math.isfinite(val) or val < 0:
                raise ValueError(
                    f"TrackingConfig.{name} must be finite and ≥ 0, got {val}"
                )
        if self.min_trajectory_points < 1:
            raise ValueError(
                f"min_trajectory_points must be ≥ 1, got {self.min_trajectory_points}"
            )

    @classmethod
    def default(cls) -> "TrackingConfig":
        return cls()

    @classmethod
    def from_dict(cls, cfg: dict) -> "TrackingConfig":
        """Build from a partial YAML-loaded dict."""
        def _f(k, d):
            v = cfg.get(k, d)
            return float(v) if v is not None else d

        def _i(k, d):
            v = cfg.get(k, d)
            return int(v) if v is not None else d

        def _b(k, d):
            v = cfg.get(k, d)
            return bool(v) if v is not None else d

        method_str = cfg.get("matching_method", "NEAREST_SEGMENT").upper()
        try:
            method = MatchingMethod[method_str]
        except KeyError:
            method = MatchingMethod.NEAREST_SEGMENT

        return cls(
            enabled               = _b("enabled", True),
            matching_method       = method,
            max_reference_age_s   = _f("max_reference_age_s",  1.0),
            min_trajectory_points = _i("min_trajectory_points", 1),
            cte_minor_m           = _f("cte_minor_m",           0.30),
            cte_major_m           = _f("cte_major_m",           1.00),
            cte_large_m           = _f("cte_large_m",           3.00),
            heading_minor_rad     = _f("heading_minor_rad",      0.30),
            heading_major_rad     = _f("heading_major_rad",      0.785),
            speed_minor_mps       = _f("speed_minor_mps",        2.0),
            speed_major_mps       = _f("speed_major_mps",        5.0),
        )
