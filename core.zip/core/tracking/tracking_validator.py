"""
IndiDrive AI — Phase 10.2 | Tracking Validator
===============================================
Deterministic validation of Phase 10.2 inputs before processing.

Invalid inputs return explicit error codes rather than producing
misleading-looking valid tracking results.

No side effects; no mutable state.  All methods are static.
"""
from __future__ import annotations

import math
import time
from typing import List, Tuple

from .reference_trajectory import ReferenceTrajectory
from .tracking_config import TrackingConfig
from .tracking_types import TrackingQuality, NOT_AVAILABLE
from ..vehicle.vehicle_state import VehicleState
from ..vehicle.vehicle_types import CoordinateFrame


# Return type: (ok: bool, quality: TrackingQuality, reasons: List[str])
ValidationResult = Tuple[bool, TrackingQuality, List[str]]


class TrackingValidator:
    """
    Collection of validation checks for Phase 10.2 data contracts.

    All methods are static; instantiation is optional.
    """

    @staticmethod
    def validate_ego_state(state: VehicleState) -> ValidationResult:
        """Validate that ego state is numerically sound."""
        reasons: List[str] = []
        try:
            state.validate()
        except ValueError as exc:
            reasons.append(f"ego_state invalid: {exc}")
            return False, TrackingQuality.INVALID_INPUT, reasons
        return True, TrackingQuality.UNKNOWN, reasons

    @staticmethod
    def validate_trajectory(
        traj: ReferenceTrajectory,
        config: TrackingConfig,
        ego_timestamp: float,
    ) -> ValidationResult:
        """
        Validate reference trajectory.

        Checks:
        * trajectory exists and is not empty
        * has at least min_trajectory_points
        * all point positions are finite
        * coordinate frame is VEHICLE
        * trajectory timestamp is not stale
        """
        reasons: List[str] = []

        if traj is None:
            reasons.append("reference_trajectory is None")
            return False, TrackingQuality.REFERENCE_LOST, reasons

        if traj.is_empty:
            reasons.append("reference_trajectory is empty")
            return False, TrackingQuality.REFERENCE_LOST, reasons

        if traj.length < config.min_trajectory_points:
            reasons.append(
                f"trajectory has {traj.length} point(s), "
                f"min required: {config.min_trajectory_points}"
            )
            return False, TrackingQuality.REFERENCE_LOST, reasons

        if traj.coordinate_frame != CoordinateFrame.VEHICLE:
            reasons.append(
                f"coordinate_frame mismatch: got {traj.coordinate_frame}, "
                f"expected VEHICLE"
            )
            return False, TrackingQuality.INVALID_INPUT, reasons

        # Check all positions are finite
        for i, pt in enumerate(traj.points):
            if not pt.is_position_finite():
                reasons.append(
                    f"trajectory point[{i}] has non-finite position "
                    f"(x={pt.x}, y={pt.y})"
                )
                return False, TrackingQuality.INVALID_INPUT, reasons
            if not math.isfinite(traj.timestamp):
                reasons.append("trajectory.timestamp is non-finite")
                return False, TrackingQuality.INVALID_INPUT, reasons

        # Staleness check
        if math.isfinite(traj.timestamp) and math.isfinite(ego_timestamp):
            age_s = ego_timestamp - traj.timestamp
            if age_s > config.max_reference_age_s:
                reasons.append(
                    f"reference trajectory is stale: age={age_s:.3f}s > "
                    f"max={config.max_reference_age_s}s"
                )
                return False, TrackingQuality.STALE_REFERENCE, reasons

        return True, TrackingQuality.UNKNOWN, reasons

    @staticmethod
    def validate_coordinate_frames(
        ego: VehicleState,
        traj: ReferenceTrajectory,
    ) -> ValidationResult:
        """Both ego state and trajectory must be in VEHICLE frame."""
        reasons: List[str] = []
        if ego.coordinate_frame != CoordinateFrame.VEHICLE:
            reasons.append(
                f"ego coordinate_frame={ego.coordinate_frame}, expected VEHICLE"
            )
            return False, TrackingQuality.INVALID_INPUT, reasons
        if traj.coordinate_frame != CoordinateFrame.VEHICLE:
            reasons.append(
                f"trajectory coordinate_frame={traj.coordinate_frame}, expected VEHICLE"
            )
            return False, TrackingQuality.INVALID_INPUT, reasons
        return True, TrackingQuality.UNKNOWN, reasons
