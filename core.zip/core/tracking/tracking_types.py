"""
IndiDrive AI — Phase 10.2 | Tracking Types — Enums and Constants
================================================================
Shared enumerations, sentinels, and schema version for the trajectory
tracking package.

Nothing here performs computation; all values are structural.

Coordinate convention (project-wide, same as Phases 9.x and 10.1):
    +X = forward, +Y = left, +Z = up
    Origin = vehicle rear-axle centre
    Units  = metres, radians, seconds
"""
from __future__ import annotations

from enum import Enum

# ---------------------------------------------------------------------------
# Schema version
# ---------------------------------------------------------------------------

TRACKING_SCHEMA_VERSION: str = "10.2"

# Sentinel for optional / unavailable fields
NOT_AVAILABLE: str = "NOT_AVAILABLE"

# ---------------------------------------------------------------------------
# Matching method
# ---------------------------------------------------------------------------

class MatchingMethod(str, Enum):
    """
    Algorithm used to select the reference point/segment for the current
    ego position.

    NEAREST_POINT   — Euclidean nearest point in the reference list.
    NEAREST_SEGMENT — Nearest point on any segment, then project onto it.
                      Handles the case where the ego lies between two
                      sparsely-sampled reference points.
    """
    NEAREST_POINT   = "NEAREST_POINT"
    NEAREST_SEGMENT = "NEAREST_SEGMENT"


# ---------------------------------------------------------------------------
# Tracking quality
# ---------------------------------------------------------------------------

class TrackingQuality(str, Enum):
    """
    Deterministic categorical assessment of ego-vehicle deviation from the
    reference trajectory.

    Thresholds are configured in TrackingConfig — not hard-coded here.

    ON_TRACK         — errors within all minor thresholds.
    MINOR_DEVIATION  — at least one error exceeds its minor threshold,
                       but none exceeds its major threshold.
    DEVIATING        — at least one error exceeds its major threshold.
    LARGE_DEVIATION  — cross-track or heading error is very large; the
                       vehicle may be off-road.
    REFERENCE_LOST   — reference trajectory is empty or matching failed
                       completely.
    STALE_REFERENCE  — reference trajectory exists but its timestamp is
                       older than max_reference_age_s.
    INVALID_INPUT    — ego state or trajectory failed basic validation.
    DEGRADED         — partial data; result carries elevated uncertainty.
    UNKNOWN          — cannot determine quality (e.g. first cycle).
    """
    ON_TRACK         = "ON_TRACK"
    MINOR_DEVIATION  = "MINOR_DEVIATION"
    DEVIATING        = "DEVIATING"
    LARGE_DEVIATION  = "LARGE_DEVIATION"
    REFERENCE_LOST   = "REFERENCE_LOST"
    STALE_REFERENCE  = "STALE_REFERENCE"
    INVALID_INPUT    = "INVALID_INPUT"
    DEGRADED         = "DEGRADED"
    UNKNOWN          = "UNKNOWN"


# ---------------------------------------------------------------------------
# Reference availability
# ---------------------------------------------------------------------------

class ReferenceAvailability(str, Enum):
    """
    Whether the matched reference point has usable data for a given field.

    AVAILABLE     — field is present and finite.
    UNAVAILABLE   — field is None / missing in the input trajectory.
    DERIVED       — field was computed from adjacent points (e.g. heading).
    INVALID       — field is present but non-finite.
    """
    AVAILABLE   = "AVAILABLE"
    UNAVAILABLE = "UNAVAILABLE"
    DERIVED     = "DERIVED"
    INVALID     = "INVALID"
