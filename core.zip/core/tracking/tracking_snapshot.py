"""
IndiDrive AI — Phase 10.2 | Tracking Snapshot
==============================================
Immutable result snapshot from one trajectory-tracking cycle.

The snapshot contains everything needed to audit or diagnose one update:

    timestamp, frame_id, source_id
    matched_index, reference_state (scalar copies)
    tracking_error (scalar copies)
    tracking_quality
    confidence, degraded, reason_codes
    schema_version

Modifying upstream objects after snapshot creation does NOT mutate
the snapshot.  All fields are copied from their sources at creation time.

This snapshot is NOT:
    * a control command
    * an actuator command
    * an MPC output
    * a steering / throttle / brake target
"""
from __future__ import annotations

import math
import time
from dataclasses import dataclass, field
from typing import Optional, Tuple

from .tracking_types import (
    TRACKING_SCHEMA_VERSION,
    NOT_AVAILABLE,
    TrackingQuality,
)
from .tracking_error import ReferenceState, TrackingError


@dataclass(frozen=True)
class TrackingSnapshot:
    """
    Immutable snapshot of one tracking-engine update cycle.

    frozen=True — no field can be changed after construction.
    All mutable inputs are copied to scalar values at creation.

    Fields
    ------
    schema_version     : "10.2".
    snap_timestamp     : Wall-clock time when snapshot was taken (s).
    sim_timestamp      : Ego-state simulation timestamp (s).
    frame_id           : Frame counter from the ego state.
    source_id          : Planning source ID from the reference trajectory.

    matched_index      : Index of the matched reference point.
    interpolated       : True if match was interpolated between segments.

    # Reference state (scalar copies)
    ref_x, ref_y       : Matched reference position (m).
    ref_yaw            : Reference heading (rad); NaN if unavailable.
    ref_velocity       : Reference speed (m/s); NaN if unavailable.
    ref_curvature      : Reference curvature (1/m); NaN if unavailable.

    # Tracking errors (scalar copies)
    nearest_distance_m      : Euclidean distance to nearest reference (m).
    cross_track_error_m     : Signed lateral deviation (m).
    along_track_error_m     : Signed longitudinal displacement (m).
    heading_error_rad       : Heading error (rad), normalised to [-π, π).
    speed_error_mps         : Speed error (m/s); NaN if unavailable.
    curvature_error_1pm     : Curvature error (1/m); NaN if unavailable.
    yaw_rate_error_radps    : Yaw-rate error (rad/s); NaN if unavailable.

    # Status
    tracking_quality   : TrackingQuality enum.
    degraded           : True if result carries elevated uncertainty.
    confidence         : [0, 1] — UNKNOWN represented as 0.
    reason_codes       : Tuple of diagnostic string codes.
    """

    # Identity
    schema_version: str   = TRACKING_SCHEMA_VERSION
    snap_timestamp: float = field(default_factory=time.time)
    sim_timestamp:  float = 0.0
    frame_id:       int   = 0
    source_id:      str   = NOT_AVAILABLE

    # Match
    matched_index: int  = 0
    interpolated:  bool = False

    # Reference state (scalar — NaN = unavailable)
    ref_x:        float = 0.0
    ref_y:        float = 0.0
    ref_yaw:      float = float("nan")
    ref_velocity: float = float("nan")
    ref_curvature:float = float("nan")

    # Tracking errors (scalar — NaN = unavailable)
    nearest_distance_m:   float = 0.0
    cross_track_error_m:  float = 0.0
    along_track_error_m:  float = 0.0
    heading_error_rad:    float = 0.0
    speed_error_mps:      float = float("nan")
    curvature_error_1pm:  float = float("nan")
    yaw_rate_error_radps: float = float("nan")

    # Status
    tracking_quality: TrackingQuality = TrackingQuality.UNKNOWN
    degraded:         bool            = True
    confidence:       float           = 0.0
    reason_codes:     Tuple[str, ...] = field(default_factory=tuple)

    # ------------------------------------------------------------------ #
    # Factory
    # ------------------------------------------------------------------ #

    @classmethod
    def from_result(
        cls,
        ref_state:   ReferenceState,
        error:       TrackingError,
        quality:     TrackingQuality,
        sim_timestamp: float,
        frame_id:    int,
        source_id:   str,
        degraded:    bool,
        confidence:  float,
        reason_codes: Tuple[str, ...],
        interpolated: bool = False,
    ) -> "TrackingSnapshot":
        """
        Build a snapshot from tracking engine outputs.

        All Optional fields are converted to float with NaN for None.
        """
        def _f(v: Optional[float]) -> float:
            return float(v) if v is not None else float("nan")

        return cls(
            schema_version     = TRACKING_SCHEMA_VERSION,
            snap_timestamp     = time.time(),
            sim_timestamp      = sim_timestamp,
            frame_id           = frame_id,
            source_id          = source_id,
            matched_index      = ref_state.matched_index,
            interpolated       = interpolated,
            ref_x              = float(ref_state.reference_x),
            ref_y              = float(ref_state.reference_y),
            ref_yaw            = _f(ref_state.reference_yaw),
            ref_velocity       = _f(ref_state.reference_velocity),
            ref_curvature      = _f(ref_state.reference_curvature),
            nearest_distance_m  = float(error.nearest_distance_m),
            cross_track_error_m = float(error.cross_track_error_m),
            along_track_error_m = float(error.along_track_error_m),
            heading_error_rad   = float(error.heading_error_rad),
            speed_error_mps     = _f(error.speed_error_mps),
            curvature_error_1pm = _f(error.curvature_error_1pm),
            yaw_rate_error_radps= _f(error.yaw_rate_error_radps),
            tracking_quality   = quality,
            degraded           = degraded,
            confidence         = float(confidence),
            reason_codes       = reason_codes,
        )

    # ------------------------------------------------------------------ #

    def __repr__(self) -> str:
        yaw_str = (f"{math.degrees(self.ref_yaw):.1f}°"
                   if math.isfinite(self.ref_yaw) else "N/A")
        return (
            f"TrackingSnapshot("
            f"quality={self.tracking_quality.value}, "
            f"cte={self.cross_track_error_m:.3f} m, "
            f"he={math.degrees(self.heading_error_rad):.1f}°, "
            f"ref_yaw={yaw_str}, "
            f"t={self.sim_timestamp:.3f}s)"
        )
