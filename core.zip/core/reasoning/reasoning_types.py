"""
IndiDrive AI — Phase 8.1 | Situation Assessment & Risk Reasoning Data Contracts
=================================================================================
Strongly-typed, compact data containers for the reasoning layer output.

The reasoning layer answers:
    «"What is happening around the vehicle right now, how complex is
      the situation, what hazards matter most, and what level of
      attention is required?"»

Design rules (same as all prior phases):
  * dataclasses — not raw dicts
  * explicit NOT_AVAILABLE / unknown — never fabricated
  * no path planning, no steering, no throttle, no MPC
  * confidence ≠ uncertainty ≠ risk — kept separate
  * deterministic: same input → same output
  * compact: bounded lists, summaries only
  * immutable snapshots (ReasoningSnapshot)
  * offline — no LLM, no cloud, no neural networks

This module contains ONLY structural containers.
Computation lives in the engine modules.
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from enum import Enum
from typing import List, Optional, Tuple

__all__ = [
    # Sentinel
    "NOT_AVAILABLE",
    # Schema
    "REASONING_SCHEMA_VERSION",
    # Enums
    "ReasoningState",
    "SituationCategory",
    "HazardCategory",
    "TtcBand",
    "InteractionType",
    "RiskLevel",
    "ComplexityLevel",
    "UncertaintyLevel",
    "WorldCompletenessLevel",
    # Sub-structures
    "HazardEntry",
    "InteractionEntry",
    "SituationInfo",
    "EnvironmentInfo",
    "HazardSummary",
    "RiskSummary",
    "ComplexityInfo",
    "UncertaintyInfo",
    "ReasoningExplanation",
    # Primary output
    "ReasoningSnapshot",
    "ReasoningResult",
]

NOT_AVAILABLE = "NOT_AVAILABLE"

REASONING_SCHEMA_VERSION = "8.1"


# ---------------------------------------------------------------------------
# Core state enums
# ---------------------------------------------------------------------------

class ReasoningState(str, Enum):
    """
    Environmental reasoning state — NOT a driving action.

    Describes the level of situational complexity and attention required.
    Must NOT be confused with vehicle control states.
    """
    NORMAL     = "NORMAL"      # routine environment, low complexity
    ATTENTION  = "ATTENTION"   # noteworthy environmental change
    CAUTION    = "CAUTION"     # elevated hazard count or moderate risk
    HIGH_RISK  = "HIGH_RISK"   # significant hazard(s) demanding focus
    CRITICAL   = "CRITICAL"    # immediate threat(s) present
    DEGRADED   = "DEGRADED"    # world model incomplete/unreliable
    UNKNOWN    = "UNKNOWN"     # cannot determine state


class SituationCategory(str, Enum):
    """High-level classification of the current driving environment."""
    OPEN_ROAD            = "OPEN_ROAD"
    NORMAL_TRAFFIC       = "NORMAL_TRAFFIC"
    DENSE_TRAFFIC        = "DENSE_TRAFFIC"
    VULNERABLE_ROAD_USER = "VULNERABLE_ROAD_USER"
    ROAD_HAZARD          = "ROAD_HAZARD"
    TRAJECTORY_CONFLICT  = "TRAJECTORY_CONFLICT"
    INTERSECTION_COMPLEXITY = "INTERSECTION_COMPLEXITY"
    MERGE_COMPLEXITY     = "MERGE_COMPLEXITY"
    NARROW_ROAD          = "NARROW_ROAD"
    UNSTRUCTURED_ROAD    = "UNSTRUCTURED_ROAD"
    COMPOUND_HAZARD      = "COMPOUND_HAZARD"
    DEGRADED_ENVIRONMENT = "DEGRADED_ENVIRONMENT"
    UNKNOWN              = "UNKNOWN"


class HazardCategory(str, Enum):
    """Classification of a hazard source extracted from the World Model."""
    PEDESTRIAN           = "PEDESTRIAN"
    CYCLIST              = "CYCLIST"
    MOTORCYCLE           = "MOTORCYCLE"
    SCOOTER              = "SCOOTER"
    AUTO_RICKSHAW        = "AUTO_RICKSHAW"
    CAR                  = "CAR"
    BUS                  = "BUS"
    TRUCK                = "TRUCK"
    TRACTOR              = "TRACTOR"
    CATTLE               = "CATTLE"
    PUSHCART             = "PUSHCART"
    ROAD_OBSTACLE        = "ROAD_OBSTACLE"
    POTHOLE              = "POTHOLE"
    DEBRIS               = "DEBRIS"
    CONSTRUCTION         = "CONSTRUCTION"
    WRONG_SIDE_TRAFFIC   = "WRONG_SIDE_TRAFFIC"
    ROAD_BOUNDARY_RESTRICTION = "ROAD_BOUNDARY_RESTRICTION"
    LANE_CONFLICT        = "LANE_CONFLICT"
    PREDICTED_COLLISION  = "PREDICTED_COLLISION"
    UNKNOWN              = "UNKNOWN"


class TtcBand(str, Enum):
    """
    Qualitative TTC classification band.
    Exact thresholds come from ReasoningConfig — not hard-coded here.
    """
    IMMEDIATE    = "IMMEDIATE"    # TTC < immediate_threshold_s
    NEAR_TERM    = "NEAR_TERM"    # TTC < near_threshold_s
    MODERATE     = "MODERATE"     # TTC < moderate_threshold_s
    DISTANT      = "DISTANT"      # TTC >= moderate_threshold_s
    UNAVAILABLE  = "UNAVAILABLE"  # TTC not computable
    NO_COLLISION = "NO_COLLISION" # Objects diverging


class InteractionType(str, Enum):
    """Type of interaction between two environmental entities."""
    VEHICLE_PEDESTRIAN      = "VEHICLE_PEDESTRIAN"
    VEHICLE_CYCLIST         = "VEHICLE_CYCLIST"
    VEHICLE_MOTORCYCLE      = "VEHICLE_MOTORCYCLE"
    VEHICLE_CATTLE          = "VEHICLE_CATTLE"
    VEHICLE_VEHICLE         = "VEHICLE_VEHICLE"
    VEHICLE_ROAD_ANOMALY    = "VEHICLE_ROAD_ANOMALY"
    VEHICLE_PUSHCART        = "VEHICLE_PUSHCART"
    OBJECT_OBJECT           = "OBJECT_OBJECT"
    COMPOUND_MULTI_HAZARD   = "COMPOUND_MULTI_HAZARD"
    UNKNOWN                 = "UNKNOWN"


class RiskLevel(str, Enum):
    """Risk level — mirrors Phase 4D for consistency."""
    LOW      = "LOW"
    MEDIUM   = "MEDIUM"
    HIGH     = "HIGH"
    CRITICAL = "CRITICAL"
    UNKNOWN  = "UNKNOWN"


class ComplexityLevel(str, Enum):
    """Road/situation complexity level."""
    LOW       = "LOW"
    MEDIUM    = "MEDIUM"
    HIGH      = "HIGH"
    VERY_HIGH = "VERY_HIGH"
    UNKNOWN   = "UNKNOWN"


class UncertaintyLevel(str, Enum):
    """Qualitative uncertainty band."""
    LOW       = "LOW"
    MEDIUM    = "MEDIUM"
    HIGH      = "HIGH"
    VERY_HIGH = "VERY_HIGH"
    UNKNOWN   = "UNKNOWN"


class WorldCompletenessLevel(str, Enum):
    """How complete the World Model input was for this reasoning cycle."""
    FULL    = "FULL"
    PARTIAL = "PARTIAL"
    MINIMAL = "MINIMAL"
    EMPTY   = "EMPTY"


# ---------------------------------------------------------------------------
# Hazard sub-structure
# ---------------------------------------------------------------------------

@dataclass
class HazardEntry:
    """
    One prioritised hazard extracted from the World Model.

    Fields are intentionally compact — no raw sensor data, no tensors.
    All optional numeric fields use None to mean 'unavailable'; zero is
    never substituted for unknown.
    """
    hazard_id: str = NOT_AVAILABLE          # object/anomaly ID from WM
    hazard_category: HazardCategory = HazardCategory.UNKNOWN
    risk_level: RiskLevel = RiskLevel.UNKNOWN
    ttc_band: TtcBand = TtcBand.UNAVAILABLE
    ttc_s: Optional[float] = None           # raw TTC if available
    distance_m: Optional[float] = None
    closing_speed_ms: Optional[float] = None
    collision_likelihood: Optional[float] = None  # [0, 1] from Phase 4D
    predicted_conflict: bool = False
    is_moving: bool = False
    is_vulnerable: bool = False             # pedestrian / cyclist / cattle
    priority_score: float = 0.0            # deterministic priority [0, 1]
    confidence: float = 0.0
    uncertainty: float = 1.0
    reason_codes: List[str] = field(default_factory=list)  # WHY this priority

    def to_dict(self) -> dict:
        return {
            "hazard_id": self.hazard_id,
            "hazard_category": self.hazard_category.value,
            "risk_level": self.risk_level.value,
            "ttc_band": self.ttc_band.value,
            "ttc_s": round(self.ttc_s, 3) if self.ttc_s is not None else NOT_AVAILABLE,
            "distance_m": round(self.distance_m, 3) if self.distance_m is not None else NOT_AVAILABLE,
            "closing_speed_ms": round(self.closing_speed_ms, 3) if self.closing_speed_ms is not None else NOT_AVAILABLE,
            "collision_likelihood": round(self.collision_likelihood, 3) if self.collision_likelihood is not None else NOT_AVAILABLE,
            "predicted_conflict": self.predicted_conflict,
            "is_moving": self.is_moving,
            "is_vulnerable": self.is_vulnerable,
            "priority_score": round(self.priority_score, 4),
            "confidence": round(self.confidence, 3),
            "uncertainty": round(self.uncertainty, 3),
            "reason_codes": list(self.reason_codes),
        }


# ---------------------------------------------------------------------------
# Interaction sub-structure
# ---------------------------------------------------------------------------

@dataclass
class InteractionEntry:
    """
    One identified interaction between environmental entities.

    Does NOT prescribe a vehicle response — only describes the interaction
    as an environmental observation.
    """
    interaction_id: str = NOT_AVAILABLE
    interaction_type: InteractionType = InteractionType.UNKNOWN
    entity_a_id: str = NOT_AVAILABLE
    entity_b_id: str = NOT_AVAILABLE        # may be road feature id
    severity: RiskLevel = RiskLevel.UNKNOWN
    confidence: float = 0.0
    uncertainty: float = 1.0
    is_active: bool = False                 # currently in progress vs predicted
    reason_codes: List[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "interaction_id": self.interaction_id,
            "interaction_type": self.interaction_type.value,
            "entity_a_id": self.entity_a_id,
            "entity_b_id": self.entity_b_id,
            "severity": self.severity.value,
            "confidence": round(self.confidence, 3),
            "uncertainty": round(self.uncertainty, 3),
            "is_active": self.is_active,
            "reason_codes": list(self.reason_codes),
        }


# ---------------------------------------------------------------------------
# Situation info
# ---------------------------------------------------------------------------

@dataclass
class SituationInfo:
    """Top-level situation classification result."""
    timestamp: float = field(default_factory=time.time)
    frame_id: int = 0
    situation_category: SituationCategory = SituationCategory.UNKNOWN
    situation_subcategory: str = NOT_AVAILABLE
    situation_confidence: float = 0.0
    situation_uncertainty: float = 1.0
    contributing_factors: List[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "timestamp": self.timestamp,
            "frame_id": self.frame_id,
            "situation_category": self.situation_category.value,
            "situation_subcategory": self.situation_subcategory,
            "situation_confidence": round(self.situation_confidence, 3),
            "situation_uncertainty": round(self.situation_uncertainty, 3),
            "contributing_factors": list(self.contributing_factors),
        }


# ---------------------------------------------------------------------------
# Environment info
# ---------------------------------------------------------------------------

@dataclass
class EnvironmentInfo:
    """Compact environmental state extracted from the World Model."""
    road_type: str = NOT_AVAILABLE
    road_structure: str = NOT_AVAILABLE
    lane_state: str = NOT_AVAILABLE         # marking state
    traffic_density: str = NOT_AVAILABLE
    traffic_mix: str = NOT_AVAILABLE
    road_complexity: str = NOT_AVAILABLE
    visibility_state: str = NOT_AVAILABLE
    available_drivable_width_m: Optional[float] = None
    is_narrow_road: bool = False
    is_intersection: bool = False
    is_unmarked: bool = False
    has_roadside_activity: bool = False
    has_cattle: bool = False
    has_vru: bool = False                   # vulnerable road users
    has_wrong_side_traffic: bool = False

    def to_dict(self) -> dict:
        return {
            "road_type": self.road_type,
            "road_structure": self.road_structure,
            "lane_state": self.lane_state,
            "traffic_density": self.traffic_density,
            "traffic_mix": self.traffic_mix,
            "road_complexity": self.road_complexity,
            "visibility_state": self.visibility_state,
            "available_drivable_width_m": (
                round(self.available_drivable_width_m, 2)
                if self.available_drivable_width_m is not None
                else NOT_AVAILABLE
            ),
            "is_narrow_road": self.is_narrow_road,
            "is_intersection": self.is_intersection,
            "is_unmarked": self.is_unmarked,
            "has_roadside_activity": self.has_roadside_activity,
            "has_cattle": self.has_cattle,
            "has_vru": self.has_vru,
            "has_wrong_side_traffic": self.has_wrong_side_traffic,
        }


# ---------------------------------------------------------------------------
# Hazard summary
# ---------------------------------------------------------------------------

@dataclass
class HazardSummary:
    """Aggregate hazard counts and top-priority hazard list."""
    total_hazards: int = 0
    critical_hazards: int = 0
    high_risk_hazards: int = 0
    active_hazards: int = 0
    predicted_hazards: int = 0
    road_hazards: int = 0
    vulnerable_road_users: int = 0
    unusual_participants: int = 0          # cattle, pushcarts, tractors
    # Bounded ordered list — highest priority first
    top_hazards: List[HazardEntry] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "total_hazards": self.total_hazards,
            "critical_hazards": self.critical_hazards,
            "high_risk_hazards": self.high_risk_hazards,
            "active_hazards": self.active_hazards,
            "predicted_hazards": self.predicted_hazards,
            "road_hazards": self.road_hazards,
            "vulnerable_road_users": self.vulnerable_road_users,
            "unusual_participants": self.unusual_participants,
            "top_hazard_count": len(self.top_hazards),
            "top_hazards": [h.to_dict() for h in self.top_hazards],
        }


# ---------------------------------------------------------------------------
# Risk summary
# ---------------------------------------------------------------------------

@dataclass
class RiskSummary:
    """Aggregate risk assessment across the environment."""
    overall_risk_level: RiskLevel = RiskLevel.UNKNOWN
    max_hazard_risk: RiskLevel = RiskLevel.UNKNOWN
    collision_threat_present: bool = False
    time_criticality: TtcBand = TtcBand.UNAVAILABLE
    uncertainty_level: UncertaintyLevel = UncertaintyLevel.UNKNOWN
    reason_codes: List[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "overall_risk_level": self.overall_risk_level.value,
            "max_hazard_risk": self.max_hazard_risk.value,
            "collision_threat_present": self.collision_threat_present,
            "time_criticality": self.time_criticality.value,
            "uncertainty_level": self.uncertainty_level.value,
            "reason_codes": list(self.reason_codes),
        }


# ---------------------------------------------------------------------------
# Complexity info
# ---------------------------------------------------------------------------

@dataclass
class ComplexityInfo:
    """Road and situation complexity assessment."""
    complexity_level: ComplexityLevel = ComplexityLevel.UNKNOWN
    contributing_factors: List[str] = field(default_factory=list)
    confidence: float = 0.0
    uncertainty: float = 1.0

    def to_dict(self) -> dict:
        return {
            "complexity_level": self.complexity_level.value,
            "contributing_factors": list(self.contributing_factors),
            "confidence": round(self.confidence, 3),
            "uncertainty": round(self.uncertainty, 3),
        }


# ---------------------------------------------------------------------------
# Uncertainty info
# ---------------------------------------------------------------------------

@dataclass
class UncertaintyInfo:
    """
    Detailed uncertainty breakdown.

    High uncertainty ≠ low risk.  Missing information must not be
    converted to zero risk.
    """
    overall_uncertainty: float = 1.0
    world_completeness: WorldCompletenessLevel = WorldCompletenessLevel.EMPTY
    missing_modules: List[str] = field(default_factory=list)
    degraded_modules: List[str] = field(default_factory=list)
    stale_data_present: bool = False
    sensor_degradation: bool = False
    prediction_unavailable: bool = False
    road_info_unavailable: bool = False

    def to_dict(self) -> dict:
        return {
            "overall_uncertainty": round(self.overall_uncertainty, 3),
            "world_completeness": self.world_completeness.value,
            "missing_modules": list(self.missing_modules),
            "degraded_modules": list(self.degraded_modules),
            "stale_data_present": self.stale_data_present,
            "sensor_degradation": self.sensor_degradation,
            "prediction_unavailable": self.prediction_unavailable,
            "road_info_unavailable": self.road_info_unavailable,
        }


# ---------------------------------------------------------------------------
# Explanation trace
# ---------------------------------------------------------------------------

@dataclass
class ReasoningExplanation:
    """
    Machine-readable reasoning trace.

    Uses deterministic structured reason codes — NOT natural language.
    NOT LLM output.  Compact and bounded.
    """
    # Reason codes for the overall reasoning state
    state_reason_codes: List[str] = field(default_factory=list)
    # Reason codes for the situation classification
    situation_reason_codes: List[str] = field(default_factory=list)
    # Reason codes for the complexity assessment
    complexity_reason_codes: List[str] = field(default_factory=list)
    # Per-factor contributions: {factor: contribution_level}
    # contribution_level: "high" | "medium" | "low"
    contributors: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        return {
            "state_reason_codes": list(self.state_reason_codes),
            "situation_reason_codes": list(self.situation_reason_codes),
            "complexity_reason_codes": list(self.complexity_reason_codes),
            "contributors": dict(self.contributors),
        }


# ---------------------------------------------------------------------------
# Primary output: ReasoningSnapshot
# ---------------------------------------------------------------------------

@dataclass
class ReasoningSnapshot:
    """
    One immutable, consistent reasoning state for a single processing cycle.

    Consumers MUST NOT mutate this object.
    Repeated identical input → identical output (deterministic).

    This is environmental reasoning only.
    It does NOT contain:
      - steering commands
      - throttle commands
      - braking commands
      - path or trajectory
      - lane-change decisions
      - vehicle control of any kind
    """
    schema_version: str = REASONING_SCHEMA_VERSION
    timestamp: float = field(default_factory=time.time)
    frame_id: int = 0

    # --- Primary reasoning output ---
    reasoning_state: ReasoningState = ReasoningState.UNKNOWN

    # --- Situation ---
    situation: SituationInfo = field(default_factory=SituationInfo)

    # --- Environment ---
    environment: EnvironmentInfo = field(default_factory=EnvironmentInfo)

    # --- Hazards ---
    hazards: HazardSummary = field(default_factory=HazardSummary)

    # --- Interactions (bounded tuple for immutability) ---
    _interactions: tuple = field(default_factory=tuple, repr=False)

    # --- Risk ---
    risk: RiskSummary = field(default_factory=RiskSummary)

    # --- Complexity ---
    complexity: ComplexityInfo = field(default_factory=ComplexityInfo)

    # --- Uncertainty ---
    uncertainty_info: UncertaintyInfo = field(default_factory=UncertaintyInfo)

    # --- Explanation ---
    explanation: ReasoningExplanation = field(default_factory=ReasoningExplanation)

    # --- Overall confidence in this reasoning result ---
    reasoning_confidence: float = 0.0

    @property
    def interactions(self) -> tuple:
        """Read-only tuple of InteractionEntry."""
        return self._interactions

    @property
    def interaction_count(self) -> int:
        return len(self._interactions)

    def to_dict(self) -> dict:
        return {
            "schema_version": self.schema_version,
            "timestamp": self.timestamp,
            "frame_id": self.frame_id,
            "reasoning_state": self.reasoning_state.value,
            "reasoning_confidence": round(self.reasoning_confidence, 3),
            "situation": self.situation.to_dict(),
            "environment": self.environment.to_dict(),
            "hazards": self.hazards.to_dict(),
            "interaction_count": self.interaction_count,
            "interactions": [i.to_dict() for i in self._interactions],
            "risk": self.risk.to_dict(),
            "complexity": self.complexity.to_dict(),
            "uncertainty": self.uncertainty_info.to_dict(),
            "explanation": self.explanation.to_dict(),
        }


# ---------------------------------------------------------------------------
# Build result wrapper
# ---------------------------------------------------------------------------

@dataclass
class ReasoningResult:
    """
    Return value of ReasoningEngine.assess().

    Always present — never raises on partial or invalid input.
    """
    snapshot: ReasoningSnapshot
    assessment_status: str = "ok"          # ok | degraded | empty | error
    assessment_warnings: List[str] = field(default_factory=list)
    assessment_errors: List[str] = field(default_factory=list)
    assessment_duration_s: float = 0.0

    @property
    def is_valid(self) -> bool:
        return self.assessment_status in ("ok", "degraded")

    def to_dict(self) -> dict:
        return {
            "snapshot": self.snapshot.to_dict(),
            "assessment_status": self.assessment_status,
            "assessment_warnings": list(self.assessment_warnings),
            "assessment_errors": list(self.assessment_errors),
            "assessment_duration_s": round(self.assessment_duration_s, 6),
        }
