"""
IndiDrive AI — Phase 8.4 | Decision Arbitration & Safety Gate Data Contracts
=============================================================================
Strongly-typed, compact data containers for Phase 8.4 output.

Phase 8.4 answers:
    «"Which abstract requirements are currently dominant, which conflict,
      what safety constraints must the planner respect, and what is the
      current safety gate state?"»

Phase 8.4 does NOT answer:
    «"Which path should the vehicle follow?"»
    «"How much should it steer / brake / throttle?"»

Those belong to Phase 9 (path planning) and Phase 10 (MPC).

Design rules (same as all prior phases):
  * dataclasses — not raw dicts
  * explicit NOT_AVAILABLE / unknown — never fabricated
  * no path planning, no steering, no throttle, no MPC, no waypoints
  * confidence ≠ uncertainty ≠ severity ≠ urgency — kept separate
  * deterministic: same input → same output
  * compact: bounded tuples, summaries only
  * immutable snapshots (ArbitrationSnapshot)
  * offline — no LLM, no cloud, no neural networks

This module contains ONLY structural containers.
Computation lives in arbitration_engine.py and safety_gate.py.
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from enum import Enum
from typing import List, Optional, Tuple

# Re-use upstream types — do NOT duplicate them.
from .action_abstraction_types import (
    DecisionRequirement,
    RequirementType,
    AbstractUrgency,
    AbstractSeverity,
    EvidenceType,
)

__all__ = [
    # Sentinel / schema
    "NOT_AVAILABLE",
    "ARBITRATION_SCHEMA_VERSION",
    # Enums
    "SafetyGateState",
    "ConstraintHardness",
    "RequirementStatus",
    "TemporalValidity",
    "PlanningMode",
    "ArbitrationValidationStatus",
    # Data structures
    "SafetyConstraint",
    "ArbitratedRequirement",
    "RequirementConflict",
    "PlanningContext",
    # Primary output
    "ArbitrationSnapshot",
    "ArbitrationResult",
]

NOT_AVAILABLE = "NOT_AVAILABLE"
ARBITRATION_SCHEMA_VERSION = "8.4"


# ---------------------------------------------------------------------------
# Safety gate states
# ---------------------------------------------------------------------------

class SafetyGateState(str, Enum):
    """
    Safety gate state for the current processing cycle.

    This is an ABSTRACT SAFETY CLASSIFICATION — not a vehicle command.

    CLEAR      — situation sufficiently understood; no significant hazard;
                 normal planning allowed.
    CAUTION    — relevant hazard or uncertainty exists; planning must remain
                 safety-aware.
    RESTRICTED — one or more significant hard constraints are active;
                 planner must respect stronger restrictions.
    HIGH_ALERT — significant collision/conflict risk or severe uncertainty;
                 planning must prioritise safety constraints.
    CRITICAL   — immediate high-severity/high-urgency threat; planning must
                 receive a critical safety condition.
    DEGRADED   — important system inputs are degraded or unavailable;
                 planning must operate using reduced-confidence information.
    UNKNOWN    — insufficient information to safely classify the current state.
    """
    CLEAR      = "CLEAR"
    CAUTION    = "CAUTION"
    RESTRICTED = "RESTRICTED"
    HIGH_ALERT = "HIGH_ALERT"
    CRITICAL   = "CRITICAL"
    DEGRADED   = "DEGRADED"
    UNKNOWN    = "UNKNOWN"


# ---------------------------------------------------------------------------
# Constraint hardness
# ---------------------------------------------------------------------------

class ConstraintHardness(str, Enum):
    """
    Whether a planning constraint is hard (must be respected) or soft
    (should be respected but may be relaxed under competing hard constraints).

    Hard constraints include collision-critical restrictions, severe
    uncertainty, invalid world state, and critical VRU interactions.

    Soft constraints include comfort preferences, efficiency preferences,
    and non-critical monitoring requirements.
    """
    HARD = "HARD"
    SOFT = "SOFT"


# ---------------------------------------------------------------------------
# Requirement status within arbitration
# ---------------------------------------------------------------------------

class RequirementStatus(str, Enum):
    """
    Status assigned to a DecisionRequirement after arbitration.

    ACTIVE      — requirement is valid and relevant; considered in arbitration.
    DOMINANT    — requirement is the highest-priority active requirement
                  after conflict resolution.
    SUPPORTING  — requirement supports the dominant requirement.
    CONFLICTING — requirement conflicts with a higher-priority requirement.
    SUPPRESSED  — requirement was active but overridden by a higher-priority one.
    DEFERRED    — requirement cannot be addressed immediately; deferred.
    STALE       — requirement has exceeded the stale threshold.
    EXPIRED     — requirement has exceeded the expiry threshold.
    UNKNOWN     — status cannot be determined.
    """
    ACTIVE      = "ACTIVE"
    DOMINANT    = "DOMINANT"
    SUPPORTING  = "SUPPORTING"
    CONFLICTING = "CONFLICTING"
    SUPPRESSED  = "SUPPRESSED"
    DEFERRED    = "DEFERRED"
    STALE       = "STALE"
    EXPIRED     = "EXPIRED"
    UNKNOWN     = "UNKNOWN"


# ---------------------------------------------------------------------------
# Temporal validity
# ---------------------------------------------------------------------------

class TemporalValidity(str, Enum):
    """
    Freshness classification for a requirement or constraint.

    VALID   — within normal freshness bounds.
    AGING   — approaching the stale threshold; still usable.
    STALE   — older than stale threshold; use with caution.
    EXPIRED — older than critical stale threshold; must not be used actively.
    UNKNOWN — timestamp information unavailable.
    """
    VALID   = "VALID"
    AGING   = "AGING"
    STALE   = "STALE"
    EXPIRED = "EXPIRED"
    UNKNOWN = "UNKNOWN"


# ---------------------------------------------------------------------------
# Planning mode
# ---------------------------------------------------------------------------

class PlanningMode(str, Enum):
    """
    Abstract planning mode handed to Phase 9.

    This is NOT a maneuver command. It describes the operational envelope
    that Phase 9 planning must operate within.

    NORMAL           — full planning capability allowed.
    RESTRICTED       — planning must respect active hard constraints.
    SAFETY_RESTRICTED — planning dominated by safety-critical constraints.
    DEGRADED         — planning operates with reduced-confidence inputs.
    UNKNOWN          — planning mode cannot be determined safely.
    """
    NORMAL            = "NORMAL"
    RESTRICTED        = "RESTRICTED"
    SAFETY_RESTRICTED = "SAFETY_RESTRICTED"
    DEGRADED          = "DEGRADED"
    UNKNOWN           = "UNKNOWN"


# ---------------------------------------------------------------------------
# Arbitration validation status
# ---------------------------------------------------------------------------

class ArbitrationValidationStatus(str, Enum):
    """Result of validating an ArbitrationSnapshot."""
    VALID    = "VALID"
    PARTIAL  = "PARTIAL"
    DEGRADED = "DEGRADED"
    INVALID  = "INVALID"


# ---------------------------------------------------------------------------
# Safety constraint
# ---------------------------------------------------------------------------

@dataclass
class SafetyConstraint:
    """
    One abstract safety constraint for Phase 9.

    This is an ABSTRACT CONSTRAINT — not a vehicle command.

    It describes a restriction that the planner must respect.
    It does NOT specify steering angles, braking values, paths, or waypoints.

    Fields
    ------
    constraint_id    : unique identifier for this constraint instance.
    constraint_type  : human-readable type label (e.g. "COLLISION_CRITICAL").
    hardness         : HARD or SOFT — see ConstraintHardness.
    source           : which upstream requirement generated this constraint.
    requirement_type : the RequirementType that caused this constraint.
    priority         : deterministic priority score [0, 1]; 1 = highest.
    urgency          : temporal urgency of this constraint.
    severity         : severity of the underlying situation.
    confidence       : confidence in this constraint [0, 1].
    uncertainty      : uncertainty in this constraint [0, 1].
    evidence_type    : epistemological class of supporting evidence.
    affected_entity_ids : entity IDs this constraint relates to.
    affected_region  : compact abstract description; NOT coordinates or paths.
    reason_codes     : deterministic structured reason codes (NOT free text).
    temporal_validity: freshness classification.
    timestamp        : when this constraint was generated.
    frame_id         : associated processing frame.
    schema_version   : Phase 8.4 schema version.
    """
    constraint_id: str = NOT_AVAILABLE
    constraint_type: str = NOT_AVAILABLE
    hardness: ConstraintHardness = ConstraintHardness.SOFT
    source: str = NOT_AVAILABLE
    requirement_type: RequirementType = RequirementType.HANDLE_UNCERTAINTY
    priority: float = 0.0
    urgency: AbstractUrgency = AbstractUrgency.UNKNOWN
    severity: AbstractSeverity = AbstractSeverity.UNKNOWN
    confidence: float = 0.0
    uncertainty: float = 1.0
    evidence_type: EvidenceType = EvidenceType.UNKNOWN
    affected_entity_ids: Tuple[str, ...] = field(default_factory=tuple)
    affected_region: str = NOT_AVAILABLE
    reason_codes: Tuple[str, ...] = field(default_factory=tuple)
    temporal_validity: TemporalValidity = TemporalValidity.UNKNOWN
    timestamp: float = field(default_factory=time.time)
    frame_id: int = 0
    schema_version: str = ARBITRATION_SCHEMA_VERSION

    def to_dict(self) -> dict:
        return {
            "constraint_id": self.constraint_id,
            "constraint_type": self.constraint_type,
            "hardness": self.hardness.value,
            "source": self.source,
            "requirement_type": self.requirement_type.value,
            "priority": round(self.priority, 4),
            "urgency": self.urgency.value,
            "severity": self.severity.value,
            "confidence": round(self.confidence, 3),
            "uncertainty": round(self.uncertainty, 3),
            "evidence_type": self.evidence_type.value,
            "affected_entity_ids": list(self.affected_entity_ids),
            "affected_region": self.affected_region,
            "reason_codes": list(self.reason_codes),
            "temporal_validity": self.temporal_validity.value,
            "timestamp": self.timestamp,
            "frame_id": self.frame_id,
            "schema_version": self.schema_version,
        }


# ---------------------------------------------------------------------------
# Arbitrated requirement — a requirement with its arbitration metadata
# ---------------------------------------------------------------------------

@dataclass
class ArbitratedRequirement:
    """
    A DecisionRequirement enriched with arbitration metadata.

    The original requirement is preserved unchanged; arbitration metadata
    is added alongside it.

    Fields
    ------
    requirement        : the original DecisionRequirement from Phase 8.3.
    status             : arbitration status (DOMINANT, ACTIVE, SUPPRESSED, ...).
    temporal_validity  : freshness of this requirement.
    suppressed_by      : requirement_id of the dominant that suppressed this one
                         (only set when status = SUPPRESSED or CONFLICTING).
    suppression_reason : reason code for suppression (NOT free text).
    """
    requirement: DecisionRequirement = field(
        default_factory=DecisionRequirement
    )
    status: RequirementStatus = RequirementStatus.UNKNOWN
    temporal_validity: TemporalValidity = TemporalValidity.UNKNOWN
    suppressed_by: str = NOT_AVAILABLE
    suppression_reason: str = NOT_AVAILABLE

    def to_dict(self) -> dict:
        return {
            "requirement": self.requirement.to_dict(),
            "status": self.status.value,
            "temporal_validity": self.temporal_validity.value,
            "suppressed_by": self.suppressed_by,
            "suppression_reason": self.suppression_reason,
        }


# ---------------------------------------------------------------------------
# Requirement conflict record
# ---------------------------------------------------------------------------

@dataclass
class RequirementConflict:
    """
    A detected conflict between two requirements.

    Records which requirement was preserved and which was suppressed,
    and why.

    This is NOT a maneuver decision — it is a record of the arbitration
    logic that determined priority ordering.
    """
    requirement_id_dominant: str = NOT_AVAILABLE
    requirement_id_suppressed: str = NOT_AVAILABLE
    reason_code: str = NOT_AVAILABLE
    note: str = NOT_AVAILABLE   # compact code, NOT a free-text paragraph

    def to_dict(self) -> dict:
        return {
            "requirement_id_dominant": self.requirement_id_dominant,
            "requirement_id_suppressed": self.requirement_id_suppressed,
            "reason_code": self.reason_code,
            "note": self.note,
        }


# ---------------------------------------------------------------------------
# Planning context — the handoff to Phase 9
# ---------------------------------------------------------------------------

@dataclass
class PlanningContext:
    """
    Abstract planning context handed from Phase 8.4 to Phase 9.

    This is an ABSTRACT CONTEXT DESCRIPTION — NOT a vehicle command.

    It tells Phase 9:
        "These are the abstract requirements and safety constraints that
         the planner must respect."

    It does NOT tell Phase 9:
        "Steer left."
        "Brake now."
        "Follow this trajectory."
        "Target speed = X."
        "Waypoint at (x, y)."

    Fields
    ------
    context_id              : unique ID for this planning context.
    timestamp               : generation timestamp.
    frame_id                : processing frame.
    safety_gate_state       : the current safety gate classification.
    dominant_requirement    : the dominant arbitrated requirement (may be None).
    active_requirements     : all requirements with ACTIVE or DOMINANT status.
    hard_constraints        : constraints that MUST be respected by the planner.
    soft_constraints        : constraints the planner should try to respect.
    affected_entity_ids     : entity IDs relevant to active requirements.
    uncertainty_level       : overall uncertainty classification.
    world_model_completeness: [0, 1] completeness from WorldModel.
    planning_allowed        : False when context is unknown/invalid.
    planning_mode           : abstract mode for Phase 9 (NORMAL/RESTRICTED/...).
    safety_override_required: True when safety constraints must dominate planning.
    reason_codes            : deterministic structured reason codes.
    confidence              : overall confidence in this planning context [0, 1].
    schema_version          : Phase 8.4 schema version.

    FORBIDDEN (must never appear here):
        path, trajectory, waypoints, steering_angle, throttle, brake,
        target_speed, acceleration_cmd, lane_change_command, steer_cmd.
    """
    context_id: str = NOT_AVAILABLE
    timestamp: float = field(default_factory=time.time)
    frame_id: int = 0

    # --- Safety gate ---
    safety_gate_state: SafetyGateState = SafetyGateState.UNKNOWN

    # --- Requirements ---
    dominant_requirement: Optional[ArbitratedRequirement] = None
    _active_requirements: Tuple[ArbitratedRequirement, ...] = field(
        default_factory=tuple, repr=False
    )

    # --- Constraints ---
    _hard_constraints: Tuple[SafetyConstraint, ...] = field(
        default_factory=tuple, repr=False
    )
    _soft_constraints: Tuple[SafetyConstraint, ...] = field(
        default_factory=tuple, repr=False
    )

    # --- Affected entities ---
    affected_entity_ids: Tuple[str, ...] = field(default_factory=tuple)

    # --- Uncertainty / completeness ---
    uncertainty_level: str = NOT_AVAILABLE   # LOW / MEDIUM / HIGH / VERY_HIGH / UNKNOWN
    world_model_completeness: float = 0.0    # [0, 1]

    # --- Planning control ---
    planning_allowed: bool = False
    planning_mode: PlanningMode = PlanningMode.UNKNOWN
    safety_override_required: bool = False

    # --- Metadata ---
    reason_codes: Tuple[str, ...] = field(default_factory=tuple)
    confidence: float = 0.0
    schema_version: str = ARBITRATION_SCHEMA_VERSION

    # ------------------------------------------------------------------
    # Safe read-only properties
    # ------------------------------------------------------------------

    @property
    def active_requirements(self) -> Tuple[ArbitratedRequirement, ...]:
        return self._active_requirements

    @property
    def hard_constraints(self) -> Tuple[SafetyConstraint, ...]:
        return self._hard_constraints

    @property
    def soft_constraints(self) -> Tuple[SafetyConstraint, ...]:
        return self._soft_constraints

    @property
    def hard_constraint_count(self) -> int:
        return len(self._hard_constraints)

    @property
    def soft_constraint_count(self) -> int:
        return len(self._soft_constraints)

    @property
    def active_requirement_count(self) -> int:
        return len(self._active_requirements)

    def to_dict(self) -> dict:
        return {
            "context_id": self.context_id,
            "timestamp": self.timestamp,
            "frame_id": self.frame_id,
            "safety_gate_state": self.safety_gate_state.value,
            "dominant_requirement": (
                self.dominant_requirement.to_dict()
                if self.dominant_requirement is not None
                else None
            ),
            "active_requirement_count": self.active_requirement_count,
            "active_requirements": [r.to_dict() for r in self._active_requirements],
            "hard_constraint_count": self.hard_constraint_count,
            "hard_constraints": [c.to_dict() for c in self._hard_constraints],
            "soft_constraint_count": self.soft_constraint_count,
            "soft_constraints": [c.to_dict() for c in self._soft_constraints],
            "affected_entity_ids": list(self.affected_entity_ids),
            "uncertainty_level": self.uncertainty_level,
            "world_model_completeness": round(self.world_model_completeness, 3),
            "planning_allowed": self.planning_allowed,
            "planning_mode": self.planning_mode.value,
            "safety_override_required": self.safety_override_required,
            "reason_codes": list(self.reason_codes),
            "confidence": round(self.confidence, 3),
            "schema_version": self.schema_version,
        }


# ---------------------------------------------------------------------------
# Primary output: ArbitrationSnapshot
# ---------------------------------------------------------------------------

@dataclass
class ArbitrationSnapshot:
    """
    One immutable Phase 8.4 output for a single processing cycle.

    Consumers MUST NOT mutate this object.
    Repeated identical input → identical output (deterministic).

    This is an ARBITRATION LAYER output only.
    It does NOT contain:
      - steering commands
      - throttle commands
      - braking commands
      - path, trajectory, or waypoints
      - lane-change or overtaking decisions
      - target speed
      - vehicle control of any kind
      - LLM output
      - cloud reasoning output

    It provides an arbitrated planning context only.
    """
    schema_version: str = ARBITRATION_SCHEMA_VERSION
    timestamp: float = field(default_factory=time.time)
    frame_id: int = 0

    # --- Safety gate state ---
    safety_gate_state: SafetyGateState = SafetyGateState.UNKNOWN

    # --- All arbitrated requirements (immutable tuple) ---
    _arbitrated_requirements: Tuple[ArbitratedRequirement, ...] = field(
        default_factory=tuple, repr=False
    )

    # --- Detected conflicts ---
    _conflicts: Tuple[RequirementConflict, ...] = field(
        default_factory=tuple, repr=False
    )

    # --- Planning context (primary handoff to Phase 9) ---
    planning_context: PlanningContext = field(default_factory=PlanningContext)

    # --- Overall confidence / uncertainty ---
    confidence: float = 0.0
    uncertainty: float = 1.0

    # --- World model completeness at arbitration time ---
    world_model_completeness: float = 0.0

    # --- Degraded flag ---
    degraded: bool = False

    # --- Reason codes for this arbitration cycle ---
    reason_codes: Tuple[str, ...] = field(default_factory=tuple)

    # --- Source frame IDs from upstream ---
    situation_frame_id: int = 0
    behavior_frame_id: int = 0
    abstraction_frame_id: int = 0

    # ------------------------------------------------------------------
    # Safe read-only properties
    # ------------------------------------------------------------------

    @property
    def arbitrated_requirements(self) -> Tuple[ArbitratedRequirement, ...]:
        return self._arbitrated_requirements

    @property
    def conflicts(self) -> Tuple[RequirementConflict, ...]:
        return self._conflicts

    @property
    def dominant_requirement(self) -> Optional[ArbitratedRequirement]:
        """The dominant ArbitratedRequirement, or None if none exists."""
        return self.planning_context.dominant_requirement

    @property
    def active_requirements(self) -> Tuple[ArbitratedRequirement, ...]:
        """Requirements with ACTIVE or DOMINANT status."""
        return tuple(
            r for r in self._arbitrated_requirements
            if r.status in (RequirementStatus.ACTIVE, RequirementStatus.DOMINANT)
        )

    @property
    def suppressed_requirements(self) -> Tuple[ArbitratedRequirement, ...]:
        return tuple(
            r for r in self._arbitrated_requirements
            if r.status in (RequirementStatus.SUPPRESSED, RequirementStatus.CONFLICTING)
        )

    @property
    def stale_requirements(self) -> Tuple[ArbitratedRequirement, ...]:
        return tuple(
            r for r in self._arbitrated_requirements
            if r.status in (RequirementStatus.STALE, RequirementStatus.EXPIRED)
        )

    @property
    def requirement_count(self) -> int:
        return len(self._arbitrated_requirements)

    @property
    def conflict_count(self) -> int:
        return len(self._conflicts)

    @property
    def hard_constraint_count(self) -> int:
        return self.planning_context.hard_constraint_count

    @property
    def soft_constraint_count(self) -> int:
        return self.planning_context.soft_constraint_count

    # ------------------------------------------------------------------
    # Serialisation
    # ------------------------------------------------------------------

    def to_dict(self) -> dict:
        return {
            "schema_version": self.schema_version,
            "timestamp": self.timestamp,
            "frame_id": self.frame_id,
            "safety_gate_state": self.safety_gate_state.value,
            "confidence": round(self.confidence, 3),
            "uncertainty": round(self.uncertainty, 3),
            "world_model_completeness": round(self.world_model_completeness, 3),
            "degraded": self.degraded,
            "requirement_count": self.requirement_count,
            "arbitrated_requirements": [r.to_dict() for r in self._arbitrated_requirements],
            "conflict_count": self.conflict_count,
            "conflicts": [c.to_dict() for c in self._conflicts],
            "hard_constraint_count": self.hard_constraint_count,
            "soft_constraint_count": self.soft_constraint_count,
            "reason_codes": list(self.reason_codes),
            "planning_context": self.planning_context.to_dict(),
            "situation_frame_id": self.situation_frame_id,
            "behavior_frame_id": self.behavior_frame_id,
            "abstraction_frame_id": self.abstraction_frame_id,
        }


# ---------------------------------------------------------------------------
# Build result wrapper
# ---------------------------------------------------------------------------

@dataclass
class ArbitrationResult:
    """
    Return value of DecisionArbitrationEngine.arbitrate().

    Always present — never raises on partial or invalid input.
    The snapshot is always a valid ArbitrationSnapshot even when input
    data is degraded or empty.
    """
    snapshot: ArbitrationSnapshot
    status: str = "ok"          # ok | degraded | empty | error
    warnings: List[str] = field(default_factory=list)
    errors: List[str] = field(default_factory=list)
    duration_s: float = 0.0

    @property
    def is_valid(self) -> bool:
        return self.status in ("ok", "degraded", "empty")

    def to_dict(self) -> dict:
        return {
            "snapshot": self.snapshot.to_dict(),
            "status": self.status,
            "warnings": list(self.warnings),
            "errors": list(self.errors),
            "duration_s": round(self.duration_s, 6),
        }
