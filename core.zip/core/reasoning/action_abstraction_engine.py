"""
IndiDrive AI — Phase 8.3 | Action Abstraction Engine (Public API)
==================================================================
Main entry point for Phase 8.3 Decision & Action Abstraction.

Usage
-----
    config = load_action_abstraction_config()
    engine = ActionAbstractionEngine(config=config)
    result = engine.generate(
        world_model=world_model_snapshot,    # Phase 7 (optional)
        situation_state=reasoning_snapshot,  # Phase 8.1 (required)
        behavior_reasoning=behavior_state,   # Phase 8.2 (optional)
    )

    snap = result.snapshot
    if result.is_valid:
        print(snap.response_family)
        print(snap.requirements)

Inputs
------
  - Phase 7 WorldModelSnapshot (optional — degrades gracefully)
  - Phase 8.1 ReasoningSnapshot (required for full operation)
  - Phase 8.2 BehaviorReasoningState (optional — degrades gracefully)

All inputs are consumed READ-ONLY.  None are mutated.

Outputs
-------
  - ActionAbstractionResult containing an ActionAbstractionSnapshot

Architectural Boundary
-----------------------
Phase 8.3 does NOT implement:
  - Path planning (Hybrid A*, A*, RRT, RRT*)
  - MPC / PID / steering / throttle / brake commands
  - Lane-change or overtaking execution
  - Trajectory generation or optimisation
  - New perception / tracking / prediction engine
  - New TTC or collision-likelihood engine
  - LLM / cloud / vector database / FAISS
  - Decision arbitration (belongs to Phase 8.4)
  - Safety gate (belongs to Phase 8.4)

The output contains ABSTRACT DECISION REQUIREMENTS only.

Thread Safety
-------------
generate() is stateless.  Multiple snapshots can be processed
concurrently with independent engine instances.
No global mutable state is shared.
Configuration is never mutated after construction.
"""
from __future__ import annotations

import time
from typing import List, Optional

from .action_abstraction_config import (
    ActionAbstractionConfig,
    load_action_abstraction_config,
)
from .action_abstraction_types import (
    NOT_AVAILABLE,
    ACTION_ABSTRACTION_SCHEMA_VERSION,
    AbstractSeverity,
    AbstractUrgency,
    ActionAbstractionResult,
    ActionAbstractionSnapshot,
    DecisionRequirement,
    RequirementType,
    ResponseFamily,
)
from .requirement_generator import (
    generate_collision_avoidance,
    generate_trajectory_conflict,
    generate_vulnerable_user,
    generate_road_hazard,
    generate_narrow_road,
    generate_intersection,
    generate_merge,
    generate_monitor_dynamic_object,
    generate_monitor_unpredictable,
    generate_uncertainty,
    generate_maintain_safe_space,
    generate_normal_progress,
    _urgency_rank,
    _severity_rank,
)
from .response_requirement_classifier import (
    classify_response_family,
    detect_relationships,
)

# Upstream type imports (consumed read-only)
from .reasoning_types import ReasoningSnapshot
from .behavior_types import BehaviorReasoningState
from core.world_model.world_model_types import WorldModelSnapshot, WorldModelStatus


# ---------------------------------------------------------------------------
# Engine
# ---------------------------------------------------------------------------

class ActionAbstractionEngine:
    """
    Phase 8.3 Decision & Action Abstraction Engine.

    Deterministic, stateless, planner-independent.
    Converts upstream reasoning outputs into abstract decision requirements.
    """

    def __init__(self, config: Optional[ActionAbstractionConfig] = None) -> None:
        self._config = config or load_action_abstraction_config()

    @property
    def config(self) -> ActionAbstractionConfig:
        return self._config

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def generate(
        self,
        situation_state: Optional[ReasoningSnapshot] = None,
        behavior_reasoning: Optional[BehaviorReasoningState] = None,
        world_model: Optional[WorldModelSnapshot] = None,
    ) -> ActionAbstractionResult:
        """
        Generate abstract decision requirements for the current situation.

        Parameters
        ----------
        situation_state : Phase 8.1 ReasoningSnapshot.
            Required for full operation.  Degrades gracefully if None.
        behavior_reasoning : Phase 8.2 BehaviorReasoningState.
            Optional.  Enriches requirements when available.
        world_model : Phase 7 WorldModelSnapshot.
            Optional.  Provides road context when available.

        Returns
        -------
        ActionAbstractionResult
            Always returns a valid result — never raises on bad input.
        """
        t_start = time.monotonic()
        warnings: List[str] = []
        errors: List[str] = []

        # --- Handle completely missing situation state ---
        if situation_state is None:
            warnings.append("situation_state is None — operating in fully degraded mode")
            snap = self._build_empty_degraded_snapshot(
                world_model=world_model,
                frame_id=0,
                ts=time.time(),
            )
            return ActionAbstractionResult(
                snapshot=snap,
                status="empty",
                warnings=warnings,
                errors=errors,
                duration_s=time.monotonic() - t_start,
            )

        # --- Extract frame/timestamp from situation state ---
        frame_id = situation_state.frame_id
        ts = situation_state.timestamp

        # --- Check for invalid world model ---
        if world_model is not None and world_model.status == WorldModelStatus.INVALID:
            warnings.append("world_model status is INVALID — ignoring road context")
            world_model = None

        # --- Run requirement generators ---
        all_reqs: List[DecisionRequirement] = []

        # Phase 8.3 pipelines — order matters for deduplication priority
        # but final ordering is by priority score (deterministic sort)
        try:
            all_reqs.extend(
                generate_collision_avoidance(situation_state, self._config, frame_id, ts)
            )
        except Exception as exc:
            warnings.append(f"collision_avoidance generator failed: {exc}")

        try:
            all_reqs.extend(
                generate_trajectory_conflict(behavior_reasoning, self._config, frame_id, ts)
            )
        except Exception as exc:
            warnings.append(f"trajectory_conflict generator failed: {exc}")

        try:
            all_reqs.extend(
                generate_vulnerable_user(
                    situation_state, behavior_reasoning, self._config, frame_id, ts
                )
            )
        except Exception as exc:
            warnings.append(f"vulnerable_user generator failed: {exc}")

        try:
            all_reqs.extend(
                generate_road_hazard(
                    situation_state, world_model, self._config, frame_id, ts
                )
            )
        except Exception as exc:
            warnings.append(f"road_hazard generator failed: {exc}")

        try:
            all_reqs.extend(
                generate_narrow_road(
                    situation_state, world_model, self._config, frame_id, ts
                )
            )
        except Exception as exc:
            warnings.append(f"narrow_road generator failed: {exc}")

        try:
            all_reqs.extend(
                generate_intersection(
                    situation_state, world_model, self._config, frame_id, ts
                )
            )
        except Exception as exc:
            warnings.append(f"intersection generator failed: {exc}")

        try:
            all_reqs.extend(
                generate_merge(
                    situation_state, behavior_reasoning, self._config, frame_id, ts
                )
            )
        except Exception as exc:
            warnings.append(f"merge generator failed: {exc}")

        try:
            all_reqs.extend(
                generate_monitor_dynamic_object(
                    situation_state, behavior_reasoning, self._config, frame_id, ts
                )
            )
        except Exception as exc:
            warnings.append(f"monitor_dynamic_object generator failed: {exc}")

        try:
            all_reqs.extend(
                generate_monitor_unpredictable(
                    situation_state, behavior_reasoning, self._config, frame_id, ts
                )
            )
        except Exception as exc:
            warnings.append(f"monitor_unpredictable generator failed: {exc}")

        try:
            all_reqs.extend(
                generate_uncertainty(
                    situation_state, behavior_reasoning, world_model,
                    self._config, frame_id, ts
                )
            )
        except Exception as exc:
            warnings.append(f"uncertainty generator failed: {exc}")

        try:
            all_reqs.extend(
                generate_maintain_safe_space(situation_state, self._config, frame_id, ts)
            )
        except Exception as exc:
            warnings.append(f"maintain_safe_space generator failed: {exc}")

        try:
            all_reqs.extend(
                generate_normal_progress(
                    situation_state, world_model, self._config, frame_id, ts
                )
            )
        except Exception as exc:
            warnings.append(f"normal_progress generator failed: {exc}")

        # --- Deduplicate by requirement type (keep highest priority) ---
        all_reqs = _deduplicate_by_type(all_reqs)

        # --- Suppress NORMAL_PROGRESS if any critical/safety-critical req exists ---
        all_reqs = _suppress_normal_progress_if_warranted(all_reqs)

        # --- Sort: safety-critical first, then by priority descending ---
        all_reqs = _sort_requirements(all_reqs)

        # --- Enforce max requirements bound ---
        if len(all_reqs) > self._config.max_requirements:
            all_reqs = all_reqs[: self._config.max_requirements]

        # --- Classify response family ---
        response_family = classify_response_family(all_reqs)

        # --- Detect relationships ---
        relationships = detect_relationships(all_reqs, self._config)

        # --- Aggregate urgency / severity ---
        overall_urgency = _aggregate_urgency(all_reqs)
        overall_severity = _aggregate_severity(all_reqs)

        # --- Safety-critical flag ---
        any_safety_critical = any(r.is_safety_critical for r in all_reqs)

        # --- Overall confidence / uncertainty ---
        confidence, uncertainty = _aggregate_confidence(situation_state, behavior_reasoning, world_model)

        # --- Input completeness ---
        input_completeness = _compute_input_completeness(
            situation_state, behavior_reasoning, world_model
        )

        # --- Degraded flag ---
        degraded = (
            situation_state.uncertainty_info.sensor_degradation or
            situation_state.uncertainty_info.overall_uncertainty >= self._config.uncertainty_degraded_threshold or
            (world_model is not None and world_model.status == WorldModelStatus.DEGRADED) or
            (behavior_reasoning is not None and behavior_reasoning.degraded)
        )

        # --- Reason codes for the overall snapshot ---
        reason_codes = _build_snapshot_reason_codes(
            all_reqs, response_family, degraded, self._config
        )

        # --- Determine status ---
        if not all_reqs:
            status = "empty"
        elif degraded:
            status = "degraded"
        else:
            status = "ok"

        snap = ActionAbstractionSnapshot(
            schema_version=ACTION_ABSTRACTION_SCHEMA_VERSION,
            timestamp=ts,
            frame_id=frame_id,
            _requirements=tuple(all_reqs),
            _relationships=tuple(relationships),
            response_family=response_family,
            overall_urgency=overall_urgency,
            overall_severity=overall_severity,
            any_safety_critical=any_safety_critical,
            confidence=confidence,
            uncertainty=uncertainty,
            input_completeness=input_completeness,
            degraded=degraded,
            reason_codes=tuple(reason_codes),
            situation_frame_id=situation_state.frame_id,
            behavior_frame_id=(
                behavior_reasoning.frame_id if behavior_reasoning is not None else 0
            ),
        )

        return ActionAbstractionResult(
            snapshot=snap,
            status=status,
            warnings=warnings,
            errors=errors,
            duration_s=time.monotonic() - t_start,
        )

    # ------------------------------------------------------------------
    # Empty / degraded snapshots
    # ------------------------------------------------------------------

    def _build_empty_degraded_snapshot(
        self,
        world_model: Optional[WorldModelSnapshot],
        frame_id: int,
        ts: float,
    ) -> ActionAbstractionSnapshot:
        """
        Build a minimal DEGRADED_OPERATION snapshot when situation_state is None.
        """
        from .requirement_generator import _new_req_id
        from .action_abstraction_types import EvidenceType

        req = DecisionRequirement(
            requirement_id=_new_req_id(),
            requirement_type=RequirementType.DEGRADED_OPERATION,
            priority=1.0,
            urgency=AbstractUrgency.HIGH,
            severity=AbstractSeverity.HIGH,
            confidence=0.0,
            uncertainty=1.0,
            evidence_type=EvidenceType.UNKNOWN,
            source="abstraction_engine",
            affected_entity_ids=tuple(),
            affected_region="all",
            time_relevance_s=None,
            reason_codes=("SITUATION_STATE_UNAVAILABLE",),
            constraints_summary="degraded_operation_mode",
            is_safety_critical=True,
            timestamp=ts,
            frame_id=frame_id,
        )
        return ActionAbstractionSnapshot(
            schema_version=ACTION_ABSTRACTION_SCHEMA_VERSION,
            timestamp=ts,
            frame_id=frame_id,
            _requirements=(req,),
            _relationships=tuple(),
            response_family=ResponseFamily.DEGRADED,
            overall_urgency=AbstractUrgency.HIGH,
            overall_severity=AbstractSeverity.HIGH,
            any_safety_critical=True,
            confidence=0.0,
            uncertainty=1.0,
            input_completeness=0.0,
            degraded=True,
            reason_codes=("MISSING_SITUATION_STATE",),
            situation_frame_id=0,
            behavior_frame_id=0,
        )


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _deduplicate_by_type(
    reqs: List[DecisionRequirement],
) -> List[DecisionRequirement]:
    """
    Keep at most one requirement per RequirementType.
    When duplicates exist, keep the highest-priority one.
    Deterministic: processes in list order, stable for equal priority.
    """
    seen: dict = {}
    for req in reqs:
        rt = req.requirement_type
        if rt not in seen or req.priority > seen[rt].priority:
            seen[rt] = req
    # Restore original order of first appearance
    order = []
    seen_types: set = set()
    for req in reqs:
        rt = req.requirement_type
        if rt not in seen_types:
            order.append(seen[rt])
            seen_types.add(rt)
    return order


def _suppress_normal_progress_if_warranted(
    reqs: List[DecisionRequirement],
) -> List[DecisionRequirement]:
    """
    Remove NORMAL_PROGRESS if any safety-critical, collision, or high-urgency
    requirement is present.
    """
    blocking_types = {
        RequirementType.COLLISION_AVOIDANCE_REQUIRED,
        RequirementType.HANDLE_TRAJECTORY_CONFLICT,
        RequirementType.DEGRADED_OPERATION,
        RequirementType.HANDLE_UNCERTAINTY,
    }
    has_blocker = any(r.requirement_type in blocking_types for r in reqs)
    has_safety_critical = any(r.is_safety_critical for r in reqs)

    if has_blocker or has_safety_critical:
        return [r for r in reqs if r.requirement_type != RequirementType.NORMAL_PROGRESS]
    return reqs


def _sort_requirements(
    reqs: List[DecisionRequirement],
) -> List[DecisionRequirement]:
    """
    Sort requirements deterministically:
      1. Safety-critical first (True before False)
      2. Priority descending
      3. Requirement type value for stable ordering
    """
    return sorted(
        reqs,
        key=lambda r: (
            0 if r.is_safety_critical else 1,   # safety-critical first
            -r.priority,                          # highest priority first
            r.requirement_type.value,             # stable tie-break
        ),
    )


def _aggregate_urgency(reqs: List[DecisionRequirement]) -> AbstractUrgency:
    if not reqs:
        return AbstractUrgency.UNKNOWN
    return max(reqs, key=lambda r: _urgency_rank(r.urgency)).urgency


def _aggregate_severity(reqs: List[DecisionRequirement]) -> AbstractSeverity:
    if not reqs:
        return AbstractSeverity.UNKNOWN
    return max(reqs, key=lambda r: _severity_rank(r.severity)).severity


def _aggregate_confidence(
    situation: ReasoningSnapshot,
    behavior: Optional[BehaviorReasoningState],
    world: Optional[WorldModelSnapshot],
) -> tuple:
    """Return (confidence, uncertainty) as a weighted aggregate."""
    weights = []
    confidences = []
    uncertainties = []

    # Situation state — highest weight
    weights.append(0.5)
    confidences.append(situation.reasoning_confidence)
    uncertainties.append(situation.uncertainty_info.overall_uncertainty)

    if behavior is not None:
        weights.append(0.3)
        confidences.append(behavior.confidence)
        uncertainties.append(behavior.uncertainty)

    if world is not None:
        weights.append(0.2)
        confidences.append(world.data_quality.overall_confidence)
        uncertainties.append(world.data_quality.overall_uncertainty)

    total_w = sum(weights)
    conf = sum(c * w for c, w in zip(confidences, weights)) / total_w
    unc = sum(u * w for u, w in zip(uncertainties, weights)) / total_w
    return round(max(0.0, min(1.0, conf)), 3), round(max(0.0, min(1.0, unc)), 3)


def _compute_input_completeness(
    situation: Optional[ReasoningSnapshot],
    behavior: Optional[BehaviorReasoningState],
    world: Optional[WorldModelSnapshot],
) -> float:
    """
    [0, 1] fraction of expected input modules that delivered valid data.
    Three expected modules: situation, behavior, world.
    """
    present = 0
    total = 3
    if situation is not None:
        present += 1
    if behavior is not None:
        present += 1
    if world is not None:
        present += 1
    return round(present / total, 3)


def _build_snapshot_reason_codes(
    reqs: List[DecisionRequirement],
    family: ResponseFamily,
    degraded: bool,
    cfg: ActionAbstractionConfig,
) -> List[str]:
    codes: List[str] = [f"RESPONSE_FAMILY_{family.value}"]
    if degraded:
        codes.append("DEGRADED_INPUT")
    type_codes = list({r.requirement_type.value for r in reqs})
    type_codes.sort()  # deterministic
    codes.extend(type_codes)
    return codes[: cfg.max_reason_codes]
