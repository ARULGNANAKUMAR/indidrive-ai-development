"""
IndiDrive AI — Phase 8.1 | Reasoning Snapshot Utilities
=========================================================
Utility functions for working with ReasoningSnapshot objects.
Mirrors the pattern from core/world_model/world_model_snapshot.py.
"""
from __future__ import annotations

import copy
import json
import time
from typing import Optional

from .reasoning_types import ReasoningSnapshot

__all__ = [
    "reasoning_snapshot_age_s",
    "is_reasoning_snapshot_stale",
    "reasoning_snapshot_to_json",
    "reasoning_snapshot_summary",
    "safe_copy_reasoning_snapshot",
]


def reasoning_snapshot_age_s(snapshot: ReasoningSnapshot) -> float:
    """Return age of the snapshot in seconds (wall-clock)."""
    return time.time() - snapshot.timestamp


def is_reasoning_snapshot_stale(
    snapshot: ReasoningSnapshot,
    max_age_s: float = 1.5,
) -> bool:
    """Return True if the snapshot is older than max_age_s."""
    return reasoning_snapshot_age_s(snapshot) > max_age_s


def reasoning_snapshot_to_json(snapshot: ReasoningSnapshot, indent: Optional[int] = 2) -> str:
    """Serialise a snapshot to a JSON string."""
    return json.dumps(snapshot.to_dict(), indent=indent)


def reasoning_snapshot_summary(snapshot: ReasoningSnapshot) -> dict:
    """Return a compact human-readable summary dict."""
    return {
        "frame_id": snapshot.frame_id,
        "reasoning_state": snapshot.reasoning_state.value,
        "situation": snapshot.situation.situation_category.value,
        "complexity": snapshot.complexity.complexity_level.value,
        "overall_risk": snapshot.risk.overall_risk_level.value,
        "total_hazards": snapshot.hazards.total_hazards,
        "critical_hazards": snapshot.hazards.critical_hazards,
        "collision_threat": snapshot.risk.collision_threat_present,
        "time_criticality": snapshot.risk.time_criticality.value,
        "reasoning_confidence": snapshot.reasoning_confidence,
        "uncertainty": snapshot.uncertainty_info.overall_uncertainty,
        "world_completeness": snapshot.uncertainty_info.world_completeness.value,
    }


def safe_copy_reasoning_snapshot(snapshot: ReasoningSnapshot) -> ReasoningSnapshot:
    """
    Return a shallow-safe copy of the snapshot.
    The original is not mutated; top-level immutable fields are shared.
    """
    return copy.copy(snapshot)
