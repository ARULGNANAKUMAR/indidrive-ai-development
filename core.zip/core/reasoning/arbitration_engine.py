"""
IndiDrive AI — Phase 8.4 | Decision Arbitration Engine
========================================================
Deterministic arbitration layer that consumes Phase 7, 8.1, 8.2, and 8.3
outputs and produces an ArbitrationResult for Phase 9.

Phase 8.4 answers:
    «"Which abstract requirements are currently dominant, what safety
      constraints must the planner respect, and what is the safety gate?"»

Phase 8.4 does NOT answer:
    «"How should the vehicle steer / brake / accelerate?"»
    «"Which path should the vehicle follow?"»

Design rules:
  * Fully deterministic — same input → same ArbitrationResult.
  * No LLM, no cloud, no ML inference.
  * All thresholds from ArbitrationConfig.
  * Reads upstream phases via their public interfaces only.
  * Does not modify any upstream phase.
  * Thread-safe: no global mutable state.
  * Fails safely: always returns an ArbitrationResult even on bad input.
"""
from __future__ import annotations

import time
import uuid
from typing import Any, List, Optional, Tuple

from .arbitration_types import (
    NOT_AVAILABLE,
    ARBITRATION_SCHEMA_VERSION,
    SafetyGateState,
    ConstraintHardness,
    RequirementStatus,
    TemporalValidity,
    PlanningMode,
    SafetyConstraint,
    ArbitratedRequirement,
    RequirementConflict,
    PlanningContext,
    ArbitrationSnapshot,
    ArbitrationResult,
)
from .arbitration_config import ArbitrationConfig, load_arbitration_config
from .safety_gate import SafetyGateEvaluator

from .action_abstraction_types import (
    DecisionRequirement,
    RequirementType,
    AbstractUrgency,
    AbstractSeverity,
    EvidenceType,
    ActionAbstractionSnapshot,
)
from .reasoning_types import ReasoningSnapshot, ReasoningState
from .behavior_types import BehaviorReasoningState

__all__ = ["DecisionArbitrationEngine"]


# ---------------------------------------------------------------------------
# Priority helpers
# ---------------------------------------------------------------------------

# Numeric value for urgency — higher = more urgent.
_URGENCY_SCORE: dict = {
    AbstractUrgency.IMMEDIATE: 5,
    AbstractUrgency.HIGH:      4,
    AbstractUrgency.MEDIUM:    3,
    AbstractUrgency.LOW:       2,
    AbstractUrgency.NONE:      1,
    AbstractUrgency.UNKNOWN:   0,
}

# Numeric value for severity — higher = more severe.
_SEVERITY_SCORE: dict = {
    AbstractSeverity.CRITICAL: 5,
    AbstractSeverity.HIGH:     4,
    AbstractSeverity.MEDIUM:   3,
    AbstractSeverity.LOW:      2,
    AbstractSeverity.NONE:     1,
    AbstractSeverity.UNKNOWN:  0,
}


def _urgency_score(urgency: AbstractUrgency) -> int:
    return _URGENCY_SCORE.get(urgency, 0)


def _severity_score(severity: AbstractSeverity) -> int:
    return _SEVERITY_SCORE.get(severity, 0)


def _type_priority_index(req_type: RequirementType, order: Tuple[str, ...]) -> int:
    """Lower index = higher priority. Unknown type gets lowest priority."""
    try:
        return order.index(req_type.value)
    except ValueError:
        return len(order)


def _requirement_sort_key(
    req: DecisionRequirement,
    type_order: Tuple[str, ...],
) -> tuple:
    """
    Deterministic sort key for a DecisionRequirement.
    Lower tuple value = higher priority (for sorted(..., reverse=False)).

    Key components (all inverted so that smaller = better):
      0. Not a hard constraint type (0 = hard, 1 = not)
      1. Not safety critical (0 = critical, 1 = not)
      2. Inverted urgency score
      3. Inverted severity score
      4. Inverted priority float (rounded)
      5. Type priority index (lower = better)
      6. Inverted confidence
      7. Stable ID string
    """
    is_hard = int(req.requirement_type.value not in (
        "COLLISION_AVOIDANCE_REQUIRED",
        "HANDLE_TRAJECTORY_CONFLICT",
        "HANDLE_VULNERABLE_USER",
        "DEGRADED_OPERATION",
    ))
    return (
        int(not req.is_safety_critical),
        is_hard,
        -_urgency_score(req.urgency),
        -_severity_score(req.severity),
        -round(req.priority, 4),
        _type_priority_index(req.requirement_type, type_order),
        -round(req.confidence, 3),
        req.requirement_id,        # stable string tie-break
    )


# ---------------------------------------------------------------------------
# Temporal validity helpers
# ---------------------------------------------------------------------------

def _temporal_validity(
    req_timestamp: float,
    now: float,
    cfg: ArbitrationConfig,
) -> TemporalValidity:
    """Classify the temporal validity of a requirement by its age."""
    age_ms = (now - req_timestamp) * 1000.0
    if age_ms < 0:
        return TemporalValidity.UNKNOWN
    if age_ms >= cfg.critical_stale_threshold_ms:
        return TemporalValidity.EXPIRED
    if age_ms >= cfg.stale_threshold_ms:
        return TemporalValidity.STALE
    if age_ms >= cfg.aging_threshold_ms:
        return TemporalValidity.AGING
    return TemporalValidity.VALID


# ---------------------------------------------------------------------------
# Constraint builder
# ---------------------------------------------------------------------------

def _build_constraint(
    req: DecisionRequirement,
    hardness: ConstraintHardness,
    temporal_validity: TemporalValidity,
    constraint_type: str,
    frame_id: int,
) -> SafetyConstraint:
    """Build a SafetyConstraint from a DecisionRequirement."""
    return SafetyConstraint(
        constraint_id=f"c_{req.requirement_id}",
        constraint_type=constraint_type,
        hardness=hardness,
        source=req.source,
        requirement_type=req.requirement_type,
        priority=req.priority,
        urgency=req.urgency,
        severity=req.severity,
        confidence=req.confidence,
        uncertainty=req.uncertainty,
        evidence_type=req.evidence_type,
        affected_entity_ids=req.affected_entity_ids,
        affected_region=req.affected_region,
        reason_codes=req.reason_codes,
        temporal_validity=temporal_validity,
        timestamp=req.timestamp,
        frame_id=frame_id,
    )


def _classify_hardness(
    req: DecisionRequirement,
    cfg: ArbitrationConfig,
) -> ConstraintHardness:
    """Determine whether a requirement generates a HARD or SOFT constraint."""
    if cfg.hard_constraint_if_safety_critical and req.is_safety_critical:
        return ConstraintHardness.HARD
    if req.requirement_type.value in cfg.hard_constraint_requirement_types:
        return ConstraintHardness.HARD
    if req.severity.value in cfg.hard_constraint_severity_values:
        return ConstraintHardness.HARD
    if req.urgency.value in cfg.hard_constraint_urgency_values:
        return ConstraintHardness.HARD
    return ConstraintHardness.SOFT


# ---------------------------------------------------------------------------
# Conflict detection
# ---------------------------------------------------------------------------

def _detect_conflicts(
    sorted_reqs: List[DecisionRequirement],
    cfg: ArbitrationConfig,
) -> List[RequirementConflict]:
    """
    Detect conflicts between simultaneously active requirements.

    conflict_pairs defines (lower_priority_type, higher_priority_type).
    When both exist, the lower_priority one is in conflict with the higher.
    """
    conflicts: List[RequirementConflict] = []
    type_to_reqs: dict = {}
    for req in sorted_reqs:
        type_to_reqs.setdefault(req.requirement_type.value, []).append(req)

    seen: set = set()
    for lower_type, higher_type in cfg.conflict_pairs:
        if lower_type not in type_to_reqs or higher_type not in type_to_reqs:
            continue
        key = (higher_type, lower_type)
        if key in seen:
            continue
        seen.add(key)
        dominant_req = type_to_reqs[higher_type][0]
        suppressed_req = type_to_reqs[lower_type][0]
        conflicts.append(RequirementConflict(
            requirement_id_dominant=dominant_req.requirement_id,
            requirement_id_suppressed=suppressed_req.requirement_id,
            reason_code="SAFETY_PRIORITY_OVERRIDE",
            note=f"{higher_type}_overrides_{lower_type}",
        ))

    return conflicts[:cfg.max_conflicts]


# ---------------------------------------------------------------------------
# Requirement status assignment
# ---------------------------------------------------------------------------

def _assign_statuses(
    sorted_reqs: List[DecisionRequirement],
    conflicts: List[RequirementConflict],
    now: float,
    cfg: ArbitrationConfig,
) -> List[ArbitratedRequirement]:
    """
    Assign RequirementStatus and TemporalValidity to each requirement.

    Rules:
      - First active, non-expired requirement → DOMINANT.
      - Subsequent active, non-expired requirements:
          * If conflicted with a higher-priority requirement → SUPPRESSED/CONFLICTING.
          * Otherwise → ACTIVE or SUPPORTING.
      - STALE/EXPIRED requirements → STALE/EXPIRED status.
    """
    suppressed_ids: dict = {
        c.requirement_id_suppressed: c
        for c in conflicts
    }

    arbitrated: List[ArbitratedRequirement] = []
    dominant_assigned = False

    for req in sorted_reqs:
        tv = _temporal_validity(req.timestamp, now, cfg)

        if tv == TemporalValidity.EXPIRED:
            arbitrated.append(ArbitratedRequirement(
                requirement=req,
                status=RequirementStatus.EXPIRED,
                temporal_validity=tv,
            ))
            continue

        if tv == TemporalValidity.STALE:
            arbitrated.append(ArbitratedRequirement(
                requirement=req,
                status=RequirementStatus.STALE,
                temporal_validity=tv,
            ))
            continue

        if req.requirement_id in suppressed_ids:
            conflict = suppressed_ids[req.requirement_id]
            arbitrated.append(ArbitratedRequirement(
                requirement=req,
                status=RequirementStatus.SUPPRESSED,
                temporal_validity=tv,
                suppressed_by=conflict.requirement_id_dominant,
                suppression_reason=conflict.reason_code,
            ))
            continue

        if not dominant_assigned:
            arbitrated.append(ArbitratedRequirement(
                requirement=req,
                status=RequirementStatus.DOMINANT,
                temporal_validity=tv,
            ))
            dominant_assigned = True
        else:
            # SUPPORTING if it helps the dominant; ACTIVE otherwise.
            # Simple heuristic: same response family as dominant → SUPPORTING.
            first_status = arbitrated[0].status if arbitrated else None
            if (first_status == RequirementStatus.DOMINANT
                    and req.is_safety_critical):
                arbitrated.append(ArbitratedRequirement(
                    requirement=req,
                    status=RequirementStatus.SUPPORTING,
                    temporal_validity=tv,
                ))
            else:
                arbitrated.append(ArbitratedRequirement(
                    requirement=req,
                    status=RequirementStatus.ACTIVE,
                    temporal_validity=tv,
                ))

    return arbitrated


# ---------------------------------------------------------------------------
# Constraint builder
# ---------------------------------------------------------------------------

def _build_constraints(
    arbitrated: List[ArbitratedRequirement],
    cfg: ArbitrationConfig,
    frame_id: int,
) -> Tuple[List[SafetyConstraint], List[SafetyConstraint]]:
    """
    Build hard and soft constraints from arbitrated requirements.

    Only ACTIVE, DOMINANT, SUPPORTING requirements generate constraints.
    SUPPRESSED, STALE, EXPIRED do not generate new constraints (they are
    still preserved in the arbitrated list for transparency).
    """
    hard: List[SafetyConstraint] = []
    soft: List[SafetyConstraint] = []
    total = 0

    for ar in arbitrated:
        if ar.status not in (
            RequirementStatus.ACTIVE,
            RequirementStatus.DOMINANT,
            RequirementStatus.SUPPORTING,
        ):
            continue
        if total >= cfg.max_constraints:
            break

        req = ar.requirement
        hardness = _classify_hardness(req, cfg)
        constraint_type = _derive_constraint_type(req)

        constraint = _build_constraint(
            req, hardness, ar.temporal_validity, constraint_type, frame_id
        )
        if hardness == ConstraintHardness.HARD:
            hard.append(constraint)
        else:
            soft.append(constraint)
        total += 1

    return hard, soft


def _derive_constraint_type(req: DecisionRequirement) -> str:
    """Map a RequirementType to a constraint type string."""
    _map = {
        RequirementType.COLLISION_AVOIDANCE_REQUIRED: "COLLISION_CRITICAL",
        RequirementType.HANDLE_TRAJECTORY_CONFLICT:   "TRAJECTORY_CONFLICT",
        RequirementType.HANDLE_VULNERABLE_USER:       "VRU_CRITICAL",
        RequirementType.HANDLE_ROAD_HAZARD:           "ROAD_HAZARD",
        RequirementType.MAINTAIN_DRIVABLE_REGION:     "DRIVABLE_REGION_RESTRICTION",
        RequirementType.HANDLE_NARROW_ROAD:           "NARROW_ROAD_RESTRICTION",
        RequirementType.HANDLE_INTERSECTION:          "INTERSECTION_HANDLING",
        RequirementType.HANDLE_MERGE:                 "MERGE_HANDLING",
        RequirementType.MONITOR_DYNAMIC_OBJECT:       "DYNAMIC_MONITORING",
        RequirementType.MONITOR_UNPREDICTABLE_OBJECT: "UNPREDICTABLE_MONITORING",
        RequirementType.HANDLE_UNCERTAINTY:           "UNCERTAINTY_RESTRICTION",
        RequirementType.DEGRADED_OPERATION:           "DEGRADED_MODE",
        RequirementType.MAINTAIN_SAFE_SPACE:          "SAFE_SPACE_PREFERENCE",
        RequirementType.NORMAL_PROGRESS:              "NORMAL_PROGRESS_PREFERENCE",
    }
    return _map.get(req.requirement_type, "ABSTRACT_CONSTRAINT")


# ---------------------------------------------------------------------------
# Planning mode derivation
# ---------------------------------------------------------------------------

def _derive_planning_mode(
    gate_state: SafetyGateState,
) -> PlanningMode:
    """Map SafetyGateState to PlanningMode."""
    _map = {
        SafetyGateState.CLEAR:      PlanningMode.NORMAL,
        SafetyGateState.CAUTION:    PlanningMode.RESTRICTED,
        SafetyGateState.RESTRICTED: PlanningMode.RESTRICTED,
        SafetyGateState.HIGH_ALERT: PlanningMode.SAFETY_RESTRICTED,
        SafetyGateState.CRITICAL:   PlanningMode.SAFETY_RESTRICTED,
        SafetyGateState.DEGRADED:   PlanningMode.DEGRADED,
        SafetyGateState.UNKNOWN:    PlanningMode.UNKNOWN,
    }
    return _map.get(gate_state, PlanningMode.UNKNOWN)


# ---------------------------------------------------------------------------
# Uncertainty level classification
# ---------------------------------------------------------------------------

def _classify_uncertainty_level(uncertainty: float) -> str:
    if uncertainty < 0.30:
        return "LOW"
    if uncertainty < 0.60:
        return "MEDIUM"
    if uncertainty < 0.85:
        return "HIGH"
    return "VERY_HIGH"


# ---------------------------------------------------------------------------
# Main engine
# ---------------------------------------------------------------------------

class DecisionArbitrationEngine:
    """
    Phase 8.4 Decision Arbitration Engine.

    Consumes Phase 7 / 8.1 / 8.2 / 8.3 outputs.
    Produces an ArbitrationResult containing:
      - ArbitrationSnapshot (primary output)
      - PlanningContext (handoff to Phase 9)
      - ArbitrationResult.status

    Public interface
    ----------------
    engine = DecisionArbitrationEngine()
    result = engine.arbitrate(
        world_model=...,       # WorldModelSnapshot | None
        situation_state=...,   # ReasoningSnapshot | None
        behavior_state=...,    # BehaviorReasoningState | None
        action_abstraction=...,# ActionAbstractionSnapshot | None
        timestamp=...,         # float | None (wall-clock seconds)
    )
    """

    def __init__(self, config: Optional[ArbitrationConfig] = None) -> None:
        self._config = config or load_arbitration_config()
        self._gate = SafetyGateEvaluator(self._config)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def arbitrate(
        self,
        world_model=None,
        situation_state=None,
        behavior_state=None,
        action_abstraction=None,
        timestamp: Optional[float] = None,
    ) -> ArbitrationResult:
        """
        Run arbitration.

        Parameters
        ----------
        world_model         : WorldModelSnapshot | None
        situation_state     : ReasoningSnapshot | None
        behavior_state      : BehaviorReasoningState | None
        action_abstraction  : ActionAbstractionSnapshot | None
        timestamp           : float | None  (defaults to time.time())

        Returns
        -------
        ArbitrationResult — always valid, never raises.
        """
        t_start = time.time()
        now = timestamp if timestamp is not None else t_start

        warnings: List[str] = []
        errors: List[str] = []
        status = "ok"

        try:
            snapshot, status, warnings, errors = self._run(
                world_model, situation_state, behavior_state,
                action_abstraction, now, warnings, errors,
            )
        except Exception as exc:
            errors.append(f"arbitration_engine_error: {exc}")
            snapshot = self._empty_snapshot(now)
            status = "error"

        duration_s = time.time() - t_start

        return ArbitrationResult(
            snapshot=snapshot,
            status=status,
            warnings=warnings,
            errors=errors,
            duration_s=duration_s,
        )

    # ------------------------------------------------------------------
    # Internal orchestration
    # ------------------------------------------------------------------

    def _run(
        self,
        world_model,
        situation_state,
        behavior_state,
        action_abstraction,
        now: float,
        warnings: List[str],
        errors: List[str],
    ):
        cfg = self._config
        status = "ok"

        # ---------------------------------------------------------------
        # 1. Extract inputs safely
        # ---------------------------------------------------------------
        wm_completeness, wm_uncertainty, wm_degraded, wm_frame_id = \
            self._extract_world_model(world_model, warnings)

        sit_frame_id = (situation_state.frame_id
                        if situation_state is not None else 0)
        beh_frame_id = (behavior_state.frame_id
                        if behavior_state is not None else 0)

        # ---------------------------------------------------------------
        # 2. Handle absent abstraction snapshot
        # ---------------------------------------------------------------
        if action_abstraction is None:
            warnings.append("action_abstraction_missing")
            status = "empty"
            snapshot = self._degraded_snapshot(
                now=now,
                wm_completeness=wm_completeness,
                wm_uncertainty=wm_uncertainty,
                degraded=True,
                reason_codes=("UNKNOWN_WORLD_STATE",),
                sit_frame_id=sit_frame_id,
                beh_frame_id=beh_frame_id,
                frame_id=wm_frame_id,
            )
            return snapshot, status, warnings, errors

        abs_snap: ActionAbstractionSnapshot = action_abstraction
        abs_frame_id = abs_snap.frame_id
        frame_id = abs_frame_id or wm_frame_id

        # ---------------------------------------------------------------
        # 3. Gather overall uncertainty / confidence / completeness
        # ---------------------------------------------------------------
        overall_uncertainty = max(abs_snap.uncertainty, wm_uncertainty)
        overall_confidence = min(abs_snap.confidence,
                                 1.0 - wm_uncertainty + 0.001)
        overall_confidence = max(0.0, min(1.0, overall_confidence))

        # Use config thresholds for degraded classification so that a
        # merely partial world model (completeness=0.75) is not treated
        # the same as a truly degraded one (completeness=0.15).
        is_degraded = (
            abs_snap.degraded
            or (wm_degraded and wm_completeness < cfg.degraded_completeness_threshold)
            or wm_completeness < cfg.degraded_completeness_threshold
            or overall_uncertainty > cfg.degraded_uncertainty_threshold
        )
        if is_degraded:
            status = "degraded"

        # ---------------------------------------------------------------
        # 4. Sort requirements deterministically
        # ---------------------------------------------------------------
        requirements = list(abs_snap.requirements)

        if not requirements:
            warnings.append("no_requirements_from_phase83")
            if status == "ok":
                status = "empty"

        sorted_reqs = sorted(
            requirements,
            key=lambda r: _requirement_sort_key(
                r, cfg.requirement_type_priority_order
            )
        )
        # Bound
        sorted_reqs = sorted_reqs[:cfg.max_active_requirements]

        # ---------------------------------------------------------------
        # 5. Detect conflicts
        # ---------------------------------------------------------------
        conflicts = _detect_conflicts(sorted_reqs, cfg)

        # ---------------------------------------------------------------
        # 6. Assign statuses
        # ---------------------------------------------------------------
        arbitrated = _assign_statuses(sorted_reqs, conflicts, now, cfg)

        # ---------------------------------------------------------------
        # 7. Build constraints
        # ---------------------------------------------------------------
        hard_constraints, soft_constraints = _build_constraints(
            arbitrated, cfg, frame_id
        )

        # ---------------------------------------------------------------
        # 8. Safety gate evaluation
        # ---------------------------------------------------------------
        gate_state, gate_reason_codes = self._gate.evaluate(
            abstraction_snapshot=abs_snap,
            world_model_completeness=wm_completeness,
            overall_uncertainty=overall_uncertainty,
            degraded=is_degraded,
        )

        # ---------------------------------------------------------------
        # 9. Assemble reason codes
        # ---------------------------------------------------------------
        reason_codes: List[str] = list(gate_reason_codes)
        for c in conflicts:
            if c.reason_code not in reason_codes:
                reason_codes.append(c.reason_code)
        if is_degraded and "DEGRADED_OPERATION" not in reason_codes:
            reason_codes.append("DEGRADED_OPERATION")
        reason_codes = reason_codes[:cfg.max_reason_codes]

        # ---------------------------------------------------------------
        # 10. Dominant requirement
        # ---------------------------------------------------------------
        dominant: Optional[ArbitratedRequirement] = next(
            (ar for ar in arbitrated
             if ar.status == RequirementStatus.DOMINANT),
            None,
        )

        # ---------------------------------------------------------------
        # 11. Planning mode / allowed
        # ---------------------------------------------------------------
        planning_mode = _derive_planning_mode(gate_state)
        planning_allowed = gate_state not in (
            SafetyGateState.UNKNOWN,
        )
        safety_override = gate_state in (
            SafetyGateState.CRITICAL,
            SafetyGateState.HIGH_ALERT,
        )

        # ---------------------------------------------------------------
        # 12. Active requirements for PlanningContext
        # ---------------------------------------------------------------
        active_for_context = tuple(
            ar for ar in arbitrated
            if ar.status in (RequirementStatus.DOMINANT,
                             RequirementStatus.ACTIVE,
                             RequirementStatus.SUPPORTING)
        )

        # ---------------------------------------------------------------
        # 13. Affected entity IDs (aggregate, bounded)
        # ---------------------------------------------------------------
        entity_ids: List[str] = []
        seen_ids: set = set()
        for ar in active_for_context:
            for eid in ar.requirement.affected_entity_ids:
                if eid not in seen_ids and eid != NOT_AVAILABLE:
                    entity_ids.append(eid)
                    seen_ids.add(eid)
        entity_ids_tuple = tuple(entity_ids[:16])

        # ---------------------------------------------------------------
        # 14. Assemble PlanningContext
        # ---------------------------------------------------------------
        planning_context = PlanningContext(
            context_id=f"ctx_{frame_id}_{int(now * 1000) % 1_000_000}",
            timestamp=now,
            frame_id=frame_id,
            safety_gate_state=gate_state,
            dominant_requirement=dominant,
            _active_requirements=active_for_context,
            _hard_constraints=tuple(hard_constraints),
            _soft_constraints=tuple(soft_constraints),
            affected_entity_ids=entity_ids_tuple,
            uncertainty_level=_classify_uncertainty_level(overall_uncertainty),
            world_model_completeness=wm_completeness,
            planning_allowed=planning_allowed,
            planning_mode=planning_mode,
            safety_override_required=safety_override,
            reason_codes=tuple(reason_codes),
            confidence=overall_confidence,
        )

        # ---------------------------------------------------------------
        # 15. Assemble ArbitrationSnapshot
        # ---------------------------------------------------------------
        snapshot = ArbitrationSnapshot(
            schema_version=ARBITRATION_SCHEMA_VERSION,
            timestamp=now,
            frame_id=frame_id,
            safety_gate_state=gate_state,
            _arbitrated_requirements=tuple(arbitrated),
            _conflicts=tuple(conflicts),
            planning_context=planning_context,
            confidence=overall_confidence,
            uncertainty=overall_uncertainty,
            world_model_completeness=wm_completeness,
            degraded=is_degraded,
            reason_codes=tuple(reason_codes),
            situation_frame_id=sit_frame_id,
            behavior_frame_id=beh_frame_id,
            abstraction_frame_id=abs_frame_id,
        )

        return snapshot, status, warnings, errors

    # ------------------------------------------------------------------
    # World model extraction
    # ------------------------------------------------------------------

    def _extract_world_model(
        self, world_model, warnings: List[str]
    ) -> Tuple[float, float, bool, int]:
        """
        Safely extract completeness, uncertainty, degraded flag, frame_id
        from a WorldModelSnapshot.  Returns safe defaults if None/invalid.
        """
        if world_model is None:
            warnings.append("world_model_missing")
            return 0.0, 1.0, True, 0

        try:
            dq = world_model.data_quality
            completeness = float(getattr(dq, "completeness", 0.0))
            uncertainty = float(getattr(dq, "overall_uncertainty", 1.0))
            is_partial = bool(getattr(dq, "is_partial", True))
            frame_id = int(getattr(world_model, "frame_id", 0))

            status = getattr(world_model, "status", None)
            status_val = status.value if hasattr(status, "value") else str(status)
            degraded = status_val in ("DEGRADED", "EMPTY", "INVALID") or is_partial

            return completeness, uncertainty, degraded, frame_id
        except Exception as exc:
            warnings.append(f"world_model_extraction_error: {exc}")
            return 0.0, 1.0, True, 0

    # ------------------------------------------------------------------
    # Safe fallback snapshots
    # ------------------------------------------------------------------

    def _empty_snapshot(self, now: float) -> ArbitrationSnapshot:
        """Minimal valid snapshot for catastrophic error cases."""
        ctx = PlanningContext(
            context_id=f"ctx_error_{int(now * 1000) % 1_000_000}",
            timestamp=now,
            safety_gate_state=SafetyGateState.UNKNOWN,
            planning_allowed=False,
            planning_mode=PlanningMode.UNKNOWN,
            reason_codes=("UNKNOWN_WORLD_STATE",),
        )
        return ArbitrationSnapshot(
            timestamp=now,
            safety_gate_state=SafetyGateState.UNKNOWN,
            planning_context=ctx,
            degraded=True,
            reason_codes=("UNKNOWN_WORLD_STATE",),
        )

    def _degraded_snapshot(
        self,
        now: float,
        wm_completeness: float,
        wm_uncertainty: float,
        degraded: bool,
        reason_codes: tuple,
        sit_frame_id: int,
        beh_frame_id: int,
        frame_id: int,
    ) -> ArbitrationSnapshot:
        """Snapshot for missing-abstraction or fully-degraded case."""
        gate = SafetyGateState.UNKNOWN
        planning_mode = PlanningMode.UNKNOWN

        ctx = PlanningContext(
            context_id=f"ctx_deg_{frame_id}_{int(now * 1000) % 1_000_000}",
            timestamp=now,
            frame_id=frame_id,
            safety_gate_state=gate,
            planning_allowed=False,
            planning_mode=planning_mode,
            safety_override_required=True,
            reason_codes=reason_codes,
            uncertainty_level=_classify_uncertainty_level(wm_uncertainty),
            world_model_completeness=wm_completeness,
        )
        return ArbitrationSnapshot(
            timestamp=now,
            frame_id=frame_id,
            safety_gate_state=gate,
            planning_context=ctx,
            confidence=0.0,
            uncertainty=wm_uncertainty,
            world_model_completeness=wm_completeness,
            degraded=True,
            reason_codes=reason_codes,
            situation_frame_id=sit_frame_id,
            behavior_frame_id=beh_frame_id,
        )
