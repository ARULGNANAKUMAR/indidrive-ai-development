"""
IndiDrive AI — Phase 8.1 | Reasoning Package
=============================================
Public interface for the Phase 8.1 Situation Assessment & Risk Reasoning layer.

Quick start
-----------
    from core.reasoning import ReasoningEngine, load_reasoning_config

    config = load_reasoning_config()
    engine = ReasoningEngine(config=config)
    result = engine.assess(world_model_snapshot)

    snapshot = result.snapshot
    if result.is_valid:
        print(snapshot.reasoning_state)
        print(snapshot.hazards.total_hazards)

Architectural boundary
-----------------------
Phase 8.1 does NOT implement planning, path finding, MPC, steering,
braking, throttle, lane-change execution, or any vehicle control.
The output is only a structured environmental reasoning state.
"""
from .reasoning_engine import ReasoningEngine
from .reasoning_config import ReasoningConfig, load_reasoning_config
from .reasoning_types import (
    # Sentinel
    NOT_AVAILABLE,
    # Schema
    REASONING_SCHEMA_VERSION,
    # Enums
    ReasoningState,
    SituationCategory,
    HazardCategory,
    TtcBand,
    InteractionType,
    RiskLevel,
    ComplexityLevel,
    UncertaintyLevel,
    WorldCompletenessLevel,
    # Sub-structures
    HazardEntry,
    InteractionEntry,
    SituationInfo,
    EnvironmentInfo,
    HazardSummary,
    RiskSummary,
    ComplexityInfo,
    UncertaintyInfo,
    ReasoningExplanation,
    # Primary output
    ReasoningSnapshot,
    ReasoningResult,
)
from .reasoning_validator import ReasoningValidator, ReasoningValidationResult
from .reasoning_snapshot import (
    reasoning_snapshot_age_s,
    is_reasoning_snapshot_stale,
    reasoning_snapshot_to_json,
    reasoning_snapshot_summary,
    safe_copy_reasoning_snapshot,
)

__all__ = [
    "ReasoningEngine",
    "ReasoningConfig",
    "load_reasoning_config",
    "NOT_AVAILABLE",
    "REASONING_SCHEMA_VERSION",
    "ReasoningState",
    "SituationCategory",
    "HazardCategory",
    "TtcBand",
    "InteractionType",
    "RiskLevel",
    "ComplexityLevel",
    "UncertaintyLevel",
    "WorldCompletenessLevel",
    "HazardEntry",
    "InteractionEntry",
    "SituationInfo",
    "EnvironmentInfo",
    "HazardSummary",
    "RiskSummary",
    "ComplexityInfo",
    "UncertaintyInfo",
    "ReasoningExplanation",
    "ReasoningSnapshot",
    "ReasoningResult",
    "ReasoningValidator",
    "ReasoningValidationResult",
    "reasoning_snapshot_age_s",
    "is_reasoning_snapshot_stale",
    "reasoning_snapshot_to_json",
    "reasoning_snapshot_summary",
    "safe_copy_reasoning_snapshot",
]

# ---------------------------------------------------------------------------
# Phase 8.2 — Behavior & Interaction Reasoning
# ---------------------------------------------------------------------------
from .behavior_types import (
    BEHAVIOR_REASONING_SCHEMA_VERSION,
    EvidenceClass,
    BehaviorState,
    IntentType,
    BehaviorInteractionType,
    InteractionSeverity,
    TimeRelevance,
    CompoundSituationType,
    GraphEdgeType,
    BehaviorValidationStatus,
    BehaviorEvidenceItem,
    BehaviorClassification,
    IntentHypothesis,
    BehaviorInteractionEntry,
    InteractionGraphNode,
    InteractionGraphEdge,
    InteractionGraph,
    CompoundSituation,
    BehaviorReasoningState,
    BehaviorReasoningResult,
)
from .behavior_reasoning_config import BehaviorReasoningConfig, load_behavior_reasoning_config
from .behavior_reasoning_engine import BehaviorReasoningEngine
from .behavior_validator import BehaviorValidator, BehaviorValidationResult
from .behavior_snapshot import (
    behavior_state_age_s,
    is_behavior_state_stale,
    behavior_state_to_json,
    behavior_state_summary,
    safe_copy_behavior_state,
)

__all__ += [
    # Phase 8.2 schema
    "BEHAVIOR_REASONING_SCHEMA_VERSION",
    # Enums
    "EvidenceClass",
    "BehaviorState",
    "IntentType",
    "BehaviorInteractionType",
    "InteractionSeverity",
    "TimeRelevance",
    "CompoundSituationType",
    "GraphEdgeType",
    "BehaviorValidationStatus",
    # Data types
    "BehaviorEvidenceItem",
    "BehaviorClassification",
    "IntentHypothesis",
    "BehaviorInteractionEntry",
    "InteractionGraphNode",
    "InteractionGraphEdge",
    "InteractionGraph",
    "CompoundSituation",
    "BehaviorReasoningState",
    "BehaviorReasoningResult",
    # Config
    "BehaviorReasoningConfig",
    "load_behavior_reasoning_config",
    # Engine
    "BehaviorReasoningEngine",
    # Validator
    "BehaviorValidator",
    "BehaviorValidationResult",
    # Snapshot utils
    "behavior_state_age_s",
    "is_behavior_state_stale",
    "behavior_state_to_json",
    "behavior_state_summary",
    "safe_copy_behavior_state",
]

# ---------------------------------------------------------------------------
# Phase 8.3 — Decision & Action Abstraction Layer
# ---------------------------------------------------------------------------
from .action_abstraction_types import (
    ACTION_ABSTRACTION_SCHEMA_VERSION,
    RequirementType,
    ResponseFamily,
    AbstractUrgency,
    AbstractSeverity,
    EvidenceType,
    RequirementRelationship,
    AbstractionValidationStatus,
    DecisionRequirement,
    RequirementRelationshipEntry,
    ActionAbstractionSnapshot,
    ActionAbstractionResult,
)
from .action_abstraction_config import (
    ActionAbstractionConfig,
    load_action_abstraction_config,
)
from .action_abstraction_engine import ActionAbstractionEngine
from .action_abstraction_validator import (
    ActionAbstractionValidator,
    ActionAbstractionValidationResult,
)
from .action_abstraction_snapshot import (
    abstraction_snapshot_age_s,
    is_abstraction_snapshot_stale,
    abstraction_snapshot_to_json,
    abstraction_snapshot_summary,
    safe_copy_abstraction_snapshot,
    find_requirement_by_type,
)

__all__ += [
    # Phase 8.3 schema
    "ACTION_ABSTRACTION_SCHEMA_VERSION",
    # Enums
    "RequirementType",
    "ResponseFamily",
    "AbstractUrgency",
    "AbstractSeverity",
    "EvidenceType",
    "RequirementRelationship",
    "AbstractionValidationStatus",
    # Data types
    "DecisionRequirement",
    "RequirementRelationshipEntry",
    "ActionAbstractionSnapshot",
    "ActionAbstractionResult",
    # Config
    "ActionAbstractionConfig",
    "load_action_abstraction_config",
    # Engine
    "ActionAbstractionEngine",
    # Validator
    "ActionAbstractionValidator",
    "ActionAbstractionValidationResult",
    # Snapshot utils
    "abstraction_snapshot_age_s",
    "is_abstraction_snapshot_stale",
    "abstraction_snapshot_to_json",
    "abstraction_snapshot_summary",
    "safe_copy_abstraction_snapshot",
    "find_requirement_by_type",
]

# ---------------------------------------------------------------------------
# Phase 8.4 — Decision Arbitration & Safety Gate
# ---------------------------------------------------------------------------
from .arbitration_types import (
    ARBITRATION_SCHEMA_VERSION,
    SafetyGateState,
    ConstraintHardness,
    RequirementStatus,
    TemporalValidity,
    PlanningMode,
    ArbitrationValidationStatus,
    SafetyConstraint,
    ArbitratedRequirement,
    RequirementConflict,
    PlanningContext,
    ArbitrationSnapshot,
    ArbitrationResult,
)
from .arbitration_config import ArbitrationConfig, load_arbitration_config
from .arbitration_engine import DecisionArbitrationEngine
from .arbitration_validator import ArbitrationValidator, ArbitrationValidationResult
from .arbitration_snapshot import (
    arbitration_snapshot_age_s,
    is_arbitration_snapshot_stale,
    arbitration_snapshot_to_json,
    arbitration_snapshot_summary,
    safe_copy_arbitration_snapshot,
    find_arbitrated_by_type,
)
from .safety_gate import SafetyGateEvaluator

__all__ += [
    # Phase 8.4 schema
    "ARBITRATION_SCHEMA_VERSION",
    # Enums
    "SafetyGateState",
    "ConstraintHardness",
    "RequirementStatus",
    "TemporalValidity",
    "PlanningMode",
    "ArbitrationValidationStatus",
    # Data types
    "SafetyConstraint",
    "ArbitratedRequirement",
    "RequirementConflict",
    "PlanningContext",
    "ArbitrationSnapshot",
    "ArbitrationResult",
    # Config
    "ArbitrationConfig",
    "load_arbitration_config",
    # Engine
    "DecisionArbitrationEngine",
    # Validator
    "ArbitrationValidator",
    "ArbitrationValidationResult",
    # Snapshot utils
    "arbitration_snapshot_age_s",
    "is_arbitration_snapshot_stale",
    "arbitration_snapshot_to_json",
    "arbitration_snapshot_summary",
    "safe_copy_arbitration_snapshot",
    "find_arbitrated_by_type",
    # Safety gate
    "SafetyGateEvaluator",
]
