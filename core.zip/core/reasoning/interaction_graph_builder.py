"""
IndiDrive AI — Phase 8.2 | Pairwise Interaction & Graph Builder
================================================================
Detects pairwise interactions between entities and builds the
bounded interaction graph for the current reasoning snapshot.

Consumes:
  - WorldModelSnapshot (objects, road, indian_context)
  - BehaviorClassification list
  - Phase 8.1 HazardEntry list (for severity signals)

Produces:
  - List[BehaviorInteractionEntry]
  - InteractionGraph

Design:
  - Deterministic
  - Bounded: configured max nodes / edges / interactions
  - No duplicate TTC/collision engines (uses WM data)
  - No path planning or vehicle control
  - No LLM or cloud
"""
from __future__ import annotations

import math
from typing import Dict, List, Optional, Tuple

from core.world_model.world_model_types import (
    WorldModelSnapshot, WorldObject, NOT_AVAILABLE
)
from .reasoning_types import HazardEntry, TtcBand

from .behavior_types import (
    BehaviorClassification,
    BehaviorEvidenceItem,
    BehaviorInteractionEntry,
    BehaviorInteractionType,
    BehaviorState,
    EvidenceClass,
    GraphEdgeType,
    InteractionGraph,
    InteractionGraphEdge,
    InteractionGraphNode,
    InteractionSeverity,
    TimeRelevance,
)
from .behavior_reasoning_config import BehaviorReasoningConfig

__all__ = ["InteractionGraphBuilder"]

# ---------------------------------------------------------------------------
# Evidence codes
# ---------------------------------------------------------------------------
_E_TRAJ_INTERSECT = "TRAJECTORY_INTERSECTION"
_E_TTC_FINITE     = "TTC_FINITE"
_E_CLOSING        = "CLOSING_SPEED_HIGH"
_E_PROXIMITY      = "CLOSE_PROXIMITY"
_E_CONFLICT       = "PREDICTED_CONFLICT"
_E_LAT_MOTION     = "LATERAL_MOTION"
_E_ROAD_BOUND     = "NEAR_ROAD_BOUNDARY"
_E_NARROW_ROAD    = "NARROW_ROAD_CONTEXT"
_E_VRU            = "VULNERABLE_ROAD_USER"
_E_CATTLE         = "CATTLE_ENTITY"
_E_WRONG_SIDE     = "WRONG_SIDE_APPROACH"
_E_ANOMALY        = "ROAD_ANOMALY_PRESENT"
_E_COMPOUND       = "COMPOUND_MULTI_ENTITY"


def _ev(code: str, cls: EvidenceClass, strength: float = 0.6) -> BehaviorEvidenceItem:
    return BehaviorEvidenceItem(code=code, evidence_class=cls, strength=strength)


# Severity derivation from risk_level string
_RISK_TO_SEVERITY: Dict[str, InteractionSeverity] = {
    "CRITICAL": InteractionSeverity.CRITICAL,
    "HIGH":     InteractionSeverity.HIGH,
    "MEDIUM":   InteractionSeverity.MEDIUM,
    "LOW":      InteractionSeverity.LOW,
}


class InteractionGraphBuilder:
    """
    Builds pairwise interaction entries and the bounded interaction graph.
    """

    def __init__(self, config: BehaviorReasoningConfig) -> None:
        self._cfg = config
        self._icount = 0
        self._ecount = 0

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def build(
        self,
        snapshot: WorldModelSnapshot,
        behaviors: List[BehaviorClassification],
        hazards: List[HazardEntry],
    ) -> Tuple[List[BehaviorInteractionEntry], InteractionGraph]:
        """
        Build interactions and interaction graph for the current snapshot.

        Returns (interactions, graph).
        """
        self._icount = 0
        self._ecount = 0

        objects_by_id: Dict[str, WorldObject] = {}
        for obj in snapshot.objects:
            oid = obj.primary_id()
            if oid:
                objects_by_id[oid] = obj

        behaviors_by_id: Dict[str, BehaviorClassification] = {
            bc.entity_id: bc for bc in behaviors
        }

        hazards_by_id: Dict[str, HazardEntry] = {
            h.hazard_id: h for h in hazards
        }

        interactions: List[BehaviorInteractionEntry] = []

        # 1. Ego ↔ each object interaction
        for bc in behaviors:
            if len(interactions) >= self._cfg.max_behavior_interactions:
                break
            obj = objects_by_id.get(bc.entity_id)
            entry = self._ego_object_interaction(bc, obj, snapshot)
            if entry is not None:
                interactions.append(entry)

        # 2. Object ↔ road anomaly interactions
        if snapshot.road.status.value != "NONE":
            for obj in snapshot.objects:
                if len(interactions) >= self._cfg.max_behavior_interactions:
                    break
                entry = self._entity_road_interaction(obj, snapshot)
                if entry is not None:
                    interactions.append(entry)

        # 3. Pairwise object ↔ object for high-risk pairs
        high_risk_objs = [
            o for o in snapshot.objects
            if o.collision.risk_level in ("HIGH", "CRITICAL")
        ]
        pairs_seen: set = set()
        for i, oa in enumerate(high_risk_objs):
            for ob in high_risk_objs[i+1:]:
                if len(interactions) >= self._cfg.max_behavior_interactions:
                    break
                pair_key = tuple(sorted([oa.primary_id() or "", ob.primary_id() or ""]))
                if pair_key in pairs_seen:
                    continue
                pairs_seen.add(pair_key)
                entry = self._obj_obj_interaction(oa, ob, snapshot)
                if entry is not None:
                    interactions.append(entry)

        # 4. Build interaction graph
        graph = self._build_graph(
            snapshot, behaviors, interactions, objects_by_id
        )

        return interactions, graph

    # ------------------------------------------------------------------
    # Ego ↔ object
    # ------------------------------------------------------------------

    def _ego_object_interaction(
        self,
        bc: BehaviorClassification,
        obj: Optional[WorldObject],
        snapshot: WorldModelSnapshot,
    ) -> Optional[BehaviorInteractionEntry]:
        """Interaction between ego vehicle and one world object."""
        if obj is None:
            return None

        dist = obj.position.distance_m
        if dist is not None and dist > self._cfg.max_interaction_distance_m:
            return None

        collision = obj.collision
        otype = obj.object_type.upper()
        osubtype = obj.object_subtype.upper()

        # Determine interaction type
        itype = self._classify_ego_interaction_type(otype, osubtype, bc, obj, snapshot)

        # Determine severity from existing collision data
        severity = _RISK_TO_SEVERITY.get(collision.risk_level, InteractionSeverity.UNKNOWN)
        if severity == InteractionSeverity.UNKNOWN:
            severity = self._infer_severity(bc, obj, snapshot)

        # Time relevance from TTC
        time_rel = self._time_relevance_from_ttc(collision.ttc_s, collision.ttc_status)

        # Evidence
        evidence: List[BehaviorEvidenceItem] = []
        if collision.predicted_conflict:
            evidence.append(_ev(_E_CONFLICT, EvidenceClass.PREDICTED, 0.75))
            evidence.append(_ev(_E_TRAJ_INTERSECT, EvidenceClass.PREDICTED, 0.7))
        if collision.ttc_s is not None:
            evidence.append(_ev(_E_TTC_FINITE, EvidenceClass.OBSERVED, 0.7))
        if collision.closing_speed_ms and collision.closing_speed_ms > 1.0:
            evidence.append(_ev(_E_CLOSING, EvidenceClass.OBSERVED, 0.75))
        if dist is not None and dist < self._cfg.proximity_threshold_m:
            evidence.append(_ev(_E_PROXIMITY, EvidenceClass.OBSERVED, 0.8))
        is_vru = otype in ("PEDESTRIAN", "CYCLIST", "CATTLE") or osubtype in ("COW", "BULL", "CATTLE")
        if is_vru:
            evidence.append(_ev(_E_VRU, EvidenceClass.OBSERVED, 0.6))
            if "CATTLE" in otype or osubtype in ("COW", "BULL", "CATTLE"):
                evidence.append(_ev(_E_CATTLE, EvidenceClass.OBSERVED, 0.55))
        if bc.behavior_state == BehaviorState.CROSSING:
            evidence.append(_ev(_E_LAT_MOTION, EvidenceClass.INFERRED, 0.65))

        # Confidence: use object quality
        conf = max(0.2, obj.quality.object_confidence * 0.9)
        unc = round(1.0 - conf, 3)

        # Filter low-confidence
        if conf < self._cfg.interaction_min_confidence:
            return None

        return BehaviorInteractionEntry(
            interaction_id=self._next_iid(),
            entity_a_id="ego",
            entity_b_id=bc.entity_id,
            interaction_type=itype,
            interaction_state=EvidenceClass.OBSERVED if collision.ttc_s is not None else EvidenceClass.INFERRED,
            severity=severity,
            time_relevance=time_rel,
            confidence=round(conf, 3),
            uncertainty=unc,
            evidence=evidence[: self._cfg.max_evidence_items],
        )

    def _classify_ego_interaction_type(
        self,
        otype: str,
        osubtype: str,
        bc: BehaviorClassification,
        obj: WorldObject,
        snapshot: WorldModelSnapshot,
    ) -> BehaviorInteractionType:
        """Map object type + behavior → interaction type."""
        # Specific vulnerable types
        if "PEDESTRIAN" in otype:
            return BehaviorInteractionType.PEDESTRIAN_VEHICLE
        if "CATTLE" in otype or osubtype in ("COW", "BULL", "CATTLE"):
            return BehaviorInteractionType.CATTLE_VEHICLE
        # Vehicle types
        if otype in ("VEHICLE", "CAR", "TRUCK", "BUS", "TRACTOR",
                     "AUTO_RICKSHAW", "MOTORCYCLE", "SCOOTER", "CYCLIST",
                     "PUSHCART"):
            # Check for wrong-side indicator
            vx = obj.velocity.vx
            if vx is not None and vx < -1.0:
                return BehaviorInteractionType.WRONG_SIDE_APPROACH
            if bc.behavior_state == BehaviorState.CROSSING:
                return BehaviorInteractionType.CROSSING
            if bc.behavior_state == BehaviorState.MERGING:
                return BehaviorInteractionType.MERGING
            if bc.behavior_state == BehaviorState.APPROACHING:
                return BehaviorInteractionType.APPROACHING
            if bc.behavior_state == BehaviorState.LATERAL_MOVEMENT:
                return BehaviorInteractionType.LATERAL_CONFLICT
            return BehaviorInteractionType.VEHICLE_VEHICLE
        return BehaviorInteractionType.APPROACHING

    # ------------------------------------------------------------------
    # Entity ↔ road anomaly
    # ------------------------------------------------------------------

    def _entity_road_interaction(
        self,
        obj: WorldObject,
        snapshot: WorldModelSnapshot,
    ) -> Optional[BehaviorInteractionEntry]:
        """Check if an object is interacting with a road anomaly or boundary."""
        if not snapshot.road.anomalies:
            return None
        dist = obj.position.distance_m
        if dist is None or dist > self._cfg.road_context_distance_m:
            return None
        # Any critical anomaly within context range = interaction
        critical = any(a.severity == "CRITICAL" for a in snapshot.road.anomalies)
        sev = InteractionSeverity.HIGH if critical else InteractionSeverity.MEDIUM

        evidence = [
            _ev(_E_ANOMALY, EvidenceClass.OBSERVED, 0.65),
            _ev(_E_PROXIMITY, EvidenceClass.INFERRED, 0.55),
        ]
        dw = snapshot.road.drivable_space.road_width_m
        if dw is not None and dw < self._cfg.narrow_road_width_m:
            evidence.append(_ev(_E_NARROW_ROAD, EvidenceClass.OBSERVED, 0.6))

        conf = 0.5
        return BehaviorInteractionEntry(
            interaction_id=self._next_iid(),
            entity_a_id=obj.primary_id() or NOT_AVAILABLE,
            entity_b_id="road_anomaly",
            interaction_type=BehaviorInteractionType.ENTITY_ROAD_ANOMALY,
            interaction_state=EvidenceClass.OBSERVED,
            severity=sev,
            time_relevance=TimeRelevance.UNKNOWN,
            confidence=conf,
            uncertainty=round(1.0 - conf, 3),
            evidence=evidence,
        )

    # ------------------------------------------------------------------
    # Object ↔ Object
    # ------------------------------------------------------------------

    def _obj_obj_interaction(
        self,
        oa: WorldObject,
        ob: WorldObject,
        snapshot: WorldModelSnapshot,
    ) -> Optional[BehaviorInteractionEntry]:
        """Interaction between two non-ego objects."""
        # Compute relative distance
        xa, ya = oa.position.x, oa.position.y
        xb, yb = ob.position.x, ob.position.y
        if None in (xa, ya, xb, yb):
            return None
        rel_dist = math.sqrt((xa - xb)**2 + (ya - yb)**2)
        if rel_dist > self._cfg.max_interaction_distance_m:
            return None

        # Only if both have collision risk
        sev_a = _RISK_TO_SEVERITY.get(oa.collision.risk_level, InteractionSeverity.LOW)
        sev_b = _RISK_TO_SEVERITY.get(ob.collision.risk_level, InteractionSeverity.LOW)
        max_sev = sev_a if (
            list(InteractionSeverity).index(sev_a) >= list(InteractionSeverity).index(sev_b)
        ) else sev_b

        evidence = [
            _ev("HIGH_RISK_PROXIMITY", EvidenceClass.INFERRED, 0.6),
            _ev("OBJECT_OBJECT_CONFLICT", EvidenceClass.INFERRED, 0.55),
        ]
        conf = 0.45
        return BehaviorInteractionEntry(
            interaction_id=self._next_iid(),
            entity_a_id=oa.primary_id() or NOT_AVAILABLE,
            entity_b_id=ob.primary_id() or NOT_AVAILABLE,
            interaction_type=BehaviorInteractionType.VEHICLE_VEHICLE,
            interaction_state=EvidenceClass.INFERRED,
            severity=max_sev,
            time_relevance=TimeRelevance.UNKNOWN,
            confidence=conf,
            uncertainty=round(1.0 - conf, 3),
            evidence=evidence,
        )

    # ------------------------------------------------------------------
    # Interaction graph
    # ------------------------------------------------------------------

    def _build_graph(
        self,
        snapshot: WorldModelSnapshot,
        behaviors: List[BehaviorClassification],
        interactions: List[BehaviorInteractionEntry],
        objects_by_id: Dict[str, WorldObject],
    ) -> InteractionGraph:
        """Build bounded interaction graph."""
        nodes: List[InteractionGraphNode] = []
        edges: List[InteractionGraphEdge] = []

        # Add ego node
        nodes.append(InteractionGraphNode(node_id="ego", node_type="ego", label="ego_vehicle"))

        # Add object nodes (bounded)
        node_ids_added: set = {"ego"}
        for bc in behaviors[:self._cfg.max_graph_nodes - 1]:
            if bc.entity_id and bc.entity_id not in node_ids_added:
                nodes.append(InteractionGraphNode(
                    node_id=bc.entity_id,
                    node_type="object",
                    label=f"{bc.entity_type.lower()}_{bc.entity_id[-4:]}",
                ))
                node_ids_added.add(bc.entity_id)

        # Add road anomaly node if applicable
        if snapshot.road.anomalies and len(nodes) < self._cfg.max_graph_nodes:
            nodes.append(InteractionGraphNode(
                node_id="road_anomaly",
                node_type="road_feature",
                label="road_anomaly",
            ))
            node_ids_added.add("road_anomaly")

        # Add edges from interactions (bounded)
        for inter in interactions[:self._cfg.max_graph_edges]:
            if (inter.entity_a_id in node_ids_added and
                    inter.entity_b_id in node_ids_added):
                etype = self._interaction_to_edge_type(inter.interaction_type)
                edges.append(InteractionGraphEdge(
                    edge_id=self._next_eid(),
                    from_node=inter.entity_a_id,
                    to_node=inter.entity_b_id,
                    edge_type=etype,
                    weight=inter.confidence,
                    confidence=inter.confidence,
                ))

        graph = InteractionGraph()
        graph.nodes = nodes[: self._cfg.max_graph_nodes]
        graph.edges = edges[: self._cfg.max_graph_edges]
        return graph

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _interaction_to_edge_type(
        itype: BehaviorInteractionType,
    ) -> GraphEdgeType:
        mapping = {
            BehaviorInteractionType.CROSSING: GraphEdgeType.TRAJECTORY_OVERLAP,
            BehaviorInteractionType.APPROACHING: GraphEdgeType.SPATIAL_PROXIMITY,
            BehaviorInteractionType.MERGING: GraphEdgeType.ROAD_SPACE_SHARING,
            BehaviorInteractionType.LATERAL_CONFLICT: GraphEdgeType.TRAJECTORY_OVERLAP,
            BehaviorInteractionType.LONGITUDINAL_CONFLICT: GraphEdgeType.TRAJECTORY_OVERLAP,
            BehaviorInteractionType.ENTITY_ROAD_ANOMALY: GraphEdgeType.ROAD_SPACE_SHARING,
            BehaviorInteractionType.ENTITY_ROAD_BOUNDARY: GraphEdgeType.ROAD_SPACE_SHARING,
            BehaviorInteractionType.WRONG_SIDE_APPROACH: GraphEdgeType.PREDICTED_CONFLICT,
            BehaviorInteractionType.PEDESTRIAN_VEHICLE: GraphEdgeType.BEHAVIORAL_COUPLING,
            BehaviorInteractionType.CATTLE_VEHICLE: GraphEdgeType.BEHAVIORAL_COUPLING,
        }
        return mapping.get(itype, GraphEdgeType.SPATIAL_PROXIMITY)

    def _time_relevance_from_ttc(
        self,
        ttc: Optional[float],
        ttc_status: str,
    ) -> TimeRelevance:
        if ttc_status == "NO_COLLISION" or ttc is None:
            return TimeRelevance.UNKNOWN
        if ttc <= self._cfg.ttc_immediate_s:
            return TimeRelevance.IMMEDIATE
        if ttc <= self._cfg.ttc_near_s:
            return TimeRelevance.NEAR_TERM
        if ttc <= self._cfg.ttc_moderate_s:
            return TimeRelevance.MEDIUM_TERM
        return TimeRelevance.DISTANT

    def _infer_severity(
        self,
        bc: BehaviorClassification,
        obj: WorldObject,
        snapshot: WorldModelSnapshot,
    ) -> InteractionSeverity:
        """Fallback severity derivation when risk_level unavailable."""
        likelihood = obj.collision.collision_likelihood
        if likelihood is None:
            return InteractionSeverity.LOW
        if likelihood >= 0.75:
            return InteractionSeverity.CRITICAL
        if likelihood >= 0.5:
            return InteractionSeverity.HIGH
        if likelihood >= 0.25:
            return InteractionSeverity.MEDIUM
        return InteractionSeverity.LOW

    def _next_iid(self) -> str:
        self._icount += 1
        return f"bi_{self._icount:04d}"

    def _next_eid(self) -> str:
        self._ecount += 1
        return f"ge_{self._ecount:04d}"
