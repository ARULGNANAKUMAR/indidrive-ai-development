"""
IndiDrive AI — Phase 8.2 | Behavior Reasoning Validator
=========================================================
Validates a BehaviorReasoningState for structural integrity.

Validates:
  - Entity IDs
  - Interaction IDs
  - Confidence / uncertainty
  - Behavior states
  - Intent types
  - Interaction types
  - Graph size bounds
  - Hypothesis bounds
  - Schema version
  - Completeness range

Returns:
  BehaviorValidationResult with status VALID | PARTIAL | DEGRADED | INVALID

Does NOT silently repair invalid inputs.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import List

from .behavior_types import (
    BehaviorReasoningState,
    BehaviorState,
    BehaviorValidationStatus,
    IntentType,
    BehaviorInteractionType,
    InteractionSeverity,
    TimeRelevance,
    EvidenceClass,
    BEHAVIOR_REASONING_SCHEMA_VERSION,
    NOT_AVAILABLE,
)
from .behavior_reasoning_config import BehaviorReasoningConfig

__all__ = ["BehaviorValidator", "BehaviorValidationResult"]

_VALID_BEHAVIOR_STATES = {s.value for s in BehaviorState}
_VALID_INTENT_TYPES = {i.value for i in IntentType}
_VALID_INTERACTION_TYPES = {t.value for t in BehaviorInteractionType}
_VALID_SEVERITIES = {s.value for s in InteractionSeverity}
_VALID_TIME_RELEVANCE = {t.value for t in TimeRelevance}
_VALID_EVIDENCE_CLASSES = {c.value for c in EvidenceClass}


@dataclass
class BehaviorValidationResult:
    status: BehaviorValidationStatus = BehaviorValidationStatus.VALID
    warnings: List[str] = field(default_factory=list)
    errors: List[str] = field(default_factory=list)

    @property
    def is_valid(self) -> bool:
        return self.status in (
            BehaviorValidationStatus.VALID,
            BehaviorValidationStatus.PARTIAL,
        )

    def to_dict(self) -> dict:
        return {
            "status": self.status.value,
            "warnings": list(self.warnings),
            "errors": list(self.errors),
        }


class BehaviorValidator:
    """Validates BehaviorReasoningState structural integrity."""

    def __init__(self, config: BehaviorReasoningConfig) -> None:
        self._cfg = config

    def validate(self, state: BehaviorReasoningState) -> BehaviorValidationResult:
        result = BehaviorValidationResult()

        # Schema version
        if state.schema_version != BEHAVIOR_REASONING_SCHEMA_VERSION:
            result.warnings.append(
                f"schema_version_mismatch: {state.schema_version} != "
                f"{BEHAVIOR_REASONING_SCHEMA_VERSION}"
            )

        # Completeness range
        if not (0.0 <= state.completeness <= 1.0):
            result.errors.append(f"completeness_out_of_range: {state.completeness}")

        # Confidence / uncertainty
        self._check_conf_unc(state.confidence, state.uncertainty, "state", result)

        # Entity behaviors
        for bc in state.entity_behaviors:
            if bc.entity_id == NOT_AVAILABLE:
                result.warnings.append("entity_behavior_missing_id")
            if bc.behavior_state.value not in _VALID_BEHAVIOR_STATES:
                result.errors.append(f"invalid_behavior_state: {bc.behavior_state}")
            self._check_conf_unc(bc.behavior_confidence, bc.behavior_uncertainty, "behavior", result)

        # Bounds: entity behaviors
        if len(state.entity_behaviors) > self._cfg.max_behavior_entities:
            result.errors.append(
                f"entity_behaviors_exceed_max: {len(state.entity_behaviors)} > "
                f"{self._cfg.max_behavior_entities}"
            )

        # Interactions
        seen_iids: set = set()
        for inter in state.interactions:
            if inter.interaction_id in seen_iids:
                result.errors.append(f"duplicate_interaction_id: {inter.interaction_id}")
            seen_iids.add(inter.interaction_id)
            if inter.interaction_type.value not in _VALID_INTERACTION_TYPES:
                result.errors.append(f"invalid_interaction_type: {inter.interaction_type}")
            if inter.severity.value not in _VALID_SEVERITIES:
                result.errors.append(f"invalid_severity: {inter.severity}")
            self._check_conf_unc(inter.confidence, inter.uncertainty, "interaction", result)

        if len(state.interactions) > self._cfg.max_behavior_interactions:
            result.errors.append(
                f"interactions_exceed_max: {len(state.interactions)} > "
                f"{self._cfg.max_behavior_interactions}"
            )

        # Intent hypotheses
        for ih in state.intent_hypotheses:
            if ih.intent_type.value not in _VALID_INTENT_TYPES:
                result.errors.append(f"invalid_intent_type: {ih.intent_type}")
            self._check_conf_unc(ih.confidence, ih.uncertainty, "intent", result)

        if len(state.intent_hypotheses) > self._cfg.max_intent_hypotheses:
            result.errors.append(
                f"intent_hypotheses_exceed_max: {len(state.intent_hypotheses)} > "
                f"{self._cfg.max_intent_hypotheses}"
            )

        # Graph bounds
        if state.interaction_graph.node_count > self._cfg.max_graph_nodes:
            result.errors.append(
                f"graph_nodes_exceed_max: {state.interaction_graph.node_count} > "
                f"{self._cfg.max_graph_nodes}"
            )
        if state.interaction_graph.edge_count > self._cfg.max_graph_edges:
            result.errors.append(
                f"graph_edges_exceed_max: {state.interaction_graph.edge_count} > "
                f"{self._cfg.max_graph_edges}"
            )

        # Compound situations
        if len(state.compound_situations) > self._cfg.max_compound_situations:
            result.errors.append(
                f"compound_situations_exceed_max: {len(state.compound_situations)} > "
                f"{self._cfg.max_compound_situations}"
            )

        # Determine final status
        if result.errors:
            result.status = BehaviorValidationStatus.INVALID
        elif result.warnings:
            result.status = BehaviorValidationStatus.PARTIAL
        else:
            result.status = BehaviorValidationStatus.VALID

        return result

    @staticmethod
    def _check_conf_unc(
        conf: float,
        unc: float,
        label: str,
        result: BehaviorValidationResult,
    ) -> None:
        if not (0.0 <= conf <= 1.0):
            result.errors.append(f"{label}_confidence_out_of_range: {conf}")
        if not (0.0 <= unc <= 1.0):
            result.errors.append(f"{label}_uncertainty_out_of_range: {unc}")
