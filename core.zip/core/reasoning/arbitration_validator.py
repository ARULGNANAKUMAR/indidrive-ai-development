"""
IndiDrive AI — Phase 8.4 | Arbitration Validator
==================================================
Structured validation for ArbitrationSnapshot and PlanningContext.

Validation states:
  VALID    — all fields pass all checks
  PARTIAL  — non-critical fields missing or out-of-range
  DEGRADED — significant fields missing; use with caution
  INVALID  — critical structural failure; do not use

Does NOT silently repair invalid data.
Reports all violations.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import List

from .arbitration_types import (
    NOT_AVAILABLE,
    ARBITRATION_SCHEMA_VERSION,
    ArbitrationValidationStatus,
    ArbitrationSnapshot,
    PlanningContext,
    SafetyConstraint,
    ArbitratedRequirement,
    SafetyGateState,
    ConstraintHardness,
    RequirementStatus,
    TemporalValidity,
    PlanningMode,
)

__all__ = [
    "ArbitrationValidator",
    "ArbitrationValidationResult",
]

# ---------------------------------------------------------------------------
# Fields that must NEVER appear in Phase 8.4 output
# ---------------------------------------------------------------------------
_FORBIDDEN_KEYS = frozenset({
    "steering", "throttle", "brake", "path_points", "waypoints",
    "trajectory", "steering_angle", "target_speed", "lane_change_command",
    "throttle_cmd", "brake_cmd", "acceleration_cmd", "steer_cmd",
    "path", "waypoint", "mpc_cmd",
})

_FORBIDDEN_CONSTRAINT_KEYWORDS = frozenset({
    "steer_left", "steer_right", "brake_now", "throttle_up",
    "accelerate_to", "decelerate_to", "change_lane",
    "overtake_now", "turn_left", "turn_right",
})


@dataclass
class ArbitrationValidationResult:
    """Result of validating an ArbitrationSnapshot."""
    status: ArbitrationValidationStatus = ArbitrationValidationStatus.INVALID
    errors: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)

    @property
    def is_usable(self) -> bool:
        return self.status in (
            ArbitrationValidationStatus.VALID,
            ArbitrationValidationStatus.PARTIAL,
            ArbitrationValidationStatus.DEGRADED,
        )

    def to_dict(self) -> dict:
        return {
            "status": self.status.value,
            "error_count": len(self.errors),
            "warning_count": len(self.warnings),
            "errors": list(self.errors),
            "warnings": list(self.warnings),
        }


class ArbitrationValidator:
    """
    Validate an ArbitrationSnapshot for structural integrity.
    Does not repair data — only reports violations.
    """

    def validate(
        self,
        snapshot: ArbitrationSnapshot,
        max_requirements: int = 12,
        max_constraints: int = 24,
    ) -> ArbitrationValidationResult:
        """Validate the snapshot and return a structured result."""
        errors: List[str] = []
        warnings: List[str] = []

        # --- Schema version ---
        if snapshot.schema_version != ARBITRATION_SCHEMA_VERSION:
            errors.append(
                f"schema_version mismatch: expected "
                f"'{ARBITRATION_SCHEMA_VERSION}', "
                f"got '{snapshot.schema_version}'"
            )

        # --- Timestamp ---
        if snapshot.timestamp <= 0:
            errors.append("timestamp is zero or negative")

        # --- Frame ID ---
        if snapshot.frame_id < 0:
            errors.append("frame_id is negative")

        # --- Safety gate state ---
        try:
            SafetyGateState(snapshot.safety_gate_state)
        except (ValueError, KeyError):
            errors.append(
                f"safety_gate_state is not a valid SafetyGateState: "
                f"{snapshot.safety_gate_state!r}"
            )

        # --- Confidence / uncertainty ---
        if not (0.0 <= snapshot.confidence <= 1.0):
            errors.append(
                f"confidence out of range [0,1]: {snapshot.confidence}"
            )
        if not (0.0 <= snapshot.uncertainty <= 1.0):
            errors.append(
                f"uncertainty out of range [0,1]: {snapshot.uncertainty}"
            )
        if not (0.0 <= snapshot.world_model_completeness <= 1.0):
            errors.append(
                f"world_model_completeness out of range [0,1]: "
                f"{snapshot.world_model_completeness}"
            )

        # --- Arbitrated requirements ---
        if len(snapshot.arbitrated_requirements) > max_requirements:
            warnings.append(
                f"arbitrated_requirements count "
                f"({len(snapshot.arbitrated_requirements)}) "
                f"exceeds max ({max_requirements})"
            )

        dominant_count = 0
        for i, ar in enumerate(snapshot.arbitrated_requirements):
            errs = self._validate_arbitrated(ar, i)
            errors.extend(errs)
            if ar.status == RequirementStatus.DOMINANT:
                dominant_count += 1

        if dominant_count > 1:
            errors.append(
                f"multiple DOMINANT requirements: {dominant_count}"
            )

        # --- Planning context ---
        ctx_errors = self._validate_planning_context(
            snapshot.planning_context, max_constraints
        )
        errors.extend(ctx_errors)

        # --- Consistency: gate state vs planning_allowed ---
        if (snapshot.safety_gate_state == SafetyGateState.UNKNOWN
                and snapshot.planning_context.planning_allowed):
            errors.append(
                "planning_allowed=True while safety_gate_state=UNKNOWN"
            )

        # --- Consistency: CRITICAL/HIGH_ALERT → safety_override_required ---
        if snapshot.safety_gate_state in (
            SafetyGateState.CRITICAL, SafetyGateState.HIGH_ALERT
        ):
            if not snapshot.planning_context.safety_override_required:
                warnings.append(
                    f"safety_override_required=False while gate="
                    f"{snapshot.safety_gate_state.value}"
                )

        # --- Reason codes ---
        if not snapshot.reason_codes:
            warnings.append("reason_codes is empty")

        # --- Forbidden fields ---
        serial = snapshot.to_dict()
        forbidden_found = self._scan_forbidden(serial)
        if forbidden_found:
            errors.append(
                f"forbidden vehicle-control fields found: {forbidden_found}"
            )

        # --- Determine status ---
        if errors:
            # Critical structural errors → INVALID
            critical = [e for e in errors if "mismatch" in e
                        or "out of range" in e or "forbidden" in e
                        or "multiple DOMINANT" in e]
            if critical:
                status = ArbitrationValidationStatus.INVALID
            elif snapshot.degraded:
                status = ArbitrationValidationStatus.DEGRADED
            else:
                status = ArbitrationValidationStatus.PARTIAL
        elif warnings:
            status = ArbitrationValidationStatus.PARTIAL
        else:
            status = ArbitrationValidationStatus.VALID

        return ArbitrationValidationResult(
            status=status,
            errors=errors,
            warnings=warnings,
        )

    # ------------------------------------------------------------------

    def _validate_arbitrated(
        self,
        ar: ArbitratedRequirement,
        index: int,
    ) -> List[str]:
        errors: List[str] = []
        prefix = f"arbitrated_requirements[{index}]"

        # Status
        try:
            RequirementStatus(ar.status)
        except (ValueError, KeyError):
            errors.append(f"{prefix}.status invalid: {ar.status!r}")

        # Temporal validity
        try:
            TemporalValidity(ar.temporal_validity)
        except (ValueError, KeyError):
            errors.append(
                f"{prefix}.temporal_validity invalid: "
                f"{ar.temporal_validity!r}"
            )

        # Expired requirement must not be DOMINANT or ACTIVE
        if ar.temporal_validity in (
            TemporalValidity.EXPIRED,
        ) and ar.status in (RequirementStatus.DOMINANT, RequirementStatus.ACTIVE):
            errors.append(
                f"{prefix}: EXPIRED requirement cannot be DOMINANT or ACTIVE"
            )

        # Suppressed requirement should have suppressed_by set
        if ar.status == RequirementStatus.SUPPRESSED:
            if ar.suppressed_by == NOT_AVAILABLE:
                errors.append(
                    f"{prefix}: SUPPRESSED requirement missing suppressed_by"
                )

        # Requirement priority range
        req = ar.requirement
        if not (0.0 <= req.priority <= 1.0):
            errors.append(
                f"{prefix}.requirement.priority out of range [0,1]: "
                f"{req.priority}"
            )
        if not (0.0 <= req.confidence <= 1.0):
            errors.append(
                f"{prefix}.requirement.confidence out of range [0,1]: "
                f"{req.confidence}"
            )
        if not (0.0 <= req.uncertainty <= 1.0):
            errors.append(
                f"{prefix}.requirement.uncertainty out of range [0,1]: "
                f"{req.uncertainty}"
            )

        return errors

    def _validate_planning_context(
        self,
        ctx: PlanningContext,
        max_constraints: int,
    ) -> List[str]:
        errors: List[str] = []

        if ctx.timestamp <= 0:
            errors.append("planning_context.timestamp is zero or negative")

        try:
            SafetyGateState(ctx.safety_gate_state)
        except (ValueError, KeyError):
            errors.append(
                f"planning_context.safety_gate_state invalid: "
                f"{ctx.safety_gate_state!r}"
            )

        try:
            PlanningMode(ctx.planning_mode)
        except (ValueError, KeyError):
            errors.append(
                f"planning_context.planning_mode invalid: "
                f"{ctx.planning_mode!r}"
            )

        if not (0.0 <= ctx.confidence <= 1.0):
            errors.append(
                f"planning_context.confidence out of range [0,1]: "
                f"{ctx.confidence}"
            )

        if not (0.0 <= ctx.world_model_completeness <= 1.0):
            errors.append(
                f"planning_context.world_model_completeness out of range [0,1]: "
                f"{ctx.world_model_completeness}"
            )

        total_constraints = ctx.hard_constraint_count + ctx.soft_constraint_count
        if total_constraints > max_constraints:
            errors.append(
                f"planning_context total constraints "
                f"({total_constraints}) exceeds max ({max_constraints})"
            )

        # Hard constraints must not be optional
        for i, hc in enumerate(ctx.hard_constraints):
            if hc.hardness != ConstraintHardness.HARD:
                errors.append(
                    f"planning_context.hard_constraints[{i}].hardness "
                    f"is not HARD: {hc.hardness!r}"
                )

        # Forbidden fields in context
        ctx_dict = ctx.to_dict()
        forbidden_found = self._scan_forbidden(ctx_dict)
        if forbidden_found:
            errors.append(
                f"planning_context contains forbidden vehicle-control fields: "
                f"{forbidden_found}"
            )

        return errors

    def _scan_forbidden(self, d: dict) -> List[str]:
        """Recursively scan a dict for forbidden vehicle-control keys."""
        found: List[str] = []
        for k, v in d.items():
            if k in _FORBIDDEN_KEYS:
                found.append(k)
            # Also check constraint reason_codes for forbidden keywords
            if k == "reason_codes" and isinstance(v, list):
                for code in v:
                    code_lower = str(code).lower()
                    for kw in _FORBIDDEN_CONSTRAINT_KEYWORDS:
                        if kw in code_lower:
                            found.append(f"forbidden_keyword_in_reason_code:{code}")
            if isinstance(v, dict):
                found.extend(self._scan_forbidden(v))
            elif isinstance(v, list):
                for item in v:
                    if isinstance(item, dict):
                        found.extend(self._scan_forbidden(item))
        return found
