"""
IndiDrive AI — Phase 8.3 | Action Abstraction Configuration
=============================================================
All thresholds and limits governing Phase 8.3 Decision & Action Abstraction.
No magic numbers in the engine — every configurable value lives here.

Loaded from config/reasoning_config.yaml (same file as Phase 8.1 / 8.2).
Phase 8.3 keys use the prefix 'abstraction_' to avoid conflicts.
Unknown keys are silently ignored for forward-compatibility.
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Optional

__all__ = ["ActionAbstractionConfig", "load_action_abstraction_config"]

ROOT = Path(__file__).resolve().parent.parent.parent
CONFIG_PATH = ROOT / "config" / "reasoning_config.yaml"


@dataclass
class ActionAbstractionConfig:
    """
    Configuration for Phase 8.3 action abstraction layer.
    Safe defaults suitable for Indian road conditions.
    """

    # ------------------------------------------------------------------
    # TTC thresholds (seconds) — mirror Phase 8.1 / 8.2 values
    # ------------------------------------------------------------------
    ttc_immediate_s: float = 1.5
    """TTC below this → IMMEDIATE urgency."""

    ttc_high_s: float = 3.0
    """TTC below this → HIGH urgency."""

    ttc_medium_s: float = 6.0
    """TTC below this → MEDIUM urgency; beyond = LOW."""

    # ------------------------------------------------------------------
    # Collision likelihood thresholds
    # ------------------------------------------------------------------
    collision_likelihood_critical: float = 0.75
    """Collision likelihood above this → severity CRITICAL."""

    collision_likelihood_high: float = 0.50
    """Collision likelihood above this → severity HIGH."""

    collision_likelihood_medium: float = 0.25
    """Collision likelihood above this → severity MEDIUM."""

    # ------------------------------------------------------------------
    # Priority score weights [0, 1]
    # Weights are normalised — they define relative contribution.
    # ------------------------------------------------------------------
    priority_weight_collision_likelihood: float = 0.30
    """Weight of collision_likelihood in requirement priority."""

    priority_weight_ttc: float = 0.25
    """Weight of TTC band in requirement priority."""

    priority_weight_severity: float = 0.20
    """Weight of interaction severity in requirement priority."""

    priority_weight_vulnerability: float = 0.15
    """Bonus weight for vulnerable road user requirements."""

    priority_weight_uncertainty: float = 0.10
    """Weight of uncertainty level in requirement priority."""

    # ------------------------------------------------------------------
    # Severity thresholds
    # ------------------------------------------------------------------
    risk_level_critical_severity: str = "CRITICAL"
    """RiskLevel value that maps to CRITICAL severity."""

    risk_level_high_severity: str = "HIGH"
    """RiskLevel value that maps to HIGH severity."""

    # ------------------------------------------------------------------
    # Road width thresholds (metres)
    # ------------------------------------------------------------------
    narrow_road_width_m: float = 4.5
    """Roads narrower than this trigger HANDLE_NARROW_ROAD."""

    very_narrow_road_width_m: float = 3.0
    """Roads narrower than this escalate HANDLE_NARROW_ROAD priority."""

    # ------------------------------------------------------------------
    # Uncertainty / confidence thresholds
    # ------------------------------------------------------------------
    uncertainty_high_threshold: float = 0.6
    """Overall uncertainty above this → HANDLE_UNCERTAINTY may be generated."""

    uncertainty_degraded_threshold: float = 0.85
    """Overall uncertainty above this → DEGRADED_OPERATION generated."""

    confidence_low_threshold: float = 0.3
    """Confidence below this → degraded mode for this requirement."""

    completeness_degraded_threshold: float = 0.25
    """World model completeness below this → DEGRADED_OPERATION generated."""

    # ------------------------------------------------------------------
    # Sensor / module degradation thresholds
    # ------------------------------------------------------------------
    sensor_degradation_triggers_degraded: bool = True
    """Whether sensor degradation alone triggers DEGRADED_OPERATION."""

    prediction_unavailable_triggers_uncertainty: bool = True
    """Whether missing prediction triggers HANDLE_UNCERTAINTY."""

    road_info_unavailable_triggers_uncertainty: bool = True
    """Whether missing road info triggers MAINTAIN_DRIVABLE_REGION + HANDLE_UNCERTAINTY."""

    # ------------------------------------------------------------------
    # Normal progress conditions
    # ------------------------------------------------------------------
    normal_progress_max_hazard_count: int = 0
    """NORMAL_PROGRESS only when hazard count is at most this."""

    normal_progress_max_uncertainty: float = 0.4
    """NORMAL_PROGRESS only when overall uncertainty is at most this."""

    normal_progress_min_world_completeness: float = 0.5
    """NORMAL_PROGRESS only when world completeness is at least this."""

    normal_progress_allowed_risk_levels: tuple = ("LOW", "UNKNOWN")
    """NORMAL_PROGRESS only when overall risk is one of these."""

    # ------------------------------------------------------------------
    # Collection bounds
    # ------------------------------------------------------------------
    max_requirements: int = 12
    """Maximum number of DecisionRequirement entries in one snapshot."""

    max_relationships: int = 16
    """Maximum number of RequirementRelationshipEntry entries."""

    max_reason_codes: int = 10
    """Maximum reason codes per requirement."""

    max_affected_entities: int = 8
    """Maximum affected entity IDs per requirement."""

    # ------------------------------------------------------------------
    # Intersection / merge detection
    # ------------------------------------------------------------------
    intersection_context_triggers: tuple = (
        "INTERSECTION",
        "JUNCTION",
        "ROUNDABOUT",
    )
    """intersection_context values that trigger HANDLE_INTERSECTION."""

    merge_context_triggers: tuple = (
        "MERGE",
        "HIGHWAY_MERGE",
        "LANE_MERGE",
    )
    """Traffic mix / context values that trigger HANDLE_MERGE."""

    # ------------------------------------------------------------------
    # Staleness
    # ------------------------------------------------------------------
    stale_data_threshold_s: float = 1.5
    """Data older than this is considered stale."""

    # ------------------------------------------------------------------
    # Requirement relationship detection
    # ------------------------------------------------------------------
    detect_relationships: bool = True
    """Whether to compute requirement relationships."""

    # ------------------------------------------------------------------
    # Construction
    # ------------------------------------------------------------------

    @classmethod
    def from_dict(cls, data: dict) -> "ActionAbstractionConfig":
        """Build from a config dict.  Unknown keys are ignored."""
        cfg = cls()
        for key, val in data.items():
            # Strip 'abstraction_' prefix if present
            attr = key[12:] if key.startswith("abstraction_") else key
            if hasattr(cfg, attr):
                current = getattr(cfg, attr)
                if isinstance(current, float) and isinstance(val, (int, float)):
                    setattr(cfg, attr, float(val))
                elif isinstance(current, int) and isinstance(val, int):
                    setattr(cfg, attr, int(val))
                elif isinstance(current, str) and isinstance(val, str):
                    setattr(cfg, attr, str(val))
                elif isinstance(current, bool) and isinstance(val, bool):
                    setattr(cfg, attr, bool(val))
                elif isinstance(current, tuple) and isinstance(val, (list, tuple)):
                    setattr(cfg, attr, tuple(val))
        return cfg


def load_action_abstraction_config(
    config_path: Optional[str] = None,
) -> ActionAbstractionConfig:
    """
    Load ActionAbstractionConfig from YAML.
    Falls back to safe defaults if the file is missing or malformed.
    """
    path = Path(config_path) if config_path else CONFIG_PATH
    if not path.exists():
        return ActionAbstractionConfig()
    try:
        import yaml  # type: ignore
        with open(path, "r", encoding="utf-8") as f:
            data = yaml.safe_load(f)
        if isinstance(data, dict):
            return ActionAbstractionConfig.from_dict(data)
        return ActionAbstractionConfig()
    except Exception:
        return ActionAbstractionConfig()
