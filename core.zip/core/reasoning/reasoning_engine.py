"""
IndiDrive AI — Phase 8.1 | Reasoning Engine (Public API)
==========================================================
Main entry point for Phase 8.1 Situation Assessment & Risk Reasoning.

Usage
-----
    config = load_reasoning_config()
    engine = ReasoningEngine(config=config)

    result = engine.assess(world_model_snapshot)

    snapshot = result.snapshot
    if result.is_valid:
        print(snapshot.reasoning_state)

Thread Safety
-------------
assess() is stateless and thread-safe.  Multiple snapshots can be
assessed concurrently with independent engine instances.  The engine
does NOT share mutable global state.

Architectural Boundary
-----------------------
Phase 8.1 does NOT implement:
  - Path planning
  - Candidate trajectories / Hybrid A*
  - MPC / steering / braking / throttle
  - Lane-change execution
  - Overtaking decisions
  - Vehicle control
  - World Model redesign
  - LLM / cloud / neural-network reasoning

The output is only a structured environmental reasoning state.
"""
from __future__ import annotations

import time
from typing import List, Optional

from core.world_model.world_model_types import (
    WorldModelSnapshot,
    WorldModelStatus,
    InputModuleStatus,
    NOT_AVAILABLE,
)
from .reasoning_config import ReasoningConfig, load_reasoning_config
from .reasoning_types import (
    ComplexityLevel,
    EnvironmentInfo,
    HazardEntry,
    HazardSummary,
    InteractionEntry,
    ReasoningExplanation,
    ReasoningResult,
    ReasoningSnapshot,
    ReasoningState,
    RiskLevel,
    SituationCategory,
    TtcBand,
    UncertaintyInfo,
    UncertaintyLevel,
    WorldCompletenessLevel,
    RiskSummary,
)
from .hazard_analyzer import HazardAnalyzer
from .hazard_prioritizer import HazardPrioritizer
from .interaction_analyzer import InteractionAnalyzer
from .complexity_analyzer import ComplexityAnalyzer
from .situation_assessor import SituationAssessor

__all__ = ["ReasoningEngine"]


class ReasoningEngine:
    """
    Phase 8.1 Situation Assessment & Risk Reasoning Engine.

    Consumes a Phase 7 WorldModelSnapshot and produces a ReasoningSnapshot
    that answers:
      «"What is happening around the vehicle right now, how complex is the
        situation, what hazards matter most, and what level of attention
        is required?"»

    Deterministic: same WorldModelSnapshot → same ReasoningSnapshot.
    Stateless: no internal mutable state between assess() calls.
    """

    def __init__(
        self,
        config: Optional[ReasoningConfig] = None,
        config_path: Optional[str] = None,
    ) -> None:
        if config is not None:
            self._cfg = config
        else:
            self._cfg = load_reasoning_config(config_path)

        # Sub-components — all stateless
        self._hazard_analyzer = HazardAnalyzer(self._cfg)
        self._hazard_prioritizer = HazardPrioritizer(self._cfg)
        self._interaction_analyzer = InteractionAnalyzer(self._cfg)
        self._complexity_analyzer = ComplexityAnalyzer(self._cfg)
        self._situation_assessor = SituationAssessor(self._cfg)

    # ------------------------------------------------------------------
    # Primary API
    # ------------------------------------------------------------------

    def assess(self, snapshot: WorldModelSnapshot) -> ReasoningResult:
        """
        Assess the world model snapshot and return a ReasoningResult.

        Always returns a valid result — never raises on degraded input.
        Repeated calls with identical input produce identical output.

        Parameters
        ----------
        snapshot : WorldModelSnapshot
            The Phase 7 world model snapshot for the current cycle.

        Returns
        -------
        ReasoningResult
            Contains the ReasoningSnapshot plus assessment metadata.
        """
        t_start = time.perf_counter()
        warnings: List[str] = []
        errors: List[str] = []

        try:
            reasoning_snapshot = self._run_pipeline(snapshot, warnings)
            status = "degraded" if reasoning_snapshot.reasoning_state == ReasoningState.DEGRADED else "ok"
        except Exception as exc:  # pragma: no cover
            errors.append(f"REASONING_ERROR: {exc!r}")
            reasoning_snapshot = self._empty_snapshot(snapshot)
            status = "error"

        duration = time.perf_counter() - t_start

        return ReasoningResult(
            snapshot=reasoning_snapshot,
            assessment_status=status,
            assessment_warnings=warnings,
            assessment_errors=errors,
            assessment_duration_s=round(duration, 6),
        )

    # ------------------------------------------------------------------
    # Internal pipeline
    # ------------------------------------------------------------------

    def _run_pipeline(
        self,
        snapshot: WorldModelSnapshot,
        warnings: List[str],
    ) -> ReasoningSnapshot:
        """Execute the full reasoning pipeline."""
        cfg = self._cfg

        # === Step 1: Degraded mode check ===
        unc_info, world_complete = self._assess_uncertainty(snapshot, warnings)
        is_degraded = snapshot.status in (WorldModelStatus.EMPTY, WorldModelStatus.INVALID)

        if is_degraded:
            snap = self._degraded_snapshot(snapshot, unc_info, world_complete)
            return snap

        # === Step 2: Extract environment ===
        env = self._situation_assessor.extract_environment(snapshot)

        # === Step 3: Extract hazards ===
        raw_hazards = self._hazard_analyzer.extract(snapshot)

        # === Step 4: Prioritize hazards ===
        hazards = self._hazard_prioritizer.prioritize(raw_hazards)

        # === Step 5: Build hazard summary ===
        hazard_summary = self._situation_assessor.build_hazard_summary(hazards)

        # === Step 6: Analyze interactions ===
        interactions = self._interaction_analyzer.analyze(hazards, snapshot)

        # === Step 7: Assess complexity ===
        complexity = self._complexity_analyzer.assess(snapshot, hazards, env)

        # === Step 8: Classify situation ===
        situation = self._situation_assessor.classify(
            snapshot, hazards, env, complexity
        )

        # === Step 9: Build risk summary ===
        risk = self._build_risk_summary(hazards, hazard_summary, unc_info)

        # === Step 10: Determine reasoning state ===
        reasoning_state = self._determine_reasoning_state(
            hazard_summary, risk, complexity, unc_info, snapshot
        )

        # === Step 11: Build explanation ===
        explanation = self._build_explanation(
            reasoning_state, situation, complexity, risk, hazards, unc_info
        )

        # === Step 12: Confidence ===
        reasoning_conf = self._estimate_reasoning_confidence(
            snapshot, hazards, unc_info
        )

        return ReasoningSnapshot(
            timestamp=snapshot.timestamp,
            frame_id=snapshot.frame_id,
            reasoning_state=reasoning_state,
            situation=situation,
            environment=env,
            hazards=hazard_summary,
            _interactions=tuple(interactions),
            risk=risk,
            complexity=complexity,
            uncertainty_info=unc_info,
            explanation=explanation,
            reasoning_confidence=round(reasoning_conf, 3),
        )

    # ------------------------------------------------------------------
    # Uncertainty assessment
    # ------------------------------------------------------------------

    def _assess_uncertainty(
        self,
        snapshot: WorldModelSnapshot,
        warnings: List[str],
    ) -> tuple:
        dq = snapshot.data_quality
        cfg = self._cfg

        missing: List[str] = []
        degraded: List[str] = []

        def _check(status, name: str):
            if status == InputModuleStatus.UNAVAILABLE:
                missing.append(name)
            elif status in (InputModuleStatus.DEGRADED, InputModuleStatus.INVALID):
                degraded.append(name)

        _check(dq.perception_status,        "PERCEPTION")
        _check(dq.fusion_status,            "FUSION")
        _check(dq.prediction_status,        "PREDICTION")
        _check(dq.memory_status,            "MEMORY")
        _check(dq.road_understanding_status, "ROAD_UNDERSTANDING")
        _check(dq.indian_context_status,    "INDIAN_CONTEXT")

        if missing:
            warnings.append(f"MISSING_MODULES: {missing}")
        if degraded:
            warnings.append(f"DEGRADED_MODULES: {degraded}")

        unc = dq.overall_uncertainty
        unc_level = self._classify_uncertainty(unc, cfg)

        # Completeness
        completeness = dq.completeness
        if completeness >= cfg.completeness_full_threshold:
            world_complete = WorldCompletenessLevel.FULL
        elif completeness >= cfg.completeness_partial_threshold:
            world_complete = WorldCompletenessLevel.PARTIAL
        elif completeness > 0.0:
            world_complete = WorldCompletenessLevel.MINIMAL
        else:
            world_complete = WorldCompletenessLevel.EMPTY

        stale = dq.freshness < 0.5
        sensor_deg = dq.perception_status in (
            InputModuleStatus.DEGRADED, InputModuleStatus.INVALID
        )
        pred_unavail = dq.prediction_status == InputModuleStatus.UNAVAILABLE
        road_unavail = dq.road_understanding_status == InputModuleStatus.UNAVAILABLE

        unc_info = UncertaintyInfo(
            overall_uncertainty=round(unc, 3),
            world_completeness=world_complete,
            missing_modules=missing,
            degraded_modules=degraded,
            stale_data_present=stale,
            sensor_degradation=sensor_deg,
            prediction_unavailable=pred_unavail,
            road_info_unavailable=road_unavail,
        )
        return unc_info, world_complete

    @staticmethod
    def _classify_uncertainty(unc: float, cfg: ReasoningConfig) -> UncertaintyLevel:
        if unc >= cfg.uncertainty_very_high_threshold:
            return UncertaintyLevel.VERY_HIGH
        if unc >= cfg.uncertainty_high_threshold:
            return UncertaintyLevel.HIGH
        if unc >= 0.3:
            return UncertaintyLevel.MEDIUM
        return UncertaintyLevel.LOW

    # ------------------------------------------------------------------
    # Risk summary
    # ------------------------------------------------------------------

    def _build_risk_summary(
        self,
        hazards: List[HazardEntry],
        hazard_summary: HazardSummary,
        unc_info: UncertaintyInfo,
    ) -> RiskSummary:
        cfg = self._cfg
        codes: List[str] = []

        # Determine max hazard risk
        risk_order = {
            RiskLevel.CRITICAL: 4,
            RiskLevel.HIGH:     3,
            RiskLevel.MEDIUM:   2,
            RiskLevel.LOW:      1,
            RiskLevel.UNKNOWN:  0,
        }
        max_risk = RiskLevel.UNKNOWN
        for h in hazards:
            if risk_order.get(h.risk_level, 0) > risk_order.get(max_risk, 0):
                max_risk = h.risk_level

        # Collision threat
        collision_threat = hazard_summary.critical_hazards > 0 or any(
            h.predicted_conflict for h in hazards
        )
        if collision_threat:
            codes.append("COLLISION_THREAT_PRESENT")

        # Time criticality
        time_crit = TtcBand.UNAVAILABLE
        for h in hazards:
            band_order = {
                TtcBand.IMMEDIATE:    5,
                TtcBand.NEAR_TERM:    4,
                TtcBand.MODERATE:     3,
                TtcBand.DISTANT:      2,
                TtcBand.UNAVAILABLE:  1,
                TtcBand.NO_COLLISION: 0,
            }
            if band_order.get(h.ttc_band, 0) > band_order.get(time_crit, 0):
                time_crit = h.ttc_band
        if time_crit in (TtcBand.IMMEDIATE, TtcBand.NEAR_TERM):
            codes.append(f"TIME_CRITICAL_{time_crit.value}")

        # Uncertainty level
        unc_level = self._classify_uncertainty(unc_info.overall_uncertainty, cfg)
        if unc_level in (UncertaintyLevel.HIGH, UncertaintyLevel.VERY_HIGH):
            codes.append(f"UNCERTAINTY_{unc_level.value}")

        # Overall risk = max(hazard risk, uncertainty penalty)
        overall = max_risk
        if max_risk == RiskLevel.UNKNOWN and unc_info.overall_uncertainty > 0.7:
            # High uncertainty without clear risk ≠ zero risk
            overall = RiskLevel.LOW
            codes.append("RISK_UNCERTAIN_ELEVATED_TO_LOW")

        return RiskSummary(
            overall_risk_level=overall,
            max_hazard_risk=max_risk,
            collision_threat_present=collision_threat,
            time_criticality=time_crit,
            uncertainty_level=unc_level,
            reason_codes=codes[: cfg.max_reason_codes],
        )

    # ------------------------------------------------------------------
    # Reasoning state determination
    # ------------------------------------------------------------------

    def _determine_reasoning_state(
        self,
        hazard_summary: HazardSummary,
        risk: RiskSummary,
        complexity,
        unc_info: UncertaintyInfo,
        snapshot: WorldModelSnapshot,
    ) -> ReasoningState:
        cfg = self._cfg

        # Degraded world model
        if snapshot.status == WorldModelStatus.DEGRADED:
            return ReasoningState.DEGRADED

        # Critical: immediate TTC or critical hazard
        if (
            hazard_summary.critical_hazards > 0
            or risk.time_criticality == TtcBand.IMMEDIATE
            or risk.collision_threat_present
        ):
            return ReasoningState.CRITICAL

        # High risk: high-risk hazard count at threshold or near TTC
        if (
            hazard_summary.high_risk_hazards >= cfg.high_risk_min_count
            or risk.time_criticality == TtcBand.NEAR_TERM
            or risk.overall_risk_level == RiskLevel.HIGH
        ):
            return ReasoningState.HIGH_RISK

        # Caution: moderate hazard count or high complexity
        if (
            hazard_summary.total_hazards >= cfg.caution_hazard_count
            or complexity.complexity_level in (ComplexityLevel.HIGH, ComplexityLevel.VERY_HIGH)
            or risk.overall_risk_level == RiskLevel.MEDIUM
        ):
            return ReasoningState.CAUTION

        # Attention: any hazard present
        if hazard_summary.total_hazards >= cfg.attention_hazard_count:
            return ReasoningState.ATTENTION

        # Unknown: very high uncertainty with empty world
        if unc_info.overall_uncertainty > cfg.uncertainty_very_high_threshold:
            return ReasoningState.UNKNOWN

        return ReasoningState.NORMAL

    # ------------------------------------------------------------------
    # Explanation
    # ------------------------------------------------------------------

    def _build_explanation(
        self,
        state: ReasoningState,
        situation,
        complexity,
        risk: RiskSummary,
        hazards: List[HazardEntry],
        unc_info: UncertaintyInfo,
    ) -> ReasoningExplanation:
        cfg = self._cfg

        state_codes: List[str] = [f"STATE_{state.value}"]
        if state == ReasoningState.CRITICAL:
            state_codes.append("CRITICAL_THREAT_DETECTED")
        if unc_info.missing_modules:
            state_codes.append(f"MISSING_{len(unc_info.missing_modules)}_MODULES")
        if unc_info.stale_data_present:
            state_codes.append("STALE_DATA")
        state_codes += risk.reason_codes[:3]

        sit_codes = list(situation.contributing_factors[:cfg.max_reason_codes])
        cpx_codes = list(complexity.contributing_factors[:cfg.max_reason_codes])

        # Contributors
        contributors: dict = {}
        if complexity.complexity_level in (ComplexityLevel.HIGH, ComplexityLevel.VERY_HIGH):
            contributors["road_complexity"] = "high"
        elif complexity.complexity_level == ComplexityLevel.MEDIUM:
            contributors["road_complexity"] = "medium"
        else:
            contributors["road_complexity"] = "low"

        vru_count = sum(1 for h in hazards if h.is_vulnerable)
        if vru_count >= 2:
            contributors["vulnerable_road_users"] = "high"
        elif vru_count == 1:
            contributors["vulnerable_road_users"] = "medium"

        if risk.collision_threat_present:
            contributors["collision_threat"] = "high"

        if unc_info.overall_uncertainty > 0.6:
            contributors["uncertainty"] = "high"
        elif unc_info.overall_uncertainty > 0.3:
            contributors["uncertainty"] = "medium"

        td = situation.situation_category
        if td in (SituationCategory.DENSE_TRAFFIC, SituationCategory.COMPOUND_HAZARD):
            contributors["traffic_density"] = "high"

        return ReasoningExplanation(
            state_reason_codes=state_codes[: cfg.max_reason_codes],
            situation_reason_codes=sit_codes,
            complexity_reason_codes=cpx_codes,
            contributors=contributors,
        )

    # ------------------------------------------------------------------
    # Confidence
    # ------------------------------------------------------------------

    def _estimate_reasoning_confidence(
        self,
        snapshot: WorldModelSnapshot,
        hazards: List[HazardEntry],
        unc_info: UncertaintyInfo,
    ) -> float:
        """Estimate overall confidence in the reasoning output."""
        wm_conf = snapshot.data_quality.overall_confidence
        completeness_bonus = snapshot.data_quality.completeness * 0.2
        uncertainty_penalty = unc_info.overall_uncertainty * 0.3
        return max(0.0, min(1.0, wm_conf + completeness_bonus - uncertainty_penalty))

    # ------------------------------------------------------------------
    # Degraded snapshots
    # ------------------------------------------------------------------

    def _degraded_snapshot(
        self,
        snapshot: WorldModelSnapshot,
        unc_info: UncertaintyInfo,
        world_complete: WorldCompletenessLevel,
    ) -> ReasoningSnapshot:
        """Produce a minimal valid snapshot for a degraded world model."""
        from .reasoning_types import (
            SituationInfo, EnvironmentInfo, HazardSummary, RiskSummary,
            ComplexityInfo, ReasoningExplanation, SituationCategory,
        )
        sit = SituationInfo(
            timestamp=snapshot.timestamp,
            frame_id=snapshot.frame_id,
            situation_category=SituationCategory.DEGRADED_ENVIRONMENT,
            situation_subcategory="WORLD_MODEL_DEGRADED",
            situation_confidence=0.0,
            situation_uncertainty=1.0,
            contributing_factors=["WORLD_MODEL_EMPTY_OR_INVALID"],
        )
        risk = RiskSummary(
            overall_risk_level=RiskLevel.UNKNOWN,
            max_hazard_risk=RiskLevel.UNKNOWN,
            uncertainty_level=UncertaintyLevel.VERY_HIGH,
            reason_codes=["WORLD_MODEL_UNAVAILABLE"],
        )
        exp = ReasoningExplanation(
            state_reason_codes=["DEGRADED_WORLD_MODEL", f"WM_STATUS_{snapshot.status.value}"],
            situation_reason_codes=["WORLD_MODEL_EMPTY_OR_INVALID"],
            complexity_reason_codes=["CANNOT_ASSESS"],
            contributors={"world_model_availability": "unavailable"},
        )
        return ReasoningSnapshot(
            timestamp=snapshot.timestamp,
            frame_id=snapshot.frame_id,
            reasoning_state=ReasoningState.DEGRADED,
            situation=sit,
            environment=EnvironmentInfo(),
            hazards=HazardSummary(),
            _interactions=tuple(),
            risk=risk,
            complexity=ComplexityInfo(
                complexity_level=ComplexityLevel.UNKNOWN,
                confidence=0.0,
                uncertainty=1.0,
            ),
            uncertainty_info=unc_info,
            explanation=exp,
            reasoning_confidence=0.0,
        )

    def _empty_snapshot(self, snapshot: WorldModelSnapshot) -> ReasoningSnapshot:
        """Fallback snapshot for unexpected errors."""
        from .reasoning_types import (
            SituationInfo, EnvironmentInfo, HazardSummary, RiskSummary,
            ComplexityInfo, ReasoningExplanation, UncertaintyInfo,
            SituationCategory,
        )
        return ReasoningSnapshot(
            timestamp=snapshot.timestamp if snapshot else 0.0,
            frame_id=snapshot.frame_id if snapshot else 0,
            reasoning_state=ReasoningState.UNKNOWN,
            situation=SituationInfo(situation_category=SituationCategory.UNKNOWN),
            environment=EnvironmentInfo(),
            hazards=HazardSummary(),
            _interactions=tuple(),
            risk=RiskSummary(
                overall_risk_level=RiskLevel.UNKNOWN,
                uncertainty_level=UncertaintyLevel.VERY_HIGH,
            ),
            complexity=ComplexityInfo(
                complexity_level=ComplexityLevel.UNKNOWN,
                confidence=0.0,
                uncertainty=1.0,
            ),
            uncertainty_info=UncertaintyInfo(
                overall_uncertainty=1.0,
                world_completeness=WorldCompletenessLevel.EMPTY,
            ),
            explanation=ReasoningExplanation(
                state_reason_codes=["ASSESSMENT_ERROR"],
            ),
            reasoning_confidence=0.0,
        )
