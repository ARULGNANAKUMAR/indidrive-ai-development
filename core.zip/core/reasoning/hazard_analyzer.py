"""
IndiDrive AI — Phase 8.1 | Hazard Extraction
=============================================
Reads hazard information directly from the Phase 7 World Model.

Design rules:
  * Consumes only the WorldModelSnapshot public interface
  * Does NOT invent hazards not present in the World Model
  * Does NOT create new detection — only interprets existing data
  * Deterministic: same input → identical output
  * No LLM, no neural network, no cloud
"""
from __future__ import annotations

from typing import List, Optional

from core.world_model.world_model_types import (
    WorldModelSnapshot,
    WorldObject,
    WorldAnomalySummary,
    NOT_AVAILABLE,
)
from .reasoning_config import ReasoningConfig
from .reasoning_types import (
    HazardCategory,
    HazardEntry,
    TtcBand,
    RiskLevel,
)

__all__ = [
    "HazardAnalyzer",
]

# ---------------------------------------------------------------------------
# Object type → HazardCategory mapping
# Derived from WorldObject.object_type / object_subtype strings
# ---------------------------------------------------------------------------

_TYPE_TO_CATEGORY: dict = {
    "PEDESTRIAN": HazardCategory.PEDESTRIAN,
    "CYCLIST":    HazardCategory.CYCLIST,
    "BICYCLE":    HazardCategory.CYCLIST,
    "MOTORCYCLE": HazardCategory.MOTORCYCLE,
    "SCOOTER":    HazardCategory.SCOOTER,
    "AUTO":       HazardCategory.AUTO_RICKSHAW,
    "AUTO_RICKSHAW": HazardCategory.AUTO_RICKSHAW,
    "CAR":        HazardCategory.CAR,
    "VEHICLE":    HazardCategory.CAR,
    "BUS":        HazardCategory.BUS,
    "TRUCK":      HazardCategory.TRUCK,
    "TRACTOR":    HazardCategory.TRACTOR,
    "CATTLE":     HazardCategory.CATTLE,
    "COW":        HazardCategory.CATTLE,
    "ANIMAL":     HazardCategory.CATTLE,
    "PUSHCART":   HazardCategory.PUSHCART,
    "CART":       HazardCategory.PUSHCART,
}

_ANOMALY_TO_CATEGORY: dict = {
    "POTHOLE":      HazardCategory.POTHOLE,
    "DEBRIS":       HazardCategory.DEBRIS,
    "CONSTRUCTION": HazardCategory.CONSTRUCTION,
    "OBSTACLE":     HazardCategory.ROAD_OBSTACLE,
    "ROAD_DAMAGE":  HazardCategory.POTHOLE,
    "FLOODING":     HazardCategory.ROAD_OBSTACLE,
    "SPEED_BUMP":   HazardCategory.ROAD_OBSTACLE,
    "CRACK":        HazardCategory.POTHOLE,
}

_RISK_MAP = {
    "CRITICAL": RiskLevel.CRITICAL,
    "HIGH":     RiskLevel.HIGH,
    "MEDIUM":   RiskLevel.MEDIUM,
    "LOW":      RiskLevel.LOW,
}

_TTC_STATUS_NO_COLLISION = "NO_COLLISION"


class HazardAnalyzer:
    """
    Extracts prioritised hazard entries from a WorldModelSnapshot.

    Does NOT create detection.  Does NOT invent hazards.
    Only interprets what the World Model already contains.
    """

    def __init__(self, config: ReasoningConfig) -> None:
        self._cfg = config

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def extract(self, snapshot: WorldModelSnapshot) -> List[HazardEntry]:
        """
        Extract and return a bounded list of HazardEntry objects from
        the world model snapshot, sorted by priority descending.

        Returns an empty list if the snapshot contains no hazardous objects.
        """
        entries: List[HazardEntry] = []

        # 1. Dynamic objects (WorldObject entries)
        for obj in snapshot.objects:
            entry = self._object_to_hazard(obj)
            if entry is not None:
                entries.append(entry)

        # 2. Road anomalies
        for anomaly in snapshot.road.anomalies:
            entry = self._anomaly_to_hazard(anomaly)
            if entry is not None:
                entries.append(entry)

        # 3. Wrong-side traffic indicator from Indian context
        if self._has_wrong_side_traffic(snapshot):
            entry = self._make_wrong_side_entry(snapshot)
            entries.append(entry)

        # Bound the list
        entries = entries[: self._cfg.max_hazards]

        return entries

    # ------------------------------------------------------------------
    # Object extraction
    # ------------------------------------------------------------------

    def _object_to_hazard(self, obj: WorldObject) -> Optional[HazardEntry]:
        """
        Convert one WorldObject to a HazardEntry.
        Returns None if the object is not relevant (removed, no ID, etc.).
        """
        from core.world_model.world_model_types import WorldObjectLifecycle
        if obj.lifecycle == WorldObjectLifecycle.REMOVED:
            return None

        hazard_id = obj.primary_id() or NOT_AVAILABLE
        category = self._classify_object(obj)
        risk_level = _RISK_MAP.get(obj.collision.risk_level, RiskLevel.UNKNOWN)
        ttc_band = self._classify_ttc(obj)
        distance_m = obj.position.distance_m if obj.position.distance_m is not None else None
        is_vulnerable = self._is_vulnerable(obj)
        is_unusual = self._is_unusual(obj)
        reason_codes = self._object_reason_codes(obj, category, ttc_band, is_vulnerable)

        return HazardEntry(
            hazard_id=hazard_id,
            hazard_category=category,
            risk_level=risk_level,
            ttc_band=ttc_band,
            ttc_s=obj.collision.ttc_s,
            distance_m=distance_m,
            closing_speed_ms=obj.collision.closing_speed_ms,
            collision_likelihood=obj.collision.collision_likelihood,
            predicted_conflict=obj.collision.predicted_conflict,
            is_moving=obj.motion.is_moving,
            is_vulnerable=is_vulnerable,
            priority_score=0.0,  # filled by hazard_prioritizer
            confidence=obj.quality.object_confidence,
            uncertainty=1.0 - obj.quality.object_confidence,
            reason_codes=reason_codes[: self._cfg.max_reason_codes],
        )

    def _classify_object(self, obj: WorldObject) -> HazardCategory:
        """Map object_type / object_subtype to HazardCategory."""
        # Try subtype first (more specific)
        if obj.object_subtype and obj.object_subtype != NOT_AVAILABLE:
            cat = _TYPE_TO_CATEGORY.get(obj.object_subtype.upper())
            if cat is not None:
                return cat
        # Fall back to type
        if obj.object_type and obj.object_type != NOT_AVAILABLE:
            cat = _TYPE_TO_CATEGORY.get(obj.object_type.upper())
            if cat is not None:
                return cat
        return HazardCategory.UNKNOWN

    def _classify_ttc(self, obj: WorldObject) -> TtcBand:
        """Classify TTC into a qualitative band using config thresholds."""
        status = obj.collision.ttc_status
        if status == _TTC_STATUS_NO_COLLISION:
            return TtcBand.NO_COLLISION
        if status == NOT_AVAILABLE:
            return TtcBand.UNAVAILABLE

        ttc = obj.collision.ttc_s
        if ttc is None:
            return TtcBand.UNAVAILABLE
        if ttc <= self._cfg.ttc_immediate_s:
            return TtcBand.IMMEDIATE
        if ttc <= self._cfg.ttc_near_s:
            return TtcBand.NEAR_TERM
        if ttc <= self._cfg.ttc_moderate_s:
            return TtcBand.MODERATE
        return TtcBand.DISTANT

    def _is_vulnerable(self, obj: WorldObject) -> bool:
        """Return True for vulnerable road user categories."""
        for t in (obj.object_subtype, obj.object_type):
            if t and t.upper() in self._cfg.vulnerable_object_types:
                return True
        return False

    def _is_unusual(self, obj: WorldObject) -> bool:
        """Return True for unusual traffic participants."""
        for t in (obj.object_subtype, obj.object_type):
            if t and t.upper() in self._cfg.unusual_participant_types:
                return True
        return False

    def _object_reason_codes(
        self,
        obj: WorldObject,
        category: HazardCategory,
        ttc_band: TtcBand,
        is_vulnerable: bool,
    ) -> List[str]:
        codes: List[str] = []
        rl = obj.collision.risk_level
        if rl in ("CRITICAL", "HIGH"):
            codes.append(f"RISK_{rl}")
        if ttc_band == TtcBand.IMMEDIATE:
            codes.append("TTC_IMMEDIATE")
        elif ttc_band == TtcBand.NEAR_TERM:
            codes.append("TTC_NEAR_TERM")
        if obj.collision.predicted_conflict:
            codes.append("PREDICTED_CONFLICT")
        if is_vulnerable:
            codes.append("VULNERABLE_ROAD_USER")
        if category == HazardCategory.CATTLE:
            codes.append("CATTLE_PRESENT")
        if obj.quality.is_stale:
            codes.append("STALE_OBJECT")
        if obj.quality.is_degraded:
            codes.append("DEGRADED_OBJECT")
        if obj.collision.collision_likelihood is not None and obj.collision.collision_likelihood > 0.5:
            codes.append("HIGH_COLLISION_LIKELIHOOD")
        return codes

    # ------------------------------------------------------------------
    # Anomaly extraction
    # ------------------------------------------------------------------

    def _anomaly_to_hazard(self, anomaly: WorldAnomalySummary) -> Optional[HazardEntry]:
        """Convert a road anomaly to a HazardEntry."""
        atype = anomaly.anomaly_type.upper() if anomaly.anomaly_type != NOT_AVAILABLE else ""
        category = _ANOMALY_TO_CATEGORY.get(atype, HazardCategory.ROAD_OBSTACLE)

        # Only include anomalies in or near drivable area
        if not (anomaly.in_drivable_area or anomaly.in_lane_corridor):
            if anomaly.severity not in ("CRITICAL", "SEVERE"):
                return None

        sev_to_risk = {
            "CRITICAL": RiskLevel.CRITICAL,
            "SEVERE":   RiskLevel.HIGH,
            "MODERATE": RiskLevel.MEDIUM,
            "MINOR":    RiskLevel.LOW,
        }
        risk_level = sev_to_risk.get(anomaly.severity, RiskLevel.UNKNOWN)

        reason_codes: List[str] = []
        if anomaly.in_drivable_area:
            reason_codes.append("ANOMALY_IN_DRIVABLE_AREA")
        if anomaly.in_lane_corridor:
            reason_codes.append("ANOMALY_IN_LANE")
        if anomaly.drivability_impact in ("HIGH", "BLOCKING"):
            reason_codes.append(f"DRIVABILITY_{anomaly.drivability_impact}")
        if anomaly.severity in ("CRITICAL", "SEVERE"):
            reason_codes.append(f"SEVERITY_{anomaly.severity}")

        return HazardEntry(
            hazard_id=anomaly.anomaly_id,
            hazard_category=category,
            risk_level=risk_level,
            ttc_band=TtcBand.UNAVAILABLE,  # road anomalies have no TTC
            ttc_s=None,
            distance_m=None,  # position available but no Euclidean distance precomputed
            closing_speed_ms=None,
            collision_likelihood=None,
            predicted_conflict=False,
            is_moving=False,
            is_vulnerable=False,
            priority_score=0.0,
            confidence=anomaly.confidence,
            uncertainty=anomaly.uncertainty,
            reason_codes=reason_codes[: self._cfg.max_reason_codes],
        )

    # ------------------------------------------------------------------
    # Wrong-side traffic
    # ------------------------------------------------------------------

    def _has_wrong_side_traffic(self, snapshot: WorldModelSnapshot) -> bool:
        """Check Indian context for wrong-side traffic indicator."""
        ctx = snapshot.indian_context
        if not ctx.available:
            return False
        for indicator in ctx.unusual_road_indicators:
            if "WRONG" in indicator.upper() or "ONCOMING" in indicator.upper():
                return True
        return False

    def _make_wrong_side_entry(self, snapshot: WorldModelSnapshot) -> HazardEntry:
        ctx = snapshot.indian_context
        return HazardEntry(
            hazard_id="wrong_side_traffic",
            hazard_category=HazardCategory.WRONG_SIDE_TRAFFIC,
            risk_level=RiskLevel.HIGH,
            ttc_band=TtcBand.UNAVAILABLE,
            is_moving=True,
            is_vulnerable=False,
            priority_score=0.0,
            confidence=ctx.context_confidence,
            uncertainty=ctx.context_uncertainty,
            reason_codes=["WRONG_SIDE_TRAFFIC_DETECTED"],
        )
