"""
IndiDrive AI — Phase 8.1 | Situation Assessment
================================================
Extracts environment state and classifies the current driving situation.

Reads from the Phase 7 World Model.
Produces SituationInfo, EnvironmentInfo, and HazardSummary.

Handles Indian-road scenarios:
  - Village road (unmarked, narrow, cattle, mixed traffic)
  - Dense market (pedestrians, autos, roadside activity)
  - Highway (higher speeds, lane structure, merge context)
  - Cattle crossing (unpredictable trajectory)
  - Wrong-side traffic (abnormal conflict)
  - Narrow damaged road (compound hazard)

Does NOT check a scenario name and assign a fixed result.
All classification is derived from actual World Model data.
"""
from __future__ import annotations

from typing import List, Optional, Tuple

from core.world_model.world_model_types import (
    WorldModelSnapshot,
    WorldModelStatus,
    NOT_AVAILABLE,
)
from .reasoning_config import ReasoningConfig
from .reasoning_types import (
    ComplexityInfo,
    EnvironmentInfo,
    HazardCategory,
    HazardEntry,
    HazardSummary,
    RiskLevel,
    SituationCategory,
    SituationInfo,
)

__all__ = ["SituationAssessor"]


class SituationAssessor:
    """
    Extracts and classifies the current driving situation from the
    Phase 7 World Model.
    """

    def __init__(self, config: ReasoningConfig) -> None:
        self._cfg = config

    # ------------------------------------------------------------------
    # Environment extraction
    # ------------------------------------------------------------------

    def extract_environment(self, snapshot: WorldModelSnapshot) -> EnvironmentInfo:
        """Build EnvironmentInfo from the World Model snapshot."""
        road = snapshot.road
        ctx = snapshot.indian_context

        road_type = ctx.road_type if ctx.available else NOT_AVAILABLE
        traffic_density = ctx.traffic_density if ctx.available else NOT_AVAILABLE
        traffic_mix = ctx.traffic_mix if ctx.available else NOT_AVAILABLE
        road_complexity = ctx.road_complexity if ctx.available else NOT_AVAILABLE
        has_cattle = ctx.cattle_present if ctx.available else False
        has_vru = ctx.vulnerable_road_users if ctx.available else False
        has_roadside = ctx.market_like_activity if ctx.available else False
        unusual_indicators = list(ctx.unusual_road_indicators) if ctx.available else []

        # Road structure
        lane_info = road.lane_info
        lane_state = lane_info.marking_state if lane_info.available else NOT_AVAILABLE
        road_structure = lane_info.road_direction if lane_info.available else NOT_AVAILABLE
        is_intersection = (
            lane_info.intersection_state == "INTERSECTION" if lane_info.available else False
        )
        is_unmarked = lane_state in ("UNMARKED",) if lane_state != NOT_AVAILABLE else False

        # Drivable width
        ds = road.drivable_space
        width_m: Optional[float] = None
        is_narrow = False
        if ds.available and ds.road_width_m is not None:
            width_m = ds.road_width_m
            is_narrow = width_m < self._cfg.narrow_road_width_m

        # Wrong-side traffic from unusual indicators
        has_wrong_side = any(
            "WRONG" in ind.upper() or "ONCOMING" in ind.upper()
            for ind in unusual_indicators
        )

        # Visibility — approximate from dq
        vis_state = NOT_AVAILABLE
        if snapshot.data_quality.freshness < 0.3:
            vis_state = "DEGRADED"
        elif snapshot.data_quality.freshness >= 0.7:
            vis_state = "CLEAR"
        else:
            vis_state = "PARTIAL"

        return EnvironmentInfo(
            road_type=road_type,
            road_structure=road_structure,
            lane_state=lane_state,
            traffic_density=traffic_density,
            traffic_mix=traffic_mix,
            road_complexity=road_complexity,
            visibility_state=vis_state,
            available_drivable_width_m=width_m,
            is_narrow_road=is_narrow,
            is_intersection=is_intersection,
            is_unmarked=is_unmarked,
            has_roadside_activity=has_roadside,
            has_cattle=has_cattle,
            has_vru=has_vru,
            has_wrong_side_traffic=has_wrong_side,
        )

    # ------------------------------------------------------------------
    # Hazard summary
    # ------------------------------------------------------------------

    def build_hazard_summary(self, hazards: List[HazardEntry]) -> HazardSummary:
        """Aggregate hazard counts and top-priority list from the hazard list."""
        cfg = self._cfg

        total = len(hazards)
        critical = sum(1 for h in hazards if h.risk_level == RiskLevel.CRITICAL)
        high_risk = sum(1 for h in hazards if h.risk_level == RiskLevel.HIGH)
        active = sum(1 for h in hazards if h.is_moving or h.predicted_conflict)
        predicted = sum(1 for h in hazards if h.predicted_conflict)
        road_haz = sum(
            1 for h in hazards
            if h.hazard_category in (
                HazardCategory.POTHOLE,
                HazardCategory.DEBRIS,
                HazardCategory.CONSTRUCTION,
                HazardCategory.ROAD_OBSTACLE,
            )
        )
        vru = sum(1 for h in hazards if h.is_vulnerable)
        unusual = sum(
            1 for h in hazards
            if h.hazard_category in (
                HazardCategory.CATTLE,
                HazardCategory.PUSHCART,
                HazardCategory.TRACTOR,
                HazardCategory.AUTO_RICKSHAW,
                HazardCategory.WRONG_SIDE_TRAFFIC,
            )
        )

        top = hazards[: cfg.max_top_hazards]

        return HazardSummary(
            total_hazards=total,
            critical_hazards=critical,
            high_risk_hazards=high_risk,
            active_hazards=active,
            predicted_hazards=predicted,
            road_hazards=road_haz,
            vulnerable_road_users=vru,
            unusual_participants=unusual,
            top_hazards=list(top),
        )

    # ------------------------------------------------------------------
    # Situation classification
    # ------------------------------------------------------------------

    def classify(
        self,
        snapshot: WorldModelSnapshot,
        hazards: List[HazardEntry],
        env: EnvironmentInfo,
        complexity: ComplexityInfo,
    ) -> SituationInfo:
        """
        Classify the current driving situation.

        Classification is derived from actual World Model data — NOT
        from hard-coded scenario names.
        """
        category, subcategory, factors = self._classify_category(
            snapshot, hazards, env, complexity
        )

        confidence = self._estimate_confidence(snapshot, hazards)
        uncertainty = snapshot.data_quality.overall_uncertainty

        return SituationInfo(
            timestamp=snapshot.timestamp,
            frame_id=snapshot.frame_id,
            situation_category=category,
            situation_subcategory=subcategory,
            situation_confidence=round(confidence, 3),
            situation_uncertainty=round(uncertainty, 3),
            contributing_factors=factors[: self._cfg.max_reason_codes],
        )

    def _classify_category(
        self,
        snapshot: WorldModelSnapshot,
        hazards: List[HazardEntry],
        env: EnvironmentInfo,
        complexity: ComplexityInfo,
    ) -> Tuple[SituationCategory, str, List[str]]:
        factors: List[str] = []

        # Degraded world → degraded environment
        if snapshot.status in (WorldModelStatus.EMPTY, WorldModelStatus.INVALID):
            return SituationCategory.DEGRADED_ENVIRONMENT, "WORLD_MODEL_UNAVAILABLE", ["WORLD_MODEL_DEGRADED"]

        critical = [h for h in hazards if h.risk_level == RiskLevel.CRITICAL]
        high_risk = [h for h in hazards if h.risk_level in (RiskLevel.HIGH, RiskLevel.CRITICAL)]
        predicted_conflicts = [h for h in hazards if h.predicted_conflict]

        vru_present = env.has_vru or any(h.is_vulnerable for h in hazards)
        cattle_present = env.has_cattle or any(h.hazard_category == HazardCategory.CATTLE for h in hazards)
        road_anomaly_present = any(
            h.hazard_category in (HazardCategory.POTHOLE, HazardCategory.DEBRIS,
                                   HazardCategory.CONSTRUCTION, HazardCategory.ROAD_OBSTACLE)
            for h in hazards
        )
        wrong_side = env.has_wrong_side_traffic

        # Count distinct hazard categories
        categories_present = set(h.hazard_category for h in hazards)

        # Rule: compound hazard — multiple categories, narrow + anomaly + vru
        if (
            len(categories_present) >= self._cfg.compound_min_hazard_types
            and len(hazards) >= self._cfg.compound_min_total_hazards
        ):
            factors.append("COMPOUND_HAZARD_CATEGORIES")
            factors.append(f"DISTINCT_HAZARD_TYPES_{len(categories_present)}")
            return SituationCategory.COMPOUND_HAZARD, "MULTI_CATEGORY_HAZARD", factors

        # Rule: intersection
        if env.is_intersection:
            factors.append("INTERSECTION_DETECTED")
            if len(hazards) >= 2:
                factors.append("HAZARDS_AT_INTERSECTION")
                return SituationCategory.INTERSECTION_COMPLEXITY, "COMPLEX_INTERSECTION", factors
            return SituationCategory.INTERSECTION_COMPLEXITY, "INTERSECTION", factors

        # Rule: trajectory conflict
        if predicted_conflicts:
            factors.append("PREDICTED_TRAJECTORY_CONFLICT")
            return SituationCategory.TRAJECTORY_CONFLICT, "PREDICTED_COLLISION_THREAT", factors

        # Rule: critical object-level hazard
        if critical:
            factors.append(f"CRITICAL_HAZARD_COUNT_{len(critical)}")
            return SituationCategory.COMPOUND_HAZARD, "CRITICAL_HAZARD_PRESENT", factors

        # Rule: vulnerable road user dominant
        if vru_present and not road_anomaly_present:
            factors.append("VRU_DOMINANT")
            if cattle_present:
                factors.append("CATTLE_CROSSING")
                return SituationCategory.VULNERABLE_ROAD_USER, "CATTLE_CROSSING", factors
            return SituationCategory.VULNERABLE_ROAD_USER, "VRU_INTERACTION", factors

        # Rule: road hazard dominant
        if road_anomaly_present and not vru_present:
            factors.append("ROAD_ANOMALY_DOMINANT")
            if env.is_narrow_road:
                factors.append("NARROW_DAMAGED_ROAD")
                return SituationCategory.ROAD_HAZARD, "NARROW_ROAD_WITH_ANOMALY", factors
            return SituationCategory.ROAD_HAZARD, "ROAD_ANOMALY", factors

        # Rule: narrow road
        if env.is_narrow_road:
            factors.append("NARROW_ROAD")
            return SituationCategory.NARROW_ROAD, "NARROW_DRIVABLE_SPACE", factors

        # Rule: unstructured road (unmarked + no lane info)
        if env.is_unmarked:
            factors.append("UNMARKED_ROAD")
            if env.has_roadside_activity:
                factors.append("MARKET_LIKE_ACTIVITY")
                return SituationCategory.UNSTRUCTURED_ROAD, "MARKET_ROAD", factors
            return SituationCategory.UNSTRUCTURED_ROAD, "UNMARKED_VILLAGE_ROAD", factors

        # Rule: dense traffic
        if env.traffic_density in ("HIGH", "VERY_HIGH"):
            factors.append(f"DENSE_TRAFFIC_{env.traffic_density}")
            return SituationCategory.DENSE_TRAFFIC, "HIGH_DENSITY", factors

        # Rule: normal traffic
        if len(hazards) >= self._cfg.attention_hazard_count:
            factors.append("HAZARDS_PRESENT")
            return SituationCategory.NORMAL_TRAFFIC, "STANDARD_TRAFFIC", factors

        # Default: open road
        factors.append("LOW_HAZARD_COUNT")
        return SituationCategory.OPEN_ROAD, "CLEAR_ENVIRONMENT", factors

    def _estimate_confidence(
        self, snapshot: WorldModelSnapshot, hazards: List[HazardEntry]
    ) -> float:
        """Combine world model and hazard confidences."""
        wm_conf = snapshot.data_quality.overall_confidence
        if not hazards:
            return wm_conf
        avg_haz = sum(h.confidence for h in hazards) / len(hazards)
        return round(0.6 * wm_conf + 0.4 * avg_haz, 3)
