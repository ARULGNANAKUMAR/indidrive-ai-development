"""
IndiDrive AI — Phase 8.1 | Road Complexity Assessment
=======================================================
Deterministic, explainable complexity assessment using Phase 6 and Phase 7
information.

Does NOT use ML / black-box models.
All reasoning is factor-based with configured thresholds.
"""
from __future__ import annotations

from typing import List

from core.world_model.world_model_types import WorldModelSnapshot
from .reasoning_config import ReasoningConfig
from .reasoning_types import (
    ComplexityInfo,
    ComplexityLevel,
    EnvironmentInfo,
    HazardEntry,
    HazardCategory,
    NOT_AVAILABLE,
)

__all__ = ["ComplexityAnalyzer"]


class ComplexityAnalyzer:
    """
    Assesses road and situation complexity from the World Model.

    Factors evaluated (deterministic, explainable):
      - road width / narrowness
      - lane marking state (marked vs. unmarked)
      - traffic density
      - traffic mix (heterogeneity)
      - vulnerable road user count
      - road anomaly count and severity
      - intersection context
      - roadside activity
      - visibility degradation
      - unusual road structure indicators
      - total active hazard count
      - uncertainty level
    """

    def __init__(self, config: ReasoningConfig) -> None:
        self._cfg = config

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def assess(
        self,
        snapshot: WorldModelSnapshot,
        hazards: List[HazardEntry],
        env: EnvironmentInfo,
    ) -> ComplexityInfo:
        """
        Produce a ComplexityInfo from the world model snapshot plus
        already-extracted hazard list and environment info.
        """
        factors: List[str] = []
        score: float = 0.0
        cfg = self._cfg

        # 1. Road width / narrowness
        w = snapshot.road.drivable_space.road_width_m
        if w is not None and snapshot.road.drivable_space.available:
            if w < cfg.very_narrow_road_width_m:
                factors.append("VERY_NARROW_ROAD")
                score += 0.50
            elif w < cfg.narrow_road_width_m:
                factors.append("NARROW_ROAD")
                score += 0.25

        # 2. Lane marking state
        marking = snapshot.road.lane_info.marking_state
        if marking in ("UNMARKED", "WEAKLY_MARKED"):
            factors.append("UNMARKED_OR_WEAKLY_MARKED_ROAD")
            score += 0.20 if marking == "UNMARKED" else 0.10

        # 3. Traffic density
        td = snapshot.indian_context.traffic_density
        if td in cfg.complexity_dense_traffic_density:
            factors.append(f"TRAFFIC_DENSITY_{td}")
            score += 0.20
        elif td == "MEDIUM":
            score += 0.05

        # 4. Traffic mix heterogeneity
        ctx = snapshot.indian_context
        if ctx.available:
            unusual_count = sum(
                1 for h in hazards
                if h.hazard_category in (
                    HazardCategory.CATTLE,
                    HazardCategory.PUSHCART,
                    HazardCategory.TRACTOR,
                    HazardCategory.AUTO_RICKSHAW,
                )
            )
            if unusual_count >= 2:
                factors.append("MIXED_TRAFFIC_WITH_UNUSUAL_PARTICIPANTS")
                score += 0.15
            elif unusual_count == 1:
                score += 0.05

        # 5. Vulnerable road users
        vru_count = sum(1 for h in hazards if h.is_vulnerable)
        if vru_count >= 3:
            factors.append("MULTIPLE_VRУС")
            score += 0.15
        elif vru_count >= 1:
            factors.append("VRU_PRESENT")
            score += 0.05

        # 6. Cattle
        if snapshot.indian_context.cattle_present:
            factors.append("CATTLE_PRESENT")
            score += 0.10

        # 7. Road anomaly count
        anomaly_count = snapshot.road.anomaly_count
        if anomaly_count >= 3:
            factors.append("MULTIPLE_ROAD_ANOMALIES")
            score += 0.15
        elif anomaly_count >= 1:
            factors.append("ROAD_ANOMALY_PRESENT")
            score += 0.05
        if snapshot.road.has_critical_anomaly:
            factors.append("CRITICAL_ROAD_ANOMALY")
            score += 0.15

        # 8. Intersection
        lane = snapshot.road.lane_info
        if lane.intersection_state == "INTERSECTION":
            factors.append("INTERSECTION")
            score += 0.15

        # 9. Roadside activity
        if snapshot.indian_context.market_like_activity:
            factors.append("MARKET_LIKE_ROADSIDE_ACTIVITY")
            score += 0.20
        elif snapshot.indian_context.roadside_activity not in (NOT_AVAILABLE, "NONE", "LOW"):
            factors.append("ROADSIDE_ACTIVITY")
            score += 0.05

        # 10. Total active hazard count
        haz_count = len(hazards)
        if haz_count >= cfg.complexity_very_high_hazard_count:
            factors.append(f"VERY_HIGH_HAZARD_COUNT_{haz_count}")
            score += 0.50
        elif haz_count >= cfg.complexity_high_hazard_count:
            factors.append(f"HIGH_HAZARD_COUNT_{haz_count}")
            score += 0.35

        # 11. Unusual road structure indicators
        unusual_indicators = list(snapshot.indian_context.unusual_road_indicators)
        for ind in unusual_indicators:
            factors.append(f"UNUSUAL_INDICATOR_{ind.upper()[:24]}")
            score += 0.05
        if unusual_indicators:
            score += 0.05  # base bump for any unusual indicator

        # 12. Uncertainty from world model
        dq = snapshot.data_quality
        if dq.overall_uncertainty > 0.7:
            factors.append("HIGH_WORLD_UNCERTAINTY")
            score += 0.10

        # Cap score at 1.0 and classify
        score = min(1.0, score)
        level = self._score_to_level(score)

        confidence = max(0.0, min(1.0, dq.overall_confidence))
        uncertainty = max(0.0, min(1.0, dq.overall_uncertainty))

        return ComplexityInfo(
            complexity_level=level,
            contributing_factors=factors[: self._cfg.max_reason_codes],
            confidence=round(confidence, 3),
            uncertainty=round(uncertainty, 3),
        )

    # ------------------------------------------------------------------
    # Level classification
    # ------------------------------------------------------------------

    def _score_to_level(self, score: float) -> ComplexityLevel:
        if score >= 0.70:
            return ComplexityLevel.VERY_HIGH
        if score >= 0.45:
            return ComplexityLevel.HIGH
        if score >= 0.20:
            return ComplexityLevel.MEDIUM
        return ComplexityLevel.LOW
