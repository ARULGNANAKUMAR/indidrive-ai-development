"""
IndiDrive AI — Phase 8.3 | Action Abstraction Snapshot Utilities
=================================================================
Safe read-only utilities for ActionAbstractionSnapshot.

Rules:
  - All operations are read-only; inputs are never mutated.
  - Repeated reads are safe (deterministic).
  - No mutable copies are returned.
"""
from __future__ import annotations

import json
import time
from typing import Any, Dict, Optional

from .action_abstraction_types import (
    ActionAbstractionSnapshot,
    ActionAbstractionResult,
    DecisionRequirement,
    RequirementType,
    AbstractUrgency,
    AbstractSeverity,
)

__all__ = [
    "abstraction_snapshot_age_s",
    "is_abstraction_snapshot_stale",
    "abstraction_snapshot_to_json",
    "abstraction_snapshot_summary",
    "safe_copy_abstraction_snapshot",
    "find_requirement_by_type",
]


def abstraction_snapshot_age_s(
    snapshot: ActionAbstractionSnapshot,
    now: Optional[float] = None,
) -> float:
    """Return the age of this snapshot in seconds (wall-clock)."""
    if now is None:
        now = time.time()
    return max(0.0, now - snapshot.timestamp)


def is_abstraction_snapshot_stale(
    snapshot: ActionAbstractionSnapshot,
    threshold_s: float = 1.5,
    now: Optional[float] = None,
) -> bool:
    """True if the snapshot is older than threshold_s."""
    return abstraction_snapshot_age_s(snapshot, now) > threshold_s


def abstraction_snapshot_to_json(
    snapshot: ActionAbstractionSnapshot,
    indent: int = 2,
) -> str:
    """Serialise the snapshot to a JSON string. Read-only; state is not mutated."""
    return json.dumps(snapshot.to_dict(), indent=indent, default=str)


def abstraction_snapshot_summary(
    snapshot: ActionAbstractionSnapshot,
) -> Dict[str, Any]:
    """
    Return a compact summary dict (no large lists).
    Safe to log at DEBUG level without flooding output.
    """
    safety_critical_count = len(snapshot.safety_critical_requirements)
    req_type_names = [r.requirement_type.value for r in snapshot.requirements]
    return {
        "schema_version": snapshot.schema_version,
        "timestamp": snapshot.timestamp,
        "frame_id": snapshot.frame_id,
        "response_family": snapshot.response_family.value,
        "overall_urgency": snapshot.overall_urgency.value,
        "overall_severity": snapshot.overall_severity.value,
        "any_safety_critical": snapshot.any_safety_critical,
        "requirement_count": snapshot.requirement_count,
        "requirement_types": req_type_names,
        "relationship_count": snapshot.relationship_count,
        "confidence": snapshot.confidence,
        "uncertainty": snapshot.uncertainty,
        "input_completeness": snapshot.input_completeness,
        "degraded": snapshot.degraded,
        "safety_critical_count": safety_critical_count,
        "reason_code_count": len(snapshot.reason_codes),
    }


def safe_copy_abstraction_snapshot(
    snapshot: ActionAbstractionSnapshot,
) -> Dict[str, Any]:
    """
    Return a deep-copy of the snapshot as a plain dict.

    The original snapshot is not mutated.
    The copy is a plain dict — not an ActionAbstractionSnapshot —
    so it cannot affect upstream data.
    """
    return snapshot.to_dict()


def find_requirement_by_type(
    snapshot: ActionAbstractionSnapshot,
    req_type: RequirementType,
) -> Optional[DecisionRequirement]:
    """
    Return the first requirement of the given type, or None.
    Read-only — snapshot is not mutated.
    """
    for req in snapshot.requirements:
        if req.requirement_type == req_type:
            return req
    return None
