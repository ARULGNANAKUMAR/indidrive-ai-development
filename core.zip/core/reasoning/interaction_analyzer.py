"""
IndiDrive AI — Phase 8.1 | Interaction Analysis
=================================================
Lightweight interaction analysis between environmental entities.

Determines whether interaction exists, what kind, severity, confidence
and uncertainty.

Does NOT determine steering / path response.
"""
from __future__ import annotations

from typing import List

from core.world_model.world_model_types import WorldModelSnapshot
from .reasoning_config import ReasoningConfig
from .reasoning_types import (
    HazardEntry,
    HazardCategory,
    InteractionEntry,
    InteractionType,
    RiskLevel,
    NOT_AVAILABLE,
)

__all__ = ["InteractionAnalyzer"]

# ---------------------------------------------------------------------------
# Category → interaction type mapping
# ego = the vehicle itself; entity_a = hazard object
# ---------------------------------------------------------------------------

_EGO_INTERACTION_MAP: dict = {
    HazardCategory.PEDESTRIAN:   InteractionType.VEHICLE_PEDESTRIAN,
    HazardCategory.CYCLIST:      InteractionType.VEHICLE_CYCLIST,
    HazardCategory.MOTORCYCLE:   InteractionType.VEHICLE_MOTORCYCLE,
    HazardCategory.SCOOTER:      InteractionType.VEHICLE_MOTORCYCLE,
    HazardCategory.CATTLE:       InteractionType.VEHICLE_CATTLE,
    HazardCategory.PUSHCART:     InteractionType.VEHICLE_PUSHCART,
    HazardCategory.CAR:          InteractionType.VEHICLE_VEHICLE,
    HazardCategory.BUS:          InteractionType.VEHICLE_VEHICLE,
    HazardCategory.TRUCK:        InteractionType.VEHICLE_VEHICLE,
    HazardCategory.TRACTOR:      InteractionType.VEHICLE_VEHICLE,
    HazardCategory.AUTO_RICKSHAW: InteractionType.VEHICLE_VEHICLE,
    HazardCategory.POTHOLE:      InteractionType.VEHICLE_ROAD_ANOMALY,
    HazardCategory.DEBRIS:       InteractionType.VEHICLE_ROAD_ANOMALY,
    HazardCategory.CONSTRUCTION: InteractionType.VEHICLE_ROAD_ANOMALY,
    HazardCategory.ROAD_OBSTACLE: InteractionType.VEHICLE_ROAD_ANOMALY,
}

_INTERACTION_RISK_THRESHOLD = 0.3  # minimum priority to form an interaction


class InteractionAnalyzer:
    """
    Detects interactions between the ego vehicle and environmental hazards,
    and between hazards themselves when multiple are active.

    Bounded to max_interactions from config.
    """

    def __init__(self, config: ReasoningConfig) -> None:
        self._cfg = config
        self._counter = 0

    def analyze(
        self,
        hazards: List[HazardEntry],
        snapshot: WorldModelSnapshot,
    ) -> List[InteractionEntry]:
        """
        Produce a bounded list of InteractionEntry objects.

        Ego ↔ each relevant hazard → primary interactions.
        Multiple high-priority hazards → compound interaction if applicable.
        """
        entries: List[InteractionEntry] = []
        self._counter = 0

        for hazard in hazards:
            if hazard.priority_score < _INTERACTION_RISK_THRESHOLD:
                continue
            if len(entries) >= self._cfg.max_interactions:
                break
            entry = self._ego_hazard_interaction(hazard, snapshot)
            if entry is not None:
                entries.append(entry)

        # Compound: multiple high-priority hazards → one compound entry
        high_count = sum(
            1 for h in hazards
            if h.risk_level in (RiskLevel.HIGH, RiskLevel.CRITICAL)
        )
        if high_count >= 2 and len(entries) < self._cfg.max_interactions:
            entries.append(self._compound_interaction(hazards, high_count))

        return entries[: self._cfg.max_interactions]

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _next_id(self) -> str:
        self._counter += 1
        return f"interaction_{self._counter:03d}"

    def _ego_hazard_interaction(
        self,
        hazard: HazardEntry,
        snapshot: WorldModelSnapshot,
    ) -> "InteractionEntry | None":
        """Build an ego↔hazard interaction entry."""
        itype = _EGO_INTERACTION_MAP.get(hazard.hazard_category, InteractionType.UNKNOWN)

        severity = hazard.risk_level
        if severity == RiskLevel.UNKNOWN:
            severity = RiskLevel.LOW

        reason_codes: List[str] = [f"INTERACTION_{itype.value}"]
        if hazard.predicted_conflict:
            reason_codes.append("PREDICTED_CONFLICT")
        if hazard.is_vulnerable:
            reason_codes.append("VULNERABLE_ENTITY")

        # Determine if interaction is currently active
        is_active = (
            hazard.risk_level in (RiskLevel.HIGH, RiskLevel.CRITICAL)
            or hazard.predicted_conflict
        )

        confidence = hazard.confidence
        uncertainty = hazard.uncertainty

        # Additional confidence boost if trajectory data predicted conflict
        if hazard.predicted_conflict and confidence < 0.5:
            confidence = max(confidence, 0.4)

        if confidence < self._cfg.interaction_min_confidence:
            return None

        return InteractionEntry(
            interaction_id=self._next_id(),
            interaction_type=itype,
            entity_a_id="ego",
            entity_b_id=hazard.hazard_id,
            severity=severity,
            confidence=round(confidence, 3),
            uncertainty=round(uncertainty, 3),
            is_active=is_active,
            reason_codes=reason_codes[: self._cfg.max_reason_codes],
        )

    def _compound_interaction(
        self,
        hazards: List[HazardEntry],
        high_count: int,
    ) -> InteractionEntry:
        """Produce a compound-hazard interaction summary entry."""
        top_ids = [h.hazard_id for h in hazards[:3] if h.hazard_id != NOT_AVAILABLE]
        avg_conf = sum(h.confidence for h in hazards[:high_count]) / max(1, high_count)
        avg_unc = sum(h.uncertainty for h in hazards[:high_count]) / max(1, high_count)

        return InteractionEntry(
            interaction_id=self._next_id(),
            interaction_type=InteractionType.COMPOUND_MULTI_HAZARD,
            entity_a_id=top_ids[0] if top_ids else NOT_AVAILABLE,
            entity_b_id=top_ids[1] if len(top_ids) > 1 else NOT_AVAILABLE,
            severity=RiskLevel.HIGH,
            confidence=round(avg_conf, 3),
            uncertainty=round(avg_unc, 3),
            is_active=True,
            reason_codes=[
                "COMPOUND_MULTI_HAZARD",
                f"HIGH_RISK_COUNT_{high_count}",
            ],
        )
