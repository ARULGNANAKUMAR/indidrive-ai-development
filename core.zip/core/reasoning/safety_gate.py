"""
IndiDrive AI — Phase 8.4 | Safety Gate Evaluator
==================================================
Deterministic evaluation of the SafetyGateState from arbitrated
requirements and world model information.

The safety gate answers:
    «"What is the current safety envelope that Phase 9 must operate within?"»

It does NOT answer:
    «"How should the vehicle steer / brake / accelerate?"»

Design rules:
  * Fully deterministic — same input → same state.
  * No LLM, no cloud, no neural networks.
  * All thresholds come from ArbitrationConfig.
  * Uncertainty ≠ risk: handled separately.
  * Conservative under degradation — unknown information → safe default.
"""
from __future__ import annotations

from typing import List, Optional, Tuple, TYPE_CHECKING

if TYPE_CHECKING:
    from .action_abstraction_types import ActionAbstractionSnapshot, DecisionRequirement
    from .world_model_types_shim import WorldModelSnapshot

from .arbitration_types import SafetyGateState
from .arbitration_config import ArbitrationConfig
from .action_abstraction_types import (
    RequirementType,
    AbstractUrgency,
    AbstractSeverity,
    ResponseFamily,
)

__all__ = ["SafetyGateEvaluator"]


class SafetyGateEvaluator:
    """
    Deterministic safety gate evaluator.

    Evaluates the SafetyGateState from:
      - action abstraction snapshot (Phase 8.3)
      - world model completeness
      - overall uncertainty
      - degraded flag

    Priority ordering (highest wins):
        CRITICAL > HIGH_ALERT > RESTRICTED > DEGRADED > CAUTION > CLEAR
        UNKNOWN is the fallback when information is insufficient.
    """

    def __init__(self, config: Optional[ArbitrationConfig] = None) -> None:
        self._config = config or ArbitrationConfig()

    def evaluate(
        self,
        abstraction_snapshot,   # ActionAbstractionSnapshot | None
        world_model_completeness: float,
        overall_uncertainty: float,
        degraded: bool,
    ) -> Tuple[SafetyGateState, List[str]]:
        """
        Evaluate the safety gate state.

        Returns
        -------
        (SafetyGateState, reason_codes)
            reason_codes is a list of deterministic string codes explaining
            why this gate state was selected.
        """
        cfg = self._config
        reason_codes: List[str] = []

        # --- Guard: no abstraction snapshot ---
        if abstraction_snapshot is None:
            reason_codes.append("UNKNOWN_WORLD_STATE")
            return SafetyGateState.UNKNOWN, reason_codes

        # --- UNKNOWN: insufficient information ---
        if abstraction_snapshot.degraded and world_model_completeness <= 0.0:
            reason_codes.append("UNKNOWN_WORLD_STATE")
            reason_codes.append("WORLD_MODEL_INCOMPLETE")
            return SafetyGateState.UNKNOWN, reason_codes

        requirements = abstraction_snapshot.requirements

        # ---------------------------------------------------------------
        # CRITICAL check
        # ---------------------------------------------------------------
        critical_urgencies = set(cfg.critical_urgency_values)
        critical_severities = set(cfg.critical_severity_values)
        critical_req_types = set(cfg.critical_requirement_types)

        for req in requirements:
            if not req.is_safety_critical:
                continue
            is_critical_urgency = req.urgency.value in critical_urgencies
            is_critical_severity = req.severity.value in critical_severities
            is_critical_type = req.requirement_type.value in critical_req_types

            if is_critical_urgency and (is_critical_severity or is_critical_type):
                reason_codes.append("IMMEDIATE_COLLISION_THREAT")
                if req.requirement_type == RequirementType.COLLISION_AVOIDANCE_REQUIRED:
                    reason_codes.append("COLLISION_AVOIDANCE_REQUIRED")
                elif req.requirement_type == RequirementType.HANDLE_TRAJECTORY_CONFLICT:
                    reason_codes.append("TRAJECTORY_CONFLICT")
                elif req.requirement_type == RequirementType.HANDLE_VULNERABLE_USER:
                    reason_codes.append("VRU_CONFLICT")
                return SafetyGateState.CRITICAL, reason_codes

        # ---------------------------------------------------------------
        # DEGRADED check (before HIGH_ALERT — degraded system state takes
        # precedence over hazard-based gate elevation when the primary
        # driver is DEGRADED_OPERATION or degraded inputs, not a collision)
        # ---------------------------------------------------------------
        is_degraded = (
            degraded
            or abstraction_snapshot.degraded
            or world_model_completeness < cfg.degraded_completeness_threshold
            or overall_uncertainty > cfg.degraded_uncertainty_threshold
        )
        has_degraded_req = any(
            r.requirement_type == RequirementType.DEGRADED_OPERATION
            for r in requirements
        )
        if is_degraded and (has_degraded_req or abstraction_snapshot.degraded):
            reason_codes.append("DEGRADED_OPERATION")
            if world_model_completeness < cfg.degraded_completeness_threshold:
                reason_codes.append("WORLD_MODEL_DEGRADED")
            if overall_uncertainty > cfg.degraded_uncertainty_threshold:
                reason_codes.append("HIGH_UNCERTAINTY")
            return SafetyGateState.DEGRADED, reason_codes

        # ---------------------------------------------------------------
        # HIGH_ALERT check
        # ---------------------------------------------------------------
        high_alert_severities = set(cfg.high_alert_severity_values)
        high_alert_urgencies = set(cfg.high_alert_urgency_values)
        high_alert_types = set(cfg.high_alert_requirement_types)

        # Any safety-critical requirement (that is not DEGRADED_OPERATION)
        # with HIGH urgency/severity → HIGH_ALERT
        for req in requirements:
            if not req.is_safety_critical:
                continue
            if req.requirement_type == RequirementType.DEGRADED_OPERATION:
                continue  # handled above
            if (req.severity.value in high_alert_severities
                    and req.urgency.value in high_alert_urgencies):
                reason_codes.append("HIGH_SAFETY_RISK")
                if req.requirement_type.value in high_alert_types:
                    reason_codes.append(req.requirement_type.value)
                return SafetyGateState.HIGH_ALERT, reason_codes

        # High priority requirement above threshold → HIGH_ALERT
        if requirements:
            top_req = requirements[0]
            if (top_req.requirement_type != RequirementType.DEGRADED_OPERATION
                    and top_req.priority >= cfg.high_alert_priority_threshold
                    and top_req.requirement_type.value in high_alert_types
                    and top_req.is_safety_critical):
                reason_codes.append("HIGH_PRIORITY_SAFETY_REQUIREMENT")
                return SafetyGateState.HIGH_ALERT, reason_codes

        # Secondary degraded check: degraded inputs but no explicit
        # DEGRADED_OPERATION requirement (e.g. missing world model)
        if is_degraded:
            reason_codes.append("DEGRADED_OPERATION")
            if world_model_completeness < cfg.degraded_completeness_threshold:
                reason_codes.append("WORLD_MODEL_DEGRADED")
            if overall_uncertainty > cfg.degraded_uncertainty_threshold:
                reason_codes.append("HIGH_UNCERTAINTY")
            return SafetyGateState.DEGRADED, reason_codes

        # ---------------------------------------------------------------
        # RESTRICTED check
        # ---------------------------------------------------------------
        # Hard constraints present, or significant uncertainty, or low completeness
        any_hard_constraint_req = any(
            r.requirement_type.value in cfg.hard_constraint_requirement_types
            and not r.requirement_type == RequirementType.DEGRADED_OPERATION
            for r in requirements
        )
        has_high_uncertainty = overall_uncertainty >= cfg.restricted_uncertainty_threshold
        has_low_completeness = (
            0.0 < world_model_completeness < cfg.restricted_completeness_threshold
        )
        has_uncertainty_req = any(
            r.requirement_type == RequirementType.HANDLE_UNCERTAINTY
            for r in requirements
        )
        has_road_restriction = any(
            r.requirement_type in (
                RequirementType.MAINTAIN_DRIVABLE_REGION,
                RequirementType.HANDLE_NARROW_ROAD,
                RequirementType.HANDLE_ROAD_HAZARD,
            )
            for r in requirements
        )

        if any_hard_constraint_req or (has_high_uncertainty and has_uncertainty_req):
            reason_codes.append("HARD_CONSTRAINT_ACTIVE")
            if has_high_uncertainty:
                reason_codes.append("HIGH_UNCERTAINTY")
            return SafetyGateState.RESTRICTED, reason_codes

        if has_low_completeness:
            reason_codes.append("WORLD_MODEL_INCOMPLETE")
            return SafetyGateState.RESTRICTED, reason_codes

        if has_road_restriction and abstraction_snapshot.any_safety_critical:
            reason_codes.append("ROAD_HAZARD_ACTIVE")
            return SafetyGateState.RESTRICTED, reason_codes

        # ---------------------------------------------------------------
        # CAUTION check
        # ---------------------------------------------------------------
        has_moderate_req = any(
            r.priority >= cfg.caution_hazard_priority_min
            for r in requirements
            if r.requirement_type != RequirementType.NORMAL_PROGRESS
        )
        has_moderate_uncertainty = overall_uncertainty >= cfg.caution_uncertainty_threshold

        if has_moderate_req or has_moderate_uncertainty:
            reason_codes.append("MODERATE_HAZARD_ACTIVE")
            if has_moderate_uncertainty:
                reason_codes.append("MODERATE_UNCERTAINTY")
            return SafetyGateState.CAUTION, reason_codes

        # ---------------------------------------------------------------
        # CLEAR
        # ---------------------------------------------------------------
        if (world_model_completeness >= cfg.restricted_completeness_threshold
                and overall_uncertainty < cfg.caution_uncertainty_threshold
                and not abstraction_snapshot.any_safety_critical):
            reason_codes.append("NORMAL_OPERATION")
            return SafetyGateState.CLEAR, reason_codes

        # ---------------------------------------------------------------
        # UNKNOWN fallback
        # ---------------------------------------------------------------
        reason_codes.append("UNKNOWN_WORLD_STATE")
        return SafetyGateState.UNKNOWN, reason_codes
