"""
IndiDrive AI — Phase 8.1 | Reasoning Validator
================================================
Structural validation of ReasoningSnapshot and its sub-components.

Validates:
  - timestamp and frame ID
  - object and hazard IDs
  - risk levels and confidence/uncertainty bounds
  - enum values
  - TTC values
  - collection sizes
  - priority scores

Returns structured ValidationResult — does NOT silently repair invalid data.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import List, Optional

from .reasoning_config import ReasoningConfig
from .reasoning_types import (
    HazardEntry,
    InteractionEntry,
    ReasoningSnapshot,
    ReasoningState,
    RiskLevel,
    TtcBand,
    ComplexityLevel,
    UncertaintyLevel,
    NOT_AVAILABLE,
)

__all__ = [
    "ReasoningValidator",
    "ReasoningValidationResult",
]


@dataclass
class ReasoningValidationResult:
    """Structured result from validating a ReasoningSnapshot."""
    is_valid: bool = True
    errors: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)

    def add_error(self, msg: str) -> None:
        self.errors.append(msg)
        self.is_valid = False

    def add_warning(self, msg: str) -> None:
        self.warnings.append(msg)

    def to_dict(self) -> dict:
        return {
            "is_valid": self.is_valid,
            "error_count": len(self.errors),
            "warning_count": len(self.warnings),
            "errors": list(self.errors),
            "warnings": list(self.warnings),
        }


class ReasoningValidator:
    """
    Validates a ReasoningSnapshot for structural integrity.
    Does NOT silently repair; callers receive explicit error reports.
    """

    def __init__(self, config: Optional[ReasoningConfig] = None) -> None:
        self._cfg = config or ReasoningConfig()

    def validate(self, snapshot: ReasoningSnapshot) -> ReasoningValidationResult:
        result = ReasoningValidationResult()

        self._validate_top_level(snapshot, result)
        self._validate_situation(snapshot, result)
        self._validate_hazards(snapshot, result)
        self._validate_interactions(snapshot, result)
        self._validate_risk(snapshot, result)
        self._validate_complexity(snapshot, result)
        self._validate_uncertainty(snapshot, result)
        self._validate_explanation(snapshot, result)

        return result

    # ------------------------------------------------------------------
    # Top-level
    # ------------------------------------------------------------------

    def _validate_top_level(self, snap: ReasoningSnapshot, r: ReasoningValidationResult) -> None:
        if not isinstance(snap.timestamp, (int, float)) or not math.isfinite(snap.timestamp):
            r.add_error("INVALID_TIMESTAMP")
        if snap.timestamp < 0:
            r.add_error("NEGATIVE_TIMESTAMP")

        if not isinstance(snap.frame_id, int) or snap.frame_id < 0:
            r.add_error("INVALID_FRAME_ID")

        if snap.reasoning_state not in list(ReasoningState):
            r.add_error(f"INVALID_REASONING_STATE: {snap.reasoning_state!r}")

        if not (0.0 <= snap.reasoning_confidence <= 1.0):
            r.add_error(f"REASONING_CONFIDENCE_OUT_OF_BOUNDS: {snap.reasoning_confidence}")

        if snap.schema_version != "8.1":
            r.add_warning(f"UNEXPECTED_SCHEMA_VERSION: {snap.schema_version!r}")

    # ------------------------------------------------------------------
    # Situation
    # ------------------------------------------------------------------

    def _validate_situation(self, snap: ReasoningSnapshot, r: ReasoningValidationResult) -> None:
        sit = snap.situation
        if not (0.0 <= sit.situation_confidence <= 1.0):
            r.add_error(f"SITUATION_CONFIDENCE_OUT_OF_BOUNDS: {sit.situation_confidence}")
        if not (0.0 <= sit.situation_uncertainty <= 1.0):
            r.add_error(f"SITUATION_UNCERTAINTY_OUT_OF_BOUNDS: {sit.situation_uncertainty}")
        if sit.frame_id != snap.frame_id:
            r.add_warning("SITUATION_FRAME_ID_MISMATCH")

    # ------------------------------------------------------------------
    # Hazards
    # ------------------------------------------------------------------

    def _validate_hazards(self, snap: ReasoningSnapshot, r: ReasoningValidationResult) -> None:
        haz = snap.hazards

        # Count fields must be non-negative
        for field_name in ("total_hazards", "critical_hazards", "high_risk_hazards",
                           "active_hazards", "predicted_hazards", "road_hazards",
                           "vulnerable_road_users", "unusual_participants"):
            val = getattr(haz, field_name)
            if not isinstance(val, int) or val < 0:
                r.add_error(f"HAZARD_COUNT_NEGATIVE: {field_name}={val}")

        if haz.critical_hazards > haz.total_hazards:
            r.add_error("CRITICAL_HAZARDS_EXCEED_TOTAL")

        if len(haz.top_hazards) > self._cfg.max_top_hazards:
            r.add_error(f"TOP_HAZARDS_EXCEED_MAX: {len(haz.top_hazards)}")

        for i, h in enumerate(haz.top_hazards):
            self._validate_hazard_entry(h, f"top_hazards[{i}]", r)

    def _validate_hazard_entry(
        self, h: HazardEntry, ctx: str, r: ReasoningValidationResult
    ) -> None:
        if not (0.0 <= h.priority_score <= 1.0):
            r.add_error(f"PRIORITY_SCORE_OUT_OF_BOUNDS: {ctx} score={h.priority_score}")
        if not (0.0 <= h.confidence <= 1.0):
            r.add_error(f"CONFIDENCE_OUT_OF_BOUNDS: {ctx} conf={h.confidence}")
        if not (0.0 <= h.uncertainty <= 1.0):
            r.add_error(f"UNCERTAINTY_OUT_OF_BOUNDS: {ctx} unc={h.uncertainty}")
        if h.ttc_s is not None and (not math.isfinite(h.ttc_s) or h.ttc_s < 0):
            r.add_error(f"INVALID_TTC: {ctx} ttc={h.ttc_s}")
        if h.collision_likelihood is not None and not (0.0 <= h.collision_likelihood <= 1.0):
            r.add_error(f"COLLISION_LIKELIHOOD_OUT_OF_BOUNDS: {ctx} cl={h.collision_likelihood}")
        if h.ttc_band not in list(TtcBand):
            r.add_error(f"INVALID_TTC_BAND: {ctx} band={h.ttc_band!r}")
        if h.risk_level not in list(RiskLevel):
            r.add_error(f"INVALID_RISK_LEVEL: {ctx} rl={h.risk_level!r}")
        if len(h.reason_codes) > self._cfg.max_reason_codes:
            r.add_warning(f"TOO_MANY_REASON_CODES: {ctx}")

    # ------------------------------------------------------------------
    # Interactions
    # ------------------------------------------------------------------

    def _validate_interactions(self, snap: ReasoningSnapshot, r: ReasoningValidationResult) -> None:
        if len(snap.interactions) > self._cfg.max_interactions:
            r.add_error(f"TOO_MANY_INTERACTIONS: {len(snap.interactions)}")
        for i, intr in enumerate(snap.interactions):
            self._validate_interaction_entry(intr, f"interactions[{i}]", r)

    def _validate_interaction_entry(
        self, intr: InteractionEntry, ctx: str, r: ReasoningValidationResult
    ) -> None:
        if not (0.0 <= intr.confidence <= 1.0):
            r.add_error(f"INTERACTION_CONFIDENCE_OOB: {ctx}")
        if not (0.0 <= intr.uncertainty <= 1.0):
            r.add_error(f"INTERACTION_UNCERTAINTY_OOB: {ctx}")
        if intr.severity not in list(RiskLevel):
            r.add_error(f"INVALID_INTERACTION_SEVERITY: {ctx}")

    # ------------------------------------------------------------------
    # Risk
    # ------------------------------------------------------------------

    def _validate_risk(self, snap: ReasoningSnapshot, r: ReasoningValidationResult) -> None:
        risk = snap.risk
        if risk.overall_risk_level not in list(RiskLevel):
            r.add_error(f"INVALID_OVERALL_RISK: {risk.overall_risk_level!r}")
        if risk.max_hazard_risk not in list(RiskLevel):
            r.add_error(f"INVALID_MAX_HAZARD_RISK: {risk.max_hazard_risk!r}")
        if risk.time_criticality not in list(TtcBand):
            r.add_error(f"INVALID_TIME_CRITICALITY: {risk.time_criticality!r}")
        if risk.uncertainty_level not in list(UncertaintyLevel):
            r.add_error(f"INVALID_UNCERTAINTY_LEVEL: {risk.uncertainty_level!r}")

    # ------------------------------------------------------------------
    # Complexity
    # ------------------------------------------------------------------

    def _validate_complexity(self, snap: ReasoningSnapshot, r: ReasoningValidationResult) -> None:
        cpx = snap.complexity
        if cpx.complexity_level not in list(ComplexityLevel):
            r.add_error(f"INVALID_COMPLEXITY_LEVEL: {cpx.complexity_level!r}")
        if not (0.0 <= cpx.confidence <= 1.0):
            r.add_error(f"COMPLEXITY_CONFIDENCE_OOB: {cpx.confidence}")
        if not (0.0 <= cpx.uncertainty <= 1.0):
            r.add_error(f"COMPLEXITY_UNCERTAINTY_OOB: {cpx.uncertainty}")

    # ------------------------------------------------------------------
    # Uncertainty
    # ------------------------------------------------------------------

    def _validate_uncertainty(self, snap: ReasoningSnapshot, r: ReasoningValidationResult) -> None:
        unc = snap.uncertainty_info
        if not (0.0 <= unc.overall_uncertainty <= 1.0):
            r.add_error(f"UNCERTAINTY_OOB: {unc.overall_uncertainty}")

    # ------------------------------------------------------------------
    # Explanation
    # ------------------------------------------------------------------

    def _validate_explanation(self, snap: ReasoningSnapshot, r: ReasoningValidationResult) -> None:
        exp = snap.explanation
        for lst_name in ("state_reason_codes", "situation_reason_codes", "complexity_reason_codes"):
            lst = getattr(exp, lst_name)
            if len(lst) > self._cfg.max_reason_codes:
                r.add_warning(f"EXPLANATION_{lst_name.upper()}_EXCEEDS_MAX")
