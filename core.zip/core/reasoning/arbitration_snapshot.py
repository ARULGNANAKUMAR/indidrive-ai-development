"""
IndiDrive AI — Phase 8.4 | Arbitration Snapshot Utilities
===========================================================
Safe read-only utilities for ArbitrationSnapshot.

Rules:
  - All operations are read-only; inputs are never mutated.
  - Repeated reads are safe (deterministic).
  - No mutable copies are returned.
"""
from __future__ import annotations

import json
import time
from typing import Any, Dict, Optional

from .arbitration_types import (
    ArbitrationSnapshot,
    ArbitrationResult,
    ArbitratedRequirement,
    RequirementStatus,
    SafetyGateState,
)
from .action_abstraction_types import RequirementType

__all__ = [
    "arbitration_snapshot_age_s",
    "is_arbitration_snapshot_stale",
    "arbitration_snapshot_to_json",
    "arbitration_snapshot_summary",
    "safe_copy_arbitration_snapshot",
    "find_arbitrated_by_type",
]


def arbitration_snapshot_age_s(
    snapshot: ArbitrationSnapshot,
    now: Optional[float] = None,
) -> float:
    """Return the age of this snapshot in seconds (wall-clock)."""
    if now is None:
        now = time.time()
    return max(0.0, now - snapshot.timestamp)


def is_arbitration_snapshot_stale(
    snapshot: ArbitrationSnapshot,
    threshold_s: float = 1.5,
    now: Optional[float] = None,
) -> bool:
    """True if the snapshot is older than threshold_s."""
    return arbitration_snapshot_age_s(snapshot, now) > threshold_s


def arbitration_snapshot_to_json(
    snapshot: ArbitrationSnapshot,
    indent: int = 2,
) -> str:
    """Serialise the snapshot to a JSON string. Read-only; state is not mutated."""
    return json.dumps(snapshot.to_dict(), indent=indent, default=str)


def arbitration_snapshot_summary(
    snapshot: ArbitrationSnapshot,
) -> Dict[str, Any]:
    """
    Return a compact summary dict (no large lists).
    Safe to log at DEBUG level without flooding output.
    """
    dom = snapshot.dominant_requirement
    dom_type = (
        dom.requirement.requirement_type.value
        if dom is not None else "NONE"
    )
    active_types = [
        ar.requirement.requirement_type.value
        for ar in snapshot.active_requirements
    ]
    return {
        "schema_version": snapshot.schema_version,
        "timestamp": snapshot.timestamp,
        "frame_id": snapshot.frame_id,
        "safety_gate_state": snapshot.safety_gate_state.value,
        "dominant_requirement_type": dom_type,
        "active_requirement_count": len(snapshot.active_requirements),
        "active_requirement_types": active_types,
        "total_requirement_count": snapshot.requirement_count,
        "conflict_count": snapshot.conflict_count,
        "hard_constraint_count": snapshot.hard_constraint_count,
        "soft_constraint_count": snapshot.soft_constraint_count,
        "planning_allowed": snapshot.planning_context.planning_allowed,
        "planning_mode": snapshot.planning_context.planning_mode.value,
        "safety_override_required": snapshot.planning_context.safety_override_required,
        "confidence": snapshot.confidence,
        "uncertainty": snapshot.uncertainty,
        "world_model_completeness": snapshot.world_model_completeness,
        "degraded": snapshot.degraded,
        "reason_code_count": len(snapshot.reason_codes),
    }


def safe_copy_arbitration_snapshot(
    snapshot: ArbitrationSnapshot,
) -> Dict[str, Any]:
    """
    Return a deep-copy of the snapshot as a plain dict.

    The original snapshot is not mutated.
    The copy is a plain dict — not an ArbitrationSnapshot —
    so it cannot affect upstream data.
    """
    return snapshot.to_dict()


def find_arbitrated_by_type(
    snapshot: ArbitrationSnapshot,
    req_type: RequirementType,
) -> Optional[ArbitratedRequirement]:
    """
    Return the first ArbitratedRequirement of the given type, or None.
    Read-only — snapshot is not mutated.
    """
    for ar in snapshot.arbitrated_requirements:
        if ar.requirement.requirement_type == req_type:
            return ar
    return None
