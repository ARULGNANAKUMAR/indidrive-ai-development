"""
IndiDrive AI — Phase 8.2 | Intent Estimator
=============================================
Lightweight intent estimation from observable vehicle/object dynamics.

This is NOT human psychological intent.
It means: probable motion/behavior intention inferred from observable
vehicle/object dynamics.

Rules:
  - Deterministic: same input → same output
  - Every intent backed by explicit evidence items
  - No certainty is ever claimed
  - Intent is NOT inferred from object class alone
    (motorcycle ≠ automatically overtaking)
  - Indian-road behavior patterns supported when evidence present
  - Does NOT use LLM, cloud, or neural networks
"""
from __future__ import annotations

from typing import List, Optional

from core.world_model.world_model_types import WorldObject, NOT_AVAILABLE

from .behavior_types import (
    BehaviorClassification,
    BehaviorEvidenceItem,
    BehaviorState,
    EvidenceClass,
    IntentHypothesis,
    IntentType,
)
from .behavior_reasoning_config import BehaviorReasoningConfig

__all__ = ["IntentEstimator"]

# ---------------------------------------------------------------------------
# Evidence reason codes
# ---------------------------------------------------------------------------
_E_LAT_MOTION         = "LATERAL_MOTION"
_E_TRAJ_INTERSECT     = "TRAJECTORY_INTERSECTION"
_E_HEADING_CHANGE     = "HEADING_CHANGE"
_E_DECEL              = "DECELERATION_OBSERVED"
_E_NEAR_ROAD_BOUNDARY = "NEAR_ROAD_BOUNDARY"
_E_ROAD_APPROACH      = "ROAD_APPROACH_VECTOR"
_E_SPEED_LOW          = "SPEED_LOW"
_E_CONFLICT           = "PREDICTED_CONFLICT"
_E_WRONG_SIDE         = "WRONG_SIDE_APPROACH"
_E_CLOSING_SPEED      = "CLOSING_SPEED_HIGH"
_E_LAT_VEL_HIGH       = "LATERAL_VELOCITY_HIGH"
_E_OVERTAKE_PATTERN   = "LATERAL_OVERSHOOT_PATTERN"
_E_ERRATIC_MOTION     = "ERRATIC_MOTION_PATTERN"
_E_NEAR_BOUNDARY      = "NEAR_DRIVABLE_BOUNDARY"
_E_ROADSIDE           = "ROADSIDE_POSITION"
_E_HYPO_CROSSING      = "HYPOTHESIS_CROSSING"
_E_HYPO_TURN          = "HYPOTHESIS_TURNING"
_E_HYPO_MERGE         = "HYPOTHESIS_MERGING"
_E_HYPO_STOP          = "HYPOTHESIS_STOPPING"


def _ev(code: str, cls: EvidenceClass, strength: float = 0.6) -> BehaviorEvidenceItem:
    return BehaviorEvidenceItem(code=code, evidence_class=cls, strength=strength)


class IntentEstimator:
    """
    Estimates probable motion intentions from observable dynamics.

    Uses BehaviorClassification + WorldObject data as inputs.
    Never assigns intent from object type alone.
    Produces at most max_intent_hypotheses per entity.
    """

    def __init__(self, config: BehaviorReasoningConfig) -> None:
        self._cfg = config

    def estimate_all(
        self,
        behaviors: List[BehaviorClassification],
        objects_by_id: dict,
        road_is_narrow: bool,
        has_indian_context: bool,
        indian_road_type: str,
    ) -> List[IntentHypothesis]:
        """
        Produce bounded list of intent hypotheses for all classified entities.

        Returns at most max_intent_hypotheses total across all entities.
        """
        results: List[IntentHypothesis] = []
        for bc in behaviors:
            obj = objects_by_id.get(bc.entity_id)
            hypotheses = self._estimate_one(
                bc, obj, road_is_narrow, has_indian_context, indian_road_type
            )
            results.extend(hypotheses)
            if len(results) >= self._cfg.max_intent_hypotheses:
                break
        return results[: self._cfg.max_intent_hypotheses]

    def _estimate_one(
        self,
        bc: BehaviorClassification,
        obj: Optional[WorldObject],
        road_is_narrow: bool,
        has_indian_context: bool,
        indian_road_type: str,
    ) -> List[IntentHypothesis]:
        """Estimate intent hypotheses for one entity."""
        entity_id = bc.entity_id
        state = bc.behavior_state
        hypotheses: List[IntentHypothesis] = []

        # --- Extract WorldObject signals if available ---
        vx = vy = None
        speed = None
        ax = None
        ttc = None
        closing = None
        predicted_conflict = False
        yaw_rate = None
        dist = None
        hypo_behaviors: set = set()

        if obj is not None:
            vx = obj.velocity.vx
            vy = obj.velocity.vy
            speed = obj.velocity.speed_ms
            ax = obj.velocity.ax
            ttc = obj.collision.ttc_s
            closing = obj.collision.closing_speed_ms
            predicted_conflict = obj.collision.predicted_conflict
            yaw_rate = obj.motion.yaw_rate_rads
            dist = obj.position.distance_m
            for h in obj.prediction.hypotheses[:3]:
                hypo_behaviors.add(str(h.get("behaviour", "")).upper())

        lat_ratio = 0.0
        if vx is not None and vy is not None:
            total = abs(vx) + abs(vy) + 1e-6
            lat_ratio = abs(vy) / total

        # --- Map behavior state → intent candidates ---

        if state == BehaviorState.STATIONARY:
            # Could be yielding, stopped, obstacle
            if closing is not None and closing > 0.5:
                h = self._hypo(
                    entity_id, IntentType.POSSIBLE_STOPPING,
                    0.55, [_ev(_E_SPEED_LOW, EvidenceClass.OBSERVED, 0.7)],
                    EvidenceClass.OBSERVED,
                )
                hypotheses.append(h)
            return hypotheses

        if state == BehaviorState.APPROACHING:
            ev = [_ev(_E_CLOSING_SPEED, EvidenceClass.OBSERVED, 0.8)]
            if predicted_conflict:
                ev.append(_ev(_E_CONFLICT, EvidenceClass.PREDICTED, 0.7))
                ev.append(_ev(_E_TRAJ_INTERSECT, EvidenceClass.PREDICTED, 0.65))
            h = self._hypo(entity_id, IntentType.POSSIBLE_APPROACH, 0.7, ev, EvidenceClass.OBSERVED)
            hypotheses.append(h)

        if state == BehaviorState.RECEDING:
            h = self._hypo(
                entity_id, IntentType.POSSIBLE_DEPARTURE,
                0.65, [_ev("RECEDING_OBSERVED", EvidenceClass.OBSERVED, 0.7)],
                EvidenceClass.OBSERVED,
            )
            hypotheses.append(h)

        if state in (BehaviorState.CROSSING, BehaviorState.LATERAL_MOVEMENT):
            ev = [_ev(_E_LAT_MOTION, EvidenceClass.OBSERVED, 0.75)]
            if predicted_conflict:
                ev.append(_ev(_E_TRAJ_INTERSECT, EvidenceClass.PREDICTED, 0.7))
            if "CROSSING" in hypo_behaviors:
                ev.append(_ev(_E_HYPO_CROSSING, EvidenceClass.PREDICTED, 0.6))
            conf = 0.65 + (0.1 if predicted_conflict else 0.0)
            h = self._hypo(entity_id, IntentType.POSSIBLE_CROSSING, min(0.85, conf), ev, EvidenceClass.INFERRED)
            hypotheses.append(h)

        if state == BehaviorState.TURNING:
            ev = [_ev(_E_HEADING_CHANGE, EvidenceClass.OBSERVED, 0.75)]
            if yaw_rate is not None:
                ev.append(_ev("YAW_RATE_HIGH", EvidenceClass.OBSERVED, 0.7))
            if "TURNING" in hypo_behaviors or "TURN" in hypo_behaviors:
                ev.append(_ev(_E_HYPO_TURN, EvidenceClass.PREDICTED, 0.6))
            h = self._hypo(entity_id, IntentType.POSSIBLE_TURNING, 0.65, ev, EvidenceClass.INFERRED)
            hypotheses.append(h)

        if state == BehaviorState.MERGING:
            ev = [_ev(_E_LAT_VEL_HIGH, EvidenceClass.OBSERVED, 0.7)]
            if "MERGING" in hypo_behaviors or "LANE_CHANGE" in hypo_behaviors:
                ev.append(_ev(_E_HYPO_MERGE, EvidenceClass.PREDICTED, 0.6))
            h = self._hypo(entity_id, IntentType.POSSIBLE_MERGING, 0.60, ev, EvidenceClass.INFERRED)
            hypotheses.append(h)

        if state in (BehaviorState.STOPPING, BehaviorState.DECELERATING):
            ev = [_ev(_E_DECEL, EvidenceClass.OBSERVED, 0.75)]
            if "STOPPING" in hypo_behaviors or "STOP" in hypo_behaviors:
                ev.append(_ev(_E_HYPO_STOP, EvidenceClass.PREDICTED, 0.6))
            h = self._hypo(entity_id, IntentType.POSSIBLE_STOPPING, 0.65, ev, EvidenceClass.INFERRED)
            hypotheses.append(h)

        if state == BehaviorState.MOVING:
            # Possibly lane-following
            ev = [_ev("SPEED_STABLE", EvidenceClass.OBSERVED, 0.5)]
            h = self._hypo(entity_id, IntentType.POSSIBLE_LANE_FOLLOWING, 0.45, ev, EvidenceClass.INFERRED)
            hypotheses.append(h)

        # --- Indian-road specific intent patterns ---
        # Only when supported by actual evidence, never from object type alone.

        if has_indian_context and obj is not None:
            otype = obj.object_type.upper()
            osubtype = obj.object_subtype.upper()

            # Pedestrian or cattle near drivable boundary → road entry tendency
            is_vru = otype in ("PEDESTRIAN", "CYCLIST", "CATTLE")
            if is_vru and road_is_narrow:
                ev = [_ev(_E_NEAR_BOUNDARY, EvidenceClass.INFERRED, 0.55)]
                if state in (BehaviorState.LATERAL_MOVEMENT, BehaviorState.CROSSING,
                             BehaviorState.MOVING, BehaviorState.APPROACHING):
                    ev.append(_ev(_E_ROAD_APPROACH, EvidenceClass.INFERRED, 0.5))
                    h = self._hypo(
                        entity_id, IntentType.POSSIBLE_ROAD_ENTRY,
                        0.50, ev, EvidenceClass.INFERRED
                    )
                    hypotheses.append(h)

            # Wrong-side vehicle pattern
            is_vehicle = otype in ("VEHICLE", "CAR", "TRUCK", "BUS")
            if is_vehicle and vx is not None and vx < 0 and closing and closing > 2.0:
                ev = [
                    _ev(_E_WRONG_SIDE, EvidenceClass.INFERRED, 0.65),
                    _ev(_E_CLOSING_SPEED, EvidenceClass.OBSERVED, 0.75),
                ]
                h = self._hypo(
                    entity_id, IntentType.POSSIBLE_WRONG_SIDE,
                    0.55, ev, EvidenceClass.INFERRED
                )
                hypotheses.append(h)

            # Motorcycle lateral overtake pattern (only if lateral motion observed)
            is_moto = "MOTORCYCLE" in otype or "SCOOTER" in osubtype or "MOTORCYCLE" in osubtype
            if is_moto and lat_ratio > 0.35 and speed and speed > 3.0:
                ev = [
                    _ev(_E_LAT_MOTION, EvidenceClass.OBSERVED, 0.6),
                    _ev(_E_LAT_VEL_HIGH, EvidenceClass.OBSERVED, 0.55),
                ]
                h = self._hypo(
                    entity_id, IntentType.POSSIBLE_OVERTAKING,
                    0.45, ev, EvidenceClass.INFERRED
                )
                hypotheses.append(h)

        # Cap hypotheses per entity
        return hypotheses[: self._cfg.max_intent_per_entity]

    @staticmethod
    def _hypo(
        entity_id: str,
        intent: IntentType,
        confidence: float,
        evidence: List[BehaviorEvidenceItem],
        ecls: EvidenceClass,
    ) -> IntentHypothesis:
        uncertainty = round(1.0 - confidence, 3)
        confidence = round(confidence, 3)
        return IntentHypothesis(
            entity_id=entity_id,
            intent_type=intent,
            confidence=confidence,
            uncertainty=uncertainty,
            evidence_class=ecls,
            evidence=evidence,
        )
