"""
IndiDrive AI — Phase 8.3 | Decision & Action Abstraction Data Contracts
========================================================================
Strongly-typed, compact data containers for Phase 8.3 output.

Phase 8.3 answers:
    «"What KIND of response does the current situation require?"»

Phase 8.3 does NOT answer:
    «"Which exact path should the vehicle take?"»
    «"What steering / throttle / brake commands are needed?"»

That belongs to Phase 9 (path planning) and Phase 8.4 (arbitration).

Design rules (same as all prior phases):
  * dataclasses — not raw dicts
  * explicit NOT_AVAILABLE / unknown — never fabricated
  * no path planning, no steering, no throttle, no MPC
  * confidence ≠ uncertainty ≠ severity ≠ urgency — kept separate
  * deterministic: same input → same output
  * compact: bounded lists, summaries only
  * immutable snapshots (ActionAbstractionSnapshot)
  * offline — no LLM, no cloud, no neural networks

This module contains ONLY structural containers.
Computation lives in action_abstraction_engine.py.
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from enum import Enum
from typing import List, Optional, Tuple

__all__ = [
    # Sentinel / schema
    "NOT_AVAILABLE",
    "ACTION_ABSTRACTION_SCHEMA_VERSION",
    # Enums
    "RequirementType",
    "ResponseFamily",
    "AbstractUrgency",
    "AbstractSeverity",
    "EvidenceType",
    "RequirementRelationship",
    "AbstractionValidationStatus",
    # Data structures
    "DecisionRequirement",
    "RequirementRelationshipEntry",
    "ActionAbstractionSnapshot",
    "ActionAbstractionResult",
]

NOT_AVAILABLE = "NOT_AVAILABLE"
ACTION_ABSTRACTION_SCHEMA_VERSION = "8.3"


# ---------------------------------------------------------------------------
# Requirement type — the abstract «what kind of response?» answer
# ---------------------------------------------------------------------------

class RequirementType(str, Enum):
    """
    Abstract response requirement type.

    These are ABSTRACT REQUIREMENTS — not vehicle commands.

    ALLOWED:
      COLLISION_AVOIDANCE_REQUIRED, MAINTAIN_SAFE_SPACE, etc.

    NOT ALLOWED:
      STEER_LEFT, BRAKE_NOW, THROTTLE_UP, etc. (those belong to Phase 9)
    """
    # --- Normal operation ---
    NORMAL_PROGRESS             = "NORMAL_PROGRESS"
    MAINTAIN_SAFE_SPACE         = "MAINTAIN_SAFE_SPACE"

    # --- Collision / conflict ---
    COLLISION_AVOIDANCE_REQUIRED = "COLLISION_AVOIDANCE_REQUIRED"
    HANDLE_TRAJECTORY_CONFLICT  = "HANDLE_TRAJECTORY_CONFLICT"

    # --- Vulnerable road users ---
    HANDLE_VULNERABLE_USER      = "HANDLE_VULNERABLE_USER"

    # --- Road hazards ---
    HANDLE_ROAD_HAZARD          = "HANDLE_ROAD_HAZARD"
    MAINTAIN_DRIVABLE_REGION    = "MAINTAIN_DRIVABLE_REGION"
    HANDLE_NARROW_ROAD          = "HANDLE_NARROW_ROAD"

    # --- Road structure ---
    HANDLE_INTERSECTION         = "HANDLE_INTERSECTION"
    HANDLE_MERGE                = "HANDLE_MERGE"

    # --- Monitoring ---
    MONITOR_DYNAMIC_OBJECT      = "MONITOR_DYNAMIC_OBJECT"
    MONITOR_UNPREDICTABLE_OBJECT = "MONITOR_UNPREDICTABLE_OBJECT"

    # --- Uncertainty / degradation ---
    HANDLE_UNCERTAINTY          = "HANDLE_UNCERTAINTY"
    DEGRADED_OPERATION          = "DEGRADED_OPERATION"


# ---------------------------------------------------------------------------
# Response family — higher-level compact abstraction
# ---------------------------------------------------------------------------

class ResponseFamily(str, Enum):
    """
    High-level response family — compact abstraction for downstream arbitration.

    NOT a maneuver.  NOT LEFT / RIGHT / BRAKE / ACCELERATE.
    Only an abstract family label for Phase 8.4.
    """
    NORMAL              = "NORMAL"
    CAUTION             = "CAUTION"
    SAFETY_CRITICAL     = "SAFETY_CRITICAL"
    HAZARD_HANDLING     = "HAZARD_HANDLING"
    CONFLICT_HANDLING   = "CONFLICT_HANDLING"
    DEGRADED            = "DEGRADED"
    UNCERTAINTY_MANAGEMENT = "UNCERTAINTY_MANAGEMENT"
    UNKNOWN             = "UNKNOWN"


# ---------------------------------------------------------------------------
# Urgency
# ---------------------------------------------------------------------------

class AbstractUrgency(str, Enum):
    """
    Temporal urgency of a decision requirement.

    IMMEDIATE — must be addressed this processing cycle.
    HIGH      — must be addressed within the near TTC band.
    MEDIUM    — should be addressed within the moderate TTC band.
    LOW       — can be addressed over multiple cycles.
    NONE      — no time pressure.
    UNKNOWN   — timing information unavailable.
    """
    IMMEDIATE = "IMMEDIATE"
    HIGH      = "HIGH"
    MEDIUM    = "MEDIUM"
    LOW       = "LOW"
    NONE      = "NONE"
    UNKNOWN   = "UNKNOWN"


# ---------------------------------------------------------------------------
# Severity
# ---------------------------------------------------------------------------

class AbstractSeverity(str, Enum):
    """
    Severity of the situation underlying a decision requirement.

    Severity and urgency are kept SEPARATE.

    Example valid combination:
        severity=HIGH, urgency=LOW
        (serious threat that is currently not time-critical)

    Another valid combination:
        severity=MEDIUM, urgency=IMMEDIATE
        (moderate threat but TTC is very short)
    """
    CRITICAL = "CRITICAL"
    HIGH     = "HIGH"
    MEDIUM   = "MEDIUM"
    LOW      = "LOW"
    NONE     = "NONE"
    UNKNOWN  = "UNKNOWN"


# ---------------------------------------------------------------------------
# Evidence type
# ---------------------------------------------------------------------------

class EvidenceType(str, Enum):
    """
    Epistemological class of the evidence underlying a requirement.

    OBSERVED  — directly seen in current world-model data.
    INFERRED  — derived from observable dynamics with explicit evidence.
    PREDICTED — from prediction hypotheses (not yet confirmed).
    COMBINED  — mixture of observed, inferred, and/or predicted.
    UNKNOWN   — evidence class cannot be determined.
    """
    OBSERVED  = "OBSERVED"
    INFERRED  = "INFERRED"
    PREDICTED = "PREDICTED"
    COMBINED  = "COMBINED"
    UNKNOWN   = "UNKNOWN"


# ---------------------------------------------------------------------------
# Requirement relationship
# ---------------------------------------------------------------------------

class RequirementRelationship(str, Enum):
    """Relationship between two simultaneously active requirements."""
    COMPATIBLE  = "COMPATIBLE"   # can both be addressed together
    CONFLICTING = "CONFLICTING"  # addressing one may impede the other
    SUPPORTING  = "SUPPORTING"   # addressing one helps address the other
    DEPENDENT   = "DEPENDENT"    # one depends on the other being satisfied


# ---------------------------------------------------------------------------
# Validation status
# ---------------------------------------------------------------------------

class AbstractionValidationStatus(str, Enum):
    """Result of validating an ActionAbstractionSnapshot."""
    VALID    = "VALID"
    PARTIAL  = "PARTIAL"
    DEGRADED = "DEGRADED"
    INVALID  = "INVALID"


# ---------------------------------------------------------------------------
# DecisionRequirement — the core output unit
# ---------------------------------------------------------------------------

@dataclass
class DecisionRequirement:
    """
    One abstract decision requirement for the current situation.

    This is an ABSTRACT REQUIREMENT — not a vehicle command.

    It answers: «"What kind of response is required?"»
    It does NOT answer: «"What exact path / steering / throttle?"»

    Fields
    ------
    requirement_id : unique identifier for this requirement instance.
    requirement_type : abstract requirement category (RequirementType).
    priority : deterministic priority score [0, 1]; 1 = highest.
    urgency : temporal urgency classification.
    severity : severity of the underlying situation.
    confidence : confidence in this requirement [0, 1].
    uncertainty : uncertainty in this requirement [0, 1].
    evidence_type : epistemological class of supporting evidence.
    source : which upstream module primarily triggered this.
    affected_entity_ids : entities this requirement relates to.
    affected_region : compact description of affected road region.
    time_relevance_s : approximate time horizon (seconds); None = unknown.
    reason_codes : deterministic structured reason codes (NOT free text).
    constraints_summary : compact abstract constraints for Phase 8.4.
    is_safety_critical : True when this requirement affects safety.
    timestamp : when this requirement was generated.
    frame_id : associated processing frame.
    schema_version : Phase 8.3 schema version.
    """
    requirement_id: str = NOT_AVAILABLE
    requirement_type: RequirementType = RequirementType.HANDLE_UNCERTAINTY
    priority: float = 0.0                          # [0, 1]; 1 = highest
    urgency: AbstractUrgency = AbstractUrgency.UNKNOWN
    severity: AbstractSeverity = AbstractSeverity.UNKNOWN
    confidence: float = 0.0                        # [0, 1]
    uncertainty: float = 1.0                       # [0, 1]
    evidence_type: EvidenceType = EvidenceType.UNKNOWN
    source: str = NOT_AVAILABLE                    # "phase_8_1" | "phase_8_2" | "combined" | ...
    affected_entity_ids: Tuple[str, ...] = field(default_factory=tuple)
    affected_region: str = NOT_AVAILABLE           # compact string; NOT coordinates
    time_relevance_s: Optional[float] = None       # None = unknown
    reason_codes: Tuple[str, ...] = field(default_factory=tuple)
    constraints_summary: str = NOT_AVAILABLE       # abstract constraints for 8.4
    is_safety_critical: bool = False
    timestamp: float = field(default_factory=time.time)
    frame_id: int = 0
    schema_version: str = ACTION_ABSTRACTION_SCHEMA_VERSION

    def to_dict(self) -> dict:
        return {
            "requirement_id": self.requirement_id,
            "requirement_type": self.requirement_type.value,
            "priority": round(self.priority, 4),
            "urgency": self.urgency.value,
            "severity": self.severity.value,
            "confidence": round(self.confidence, 3),
            "uncertainty": round(self.uncertainty, 3),
            "evidence_type": self.evidence_type.value,
            "source": self.source,
            "affected_entity_ids": list(self.affected_entity_ids),
            "affected_region": self.affected_region,
            "time_relevance_s": (
                round(self.time_relevance_s, 3)
                if self.time_relevance_s is not None
                else NOT_AVAILABLE
            ),
            "reason_codes": list(self.reason_codes),
            "constraints_summary": self.constraints_summary,
            "is_safety_critical": self.is_safety_critical,
            "timestamp": self.timestamp,
            "frame_id": self.frame_id,
            "schema_version": self.schema_version,
        }


# ---------------------------------------------------------------------------
# Requirement relationship entry
# ---------------------------------------------------------------------------

@dataclass
class RequirementRelationshipEntry:
    """
    Relationship between two simultaneously active requirements.

    Phase 8.3 exposes relationships — it does NOT arbitrate between them.
    Final arbitration belongs to Phase 8.4.
    """
    requirement_id_a: str = NOT_AVAILABLE
    requirement_id_b: str = NOT_AVAILABLE
    relationship: RequirementRelationship = RequirementRelationship.COMPATIBLE
    note: str = NOT_AVAILABLE              # compact reason code, NOT free text

    def to_dict(self) -> dict:
        return {
            "requirement_id_a": self.requirement_id_a,
            "requirement_id_b": self.requirement_id_b,
            "relationship": self.relationship.value,
            "note": self.note,
        }


# ---------------------------------------------------------------------------
# Primary output: ActionAbstractionSnapshot
# ---------------------------------------------------------------------------

@dataclass
class ActionAbstractionSnapshot:
    """
    One immutable Phase 8.3 output for a single processing cycle.

    Consumers MUST NOT mutate this object.
    Repeated identical input → identical output (deterministic).

    This is an ABSTRACTION LAYER output only.
    It does NOT contain:
      - steering commands
      - throttle commands
      - braking commands
      - path, trajectory, or waypoints
      - lane-change or overtaking decisions
      - target speed
      - vehicle control of any kind
      - LLM output
      - cloud reasoning output

    It provides abstract decision requirements only.
    """
    schema_version: str = ACTION_ABSTRACTION_SCHEMA_VERSION
    timestamp: float = field(default_factory=time.time)
    frame_id: int = 0

    # --- Abstract requirements (bounded immutable tuple, highest priority first) ---
    _requirements: Tuple[DecisionRequirement, ...] = field(
        default_factory=tuple, repr=False
    )

    # --- Requirement relationships ---
    _relationships: Tuple[RequirementRelationshipEntry, ...] = field(
        default_factory=tuple, repr=False
    )

    # --- Higher-level response family ---
    response_family: ResponseFamily = ResponseFamily.UNKNOWN

    # --- Overall urgency and severity (aggregate of all requirements) ---
    overall_urgency: AbstractUrgency = AbstractUrgency.UNKNOWN
    overall_severity: AbstractSeverity = AbstractSeverity.UNKNOWN

    # --- Safety-critical flag: True if any requirement is safety-critical ---
    any_safety_critical: bool = False

    # --- Overall confidence / uncertainty ---
    confidence: float = 0.0
    uncertainty: float = 1.0

    # --- Input completeness: how complete were upstream inputs? ---
    input_completeness: float = 0.0   # [0, 1]

    # --- Degraded flag ---
    degraded: bool = False

    # --- Reason codes for overall abstraction state ---
    reason_codes: Tuple[str, ...] = field(default_factory=tuple)

    # --- Source frame IDs from upstream ---
    situation_frame_id: int = 0
    behavior_frame_id: int = 0

    # ------------------------------------------------------------------
    # Safe read-only properties
    # ------------------------------------------------------------------

    @property
    def requirements(self) -> Tuple[DecisionRequirement, ...]:
        """Read-only tuple of DecisionRequirement, highest priority first."""
        return self._requirements

    @property
    def relationships(self) -> Tuple[RequirementRelationshipEntry, ...]:
        """Read-only tuple of RequirementRelationshipEntry."""
        return self._relationships

    @property
    def requirement_count(self) -> int:
        return len(self._requirements)

    @property
    def relationship_count(self) -> int:
        return len(self._relationships)

    @property
    def safety_critical_requirements(self) -> Tuple[DecisionRequirement, ...]:
        return tuple(r for r in self._requirements if r.is_safety_critical)

    @property
    def highest_priority_requirement(self) -> Optional[DecisionRequirement]:
        return self._requirements[0] if self._requirements else None

    # ------------------------------------------------------------------
    # Serialisation
    # ------------------------------------------------------------------

    def to_dict(self) -> dict:
        return {
            "schema_version": self.schema_version,
            "timestamp": self.timestamp,
            "frame_id": self.frame_id,
            "response_family": self.response_family.value,
            "overall_urgency": self.overall_urgency.value,
            "overall_severity": self.overall_severity.value,
            "any_safety_critical": self.any_safety_critical,
            "confidence": round(self.confidence, 3),
            "uncertainty": round(self.uncertainty, 3),
            "input_completeness": round(self.input_completeness, 3),
            "degraded": self.degraded,
            "requirement_count": self.requirement_count,
            "requirements": [r.to_dict() for r in self._requirements],
            "relationship_count": self.relationship_count,
            "relationships": [r.to_dict() for r in self._relationships],
            "reason_codes": list(self.reason_codes),
            "situation_frame_id": self.situation_frame_id,
            "behavior_frame_id": self.behavior_frame_id,
        }


# ---------------------------------------------------------------------------
# Build result wrapper
# ---------------------------------------------------------------------------

@dataclass
class ActionAbstractionResult:
    """
    Return value of ActionAbstractionEngine.generate().

    Always present — never raises on partial or invalid input.
    The snapshot is always a valid ActionAbstractionSnapshot even
    when input data is degraded or empty.
    """
    snapshot: ActionAbstractionSnapshot
    status: str = "ok"         # ok | degraded | empty | error
    warnings: List[str] = field(default_factory=list)
    errors: List[str] = field(default_factory=list)
    duration_s: float = 0.0

    @property
    def is_valid(self) -> bool:
        return self.status in ("ok", "degraded", "empty")

    def to_dict(self) -> dict:
        return {
            "snapshot": self.snapshot.to_dict(),
            "status": self.status,
            "warnings": list(self.warnings),
            "errors": list(self.errors),
            "duration_s": round(self.duration_s, 6),
        }
