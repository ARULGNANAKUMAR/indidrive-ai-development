"""
IndiDrive AI — Phase 8.2 | Behavior Classifier
================================================
Lightweight deterministic behavior classification for each relevant
entity in the World Model.

Consumes WorldObject motion/prediction/collision data.
Produces BehaviorClassification — no planning, no steering, no control.

Design:
  - Deterministic: same WorldObject → same BehaviorClassification
  - Bounded: only processes objects within configured distance
  - Evidence-first: every state backed by explicit reason codes
  - Uncertainty-aware: conflicting evidence → UNCERTAIN + competing states
  - Indian-road aware: recognizes relevant local patterns
  - Does NOT rebuild Kalman filter or prediction
  - Does NOT use LLM or cloud
"""
from __future__ import annotations

import math
from typing import List, Optional, Tuple

from core.world_model.world_model_types import WorldObject, NOT_AVAILABLE

from .behavior_types import (
    BehaviorClassification,
    BehaviorEvidenceItem,
    BehaviorState,
    EvidenceClass,
)
from .behavior_reasoning_config import BehaviorReasoningConfig

__all__ = ["BehaviorClassifier"]

# ---------------------------------------------------------------------------
# Evidence reason codes (structured, not natural language)
# ---------------------------------------------------------------------------
_E_ZERO_SPEED        = "SPEED_NEAR_ZERO"
_E_SPEED_POSITIVE    = "SPEED_POSITIVE"
_E_REL_SPEED_POS     = "RELATIVE_SPEED_POSITIVE"        # closing
_E_REL_SPEED_NEG     = "RELATIVE_SPEED_NEGATIVE"        # receding
_E_LAT_DISP_INC      = "LATERAL_DISPLACEMENT_INCREASING"
_E_LAT_VEL_HIGH      = "LATERAL_VELOCITY_HIGH"
_E_LONG_VEL_DOM      = "LONGITUDINAL_VELOCITY_DOMINANT"
_E_HEADING_CHANGE    = "HEADING_CHANGE"
_E_YAW_HIGH          = "YAW_RATE_HIGH"
_E_TTC_FINITE        = "TTC_FINITE"
_E_TTC_DEC           = "TTC_DECREASING"
_E_TRAJ_INTERSECT    = "TRAJECTORY_INTERSECTION"
_E_TRAJ_CROSSING     = "TRAJECTORY_CROSSING_PATTERN"
_E_ACCEL_POS         = "ACCELERATION_POSITIVE"
_E_ACCEL_NEG         = "ACCELERATION_NEGATIVE"
_E_CLOSE_DIST        = "CLOSE_DISTANCE"
_E_CONFLICT          = "PREDICTED_CONFLICT"
_E_HYPO_CROSSING     = "HYPOTHESIS_CROSSING"
_E_HYPO_TURN         = "HYPOTHESIS_TURNING"
_E_HYPO_MERGE        = "HYPOTHESIS_MERGING"
_E_HYPO_STOP         = "HYPOTHESIS_STOPPING"
_E_STALE             = "DATA_STALE"
_E_LOW_CONF          = "LOW_CONFIDENCE"


def _ev(code: str, cls: EvidenceClass, strength: float = 0.6) -> BehaviorEvidenceItem:
    return BehaviorEvidenceItem(code=code, evidence_class=cls, strength=strength)


class BehaviorClassifier:
    """
    Classifies the behavior state of each WorldObject.

    All classification is deterministic, bounded, and uncertainty-aware.
    """

    def __init__(self, config: BehaviorReasoningConfig) -> None:
        self._cfg = config

    def classify_all(
        self,
        objects: tuple,
        now: float,
    ) -> List[BehaviorClassification]:
        """
        Classify behavior for every relevant object.

        Objects beyond max_interaction_distance_m are skipped.
        Returns a bounded list, highest-priority objects first.
        """
        results: List[BehaviorClassification] = []
        for obj in objects:
            dist = obj.position.distance_m
            if dist is not None and dist > self._cfg.max_interaction_distance_m:
                continue
            bc = self._classify_one(obj, now)
            results.append(bc)
            if len(results) >= self._cfg.max_behavior_entities:
                break
        return results

    def _classify_one(self, obj: WorldObject, now: float) -> BehaviorClassification:
        """Build a BehaviorClassification for one WorldObject."""
        entity_id = obj.primary_id() or NOT_AVAILABLE
        is_stale = obj.quality.is_stale

        evidence: List[BehaviorEvidenceItem] = []
        competing: List[Tuple[BehaviorState, float]] = []

        # --- Gather raw motion signals ---
        speed = obj.velocity.speed_ms
        vx = obj.velocity.vx
        vy = obj.velocity.vy
        ax = obj.velocity.ax
        ay = obj.velocity.ay
        yaw = obj.motion.yaw_rate_rads
        is_moving = obj.motion.is_moving
        dist = obj.position.distance_m
        closing = obj.collision.closing_speed_ms  # positive = closing
        ttc = obj.collision.ttc_s
        predicted_conflict = obj.collision.predicted_conflict

        # Staleness evidence
        if is_stale:
            evidence.append(_ev(_E_STALE, EvidenceClass.OBSERVED, 0.3))
        if obj.quality.object_confidence < self._cfg.low_confidence_threshold:
            evidence.append(_ev(_E_LOW_CONF, EvidenceClass.OBSERVED, 0.2))

        # Prediction hypotheses (use as supporting evidence only)
        hypo_behaviors = set()
        if obj.prediction.hypotheses:
            for h in obj.prediction.hypotheses[:3]:
                beh = str(h.get("behaviour", "")).upper()
                hypo_behaviors.add(beh)

        # ------------------------------------------------------------------
        # Classification logic
        # ------------------------------------------------------------------

        # 1. Stationary check
        if speed is not None and speed < self._cfg.stationary_speed_threshold_ms:
            if not is_moving:
                evidence.append(_ev(_E_ZERO_SPEED, EvidenceClass.OBSERVED, 0.9))
                return self._make(
                    obj, BehaviorState.STATIONARY, 0.85, 0.15,
                    EvidenceClass.OBSERVED, evidence, competing
                )

        # Determine if there are conflicting signals
        signals = []

        # Lateral vs longitudinal motion
        lat_ratio = 0.0
        if vx is not None and vy is not None:
            total = abs(vx) + abs(vy) + 1e-6
            lat_ratio = abs(vy) / total
        elif vy is not None and speed and speed > 0:
            lat_ratio = abs(vy) / (speed + 1e-6)

        high_lat = lat_ratio > self._cfg.lateral_motion_ratio_threshold

        # Heading change
        high_yaw = yaw is not None and abs(yaw) > self._cfg.turning_yaw_threshold_rads

        # Approaching vs receding
        approaching = closing is not None and closing > self._cfg.approaching_speed_threshold_ms
        receding = (
            closing is not None and closing < -self._cfg.approaching_speed_threshold_ms
        ) or (
            closing is None and dist is not None and vx is not None and vx < 0
        )

        # Acceleration signals
        has_accel = (
            (ax is not None and ax > self._cfg.acceleration_threshold_ms2) or
            (ay is not None and abs(ay) > self._cfg.acceleration_threshold_ms2)
        )
        has_decel = ax is not None and ax < -self._cfg.deceleration_threshold_ms2

        # Stopping: decelerating toward zero
        stopping = (
            has_decel and speed is not None and speed < self._cfg.stopping_speed_threshold_ms
        )

        # 2. Classify with conflict detection
        if is_stale:
            # Low reliability — use UNKNOWN if we have no strong signal
            if predicted_conflict:
                evidence.append(_ev(_E_CONFLICT, EvidenceClass.PREDICTED, 0.5))
                state = BehaviorState.APPROACHING
                conf, unc = 0.35, 0.65
                ecls = EvidenceClass.PREDICTED
            else:
                state = BehaviorState.UNKNOWN
                conf, unc = 0.1, 0.9
                ecls = EvidenceClass.UNKNOWN
            return self._make(obj, state, conf, unc, ecls, evidence, competing)

        if not is_moving and (speed is None or speed < self._cfg.stationary_speed_threshold_ms):
            evidence.append(_ev(_E_ZERO_SPEED, EvidenceClass.OBSERVED, 0.8))
            return self._make(
                obj, BehaviorState.STATIONARY, 0.8, 0.2,
                EvidenceClass.OBSERVED, evidence, competing
            )

        evidence.append(_ev(_E_SPEED_POSITIVE, EvidenceClass.OBSERVED, 0.7))

        # Check for trajectory crossing in hypotheses
        hypo_crossing = any(
            beh in ("CROSSING", "LANE_CHANGE", "CUT_IN") for beh in hypo_behaviors
        )
        hypo_turning = any(beh in ("TURNING", "TURN") for beh in hypo_behaviors)
        hypo_merging = any(beh in ("MERGING", "MERGE", "LANE_CHANGE") for beh in hypo_behaviors)
        hypo_stopping = any(beh in ("STOPPING", "STOP", "DECELERATING") for beh in hypo_behaviors)

        if hypo_crossing:
            evidence.append(_ev(_E_HYPO_CROSSING, EvidenceClass.PREDICTED, 0.5))
        if hypo_turning:
            evidence.append(_ev(_E_HYPO_TURN, EvidenceClass.PREDICTED, 0.5))
        if hypo_merging:
            evidence.append(_ev(_E_HYPO_MERGE, EvidenceClass.PREDICTED, 0.5))
        if hypo_stopping:
            evidence.append(_ev(_E_HYPO_STOP, EvidenceClass.PREDICTED, 0.5))

        if predicted_conflict:
            evidence.append(_ev(_E_CONFLICT, EvidenceClass.PREDICTED, 0.7))
            evidence.append(_ev(_E_TRAJ_INTERSECT, EvidenceClass.PREDICTED, 0.65))

        # Conflict detection: multiple dominant signals
        dominant_signals = []
        if high_lat:
            dominant_signals.append(BehaviorState.CROSSING)
            evidence.append(_ev(_E_LAT_DISP_INC, EvidenceClass.INFERRED, 0.6))
            evidence.append(_ev(_E_LAT_VEL_HIGH, EvidenceClass.OBSERVED, 0.65))
        if high_yaw:
            dominant_signals.append(BehaviorState.TURNING)
            evidence.append(_ev(_E_YAW_HIGH, EvidenceClass.OBSERVED, 0.7))
            evidence.append(_ev(_E_HEADING_CHANGE, EvidenceClass.INFERRED, 0.65))
        if approaching:
            dominant_signals.append(BehaviorState.APPROACHING)
            evidence.append(_ev(_E_REL_SPEED_POS, EvidenceClass.OBSERVED, 0.8))
            evidence.append(_ev(_E_TTC_FINITE, EvidenceClass.OBSERVED, 0.7))
        if stopping:
            dominant_signals.append(BehaviorState.STOPPING)
            evidence.append(_ev(_E_ACCEL_NEG, EvidenceClass.OBSERVED, 0.7))
        if has_accel and not stopping:
            dominant_signals.append(BehaviorState.ACCELERATING)
            evidence.append(_ev(_E_ACCEL_POS, EvidenceClass.OBSERVED, 0.6))
        if has_decel and not stopping:
            dominant_signals.append(BehaviorState.DECELERATING)
            evidence.append(_ev(_E_ACCEL_NEG, EvidenceClass.OBSERVED, 0.6))
        if receding:
            dominant_signals.append(BehaviorState.RECEDING)
            evidence.append(_ev(_E_REL_SPEED_NEG, EvidenceClass.OBSERVED, 0.7))

        # Conflict → UNCERTAIN
        distinct_dominant = list(dict.fromkeys(dominant_signals))  # preserve order, dedupe
        if len(distinct_dominant) >= 2:
            # Build competing hypotheses
            for ds in distinct_dominant[:self._cfg.max_behavior_hypotheses]:
                competing.append((ds, 0.5 / len(distinct_dominant)))
            return self._make(
                obj, BehaviorState.UNCERTAIN,
                0.3, 0.7, EvidenceClass.INFERRED, evidence, competing
            )

        # Single dominant state
        if distinct_dominant:
            state = distinct_dominant[0]
            conf, unc = self._state_confidence(state, evidence)
            ecls = self._state_evidence_class(state, predicted_conflict, hypo_crossing)
            return self._make(obj, state, conf, unc, ecls, evidence, competing)

        # No dominant: Moving (generic)
        if not high_lat:
            evidence.append(_ev(_E_LONG_VEL_DOM, EvidenceClass.OBSERVED, 0.5))
        return self._make(
            obj, BehaviorState.MOVING, 0.55, 0.45,
            EvidenceClass.OBSERVED, evidence, competing
        )

    @staticmethod
    def _state_confidence(
        state: BehaviorState,
        evidence: List[BehaviorEvidenceItem],
    ) -> Tuple[float, float]:
        """Derive confidence/uncertainty from evidence quality."""
        if not evidence:
            return 0.3, 0.7
        observed = [e for e in evidence if e.evidence_class == EvidenceClass.OBSERVED]
        inferred = [e for e in evidence if e.evidence_class == EvidenceClass.INFERRED]
        predicted = [e for e in evidence if e.evidence_class == EvidenceClass.PREDICTED]
        stale = any(e.code == _E_STALE for e in evidence)
        low_conf = any(e.code == _E_LOW_CONF for e in evidence)

        base = 0.6
        if observed:
            base += 0.1 * min(len(observed), 3)
        if inferred:
            base += 0.05 * min(len(inferred), 2)
        if predicted and not observed:
            base -= 0.1
        if stale:
            base -= 0.2
        if low_conf:
            base -= 0.1

        conf = max(0.05, min(0.95, base))
        return round(conf, 3), round(1.0 - conf, 3)

    @staticmethod
    def _state_evidence_class(
        state: BehaviorState,
        predicted_conflict: bool,
        hypo_crossing: bool,
    ) -> EvidenceClass:
        """Determine highest-quality evidence class for the state."""
        if state in (BehaviorState.CROSSING, BehaviorState.TURNING,
                     BehaviorState.MERGING, BehaviorState.LATERAL_MOVEMENT):
            if hypo_crossing:
                return EvidenceClass.PREDICTED
            return EvidenceClass.INFERRED
        if state == BehaviorState.APPROACHING and predicted_conflict:
            return EvidenceClass.PREDICTED
        if state in (BehaviorState.STATIONARY, BehaviorState.MOVING,
                     BehaviorState.ACCELERATING, BehaviorState.DECELERATING):
            return EvidenceClass.OBSERVED
        return EvidenceClass.INFERRED

    def _make(
        self,
        obj: WorldObject,
        state: BehaviorState,
        conf: float,
        unc: float,
        ecls: EvidenceClass,
        evidence: List[BehaviorEvidenceItem],
        competing: List[Tuple[BehaviorState, float]],
    ) -> BehaviorClassification:
        return BehaviorClassification(
            entity_id=obj.primary_id() or NOT_AVAILABLE,
            entity_type=obj.object_type,
            entity_subtype=obj.object_subtype,
            behavior_state=state,
            behavior_confidence=round(conf, 3),
            behavior_uncertainty=round(unc, 3),
            evidence_class=ecls,
            evidence=evidence[: self._cfg.max_evidence_items],
            competing_states=competing[: self._cfg.max_behavior_hypotheses],
        )
