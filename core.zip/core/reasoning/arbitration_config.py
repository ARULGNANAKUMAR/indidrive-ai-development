"""
IndiDrive AI — Phase 8.4 | Decision Arbitration & Safety Gate Configuration
=============================================================================
All thresholds and limits governing Phase 8.4 Decision Arbitration.
No magic numbers in the engine — every configurable value lives here.

Loaded from config/reasoning_config.yaml (same file as Phase 8.1 / 8.2 / 8.3).
Phase 8.4 keys use the prefix 'arbitration_' to avoid conflicts.
Unknown keys are silently ignored for forward-compatibility.
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Optional

__all__ = ["ArbitrationConfig", "load_arbitration_config"]

ROOT = Path(__file__).resolve().parent.parent.parent
CONFIG_PATH = ROOT / "config" / "reasoning_config.yaml"


@dataclass
class ArbitrationConfig:
    """
    Configuration for Phase 8.4 decision arbitration layer.
    Safe defaults suitable for Indian road conditions.
    """

    # ------------------------------------------------------------------
    # Enable / disable
    # ------------------------------------------------------------------
    enabled: bool = True
    """Whether Phase 8.4 arbitration is active."""

    deterministic: bool = True
    """Must always be True; flag exists for config validation only."""

    # ------------------------------------------------------------------
    # Collection bounds
    # ------------------------------------------------------------------
    max_active_requirements: int = 12
    """Maximum number of active requirements carried into arbitration."""

    max_constraints: int = 24
    """Maximum total constraints (hard + soft) in a PlanningContext."""

    max_reason_codes: int = 16
    """Maximum reason codes per snapshot."""

    max_conflicts: int = 16
    """Maximum conflict records per snapshot."""

    # ------------------------------------------------------------------
    # Temporal validity thresholds (milliseconds)
    # ------------------------------------------------------------------
    aging_threshold_ms: float = 800.0
    """Requirement age above this (ms) → AGING."""

    stale_threshold_ms: float = 1500.0
    """Requirement age above this (ms) → STALE."""

    critical_stale_threshold_ms: float = 3000.0
    """Requirement age above this (ms) → EXPIRED."""

    # ------------------------------------------------------------------
    # Safety gate thresholds
    # ------------------------------------------------------------------

    # CRITICAL gate
    critical_urgency_values: tuple = ("IMMEDIATE",)
    """AbstractUrgency values that can contribute to CRITICAL gate."""

    critical_severity_values: tuple = ("CRITICAL",)
    """AbstractSeverity values that can contribute to CRITICAL gate."""

    critical_requirement_types: tuple = (
        "COLLISION_AVOIDANCE_REQUIRED",
        "HANDLE_TRAJECTORY_CONFLICT",
        "HANDLE_VULNERABLE_USER",
    )
    """RequirementTypes that, if safety-critical + IMMEDIATE urgency → CRITICAL gate."""

    # HIGH_ALERT gate
    high_alert_priority_threshold: float = 0.70
    """Dominant requirement priority at/above this → HIGH_ALERT (if not CRITICAL)."""

    high_alert_severity_values: tuple = ("CRITICAL", "HIGH")
    """Severity values that can contribute to HIGH_ALERT."""

    high_alert_urgency_values: tuple = ("IMMEDIATE", "HIGH")
    """Urgency values that can contribute to HIGH_ALERT."""

    high_alert_requirement_types: tuple = (
        "COLLISION_AVOIDANCE_REQUIRED",
        "HANDLE_TRAJECTORY_CONFLICT",
        "HANDLE_VULNERABLE_USER",
        "HANDLE_ROAD_HAZARD",
    )

    # RESTRICTED gate
    restricted_uncertainty_threshold: float = 0.65
    """Overall uncertainty at/above this → at least RESTRICTED."""

    restricted_hard_constraint_count: int = 1
    """Hard constraint count at/above this → at least RESTRICTED."""

    restricted_completeness_threshold: float = 0.40
    """World model completeness below this → at least RESTRICTED."""

    # DEGRADED gate
    degraded_completeness_threshold: float = 0.25
    """World model completeness below this → DEGRADED."""

    degraded_uncertainty_threshold: float = 0.85
    """Overall uncertainty above this → DEGRADED."""

    # CAUTION gate
    caution_hazard_priority_min: float = 0.20
    """Any requirement priority at/above this (medium hazard) → at least CAUTION."""

    caution_uncertainty_threshold: float = 0.40
    """Overall uncertainty at/above this → at least CAUTION."""

    # ------------------------------------------------------------------
    # Conflict detection
    # ------------------------------------------------------------------
    conflict_pairs: tuple = (
        ("NORMAL_PROGRESS", "COLLISION_AVOIDANCE_REQUIRED"),
        ("NORMAL_PROGRESS", "HANDLE_TRAJECTORY_CONFLICT"),
        ("NORMAL_PROGRESS", "HANDLE_UNCERTAINTY"),
        ("NORMAL_PROGRESS", "DEGRADED_OPERATION"),
        ("NORMAL_PROGRESS", "HANDLE_VULNERABLE_USER"),
        ("NORMAL_PROGRESS", "HANDLE_ROAD_HAZARD"),
        ("NORMAL_PROGRESS", "MAINTAIN_DRIVABLE_REGION"),
        ("MAINTAIN_DRIVABLE_REGION", "HANDLE_ROAD_HAZARD"),
    )
    """
    Pairs of RequirementType values that conflict.
    Each tuple is (lower_priority_type, higher_priority_type).
    """

    # ------------------------------------------------------------------
    # Priority ordering for tie-breaking (lower index = higher priority)
    # ------------------------------------------------------------------
    requirement_type_priority_order: tuple = (
        "COLLISION_AVOIDANCE_REQUIRED",
        "HANDLE_TRAJECTORY_CONFLICT",
        "HANDLE_VULNERABLE_USER",
        "HANDLE_ROAD_HAZARD",
        "MAINTAIN_DRIVABLE_REGION",
        "HANDLE_INTERSECTION",
        "HANDLE_MERGE",
        "HANDLE_NARROW_ROAD",
        "HANDLE_UNCERTAINTY",
        "DEGRADED_OPERATION",
        "MONITOR_DYNAMIC_OBJECT",
        "MONITOR_UNPREDICTABLE_OBJECT",
        "MAINTAIN_SAFE_SPACE",
        "NORMAL_PROGRESS",
    )
    """Deterministic type-level priority order for tie-breaking."""

    # ------------------------------------------------------------------
    # Hard constraint classification
    # ------------------------------------------------------------------
    hard_constraint_requirement_types: tuple = (
        "COLLISION_AVOIDANCE_REQUIRED",
        "HANDLE_TRAJECTORY_CONFLICT",
        "HANDLE_VULNERABLE_USER",
        "DEGRADED_OPERATION",
    )
    """RequirementTypes that always generate HARD constraints."""

    hard_constraint_severity_values: tuple = ("CRITICAL",)
    """Severity values that promote a constraint to HARD."""

    hard_constraint_urgency_values: tuple = ("IMMEDIATE",)
    """Urgency values that promote a constraint to HARD."""

    hard_constraint_if_safety_critical: bool = True
    """If True, any is_safety_critical requirement generates a HARD constraint."""

    # ------------------------------------------------------------------
    # Vulnerable road user types (for special priority handling)
    # ------------------------------------------------------------------
    vru_requirement_types: tuple = ("HANDLE_VULNERABLE_USER",)
    """RequirementTypes classified as VRU-related for priority purposes."""

    # ------------------------------------------------------------------
    # Construction
    # ------------------------------------------------------------------

    @classmethod
    def from_dict(cls, data: dict) -> "ArbitrationConfig":
        """Build from a config dict. Unknown keys are ignored."""
        cfg = cls()
        for key, val in data.items():
            # Strip 'arbitration_' prefix if present
            attr = key[12:] if key.startswith("arbitration_") else key
            if not hasattr(cfg, attr):
                continue
            current = getattr(cfg, attr)
            if isinstance(current, bool) and isinstance(val, bool):
                setattr(cfg, attr, bool(val))
            elif isinstance(current, float) and isinstance(val, (int, float)):
                setattr(cfg, attr, float(val))
            elif isinstance(current, int) and isinstance(val, int):
                setattr(cfg, attr, int(val))
            elif isinstance(current, str) and isinstance(val, str):
                setattr(cfg, attr, str(val))
            elif isinstance(current, tuple) and isinstance(val, (list, tuple)):
                # Tuples of strings
                if val and isinstance(val[0], (list, tuple)):
                    # Tuple of pairs
                    setattr(cfg, attr, tuple(tuple(p) for p in val))
                else:
                    setattr(cfg, attr, tuple(val))
        return cfg


def load_arbitration_config(
    config_path: Optional[str] = None,
) -> ArbitrationConfig:
    """
    Load ArbitrationConfig from YAML.
    Falls back to safe defaults if the file is missing or malformed.
    """
    path = Path(config_path) if config_path else CONFIG_PATH
    if not path.exists():
        return ArbitrationConfig()
    try:
        import yaml  # type: ignore
        with open(path, "r", encoding="utf-8") as f:
            data = yaml.safe_load(f)
        if isinstance(data, dict):
            return ArbitrationConfig.from_dict(data)
        return ArbitrationConfig()
    except Exception:
        return ArbitrationConfig()
