"""
IndiDrive AI — Phase 8.2 | Behavior Reasoning Configuration
=============================================================
All thresholds and bounds governing Phase 8.2 behavior and interaction
reasoning.  No magic numbers in the engine — every configurable value
lives here with a documented safe default.

Loaded from config/reasoning_config.yaml (same file as Phase 8.1).
Phase 8.2 keys use the prefix 'behavior_' to avoid conflicts.
Unknown keys are silently ignored for forward-compatibility.
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Optional

__all__ = ["BehaviorReasoningConfig", "load_behavior_reasoning_config"]

ROOT = Path(__file__).resolve().parent.parent.parent
CONFIG_PATH = ROOT / "config" / "reasoning_config.yaml"


@dataclass
class BehaviorReasoningConfig:
    """
    Configuration for Phase 8.2 behavior and interaction reasoning.
    Safe defaults suitable for Indian road conditions.
    """

    # ------------------------------------------------------------------
    # TTC thresholds (seconds) — reuse from Phase 8.1
    # ------------------------------------------------------------------
    ttc_immediate_s: float = 1.5
    ttc_near_s: float = 3.0
    ttc_moderate_s: float = 6.0

    # ------------------------------------------------------------------
    # Distance thresholds (metres)
    # ------------------------------------------------------------------
    max_interaction_distance_m: float = 60.0
    """Maximum range for interaction detection."""

    proximity_threshold_m: float = 8.0
    """Distance below which proximity evidence fires."""

    road_context_distance_m: float = 40.0
    """Distance within which road context interactions are considered."""

    narrow_road_width_m: float = 4.5
    """Road width below which 'narrow road' constraint applies."""

    # ------------------------------------------------------------------
    # Motion thresholds
    # ------------------------------------------------------------------
    stationary_speed_threshold_ms: float = 0.3
    """Speed below which an object is classified STATIONARY."""

    approaching_speed_threshold_ms: float = 0.5
    """Closing speed above which APPROACHING evidence fires."""

    lateral_motion_ratio_threshold: float = 0.30
    """Ratio of lateral/total velocity above which CROSSING/LATERAL evidence fires."""

    turning_yaw_threshold_rads: float = 0.15
    """Yaw rate above which TURNING evidence fires (rad/s)."""

    acceleration_threshold_ms2: float = 0.5
    """Acceleration above which ACCELERATING evidence fires (m/s²)."""

    deceleration_threshold_ms2: float = 0.5
    """Deceleration below which DECELERATING evidence fires (m/s²)."""

    stopping_speed_threshold_ms: float = 2.0
    """Speed below which STOPPING (not just DECELERATING) applies."""

    # ------------------------------------------------------------------
    # Confidence thresholds
    # ------------------------------------------------------------------
    interaction_min_confidence: float = 0.25
    """Minimum confidence to report an interaction."""

    intent_min_confidence: float = 0.30
    """Minimum confidence to report an intent hypothesis."""

    low_confidence_threshold: float = 0.3
    """Object confidence below which LOW_CONFIDENCE evidence fires."""

    # ------------------------------------------------------------------
    # Collection bounds
    # ------------------------------------------------------------------
    max_behavior_entities: int = 20
    """Maximum number of entities to classify behavior for."""

    max_behavior_interactions: int = 24
    """Maximum interaction entries in the output."""

    max_behavior_hypotheses: int = 3
    """Maximum competing behavior hypotheses per entity."""

    max_intent_hypotheses: int = 20
    """Maximum total intent hypotheses in output."""

    max_intent_per_entity: int = 2
    """Maximum intent hypotheses per entity."""

    max_compound_situations: int = 6
    """Maximum compound situation entries."""

    max_compound_entities: int = 6
    """Maximum entities per compound situation."""

    max_graph_nodes: int = 20
    """Maximum nodes in the interaction graph."""

    max_graph_edges: int = 30
    """Maximum edges in the interaction graph."""

    max_evidence_items: int = 8
    """Maximum evidence items per behavior/interaction entry."""

    max_dominant_interactions: int = 5
    """Maximum entries in the dominant interactions list."""

    # ------------------------------------------------------------------
    # Compound hazard detection
    # ------------------------------------------------------------------
    compound_min_hazard_count: int = 2
    """Minimum hazard count to trigger compound analysis."""

    # ------------------------------------------------------------------
    # Interaction complexity scoring weights
    # ------------------------------------------------------------------
    complexity_weight_interaction_count: float = 0.30
    complexity_weight_compound_count: float = 0.25
    complexity_weight_severity: float = 0.25
    complexity_weight_uncertainty: float = 0.20

    # ------------------------------------------------------------------
    # Staleness
    # ------------------------------------------------------------------
    stale_data_threshold_s: float = 1.5
    """Data older than this triggers stale evidence."""

    # ------------------------------------------------------------------
    # Construction
    # ------------------------------------------------------------------

    @classmethod
    def from_dict(cls, data: dict) -> "BehaviorReasoningConfig":
        """Build from a config dict.  Unknown keys are ignored."""
        cfg = cls()
        for key, val in data.items():
            # Strip 'behavior_' prefix if present
            attr = key[9:] if key.startswith("behavior_") else key
            if hasattr(cfg, attr):
                current = getattr(cfg, attr)
                if isinstance(current, float) and isinstance(val, (int, float)):
                    setattr(cfg, attr, float(val))
                elif isinstance(current, int) and isinstance(val, int):
                    setattr(cfg, attr, int(val))
                elif isinstance(current, str) and isinstance(val, str):
                    setattr(cfg, attr, str(val))
        return cfg


def load_behavior_reasoning_config(config_path: Optional[str] = None) -> BehaviorReasoningConfig:
    """
    Load BehaviorReasoningConfig from YAML.
    Falls back to safe defaults if the file is missing or malformed.
    """
    path = Path(config_path) if config_path else CONFIG_PATH
    if not path.exists():
        return BehaviorReasoningConfig()
    try:
        import yaml  # type: ignore
        with open(path, "r", encoding="utf-8") as f:
            data = yaml.safe_load(f)
        if isinstance(data, dict):
            return BehaviorReasoningConfig.from_dict(data)
        return BehaviorReasoningConfig()
    except Exception:
        return BehaviorReasoningConfig()
