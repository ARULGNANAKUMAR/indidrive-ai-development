"""
IndiDrive AI — Phase 8.3 | Action Abstraction Validator
=========================================================
Structured validation for ActionAbstractionSnapshot.

Validation states:
  VALID    — all fields pass all checks
  PARTIAL  — non-critical fields missing or out-of-range
  DEGRADED — significant fields missing; output should be used with caution
  INVALID  — critical structural failure; output should not be used

Does NOT silently repair invalid data.
Reports all violations.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import List

from .action_abstraction_types import (
    NOT_AVAILABLE,
    ACTION_ABSTRACTION_SCHEMA_VERSION,
    AbstractionValidationStatus,
    ActionAbstractionSnapshot,
    DecisionRequirement,
    RequirementType,
)

__all__ = [
    "ActionAbstractionValidator",
    "ActionAbstractionValidationResult",
]


@dataclass
class ActionAbstractionValidationResult:
    """Result of validating an ActionAbstractionSnapshot."""
    status: AbstractionValidationStatus = AbstractionValidationStatus.INVALID
    errors: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)

    @property
    def is_usable(self) -> bool:
        return self.status in (
            AbstractionValidationStatus.VALID,
            AbstractionValidationStatus.PARTIAL,
            AbstractionValidationStatus.DEGRADED,
        )

    def to_dict(self) -> dict:
        return {
            "status": self.status.value,
            "error_count": len(self.errors),
            "warning_count": len(self.warnings),
            "errors": list(self.errors),
            "warnings": list(self.warnings),
        }


class ActionAbstractionValidator:
    """
    Validate an ActionAbstractionSnapshot for structural integrity.
    Does not repair data — only reports violations.
    """

    # ------------------------------------------------------------------
    # Forbidden output fields — Phase 8.3 must never contain these
    # ------------------------------------------------------------------
    _FORBIDDEN_FIELDS = (
        "steering", "throttle", "brake", "path_points", "waypoints",
        "trajectory", "steering_angle", "target_speed", "lane_change_command",
        "throttle_cmd", "brake_cmd", "acceleration_cmd", "steer_cmd",
    )

    _FORBIDDEN_CONSTRAINT_KEYWORDS = (
        "steer_left", "steer_right", "brake_now", "throttle_up",
        "accelerate_to", "decelerate_to", "change_lane",
        "overtake_now", "turn_left", "turn_right",
    )

    def validate(
        self,
        snapshot: ActionAbstractionSnapshot,
        max_requirements: int = 12,
    ) -> ActionAbstractionValidationResult:
        """
        Validate the snapshot and return a structured result.
        """
        errors: List[str] = []
        warnings: List[str] = []

        # --- Schema version ---
        if snapshot.schema_version != ACTION_ABSTRACTION_SCHEMA_VERSION:
            errors.append(
                f"schema_version mismatch: expected "
                f"'{ACTION_ABSTRACTION_SCHEMA_VERSION}', "
                f"got '{snapshot.schema_version}'"
            )

        # --- Timestamp ---
        if snapshot.timestamp <= 0:
            errors.append("timestamp must be positive")

        # --- Frame ID ---
        if snapshot.frame_id < 0:
            errors.append("frame_id must be non-negative")

        # --- Confidence / uncertainty ---
        if not (0.0 <= snapshot.confidence <= 1.0):
            errors.append(
                f"snapshot confidence out of range: {snapshot.confidence}"
            )
        if not (0.0 <= snapshot.uncertainty <= 1.0):
            errors.append(
                f"snapshot uncertainty out of range: {snapshot.uncertainty}"
            )
        if not (0.0 <= snapshot.input_completeness <= 1.0):
            warnings.append(
                f"input_completeness out of range: {snapshot.input_completeness}"
            )

        # --- Requirement count ---
        if snapshot.requirement_count > max_requirements:
            errors.append(
                f"requirement_count {snapshot.requirement_count} exceeds "
                f"max {max_requirements}"
            )

        # --- Validate each requirement ---
        seen_ids: set = set()
        for req in snapshot.requirements:
            req_errors, req_warnings = self._validate_requirement(req, seen_ids)
            errors.extend(req_errors)
            warnings.extend(req_warnings)
            seen_ids.add(req.requirement_id)

        # --- Forbidden field check on snapshot dict ---
        snap_dict = snapshot.to_dict()
        for forbidden in self._FORBIDDEN_FIELDS:
            if forbidden in snap_dict:
                errors.append(
                    f"forbidden field '{forbidden}' present in snapshot output"
                )

        # --- Normal progress consistency ---
        has_normal = any(
            r.requirement_type == RequirementType.NORMAL_PROGRESS
            for r in snapshot.requirements
        )
        if has_normal and snapshot.any_safety_critical:
            errors.append(
                "NORMAL_PROGRESS requirement co-exists with safety-critical "
                "requirement — this indicates a generation error"
            )

        # --- Determine overall status ---
        if errors:
            critical_errors = [e for e in errors if "forbidden" in e or "mismatch" in e]
            if critical_errors:
                status = AbstractionValidationStatus.INVALID
            else:
                status = AbstractionValidationStatus.DEGRADED
        elif warnings:
            status = AbstractionValidationStatus.PARTIAL
        else:
            status = AbstractionValidationStatus.VALID

        return ActionAbstractionValidationResult(
            status=status,
            errors=errors,
            warnings=warnings,
        )

    # ------------------------------------------------------------------
    # Per-requirement validation
    # ------------------------------------------------------------------

    def _validate_requirement(
        self,
        req: DecisionRequirement,
        seen_ids: set,
    ) -> tuple:
        errors: List[str] = []
        warnings: List[str] = []
        rid = req.requirement_id

        # ID
        if rid == NOT_AVAILABLE or not rid:
            errors.append("requirement has missing or NOT_AVAILABLE requirement_id")
        elif rid in seen_ids:
            errors.append(f"duplicate requirement_id: {rid}")

        # Schema version
        if req.schema_version != ACTION_ABSTRACTION_SCHEMA_VERSION:
            warnings.append(
                f"requirement {rid}: schema_version "
                f"'{req.schema_version}' != '{ACTION_ABSTRACTION_SCHEMA_VERSION}'"
            )

        # Priority
        if not (0.0 <= req.priority <= 1.0):
            errors.append(f"requirement {rid}: priority {req.priority} out of [0,1]")

        # Confidence / uncertainty
        if not (0.0 <= req.confidence <= 1.0):
            errors.append(
                f"requirement {rid}: confidence {req.confidence} out of [0,1]"
            )
        if not (0.0 <= req.uncertainty <= 1.0):
            errors.append(
                f"requirement {rid}: uncertainty {req.uncertainty} out of [0,1]"
            )

        # Timestamp
        if req.timestamp <= 0:
            warnings.append(f"requirement {rid}: timestamp <= 0")

        # Frame ID
        if req.frame_id < 0:
            warnings.append(f"requirement {rid}: frame_id < 0")

        # Reason codes
        if not req.reason_codes:
            warnings.append(f"requirement {rid}: no reason_codes provided")

        # Source
        if req.source == NOT_AVAILABLE:
            warnings.append(f"requirement {rid}: source is NOT_AVAILABLE")

        # Constraints summary — check for forbidden keywords
        cs = (req.constraints_summary or "").lower()
        for kw in self._FORBIDDEN_CONSTRAINT_KEYWORDS:
            if kw in cs:
                errors.append(
                    f"requirement {rid}: constraints_summary contains "
                    f"forbidden keyword '{kw}'"
                )

        # Affected entities
        for eid in req.affected_entity_ids:
            if not eid or eid == NOT_AVAILABLE:
                warnings.append(
                    f"requirement {rid}: affected_entity_ids contains "
                    f"invalid value '{eid}'"
                )

        return errors, warnings
