"""
IndiDrive AI — Phase 8.1 | Hazard Prioritization
==================================================
Deterministic hazard prioritization.

Answers: «"Which environmental hazards deserve the most reasoning attention?"»

NOT a driving decision.  Only answers which hazards are most relevant to
the current environmental assessment.

All thresholds come from ReasoningConfig — never hard-coded.
"""
from __future__ import annotations

from typing import List

from .reasoning_config import ReasoningConfig
from .reasoning_types import HazardEntry, TtcBand, RiskLevel

__all__ = ["HazardPrioritizer"]

# ---------------------------------------------------------------------------
# Band → numeric score helpers (normalised [0, 1])
# ---------------------------------------------------------------------------

_TTC_BAND_SCORE: dict = {
    TtcBand.IMMEDIATE:    1.0,
    TtcBand.NEAR_TERM:    0.75,
    TtcBand.MODERATE:     0.40,
    TtcBand.DISTANT:      0.10,
    TtcBand.UNAVAILABLE:  0.20,   # unknown ≠ safe
    TtcBand.NO_COLLISION: 0.0,
}

_RISK_SCORE: dict = {
    RiskLevel.CRITICAL: 1.0,
    RiskLevel.HIGH:     0.75,
    RiskLevel.MEDIUM:   0.40,
    RiskLevel.LOW:      0.10,
    RiskLevel.UNKNOWN:  0.20,     # unknown ≠ low risk
}


def _safe_float(v, default: float = 0.0) -> float:
    if v is not None and isinstance(v, (int, float)):
        import math
        if math.isfinite(v):
            return float(v)
    return default


class HazardPrioritizer:
    """
    Assigns a deterministic priority_score [0, 1] to each HazardEntry and
    returns the list sorted descending by priority.

    Priority is a weighted sum of:
      - collision_likelihood (from Phase 4D)
      - TTC band score
      - proximity score (distance)
      - predicted_conflict bonus
      - vulnerability bonus

    All weights come from ReasoningConfig.
    """

    def __init__(self, config: ReasoningConfig) -> None:
        self._cfg = config

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def prioritize(self, hazards: List[HazardEntry]) -> List[HazardEntry]:
        """
        Score and sort hazards.  Returns a new list; input list is not
        mutated.  Stable sort is used for equal-score tie-breaking
        (preserves original order for ties).
        """
        scored = [self._score(h) for h in hazards]
        # Sort descending by priority_score, stable
        scored.sort(key=lambda h: h.priority_score, reverse=True)
        return scored

    # ------------------------------------------------------------------
    # Scoring
    # ------------------------------------------------------------------

    def _score(self, h: HazardEntry) -> HazardEntry:
        """Compute priority_score for one HazardEntry (returns copy)."""
        cfg = self._cfg

        # Component 1: collision likelihood [0, 1]
        cl = _safe_float(h.collision_likelihood, default=0.2)  # unknown ≠ 0
        if h.collision_likelihood is None:
            cl = 0.2  # absence of info → mild penalty, not zero

        # Component 2: TTC band
        ttc_score = _TTC_BAND_SCORE.get(h.ttc_band, 0.2)

        # Component 3: proximity score [0, 1]
        prox = self._proximity_score(h.distance_m)

        # Weighted sum of main components
        score = (
            cfg.weight_collision_likelihood * cl
            + cfg.weight_ttc * ttc_score
            + cfg.weight_distance * prox
        )

        # Component 4: predicted conflict bonus
        if h.predicted_conflict:
            score += cfg.weight_predicted_conflict

        # Component 5: vulnerability bonus
        if h.is_vulnerable:
            score += cfg.weight_vulnerability

        # Clamp to [0, 1]
        score = max(0.0, min(1.0, score))

        # Add reason code for scoring components
        reason_codes = list(h.reason_codes)
        if cl > 0.5 and "HIGH_COLLISION_LIKELIHOOD" not in reason_codes:
            reason_codes.append("HIGH_COLLISION_LIKELIHOOD")
        if ttc_score >= 0.75 and "HIGH_TTC_SCORE" not in reason_codes:
            reason_codes.append("HIGH_TTC_SCORE")
        if prox >= 0.7 and "CLOSE_PROXIMITY" not in reason_codes:
            reason_codes.append("CLOSE_PROXIMITY")

        reason_codes = reason_codes[: cfg.max_reason_codes]

        # Return a new HazardEntry with the updated score
        import dataclasses
        return dataclasses.replace(
            h,
            priority_score=round(score, 4),
            reason_codes=reason_codes,
        )

    def _proximity_score(self, distance_m) -> float:
        """
        Normalise distance to [0, 1].  Closer = higher score.
        None (unavailable) → moderate score (unknown ≠ far).
        """
        cfg = self._cfg
        if distance_m is None:
            return 0.25   # unknown distance — not zero
        d = _safe_float(distance_m)
        if d <= 0:
            return 1.0
        if d <= cfg.distance_critical_m:
            return 1.0
        if d <= cfg.distance_near_m:
            # linear from 0.7..1.0
            return 0.7 + 0.3 * (1.0 - (d - cfg.distance_critical_m) / max(0.01, cfg.distance_near_m - cfg.distance_critical_m))
        if d <= cfg.distance_relevant_m:
            # linear from 0.1..0.7
            return 0.1 + 0.6 * (1.0 - (d - cfg.distance_near_m) / max(0.01, cfg.distance_relevant_m - cfg.distance_near_m))
        return 0.05   # beyond relevant range — still not zero
