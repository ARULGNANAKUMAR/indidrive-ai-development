"""
IndiDrive AI — Phase 8.1 | Reasoning Configuration
=====================================================
All thresholds and limits governing Phase 8.1 situation assessment.
No magic numbers are embedded in the engine — every configurable
value lives here with a documented default and can be overridden
from config/reasoning_config.yaml.

Design rules (same as all prior phases):
  * dataclasses — typed and explicit
  * safe defaults matching Indian-road conditions
  * no hidden heuristics
  * forward-compatible: from_dict() ignores unknown keys
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Optional

__all__ = [
    "ReasoningConfig",
    "load_reasoning_config",
]

CONFIG_VERSION = "8.1"

ROOT = Path(__file__).resolve().parent.parent.parent
CONFIG_PATH = ROOT / "config" / "reasoning_config.yaml"


@dataclass
class ReasoningConfig:
    """
    Configuration container for the Phase 8.1 reasoning layer.

    Safe defaults are chosen to be conservative for Indian road conditions.
    """

    # ------------------------------------------------------------------
    # TTC band thresholds (seconds)
    # ------------------------------------------------------------------

    ttc_immediate_s: float = 1.5
    """TTC below this → IMMEDIATE band (most critical)."""

    ttc_near_s: float = 3.0
    """TTC below this → NEAR_TERM band."""

    ttc_moderate_s: float = 6.0
    """TTC below this → MODERATE band; else DISTANT."""

    # ------------------------------------------------------------------
    # Hazard priority weights [0, 1]
    # ------------------------------------------------------------------

    weight_collision_likelihood: float = 0.35
    """Weight of collision_likelihood in priority score."""

    weight_ttc: float = 0.30
    """Weight of TTC band contribution in priority score."""

    weight_distance: float = 0.15
    """Weight of proximity in priority score."""

    weight_predicted_conflict: float = 0.10
    """Bonus weight when predicted_conflict is True."""

    weight_vulnerability: float = 0.10
    """Bonus weight for vulnerable road users (pedestrian/cyclist/cattle)."""

    # ------------------------------------------------------------------
    # Vulnerability categories
    # ------------------------------------------------------------------

    vulnerable_object_types: tuple = (
        "PEDESTRIAN", "CYCLIST", "CATTLE", "PUSHCART",
    )
    """Object subtypes/types considered vulnerable road users."""

    unusual_participant_types: tuple = (
        "CATTLE", "PUSHCART", "TRACTOR", "AUTO_RICKSHAW",
    )
    """Participants that add to 'unusual' count and compound complexity."""

    # ------------------------------------------------------------------
    # Distance thresholds (metres)
    # ------------------------------------------------------------------

    distance_critical_m: float = 5.0
    """Objects within this distance are treated as critical proximity."""

    distance_near_m: float = 15.0
    """Objects within this distance are treated as near."""

    distance_relevant_m: float = 50.0
    """Objects beyond this distance are ignored for active hazard count."""

    # ------------------------------------------------------------------
    # Road width thresholds (metres)
    # ------------------------------------------------------------------

    narrow_road_width_m: float = 4.5
    """Roads narrower than this are classified as NARROW."""

    very_narrow_road_width_m: float = 3.0
    """Roads narrower than this are classified as VERY_NARROW."""

    # ------------------------------------------------------------------
    # Complexity thresholds
    # ------------------------------------------------------------------

    complexity_high_hazard_count: int = 4
    """Hazard count at/above which complexity ≥ HIGH."""

    complexity_very_high_hazard_count: int = 8
    """Hazard count at/above which complexity = VERY_HIGH."""

    complexity_dense_traffic_density: tuple = ("HIGH", "VERY_HIGH")
    """Traffic density values that contribute to complexity."""

    # ------------------------------------------------------------------
    # Risk state thresholds
    # ------------------------------------------------------------------

    critical_ttc_s: float = 1.5
    """TTC at/below which reasoning_state → CRITICAL."""

    high_risk_min_count: int = 1
    """Number of HIGH/CRITICAL hazards that triggers HIGH_RISK state."""

    caution_hazard_count: int = 2
    """Hazard count at/above which reasoning_state ≥ CAUTION."""

    attention_hazard_count: int = 1
    """Any hazard triggers at least ATTENTION."""

    # ------------------------------------------------------------------
    # Uncertainty thresholds
    # ------------------------------------------------------------------

    uncertainty_high_threshold: float = 0.6
    """Overall uncertainty above this → HIGH uncertainty level."""

    uncertainty_very_high_threshold: float = 0.8
    """Overall uncertainty above this → VERY_HIGH uncertainty level."""

    completeness_full_threshold: float = 0.85
    """World model completeness above this → FULL."""

    completeness_partial_threshold: float = 0.40
    """World model completeness above this → PARTIAL (else MINIMAL)."""

    # ------------------------------------------------------------------
    # Confidence thresholds
    # ------------------------------------------------------------------

    confidence_high_threshold: float = 0.7
    """Confidence above this → reliable reasoning."""

    confidence_low_threshold: float = 0.3
    """Confidence below this → degraded reasoning."""

    # ------------------------------------------------------------------
    # Collection bounds
    # ------------------------------------------------------------------

    max_hazards: int = 32
    """Maximum hazard entries in the snapshot."""

    max_interactions: int = 16
    """Maximum interaction entries in the snapshot."""

    max_top_hazards: int = 8
    """Maximum entries in top_hazards list."""

    max_reason_codes: int = 12
    """Maximum reason codes per list."""

    # ------------------------------------------------------------------
    # Staleness
    # ------------------------------------------------------------------

    stale_data_threshold_s: float = 1.5
    """World model older than this is treated as stale data present."""

    # ------------------------------------------------------------------
    # Compound hazard detection
    # ------------------------------------------------------------------

    compound_min_hazard_types: int = 3
    """Minimum distinct hazard categories to classify as COMPOUND_HAZARD."""

    compound_min_total_hazards: int = 2
    """Minimum total hazards before compound classification is considered."""

    # ------------------------------------------------------------------
    # Interaction detection
    # ------------------------------------------------------------------

    interaction_min_confidence: float = 0.3
    """Minimum confidence to report an interaction."""

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    config_version: str = CONFIG_VERSION

    # ------------------------------------------------------------------
    # Construction
    # ------------------------------------------------------------------

    @classmethod
    def from_dict(cls, data: dict) -> "ReasoningConfig":
        """
        Build from a dict (e.g. parsed YAML).
        Unknown keys are silently ignored for forward-compatibility.
        """
        cfg = cls()
        for key, val in data.items():
            if hasattr(cfg, key):
                # Type-coerce simple scalars; skip complex nested objects
                current = getattr(cfg, key)
                if isinstance(current, float) and isinstance(val, (int, float)):
                    setattr(cfg, key, float(val))
                elif isinstance(current, int) and isinstance(val, int):
                    setattr(cfg, key, int(val))
                elif isinstance(current, str) and isinstance(val, str):
                    setattr(cfg, key, str(val))
                elif isinstance(current, tuple) and isinstance(val, (list, tuple)):
                    setattr(cfg, key, tuple(val))
                # other types: leave as default
        return cfg


def load_reasoning_config(config_path: Optional[str] = None) -> ReasoningConfig:
    """
    Load ReasoningConfig from YAML.  Falls back to safe defaults if the
    file is missing or malformed (logs a warning but does not raise).
    """
    path = Path(config_path) if config_path else CONFIG_PATH
    if not path.exists():
        return ReasoningConfig()
    try:
        import yaml  # type: ignore
        with open(path, "r", encoding="utf-8") as f:
            data = yaml.safe_load(f)
        if isinstance(data, dict):
            return ReasoningConfig.from_dict(data)
        return ReasoningConfig()
    except Exception:
        # Malformed YAML — use safe defaults
        return ReasoningConfig()
