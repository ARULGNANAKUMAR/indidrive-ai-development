"""
IndiDrive AI — Phase 8.2 | Behavior & Interaction Reasoning Data Contracts
===========================================================================
Strongly-typed data containers for Phase 8.2 output.

Phase 8.2 answers:
    «"How are the important entities interacting, and what behavior/intent
      pattern is emerging?"»

This is a REASONING layer only.  It does NOT:
  - plan paths
  - issue steering / throttle / brake commands
  - redesign World Model or Phase 8.1
  - use LLM, cloud, or large neural networks

All numeric fields use None to mean 'unavailable'.  Zero is never
substituted for unknown.

Every behavior / intent classification distinguishes:
  OBSERVED   — directly observed from current sensor/world-model data
  INFERRED   — derived from observable dynamics with explicit evidence
  PREDICTED  — from prediction hypotheses (not confirmed)
  UNKNOWN    — insufficient evidence to classify

Deterministic: same input → same output.
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from enum import Enum
from typing import List, Optional, Tuple

__all__ = [
    # Sentinel / schema
    "NOT_AVAILABLE",
    "BEHAVIOR_REASONING_SCHEMA_VERSION",
    # Evidence classification
    "EvidenceClass",
    # Behavior states
    "BehaviorState",
    # Intent types
    "IntentType",
    # Interaction types (extended)
    "BehaviorInteractionType",
    # Severity / time relevance
    "InteractionSeverity",
    "TimeRelevance",
    # Compound situation type
    "CompoundSituationType",
    # Graph edge type
    "GraphEdgeType",
    # Validation status
    "BehaviorValidationStatus",
    # Data structures
    "BehaviorEvidenceItem",
    "BehaviorClassification",
    "IntentHypothesis",
    "BehaviorInteractionEntry",
    "InteractionGraphNode",
    "InteractionGraphEdge",
    "InteractionGraph",
    "CompoundSituation",
    "BehaviorReasoningState",
    "BehaviorReasoningResult",
]

NOT_AVAILABLE = "NOT_AVAILABLE"
BEHAVIOR_REASONING_SCHEMA_VERSION = "8.2"


# ---------------------------------------------------------------------------
# Evidence classification
# ---------------------------------------------------------------------------

class EvidenceClass(str, Enum):
    """
    Epistemological class for a behavior or intent classification.

    OBSERVED   — directly seen in current world-model data.
    INFERRED   — derived from observable dynamics; not directly measured.
    PREDICTED  — from prediction hypotheses; may not occur.
    UNKNOWN    — cannot determine evidence class.
    """
    OBSERVED  = "OBSERVED"
    INFERRED  = "INFERRED"
    PREDICTED = "PREDICTED"
    UNKNOWN   = "UNKNOWN"


# ---------------------------------------------------------------------------
# Behavior states
# ---------------------------------------------------------------------------

class BehaviorState(str, Enum):
    """
    Compact behavior state for one dynamic entity.

    States are derived from motion data — never from object type alone.
    UNCERTAIN is used when evidence conflicts.
    """
    STATIONARY           = "STATIONARY"
    MOVING               = "MOVING"
    APPROACHING          = "APPROACHING"       # closing distance to ego
    RECEDING             = "RECEDING"          # increasing distance from ego
    CROSSING             = "CROSSING"          # lateral crossing trajectory
    LATERAL_MOVEMENT     = "LATERAL_MOVEMENT"  # significant lateral component
    LONGITUDINAL_MOVEMENT = "LONGITUDINAL_MOVEMENT"  # primarily forward/back
    TURNING              = "TURNING"           # heading change detected
    MERGING              = "MERGING"           # moving into shared lane/space
    DIVERGING            = "DIVERGING"         # moving away from shared space
    STOPPING             = "STOPPING"          # decelerating toward zero
    ACCELERATING         = "ACCELERATING"      # increasing speed
    DECELERATING         = "DECELERATING"      # decreasing speed (not stopping)
    UNCERTAIN            = "UNCERTAIN"         # conflicting evidence
    UNKNOWN              = "UNKNOWN"           # insufficient evidence


# ---------------------------------------------------------------------------
# Intent types
# ---------------------------------------------------------------------------

class IntentType(str, Enum):
    """
    Probable motion/behavior intention inferred from observable dynamics.

    This is NOT human psychological intent.
    It describes probable physical behavior direction inferred from motion.
    Every intent must be supported by evidence — never inferred from type alone.
    """
    POSSIBLE_CROSSING       = "POSSIBLE_CROSSING"
    POSSIBLE_TURNING        = "POSSIBLE_TURNING"
    POSSIBLE_MERGING        = "POSSIBLE_MERGING"
    POSSIBLE_STOPPING       = "POSSIBLE_STOPPING"
    POSSIBLE_LANE_FOLLOWING = "POSSIBLE_LANE_FOLLOWING"
    POSSIBLE_APPROACH       = "POSSIBLE_APPROACH"
    POSSIBLE_DEPARTURE      = "POSSIBLE_DEPARTURE"
    POSSIBLE_ROAD_ENTRY     = "POSSIBLE_ROAD_ENTRY"
    POSSIBLE_YIELDING       = "POSSIBLE_YIELDING"
    POSSIBLE_OVERTAKING     = "POSSIBLE_OVERTAKING"
    POSSIBLE_WRONG_SIDE     = "POSSIBLE_WRONG_SIDE"
    POSSIBLE_ERRATIC        = "POSSIBLE_ERRATIC"
    UNKNOWN                 = "UNKNOWN"


# ---------------------------------------------------------------------------
# Interaction types (Phase 8.2 extended taxonomy)
# ---------------------------------------------------------------------------

class BehaviorInteractionType(str, Enum):
    """
    Pairwise interaction type between two environmental entities or
    between an entity and the road space.

    'ego' is one valid entity identifier (the host vehicle).
    """
    FOLLOWING                    = "FOLLOWING"
    APPROACHING                  = "APPROACHING"
    CROSSING                     = "CROSSING"
    MERGING                      = "MERGING"
    DIVERGING                    = "DIVERGING"
    LATERAL_CONFLICT             = "LATERAL_CONFLICT"
    LONGITUDINAL_CONFLICT        = "LONGITUDINAL_CONFLICT"
    ROADSPACE_CONFLICT           = "ROADSPACE_CONFLICT"
    PEDESTRIAN_VEHICLE           = "PEDESTRIAN_VEHICLE"
    CATTLE_VEHICLE               = "CATTLE_VEHICLE"
    VEHICLE_VEHICLE              = "VEHICLE_VEHICLE"
    WRONG_SIDE_APPROACH          = "WRONG_SIDE_APPROACH"
    ENTITY_ROAD_ANOMALY          = "ENTITY_ROAD_ANOMALY"
    ENTITY_ROAD_BOUNDARY         = "ENTITY_ROAD_BOUNDARY"
    ENTITY_DRIVABLE_AREA         = "ENTITY_DRIVABLE_AREA"
    COMPOUND_MULTI_ENTITY        = "COMPOUND_MULTI_ENTITY"
    UNKNOWN                      = "UNKNOWN"


# ---------------------------------------------------------------------------
# Severity and time relevance
# ---------------------------------------------------------------------------

class InteractionSeverity(str, Enum):
    """
    Severity of a detected interaction.
    Derived from evidence — never assigned merely because an object is present.
    """
    LOW      = "LOW"
    MEDIUM   = "MEDIUM"
    HIGH     = "HIGH"
    CRITICAL = "CRITICAL"
    UNKNOWN  = "UNKNOWN"


class TimeRelevance(str, Enum):
    """
    Temporal relevance of an interaction.
    Classified from TTC / prediction horizon — never fabricated.
    """
    IMMEDIATE   = "IMMEDIATE"   # within ttc_immediate_s
    NEAR_TERM   = "NEAR_TERM"   # within ttc_near_s
    MEDIUM_TERM = "MEDIUM_TERM" # within ttc_moderate_s
    DISTANT     = "DISTANT"     # beyond moderate threshold
    UNKNOWN     = "UNKNOWN"     # TTC unavailable


# ---------------------------------------------------------------------------
# Compound situation type
# ---------------------------------------------------------------------------

class CompoundSituationType(str, Enum):
    """High-level classification of a compound / multi-hazard situation."""
    INDEPENDENT_HAZARDS    = "INDEPENDENT_HAZARDS"
    RELATED_HAZARDS        = "RELATED_HAZARDS"
    COMPOUND_HAZARD        = "COMPOUND_HAZARD"
    CASCADING_INTERACTION  = "CASCADING_INTERACTION"
    UNCERTAIN_INTERACTION  = "UNCERTAIN_INTERACTION"


# ---------------------------------------------------------------------------
# Graph edge type
# ---------------------------------------------------------------------------

class GraphEdgeType(str, Enum):
    """Type of edge in the interaction graph."""
    SPATIAL_PROXIMITY     = "SPATIAL_PROXIMITY"
    TRAJECTORY_OVERLAP    = "TRAJECTORY_OVERLAP"
    ROAD_SPACE_SHARING    = "ROAD_SPACE_SHARING"
    PREDICTED_CONFLICT    = "PREDICTED_CONFLICT"
    BEHAVIORAL_COUPLING   = "BEHAVIORAL_COUPLING"


# ---------------------------------------------------------------------------
# Validation status
# ---------------------------------------------------------------------------

class BehaviorValidationStatus(str, Enum):
    """Result of validating a BehaviorReasoningState."""
    VALID   = "VALID"
    PARTIAL = "PARTIAL"
    DEGRADED = "DEGRADED"
    INVALID = "INVALID"


# ---------------------------------------------------------------------------
# Evidence item
# ---------------------------------------------------------------------------

@dataclass
class BehaviorEvidenceItem:
    """
    One piece of structured evidence supporting a behavior or intent.

    Uses compact reason codes — NOT natural-language strings.
    Examples: RELATIVE_SPEED_POSITIVE, LATERAL_DISPLACEMENT_INCREASING,
              HEADING_CHANGE, TRAJECTORY_INTERSECTION, TTC_DECREASING.
    """
    code: str = NOT_AVAILABLE
    evidence_class: EvidenceClass = EvidenceClass.UNKNOWN
    strength: float = 0.0   # [0, 1] — how strongly this supports the claim

    def to_dict(self) -> dict:
        return {
            "code": self.code,
            "evidence_class": self.evidence_class.value,
            "strength": round(self.strength, 3),
        }


# ---------------------------------------------------------------------------
# Behavior classification for one entity
# ---------------------------------------------------------------------------

@dataclass
class BehaviorClassification:
    """
    Behavior state for one dynamic entity in the World Model.

    Never presents inference as observation.
    Never presents prediction as confirmed event.
    Conflicting evidence → UNCERTAIN state.
    """
    entity_id: str = NOT_AVAILABLE
    entity_type: str = NOT_AVAILABLE       # object_type from WorldObject
    entity_subtype: str = NOT_AVAILABLE    # object_subtype from WorldObject

    # Primary behavior state
    behavior_state: BehaviorState = BehaviorState.UNKNOWN
    behavior_confidence: float = 0.0
    behavior_uncertainty: float = 1.0

    # Evidence class for the primary state
    evidence_class: EvidenceClass = EvidenceClass.UNKNOWN

    # Supporting evidence codes
    evidence: List[BehaviorEvidenceItem] = field(default_factory=list)

    # Competing hypotheses when evidence conflicts
    competing_states: List[Tuple[BehaviorState, float]] = field(default_factory=list)

    # Source and freshness
    source: str = "world_model"
    timestamp: float = field(default_factory=time.time)

    def to_dict(self) -> dict:
        return {
            "entity_id": self.entity_id,
            "entity_type": self.entity_type,
            "entity_subtype": self.entity_subtype,
            "behavior_state": self.behavior_state.value,
            "behavior_confidence": round(self.behavior_confidence, 3),
            "behavior_uncertainty": round(self.behavior_uncertainty, 3),
            "evidence_class": self.evidence_class.value,
            "evidence": [e.to_dict() for e in self.evidence],
            "competing_states": [
                {"state": s.value, "confidence": round(c, 3)}
                for s, c in self.competing_states
            ],
            "source": self.source,
            "timestamp": self.timestamp,
        }


# ---------------------------------------------------------------------------
# Intent hypothesis
# ---------------------------------------------------------------------------

@dataclass
class IntentHypothesis:
    """
    Probable motion/behavior intention for one entity.

    confidence + uncertainty should sum to ~1.0.
    Every intent must include supporting evidence.
    No certainty is ever claimed.
    """
    entity_id: str = NOT_AVAILABLE
    intent_type: IntentType = IntentType.UNKNOWN
    confidence: float = 0.0
    uncertainty: float = 1.0
    evidence_class: EvidenceClass = EvidenceClass.UNKNOWN
    evidence: List[BehaviorEvidenceItem] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "entity_id": self.entity_id,
            "intent_type": self.intent_type.value,
            "confidence": round(self.confidence, 3),
            "uncertainty": round(self.uncertainty, 3),
            "evidence_class": self.evidence_class.value,
            "evidence": [e.to_dict() for e in self.evidence],
        }


# ---------------------------------------------------------------------------
# Pairwise interaction entry
# ---------------------------------------------------------------------------

@dataclass
class BehaviorInteractionEntry:
    """
    Pairwise interaction between two entities (or entity + road feature).

    Does NOT prescribe a vehicle response.
    Does NOT determine the best action.
    Describes only the observed/inferred/predicted interaction state.
    """
    interaction_id: str = NOT_AVAILABLE
    entity_a_id: str = NOT_AVAILABLE
    entity_b_id: str = NOT_AVAILABLE  # may be "ego", road feature id, etc.
    interaction_type: BehaviorInteractionType = BehaviorInteractionType.UNKNOWN

    # State
    interaction_state: EvidenceClass = EvidenceClass.UNKNOWN  # how this is known

    # Severity / time
    severity: InteractionSeverity = InteractionSeverity.UNKNOWN
    time_relevance: TimeRelevance = TimeRelevance.UNKNOWN

    # Confidence / uncertainty
    confidence: float = 0.0
    uncertainty: float = 1.0

    # Evidence
    evidence: List[BehaviorEvidenceItem] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "interaction_id": self.interaction_id,
            "entity_a_id": self.entity_a_id,
            "entity_b_id": self.entity_b_id,
            "interaction_type": self.interaction_type.value,
            "interaction_state": self.interaction_state.value,
            "severity": self.severity.value,
            "time_relevance": self.time_relevance.value,
            "confidence": round(self.confidence, 3),
            "uncertainty": round(self.uncertainty, 3),
            "evidence": [e.to_dict() for e in self.evidence],
        }


# ---------------------------------------------------------------------------
# Interaction graph
# ---------------------------------------------------------------------------

@dataclass
class InteractionGraphNode:
    """One node in the interaction graph."""
    node_id: str = NOT_AVAILABLE
    node_type: str = NOT_AVAILABLE   # "object" | "road_feature" | "ego"
    label: str = NOT_AVAILABLE       # human-readable short label (e.g. "pedestrian")

    def to_dict(self) -> dict:
        return {
            "node_id": self.node_id,
            "node_type": self.node_type,
            "label": self.label,
        }


@dataclass
class InteractionGraphEdge:
    """One directed edge in the interaction graph."""
    edge_id: str = NOT_AVAILABLE
    from_node: str = NOT_AVAILABLE
    to_node: str = NOT_AVAILABLE
    edge_type: GraphEdgeType = GraphEdgeType.SPATIAL_PROXIMITY
    weight: float = 0.0   # [0, 1] — strength of interaction
    confidence: float = 0.0

    def to_dict(self) -> dict:
        return {
            "edge_id": self.edge_id,
            "from_node": self.from_node,
            "to_node": self.to_node,
            "edge_type": self.edge_type.value,
            "weight": round(self.weight, 3),
            "confidence": round(self.confidence, 3),
        }


@dataclass
class InteractionGraph:
    """
    Lightweight bounded interaction graph for the current reasoning snapshot.

    Nodes = relevant world objects + road hazards.
    Edges = spatial, trajectory, road-space, or behavioral interactions.

    The graph is snapshot-based: it exists only for the current cycle.
    No graph database.  No persistent state.
    """
    nodes: List[InteractionGraphNode] = field(default_factory=list)
    edges: List[InteractionGraphEdge] = field(default_factory=list)

    @property
    def node_count(self) -> int:
        return len(self.nodes)

    @property
    def edge_count(self) -> int:
        return len(self.edges)

    def to_dict(self) -> dict:
        return {
            "node_count": self.node_count,
            "edge_count": self.edge_count,
            "nodes": [n.to_dict() for n in self.nodes],
            "edges": [e.to_dict() for e in self.edges],
        }


# ---------------------------------------------------------------------------
# Compound situation
# ---------------------------------------------------------------------------

@dataclass
class CompoundSituation:
    """
    A group of interactions that form a compound or cascading pattern.

    Does NOT produce a vehicle action recommendation.
    Describes only the compound interaction context.
    """
    situation_id: str = NOT_AVAILABLE
    situation_type: CompoundSituationType = CompoundSituationType.UNCERTAIN_INTERACTION

    # Entities involved
    entity_ids: List[str] = field(default_factory=list)

    # Interaction IDs contributing to this compound situation
    interaction_ids: List[str] = field(default_factory=list)

    # Road context constraints
    road_constraints: List[str] = field(default_factory=list)  # e.g. "narrow_road"

    # Severity / confidence
    severity: InteractionSeverity = InteractionSeverity.UNKNOWN
    confidence: float = 0.0
    uncertainty: float = 1.0

    # Reason codes
    reason_codes: List[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "situation_id": self.situation_id,
            "situation_type": self.situation_type.value,
            "entity_ids": list(self.entity_ids),
            "interaction_ids": list(self.interaction_ids),
            "road_constraints": list(self.road_constraints),
            "severity": self.severity.value,
            "confidence": round(self.confidence, 3),
            "uncertainty": round(self.uncertainty, 3),
            "reason_codes": list(self.reason_codes),
        }


# ---------------------------------------------------------------------------
# Primary output: BehaviorReasoningState
# ---------------------------------------------------------------------------

@dataclass
class BehaviorReasoningState:
    """
    One immutable, consistent Phase 8.2 reasoning state for a single cycle.

    Consumers MUST NOT mutate this object.
    Repeated identical input → identical output (deterministic).

    This is interaction/behavior reasoning only.
    It does NOT contain:
      - steering commands
      - throttle/brake commands
      - path or trajectory
      - lane-change or overtaking decisions
      - vehicle control of any kind
    """
    schema_version: str = BEHAVIOR_REASONING_SCHEMA_VERSION
    timestamp: float = field(default_factory=time.time)
    frame_id: int = 0

    # --- Entity behavior classifications (immutable after build) ---
    _entity_behaviors: tuple = field(default_factory=tuple, repr=False)

    # --- Pairwise interactions (immutable after build) ---
    _interactions: tuple = field(default_factory=tuple, repr=False)

    # --- Intent hypotheses (immutable after build) ---
    _intent_hypotheses: tuple = field(default_factory=tuple, repr=False)

    # --- Interaction graph ---
    interaction_graph: InteractionGraph = field(default_factory=InteractionGraph)

    # --- Compound situations ---
    _compound_situations: tuple = field(default_factory=tuple, repr=False)

    # --- Dominant interactions (attention prioritization, NOT a driving decision) ---
    _dominant_interactions: tuple = field(default_factory=tuple, repr=False)

    # --- Overall complexity of the interaction space ---
    overall_interaction_complexity: str = NOT_AVAILABLE  # LOW | MEDIUM | HIGH | VERY_HIGH

    # --- Aggregate confidence / uncertainty ---
    confidence: float = 0.0
    uncertainty: float = 1.0

    # --- Completeness ---
    completeness: float = 0.0   # [0, 1] — how much input data was available

    # --- Degraded flag ---
    degraded: bool = False

    # --- Reason codes ---
    reason_codes: List[str] = field(default_factory=list)

    # --- Memory context summary (read-only; may be "unavailable") ---
    memory_context: str = "unavailable"

    # ------------------------------------------------------------------
    # Safe read-only properties
    # ------------------------------------------------------------------

    @property
    def entity_behaviors(self) -> tuple:
        return self._entity_behaviors

    @property
    def interactions(self) -> tuple:
        return self._interactions

    @property
    def intent_hypotheses(self) -> tuple:
        return self._intent_hypotheses

    @property
    def compound_situations(self) -> tuple:
        return self._compound_situations

    @property
    def dominant_interactions(self) -> tuple:
        return self._dominant_interactions

    @property
    def entity_count(self) -> int:
        return len(self._entity_behaviors)

    @property
    def interaction_count(self) -> int:
        return len(self._interactions)

    @property
    def intent_count(self) -> int:
        return len(self._intent_hypotheses)

    @property
    def compound_count(self) -> int:
        return len(self._compound_situations)

    def to_dict(self) -> dict:
        return {
            "schema_version": self.schema_version,
            "timestamp": self.timestamp,
            "frame_id": self.frame_id,
            "entity_count": self.entity_count,
            "entity_behaviors": [b.to_dict() for b in self._entity_behaviors],
            "interaction_count": self.interaction_count,
            "interactions": [i.to_dict() for i in self._interactions],
            "intent_count": self.intent_count,
            "intent_hypotheses": [h.to_dict() for h in self._intent_hypotheses],
            "interaction_graph": self.interaction_graph.to_dict(),
            "compound_count": self.compound_count,
            "compound_situations": [s.to_dict() for s in self._compound_situations],
            "dominant_interaction_count": len(self._dominant_interactions),
            "dominant_interactions": [i.to_dict() for i in self._dominant_interactions],
            "overall_interaction_complexity": self.overall_interaction_complexity,
            "confidence": round(self.confidence, 3),
            "uncertainty": round(self.uncertainty, 3),
            "completeness": round(self.completeness, 3),
            "degraded": self.degraded,
            "reason_codes": list(self.reason_codes),
            "memory_context": self.memory_context,
        }


# ---------------------------------------------------------------------------
# Build result wrapper
# ---------------------------------------------------------------------------

@dataclass
class BehaviorReasoningResult:
    """
    Return value of BehaviorReasoningEngine.reason().

    Always present — never raises on partial or invalid input.
    The reasoning state is always a valid BehaviorReasoningState even
    when input data is degraded or empty.
    """
    state: BehaviorReasoningState
    status: str = "ok"          # ok | degraded | empty | error
    warnings: List[str] = field(default_factory=list)
    errors: List[str] = field(default_factory=list)
    duration_s: float = 0.0

    @property
    def is_valid(self) -> bool:
        return self.status in ("ok", "degraded", "empty")

    def to_dict(self) -> dict:
        return {
            "state": self.state.to_dict(),
            "status": self.status,
            "warnings": list(self.warnings),
            "errors": list(self.errors),
            "duration_s": round(self.duration_s, 6),
        }
