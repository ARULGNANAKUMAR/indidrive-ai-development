"""
IndiDrive AI — Phase 8.2 | Multi-Hazard Interaction Reasoner
=============================================================
Determines how multiple hazards interact — whether they form
independent, related, compound, or cascading situations.

This is the main Phase 8.2 feature.

Rules:
  - Deterministic
  - Bounded: max_compound_situations from config
  - No path planning, no vehicle control
  - No LLM or cloud

Multi-hazard classification:
  INDEPENDENT_HAZARDS   — hazards don't share space/trajectory
  RELATED_HAZARDS       — share road space but don't directly interact
  COMPOUND_HAZARD       — multiple entities in constrained shared space
  CASCADING_INTERACTION — one event likely to trigger another
  UNCERTAIN_INTERACTION — conflicting or insufficient evidence
"""
from __future__ import annotations

from typing import Dict, List, Optional, Set, Tuple

from core.world_model.world_model_types import WorldModelSnapshot, WorldObject, NOT_AVAILABLE

from .behavior_types import (
    BehaviorClassification,
    BehaviorEvidenceItem,
    BehaviorInteractionEntry,
    BehaviorInteractionType,
    BehaviorState,
    CompoundSituation,
    CompoundSituationType,
    EvidenceClass,
    InteractionSeverity,
)
from .reasoning_types import HazardEntry, RiskLevel
from .behavior_reasoning_config import BehaviorReasoningConfig

__all__ = ["MultiHazardReasoner"]

_HIGH_SEVERITY = {InteractionSeverity.HIGH, InteractionSeverity.CRITICAL}
_HIGH_RISK = {RiskLevel.HIGH.value, RiskLevel.CRITICAL.value}


def _ev(code: str, strength: float = 0.6) -> BehaviorEvidenceItem:
    return BehaviorEvidenceItem(code=code, evidence_class=EvidenceClass.INFERRED, strength=strength)


class MultiHazardReasoner:
    """
    Identifies compound and cascading interaction patterns across
    multiple simultaneous hazards.
    """

    def __init__(self, config: BehaviorReasoningConfig) -> None:
        self._cfg = config
        self._sid_counter = 0

    def reason(
        self,
        snapshot: WorldModelSnapshot,
        hazards: List[HazardEntry],
        behaviors: List[BehaviorClassification],
        interactions: List[BehaviorInteractionEntry],
    ) -> List[CompoundSituation]:
        """
        Analyse multi-hazard interactions and produce compound situations.

        Returns a bounded list of CompoundSituation objects.
        """
        self._sid_counter = 0
        situations: List[CompoundSituation] = []

        high_hazards = [h for h in hazards if h.risk_level in (RiskLevel.HIGH, RiskLevel.CRITICAL)]
        all_hazards = hazards

        # --- Strategy 1: Road-space constraint compound ---
        narrow = self._road_is_narrow(snapshot)
        if narrow and len(all_hazards) >= 2:
            s = self._road_space_compound(all_hazards, behaviors, interactions, snapshot)
            if s is not None:
                situations.append(s)

        # --- Strategy 2: VRU + vehicle compound ---
        vru_hazards = [h for h in all_hazards if self._is_vru(h)]
        vehicle_hazards = [h for h in all_hazards if self._is_vehicle(h)]
        if vru_hazards and vehicle_hazards:
            s = self._vru_vehicle_compound(vru_hazards, vehicle_hazards, interactions, snapshot)
            if s is not None and len(situations) < self._cfg.max_compound_situations:
                situations.append(s)

        # --- Strategy 3: Cattle crossing compound (Indian-specific) ---
        cattle_hazards = [h for h in all_hazards if self._is_cattle(h)]
        if cattle_hazards and vehicle_hazards:
            s = self._cattle_compound(cattle_hazards, vehicle_hazards, interactions, snapshot)
            if s is not None and len(situations) < self._cfg.max_compound_situations:
                situations.append(s)

        # --- Strategy 4: Wrong-side traffic compound ---
        wrong_side_ints = [
            i for i in interactions
            if i.interaction_type == BehaviorInteractionType.WRONG_SIDE_APPROACH
        ]
        if wrong_side_ints and len(situations) < self._cfg.max_compound_situations:
            s = self._wrong_side_compound(wrong_side_ints, hazards, snapshot)
            if s is not None:
                situations.append(s)

        # --- Strategy 5: High-count independent hazards ---
        if len(high_hazards) >= self._cfg.compound_min_hazard_count and \
                not situations and len(situations) < self._cfg.max_compound_situations:
            s = self._independent_high_hazards(high_hazards, interactions)
            if s is not None:
                situations.append(s)

        # --- Strategy 6: Cascading — one predicted to trigger another ---
        if len(situations) < self._cfg.max_compound_situations:
            s = self._cascading_check(high_hazards, behaviors, interactions, snapshot)
            if s is not None:
                situations.append(s)

        return situations[: self._cfg.max_compound_situations]

    # ------------------------------------------------------------------
    # Road-space compound
    # ------------------------------------------------------------------

    def _road_space_compound(
        self,
        hazards: List[HazardEntry],
        behaviors: List[BehaviorClassification],
        interactions: List[BehaviorInteractionEntry],
        snapshot: WorldModelSnapshot,
    ) -> Optional[CompoundSituation]:
        """Multiple entities sharing constrained road space."""
        relevant = hazards[:self._cfg.max_compound_entities]
        if len(relevant) < 2:
            return None

        entity_ids = [h.hazard_id for h in relevant if h.hazard_id != NOT_AVAILABLE]
        int_ids = [i.interaction_id for i in interactions[:4]]

        # Road constraints
        road_constraints = ["narrow_road"]
        dw = snapshot.road.drivable_space.road_width_m
        if dw is not None:
            road_constraints.append(f"drivable_width_{dw:.1f}m")
        if snapshot.road.anomalies:
            road_constraints.append("road_anomaly_present")

        avg_conf = sum(h.confidence for h in relevant) / len(relevant)
        avg_unc = sum(h.uncertainty for h in relevant) / len(relevant)

        high_count = sum(1 for h in relevant if h.risk_level in (RiskLevel.HIGH, RiskLevel.CRITICAL))
        sev = InteractionSeverity.HIGH if high_count >= 1 else InteractionSeverity.MEDIUM

        return CompoundSituation(
            situation_id=self._next_sid(),
            situation_type=CompoundSituationType.COMPOUND_HAZARD,
            entity_ids=entity_ids[:self._cfg.max_compound_entities],
            interaction_ids=int_ids,
            road_constraints=road_constraints,
            severity=sev,
            confidence=round(avg_conf, 3),
            uncertainty=round(avg_unc, 3),
            reason_codes=["NARROW_ROAD_MULTI_HAZARD", "ROAD_SPACE_CONSTRAINT"],
        )

    # ------------------------------------------------------------------
    # VRU + vehicle compound
    # ------------------------------------------------------------------

    def _vru_vehicle_compound(
        self,
        vru_hazards: List[HazardEntry],
        vehicle_hazards: List[HazardEntry],
        interactions: List[BehaviorInteractionEntry],
        snapshot: WorldModelSnapshot,
    ) -> Optional[CompoundSituation]:
        vru_ids = [h.hazard_id for h in vru_hazards[:3]]
        veh_ids = [h.hazard_id for h in vehicle_hazards[:2]]
        all_ids = list(dict.fromkeys(vru_ids + veh_ids))
        if len(all_ids) < 2:
            return None

        # Select interactions involving VRU types
        rel_ints = [
            i for i in interactions
            if i.interaction_type in (
                BehaviorInteractionType.PEDESTRIAN_VEHICLE,
                BehaviorInteractionType.CATTLE_VEHICLE,
            )
        ]
        int_ids = [i.interaction_id for i in rel_ints[:3]]

        # Severity: elevate if any VRU is high-risk
        high_vru = any(h.risk_level in (RiskLevel.HIGH, RiskLevel.CRITICAL) for h in vru_hazards)
        sev = InteractionSeverity.HIGH if high_vru else InteractionSeverity.MEDIUM

        all_relevant = vru_hazards + vehicle_hazards
        avg_conf = sum(h.confidence for h in all_relevant) / len(all_relevant)
        avg_unc = 1.0 - avg_conf

        road_constraints = []
        if self._road_is_narrow(snapshot):
            road_constraints.append("narrow_road")

        return CompoundSituation(
            situation_id=self._next_sid(),
            situation_type=CompoundSituationType.COMPOUND_HAZARD,
            entity_ids=all_ids[:self._cfg.max_compound_entities],
            interaction_ids=int_ids,
            road_constraints=road_constraints,
            severity=sev,
            confidence=round(avg_conf, 3),
            uncertainty=round(avg_unc, 3),
            reason_codes=["VRU_VEHICLE_COMPOUND", "VULNERABLE_ROAD_USER_PRESENT"],
        )

    # ------------------------------------------------------------------
    # Cattle compound (Indian road specific)
    # ------------------------------------------------------------------

    def _cattle_compound(
        self,
        cattle: List[HazardEntry],
        vehicles: List[HazardEntry],
        interactions: List[BehaviorInteractionEntry],
        snapshot: WorldModelSnapshot,
    ) -> Optional[CompoundSituation]:
        all_ids = list(dict.fromkeys(
            [h.hazard_id for h in cattle[:2]] + [h.hazard_id for h in vehicles[:2]]
        ))
        if len(all_ids) < 2:
            return None

        cattle_ints = [
            i for i in interactions
            if i.interaction_type == BehaviorInteractionType.CATTLE_VEHICLE
        ]
        int_ids = [i.interaction_id for i in cattle_ints[:2]]

        road_constraints = ["unpredictable_cattle_trajectory"]
        indian_ctx = snapshot.indian_context
        if indian_ctx.available:
            if indian_ctx.road_type not in (NOT_AVAILABLE, "HIGHWAY"):
                road_constraints.append(f"road_type_{indian_ctx.road_type.lower()}")
        if self._road_is_narrow(snapshot):
            road_constraints.append("narrow_road")

        all_relevant = cattle + vehicles
        avg_conf = sum(h.confidence for h in all_relevant) / max(1, len(all_relevant))
        # Cattle trajectories are inherently uncertain
        avg_unc = max(0.4, 1.0 - avg_conf)

        return CompoundSituation(
            situation_id=self._next_sid(),
            situation_type=CompoundSituationType.COMPOUND_HAZARD,
            entity_ids=all_ids[:self._cfg.max_compound_entities],
            interaction_ids=int_ids,
            road_constraints=road_constraints,
            severity=InteractionSeverity.HIGH,
            confidence=round(avg_conf * 0.8, 3),  # reduce due to uncertainty
            uncertainty=round(avg_unc, 3),
            reason_codes=[
                "CATTLE_VEHICLE_COMPOUND",
                "UNPREDICTABLE_TRAJECTORY",
                "INDIAN_ROAD_CONTEXT",
            ],
        )

    # ------------------------------------------------------------------
    # Wrong-side traffic compound
    # ------------------------------------------------------------------

    def _wrong_side_compound(
        self,
        wrong_side_ints: List[BehaviorInteractionEntry],
        hazards: List[HazardEntry],
        snapshot: WorldModelSnapshot,
    ) -> Optional[CompoundSituation]:
        entity_ids = list(dict.fromkeys(
            i.entity_b_id for i in wrong_side_ints if i.entity_b_id != NOT_AVAILABLE
        ))
        int_ids = [i.interaction_id for i in wrong_side_ints[:3]]

        avg_conf = sum(i.confidence for i in wrong_side_ints) / len(wrong_side_ints)
        avg_unc = 1.0 - avg_conf

        road_constraints = ["wrong_side_approach"]
        if self._road_is_narrow(snapshot):
            road_constraints.append("narrow_road")

        return CompoundSituation(
            situation_id=self._next_sid(),
            situation_type=CompoundSituationType.COMPOUND_HAZARD,
            entity_ids=entity_ids[:self._cfg.max_compound_entities],
            interaction_ids=int_ids,
            road_constraints=road_constraints,
            severity=InteractionSeverity.CRITICAL,
            confidence=round(avg_conf, 3),
            uncertainty=round(avg_unc, 3),
            reason_codes=["WRONG_SIDE_TRAFFIC", "HEAD_ON_CONFLICT_RISK"],
        )

    # ------------------------------------------------------------------
    # Independent high hazards
    # ------------------------------------------------------------------

    def _independent_high_hazards(
        self,
        hazards: List[HazardEntry],
        interactions: List[BehaviorInteractionEntry],
    ) -> Optional[CompoundSituation]:
        if len(hazards) < 2:
            return None
        entity_ids = [h.hazard_id for h in hazards[:self._cfg.max_compound_entities]]
        avg_conf = sum(h.confidence for h in hazards[:4]) / min(4, len(hazards))
        avg_unc = 1.0 - avg_conf

        return CompoundSituation(
            situation_id=self._next_sid(),
            situation_type=CompoundSituationType.INDEPENDENT_HAZARDS,
            entity_ids=entity_ids,
            interaction_ids=[i.interaction_id for i in interactions[:2]],
            road_constraints=[],
            severity=InteractionSeverity.HIGH,
            confidence=round(avg_conf, 3),
            uncertainty=round(avg_unc, 3),
            reason_codes=["MULTIPLE_HIGH_HAZARDS", "ATTENTION_SPLIT_REQUIRED"],
        )

    # ------------------------------------------------------------------
    # Cascading check
    # ------------------------------------------------------------------

    def _cascading_check(
        self,
        high_hazards: List[HazardEntry],
        behaviors: List[BehaviorClassification],
        interactions: List[BehaviorInteractionEntry],
        snapshot: WorldModelSnapshot,
    ) -> Optional[CompoundSituation]:
        """
        Check if one hazard stopping/swerving could trigger a second hazard.
        Heuristic: two approaching entities at different TTCs suggest cascade.
        """
        if len(high_hazards) < 2:
            return None

        # Sort by TTC ascending
        with_ttc = [(h, h.ttc_s) for h in high_hazards if h.ttc_s is not None]
        with_ttc.sort(key=lambda x: x[1] or 9999)

        if len(with_ttc) < 2:
            return None

        # Different TTC bands suggest sequential events
        near = with_ttc[0]
        far = with_ttc[1]
        if far[1] - near[1] < 1.0:
            return None  # Too close in time to be cascade

        entity_ids = [near[0].hazard_id, far[0].hazard_id]
        int_ids = [i.interaction_id for i in interactions[:2]]
        avg_conf = (near[0].confidence + far[0].confidence) / 2.0

        return CompoundSituation(
            situation_id=self._next_sid(),
            situation_type=CompoundSituationType.CASCADING_INTERACTION,
            entity_ids=entity_ids,
            interaction_ids=int_ids,
            road_constraints=[],
            severity=InteractionSeverity.HIGH,
            confidence=round(avg_conf * 0.7, 3),  # lower due to inference
            uncertainty=round(1.0 - avg_conf * 0.7, 3),
            reason_codes=[
                "SEQUENTIAL_TTC_PATTERN",
                f"NEAR_TTC_{near[1]:.1f}s",
                f"FAR_TTC_{far[1]:.1f}s",
            ],
        )

    # ------------------------------------------------------------------
    # Utilities
    # ------------------------------------------------------------------

    @staticmethod
    def _road_is_narrow(snapshot: WorldModelSnapshot) -> bool:
        dw = snapshot.road.drivable_space.road_width_m
        if dw is not None and dw < 4.5:
            return True
        if snapshot.indian_context.available:
            rt = snapshot.indian_context.road_type
            if rt in ("VILLAGE_ROAD", "NARROW_ROAD"):
                return True
        return False

    @staticmethod
    def _is_vru(h: HazardEntry) -> bool:
        from .reasoning_types import HazardCategory
        return h.hazard_category in (
            HazardCategory.PEDESTRIAN,
            HazardCategory.CYCLIST,
            HazardCategory.CATTLE,
            HazardCategory.PUSHCART,
        )

    @staticmethod
    def _is_cattle(h: HazardEntry) -> bool:
        from .reasoning_types import HazardCategory
        return h.hazard_category == HazardCategory.CATTLE

    @staticmethod
    def _is_vehicle(h: HazardEntry) -> bool:
        from .reasoning_types import HazardCategory
        return h.hazard_category in (
            HazardCategory.CAR, HazardCategory.BUS, HazardCategory.TRUCK,
            HazardCategory.MOTORCYCLE, HazardCategory.SCOOTER,
            HazardCategory.AUTO_RICKSHAW, HazardCategory.TRACTOR,
        )

    def _next_sid(self) -> str:
        self._sid_counter += 1
        return f"compound_{self._sid_counter:03d}"
