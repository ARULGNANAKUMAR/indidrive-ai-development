"""
IndiDrive AI — Phase 8.3 | Requirement Generator
=================================================
Deterministic rule-based generation of DecisionRequirement instances
from Phase 8.1 (ReasoningSnapshot) + Phase 8.2 (BehaviorReasoningState)
+ Phase 7 (WorldModelSnapshot) outputs.

Design rules:
  * Pure functions — no global mutable state
  * Same inputs → same outputs (deterministic)
  * Does NOT create new perception / tracking / prediction
  * Does NOT produce steering / throttle / brake / path / waypoints
  * All thresholds come from ActionAbstractionConfig
  * Missing / unavailable data → HANDLE_UNCERTAINTY, never fabricated
"""
from __future__ import annotations

import time
import uuid
from typing import List, Optional, Tuple

from .action_abstraction_types import (
    NOT_AVAILABLE,
    AbstractSeverity,
    AbstractUrgency,
    DecisionRequirement,
    EvidenceType,
    RequirementType,
)
from .action_abstraction_config import ActionAbstractionConfig

# ---------------------------------------------------------------------------
# Type aliases for clarity — avoid importing full upstream modules here
# (the engine does the actual imports; we only reference lightweight types)
# ---------------------------------------------------------------------------
from .reasoning_types import (
    ReasoningSnapshot,
    RiskLevel,
    TtcBand,
    HazardCategory,
    SituationCategory,
)
from .behavior_types import (
    BehaviorReasoningState,
    InteractionSeverity,
    BehaviorInteractionType,
    IntentType,
    TimeRelevance,
)
from core.world_model.world_model_types import WorldModelSnapshot, WorldModelStatus


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _new_req_id() -> str:
    """Deterministic-enough unique ID for one processing call chain."""
    return f"req_{uuid.uuid4().hex[:12]}"


def _ttc_to_urgency(
    ttc_s: Optional[float],
    ttc_band: str,
    cfg: ActionAbstractionConfig,
) -> AbstractUrgency:
    """Map TTC value / band to AbstractUrgency."""
    if ttc_s is not None:
        if ttc_s <= cfg.ttc_immediate_s:
            return AbstractUrgency.IMMEDIATE
        if ttc_s <= cfg.ttc_high_s:
            return AbstractUrgency.HIGH
        if ttc_s <= cfg.ttc_medium_s:
            return AbstractUrgency.MEDIUM
        return AbstractUrgency.LOW
    # Fall back to band
    band_map = {
        "IMMEDIATE": AbstractUrgency.IMMEDIATE,
        "NEAR_TERM": AbstractUrgency.HIGH,
        "MODERATE": AbstractUrgency.MEDIUM,
        "DISTANT": AbstractUrgency.LOW,
        "NO_COLLISION": AbstractUrgency.NONE,
        "UNAVAILABLE": AbstractUrgency.UNKNOWN,
    }
    return band_map.get(ttc_band, AbstractUrgency.UNKNOWN)


def _time_relevance_to_urgency(tr: str) -> AbstractUrgency:
    """Map Phase 8.2 TimeRelevance string to AbstractUrgency."""
    mapping = {
        "IMMEDIATE": AbstractUrgency.IMMEDIATE,
        "NEAR_TERM": AbstractUrgency.HIGH,
        "MEDIUM_TERM": AbstractUrgency.MEDIUM,
        "DISTANT": AbstractUrgency.LOW,
        "UNKNOWN": AbstractUrgency.UNKNOWN,
    }
    return mapping.get(tr, AbstractUrgency.UNKNOWN)


def _risk_to_severity(risk: str) -> AbstractSeverity:
    """Map RiskLevel string to AbstractSeverity."""
    mapping = {
        "CRITICAL": AbstractSeverity.CRITICAL,
        "HIGH": AbstractSeverity.HIGH,
        "MEDIUM": AbstractSeverity.MEDIUM,
        "LOW": AbstractSeverity.LOW,
        "UNKNOWN": AbstractSeverity.UNKNOWN,
    }
    return mapping.get(risk, AbstractSeverity.UNKNOWN)


def _interaction_severity_to_abstract(sev: str) -> AbstractSeverity:
    """Map Phase 8.2 InteractionSeverity string to AbstractSeverity."""
    mapping = {
        "CRITICAL": AbstractSeverity.CRITICAL,
        "HIGH": AbstractSeverity.HIGH,
        "MEDIUM": AbstractSeverity.MEDIUM,
        "LOW": AbstractSeverity.LOW,
        "UNKNOWN": AbstractSeverity.UNKNOWN,
    }
    return mapping.get(sev, AbstractSeverity.UNKNOWN)


def _clamp01(v: float) -> float:
    return max(0.0, min(1.0, v))


def _ttc_band_score(band: str) -> float:
    """Numeric urgency score for priority calculation [0, 1]."""
    return {
        "IMMEDIATE": 1.0,
        "NEAR_TERM": 0.75,
        "MODERATE": 0.45,
        "DISTANT": 0.15,
        "NO_COLLISION": 0.0,
        "UNAVAILABLE": 0.3,  # unknown → conservative
    }.get(band, 0.3)


def _risk_score(risk: str) -> float:
    """Numeric risk score for priority calculation [0, 1]."""
    return {
        "CRITICAL": 1.0,
        "HIGH": 0.75,
        "MEDIUM": 0.45,
        "LOW": 0.15,
        "UNKNOWN": 0.3,
    }.get(risk, 0.3)


# ---------------------------------------------------------------------------
# Generator functions — one per requirement category
# ---------------------------------------------------------------------------

def generate_collision_avoidance(
    situation: ReasoningSnapshot,
    cfg: ActionAbstractionConfig,
    frame_id: int,
    ts: float,
) -> List[DecisionRequirement]:
    """
    Generate COLLISION_AVOIDANCE_REQUIRED when evidence warrants it.
    Uses Phase 8.1 hazard + risk data.
    """
    reqs: List[DecisionRequirement] = []
    risk = situation.risk

    if not risk.collision_threat_present:
        return reqs

    # At least one hazard has CRITICAL / HIGH risk
    top_hazards = situation.hazards.top_hazards
    for hazard in top_hazards:
        if hazard.risk_level.value in ("CRITICAL", "HIGH") and hazard.predicted_conflict:
            ttc_s = hazard.ttc_s
            ttc_band = hazard.ttc_band.value
            urgency = _ttc_to_urgency(ttc_s, ttc_band, cfg)
            severity = _risk_to_severity(hazard.risk_level.value)

            # Priority score
            ttc_contrib = _ttc_band_score(ttc_band) * cfg.priority_weight_ttc
            risk_contrib = _risk_score(hazard.risk_level.value) * cfg.priority_weight_collision_likelihood
            likelihood_contrib = (
                (hazard.collision_likelihood or 0.5) * cfg.priority_weight_collision_likelihood
            )
            vuln_contrib = (
                cfg.priority_weight_vulnerability if hazard.is_vulnerable else 0.0
            )
            priority = _clamp01(ttc_contrib + risk_contrib + likelihood_contrib + vuln_contrib)

            reason_codes = list(hazard.reason_codes[:cfg.max_reason_codes])
            reason_codes.append("COLLISION_THREAT_DETECTED")
            if hazard.is_vulnerable:
                reason_codes.append("VULNERABLE_ENTITY_INVOLVED")

            req = DecisionRequirement(
                requirement_id=_new_req_id(),
                requirement_type=RequirementType.COLLISION_AVOIDANCE_REQUIRED,
                priority=priority,
                urgency=urgency,
                severity=severity,
                confidence=hazard.confidence,
                uncertainty=hazard.uncertainty,
                evidence_type=EvidenceType.COMBINED,
                source="phase_8_1",
                affected_entity_ids=(hazard.hazard_id,),
                affected_region="ego_path",
                time_relevance_s=ttc_s,
                reason_codes=tuple(reason_codes[:cfg.max_reason_codes]),
                constraints_summary="collision_threat_active",
                is_safety_critical=True,
                timestamp=ts,
                frame_id=frame_id,
            )
            reqs.append(req)
            break  # one requirement per distinct collision threat; compound handled by multi-hazard

    return reqs


def generate_trajectory_conflict(
    behavior: Optional[BehaviorReasoningState],
    cfg: ActionAbstractionConfig,
    frame_id: int,
    ts: float,
) -> List[DecisionRequirement]:
    """
    Generate HANDLE_TRAJECTORY_CONFLICT from Phase 8.2 interactions.
    """
    if behavior is None:
        return []
    reqs: List[DecisionRequirement] = []

    conflict_types = {
        "CROSSING", "LATERAL_CONFLICT", "LONGITUDINAL_CONFLICT",
        "ROADSPACE_CONFLICT", "WRONG_SIDE_APPROACH",
    }

    for interaction in behavior.dominant_interactions:
        if interaction.interaction_type.value not in conflict_types:
            continue
        if interaction.confidence < cfg.priority_weight_uncertainty:
            continue

        urgency = _time_relevance_to_urgency(interaction.time_relevance.value)
        severity = _interaction_severity_to_abstract(interaction.severity.value)

        sev_score = _risk_score(interaction.severity.value)
        ttc_score = _ttc_band_score(
            "IMMEDIATE" if urgency == AbstractUrgency.IMMEDIATE else
            "NEAR_TERM" if urgency == AbstractUrgency.HIGH else
            "MODERATE" if urgency == AbstractUrgency.MEDIUM else "DISTANT"
        )
        priority = _clamp01(
            sev_score * cfg.priority_weight_severity +
            ttc_score * cfg.priority_weight_ttc +
            interaction.confidence * cfg.priority_weight_collision_likelihood
        )

        evidence_map = {
            "OBSERVED": EvidenceType.OBSERVED,
            "INFERRED": EvidenceType.INFERRED,
            "PREDICTED": EvidenceType.PREDICTED,
            "UNKNOWN": EvidenceType.UNKNOWN,
        }
        ev_type = evidence_map.get(interaction.interaction_state.value, EvidenceType.UNKNOWN)

        req = DecisionRequirement(
            requirement_id=_new_req_id(),
            requirement_type=RequirementType.HANDLE_TRAJECTORY_CONFLICT,
            priority=priority,
            urgency=urgency,
            severity=severity,
            confidence=interaction.confidence,
            uncertainty=interaction.uncertainty,
            evidence_type=ev_type,
            source="phase_8_2",
            affected_entity_ids=(interaction.entity_a_id, interaction.entity_b_id),
            affected_region="shared_road_space",
            time_relevance_s=None,
            reason_codes=tuple(
                [e.code for e in interaction.evidence][:cfg.max_reason_codes]
            ),
            constraints_summary="trajectory_conflict_active",
            is_safety_critical=severity in (AbstractSeverity.CRITICAL, AbstractSeverity.HIGH),
            timestamp=ts,
            frame_id=frame_id,
        )
        reqs.append(req)

    return reqs


def generate_vulnerable_user(
    situation: ReasoningSnapshot,
    behavior: Optional[BehaviorReasoningState],
    cfg: ActionAbstractionConfig,
    frame_id: int,
    ts: float,
) -> List[DecisionRequirement]:
    """
    Generate HANDLE_VULNERABLE_USER when VRUs are present with non-trivial risk.
    Uses both Phase 8.1 hazard data and Phase 8.2 intent data.
    """
    reqs: List[DecisionRequirement] = []
    env = situation.environment

    if not (env.has_vru or env.has_cattle):
        # Also check hazard list for VRU types
        vru_categories = {
            "PEDESTRIAN", "CYCLIST", "CATTLE", "PUSHCART"
        }
        has_vru_hazard = any(
            h.hazard_category.value in vru_categories
            for h in situation.hazards.top_hazards
        )
        if not has_vru_hazard:
            return reqs

    # Find VRU hazards and intent hypotheses
    vru_entities: List[str] = []
    best_urgency = AbstractUrgency.LOW
    best_severity = AbstractSeverity.LOW
    best_confidence = 0.0
    best_uncertainty = 1.0
    reason_codes: List[str] = []
    ev_type = EvidenceType.OBSERVED

    vru_categories = {"PEDESTRIAN", "CYCLIST", "CATTLE", "PUSHCART"}

    for hazard in situation.hazards.top_hazards:
        if hazard.hazard_category.value in vru_categories:
            if hazard.hazard_id not in vru_entities:
                vru_entities.append(hazard.hazard_id)
            u = _ttc_to_urgency(hazard.ttc_s, hazard.ttc_band.value, cfg)
            s = _risk_to_severity(hazard.risk_level.value)
            if _urgency_rank(u) > _urgency_rank(best_urgency):
                best_urgency = u
            if _severity_rank(s) > _severity_rank(best_severity):
                best_severity = s
            if hazard.confidence > best_confidence:
                best_confidence = hazard.confidence
                best_uncertainty = hazard.uncertainty
            reason_codes.extend(hazard.reason_codes)

    # Check intent hypotheses for crossing / approach
    if behavior is not None:
        crossing_intents = {
            "POSSIBLE_CROSSING", "POSSIBLE_ROAD_ENTRY", "POSSIBLE_ERRATIC"
        }
        for hyp in behavior.intent_hypotheses:
            if hyp.entity_id in vru_entities and hyp.intent_type.value in crossing_intents:
                ev_type = EvidenceType.COMBINED
                if hyp.confidence > 0.3:
                    reason_codes.append("CROSSING_INTENT_DETECTED")
                    if best_urgency == AbstractUrgency.LOW:
                        best_urgency = AbstractUrgency.MEDIUM

    if not vru_entities:
        return reqs

    # Priority
    sev_score = _severity_rank(best_severity) / 4.0
    urg_score = _urgency_rank(best_urgency) / 5.0
    vuln_bonus = cfg.priority_weight_vulnerability
    priority = _clamp01(
        sev_score * cfg.priority_weight_severity +
        urg_score * cfg.priority_weight_ttc +
        best_confidence * cfg.priority_weight_collision_likelihood +
        vuln_bonus
    )

    req = DecisionRequirement(
        requirement_id=_new_req_id(),
        requirement_type=RequirementType.HANDLE_VULNERABLE_USER,
        priority=priority,
        urgency=best_urgency,
        severity=best_severity,
        confidence=best_confidence,
        uncertainty=best_uncertainty,
        evidence_type=ev_type,
        source="combined",
        affected_entity_ids=tuple(vru_entities[:cfg.max_affected_entities]),
        affected_region="ego_path_and_vicinity",
        time_relevance_s=None,
        reason_codes=tuple(set(reason_codes[:cfg.max_reason_codes])),
        constraints_summary="vulnerable_user_present",
        is_safety_critical=best_severity in (AbstractSeverity.CRITICAL, AbstractSeverity.HIGH),
        timestamp=ts,
        frame_id=frame_id,
    )
    reqs.append(req)
    return reqs


def generate_road_hazard(
    situation: ReasoningSnapshot,
    world: Optional[WorldModelSnapshot],
    cfg: ActionAbstractionConfig,
    frame_id: int,
    ts: float,
) -> List[DecisionRequirement]:
    """
    Generate HANDLE_ROAD_HAZARD and MAINTAIN_DRIVABLE_REGION from
    Phase 6.3 anomaly data in the World Model and Phase 8.1 hazard list.
    """
    reqs: List[DecisionRequirement] = []
    road_hazard_categories = {
        "ROAD_OBSTACLE", "POTHOLE", "DEBRIS", "CONSTRUCTION",
    }

    # From Phase 8.1 hazard list
    road_hazards = [
        h for h in situation.hazards.top_hazards
        if h.hazard_category.value in road_hazard_categories
    ]

    if not road_hazards and world is not None:
        # From World Model anomalies
        if not world.road.anomalies:
            return reqs

    if road_hazards:
        best = road_hazards[0]
        urgency = _ttc_to_urgency(best.ttc_s, best.ttc_band.value, cfg)
        severity = _risk_to_severity(best.risk_level.value)
        priority = _clamp01(
            _risk_score(best.risk_level.value) * cfg.priority_weight_severity +
            _ttc_band_score(best.ttc_band.value) * cfg.priority_weight_ttc
        )
        reqs.append(DecisionRequirement(
            requirement_id=_new_req_id(),
            requirement_type=RequirementType.HANDLE_ROAD_HAZARD,
            priority=priority,
            urgency=urgency,
            severity=severity,
            confidence=best.confidence,
            uncertainty=best.uncertainty,
            evidence_type=EvidenceType.OBSERVED,
            source="phase_8_1",
            affected_entity_ids=(best.hazard_id,),
            affected_region="drivable_path",
            time_relevance_s=best.ttc_s,
            reason_codes=tuple(best.reason_codes[:cfg.max_reason_codes]),
            constraints_summary="road_hazard_in_path",
            is_safety_critical=severity in (AbstractSeverity.CRITICAL, AbstractSeverity.HIGH),
            timestamp=ts,
            frame_id=frame_id,
        ))

    # Check if drivable region is constrained by anomalies in the world model
    if world is not None and world.road.anomalies:
        in_path = [a for a in world.road.anomalies if a.in_drivable_area]
        if in_path:
            critical = any(a.severity == "CRITICAL" for a in in_path)
            severity = AbstractSeverity.CRITICAL if critical else AbstractSeverity.HIGH
            reqs.append(DecisionRequirement(
                requirement_id=_new_req_id(),
                requirement_type=RequirementType.MAINTAIN_DRIVABLE_REGION,
                priority=_clamp01(0.7 if critical else 0.5),
                urgency=AbstractUrgency.HIGH if critical else AbstractUrgency.MEDIUM,
                severity=severity,
                confidence=world.road.road_confidence,
                uncertainty=world.road.road_uncertainty,
                evidence_type=EvidenceType.OBSERVED,
                source="world_model_road",
                affected_entity_ids=tuple(),
                affected_region="drivable_area_boundary",
                time_relevance_s=None,
                reason_codes=("ANOMALY_IN_DRIVABLE_AREA",),
                constraints_summary="drivable_region_restricted",
                is_safety_critical=critical,
                timestamp=ts,
                frame_id=frame_id,
            ))

    return reqs


def generate_narrow_road(
    situation: ReasoningSnapshot,
    world: Optional[WorldModelSnapshot],
    cfg: ActionAbstractionConfig,
    frame_id: int,
    ts: float,
) -> List[DecisionRequirement]:
    """
    Generate HANDLE_NARROW_ROAD from road width data.
    """
    reqs: List[DecisionRequirement] = []
    env = situation.environment
    if not env.is_narrow_road:
        # Also check world model drivable space
        if world is not None:
            width = world.road.drivable_space.road_width_m
            if width is None or width >= cfg.narrow_road_width_m:
                return reqs
            # Use world model width
            available_width = width
        else:
            return reqs
    else:
        available_width = env.available_drivable_width_m

    very_narrow = (
        available_width is not None and available_width < cfg.very_narrow_road_width_m
    )
    severity = AbstractSeverity.HIGH if very_narrow else AbstractSeverity.MEDIUM
    urgency = AbstractUrgency.HIGH if very_narrow else AbstractUrgency.MEDIUM
    priority = _clamp01(0.75 if very_narrow else 0.5)

    reason_codes = ["NARROW_ROAD_DETECTED"]
    if very_narrow:
        reason_codes.append("VERY_NARROW_WIDTH")
    if env.has_vru or env.has_wrong_side_traffic:
        reason_codes.append("OPPOSING_TRAFFIC_OR_VRU_PRESENT")
        priority = _clamp01(priority + 0.1)

    reqs.append(DecisionRequirement(
        requirement_id=_new_req_id(),
        requirement_type=RequirementType.HANDLE_NARROW_ROAD,
        priority=priority,
        urgency=urgency,
        severity=severity,
        confidence=situation.reasoning_confidence,
        uncertainty=situation.uncertainty_info.overall_uncertainty,
        evidence_type=EvidenceType.OBSERVED,
        source="phase_8_1",
        affected_entity_ids=tuple(),
        affected_region="road_width_constraint",
        time_relevance_s=None,
        reason_codes=tuple(reason_codes),
        constraints_summary="narrow_road_active",
        is_safety_critical=very_narrow,
        timestamp=ts,
        frame_id=frame_id,
    ))
    return reqs


def generate_intersection(
    situation: ReasoningSnapshot,
    world: Optional[WorldModelSnapshot],
    cfg: ActionAbstractionConfig,
    frame_id: int,
    ts: float,
) -> List[DecisionRequirement]:
    """Generate HANDLE_INTERSECTION from environment / world model data."""
    reqs: List[DecisionRequirement] = []
    env = situation.environment
    if not env.is_intersection:
        if world is None:
            return reqs
        ctx = world.road.lane_info.intersection_state
        if ctx == NOT_AVAILABLE:
            ctx = world.indian_context.intersection_context
        if not any(t in ctx for t in cfg.intersection_context_triggers):
            return reqs

    confidence = situation.reasoning_confidence
    uncertainty = situation.uncertainty_info.overall_uncertainty
    has_traffic = situation.hazards.total_hazards > 0
    severity = AbstractSeverity.HIGH if has_traffic else AbstractSeverity.MEDIUM
    urgency = AbstractUrgency.HIGH if has_traffic else AbstractUrgency.MEDIUM

    reqs.append(DecisionRequirement(
        requirement_id=_new_req_id(),
        requirement_type=RequirementType.HANDLE_INTERSECTION,
        priority=_clamp01(0.65 if has_traffic else 0.4),
        urgency=urgency,
        severity=severity,
        confidence=confidence,
        uncertainty=uncertainty,
        evidence_type=EvidenceType.OBSERVED,
        source="phase_8_1",
        affected_entity_ids=tuple(),
        affected_region="intersection_zone",
        time_relevance_s=None,
        reason_codes=("INTERSECTION_DETECTED",),
        constraints_summary="intersection_present",
        is_safety_critical=has_traffic and severity == AbstractSeverity.HIGH,
        timestamp=ts,
        frame_id=frame_id,
    ))
    return reqs


def generate_merge(
    situation: ReasoningSnapshot,
    behavior: Optional[BehaviorReasoningState],
    cfg: ActionAbstractionConfig,
    frame_id: int,
    ts: float,
) -> List[DecisionRequirement]:
    """Generate HANDLE_MERGE from situation category or behavior interactions."""
    reqs: List[DecisionRequirement] = []
    is_merge = situation.situation.situation_category == SituationCategory.MERGE_COMPLEXITY

    if not is_merge and behavior is not None:
        merge_types = {"MERGING"}
        is_merge = any(
            i.interaction_type.value in merge_types
            for i in behavior.dominant_interactions
        )

    if not is_merge:
        return reqs

    severity = AbstractSeverity.HIGH
    urgency = AbstractUrgency.HIGH
    reason_codes = ["MERGE_SITUATION_DETECTED"]

    if behavior is not None:
        merge_ints = [
            i for i in behavior.dominant_interactions
            if i.interaction_type.value == "MERGING"
        ]
        if merge_ints:
            mi = merge_ints[0]
            urgency = _time_relevance_to_urgency(mi.time_relevance.value)
            severity = _interaction_severity_to_abstract(mi.severity.value)

    reqs.append(DecisionRequirement(
        requirement_id=_new_req_id(),
        requirement_type=RequirementType.HANDLE_MERGE,
        priority=_clamp01(0.7),
        urgency=urgency,
        severity=severity,
        confidence=situation.reasoning_confidence,
        uncertainty=situation.uncertainty_info.overall_uncertainty,
        evidence_type=EvidenceType.COMBINED if behavior else EvidenceType.INFERRED,
        source="combined",
        affected_entity_ids=tuple(),
        affected_region="merge_zone",
        time_relevance_s=None,
        reason_codes=tuple(reason_codes),
        constraints_summary="merge_situation_active",
        is_safety_critical=True,
        timestamp=ts,
        frame_id=frame_id,
    ))
    return reqs


def generate_monitor_dynamic_object(
    situation: ReasoningSnapshot,
    behavior: Optional[BehaviorReasoningState],
    cfg: ActionAbstractionConfig,
    frame_id: int,
    ts: float,
) -> List[DecisionRequirement]:
    """
    Generate MONITOR_DYNAMIC_OBJECT for moving objects that don't yet
    require immediate action but should be tracked.
    """
    reqs: List[DecisionRequirement] = []
    if situation.hazards.total_hazards == 0:
        return reqs

    # Only if there are moving objects not already covered by collision avoidance
    medium_risk = [
        h for h in situation.hazards.top_hazards
        if h.risk_level.value in ("MEDIUM",) and h.is_moving
    ]
    if not medium_risk:
        return reqs

    entities = tuple(h.hazard_id for h in medium_risk[:cfg.max_affected_entities])
    reqs.append(DecisionRequirement(
        requirement_id=_new_req_id(),
        requirement_type=RequirementType.MONITOR_DYNAMIC_OBJECT,
        priority=_clamp01(0.35),
        urgency=AbstractUrgency.LOW,
        severity=AbstractSeverity.MEDIUM,
        confidence=sum(h.confidence for h in medium_risk) / len(medium_risk),
        uncertainty=sum(h.uncertainty for h in medium_risk) / len(medium_risk),
        evidence_type=EvidenceType.OBSERVED,
        source="phase_8_1",
        affected_entity_ids=entities,
        affected_region="monitoring_zone",
        time_relevance_s=None,
        reason_codes=("MEDIUM_RISK_MOVING_OBJECTS_PRESENT",),
        constraints_summary="dynamic_objects_require_monitoring",
        is_safety_critical=False,
        timestamp=ts,
        frame_id=frame_id,
    ))
    return reqs


def generate_monitor_unpredictable(
    situation: ReasoningSnapshot,
    behavior: Optional[BehaviorReasoningState],
    cfg: ActionAbstractionConfig,
    frame_id: int,
    ts: float,
) -> List[DecisionRequirement]:
    """
    Generate MONITOR_UNPREDICTABLE_OBJECT for cattle, erratic movers, etc.
    """
    reqs: List[DecisionRequirement] = []
    unpredictable_categories = {"CATTLE", "PUSHCART"}

    unpredictable = [
        h for h in situation.hazards.top_hazards
        if h.hazard_category.value in unpredictable_categories
    ]

    if not unpredictable:
        # Check behavior intent for erratic patterns
        if behavior is not None:
            erratic = [
                hyp for hyp in behavior.intent_hypotheses
                if hyp.intent_type.value == "POSSIBLE_ERRATIC"
            ]
            if not erratic:
                return reqs
            entities = tuple(hyp.entity_id for hyp in erratic[:cfg.max_affected_entities])
            reqs.append(DecisionRequirement(
                requirement_id=_new_req_id(),
                requirement_type=RequirementType.MONITOR_UNPREDICTABLE_OBJECT,
                priority=_clamp01(0.55),
                urgency=AbstractUrgency.MEDIUM,
                severity=AbstractSeverity.MEDIUM,
                confidence=sum(h.confidence for h in erratic) / len(erratic),
                uncertainty=sum(h.uncertainty for h in erratic) / len(erratic),
                evidence_type=EvidenceType.INFERRED,
                source="phase_8_2",
                affected_entity_ids=entities,
                affected_region="vicinity",
                time_relevance_s=None,
                reason_codes=("ERRATIC_BEHAVIOR_DETECTED",),
                constraints_summary="unpredictable_object_present",
                is_safety_critical=False,
                timestamp=ts,
                frame_id=frame_id,
            ))
            return reqs
        return reqs

    entities = tuple(h.hazard_id for h in unpredictable[:cfg.max_affected_entities])
    best = unpredictable[0]
    priority = _clamp01(
        _risk_score(best.risk_level.value) * 0.5 + 0.3  # base bonus for unpredictability
    )
    reqs.append(DecisionRequirement(
        requirement_id=_new_req_id(),
        requirement_type=RequirementType.MONITOR_UNPREDICTABLE_OBJECT,
        priority=priority,
        urgency=_ttc_to_urgency(best.ttc_s, best.ttc_band.value, cfg),
        severity=_risk_to_severity(best.risk_level.value),
        confidence=best.confidence,
        uncertainty=best.uncertainty,
        evidence_type=EvidenceType.OBSERVED,
        source="phase_8_1",
        affected_entity_ids=entities,
        affected_region="vicinity",
        time_relevance_s=best.ttc_s,
        reason_codes=("UNPREDICTABLE_PARTICIPANT_PRESENT",),
        constraints_summary="unpredictable_object_monitoring_required",
        is_safety_critical=best.risk_level.value in ("CRITICAL", "HIGH"),
        timestamp=ts,
        frame_id=frame_id,
    ))
    return reqs


def generate_uncertainty(
    situation: ReasoningSnapshot,
    behavior: Optional[BehaviorReasoningState],
    world: Optional[WorldModelSnapshot],
    cfg: ActionAbstractionConfig,
    frame_id: int,
    ts: float,
) -> List[DecisionRequirement]:
    """
    Generate HANDLE_UNCERTAINTY and DEGRADED_OPERATION when information
    is incomplete or degraded.
    """
    reqs: List[DecisionRequirement] = []
    unc = situation.uncertainty_info
    overall_unc = unc.overall_uncertainty

    # DEGRADED_OPERATION — severe degradation
    # Only apply world-model completeness check if the WM is actually provided.
    # A missing world model is a known partial-input condition, not degradation.
    world_completeness_degraded = (
        world is not None and
        world.data_quality.completeness < cfg.completeness_degraded_threshold
    )
    severe_degraded = (
        unc.sensor_degradation or
        overall_unc >= cfg.uncertainty_degraded_threshold or
        world_completeness_degraded
    )
    if severe_degraded:
        reqs.append(DecisionRequirement(
            requirement_id=_new_req_id(),
            requirement_type=RequirementType.DEGRADED_OPERATION,
            priority=_clamp01(0.85),
            urgency=AbstractUrgency.HIGH,
            severity=AbstractSeverity.HIGH,
            confidence=1.0 - overall_unc,
            uncertainty=overall_unc,
            evidence_type=EvidenceType.OBSERVED,
            source="uncertainty_assessment",
            affected_entity_ids=tuple(),
            affected_region="all",
            time_relevance_s=None,
            reason_codes=tuple(["SEVERE_DEGRADATION"] + unc.degraded_modules[:4]),
            constraints_summary="degraded_operation_mode",
            is_safety_critical=True,
            timestamp=ts,
            frame_id=frame_id,
        ))
        return reqs  # DEGRADED supersedes more specific uncertainty reqs

    # HANDLE_UNCERTAINTY — moderate information gap
    uncertainty_triggers = []
    if unc.prediction_unavailable and cfg.prediction_unavailable_triggers_uncertainty:
        uncertainty_triggers.append("PREDICTION_UNAVAILABLE")
    if unc.road_info_unavailable and cfg.road_info_unavailable_triggers_uncertainty:
        uncertainty_triggers.append("ROAD_INFO_UNAVAILABLE")
    if overall_unc >= cfg.uncertainty_high_threshold:
        uncertainty_triggers.append("HIGH_OVERALL_UNCERTAINTY")
    if behavior is not None and behavior.degraded:
        uncertainty_triggers.append("BEHAVIOR_REASONING_DEGRADED")

    if uncertainty_triggers:
        reqs.append(DecisionRequirement(
            requirement_id=_new_req_id(),
            requirement_type=RequirementType.HANDLE_UNCERTAINTY,
            priority=_clamp01(0.55 + overall_unc * 0.3),
            urgency=AbstractUrgency.MEDIUM,
            severity=AbstractSeverity.MEDIUM,
            confidence=1.0 - overall_unc,
            uncertainty=overall_unc,
            evidence_type=EvidenceType.INFERRED,
            source="uncertainty_assessment",
            affected_entity_ids=tuple(),
            affected_region="all",
            time_relevance_s=None,
            reason_codes=tuple(uncertainty_triggers[:cfg.max_reason_codes]),
            constraints_summary="operate_with_elevated_caution",
            is_safety_critical=False,
            timestamp=ts,
            frame_id=frame_id,
        ))

    return reqs


def generate_maintain_safe_space(
    situation: ReasoningSnapshot,
    cfg: ActionAbstractionConfig,
    frame_id: int,
    ts: float,
) -> List[DecisionRequirement]:
    """
    Generate MAINTAIN_SAFE_SPACE when objects are near but not yet
    collision-threatening.
    """
    reqs: List[DecisionRequirement] = []
    env = situation.environment
    if situation.hazards.total_hazards == 0:
        return reqs

    # Dense traffic or roadside activity
    dense = (
        env.traffic_density in ("HIGH", "VERY_HIGH") or
        env.has_roadside_activity or
        env.market_like_activity if hasattr(env, "market_like_activity") else False
    )
    low_risk_hazards = [
        h for h in situation.hazards.top_hazards
        if h.risk_level.value in ("LOW", "MEDIUM") and h.is_moving
    ]

    if dense or (len(low_risk_hazards) > 0 and situation.hazards.total_hazards > 1):
        priority = _clamp01(0.3 + (0.15 if dense else 0.0))
        reqs.append(DecisionRequirement(
            requirement_id=_new_req_id(),
            requirement_type=RequirementType.MAINTAIN_SAFE_SPACE,
            priority=priority,
            urgency=AbstractUrgency.LOW,
            severity=AbstractSeverity.LOW,
            confidence=situation.reasoning_confidence,
            uncertainty=situation.uncertainty_info.overall_uncertainty,
            evidence_type=EvidenceType.OBSERVED,
            source="phase_8_1",
            affected_entity_ids=tuple(),
            affected_region="surrounding_space",
            time_relevance_s=None,
            reason_codes=("DENSE_TRAFFIC_OR_ROADSIDE_ACTIVITY",) if dense else ("MULTIPLE_NEARBY_OBJECTS",),
            constraints_summary="maintain_clearance",
            is_safety_critical=False,
            timestamp=ts,
            frame_id=frame_id,
        ))
    return reqs


def generate_normal_progress(
    situation: ReasoningSnapshot,
    world: Optional[WorldModelSnapshot],
    cfg: ActionAbstractionConfig,
    frame_id: int,
    ts: float,
) -> List[DecisionRequirement]:
    """
    Generate NORMAL_PROGRESS ONLY when the environment truly supports it.
    This is suppressed if any critical threat, degradation, or high uncertainty exists.
    """
    reqs: List[DecisionRequirement] = []

    # Conditions that BLOCK normal progress
    if situation.risk.collision_threat_present:
        return reqs
    if situation.hazards.critical_hazards > 0:
        return reqs
    if situation.hazards.total_hazards > cfg.normal_progress_max_hazard_count:
        return reqs
    if situation.uncertainty_info.overall_uncertainty > cfg.normal_progress_max_uncertainty:
        return reqs
    if situation.uncertainty_info.sensor_degradation:
        return reqs

    risk_val = situation.risk.overall_risk_level.value
    if risk_val not in cfg.normal_progress_allowed_risk_levels:
        return reqs

    world_completeness = (
        world.data_quality.completeness if world is not None else 0.0
    )
    if world_completeness < cfg.normal_progress_min_world_completeness:
        if world is not None:
            return reqs

    # Also block if world model status is invalid / empty
    if world is not None and world.status in (WorldModelStatus.EMPTY, WorldModelStatus.INVALID):
        return reqs

    reqs.append(DecisionRequirement(
        requirement_id=_new_req_id(),
        requirement_type=RequirementType.NORMAL_PROGRESS,
        priority=0.1,
        urgency=AbstractUrgency.NONE,
        severity=AbstractSeverity.NONE,
        confidence=situation.reasoning_confidence,
        uncertainty=situation.uncertainty_info.overall_uncertainty,
        evidence_type=EvidenceType.OBSERVED,
        source="phase_8_1",
        affected_entity_ids=tuple(),
        affected_region="full_path",
        time_relevance_s=None,
        reason_codes=("ENVIRONMENT_SUPPORTS_NORMAL_OPERATION",),
        constraints_summary="normal_driving_conditions",
        is_safety_critical=False,
        timestamp=ts,
        frame_id=frame_id,
    ))
    return reqs


# ---------------------------------------------------------------------------
# Priority-ranking helpers
# ---------------------------------------------------------------------------

def _urgency_rank(u: AbstractUrgency) -> int:
    return {
        AbstractUrgency.IMMEDIATE: 5,
        AbstractUrgency.HIGH: 4,
        AbstractUrgency.MEDIUM: 3,
        AbstractUrgency.LOW: 2,
        AbstractUrgency.NONE: 1,
        AbstractUrgency.UNKNOWN: 0,
    }.get(u, 0)


def _severity_rank(s: AbstractSeverity) -> int:
    return {
        AbstractSeverity.CRITICAL: 4,
        AbstractSeverity.HIGH: 3,
        AbstractSeverity.MEDIUM: 2,
        AbstractSeverity.LOW: 1,
        AbstractSeverity.NONE: 0,
        AbstractSeverity.UNKNOWN: 0,
    }.get(s, 0)
