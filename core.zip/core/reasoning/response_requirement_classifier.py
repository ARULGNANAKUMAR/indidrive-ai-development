"""
IndiDrive AI — Phase 8.3 | Response Requirement Classifier
===========================================================
Deterministic logic to:
  1. Assign the overall ResponseFamily from a list of requirements.
  2. Compute overall urgency and severity aggregates.
  3. Detect requirement relationships.

No vehicle commands, no path planning, no LLM.
Same inputs → same outputs (deterministic).
"""
from __future__ import annotations

from typing import List, Tuple

from .action_abstraction_types import (
    NOT_AVAILABLE,
    AbstractSeverity,
    AbstractUrgency,
    DecisionRequirement,
    RequirementRelationship,
    RequirementRelationshipEntry,
    RequirementType,
    ResponseFamily,
)
from .action_abstraction_config import ActionAbstractionConfig


# ---------------------------------------------------------------------------
# Urgency / severity ranking helpers
# ---------------------------------------------------------------------------

_URGENCY_RANK = {
    AbstractUrgency.IMMEDIATE: 5,
    AbstractUrgency.HIGH: 4,
    AbstractUrgency.MEDIUM: 3,
    AbstractUrgency.LOW: 2,
    AbstractUrgency.NONE: 1,
    AbstractUrgency.UNKNOWN: 0,
}

_SEVERITY_RANK = {
    AbstractSeverity.CRITICAL: 4,
    AbstractSeverity.HIGH: 3,
    AbstractSeverity.MEDIUM: 2,
    AbstractSeverity.LOW: 1,
    AbstractSeverity.NONE: 0,
    AbstractSeverity.UNKNOWN: 0,
}


def _max_urgency(reqs: List[DecisionRequirement]) -> AbstractUrgency:
    if not reqs:
        return AbstractUrgency.UNKNOWN
    return max(reqs, key=lambda r: _URGENCY_RANK.get(r.urgency, 0)).urgency


def _max_severity(reqs: List[DecisionRequirement]) -> AbstractSeverity:
    if not reqs:
        return AbstractSeverity.UNKNOWN
    return max(reqs, key=lambda r: _SEVERITY_RANK.get(r.severity, 0)).severity


# ---------------------------------------------------------------------------
# Response family classification
# ---------------------------------------------------------------------------

# Safety-critical requirement types
_SAFETY_CRITICAL_TYPES = {
    RequirementType.COLLISION_AVOIDANCE_REQUIRED,
    RequirementType.HANDLE_TRAJECTORY_CONFLICT,
    RequirementType.HANDLE_VULNERABLE_USER,
    RequirementType.MAINTAIN_DRIVABLE_REGION,
}

# Hazard-handling types
_HAZARD_TYPES = {
    RequirementType.HANDLE_ROAD_HAZARD,
    RequirementType.HANDLE_NARROW_ROAD,
    RequirementType.HANDLE_INTERSECTION,
    RequirementType.HANDLE_MERGE,
}

# Conflict-handling types
_CONFLICT_TYPES = {
    RequirementType.HANDLE_TRAJECTORY_CONFLICT,
    RequirementType.COLLISION_AVOIDANCE_REQUIRED,
}

# Degraded types
_DEGRADED_TYPES = {
    RequirementType.DEGRADED_OPERATION,
}

# Uncertainty types
_UNCERTAINTY_TYPES = {
    RequirementType.HANDLE_UNCERTAINTY,
}


def classify_response_family(
    requirements: List[DecisionRequirement],
) -> ResponseFamily:
    """
    Determine the overall response family from the active requirements.

    Priority order (highest first):
      1. DEGRADED — if DEGRADED_OPERATION present
      2. SAFETY_CRITICAL — collision avoidance, trajectory conflict,
                           VRU with high severity, drivable region
      3. CONFLICT_HANDLING — trajectory conflicts
      4. HAZARD_HANDLING — road hazards, narrow road, intersection, merge
      5. UNCERTAINTY_MANAGEMENT — handle uncertainty
      6. CAUTION — any remaining non-normal
      7. NORMAL — only if NORMAL_PROGRESS is the sole/dominant requirement

    This is NOT final arbitration.  Phase 8.4 handles that.
    """
    if not requirements:
        return ResponseFamily.UNKNOWN

    req_types = {r.requirement_type for r in requirements}

    # 1. Degraded
    if req_types & _DEGRADED_TYPES:
        return ResponseFamily.DEGRADED

    # 2. Safety critical
    safety_critical_active = [
        r for r in requirements
        if r.requirement_type in _SAFETY_CRITICAL_TYPES and r.is_safety_critical
    ]
    if safety_critical_active:
        max_urg = _max_urgency(safety_critical_active)
        max_sev = _max_severity(safety_critical_active)
        if (
            _URGENCY_RANK.get(max_urg, 0) >= _URGENCY_RANK[AbstractUrgency.HIGH] or
            _SEVERITY_RANK.get(max_sev, 0) >= _SEVERITY_RANK[AbstractSeverity.HIGH]
        ):
            return ResponseFamily.SAFETY_CRITICAL

    # 3. Conflict handling
    if req_types & _CONFLICT_TYPES:
        return ResponseFamily.CONFLICT_HANDLING

    # 4. Hazard handling
    if req_types & _HAZARD_TYPES:
        return ResponseFamily.HAZARD_HANDLING

    # 5. Uncertainty management
    if req_types & _UNCERTAINTY_TYPES:
        return ResponseFamily.UNCERTAINTY_MANAGEMENT

    # 6. Caution — any monitoring or safe-space requirement
    caution_types = {
        RequirementType.MAINTAIN_SAFE_SPACE,
        RequirementType.MONITOR_DYNAMIC_OBJECT,
        RequirementType.MONITOR_UNPREDICTABLE_OBJECT,
        RequirementType.HANDLE_VULNERABLE_USER,
    }
    if req_types & caution_types:
        return ResponseFamily.CAUTION

    # 7. Normal
    if req_types == {RequirementType.NORMAL_PROGRESS}:
        return ResponseFamily.NORMAL

    return ResponseFamily.CAUTION  # conservative default


# ---------------------------------------------------------------------------
# Requirement relationship detection
# ---------------------------------------------------------------------------

# Known conflicting pairs (type A, type B) — order-independent
_CONFLICTING_PAIRS = frozenset({
    frozenset({RequirementType.NORMAL_PROGRESS, RequirementType.COLLISION_AVOIDANCE_REQUIRED}),
    frozenset({RequirementType.NORMAL_PROGRESS, RequirementType.HANDLE_TRAJECTORY_CONFLICT}),
    frozenset({RequirementType.NORMAL_PROGRESS, RequirementType.DEGRADED_OPERATION}),
    frozenset({RequirementType.NORMAL_PROGRESS, RequirementType.HANDLE_UNCERTAINTY}),
})

# Known supporting pairs (type A supports type B)
_SUPPORTING_PAIRS = frozenset({
    frozenset({RequirementType.HANDLE_ROAD_HAZARD, RequirementType.MAINTAIN_DRIVABLE_REGION}),
    frozenset({RequirementType.HANDLE_NARROW_ROAD, RequirementType.MAINTAIN_DRIVABLE_REGION}),
    frozenset({RequirementType.COLLISION_AVOIDANCE_REQUIRED, RequirementType.HANDLE_VULNERABLE_USER}),
    frozenset({RequirementType.HANDLE_TRAJECTORY_CONFLICT, RequirementType.COLLISION_AVOIDANCE_REQUIRED}),
    frozenset({RequirementType.HANDLE_UNCERTAINTY, RequirementType.DEGRADED_OPERATION}),
})

# Known compatible pairs
_COMPATIBLE_PAIRS = frozenset({
    frozenset({RequirementType.MAINTAIN_SAFE_SPACE, RequirementType.MONITOR_DYNAMIC_OBJECT}),
    frozenset({RequirementType.MONITOR_DYNAMIC_OBJECT, RequirementType.MONITOR_UNPREDICTABLE_OBJECT}),
    frozenset({RequirementType.HANDLE_INTERSECTION, RequirementType.HANDLE_VULNERABLE_USER}),
    frozenset({RequirementType.HANDLE_INTERSECTION, RequirementType.MAINTAIN_SAFE_SPACE}),
    frozenset({RequirementType.HANDLE_MERGE, RequirementType.HANDLE_TRAJECTORY_CONFLICT}),
})


def detect_relationships(
    requirements: List[DecisionRequirement],
    cfg: ActionAbstractionConfig,
) -> List[RequirementRelationshipEntry]:
    """
    Detect relationships between simultaneously active requirements.

    Phase 8.3 exposes relationships — does NOT arbitrate between them.
    Final arbitration belongs to Phase 8.4.

    Returns deterministic list (sorted by requirement_id pairs).
    """
    if not cfg.detect_relationships or len(requirements) < 2:
        return []

    entries: List[RequirementRelationshipEntry] = []

    for i in range(len(requirements)):
        for j in range(i + 1, len(requirements)):
            a = requirements[i]
            b = requirements[j]
            pair = frozenset({a.requirement_type, b.requirement_type})

            relationship = None
            note = NOT_AVAILABLE

            if pair in _CONFLICTING_PAIRS:
                relationship = RequirementRelationship.CONFLICTING
                note = "MUTUALLY_EXCLUSIVE_REQUIREMENTS"
            elif pair in _SUPPORTING_PAIRS:
                relationship = RequirementRelationship.SUPPORTING
                note = "REQUIREMENTS_REINFORCE_EACH_OTHER"
            elif pair in _COMPATIBLE_PAIRS:
                relationship = RequirementRelationship.COMPATIBLE
                note = "REQUIREMENTS_COEXIST_SAFELY"

            if relationship is not None:
                entries.append(RequirementRelationshipEntry(
                    requirement_id_a=a.requirement_id,
                    requirement_id_b=b.requirement_id,
                    relationship=relationship,
                    note=note,
                ))

    # Deterministic sort
    entries.sort(key=lambda e: (e.requirement_id_a, e.requirement_id_b))
    return entries[:cfg.max_relationships]
