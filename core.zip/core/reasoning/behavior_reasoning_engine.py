"""
IndiDrive AI — Phase 8.2 | Behavior Reasoning Engine (Public API)
==================================================================
Main entry point for Phase 8.2 Multi-Hazard Interaction & Behavior
Reasoning.

Usage
-----
    config = load_behavior_reasoning_config()
    engine = BehaviorReasoningEngine(config=config)
    result = engine.reason(world_model_snapshot, reasoning_snapshot)

    state = result.state
    if result.is_valid:
        print(state.entity_behaviors)
        print(state.interactions)
        print(state.compound_situations)

Inputs
------
  - Phase 7 WorldModelSnapshot (required)
  - Phase 8.1 ReasoningSnapshot (required)

Both are consumed read-only.  Neither is mutated.

Outputs
-------
  - BehaviorReasoningResult containing a BehaviorReasoningState

Architectural Boundary
-----------------------
Phase 8.2 does NOT implement:
  - Path planning / Hybrid A* / MPC
  - Steering / throttle / brake commands
  - Lane-change or overtaking execution
  - Vehicle control of any kind
  - New perception / tracking / prediction engine
  - New TTC or collision-likelihood engine
  - New memory system
  - LLM / cloud / vector database / FAISS
  - Large neural networks

The output is structured behavior and interaction reasoning only.

Thread Safety
-------------
reason() is stateless.  Multiple snapshots can be processed
concurrently with independent engine instances.  No global mutable
state is shared.
"""
from __future__ import annotations

import time
from typing import Dict, List, Optional

from core.world_model.world_model_types import (
    WorldModelSnapshot,
    WorldModelStatus,
    WorldObject,
    NOT_AVAILABLE,
)
from .reasoning_types import ReasoningSnapshot, HazardEntry, RiskLevel
from .behavior_reasoning_config import BehaviorReasoningConfig, load_behavior_reasoning_config
from .behavior_types import (
    BehaviorClassification,
    BehaviorReasoningResult,
    BehaviorReasoningState,
    BehaviorState,
    CompoundSituation,
    EvidenceClass,
    IntentHypothesis,
    InteractionSeverity,
    NOT_AVAILABLE as B_NOT_AVAILABLE,
    BEHAVIOR_REASONING_SCHEMA_VERSION,
)
from .behavior_classifier import BehaviorClassifier
from .intent_estimator import IntentEstimator
from .interaction_graph_builder import InteractionGraphBuilder
from .multi_hazard_reasoner import MultiHazardReasoner
from .behavior_validator import BehaviorValidator

__all__ = ["BehaviorReasoningEngine"]

_SEVERITY_ORDER = {
    InteractionSeverity.CRITICAL: 4,
    InteractionSeverity.HIGH: 3,
    InteractionSeverity.MEDIUM: 2,
    InteractionSeverity.LOW: 1,
    InteractionSeverity.UNKNOWN: 0,
}
_RISK_ORDER = {"CRITICAL": 4, "HIGH": 3, "MEDIUM": 2, "LOW": 1, NOT_AVAILABLE: 0}


class BehaviorReasoningEngine:
    """
    Phase 8.2 Behavior Reasoning Engine.

    Consumes Phase 7 WorldModelSnapshot + Phase 8.1 ReasoningSnapshot.
    Produces a BehaviorReasoningState that answers:
      «"How are the important entities interacting, and what behavior/
        intent pattern is emerging?"»

    Deterministic: same inputs → same outputs.
    Stateless: no mutable internal state between reason() calls.
    """

    def __init__(
        self,
        config: Optional[BehaviorReasoningConfig] = None,
        config_path: Optional[str] = None,
    ) -> None:
        if config is not None:
            self._cfg = config
        else:
            self._cfg = load_behavior_reasoning_config(config_path)

        self._classifier = BehaviorClassifier(self._cfg)
        self._intent_estimator = IntentEstimator(self._cfg)
        self._graph_builder = InteractionGraphBuilder(self._cfg)
        self._multi_hazard = MultiHazardReasoner(self._cfg)
        self._validator = BehaviorValidator(self._cfg)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def reason(
        self,
        world_model: WorldModelSnapshot,
        phase81: ReasoningSnapshot,
        memory_context: str = "unavailable",
    ) -> BehaviorReasoningResult:
        """
        Produce a BehaviorReasoningResult from current inputs.

        Never raises.  Partial/invalid inputs produce degraded output.
        world_model and phase81 are consumed read-only — never mutated.

        Parameters
        ----------
        world_model : WorldModelSnapshot
            Current Phase 7 world model.
        phase81 : ReasoningSnapshot
            Phase 8.1 situation assessment for this cycle.
        memory_context : str
            Optional read-only context from Phase 5.  Use "unavailable"
            when Phase 5 is absent.
        """
        t0 = time.monotonic()
        warnings: List[str] = []
        errors: List[str] = []

        # --- Validate inputs ---
        if world_model is None:
            return self._empty_result("world_model_none", errors, t0)
        if phase81 is None:
            return self._empty_result("phase81_none", errors, t0)

        wm_ok = world_model.status not in (WorldModelStatus.INVALID, WorldModelStatus.EMPTY)
        if not wm_ok:
            warnings.append(f"world_model_status_{world_model.status.value}")

        # --- Core data extraction ---
        now = world_model.timestamp
        hazards: List[HazardEntry] = list(phase81.hazards.top_hazards)

        # Build object index
        objects_by_id: Dict[str, WorldObject] = {}
        for obj in world_model.objects:
            oid = obj.primary_id()
            if oid:
                objects_by_id[oid] = obj

        # Road context
        road_is_narrow = self._check_narrow(world_model)
        indian_ctx = world_model.indian_context
        has_indian_ctx = indian_ctx.available
        indian_road_type = indian_ctx.road_type if has_indian_ctx else NOT_AVAILABLE

        # --- Step 1: Behavior classification ---
        behaviors: List[BehaviorClassification] = self._classifier.classify_all(
            world_model.objects, now
        )

        # --- Step 2: Intent estimation ---
        intent_hypos: List[IntentHypothesis] = self._intent_estimator.estimate_all(
            behaviors, objects_by_id, road_is_narrow, has_indian_ctx, indian_road_type
        )

        # --- Step 3: Pairwise interactions + graph ---
        interactions, graph = self._graph_builder.build(
            world_model, behaviors, hazards
        )

        # --- Step 4: Multi-hazard reasoning ---
        compound_situations: List[CompoundSituation] = self._multi_hazard.reason(
            world_model, hazards, behaviors, interactions
        )

        # --- Step 5: Dominant interaction prioritization ---
        dominant = self._select_dominant(interactions)

        # --- Step 6: Overall complexity ---
        complexity = self._compute_complexity(
            behaviors, interactions, compound_situations, phase81
        )

        # --- Step 7: Overall confidence / uncertainty / completeness ---
        conf, unc, completeness = self._aggregate_quality(
            world_model, behaviors, interactions, hazards
        )

        # --- Step 8: Reason codes ---
        reason_codes = self._collect_reason_codes(
            world_model, phase81, behaviors, interactions, compound_situations, road_is_narrow
        )

        # --- Degraded flag ---
        degraded = (
            not wm_ok or
            world_model.data_quality.is_partial or
            (not behaviors and not hazards)
        )

        # --- Assemble state ---
        state = BehaviorReasoningState(
            schema_version=BEHAVIOR_REASONING_SCHEMA_VERSION,
            timestamp=now,
            frame_id=world_model.frame_id,
            _entity_behaviors=tuple(behaviors),
            _interactions=tuple(interactions),
            _intent_hypotheses=tuple(intent_hypos),
            interaction_graph=graph,
            _compound_situations=tuple(compound_situations),
            _dominant_interactions=tuple(dominant),
            overall_interaction_complexity=complexity,
            confidence=round(conf, 3),
            uncertainty=round(unc, 3),
            completeness=round(completeness, 3),
            degraded=degraded,
            reason_codes=reason_codes[: self._cfg.max_graph_edges],
            memory_context=str(memory_context),
        )

        # --- Validation ---
        _val = self._validator.validate(state)
        if not _val.is_valid:
            warnings.extend(_val.warnings)

        duration = time.monotonic() - t0
        has_data = bool(behaviors or interactions or hazards)
        if not has_data and len(world_model.objects) == 0:
            status = "empty"
        elif degraded or warnings:
            status = "degraded"
        else:
            status = "ok"

        return BehaviorReasoningResult(
            state=state,
            status=status,
            warnings=warnings,
            errors=errors,
            duration_s=round(duration, 6),
        )

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _check_narrow(self, wm: WorldModelSnapshot) -> bool:
        dw = wm.road.drivable_space.road_width_m
        if dw is not None and dw < self._cfg.narrow_road_width_m:
            return True
        if wm.indian_context.available:
            rt = wm.indian_context.road_type
            if rt in ("VILLAGE_ROAD", "NARROW_ROAD"):
                return True
        return False

    def _select_dominant(
        self,
        interactions: List,
    ) -> List:
        """
        Select dominant interactions for attention prioritization.
        NOT a driving decision — only indicates which interactions
        deserve the most reasoning attention.
        Sorted by severity (desc) then confidence (desc).
        """
        scored = sorted(
            interactions,
            key=lambda i: (
                _SEVERITY_ORDER.get(i.severity, 0),
                i.confidence,
            ),
            reverse=True,
        )
        return scored[: self._cfg.max_dominant_interactions]

    def _compute_complexity(
        self,
        behaviors: List,
        interactions: List,
        compounds: List,
        phase81: ReasoningSnapshot,
    ) -> str:
        """Compute overall interaction complexity label."""
        # Score from multiple factors
        n_int = len(interactions)
        n_compound = len(compounds)
        n_critical = sum(
            1 for i in interactions
            if i.severity in (InteractionSeverity.CRITICAL, InteractionSeverity.HIGH)
        )
        base_complexity = phase81.complexity.complexity_level.value

        # Map base → score
        base_score = {"LOW": 0, "MEDIUM": 1, "HIGH": 2, "VERY_HIGH": 3, "UNKNOWN": 0}.get(
            base_complexity, 0
        )
        interaction_score = min(3, n_int // 3)
        compound_score = min(2, n_compound)
        critical_score = min(2, n_critical)

        total = base_score + interaction_score + compound_score + critical_score
        if total <= 1:
            return "LOW"
        if total <= 3:
            return "MEDIUM"
        if total <= 6:
            return "HIGH"
        return "VERY_HIGH"

    def _aggregate_quality(
        self,
        wm: WorldModelSnapshot,
        behaviors: List,
        interactions: List,
        hazards: List,
    ):
        """Compute overall confidence, uncertainty, completeness."""
        dq = wm.data_quality

        # Completeness: fraction of expected data that arrived
        has_objects = len(wm.objects) > 0
        has_road = wm.road.status.value not in ("NONE", "DEGRADED")
        has_prediction = any(
            o.prediction.availability.value == "FULL" for o in wm.objects
        )
        has_collision = any(
            o.collision.ttc_s is not None for o in wm.objects
        )
        n_ok = sum([has_objects, has_road, has_prediction, has_collision])
        completeness = n_ok / 4.0

        # Confidence from world model + behaviors
        if behaviors:
            avg_bc = sum(b.behavior_confidence for b in behaviors) / len(behaviors)
        else:
            avg_bc = 0.3

        wm_conf = dq.overall_confidence if dq.overall_confidence > 0 else 0.5
        conf = (wm_conf + avg_bc) / 2.0
        conf = max(0.05, min(0.95, conf))
        unc = round(1.0 - conf, 3)
        return round(conf, 3), unc, round(completeness, 3)

    def _collect_reason_codes(
        self,
        wm: WorldModelSnapshot,
        phase81: ReasoningSnapshot,
        behaviors: List,
        interactions: List,
        compounds: List,
        road_is_narrow: bool,
    ) -> List[str]:
        codes: List[str] = []
        if road_is_narrow:
            codes.append("NARROW_ROAD")
        if wm.indian_context.cattle_present:
            codes.append("CATTLE_PRESENT")
        if wm.indian_context.vulnerable_road_users:
            codes.append("VULNERABLE_ROAD_USERS_PRESENT")
        if wm.indian_context.market_like_activity:
            codes.append("MARKET_ACTIVITY")
        if any(b.behavior_state == BehaviorState.UNCERTAIN for b in behaviors):
            codes.append("CONFLICTING_BEHAVIOR_EVIDENCE")
        n_critical = sum(
            1 for i in interactions
            if i.severity == InteractionSeverity.CRITICAL
        )
        if n_critical:
            codes.append(f"CRITICAL_INTERACTIONS_{n_critical}")
        if compounds:
            codes.append(f"COMPOUND_SITUATIONS_{len(compounds)}")
        return codes

    @staticmethod
    def _empty_result(
        reason: str,
        errors: List[str],
        t0: float,
    ) -> BehaviorReasoningResult:
        errors.append(reason)
        from .behavior_types import InteractionGraph
        state = BehaviorReasoningState(
            degraded=True,
            reason_codes=[reason],
        )
        return BehaviorReasoningResult(
            state=state,
            status="error",
            errors=errors,
            duration_s=round(time.monotonic() - t0, 6),
        )
