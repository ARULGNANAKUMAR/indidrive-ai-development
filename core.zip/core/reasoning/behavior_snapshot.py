"""
IndiDrive AI — Phase 8.2 | Behavior Reasoning Snapshot Utilities
=================================================================
Safe read-only utilities for BehaviorReasoningState.

Rules:
  - All operations are read-only; inputs are never mutated
  - Repeated reads are safe (deterministic)
  - No mutable copies are returned
"""
from __future__ import annotations

import json
import time
from typing import Any, Dict

from .behavior_types import (
    BehaviorReasoningState,
    BehaviorReasoningResult,
    InteractionSeverity,
    NOT_AVAILABLE,
)

__all__ = [
    "behavior_state_age_s",
    "is_behavior_state_stale",
    "behavior_state_to_json",
    "behavior_state_summary",
    "safe_copy_behavior_state",
]


def behavior_state_age_s(state: BehaviorReasoningState, now: float | None = None) -> float:
    """Return the age of this state in seconds (wall-clock)."""
    if now is None:
        now = time.time()
    return max(0.0, now - state.timestamp)


def is_behavior_state_stale(
    state: BehaviorReasoningState,
    threshold_s: float = 1.5,
    now: float | None = None,
) -> bool:
    """True if the state is older than threshold_s."""
    return behavior_state_age_s(state, now) > threshold_s


def behavior_state_to_json(state: BehaviorReasoningState, indent: int = 2) -> str:
    """Serialise the state to a JSON string.  Read-only; state is not mutated."""
    return json.dumps(state.to_dict(), indent=indent, default=str)


def behavior_state_summary(state: BehaviorReasoningState) -> Dict[str, Any]:
    """
    Return a compact summary dict (no large lists).

    Safe to log at DEBUG level without flooding output.
    """
    n_critical = sum(
        1 for i in state.interactions
        if i.severity == InteractionSeverity.CRITICAL
    )
    n_high = sum(
        1 for i in state.interactions
        if i.severity == InteractionSeverity.HIGH
    )
    return {
        "schema_version": state.schema_version,
        "timestamp": state.timestamp,
        "frame_id": state.frame_id,
        "entity_count": state.entity_count,
        "interaction_count": state.interaction_count,
        "intent_count": state.intent_count,
        "compound_count": state.compound_count,
        "graph_nodes": state.interaction_graph.node_count,
        "graph_edges": state.interaction_graph.edge_count,
        "critical_interactions": n_critical,
        "high_interactions": n_high,
        "overall_complexity": state.overall_interaction_complexity,
        "confidence": state.confidence,
        "uncertainty": state.uncertainty,
        "completeness": state.completeness,
        "degraded": state.degraded,
        "memory_context": state.memory_context,
        "reason_code_count": len(state.reason_codes),
    }


def safe_copy_behavior_state(state: BehaviorReasoningState) -> Dict[str, Any]:
    """
    Return a deep-copy of the state as a plain dict.

    The original state is not mutated.  The copy is a plain dict —
    not a BehaviorReasoningState — so it cannot affect upstream data.
    """
    return state.to_dict()
