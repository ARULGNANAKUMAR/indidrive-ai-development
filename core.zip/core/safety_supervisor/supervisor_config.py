"""
IndiDrive AI — Phase 11.3 | Safety Supervisor Configuration
============================================================
Validated, deterministic configuration for the Safety Supervisor.
All thresholds live here — no magic numbers scattered through the engine.
"""
from __future__ import annotations

from dataclasses import dataclass

__all__ = ["SupervisorConfig"]

# Safe defaults
_DEFAULT_SAFETY_STATE_TIMEOUT_S:   float = 1.0
_DEFAULT_EMERGENCY_STATE_TIMEOUT_S: float = 1.0
_DEFAULT_PLANNER_STATE_TIMEOUT_S:  float = 1.0
_DEFAULT_TRACKING_STATE_TIMEOUT_S: float = 0.5
_DEFAULT_MPC_STATE_TIMEOUT_S:      float = 0.5
_DEFAULT_CONTROL_STATE_TIMEOUT_S:  float = 0.5
_DEFAULT_VEHICLE_STATE_TIMEOUT_S:  float = 0.5

_DEFAULT_ACTIVATION_CYCLES:        int   = 1   # cycles before escalating
_DEFAULT_CLEAR_CYCLES:             int   = 3   # clean cycles before recovering
_DEFAULT_MIN_OVERRIDE_HOLD:        int   = 2   # min cycles at OVERRIDE_REQUIRED

_DEFAULT_MIN_CONFIDENCE_FOR_VALID: float = 0.1
_DEFAULT_HIGH_UNCERTAINTY:         float = 0.8


@dataclass
class SupervisorConfig:
    """
    Configuration for the Safety Supervisor.

    Timeout thresholds (seconds)
    ----------------------------
    safety_state_timeout_s    : Max age of SafetyMonitorState.
    emergency_state_timeout_s : Max age of EmergencyDetectionState.
    planner_state_timeout_s   : Max age of PlannerOutput.
    tracking_state_timeout_s  : Max age of TrackingSnapshot.
    mpc_state_timeout_s       : Max age of MPCSnapshot.
    control_state_timeout_s   : Max age of VehicleControlCommand.
    vehicle_state_timeout_s   : Max age of DynamicsSnapshot.

    Hysteresis
    ----------
    activation_cycles       : Cycles a raw escalation must persist.
    clear_cycles            : Clean cycles before stepping down authority.
    min_override_hold_cycles: Min cycles to hold OVERRIDE_REQUIRED.

    Confidence / uncertainty
    ------------------------
    min_confidence_for_valid  : Below this → UNKNOWN_CONTROL_AUTHORITY.
    high_uncertainty_threshold: Above this → conservative authority.

    Feature flags
    -------------
    enable_hysteresis : Master toggle for hysteresis logic.
    """
    # Timeouts
    safety_state_timeout_s:    float = _DEFAULT_SAFETY_STATE_TIMEOUT_S
    emergency_state_timeout_s: float = _DEFAULT_EMERGENCY_STATE_TIMEOUT_S
    planner_state_timeout_s:   float = _DEFAULT_PLANNER_STATE_TIMEOUT_S
    tracking_state_timeout_s:  float = _DEFAULT_TRACKING_STATE_TIMEOUT_S
    mpc_state_timeout_s:       float = _DEFAULT_MPC_STATE_TIMEOUT_S
    control_state_timeout_s:   float = _DEFAULT_CONTROL_STATE_TIMEOUT_S
    vehicle_state_timeout_s:   float = _DEFAULT_VEHICLE_STATE_TIMEOUT_S

    # Hysteresis
    activation_cycles:        int = _DEFAULT_ACTIVATION_CYCLES
    clear_cycles:             int = _DEFAULT_CLEAR_CYCLES
    min_override_hold_cycles: int = _DEFAULT_MIN_OVERRIDE_HOLD

    # Confidence / uncertainty
    min_confidence_for_valid:   float = _DEFAULT_MIN_CONFIDENCE_FOR_VALID
    high_uncertainty_threshold: float = _DEFAULT_HIGH_UNCERTAINTY

    # Feature flags
    enable_hysteresis: bool = True

    def __post_init__(self) -> None:
        self._validate()

    def _validate(self) -> None:
        for name, val in [
            ("safety_state_timeout_s",    self.safety_state_timeout_s),
            ("emergency_state_timeout_s", self.emergency_state_timeout_s),
            ("planner_state_timeout_s",   self.planner_state_timeout_s),
            ("tracking_state_timeout_s",  self.tracking_state_timeout_s),
            ("mpc_state_timeout_s",       self.mpc_state_timeout_s),
            ("control_state_timeout_s",   self.control_state_timeout_s),
            ("vehicle_state_timeout_s",   self.vehicle_state_timeout_s),
        ]:
            if not isinstance(val, (int, float)) or val <= 0:
                raise ValueError(f"SupervisorConfig.{name} must be > 0, got {val!r}")

        for name, val in [
            ("activation_cycles",        self.activation_cycles),
            ("clear_cycles",             self.clear_cycles),
            ("min_override_hold_cycles", self.min_override_hold_cycles),
        ]:
            if not isinstance(val, int) or val < 0:
                raise ValueError(f"SupervisorConfig.{name} must be >= 0, got {val!r}")

        for name, val in [
            ("min_confidence_for_valid",   self.min_confidence_for_valid),
            ("high_uncertainty_threshold", self.high_uncertainty_threshold),
        ]:
            if not (0.0 <= val <= 1.0):
                raise ValueError(f"SupervisorConfig.{name} must be in [0,1], got {val!r}")

    @classmethod
    def default(cls) -> "SupervisorConfig":
        return cls()

    @classmethod
    def sensitive(cls) -> "SupervisorConfig":
        """Quicker activation, slower recovery — conservative in the field."""
        return cls(
            activation_cycles=1,
            clear_cycles=5,
            min_override_hold_cycles=3,
        )

    @classmethod
    def strict(cls) -> "SupervisorConfig":
        """Tight timeouts, long hold periods."""
        return cls(
            safety_state_timeout_s=0.3,
            emergency_state_timeout_s=0.3,
            tracking_state_timeout_s=0.2,
            mpc_state_timeout_s=0.2,
            control_state_timeout_s=0.2,
            vehicle_state_timeout_s=0.2,
            activation_cycles=1,
            clear_cycles=6,
            min_override_hold_cycles=4,
        )
