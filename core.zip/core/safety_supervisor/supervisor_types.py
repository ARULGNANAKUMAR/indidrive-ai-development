"""
IndiDrive AI — Phase 11.3 | Safety Supervisor Types
=====================================================
Typed enumerations and immutable data containers for the Safety Supervisor.

Design rules:
  * All containers are frozen dataclasses — immutable after construction.
  * No computation — type definitions only.
  * No circular imports — stdlib and typing only.
  * Deterministic: same input → same output.
  * UNKNOWN and CONTROL_WITHHELD are explicit, never silent NORMAL_CONTROL fallbacks.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Optional, Tuple

__all__ = [
    "SUPERVISOR_SCHEMA_VERSION",
    # Enums
    "ControlAuthority",
    "SupervisorStatus",
    "OverrideReason",
    "TransitionDirection",
    # Containers
    "TransitionInfo",
    "SafetySupervisorDecision",
    "SafetySupervisorSnapshot",
]

SUPERVISOR_SCHEMA_VERSION: str = "11.3"


# ---------------------------------------------------------------------------
# Control Authority — the primary output of the Safety Supervisor
# ---------------------------------------------------------------------------

class ControlAuthority(str, Enum):
    """
    Permitted control authority as determined by the Safety Supervisor.

    NORMAL_CONTROL          — Normal planner/MPC/control pipeline may continue.
    LIMITED_CONTROL         — Normal control allowed but under safety restrictions
                              (reduced envelope, increased monitoring).
    RESTRICTED_CONTROL      — Normal control significantly restricted;
                              downstream must not assume unrestricted authority.
    SAFETY_CONTROL_REQUIRED — Safety-supervised behavior required. Decision only —
                              does NOT generate emergency actuator commands.
    OVERRIDE_REQUIRED       — Normal control decision must not be trusted as-is;
                              a higher-level safety mechanism must take authority.
    CONTROL_WITHHELD        — Supervisor does not authorise normal control
                              (invalid, stale, critically degraded, or unsafe state).
    DEGRADED_CONTROL        — Control may continue only under explicitly degraded
                              conditions.
    UNKNOWN_CONTROL_AUTHORITY — Supervisor cannot safely determine permitted
                              authority. Treat conservatively.
    """
    NORMAL_CONTROL            = "NORMAL_CONTROL"
    LIMITED_CONTROL           = "LIMITED_CONTROL"
    RESTRICTED_CONTROL        = "RESTRICTED_CONTROL"
    SAFETY_CONTROL_REQUIRED   = "SAFETY_CONTROL_REQUIRED"
    OVERRIDE_REQUIRED         = "OVERRIDE_REQUIRED"
    CONTROL_WITHHELD          = "CONTROL_WITHHELD"
    DEGRADED_CONTROL          = "DEGRADED_CONTROL"
    UNKNOWN_CONTROL_AUTHORITY = "UNKNOWN_CONTROL_AUTHORITY"


# Ordered from most to least restrictive (for priority comparison)
AUTHORITY_RESTRICTIVENESS: Tuple[ControlAuthority, ...] = (
    ControlAuthority.CONTROL_WITHHELD,
    ControlAuthority.OVERRIDE_REQUIRED,
    ControlAuthority.SAFETY_CONTROL_REQUIRED,
    ControlAuthority.RESTRICTED_CONTROL,
    ControlAuthority.DEGRADED_CONTROL,
    ControlAuthority.LIMITED_CONTROL,
    ControlAuthority.NORMAL_CONTROL,
    # UNKNOWN handled separately — treated as more restrictive than NORMAL
)


# ---------------------------------------------------------------------------
# Supervisor internal status
# ---------------------------------------------------------------------------

class SupervisorStatus(str, Enum):
    """Internal status of the Safety Supervisor engine."""
    OK          = "OK"
    DEGRADED    = "DEGRADED"
    UNAVAILABLE = "UNAVAILABLE"
    ERROR       = "ERROR"


# ---------------------------------------------------------------------------
# Override reason codes
# ---------------------------------------------------------------------------

class OverrideReason(str, Enum):
    """
    Deterministic reason codes explaining why a control authority was chosen.
    Reuses existing Phase 11.1 / 11.2 reason code concepts where compatible.
    """
    # Emergency-derived
    CRITICAL_EMERGENCY             = "CRITICAL_EMERGENCY"
    IMMINENT_COLLISION             = "IMMINENT_COLLISION"
    CRITICAL_TTC                   = "CRITICAL_TTC"
    UNAVOIDABLE_CONFLICT           = "UNAVOIDABLE_CONFLICT"
    CRITICAL_PATH_RISK             = "CRITICAL_PATH_RISK"
    SUDDEN_VRU_CROSSING            = "SUDDEN_VRU_CROSSING"
    SUDDEN_CATTLE_CROSSING         = "SUDDEN_CATTLE_CROSSING"
    DYNAMIC_OBSTACLE_INTRUSION     = "DYNAMIC_OBSTACLE_INTRUSION"
    VEHICLE_CUT_IN                 = "VEHICLE_CUT_IN"
    CRITICAL_ROAD_HAZARD           = "CRITICAL_ROAD_HAZARD"
    # Safety Monitor-derived
    SAFETY_MONITOR_CRITICAL        = "SAFETY_MONITOR_CRITICAL"
    SAFETY_MONITOR_HIGH_ALERT      = "SAFETY_MONITOR_HIGH_ALERT"
    SAFETY_MONITOR_RESTRICTED      = "SAFETY_MONITOR_RESTRICTED"
    SAFETY_MONITOR_DEGRADED        = "SAFETY_MONITOR_DEGRADED"
    SAFETY_MONITOR_UNKNOWN         = "SAFETY_MONITOR_UNKNOWN"
    # Safety Gate-derived
    SAFETY_GATE_CRITICAL           = "SAFETY_GATE_CRITICAL"
    SAFETY_GATE_HIGH_ALERT         = "SAFETY_GATE_HIGH_ALERT"
    SAFETY_GATE_RESTRICTED         = "SAFETY_GATE_RESTRICTED"
    # System failures
    MPC_FAILURE                    = "MPC_FAILURE"
    MPC_CONSTRAINT_VIOLATED        = "MPC_CONSTRAINT_VIOLATED"
    CONTROL_FAILURE                = "CONTROL_FAILURE"
    PLANNER_FAILURE                = "PLANNER_FAILURE"
    TRACKING_LOST                  = "TRACKING_LOST"
    TRACKING_LARGE_DEVIATION       = "TRACKING_LARGE_DEVIATION"
    INVALID_VEHICLE_STATE          = "INVALID_VEHICLE_STATE"
    SYSTEM_CRITICAL_FAILURE        = "SYSTEM_CRITICAL_FAILURE"
    # Staleness
    STALE_SAFETY_STATE             = "STALE_SAFETY_STATE"
    STALE_EMERGENCY_STATE          = "STALE_EMERGENCY_STATE"
    STALE_PLANNER_STATE            = "STALE_PLANNER_STATE"
    STALE_TRACKING_STATE           = "STALE_TRACKING_STATE"
    STALE_MPC_STATE                = "STALE_MPC_STATE"
    STALE_CONTROL_STATE            = "STALE_CONTROL_STATE"
    STALE_VEHICLE_STATE            = "STALE_VEHICLE_STATE"
    # Degradation
    DEGRADED_SYSTEM                = "DEGRADED_SYSTEM"
    NO_VALID_PLANNING_STATE        = "NO_VALID_PLANNING_STATE"
    DEGRADED_PLANNER               = "DEGRADED_PLANNER"
    DEGRADED_TRACKING              = "DEGRADED_TRACKING"
    DEGRADED_MPC                   = "DEGRADED_MPC"
    # Recovery
    RECOVERY_IN_PROGRESS           = "RECOVERY_IN_PROGRESS"
    INSUFFICIENT_CLEAR_CYCLES      = "INSUFFICIENT_CLEAR_CYCLES"
    # Unknown / insufficient evidence
    UNKNOWN_SAFETY_STATE           = "UNKNOWN_SAFETY_STATE"
    INSUFFICIENT_INFORMATION       = "INSUFFICIENT_INFORMATION"


# Deterministic priority ordering for dominant reason selection
OVERRIDE_REASON_PRIORITY: Tuple[OverrideReason, ...] = (
    OverrideReason.SYSTEM_CRITICAL_FAILURE,
    OverrideReason.SAFETY_GATE_CRITICAL,
    OverrideReason.SAFETY_MONITOR_CRITICAL,
    OverrideReason.CRITICAL_EMERGENCY,
    OverrideReason.IMMINENT_COLLISION,
    OverrideReason.CRITICAL_TTC,
    OverrideReason.UNAVOIDABLE_CONFLICT,
    OverrideReason.MPC_CONSTRAINT_VIOLATED,
    OverrideReason.CONTROL_FAILURE,
    OverrideReason.MPC_FAILURE,
    OverrideReason.INVALID_VEHICLE_STATE,
    OverrideReason.TRACKING_LOST,
    OverrideReason.PLANNER_FAILURE,
    OverrideReason.CRITICAL_PATH_RISK,
    OverrideReason.SUDDEN_VRU_CROSSING,
    OverrideReason.SUDDEN_CATTLE_CROSSING,
    OverrideReason.DYNAMIC_OBSTACLE_INTRUSION,
    OverrideReason.VEHICLE_CUT_IN,
    OverrideReason.CRITICAL_ROAD_HAZARD,
    OverrideReason.SAFETY_MONITOR_HIGH_ALERT,
    OverrideReason.SAFETY_GATE_HIGH_ALERT,
    OverrideReason.SAFETY_MONITOR_RESTRICTED,
    OverrideReason.SAFETY_GATE_RESTRICTED,
    OverrideReason.TRACKING_LARGE_DEVIATION,
    OverrideReason.STALE_SAFETY_STATE,
    OverrideReason.STALE_EMERGENCY_STATE,
    OverrideReason.STALE_MPC_STATE,
    OverrideReason.STALE_CONTROL_STATE,
    OverrideReason.STALE_TRACKING_STATE,
    OverrideReason.STALE_PLANNER_STATE,
    OverrideReason.STALE_VEHICLE_STATE,
    OverrideReason.SAFETY_MONITOR_DEGRADED,
    OverrideReason.DEGRADED_SYSTEM,
    OverrideReason.DEGRADED_PLANNER,
    OverrideReason.DEGRADED_TRACKING,
    OverrideReason.DEGRADED_MPC,
    OverrideReason.NO_VALID_PLANNING_STATE,
    OverrideReason.SAFETY_MONITOR_UNKNOWN,
    OverrideReason.UNKNOWN_SAFETY_STATE,
    OverrideReason.INSUFFICIENT_INFORMATION,
    OverrideReason.RECOVERY_IN_PROGRESS,
    OverrideReason.INSUFFICIENT_CLEAR_CYCLES,
)


# ---------------------------------------------------------------------------
# Transition direction
# ---------------------------------------------------------------------------

class TransitionDirection(str, Enum):
    """Direction of authority transition from previous cycle."""
    ESCALATING  = "ESCALATING"   # authority becoming more restrictive
    STABLE      = "STABLE"       # authority unchanged
    RECOVERING  = "RECOVERING"   # authority becoming less restrictive
    INITIAL     = "INITIAL"      # first cycle, no prior state


# ---------------------------------------------------------------------------
# Transition info
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class TransitionInfo:
    """
    Compact description of the authority transition from the previous cycle.

    Fields
    ------
    direction           : ESCALATING | STABLE | RECOVERING | INITIAL.
    previous_authority  : Authority from the prior cycle (or None).
    current_authority   : Authority this cycle.
    hold_cycles         : How many cycles the current authority has been held.
    clear_cycles_needed : How many more clean cycles before a less restrictive
                          authority is permitted (0 = already permitted).
    """
    direction:           TransitionDirection     = TransitionDirection.INITIAL
    previous_authority:  Optional[ControlAuthority] = None
    current_authority:   ControlAuthority        = ControlAuthority.UNKNOWN_CONTROL_AUTHORITY
    hold_cycles:         int                     = 0
    clear_cycles_needed: int                     = 0


# ---------------------------------------------------------------------------
# Safety Supervisor Decision — primary output per cycle
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class SafetySupervisorDecision:
    """
    Immutable Safety Supervisor decision for one cycle.

    This is the primary output of Phase 11.3.
    It MUST NOT directly control the vehicle.
    It MUST NOT generate steering, brake, throttle, CAN, or ECU commands.
    It provides control-authority decisions for downstream consumers (Phase 11.4+).

    Fields
    ------
    timestamp               : Timestamp from primary input (not wall clock).
    schema_version          : "11.3".
    decision_id             : Deterministic ID (authority:dominant_reason:ts).
    frame_id                : Frame counter from primary input.
    control_authority       : The determined control authority.
    safety_state            : Safety state string from Phase 11.1.
    emergency_state         : Emergency state string from Phase 11.2.
    dominant_reason         : Most important OverrideReason.value string.
    reason_codes            : Tuple of all active OverrideReason.value strings.
    severity                : Severity string from dominant emergency/safety.
    urgency                 : Urgency string from dominant emergency.
    confidence              : [0,1] confidence in this decision.
    uncertainty             : [0,1] uncertainty.
    stale                   : True if any critical input was stale.
    degraded                : True if any critical input was degraded.
    override_required       : True when authority requires override.
    normal_control_allowed  : True only when NORMAL_CONTROL.
    normal_control_restricted: True when restricted/safety/override.
    control_withheld        : True when CONTROL_WITHHELD.
    safety_gate_state       : Safety gate state string (passed through).
    emergency_ids           : Tuple of active emergency event IDs.
    safety_event_ids        : Tuple of active safety event IDs.
    planner_state           : Planner status string.
    tracking_state          : Tracking quality string.
    mpc_state               : MPC status string.
    control_state           : Control command status string.
    vehicle_state_valid     : True if vehicle dynamics state is valid.
    transition              : TransitionInfo from previous cycle.
    valid                   : True if decision is based on sufficient data.
    supervisor_status       : SupervisorStatus string.
    """
    timestamp:                float                          = 0.0
    schema_version:           str                            = SUPERVISOR_SCHEMA_VERSION
    decision_id:              str                            = ""
    frame_id:                 int                            = 0
    control_authority:        ControlAuthority               = ControlAuthority.UNKNOWN_CONTROL_AUTHORITY
    safety_state:             str                            = "NOT_AVAILABLE"
    emergency_state:          str                            = "NOT_AVAILABLE"
    dominant_reason:          str                            = OverrideReason.INSUFFICIENT_INFORMATION.value
    reason_codes:             Tuple[str, ...]                = field(default_factory=tuple)
    severity:                 str                            = "UNKNOWN"
    urgency:                  str                            = "UNKNOWN"
    confidence:               float                          = 0.0
    uncertainty:              float                          = 1.0
    stale:                    bool                           = True
    degraded:                 bool                           = True
    override_required:        bool                           = False
    normal_control_allowed:   bool                           = False
    normal_control_restricted: bool                          = False
    control_withheld:         bool                           = False
    safety_gate_state:        str                            = "NOT_AVAILABLE"
    emergency_ids:            Tuple[str, ...]                = field(default_factory=tuple)
    safety_event_ids:         Tuple[str, ...]                = field(default_factory=tuple)
    planner_state:            str                            = "NOT_AVAILABLE"
    tracking_state:           str                            = "NOT_AVAILABLE"
    mpc_state:                str                            = "NOT_AVAILABLE"
    control_state:            str                            = "NOT_AVAILABLE"
    vehicle_state_valid:      bool                           = False
    transition:               TransitionInfo                 = field(default_factory=TransitionInfo)
    valid:                    bool                           = False
    supervisor_status:        str                            = SupervisorStatus.UNAVAILABLE.value

    @property
    def is_override(self) -> bool:
        return self.control_authority in (
            ControlAuthority.OVERRIDE_REQUIRED,
            ControlAuthority.CONTROL_WITHHELD,
            ControlAuthority.SAFETY_CONTROL_REQUIRED,
        )

    @property
    def is_restricted(self) -> bool:
        return self.control_authority in (
            ControlAuthority.RESTRICTED_CONTROL,
            ControlAuthority.SAFETY_CONTROL_REQUIRED,
            ControlAuthority.OVERRIDE_REQUIRED,
            ControlAuthority.CONTROL_WITHHELD,
        )

    def __repr__(self) -> str:
        return (
            f"SafetySupervisorDecision("
            f"authority={self.control_authority.value}, "
            f"reason={self.dominant_reason}, "
            f"confidence={self.confidence:.2f}, "
            f"stale={self.stale})"
        )


# ---------------------------------------------------------------------------
# Safety Supervisor Snapshot — immutable record for external consumers
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class SafetySupervisorSnapshot:
    """
    Immutable snapshot of Safety Supervisor state for one cycle.
    Safe to expose to other modules.

    Fields
    ------
    timestamp           : Timestamp of this snapshot.
    schema_version      : "11.3".
    decision            : Full SafetySupervisorDecision for this cycle.
    prior_authority     : Authority from the previous cycle (or None).
    hold_cycles         : Consecutive cycles at current authority.
    recovery_cycles     : Consecutive clean cycles during recovery.
    """
    timestamp:      float                          = 0.0
    schema_version: str                            = SUPERVISOR_SCHEMA_VERSION
    decision:       SafetySupervisorDecision       = field(
        default_factory=SafetySupervisorDecision
    )
    prior_authority:  Optional[ControlAuthority]   = None
    hold_cycles:      int                          = 0
    recovery_cycles:  int                          = 0
