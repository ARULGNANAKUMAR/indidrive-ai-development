"""
IndiDrive AI — Phase 11.3 | Safety Supervisor Package
======================================================
Safety Supervisor / Controller Override Decision Layer.

Sits above Phase 11.1 (Safety Monitor) and Phase 11.2 (Emergency Detection).
Produces a deterministic ControlAuthority decision for downstream consumers.

Does NOT generate actuator commands, steering, braking, throttle, CAN or ECU.
"""
from core.safety_supervisor.supervisor_types import (
    SUPERVISOR_SCHEMA_VERSION,
    ControlAuthority,
    OverrideReason,
    SafetySupervisorDecision,
    SafetySupervisorSnapshot,
    SupervisorStatus,
    TransitionDirection,
    TransitionInfo,
)
from core.safety_supervisor.supervisor_config import SupervisorConfig
from core.safety_supervisor.supervisor_engine import SafetySupervisor

__all__ = [
    "SUPERVISOR_SCHEMA_VERSION",
    "ControlAuthority",
    "OverrideReason",
    "SafetySupervisor",
    "SafetySupervisorDecision",
    "SafetySupervisorSnapshot",
    "SupervisorConfig",
    "SupervisorStatus",
    "TransitionDirection",
    "TransitionInfo",
]
