"""
IndiDrive AI — Phase 11.3 | Safety Supervisor Engine
======================================================
Deterministic Safety Supervisor / Controller Override Decision Layer.

This module DECIDES control authority.
It does NOT:
  - generate steering, brake, throttle, CAN, ECU, or actuator commands
  - perform emergency braking or steering
  - run MPC, planner, path generation, or trajectory generation
  - create new perception or prediction
  - duplicate Phase 11.1 safety-state logic
  - duplicate Phase 11.2 emergency-detection logic

Architecture position:
    Safety Monitor (11.1)
    → Emergency Detection (11.2)
    → Safety Supervisor (11.3)   ← this module
    → [Future Phase 11.4 actuator arbitration]

Design rules:
  * Deterministic — same input always → same SafetySupervisorDecision.
  * No wall-clock time inside pure evaluation logic.
  * Conservative: missing/stale/unknown safety-critical data → restrict authority.
  * Hysteresis prevents oscillation; stateless from caller (pass prior snapshot).
  * Zero modification of any Phase 0–11.2 module.
"""
from __future__ import annotations

import math
from typing import List, Optional, Set, Tuple

from .supervisor_config import SupervisorConfig
from .supervisor_types import (
    AUTHORITY_RESTRICTIVENESS,
    OVERRIDE_REASON_PRIORITY,
    SUPERVISOR_SCHEMA_VERSION,
    ControlAuthority,
    OverrideReason,
    SafetySupervisorDecision,
    SafetySupervisorSnapshot,
    SupervisorStatus,
    TransitionDirection,
    TransitionInfo,
)

# Phase 11.1 safety states
from core.safety.safety_types import SafetyState
# Phase 11.2 emergency states and types
from core.safety.emergency_types import (
    EmergencyState,
    EmergencyType,
    EmergencySeverity,
    EmergencyUrgency,
)

__all__ = ["SafetySupervisor"]

_NA = "NOT_AVAILABLE"


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _finite(val: object) -> bool:
    try:
        return math.isfinite(float(val))  # type: ignore[arg-type]
    except (TypeError, ValueError):
        return False


def _valid_ts(ts: object) -> bool:
    try:
        f = float(ts)  # type: ignore[arg-type]
        return math.isfinite(f) and f >= 0.0
    except (TypeError, ValueError):
        return False


def _is_stale(data_ts: float, ref_ts: float, timeout_s: float) -> bool:
    if not _valid_ts(data_ts) or not _valid_ts(ref_ts):
        return True
    return (ref_ts - data_ts) > timeout_s


def _clamp01(v: float) -> float:
    return min(1.0, max(0.0, v))


def _most_restrictive(authorities: List[ControlAuthority]) -> ControlAuthority:
    """
    Return the most restrictive authority from a list.
    UNKNOWN is treated as more restrictive than NORMAL_CONTROL but yields to
    any explicit restriction (DEGRADED and above in AUTHORITY_RESTRICTIVENESS).
    """
    has_unknown = ControlAuthority.UNKNOWN_CONTROL_AUTHORITY in authorities
    explicit = [a for a in authorities
                if a not in (ControlAuthority.UNKNOWN_CONTROL_AUTHORITY,
                             ControlAuthority.NORMAL_CONTROL)]
    if explicit:
        for a in AUTHORITY_RESTRICTIVENESS:
            if a in explicit:
                return a
    if has_unknown:
        return ControlAuthority.UNKNOWN_CONTROL_AUTHORITY
    return ControlAuthority.NORMAL_CONTROL


def _dominant_reason(reasons: List[OverrideReason]) -> Optional[OverrideReason]:
    """Return the highest-priority reason from a list."""
    if not reasons:
        return None
    reason_set = set(reasons)
    for r in OVERRIDE_REASON_PRIORITY:
        if r in reason_set:
            return r
    return reasons[0]


def _transition_direction(
    prior: Optional[ControlAuthority],
    current: ControlAuthority,
) -> TransitionDirection:
    if prior is None:
        return TransitionDirection.INITIAL
    if prior == current:
        return TransitionDirection.STABLE
    # More restrictive = earlier in AUTHORITY_RESTRICTIVENESS
    prior_idx = next(
        (i for i, a in enumerate(AUTHORITY_RESTRICTIVENESS) if a == prior),
        len(AUTHORITY_RESTRICTIVENESS),
    )
    curr_idx = next(
        (i for i, a in enumerate(AUTHORITY_RESTRICTIVENESS) if a == current),
        len(AUTHORITY_RESTRICTIVENESS),
    )
    return TransitionDirection.ESCALATING if curr_idx < prior_idx \
           else TransitionDirection.RECOVERING


# ---------------------------------------------------------------------------
# Safety Supervisor
# ---------------------------------------------------------------------------

class SafetySupervisor:
    """
    Deterministic Safety Supervisor / Controller Override Decision Layer.

    Usage (stateless)
    -----------------
    ::
        supervisor = SafetySupervisor(SupervisorConfig.default())
        decision = supervisor.evaluate(
            safety_monitor_state=sm_state,
            emergency_detection_state=em_state,
            planner_output=po,
            tracking_snapshot=ts,
            mpc_snapshot=mpc,
            control_command=cmd,
            dynamics_snapshot=dyn,
        )

    Usage (with hysteresis)
    -----------------------
    ::
        snapshot = supervisor.evaluate_with_snapshot(
            ...,
            prior_snapshot=prev_snapshot,
        )

    Same input always produces the same SafetySupervisorDecision.
    Output NEVER controls the vehicle.
    """

    def __init__(self, config: Optional[SupervisorConfig] = None) -> None:
        self._cfg = config if config is not None else SupervisorConfig.default()

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def evaluate(
        self,
        *,
        safety_monitor_state=None,
        emergency_detection_state=None,
        planner_output=None,
        tracking_snapshot=None,
        mpc_snapshot=None,
        control_command=None,
        dynamics_snapshot=None,
        reference_timestamp: Optional[float] = None,
        prior_snapshot: Optional[SafetySupervisorSnapshot] = None,
    ) -> SafetySupervisorDecision:
        """
        Evaluate control authority from current system state.

        Parameters
        ----------
        safety_monitor_state      : SafetyMonitorState from Phase 11.1.
        emergency_detection_state : EmergencyDetectionState from Phase 11.2.
        planner_output            : PlannerOutput or None.
        tracking_snapshot         : TrackingSnapshot or None.
        mpc_snapshot              : MPCSnapshot or None.
        control_command           : VehicleControlCommand or None.
        dynamics_snapshot         : DynamicsSnapshot or None.
        reference_timestamp       : Reference timestamp; derived if None.
        prior_snapshot            : Previous SafetySupervisorSnapshot for
                                    hysteresis. Pass None for stateless.

        Returns
        -------
        SafetySupervisorDecision — immutable, deterministic.
        """
        try:
            return self._evaluate_safe(
                safety_monitor_state=safety_monitor_state,
                emergency_detection_state=emergency_detection_state,
                planner_output=planner_output,
                tracking_snapshot=tracking_snapshot,
                mpc_snapshot=mpc_snapshot,
                control_command=control_command,
                dynamics_snapshot=dynamics_snapshot,
                reference_timestamp=reference_timestamp,
                prior_snapshot=prior_snapshot,
            )
        except Exception as exc:  # pragma: no cover — defensive wrapper
            ts = reference_timestamp if _valid_ts(reference_timestamp) else 0.0
            return SafetySupervisorDecision(
                timestamp=ts,
                schema_version=SUPERVISOR_SCHEMA_VERSION,
                decision_id=f"ERROR:{ts:.6f}",
                control_authority=ControlAuthority.UNKNOWN_CONTROL_AUTHORITY,
                dominant_reason=OverrideReason.INSUFFICIENT_INFORMATION.value,
                reason_codes=(OverrideReason.INSUFFICIENT_INFORMATION.value,),
                confidence=0.0,
                uncertainty=1.0,
                stale=True,
                degraded=True,
                valid=False,
                supervisor_status=SupervisorStatus.ERROR.value,
            )

    def evaluate_with_snapshot(
        self,
        *,
        safety_monitor_state=None,
        emergency_detection_state=None,
        planner_output=None,
        tracking_snapshot=None,
        mpc_snapshot=None,
        control_command=None,
        dynamics_snapshot=None,
        reference_timestamp: Optional[float] = None,
        prior_snapshot: Optional[SafetySupervisorSnapshot] = None,
    ) -> SafetySupervisorSnapshot:
        """Evaluate and return a full SafetySupervisorSnapshot."""
        decision = self.evaluate(
            safety_monitor_state=safety_monitor_state,
            emergency_detection_state=emergency_detection_state,
            planner_output=planner_output,
            tracking_snapshot=tracking_snapshot,
            mpc_snapshot=mpc_snapshot,
            control_command=control_command,
            dynamics_snapshot=dynamics_snapshot,
            reference_timestamp=reference_timestamp,
            prior_snapshot=prior_snapshot,
        )
        prior_auth = prior_snapshot.decision.control_authority if prior_snapshot else None
        hold_cycles = decision.transition.hold_cycles
        recovery_cycles = decision.transition.clear_cycles_needed
        return SafetySupervisorSnapshot(
            timestamp=decision.timestamp,
            schema_version=SUPERVISOR_SCHEMA_VERSION,
            decision=decision,
            prior_authority=prior_auth,
            hold_cycles=hold_cycles,
            recovery_cycles=recovery_cycles,
        )

    # ------------------------------------------------------------------
    # Phase 11.4 integration — evaluate with fail-safe input
    # ------------------------------------------------------------------

    def evaluate_with_failsafe(
        self,
        *,
        failsafe_decision=None,
        safety_monitor_state=None,
        emergency_detection_state=None,
        planner_output=None,
        tracking_snapshot=None,
        mpc_snapshot=None,
        control_command=None,
        dynamics_snapshot=None,
        reference_timestamp=None,
        prior_snapshot=None,
    ):
        """
        Evaluate control authority using Phase 11.1/11.2 inputs AND a
        Phase 11.4 FailSafeDecision.

        The fail-safe decision contributes one additional (authority, reasons)
        pair to the supervisor's existing aggregation path.  All existing
        Phase 11.1-11.3 logic runs unchanged.

        Parameters
        ----------
        failsafe_decision : FailSafeDecision | None
            Output of Phase 11.4 FailSafeEngine.evaluate() for this cycle.
            If None, behaves identically to evaluate_with_snapshot().
        (remaining parameters) : identical to evaluate_with_snapshot().

        Returns
        -------
        SafetySupervisorSnapshot - identical schema to evaluate_with_snapshot().

        Design rules:
          * Does NOT modify _evaluate_safe() or any existing internal method.
          * The fail-safe authority is an ADDITIONAL input; it can only restrict,
            never relax, the authority determined by Phases 11.1-11.2.
          * CONTROL_WITHHELD from fail-safe -> CONTROL_WITHHELD in final decision.
          * If failsafe_decision is None -> delegates to evaluate_with_snapshot().
        """
        if failsafe_decision is None:
            return self.evaluate_with_snapshot(
                safety_monitor_state=safety_monitor_state,
                emergency_detection_state=emergency_detection_state,
                planner_output=planner_output,
                tracking_snapshot=tracking_snapshot,
                mpc_snapshot=mpc_snapshot,
                control_command=control_command,
                dynamics_snapshot=dynamics_snapshot,
                reference_timestamp=reference_timestamp,
                prior_snapshot=prior_snapshot,
            )

        from core.failsafe.failsafe_supervisor_bridge import translate_failsafe_to_supervisor
        bridge = translate_failsafe_to_supervisor(failsafe_decision)

        base_snapshot = self.evaluate_with_snapshot(
            safety_monitor_state=safety_monitor_state,
            emergency_detection_state=emergency_detection_state,
            planner_output=planner_output,
            tracking_snapshot=tracking_snapshot,
            mpc_snapshot=mpc_snapshot,
            control_command=control_command,
            dynamics_snapshot=dynamics_snapshot,
            reference_timestamp=reference_timestamp,
            prior_snapshot=prior_snapshot,
        )
        base = base_snapshot.decision

        if bridge.authority == ControlAuthority.NORMAL_CONTROL and not bridge.reasons:
            return base_snapshot

        merged_authority = _most_restrictive([base.control_authority, bridge.authority])

        existing_reasons_set = set(base.reason_codes)
        new_reason_strs = tuple(
            r.value for r in bridge.reasons
            if r.value not in existing_reasons_set
        )
        if merged_authority == base.control_authority and not new_reason_strs:
            return base_snapshot

        merged_reason_codes = base.reason_codes + new_reason_strs
        dom_str = base.dominant_reason
        for r in bridge.reasons:
            if r.value not in existing_reasons_set:
                current_dom_idx = next(
                    (i for i, x in enumerate(OVERRIDE_REASON_PRIORITY)
                     if x.value == dom_str),
                    len(OVERRIDE_REASON_PRIORITY),
                )
                new_idx = next(
                    (i for i, x in enumerate(OVERRIDE_REASON_PRIORITY) if x == r),
                    len(OVERRIDE_REASON_PRIORITY),
                )
                if new_idx < current_dom_idx:
                    dom_str = r.value

        merged_stale = base.stale or bridge.stale
        merged_degraded = base.degraded or bridge.degraded
        merged_confidence = min(base.confidence, bridge.confidence) \
            if bridge.confidence > 0.0 else base.confidence

        override_required = merged_authority in (
            ControlAuthority.OVERRIDE_REQUIRED,
            ControlAuthority.SAFETY_CONTROL_REQUIRED,
        )
        normal_allowed = merged_authority == ControlAuthority.NORMAL_CONTROL
        normal_restricted = merged_authority in (
            ControlAuthority.RESTRICTED_CONTROL,
            ControlAuthority.LIMITED_CONTROL,
            ControlAuthority.DEGRADED_CONTROL,
            ControlAuthority.SAFETY_CONTROL_REQUIRED,
            ControlAuthority.OVERRIDE_REQUIRED,
        )
        withheld = merged_authority == ControlAuthority.CONTROL_WITHHELD

        merged_decision = SafetySupervisorDecision(
            timestamp=base.timestamp,
            schema_version=base.schema_version,
            decision_id=f"{merged_authority.value}:{dom_str}:{base.timestamp:.6f}:fs",
            frame_id=base.frame_id,
            control_authority=merged_authority,
            safety_state=base.safety_state,
            emergency_state=base.emergency_state,
            dominant_reason=dom_str,
            reason_codes=merged_reason_codes,
            severity=base.severity,
            urgency=base.urgency,
            confidence=merged_confidence,
            uncertainty=_clamp01(1.0 - merged_confidence),
            stale=merged_stale,
            degraded=merged_degraded,
            override_required=override_required,
            normal_control_allowed=normal_allowed,
            normal_control_restricted=normal_restricted,
            control_withheld=withheld,
            safety_gate_state=base.safety_gate_state,
            emergency_ids=base.emergency_ids,
            safety_event_ids=base.safety_event_ids,
            planner_state=base.planner_state,
            tracking_state=base.tracking_state,
            mpc_state=base.mpc_state,
            control_state=base.control_state,
            vehicle_state_valid=base.vehicle_state_valid,
            transition=base.transition,
            valid=base.valid,
            supervisor_status=base.supervisor_status,
        )

        return SafetySupervisorSnapshot(
            timestamp=base_snapshot.timestamp,
            schema_version=base_snapshot.schema_version,
            decision=merged_decision,
            prior_authority=base_snapshot.prior_authority,
            hold_cycles=base_snapshot.hold_cycles,
            recovery_cycles=base_snapshot.recovery_cycles,
        )

    # ------------------------------------------------------------------
    # Core evaluation
    # ------------------------------------------------------------------

    def _evaluate_safe(
        self,
        *,
        safety_monitor_state,
        emergency_detection_state,
        planner_output,
        tracking_snapshot,
        mpc_snapshot,
        control_command,
        dynamics_snapshot,
        reference_timestamp,
        prior_snapshot,
    ) -> SafetySupervisorDecision:
        cfg = self._cfg

        # Derive reference timestamp
        ref_ts = self._derive_ref_ts(
            reference_timestamp,
            safety_monitor_state,
            emergency_detection_state,
            planner_output,
            tracking_snapshot,
            mpc_snapshot,
            control_command,
            dynamics_snapshot,
        )

        # Extract prior state for hysteresis
        prior_decision = prior_snapshot.decision if prior_snapshot else None
        prior_authority = prior_decision.control_authority if prior_decision else None
        prior_hold_cycles = prior_snapshot.hold_cycles if prior_snapshot else 0
        prior_recovery_cycles = prior_snapshot.recovery_cycles if prior_snapshot else 0

        # --- Evaluate each signal into (authority, reasons) pairs ---
        authorities: List[ControlAuthority] = []
        reasons: List[OverrideReason] = []
        all_stale = False
        all_degraded = False

        # 1. Phase 11.1 Safety Monitor
        sm_auth, sm_reasons, sm_stale, sm_degraded, sm_state_str, sm_conf = \
            self._eval_safety_monitor(safety_monitor_state, ref_ts, cfg)
        authorities.append(sm_auth)
        reasons.extend(sm_reasons)
        all_stale = all_stale or sm_stale
        all_degraded = all_degraded or sm_degraded

        # 2. Phase 11.2 Emergency Detection
        em_auth, em_reasons, em_stale, em_degraded, em_state_str, em_conf = \
            self._eval_emergency(emergency_detection_state, ref_ts, cfg)
        authorities.append(em_auth)
        reasons.extend(em_reasons)
        all_stale = all_stale or em_stale
        all_degraded = all_degraded or em_degraded

        # 3. Planner
        pl_auth, pl_reasons, pl_stale, pl_state_str = \
            self._eval_planner(planner_output, ref_ts, cfg)
        authorities.append(pl_auth)
        reasons.extend(pl_reasons)
        all_stale = all_stale or pl_stale
        gate_state_str = _NA
        if planner_output is not None:
            gate_state_str = str(getattr(planner_output, "safety_gate_state", _NA) or _NA)

        # 4. Tracking
        tr_auth, tr_reasons, tr_stale, tr_state_str = \
            self._eval_tracking(tracking_snapshot, ref_ts, cfg)
        authorities.append(tr_auth)
        reasons.extend(tr_reasons)
        all_stale = all_stale or tr_stale

        # 5. MPC
        mpc_auth, mpc_reasons, mpc_stale, mpc_state_str = \
            self._eval_mpc(mpc_snapshot, ref_ts, cfg)
        authorities.append(mpc_auth)
        reasons.extend(mpc_reasons)
        all_stale = all_stale or mpc_stale

        # 6. Control
        ctrl_auth, ctrl_reasons, ctrl_stale, ctrl_state_str = \
            self._eval_control(control_command, ref_ts, cfg)
        authorities.append(ctrl_auth)
        reasons.extend(ctrl_reasons)
        all_stale = all_stale or ctrl_stale

        # 7. Vehicle dynamics
        veh_auth, veh_reasons, veh_stale, veh_valid = \
            self._eval_vehicle(dynamics_snapshot, ref_ts, cfg)
        authorities.append(veh_auth)
        reasons.extend(veh_reasons)
        all_stale = all_stale or veh_stale

        # --- Aggregate raw authority ---
        raw_authority = _most_restrictive(authorities)

        # --- Apply hysteresis ---
        final_authority, hold_cycles, recovery_cycles = self._apply_hysteresis(
            raw_authority=raw_authority,
            prior_authority=prior_authority,
            prior_hold_cycles=prior_hold_cycles,
            prior_recovery_cycles=prior_recovery_cycles,
            cfg=cfg,
            reasons=reasons,
        )

        # If hysteresis held a more restrictive authority, note it
        if final_authority != raw_authority and final_authority in AUTHORITY_RESTRICTIVENESS:
            raw_idx = next(
                (i for i, a in enumerate(AUTHORITY_RESTRICTIVENESS) if a == raw_authority),
                99,
            )
            fin_idx = next(
                (i for i, a in enumerate(AUTHORITY_RESTRICTIVENESS) if a == final_authority),
                99,
            )
            if fin_idx < raw_idx:
                reasons.append(OverrideReason.INSUFFICIENT_CLEAR_CYCLES)

        # --- Unique reasons, priority ordered ---
        seen: Set[OverrideReason] = set()
        unique_reasons: List[OverrideReason] = []
        for r in reasons:
            if r not in seen:
                seen.add(r)
                unique_reasons.append(r)
        dom = _dominant_reason(unique_reasons)
        dominant_str = dom.value if dom else OverrideReason.INSUFFICIENT_INFORMATION.value
        reason_strs = tuple(r.value for r in sorted(
            unique_reasons,
            key=lambda r: next(
                (i for i, x in enumerate(OVERRIDE_REASON_PRIORITY) if x == r),
                len(OVERRIDE_REASON_PRIORITY),
            ),
        ))

        # --- Transition info ---
        direction = _transition_direction(prior_authority, final_authority)
        transition = TransitionInfo(
            direction=direction,
            previous_authority=prior_authority,
            current_authority=final_authority,
            hold_cycles=hold_cycles,
            clear_cycles_needed=max(0, cfg.clear_cycles - recovery_cycles),
        )

        # --- Confidence ---
        confidence = self._aggregate_confidence(
            sm_conf, em_conf, final_authority, all_stale, all_degraded
        )
        uncertainty = _clamp01(1.0 - confidence)

        # --- Derived booleans ---
        override_required = final_authority in (
            ControlAuthority.OVERRIDE_REQUIRED,
            ControlAuthority.SAFETY_CONTROL_REQUIRED,
        )
        normal_allowed = final_authority == ControlAuthority.NORMAL_CONTROL
        normal_restricted = final_authority in (
            ControlAuthority.RESTRICTED_CONTROL,
            ControlAuthority.LIMITED_CONTROL,
            ControlAuthority.DEGRADED_CONTROL,
            ControlAuthority.SAFETY_CONTROL_REQUIRED,
            ControlAuthority.OVERRIDE_REQUIRED,
        )
        withheld = final_authority == ControlAuthority.CONTROL_WITHHELD

        # --- Emergency / safety event IDs ---
        em_ids = self._collect_emergency_ids(emergency_detection_state)
        sm_event_ids = self._collect_safety_event_ids(safety_monitor_state)

        # --- Severity / urgency from emergency ---
        sev_str = "UNKNOWN"
        urg_str = "UNKNOWN"
        if emergency_detection_state is not None:
            sev = getattr(emergency_detection_state, "dominant_severity", None)
            sev_str = sev.value if hasattr(sev, "value") else str(sev or "UNKNOWN")
            urg = getattr(emergency_detection_state, "dominant_urgency", None)
            urg_str = urg.value if hasattr(urg, "value") else str(urg or "UNKNOWN")

        # --- Valid ---
        valid = (
            safety_monitor_state is not None or
            emergency_detection_state is not None
        ) and final_authority != ControlAuthority.UNKNOWN_CONTROL_AUTHORITY

        decision_id = f"{final_authority.value}:{dominant_str}:{ref_ts:.6f}"
        frame_id = 0
        if safety_monitor_state is not None:
            frame_id = int(getattr(safety_monitor_state, "frame_id", 0) or 0)

        status = SupervisorStatus.OK if valid else SupervisorStatus.DEGRADED

        return SafetySupervisorDecision(
            timestamp=ref_ts,
            schema_version=SUPERVISOR_SCHEMA_VERSION,
            decision_id=decision_id,
            frame_id=frame_id,
            control_authority=final_authority,
            safety_state=sm_state_str,
            emergency_state=em_state_str,
            dominant_reason=dominant_str,
            reason_codes=reason_strs,
            severity=sev_str,
            urgency=urg_str,
            confidence=confidence,
            uncertainty=uncertainty,
            stale=all_stale,
            degraded=all_degraded,
            override_required=override_required,
            normal_control_allowed=normal_allowed,
            normal_control_restricted=normal_restricted,
            control_withheld=withheld,
            safety_gate_state=gate_state_str,
            emergency_ids=em_ids,
            safety_event_ids=sm_event_ids,
            planner_state=pl_state_str,
            tracking_state=tr_state_str,
            mpc_state=mpc_state_str,
            control_state=ctrl_state_str,
            vehicle_state_valid=veh_valid,
            transition=transition,
            valid=valid,
            supervisor_status=status.value,
        )

    # ------------------------------------------------------------------
    # Reference timestamp
    # ------------------------------------------------------------------

    def _derive_ref_ts(self, ref_ts, sm, em, po, ts, mpc, cmd, dyn) -> float:
        if _valid_ts(ref_ts):
            return float(ref_ts)
        candidates: List[float] = []
        for attr, obj in [
            ("timestamp", sm), ("timestamp", em),
            ("timestamp", po), ("snap_timestamp", ts),
            ("snap_timestamp", mpc), ("timestamp", cmd),
            ("snapshot_timestamp", dyn),
        ]:
            val = getattr(obj, attr, None) if obj is not None else None
            if _valid_ts(val):
                candidates.append(float(val))
        return max(candidates) if candidates else 0.0

    # ------------------------------------------------------------------
    # Per-signal evaluators
    # ------------------------------------------------------------------

    def _eval_safety_monitor(
        self, sm, ref_ts: float, cfg: SupervisorConfig
    ) -> Tuple[ControlAuthority, List[OverrideReason], bool, bool, str, float]:
        """Returns (authority, reasons, stale, degraded, state_str, confidence)."""
        if sm is None:
            return (
                ControlAuthority.UNKNOWN_CONTROL_AUTHORITY,
                [OverrideReason.UNKNOWN_SAFETY_STATE],
                True, True, _NA, 0.0,
            )

        sm_ts = float(getattr(sm, "timestamp", 0.0) or 0.0)
        stale = _is_stale(sm_ts, ref_ts, cfg.safety_state_timeout_s) or \
                bool(getattr(sm, "stale", False))
        degraded = bool(getattr(sm, "degraded", False))
        confidence = float(getattr(sm, "confidence", 0.0) or 0.0)

        safety_state = getattr(sm, "overall_safety_state", None)
        ss = safety_state  # keep enum for comparison
        ss_str = ss.value if hasattr(ss, "value") else str(ss or _NA)

        if stale:
            return (
                ControlAuthority.RESTRICTED_CONTROL,
                [OverrideReason.STALE_SAFETY_STATE],
                True, degraded, ss_str, confidence * 0.5,
            )

        reasons: List[OverrideReason] = []
        authority: ControlAuthority

        if ss == SafetyState.CRITICAL:
            authority = ControlAuthority.OVERRIDE_REQUIRED
            reasons.append(OverrideReason.SAFETY_MONITOR_CRITICAL)
        elif ss == SafetyState.HIGH_ALERT:
            authority = ControlAuthority.SAFETY_CONTROL_REQUIRED
            reasons.append(OverrideReason.SAFETY_MONITOR_HIGH_ALERT)
        elif ss == SafetyState.RESTRICTED:
            authority = ControlAuthority.RESTRICTED_CONTROL
            reasons.append(OverrideReason.SAFETY_MONITOR_RESTRICTED)
        elif ss == SafetyState.CAUTION:
            authority = ControlAuthority.LIMITED_CONTROL
        elif ss == SafetyState.DEGRADED:
            authority = ControlAuthority.DEGRADED_CONTROL
            reasons.append(OverrideReason.SAFETY_MONITOR_DEGRADED)
        elif ss == SafetyState.UNKNOWN:
            authority = ControlAuthority.UNKNOWN_CONTROL_AUTHORITY
            reasons.append(OverrideReason.SAFETY_MONITOR_UNKNOWN)
        elif ss == SafetyState.SAFE:
            authority = ControlAuthority.NORMAL_CONTROL
        else:
            authority = ControlAuthority.UNKNOWN_CONTROL_AUTHORITY
            reasons.append(OverrideReason.UNKNOWN_SAFETY_STATE)

        return authority, reasons, stale, degraded, ss_str, confidence

    # --

    def _eval_emergency(
        self, em, ref_ts: float, cfg: SupervisorConfig
    ) -> Tuple[ControlAuthority, List[OverrideReason], bool, bool, str, float]:
        if em is None:
            # No emergency detection → no additional restriction from this signal
            return ControlAuthority.NORMAL_CONTROL, [], False, False, _NA, 1.0

        em_ts = float(getattr(em, "timestamp", 0.0) or 0.0)
        stale = _is_stale(em_ts, ref_ts, cfg.emergency_state_timeout_s) or \
                bool(getattr(em, "stale", False))
        degraded = bool(getattr(em, "degraded", False))
        confidence = float(getattr(em, "confidence", 0.0) or 0.0)

        em_state = getattr(em, "emergency_state", None)
        es = em_state
        es_str = es.value if hasattr(es, "value") else str(es or _NA)

        if stale:
            return (
                ControlAuthority.RESTRICTED_CONTROL,
                [OverrideReason.STALE_EMERGENCY_STATE],
                True, degraded, es_str, confidence * 0.5,
            )

        reasons: List[OverrideReason] = []
        em_type = getattr(em, "dominant_emergency_type", None)
        authority: ControlAuthority

        # Map emergency type → reason code
        type_reason_map = {
            EmergencyType.IMMINENT_COLLISION:              OverrideReason.IMMINENT_COLLISION,
            EmergencyType.CRITICAL_TTC:                   OverrideReason.CRITICAL_TTC,
            EmergencyType.UNAVOIDABLE_TRAJECTORY_CONFLICT:OverrideReason.UNAVOIDABLE_CONFLICT,
            EmergencyType.CRITICAL_PATH_RISK:             OverrideReason.CRITICAL_PATH_RISK,
            EmergencyType.VULNERABLE_ROAD_USER_CONFLICT:  OverrideReason.SUDDEN_VRU_CROSSING,
            EmergencyType.SUDDEN_PEDESTRIAN_CROSSING:     OverrideReason.SUDDEN_VRU_CROSSING,
            EmergencyType.SUDDEN_CATTLE_CROSSING:         OverrideReason.SUDDEN_CATTLE_CROSSING,
            EmergencyType.DYNAMIC_OBSTACLE_INTRUSION:     OverrideReason.DYNAMIC_OBSTACLE_INTRUSION,
            EmergencyType.VEHICLE_CUT_IN:                 OverrideReason.VEHICLE_CUT_IN,
            EmergencyType.CRITICAL_ROAD_HAZARD:           OverrideReason.CRITICAL_ROAD_HAZARD,
            EmergencyType.PLANNER_FAILURE:                OverrideReason.PLANNER_FAILURE,
            EmergencyType.MPC_FAILURE:                    OverrideReason.MPC_FAILURE,
            EmergencyType.CONTROL_FAILURE:                OverrideReason.CONTROL_FAILURE,
            EmergencyType.TRACKING_LOST:                  OverrideReason.TRACKING_LOST,
            EmergencyType.VEHICLE_STATE_INVALID:          OverrideReason.INVALID_VEHICLE_STATE,
            EmergencyType.SAFETY_MONITOR_CRITICAL:        OverrideReason.SAFETY_MONITOR_CRITICAL,
            EmergencyType.SYSTEM_CRITICAL_FAILURE:        OverrideReason.SYSTEM_CRITICAL_FAILURE,
            EmergencyType.PATH_BLOCKED:                   OverrideReason.NO_VALID_PLANNING_STATE,
        }
        if em_type in type_reason_map:
            reasons.append(type_reason_map[em_type])

        if es == EmergencyState.CRITICAL_EMERGENCY:
            authority = ControlAuthority.OVERRIDE_REQUIRED
            if not reasons:
                reasons.append(OverrideReason.CRITICAL_EMERGENCY)
        elif es == EmergencyState.EMERGENCY_DETECTED:
            authority = ControlAuthority.SAFETY_CONTROL_REQUIRED
            if not reasons:
                reasons.append(OverrideReason.CRITICAL_EMERGENCY)
        elif es == EmergencyState.POTENTIAL_EMERGENCY:
            authority = ControlAuthority.RESTRICTED_CONTROL
        elif es == EmergencyState.EMERGENCY_DEGRADED:
            authority = ControlAuthority.DEGRADED_CONTROL
            reasons.append(OverrideReason.DEGRADED_SYSTEM)
        elif es == EmergencyState.EMERGENCY_UNKNOWN:
            authority = ControlAuthority.UNKNOWN_CONTROL_AUTHORITY
            reasons.append(OverrideReason.UNKNOWN_SAFETY_STATE)
        elif es in (EmergencyState.NO_EMERGENCY, EmergencyState.EMERGENCY_CLEARED):
            authority = ControlAuthority.NORMAL_CONTROL
        else:
            authority = ControlAuthority.UNKNOWN_CONTROL_AUTHORITY
            reasons.append(OverrideReason.UNKNOWN_SAFETY_STATE)

        return authority, reasons, stale, degraded, es_str, confidence

    # --

    def _eval_planner(
        self, po, ref_ts: float, cfg: SupervisorConfig
    ) -> Tuple[ControlAuthority, List[OverrideReason], bool, str]:
        if po is None:
            return ControlAuthority.NORMAL_CONTROL, [], False, _NA

        po_ts = float(getattr(po, "timestamp", 0.0) or 0.0)
        stale = _is_stale(po_ts, ref_ts, cfg.planner_state_timeout_s) or \
                bool(getattr(po, "stale", False))
        po_degraded = bool(getattr(po, "degraded", True))

        ps = getattr(po, "planning_status", None)
        ps_str = ps.value if hasattr(ps, "value") else str(ps or _NA)

        # Safety gate — supervisor may never grant stronger authority than gate
        gate = str(getattr(po, "safety_gate_state", _NA) or _NA)

        reasons: List[OverrideReason] = []
        authority = ControlAuthority.NORMAL_CONTROL

        if stale:
            return ControlAuthority.RESTRICTED_CONTROL, \
                   [OverrideReason.STALE_PLANNER_STATE], True, ps_str

        # Safety gate overrides
        if gate in ("CRITICAL",):
            return ControlAuthority.OVERRIDE_REQUIRED, \
                   [OverrideReason.SAFETY_GATE_CRITICAL], stale, ps_str
        elif gate in ("HIGH_ALERT",):
            authority = ControlAuthority.SAFETY_CONTROL_REQUIRED
            reasons.append(OverrideReason.SAFETY_GATE_HIGH_ALERT)
        elif gate in ("RESTRICTED",):
            authority = ControlAuthority.RESTRICTED_CONTROL
            reasons.append(OverrideReason.SAFETY_GATE_RESTRICTED)

        # Planner status
        if ps_str in ("INVALID_INPUT", "NO_FEASIBLE_CANDIDATE", "BLOCKED"):
            authority = _most_restrictive([authority, ControlAuthority.SAFETY_CONTROL_REQUIRED])
            reasons.append(OverrideReason.PLANNER_FAILURE)
        elif ps_str in ("STALE_INPUT",):
            authority = _most_restrictive([authority, ControlAuthority.RESTRICTED_CONTROL])
            reasons.append(OverrideReason.STALE_PLANNER_STATE)
        elif ps_str in ("DEGRADED",) or po_degraded:
            authority = _most_restrictive([authority, ControlAuthority.DEGRADED_CONTROL])
            if OverrideReason.DEGRADED_PLANNER not in reasons:
                reasons.append(OverrideReason.DEGRADED_PLANNER)

        # Risk summary
        risk_summary = getattr(po, "risk_summary", None)
        if risk_summary is not None:
            all_high = bool(getattr(risk_summary, "all_candidates_high_risk", False))
            if all_high and not bool(getattr(po, "planning_allowed", True)):
                authority = _most_restrictive([authority, ControlAuthority.SAFETY_CONTROL_REQUIRED])
                reasons.append(OverrideReason.NO_VALID_PLANNING_STATE)

        return authority, reasons, stale, ps_str

    # --

    def _eval_tracking(
        self, ts_snap, ref_ts: float, cfg: SupervisorConfig
    ) -> Tuple[ControlAuthority, List[OverrideReason], bool, str]:
        if ts_snap is None:
            return ControlAuthority.NORMAL_CONTROL, [], False, _NA

        snap_ts = float(getattr(ts_snap, "snap_timestamp", 0.0) or 0.0)
        stale = _is_stale(snap_ts, ref_ts, cfg.tracking_state_timeout_s)

        quality = getattr(ts_snap, "tracking_quality", None)
        tq_str = quality.value if hasattr(quality, "value") else str(quality or _NA)

        if stale:
            return ControlAuthority.RESTRICTED_CONTROL, \
                   [OverrideReason.STALE_TRACKING_STATE], True, tq_str

        reasons: List[OverrideReason] = []
        if tq_str == "REFERENCE_LOST":
            return ControlAuthority.OVERRIDE_REQUIRED, \
                   [OverrideReason.TRACKING_LOST], False, tq_str
        elif tq_str == "INVALID_INPUT":
            return ControlAuthority.SAFETY_CONTROL_REQUIRED, \
                   [OverrideReason.TRACKING_LOST], False, tq_str
        elif tq_str == "STALE_REFERENCE":
            return ControlAuthority.RESTRICTED_CONTROL, \
                   [OverrideReason.STALE_TRACKING_STATE], False, tq_str
        elif tq_str == "LARGE_DEVIATION":
            return ControlAuthority.RESTRICTED_CONTROL, \
                   [OverrideReason.TRACKING_LARGE_DEVIATION], False, tq_str
        elif tq_str in ("DEGRADED", "UNKNOWN"):
            return ControlAuthority.DEGRADED_CONTROL, \
                   [OverrideReason.DEGRADED_TRACKING], False, tq_str

        return ControlAuthority.NORMAL_CONTROL, reasons, stale, tq_str

    # --

    def _eval_mpc(
        self, mpc, ref_ts: float, cfg: SupervisorConfig
    ) -> Tuple[ControlAuthority, List[OverrideReason], bool, str]:
        if mpc is None:
            return ControlAuthority.NORMAL_CONTROL, [], False, _NA

        snap_ts = float(getattr(mpc, "snap_timestamp", 0.0) or 0.0)
        stale = _is_stale(snap_ts, ref_ts, cfg.mpc_state_timeout_s)

        ms = getattr(mpc, "status", None)
        ms_str = ms.value if hasattr(ms, "value") else str(ms or _NA)
        feasible = bool(getattr(mpc, "feasible", True))
        cs = getattr(mpc, "constraint_status", None)
        cs_str = cs.value if hasattr(cs, "value") else str(cs or _NA)

        if stale:
            return ControlAuthority.RESTRICTED_CONTROL, \
                   [OverrideReason.STALE_MPC_STATE], True, ms_str

        if cs_str == "VIOLATED":
            return ControlAuthority.OVERRIDE_REQUIRED, \
                   [OverrideReason.MPC_CONSTRAINT_VIOLATED], False, ms_str

        if ms_str in ("INVALID_INPUT", "INVALID_REFERENCE"):
            return ControlAuthority.SAFETY_CONTROL_REQUIRED, \
                   [OverrideReason.MPC_FAILURE], False, ms_str

        if ms_str in ("NO_FEASIBLE_SOLUTION",) or not feasible:
            return ControlAuthority.SAFETY_CONTROL_REQUIRED, \
                   [OverrideReason.MPC_FAILURE], False, ms_str

        if ms_str in ("DEGRADED", "SOLVER_LIMIT_REACHED"):
            return ControlAuthority.DEGRADED_CONTROL, \
                   [OverrideReason.DEGRADED_MPC], False, ms_str

        return ControlAuthority.NORMAL_CONTROL, [], False, ms_str

    # --

    def _eval_control(
        self, cmd, ref_ts: float, cfg: SupervisorConfig
    ) -> Tuple[ControlAuthority, List[OverrideReason], bool, str]:
        if cmd is None:
            return ControlAuthority.NORMAL_CONTROL, [], False, _NA

        cmd_ts = float(getattr(cmd, "timestamp", 0.0) or 0.0)
        stale = _is_stale(cmd_ts, ref_ts, cfg.control_state_timeout_s)

        cs = getattr(cmd, "status", None)
        cs_str = cs.value if hasattr(cs, "value") else str(cs or _NA)

        if stale or cs_str == "STALE":
            return ControlAuthority.RESTRICTED_CONTROL, \
                   [OverrideReason.STALE_CONTROL_STATE], True, cs_str

        if cs_str in ("INVALID", "NO_SOLUTION"):
            return ControlAuthority.SAFETY_CONTROL_REQUIRED, \
                   [OverrideReason.CONTROL_FAILURE], False, cs_str

        if cs_str in ("DEGRADED",):
            return ControlAuthority.DEGRADED_CONTROL, \
                   [OverrideReason.DEGRADED_SYSTEM], False, cs_str

        return ControlAuthority.NORMAL_CONTROL, [], False, cs_str

    # --

    def _eval_vehicle(
        self, dyn, ref_ts: float, cfg: SupervisorConfig
    ) -> Tuple[ControlAuthority, List[OverrideReason], bool, bool]:
        if dyn is None:
            return ControlAuthority.NORMAL_CONTROL, [], False, False

        snap_ts = float(getattr(dyn, "snapshot_timestamp", 0.0) or 0.0)
        stale = _is_stale(snap_ts, ref_ts, cfg.vehicle_state_timeout_s)

        if stale:
            return ControlAuthority.RESTRICTED_CONTROL, \
                   [OverrideReason.STALE_VEHICLE_STATE], True, False

        invalid_fields: List[str] = []
        for fname in ("x", "y", "yaw", "velocity", "acceleration"):
            val = getattr(dyn, fname, None)
            if val is not None and not _finite(val):
                invalid_fields.append(fname)

        if invalid_fields:
            return ControlAuthority.CONTROL_WITHHELD, \
                   [OverrideReason.INVALID_VEHICLE_STATE], False, False

        return ControlAuthority.NORMAL_CONTROL, [], False, True

    # ------------------------------------------------------------------
    # Hysteresis / recovery
    # ------------------------------------------------------------------

    def _apply_hysteresis(
        self,
        raw_authority: ControlAuthority,
        prior_authority: Optional[ControlAuthority],
        prior_hold_cycles: int,
        prior_recovery_cycles: int,
        cfg: SupervisorConfig,
        reasons: List[OverrideReason],
    ) -> Tuple[ControlAuthority, int, int]:
        """
        Apply hysteresis to prevent rapid state oscillation.
        Returns (final_authority, hold_cycles, recovery_cycles).
        """
        if not cfg.enable_hysteresis or prior_authority is None:
            return raw_authority, 0, 0

        # Restrictiveness indices
        def idx(a: ControlAuthority) -> int:
            if a == ControlAuthority.UNKNOWN_CONTROL_AUTHORITY:
                return 1  # treat as more restrictive than NORMAL
            return next(
                (i for i, x in enumerate(AUTHORITY_RESTRICTIVENESS) if x == a),
                len(AUTHORITY_RESTRICTIVENESS),
            )

        raw_idx = idx(raw_authority)
        prior_idx = idx(prior_authority)
        is_escalating = raw_idx < prior_idx
        is_recovering = raw_idx > prior_idx

        if is_escalating or raw_authority == prior_authority:
            # Escalation or stable — apply immediately
            hold_cycles = prior_hold_cycles + 1 if raw_authority == prior_authority else 1
            recovery_cycles = 0

            # Enforce minimum override hold
            if prior_authority in (
                ControlAuthority.OVERRIDE_REQUIRED,
                ControlAuthority.CONTROL_WITHHELD,
            ) and is_recovering:
                if prior_hold_cycles < cfg.min_override_hold_cycles:
                    reasons.append(OverrideReason.RECOVERY_IN_PROGRESS)
                    return prior_authority, prior_hold_cycles + 1, 0

            return raw_authority, hold_cycles, 0

        # Recovering (less restrictive than prior)
        recovery_cycles = prior_recovery_cycles + 1

        # Check minimum hold still enforced for critical authorities
        if prior_authority in (
            ControlAuthority.OVERRIDE_REQUIRED,
            ControlAuthority.CONTROL_WITHHELD,
        ) and prior_hold_cycles < cfg.min_override_hold_cycles:
            reasons.append(OverrideReason.RECOVERY_IN_PROGRESS)
            return prior_authority, prior_hold_cycles + 1, recovery_cycles

        # Check clear cycles
        if recovery_cycles < cfg.clear_cycles:
            reasons.append(OverrideReason.INSUFFICIENT_CLEAR_CYCLES)
            return prior_authority, prior_hold_cycles, recovery_cycles

        # Sufficient clear cycles — allow step-down
        return raw_authority, 0, 0

    # ------------------------------------------------------------------
    # Helper collectors
    # ------------------------------------------------------------------

    def _collect_emergency_ids(self, em) -> Tuple[str, ...]:
        if em is None:
            return ()
        events = getattr(em, "active_events", ()) or ()
        return tuple(
            str(getattr(ev, "event_id", "")) for ev in events
            if getattr(ev, "event_id", "")
        )

    def _collect_safety_event_ids(self, sm) -> Tuple[str, ...]:
        if sm is None:
            return ()
        events = getattr(sm, "active_events", ()) or ()
        return tuple(
            str(getattr(ev, "event_id", "")) for ev in events
            if getattr(ev, "event_id", "")
        )

    def _aggregate_confidence(
        self,
        sm_conf: float,
        em_conf: float,
        authority: ControlAuthority,
        stale: bool,
        degraded: bool,
    ) -> float:
        if authority == ControlAuthority.NORMAL_CONTROL:
            base = (sm_conf + em_conf) / 2.0
        elif authority in (
            ControlAuthority.OVERRIDE_REQUIRED,
            ControlAuthority.CONTROL_WITHHELD,
        ):
            base = max(sm_conf, em_conf)  # high confidence in the problem
        else:
            base = (sm_conf + em_conf) / 2.0

        if stale:
            base *= 0.6
        if degraded:
            base *= 0.8

        return _clamp01(base)
