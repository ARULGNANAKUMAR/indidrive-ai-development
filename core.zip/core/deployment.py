"""
IndiDrive AI — Phase 5 | Deployment Mode Manager
Tracks which mode the platform is running in. This flags behavior for
other modules to check (e.g. Benchmark Mode disables live-traffic writes
to ECHO; Offline Mode blocks any outbound calls) — it's a shared state
file, not a process manager, since actually sandboxing network/disk
access per-mode would require OS-level controls outside this app's scope.
"""
from __future__ import annotations
import json
import time
from pathlib import Path

STORAGE_ROOT = Path(__file__).resolve().parent.parent / "storage"
STATE_PATH = STORAGE_ROOT / "deployment_state.json"

MODES = ["demo", "research", "training", "benchmark", "offline"]

MODE_DESCRIPTIONS = {
    "demo": "Scripted, safe scenarios for live presentation. ECHO writes disabled.",
    "research": "Full logging, all ECHO writes enabled, verbose diagnostics.",
    "training": "Dataset + auto-labeling pipelines prioritized; benchmark suite paused.",
    "benchmark": "Runs the full test suite; ECHO experience writes are recorded but flagged read-only for principle promotion.",
    "offline": "No calls to Phase 2/3/4 APIs attempted; all endpoints return synthetic data only.",
}


class DeploymentManager:
    def __init__(self):
        STORAGE_ROOT.mkdir(parents=True, exist_ok=True)
        if not STATE_PATH.exists():
            self.set_mode("research")

    def get_mode(self) -> dict:
        return json.loads(STATE_PATH.read_text())

    def set_mode(self, mode: str) -> dict:
        if mode not in MODES:
            raise ValueError(f"mode must be one of {MODES}")
        state = {"mode": mode, "description": MODE_DESCRIPTIONS[mode], "set_at": time.time()}
        STATE_PATH.write_text(json.dumps(state, indent=2))
        return state

    def list_modes(self) -> dict:
        return MODE_DESCRIPTIONS
