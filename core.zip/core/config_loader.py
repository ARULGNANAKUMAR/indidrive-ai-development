"""
IndiDrive AI — Phase 0 | Config Loader
========================================
Small, dependency-light loader for config/*.yaml. Used by the health
check system and app.py. Does not change how any existing module reads
its own settings (dataset manager, deployment manager, etc. keep their
own defaults) — this is new Phase 0 infrastructure, additive only.

Requires PyYAML (already in requirements.txt). If PyYAML is missing,
raises a clear ConfigError instead of crashing with an ImportError deep
in a stack trace.
"""
from __future__ import annotations

from pathlib import Path
from typing import Any, Optional

ROOT = Path(__file__).resolve().parent.parent
CONFIG_DIR = ROOT / "config"

CONFIG_FILES = {
    "system": "system_config.yaml",
    "vehicle": "vehicle_config.yaml",
    "sensor": "sensor_config.yaml",
    "planner": "planner_config.yaml",
    # Phase 2 addition — additive only, does not change how the four
    # Phase 0 files above are read.
    "perception": "perception_config.yaml",
    # Phase 3 addition — additive only, does not change how the Phase 0/2
    # files above are read.
    "fusion": "fusion_config.yaml",
    # Phase 4A addition — additive only, does not change how the Phase 0/2/3
    # files above are read.
    "prediction": "prediction_config.yaml",
    # Phase 5.3A addition — additive only, does not change how earlier
    # config files are read.
    # Phase 5.3B also reads from this file (experience_retrieval section).
    "similarity": "similarity_config.yaml",
    # Phase 6.4 addition — Indian-Road Context Fusion thresholds.
    # Additive only; does not change how any earlier config file is read.
    "indian_road_context": "indian_road_context_config.yaml",
    # Phase 7 addition — World Model configuration.
    # Additive only; does not change how any earlier config file is read.
    "world_model": "world_model_config.yaml",
    # Phase 8.1 addition — Situation Assessment & Risk Reasoning.
    # Additive only; does not change how any earlier config file is read.
    "reasoning": "reasoning_config.yaml",
}


class ConfigError(RuntimeError):
    """Raised when a config file is missing, unreadable, or malformed."""


def _load_yaml_module():
    try:
        import yaml  # type: ignore
        return yaml
    except ImportError as e:
        raise ConfigError(
            "PyYAML is required to load config/*.yaml but is not installed. "
            "Install it with: pip install pyyaml --break-system-packages"
        ) from e


def load_config(name: str) -> dict[str, Any]:
    """Load one config file by short name: 'system' | 'vehicle' | 'sensor' | 'planner'."""
    if name not in CONFIG_FILES:
        raise ConfigError(f"Unknown config '{name}'. Expected one of: {list(CONFIG_FILES)}")
    path = CONFIG_DIR / CONFIG_FILES[name]
    if not path.exists():
        raise ConfigError(f"Config file not found: {path}")
    yaml = _load_yaml_module()
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = yaml.safe_load(f)
    except Exception as e:
        raise ConfigError(f"Failed to parse {path}: {e}") from e
    if not isinstance(data, dict):
        raise ConfigError(f"{path} did not parse to a mapping (got {type(data).__name__})")
    return data


def load_all_configs() -> dict[str, dict[str, Any]]:
    """Load all four Phase 0 config files. Raises ConfigError on the first failure."""
    return {name: load_config(name) for name in CONFIG_FILES}


def get(name: str, dotted_key: str, default: Optional[Any] = None) -> Any:
    """
    Convenience accessor: get('system', 'server.port') -> 8004
    Returns `default` if any part of the path is missing (does not raise).
    """
    try:
        data: Any = load_config(name)
    except ConfigError:
        return default
    for part in dotted_key.split("."):
        if isinstance(data, dict) and part in data:
            data = data[part]
        else:
            return default
    return data
